import { randomUUID } from "crypto";
import { NextResponse } from "next/server";
import { hashPassword, readAuthConfig, writeAuthConfig, type AuthPermission } from "@/lib/auth";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { readSettings } from "@/lib/config";
import { listWidgets } from "@/widgets/registry";

export const runtime = "nodejs";

const PERMISSIONS: AuthPermission[] = [
  "dashboard.view", "settings.view", "settings.manage", "layout.manage",
  "widgets.manage", "widgets.control", "terminals.use", "proxmox.control", "dashboards.personal", "backups.manage", "users.manage",
];

async function authorize() {
  const session = await readSessionFromCookies();
  return session && (session.role === "admin" || session.permissions?.includes("*") || session.permissions?.includes("users.manage"))
    ? session
    : null;
}

function cleanPermissions(value: unknown): AuthPermission[] {
  return Array.isArray(value)
    ? [...new Set(value.filter((item): item is AuthPermission => PERMISSIONS.includes(item as AuthPermission)))]
    : [];
}

function cleanIds(value: unknown): string[] {
  return Array.isArray(value)
    ? [...new Set(value.map(String).map((id) => id.trim()).filter((id) => id.length > 0 && id.length <= 128))]
    : [];
}

export async function GET() {
  if (!(await authorize())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const config = await readAuthConfig();
  const settings = await readSettings();
  const enabled = new Set(settings.enabledWidgets);
  return NextResponse.json({
    permissions: PERMISSIONS,
    tabs: settings.tabs.map((tab) => ({ id: tab.id, name: tab.name })),
    widgets: listWidgets().filter((widget) => enabled.has(widget.id)).map((widget) => ({ id: widget.id, name: widget.name, category: widget.category })),
    groups: config.groups,
    users: config.users.map(({ passwordHash: _passwordHash, ...user }) => user),
  });
}

export async function POST(request: Request) {
  const session = await authorize();
  if (!session) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const body = await request.json() as Record<string, unknown>;
  const config = await readAuthConfig();
  try {
    if (body.kind === "group") {
      const name = String(body.name || "").trim();
      if (name.length < 2) throw new Error("Group name must be at least 2 characters");
      if (config.groups.some((group) => group.name.toLowerCase() === name.toLowerCase())) throw new Error("Group already exists");
      config.groups.push({
        id: randomUUID(),
        name,
        permissions: cleanPermissions(body.permissions),
        restrictedTabIds: cleanIds(body.restrictedTabIds),
        restrictedWidgetIds: cleanIds(body.restrictedWidgetIds),
        restrictedLayoutTabIds: cleanIds(body.restrictedLayoutTabIds),
        createdAt: new Date().toISOString(),
      });
    } else {
      const username = String(body.username || "").trim();
      const password = String(body.password || "");
      const temporary = body.temporary === true;
      if (!/^[a-zA-Z0-9._-]{2,64}$/.test(username)) throw new Error("Invalid username");
      if (password.length < (temporary ? 6 : 8)) throw new Error(temporary ? "Temporary password must be at least 6 characters" : "Password must be at least 8 characters");
      if (config.users.some((user) => user.username.toLowerCase() === username.toLowerCase())) throw new Error("Username already exists");
      config.users.push({
        id: randomUUID(), username, passwordHash: await hashPassword(password), role: body.role === "admin" ? "admin" : "user",
        groupIds: Array.isArray(body.groupIds) ? body.groupIds.map(String).filter((id) => config.groups.some((group) => group.id === id)) : [],
        permissions: cleanPermissions(body.permissions),
        restrictedTabIds: cleanIds(body.restrictedTabIds),
        restrictedWidgetIds: cleanIds(body.restrictedWidgetIds),
        restrictedLayoutTabIds: cleanIds(body.restrictedLayoutTabIds),
        disabled: false, mustChangePassword: temporary,
        createdAt: new Date().toISOString(),
      });
    }
    await writeAuthConfig(config);
    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Invalid request" }, { status: 400 });
  }
}

export async function PATCH(request: Request) {
  if (!(await authorize())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const body = await request.json() as Record<string, unknown>;
  const config = await readAuthConfig();
  const id = String(body.id || "");
  if (body.kind === "group") {
    const group = config.groups.find((item) => item.id === id);
    if (!group) return NextResponse.json({ error: "Group not found" }, { status: 404 });
    if (body.name != null) group.name = String(body.name).trim() || group.name;
    if (body.permissions != null) group.permissions = cleanPermissions(body.permissions);
    if (body.restrictedTabIds != null) group.restrictedTabIds = cleanIds(body.restrictedTabIds);
    if (body.restrictedWidgetIds != null) group.restrictedWidgetIds = cleanIds(body.restrictedWidgetIds);
    if (body.restrictedLayoutTabIds != null) group.restrictedLayoutTabIds = cleanIds(body.restrictedLayoutTabIds);
  } else {
    const user = config.users.find((item) => item.id === id);
    if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });
    const nextRole = body.role === "admin" || body.role === "user" ? body.role : user.role;
    const nextDisabled = body.disabled != null ? Boolean(body.disabled) : Boolean(user.disabled);
    const activeAdmins = config.users.filter((item) => item.role === "admin" && !item.disabled);
    if (user.role === "admin" && !user.disabled && activeAdmins.length <= 1 && (nextRole !== "admin" || nextDisabled)) {
      return NextResponse.json({ error: "The last active admin cannot be disabled or demoted" }, { status: 400 });
    }
    if (body.username != null) {
      const username = String(body.username).trim();
      if (!/^[a-zA-Z0-9._-]{2,64}$/.test(username)) {
        return NextResponse.json({ error: "Invalid username" }, { status: 400 });
      }
      if (config.users.some((item) => item.id !== id && item.username.toLowerCase() === username.toLowerCase())) {
        return NextResponse.json({ error: "Username already exists" }, { status: 400 });
      }
      user.username = username;
    }
    user.role = nextRole;
    user.disabled = nextDisabled;
    if (body.groupIds != null) user.groupIds = Array.isArray(body.groupIds) ? body.groupIds.map(String).filter((groupId) => config.groups.some((group) => group.id === groupId)) : [];
    if (body.permissions != null) user.permissions = cleanPermissions(body.permissions);
    if (body.restrictedTabIds != null) user.restrictedTabIds = cleanIds(body.restrictedTabIds);
    if (body.restrictedWidgetIds != null) user.restrictedWidgetIds = cleanIds(body.restrictedWidgetIds);
    if (body.restrictedLayoutTabIds != null) user.restrictedLayoutTabIds = cleanIds(body.restrictedLayoutTabIds);
    if (String(body.password || "").length) {
      if (String(body.password).length < 8) return NextResponse.json({ error: "Password must be at least 8 characters" }, { status: 400 });
      user.passwordHash = await hashPassword(String(body.password));
      if (body.temporary === true) {
        user.mustChangePassword = true;
        user.passwordResetRequestedAt = undefined;
      }
    }
  }
  await writeAuthConfig(config);
  return NextResponse.json({ ok: true, reloginRequired: true });
}

export async function DELETE(request: Request) {
  const session = await authorize();
  if (!session) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const body = await request.json() as { kind?: string; id?: string };
  const config = await readAuthConfig();
  if (body.kind === "group") {
    config.groups = config.groups.filter((group) => group.id !== body.id);
    config.users = config.users.map((user) => ({ ...user, groupIds: user.groupIds.filter((id) => id !== body.id) }));
  } else {
    if (body.id === session.sub) return NextResponse.json({ error: "You cannot delete your own account" }, { status: 400 });
    const target = config.users.find((user) => user.id === body.id);
    if (target?.role === "admin" && config.users.filter((user) => user.role === "admin" && !user.disabled).length <= 1) {
      return NextResponse.json({ error: "Cannot delete the last active admin" }, { status: 400 });
    }
    config.users = config.users.filter((user) => user.id !== body.id);
  }
  await writeAuthConfig(config);
  return NextResponse.json({ ok: true });
}
