import { NextResponse } from "next/server";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { deleteSavedBackup, isSafeBackupId, readSavedBackup } from "@/lib/backup";

async function requireSession() {
  const session = await readSessionFromCookies();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  return null;
}

type Ctx = { params: Promise<{ id: string }> };

/** Download a saved backup as JSON. */
export async function GET(_request: Request, ctx: Ctx) {
  const denied = await requireSession();
  if (denied) return denied;

  const { id } = await ctx.params;
  if (!isSafeBackupId(id)) {
    return NextResponse.json({ error: "Invalid backup id" }, { status: 400 });
  }

  try {
    const backup = await readSavedBackup(id);
    const filename = `${id}.json`;
    return new NextResponse(JSON.stringify(backup, null, 2), {
      status: 200,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Content-Disposition": `attachment; filename="${filename}"`,
        "Cache-Control": "no-store",
      },
    });
  } catch {
    return NextResponse.json({ error: "Backup not found" }, { status: 404 });
  }
}

export async function DELETE(_request: Request, ctx: Ctx) {
  const denied = await requireSession();
  if (denied) return denied;

  const { id } = await ctx.params;
  if (!isSafeBackupId(id)) {
    return NextResponse.json({ error: "Invalid backup id" }, { status: 400 });
  }

  try {
    await deleteSavedBackup(id);
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Backup not found" }, { status: 404 });
  }
}
