import { NextResponse } from "next/server";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import {
  isSafeBackupId,
  parseBookmarksBackupJson,
  readSavedBookmarksBackup,
  restoreBookmarksBackup,
  saveBookmarksBackup,
  type HomedashBookmarksBackup,
} from "@/lib/backup";

async function requireSession() {
  const session = await readSessionFromCookies();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  return null;
}

/**
 * Restore from a saved bookmarks backup id or an uploaded backup payload.
 * body: {
 *   backupId?: string,
 *   backup?: HomedashBookmarksBackup | string (raw JSON),
 *   saveImport?: boolean,
 *   merge?: boolean
 * }
 */
export async function POST(request: Request) {
  const denied = await requireSession();
  if (denied) return denied;

  const body = (await request.json().catch(() => ({}))) as {
    backupId?: string;
    backup?: HomedashBookmarksBackup | string;
    saveImport?: boolean;
    merge?: boolean;
  };

  try {
    let backup: HomedashBookmarksBackup;
    if (body.backupId) {
      if (!isSafeBackupId(body.backupId)) {
        return NextResponse.json({ error: "Invalid backup id" }, { status: 400 });
      }
      backup = await readSavedBookmarksBackup(body.backupId);
    } else if (typeof body.backup === "string") {
      backup = parseBookmarksBackupJson(body.backup);
    } else if (body.backup && typeof body.backup === "object") {
      backup = parseBookmarksBackupJson(JSON.stringify(body.backup));
    } else {
      return NextResponse.json({ error: "Provide backupId or backup payload" }, { status: 400 });
    }

    let saved = null;
    if (body.saveImport) {
      saved = await saveBookmarksBackup(backup);
    }

    const result = await restoreBookmarksBackup(backup, { merge: Boolean(body.merge) });
    return NextResponse.json({ ok: true, result, saved });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Restore failed";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
