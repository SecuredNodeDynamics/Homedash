import { NextResponse } from "next/server";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import {
  bookmarksBackupFilename,
  buildBookmarksBackup,
  listSavedBookmarksBackups,
  saveBookmarksBackup,
} from "@/lib/backup";
import { readSettings } from "@/lib/config";

async function requireSession() {
  const session = await readSessionFromCookies();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  return null;
}

/** Overview + saved bookmarks backups. */
export async function GET() {
  const denied = await requireSession();
  if (denied) return denied;

  const [backups, settings] = await Promise.all([listSavedBookmarksBackups(), readSettings()]);

  return NextResponse.json({
    overview: {
      bookmarkCount: settings.bookmarks?.length || 0,
      groupCount: settings.bookmarkGroups?.length || 0,
      savedBackups: backups.length,
      latestBackupAt: backups[0]?.exportedAt || null,
    },
    backups,
  });
}

/**
 * Create a bookmarks-only backup.
 * body: { label?: string, save?: boolean, download?: boolean }
 * - save (default true): persist under config/backups/bookmarks/
 * - download (default false): also return the backup payload for client download
 */
export async function POST(request: Request) {
  const denied = await requireSession();
  if (denied) return denied;

  const body = (await request.json().catch(() => ({}))) as {
    label?: string;
    save?: boolean;
    download?: boolean;
  };

  const save = body.save !== false;
  const download = Boolean(body.download);

  try {
    const backup = await buildBookmarksBackup(body.label);

    let saved = null;
    if (save) {
      saved = await saveBookmarksBackup(backup);
    }

    if (download || !save) {
      const filename = saved?.filename || bookmarksBackupFilename(backup);
      return NextResponse.json({
        ok: true,
        saved,
        filename,
        backup,
      });
    }

    return NextResponse.json({ ok: true, saved });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Backup failed";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
