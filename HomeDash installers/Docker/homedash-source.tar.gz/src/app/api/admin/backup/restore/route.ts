import { NextResponse } from "next/server";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import {
  isSafeBackupId,
  parseBackupJson,
  readSavedBackup,
  restoreBackup,
  saveBackup,
  type HomedashBackup,
  type RestoreParts,
} from "@/lib/backup";

async function requireSession() {
  const session = await readSessionFromCookies();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  return null;
}

/**
 * Restore from a saved backup id or an uploaded backup payload.
 * body: {
 *   backupId?: string,
 *   backup?: HomedashBackup | string (raw JSON),
 *   saveImport?: boolean,
 *   parts?: { settings?: boolean, layouts?: boolean, widgets?: boolean, widgetIds?: string[] }
 * }
 */
export async function POST(request: Request) {
  const denied = await requireSession();
  if (denied) return denied;

  const body = (await request.json().catch(() => ({}))) as {
    backupId?: string;
    backup?: HomedashBackup | string;
    saveImport?: boolean;
    parts?: RestoreParts;
  };

  const parts: RestoreParts = {
    settings: body.parts?.settings === true,
    layouts: body.parts?.layouts === true,
    widgets: body.parts?.widgets !== false,
    widgetIds: Array.isArray(body.parts?.widgetIds) ? body.parts?.widgetIds : undefined,
  };

  // Default: if nothing specified, restore everything the backup contains.
  if (
    body.parts?.settings == null &&
    body.parts?.layouts == null &&
    body.parts?.widgets == null
  ) {
    parts.settings = true;
    parts.layouts = true;
    parts.widgets = true;
  }

  try {
    let backup: HomedashBackup;
    if (body.backupId) {
      if (!isSafeBackupId(body.backupId)) {
        return NextResponse.json({ error: "Invalid backup id" }, { status: 400 });
      }
      backup = await readSavedBackup(body.backupId);
    } else if (typeof body.backup === "string") {
      backup = parseBackupJson(body.backup);
    } else if (body.backup && typeof body.backup === "object") {
      backup = parseBackupJson(JSON.stringify(body.backup));
    } else {
      return NextResponse.json({ error: "Provide backupId or backup payload" }, { status: 400 });
    }

    // Only restore parts that exist when using "restore all" defaults.
    if (parts.settings && !backup.settings) parts.settings = false;
    if (parts.layouts && !backup.layouts) parts.layouts = false;

    if (!parts.settings && !parts.layouts && !parts.widgets) {
      return NextResponse.json({ error: "Nothing selected to restore" }, { status: 400 });
    }

    let saved = null;
    if (body.saveImport) {
      saved = await saveBackup(backup);
    }

    const result = await restoreBackup(backup, parts);
    return NextResponse.json({ ok: true, result, saved });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Restore failed";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
