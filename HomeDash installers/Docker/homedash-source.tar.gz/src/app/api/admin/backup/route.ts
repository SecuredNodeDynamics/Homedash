import { NextResponse } from "next/server";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import {
  backupFilename,
  backupOverview,
  buildFullBackup,
  buildWidgetsBackup,
  listSavedBackups,
  listWidgetConfigIds,
  saveBackup,
} from "@/lib/backup";
import { readSettings } from "@/lib/config";

async function requireSession() {
  const session = await readSessionFromCookies();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  return null;
}

/** Overview + saved backups + widget config inventory. */
export async function GET() {
  const denied = await requireSession();
  if (denied) return denied;

  const [overview, backups, widgetIds, settings] = await Promise.all([
    backupOverview(),
    listSavedBackups(),
    listWidgetConfigIds(),
    readSettings(),
  ]);

  const labels = new Map(
    (settings.widgetInstances || []).map((inst) => [inst.id, inst.label || inst.widgetId]),
  );

  const widgets = widgetIds.map((id) => ({
    id,
    label: labels.get(id) || id,
    widgetId: id.includes("--") ? id.slice(0, id.indexOf("--")) : id,
  }));

  return NextResponse.json({ overview, backups, widgets });
}

/**
 * Create a backup.
 * body: { kind: "full" | "widgets", widgetIds?: string[], label?: string, save?: boolean, download?: boolean }
 * - save (default true): persist under data/backups/
 * - download (default false): also return the backup payload for client download
 */
export async function POST(request: Request) {
  const denied = await requireSession();
  if (denied) return denied;

  const body = (await request.json().catch(() => ({}))) as {
    kind?: "full" | "widgets";
    widgetIds?: string[];
    label?: string;
    save?: boolean;
    download?: boolean;
  };

  const kind = body.kind === "widgets" ? "widgets" : "full";
  const save = body.save !== false;
  const download = Boolean(body.download);

  try {
    const backup =
      kind === "widgets"
        ? await buildWidgetsBackup(body.widgetIds || [], body.label)
        : await buildFullBackup(body.label);

    let saved = null;
    if (save) {
      saved = await saveBackup(backup);
    }

    if (download || !save) {
      const filename = saved?.filename || backupFilename(backup);
      return NextResponse.json({
        ok: true,
        saved,
        filename,
        backup,
      });
    }

    return NextResponse.json({ ok: true, saved });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Backup failed";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
