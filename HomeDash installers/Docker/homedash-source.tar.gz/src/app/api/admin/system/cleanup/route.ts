import { NextResponse } from "next/server";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { callWidgetAgent, type WidgetAgentJob } from "@/lib/widget-agent";
import { isTrustedOrigin } from "@/lib/security/origin";

export const runtime = "nodejs";

async function authorize() {
  const session = await readSessionFromCookies();
  return session?.role === "admin" || session?.permissions?.includes("*") ? session : null;
}

const CLEANUP_OPTION_KEYS = [
  "dockerImages",
  "containersNetworks",
  "dockerVolumes",
  "packageCache",
  "systemLogs",
] as const;

function parseOptions(input: unknown): Record<(typeof CLEANUP_OPTION_KEYS)[number], boolean> {
  const raw = input && typeof input === "object" ? (input as Record<string, unknown>) : {};
  const options = {} as Record<(typeof CLEANUP_OPTION_KEYS)[number], boolean>;
  for (const key of CLEANUP_OPTION_KEYS) {
    options[key] = raw[key] !== false;
  }
  return options;
}

function parseLogRetentionDays(input: unknown): number {
  const value = Number(input);
  if (!Number.isFinite(value)) return 3;
  return Math.min(90, Math.max(1, Math.round(value)));
}

export async function POST(request: Request) {
  if (!(await authorize())) return NextResponse.json({ error: "Administrator access required" }, { status: 403 });
  if (!isTrustedOrigin(request)) return NextResponse.json({ error: "Cross-origin cleanup request rejected" }, { status: 403 });

  const body = await request.json().catch(() => ({}));
  const options = parseOptions((body as Record<string, unknown>)?.options);
  const logRetentionDays = parseLogRetentionDays((body as Record<string, unknown>)?.logRetentionDays);

  if (!Object.values(options).some(Boolean)) {
    return NextResponse.json({ error: "Choose at least one cleanup task to run" }, { status: 400 });
  }

  try {
    const job = await callWidgetAgent<WidgetAgentJob>("POST", "/cleanup", { options, logRetentionDays });
    return NextResponse.json({ job }, { status: 202 });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Could not start the cleanup job" },
      { status: 502 },
    );
  }
}
