import { NextResponse } from "next/server";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { callWidgetAgent, type CleanupSchedule } from "@/lib/widget-agent";
import { isTrustedOrigin } from "@/lib/security/origin";

export const runtime = "nodejs";

async function authorize() {
  const session = await readSessionFromCookies();
  return session?.role === "admin" || session?.permissions?.includes("*") ? session : null;
}

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!(await authorize())) return NextResponse.json({ error: "Administrator access required" }, { status: 403 });
  if (!isTrustedOrigin(request)) return NextResponse.json({ error: "Cross-origin request rejected" }, { status: 403 });

  const { id } = await params;
  const body = await request.json().catch(() => ({}));
  try {
    const data = await callWidgetAgent<{ schedule: CleanupSchedule }>(
      "PATCH",
      `/cleanup/schedules/${encodeURIComponent(id)}`,
      body,
    );
    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Could not update the cleanup schedule" },
      { status: 400 },
    );
  }
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!(await authorize())) return NextResponse.json({ error: "Administrator access required" }, { status: 403 });
  if (!isTrustedOrigin(request)) return NextResponse.json({ error: "Cross-origin request rejected" }, { status: 403 });

  const { id } = await params;
  try {
    const data = await callWidgetAgent<{ ok: boolean }>("DELETE", `/cleanup/schedules/${encodeURIComponent(id)}`);
    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Could not remove the cleanup schedule" },
      { status: 400 },
    );
  }
}
