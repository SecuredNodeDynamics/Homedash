import { NextResponse } from "next/server";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { callWidgetAgent, type CleanupSchedule } from "@/lib/widget-agent";
import { isTrustedOrigin } from "@/lib/security/origin";

export const runtime = "nodejs";

async function authorize() {
  const session = await readSessionFromCookies();
  return session?.role === "admin" || session?.permissions?.includes("*") ? session : null;
}

export async function GET() {
  if (!(await authorize())) return NextResponse.json({ error: "Administrator access required" }, { status: 403 });

  try {
    const data = await callWidgetAgent<{ schedules: CleanupSchedule[] }>("GET", "/cleanup/schedules");
    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Could not load cleanup schedules" },
      { status: 502 },
    );
  }
}

export async function POST(request: Request) {
  if (!(await authorize())) return NextResponse.json({ error: "Administrator access required" }, { status: 403 });
  if (!isTrustedOrigin(request)) return NextResponse.json({ error: "Cross-origin request rejected" }, { status: 403 });

  const body = await request.json().catch(() => ({}));
  try {
    const data = await callWidgetAgent<{ schedule: CleanupSchedule }>("POST", "/cleanup/schedules", body);
    return NextResponse.json(data, { status: 201 });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Could not create the cleanup schedule" },
      { status: 400 },
    );
  }
}
