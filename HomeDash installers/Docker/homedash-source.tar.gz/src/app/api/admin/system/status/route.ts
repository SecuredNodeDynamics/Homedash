import { NextResponse } from "next/server";
import fs from "node:fs";
import fsp from "node:fs/promises";
import path from "node:path";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { widgetAgentHealth, widgetAgentDiskUsage, type WidgetAgentDiskUsage } from "@/lib/widget-agent";

export const dynamic = "force-dynamic";

// process.env.npm_package_version is only populated when the process is
// launched via `npm run ...`. The production container runs the standalone
// server directly (node server.mjs), so that env var is never set there and
// this used to silently fall back to a hardcoded "0.1.0" forever. Read the
// version straight from package.json instead, which is reliably present at
// the app root in both `npm run dev` and the standalone production build.
function readAppVersion(): string {
  try {
    const pkgPath = path.join(process.cwd(), "package.json");
    const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf8"));
    if (typeof pkg.version === "string" && pkg.version.length > 0) {
      return pkg.version;
    }
  } catch {
    // fall through to env var / default below
  }
  return process.env.npm_package_version || "0.0.0";
}

// The host agent (a systemd service outside this container) is only updated
// when someone re-runs install-agent.sh on the host — applying a system
// update through the app does NOT restart it. So a freshly-updated app can
// briefly run against an older agent that doesn't know /disk-usage yet. Fall
// back to reading the mount straight from this container so the meter still
// works in the meantime; on a typical bind-mounted setup this reports the
// same underlying host disk anyway.
async function containerDiskUsage(): Promise<WidgetAgentDiskUsage | null> {
  try {
    const target = process.cwd();
    const stats = await fsp.statfs(target);
    const total = stats.blocks * stats.bsize;
    const free = stats.bavail * stats.bsize;
    return { path: target, total, used: Math.max(0, total - free), free };
  } catch {
    return null;
  }
}

export async function GET() {
  const session = await readSessionFromCookies();
  if (!(session?.role === "admin" || session?.permissions?.includes("*"))) {
    return NextResponse.json({ error: "Administrator access required" }, { status: 403 });
  }
  const [agent, agentDisk] = await Promise.all([widgetAgentHealth(), widgetAgentDiskUsage()]);
  const disk = agentDisk ?? (await containerDiskUsage());
  return NextResponse.json({ version: readAppVersion(), agent, disk });
}
