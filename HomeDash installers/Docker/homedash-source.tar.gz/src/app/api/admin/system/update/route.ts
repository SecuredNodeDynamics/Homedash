import { createHash, randomUUID } from "crypto";
import { promises as fs } from "fs";
import path from "path";
import { NextResponse } from "next/server";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { getConfigDir } from "@/lib/config";
import { callWidgetAgent, type WidgetAgentJob } from "@/lib/widget-agent";
import { isTrustedOrigin } from "@/lib/security/origin";

export const runtime = "nodejs";
const MAX_UPDATE_BYTES = 100 * 1024 * 1024;

async function authorize() {
  const session = await readSessionFromCookies();
  return session?.role === "admin" || session?.permissions?.includes("*") ? session : null;
}

export async function POST(request: Request) {
  if (!(await authorize())) return NextResponse.json({ error: "Administrator access required" }, { status: 403 });
  if (!isTrustedOrigin(request)) return NextResponse.json({ error: "Cross-origin update request rejected" }, { status: 403 });

  let form: FormData;
  try {
    form = await request.formData();
  } catch {
    return NextResponse.json({ error: "Invalid update upload" }, { status: 400 });
  }
  const file = form.get("package");
  const confirmed = form.get("confirm") === "true";
  if (!(file instanceof File) || !confirmed) {
    return NextResponse.json({ error: "Choose and confirm a Homedash update package" }, { status: 400 });
  }
  if (!file.name.toLowerCase().endsWith(".hdupdate")) {
    return NextResponse.json({ error: "Choose a .hdupdate package" }, { status: 400 });
  }
  if (file.size < 1 || file.size > MAX_UPDATE_BYTES) {
    return NextResponse.json({ error: "Update package must be 100 MB or smaller" }, { status: 413 });
  }

  let stagedPath: string | undefined;
  try {
    const bytes = Buffer.from(await file.arrayBuffer());
    const sha256 = createHash("sha256").update(bytes).digest("hex");
    const uploadDir = path.join(getConfigDir(), "agent", "uploads");
    const stagedName = `${randomUUID()}.hdupdate`;
    stagedPath = path.join(uploadDir, stagedName);

    await fs.mkdir(uploadDir, { recursive: true });
    await fs.writeFile(stagedPath, bytes, { mode: 0o600, flag: "wx" });
    const job = await callWidgetAgent<WidgetAgentJob>("POST", "/system-update", {
      file: stagedName,
      sha256,
    });
    return NextResponse.json({ job, fileName: file.name, sha256 }, { status: 202 });
  } catch (error) {
    if (stagedPath) await fs.unlink(stagedPath).catch(() => undefined);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Could not start the dashboard update" },
      { status: 502 },
    );
  }
}
