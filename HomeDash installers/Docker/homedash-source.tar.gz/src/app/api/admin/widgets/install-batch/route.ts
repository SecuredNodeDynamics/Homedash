import { NextResponse } from "next/server";
import { callWidgetAgent, readWidgetPackageIndex, type WidgetAgentJob } from "@/lib/widget-agent";
import { isTrustedOrigin } from "@/lib/security/origin";

export const runtime = "nodejs";

export async function POST(request: Request) {
  if (!isTrustedOrigin(request)) {
    return NextResponse.json({ error: "Cross-origin installation request rejected" }, { status: 403 });
  }
  const body = (await request.json().catch(() => ({}))) as { ids?: unknown; confirm?: unknown };
  if (!body.confirm || !Array.isArray(body.ids) || body.ids.length < 1 || body.ids.length > 50) {
    return NextResponse.json({ error: "Choose and confirm between 1 and 50 widgets" }, { status: 400 });
  }
  const ids = body.ids.map(String);
  if (new Set(ids).size !== ids.length || ids.some((id) => !/^[a-z0-9][a-z0-9-]*$/.test(id))) {
    return NextResponse.json({ error: "Widget selection is invalid or contains duplicates" }, { status: 400 });
  }
  const index = await readWidgetPackageIndex();
  const selected = ids.map((id) => index.packages.find((item) => item.id === id));
  if (selected.some((item) => !item)) {
    return NextResponse.json({ error: "One or more widget packages are unknown" }, { status: 404 });
  }
  try {
    const job = await callWidgetAgent<WidgetAgentJob>("POST", "/install-batch", {
      packages: selected.map((pkg) => ({
        id: pkg!.id,
        file: pkg!.file,
        sha256: pkg!.sha256,
        homedashVersion: index.homedashVersion,
      })),
    });
    return NextResponse.json({ job }, { status: 202 });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Could not start bulk installation" },
      { status: 502 },
    );
  }
}
