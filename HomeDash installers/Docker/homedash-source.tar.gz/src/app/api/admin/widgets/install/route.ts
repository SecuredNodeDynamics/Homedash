import { NextResponse } from "next/server";
import { callWidgetAgent, readWidgetPackageIndex, type WidgetAgentJob } from "@/lib/widget-agent";
import { isTrustedOrigin } from "@/lib/security/origin";

export const runtime = "nodejs";

export async function POST(request: Request) {
  if (!isTrustedOrigin(request)) {
    return NextResponse.json({ error: "Cross-origin installation request rejected" }, { status: 403 });
  }
  let body: { id?: string; confirm?: boolean };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }
  if (!body.confirm || !body.id || !/^[a-z0-9][a-z0-9-]*$/.test(body.id)) {
    return NextResponse.json({ error: "Widget id and confirmation are required" }, { status: 400 });
  }
  const index = await readWidgetPackageIndex();
  const pkg = index.packages.find((item) => item.id === body.id);
  if (!pkg) return NextResponse.json({ error: "Unknown widget package" }, { status: 404 });
  try {
    const job = await callWidgetAgent<WidgetAgentJob>("POST", "/install", {
      id: pkg.id,
      file: pkg.file,
      sha256: pkg.sha256,
      homedashVersion: index.homedashVersion,
    });
    return NextResponse.json({ job }, { status: 202 });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Could not start installation" },
      { status: 502 },
    );
  }
}
