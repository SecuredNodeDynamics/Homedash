import { NextResponse } from "next/server";
import { callWidgetAgent, type WidgetAgentJob } from "@/lib/widget-agent";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  if (!/^[a-f0-9-]{20,}$/.test(id)) {
    return NextResponse.json({ error: "Invalid job id" }, { status: 400 });
  }
  try {
    const job = await callWidgetAgent<WidgetAgentJob>("GET", `/jobs/${encodeURIComponent(id)}`);
    return NextResponse.json({ job });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Could not read installation job" },
      { status: 502 },
    );
  }
}
