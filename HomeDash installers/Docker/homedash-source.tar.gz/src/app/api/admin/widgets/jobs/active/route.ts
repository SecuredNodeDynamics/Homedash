import { NextResponse } from "next/server";
import { callWidgetAgent, type WidgetAgentJob } from "@/lib/widget-agent";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const result = await callWidgetAgent<{ job: WidgetAgentJob | null }>("GET", "/jobs/active");
    return NextResponse.json(result);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Could not recover the active widget job" },
      { status: 502 },
    );
  }
}
