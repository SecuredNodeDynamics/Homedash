import { NextResponse } from "next/server";
import { listWidgets } from "@/widgets/registry";
import { isNewerVersion, readWidgetPackageIndex, widgetAgentHealth } from "@/lib/widget-agent";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const PREINSTALLED_WIDGETS = new Set(["bookmarks", "notes", "clock", "weather"]);

export async function GET() {
  const [index, agent] = await Promise.all([
    readWidgetPackageIndex(),
    widgetAgentHealth(),
  ]);
  const installedWidgets = listWidgets();
  const installed = new Map(installedWidgets.map((widget) => [widget.id, widget.version]));
  const catalogIds = new Set(index.packages.map((pkg) => pkg.id));

  const cataloged = index.packages
    .filter((pkg) => !PREINSTALLED_WIDGETS.has(pkg.id))
    .map((pkg) => {
      const installedVersion = installed.get(pkg.id) || null;
      return {
        ...pkg,
        installed: Boolean(installedVersion),
        installedVersion,
        updateAvailable: Boolean(installedVersion && isNewerVersion(pkg.version, installedVersion)),
        guideUrl: `/widget-guides/${encodeURIComponent(pkg.id)}.html`,
        downloadUrl: `/widget-packages/${encodeURIComponent(pkg.file)}`,
        custom: false,
      };
    });

  // Sideloaded/custom widgets (installed via upload-install) are registered
  // in the live widget registry but never get a catalog entry, so without
  // this they silently never show up here even though they're installed.
  const customInstalled = installedWidgets
    .filter((widget) => !PREINSTALLED_WIDGETS.has(widget.id) && !catalogIds.has(widget.id))
    .map((widget) => ({
      id: widget.id,
      name: widget.name,
      version: widget.version,
      category: widget.category || "custom",
      file: "",
      sha256: "",
      bytes: 0,
      sourceFiles: 0,
      installed: true,
      installedVersion: widget.version,
      updateAvailable: false,
      guideUrl: "",
      downloadUrl: "",
      custom: true,
    }));

  return NextResponse.json({
    homedashVersion: index.homedashVersion,
    agent,
    packages: [...cataloged, ...customInstalled],
  });
}
