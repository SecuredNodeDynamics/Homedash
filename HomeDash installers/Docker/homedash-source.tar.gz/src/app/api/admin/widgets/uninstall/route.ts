import { NextResponse } from "next/server";
import { listWidgets } from "@/widgets/registry";
import { callWidgetAgent, type WidgetAgentJob } from "@/lib/widget-agent";
import { isTrustedOrigin } from "@/lib/security/origin";

export const runtime = "nodejs";

const PROTECTED_WIDGETS = new Set(["bookmarks", "notes", "clock", "weather"]);

export async function POST(request: Request) {
  if (!isTrustedOrigin(request)) {
    return NextResponse.json({ error: "Cross-origin uninstall request rejected" }, { status: 403 });
  }
  const body = (await request.json().catch(() => ({}))) as { ids?: unknown; confirm?: unknown };
  if (!body.confirm || !Array.isArray(body.ids) || body.ids.length < 1 || body.ids.length > 50) {
    return NextResponse.json({ error: "Choose and confirm between 1 and 50 widgets" }, { status: 400 });
  }
  const ids = body.ids.map(String);
  const installed = new Set(listWidgets().map((widget) => widget.id));
  if (
    new Set(ids).size !== ids.length ||
    ids.some((id) => !/^[a-z0-9][a-z0-9-]*$/.test(id) || PROTECTED_WIDGETS.has(id) || !installed.has(id))
  ) {
    return NextResponse.json({ error: "Selection contains an invalid, protected, or uninstalled widget" }, { status: 400 });
  }
  try {
    const job = await callWidgetAgent<WidgetAgentJob>("POST", "/uninstall", { ids });
    return NextResponse.json({ job }, { status: 202 });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Could not start widget uninstall" },
      { status: 502 },
    );
  }
}
