import { createHash, randomUUID } from "crypto";
import { promises as fs } from "fs";
import path from "path";
import { NextResponse } from "next/server";
import { requireApiSession } from "@/lib/auth/require-api-session";
import { getConfigDir } from "@/lib/config";
import {
  callWidgetAgent,
  readWidgetPackageIndex,
  type WidgetAgentJob,
} from "@/lib/widget-agent";
import { isTrustedOrigin } from "@/lib/security/origin";

export const runtime = "nodejs";

const MAX_PACKAGE_BYTES = 25 * 1024 * 1024;
const MAX_PACKAGES = 10;

export async function POST(request: Request) {
  const { error: authError } = await requireApiSession("widgets.manage");
  if (authError) return authError;

  if (!isTrustedOrigin(request)) {
    return NextResponse.json(
      { error: "Cross-origin installation request rejected" },
      { status: 403 },
    );
  }

  let form: FormData;

  try {
    form = await request.formData();
  } catch {
    return NextResponse.json({ error: "Invalid package upload" }, { status: 400 });
  }

  const files = form
    .getAll("packages")
    .filter((entry): entry is File => entry instanceof File);

  const confirmed = form.get("confirm") === "true";

  if (!confirmed || files.length < 1) {
    return NextResponse.json(
      { error: "One or more confirmed widget package uploads are required" },
      { status: 400 },
    );
  }

  if (files.length > MAX_PACKAGES) {
    return NextResponse.json(
      { error: `Choose ${MAX_PACKAGES} or fewer widget packages at a time` },
      { status: 400 },
    );
  }

  for (const file of files) {
    if (!file.name.toLowerCase().endsWith(".hdwidget")) {
      return NextResponse.json(
        { error: `${file.name} is not a .hdwidget package` },
        { status: 400 },
      );
    }

    if (file.size < 1 || file.size > MAX_PACKAGE_BYTES) {
      return NextResponse.json(
        { error: `${file.name} must be 25 MB or smaller` },
        { status: 413 },
      );
    }
  }

  const staged: string[] = [];

  try {
    const uploadDir = path.join(getConfigDir(), "agent", "uploads");

    await fs.mkdir(uploadDir, { recursive: true });

    const index = await readWidgetPackageIndex();

    const packages: {
      file: string;
      sha256: string;
      homedashVersion: string;
      originalName: string;
    }[] = [];

    for (const file of files) {
      const bytes = Buffer.from(await file.arrayBuffer());
      const sha256 = createHash("sha256").update(bytes).digest("hex");
      const stagedName = `${randomUUID()}.hdwidget`;
      const stagedPath = path.join(uploadDir, stagedName);

      await fs.writeFile(stagedPath, bytes, {
        mode: 0o600,
        flag: "wx",
      });

      staged.push(stagedPath);

      packages.push({
        file: stagedName,
        sha256,
        homedashVersion: index.homedashVersion,
        originalName: file.name,
      });
    }

    const job = await callWidgetAgent<WidgetAgentJob>(
      "POST",
      "/install-upload-batch",
      { packages },
    );

    return NextResponse.json(
      { job, fileNames: files.map((file) => file.name) },
      { status: 202 },
    );
  } catch (error) {
    await Promise.all(
      staged.map((stagedPath) =>
        fs.unlink(stagedPath).catch(() => undefined),
      ),
    );

    return NextResponse.json(
      {
        error:
          error instanceof Error
            ? error.message
            : "Could not start uploaded package installation",
      },
      { status: 502 },
    );
  }
}