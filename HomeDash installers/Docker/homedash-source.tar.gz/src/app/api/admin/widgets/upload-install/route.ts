import { createHash, randomUUID } from "crypto";
import { promises as fs } from "fs";
import path from "path";
import { NextResponse } from "next/server";
import { getConfigDir } from "@/lib/config";
import { requireApiSession } from "@/lib/auth/require-api-session";
import {
  callWidgetAgent,
  readWidgetPackageIndex,
  type WidgetAgentJob,
} from "@/lib/widget-agent";
import { isTrustedOrigin } from "@/lib/security/origin";

export const runtime = "nodejs";

const MAX_PACKAGE_BYTES = 25 * 1024 * 1024;

export async function POST(request: Request) {
  const { error: authError } = await requireApiSession("widgets.manage");
  if (authError) return authError;

  if (!isTrustedOrigin(request)) {
    return NextResponse.json(
      { error: "Cross-origin installation request rejected" },
      { status: 403 },
    );
  }

  let form: FormData;
  try {
    form = await request.formData();
  } catch {
    return NextResponse.json({ error: "Invalid package upload" }, { status: 400 });
  }

  const file = form.get("package");
  const confirmed = form.get("confirm") === "true";

  if (!(file instanceof File) || !confirmed) {
    return NextResponse.json(
      { error: "A confirmed widget package upload is required" },
      { status: 400 },
    );
  }

  if (!file.name.toLowerCase().endsWith(".hdwidget")) {
    return NextResponse.json(
      { error: "Choose a .hdwidget package" },
      { status: 400 },
    );
  }

  if (file.size < 1 || file.size > MAX_PACKAGE_BYTES) {
    return NextResponse.json(
      { error: "Widget package must be 25 MB or smaller" },
      { status: 413 },
    );
  }

  let stagedPath: string | undefined;

  try {
    const bytes = Buffer.from(await file.arrayBuffer());
    const sha256 = createHash("sha256").update(bytes).digest("hex");
    const uploadDir = path.join(getConfigDir(), "agent", "uploads");
    const stagedName = `${randomUUID()}.hdwidget`;
    stagedPath = path.join(uploadDir, stagedName);

    await fs.mkdir(uploadDir, { recursive: true });
    await fs.writeFile(stagedPath, bytes, { mode: 0o600, flag: "wx" });

    const index = await readWidgetPackageIndex();
    const job = await callWidgetAgent<WidgetAgentJob>(
      "POST",
      "/install-upload",
      {
        file: stagedName,
        sha256,
        homedashVersion: index.homedashVersion,
      },
    );

    return NextResponse.json(
      { job, fileName: file.name, sha256 },
      { status: 202 },
    );
  } catch (error) {
    if (stagedPath) {
      await fs.unlink(stagedPath).catch(() => undefined);
    }

    return NextResponse.json(
      {
        error:
          error instanceof Error
            ? error.message
            : "Could not start uploaded package installation",
      },
      { status: 502 },
    );
  }
}