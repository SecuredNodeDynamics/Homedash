import { NextResponse } from "next/server";
import { takeRateLimit, updateUserPassword, verifyPassword, findUserByUsername, readAuthConfig, writeAuthConfig, effectivePermissions, effectiveRestrictions } from "@/lib/auth";
import { buildSessionToken, isRequestSecure, readSessionFromCookies, sessionCookieOptions } from "@/lib/auth/cookies";
import { SESSION_COOKIE } from "@/lib/auth/types";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const session = await readSessionFromCookies();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "local";
  const limited = takeRateLimit(`pwchange:${session.sub}:${ip}`, 10, 60_000);
  if (!limited.ok) {
    return NextResponse.json(
      { error: "Too many attempts. Try again shortly." },
      { status: 429, headers: { "Retry-After": String(limited.retryAfterSec) } },
    );
  }

  let body: { currentPassword?: string; nextPassword?: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const currentPassword = String(body.currentPassword || "");
  const nextPassword = String(body.nextPassword || "");
  if ((!session.mustChangePassword && !currentPassword) || !nextPassword) {
    return NextResponse.json({ error: "Current and new password required" }, { status: 400 });
  }

  const user = await findUserByUsername(session.username);
  if (!user || (!session.mustChangePassword && !(await verifyPassword(currentPassword, user.passwordHash)))) {
    return NextResponse.json({ error: "Current password is incorrect" }, { status: 401 });
  }

  try {
    await updateUserPassword(user.id, nextPassword);
    const config = await readAuthConfig();
    const updated = config.users.find((item) => item.id === user.id)!;
    updated.mustChangePassword = false;
    updated.passwordResetRequestedAt = undefined;
    await writeAuthConfig(config);
    const token = await buildSessionToken({ ...updated, permissions: effectivePermissions(updated, config), ...effectiveRestrictions(updated, config), mustChangePassword: false });
    const response = NextResponse.json({ ok: true });
    response.cookies.set(SESSION_COOKIE, token, sessionCookieOptions(isRequestSecure(request)));
    return response;
  } catch (cause) {
    const message = cause instanceof Error ? cause.message : "Password change failed";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
