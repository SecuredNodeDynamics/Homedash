import { randomUUID } from "crypto";
import { NextResponse } from "next/server";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { readAuthConfig, writeAuthConfig } from "@/lib/auth";
import { readSettings, readTabLayout, writeSettings, writeTabLayout } from "@/lib/config";
import type { DashboardTab } from "@/lib/types";

function allowed(session: Awaited<ReturnType<typeof readSessionFromCookies>>) {
  return Boolean(session);
}

export async function GET() {
  const session = await readSessionFromCookies();
  if (!allowed(session)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const config = await readAuthConfig();
  const user = config.users.find((item) => item.id === session!.sub);
  return NextResponse.json({ tabs: user?.personalTabs || [] });
}

export async function POST(request: Request) {
  const session = await readSessionFromCookies();
  if (!allowed(session)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const body = await request.json().catch(() => ({})) as {
    action?: string;
    tabId?: string;
    name?: string;
  };
  if (body.action === "make-private") {
    if (session!.role !== "admin") {
      return NextResponse.json({ error: "Only an administrator can privatize a shared tab" }, { status: 403 });
    }
    const config = await readAuthConfig();
    const user = config.users.find((item) => item.id === session!.sub);
    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: "Administrator not found" }, { status: 404 });
    }
    const settings = await readSettings();
    const tab = settings.tabs.find((item) => item.id === body.tabId);
    if (!tab) return NextResponse.json({ error: "Shared tab not found" }, { status: 404 });
    if (settings.tabs.length <= 1) {
      return NextResponse.json({ error: "Keep at least one shared dashboard tab" }, { status: 400 });
    }
    if (user.personalTabs?.some((item) => item.id === tab.id)) {
      return NextResponse.json({ error: "This tab is already private" }, { status: 409 });
    }
    const layout = await readTabLayout(tab.id);
    const personalTabs = user.personalTabs || [];
    user.personalTabs = [
      ...personalTabs,
      { ...tab, order: personalTabs.length },
    ];
    user.personalLayouts = {
      ...(user.personalLayouts || {}),
      [tab.id]: layout,
    };
    user.personalTabOrder = user.personalTabOrder?.length
      ? user.personalTabOrder.includes(tab.id)
        ? user.personalTabOrder
        : [...user.personalTabOrder, tab.id]
      : settings.tabs.map((item) => item.id);
    await writeAuthConfig(config);
    await writeSettings({
      ...settings,
      tabs: settings.tabs
        .filter((item) => item.id !== tab.id)
        .map((item, order) => ({ ...item, order })),
    });
    return NextResponse.json({ ok: true, tab });
  }
  if (body.action === "make-shared") {
    if (session!.role !== "admin") {
      return NextResponse.json({ error: "Only an administrator can share a private tab" }, { status: 403 });
    }
    const config = await readAuthConfig();
    const user = config.users.find((item) => item.id === session!.sub);
    const tab = user?.personalTabs?.find((item) => item.id === body.tabId);
    if (!user || !tab) {
      return NextResponse.json({ error: "Private tab not found" }, { status: 404 });
    }
    const settings = await readSettings();
    if (settings.tabs.some((item) => item.id === tab.id)) {
      return NextResponse.json({ error: "A shared tab already uses this ID" }, { status: 409 });
    }
    const layout = user.personalLayouts?.[tab.id];
    const sharedTab = { ...tab, order: settings.tabs.length };
    await writeSettings({ ...settings, tabs: [...settings.tabs, sharedTab] });
    if (layout) await writeTabLayout(tab.id, layout);
    user.personalTabs = (user.personalTabs || [])
      .filter((item) => item.id !== tab.id)
      .map((item, order) => ({ ...item, order }));
    if (user.personalLayouts) delete user.personalLayouts[tab.id];
    await writeAuthConfig(config);
    return NextResponse.json({ ok: true, tab: sharedTab });
  }
  const name = String(body.name || "").trim().slice(0, 64);
  if (name.length < 2) return NextResponse.json({ error: "Name must be at least 2 characters" }, { status: 400 });
  const config = await readAuthConfig();
  const user = config.users.find((item) => item.id === session!.sub);
  if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });
  const tabs = user.personalTabs || [];
  const tab = { id: `personal-${session!.sub.slice(0, 8)}-${randomUUID().slice(0, 8)}`, name, order: tabs.length, widgetIds: [] };
  user.personalTabs = [...tabs, tab];
  user.personalTabOrder = [...(user.personalTabOrder || []), tab.id];
  user.personalLayouts = { ...(user.personalLayouts || {}), [tab.id]: { lg: [], md: [], sm: [] } };
  await writeAuthConfig(config);
  return NextResponse.json({ ok: true, tab });
}

export async function PATCH(request: Request) {
  const session = await readSessionFromCookies();
  if (!allowed(session)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const body = await request.json().catch(() => ({})) as Partial<DashboardTab> & {
    orderIds?: string[];
  };
  const config = await readAuthConfig();
  const user = config.users.find((item) => item.id === session!.sub);
  if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });
  if (Array.isArray(body.orderIds)) {
    const settings = await readSettings();
    const allowedIds = new Set([
      ...settings.tabs.map((item) => item.id),
      ...(user.personalTabs || []).map((item) => item.id),
    ]);
    user.personalTabOrder = [
      ...new Set(body.orderIds.map(String).filter((id) => allowedIds.has(id))),
      ...Array.from(allowedIds).filter((id) => !body.orderIds!.includes(id)),
    ];
    await writeAuthConfig(config);
    return NextResponse.json({ ok: true, orderIds: user.personalTabOrder });
  }
  const name = String(body.name || "").trim().slice(0, 64);
  const tab = user?.personalTabs?.find((item) => item.id === body.id);
  if (!tab) return NextResponse.json({ error: "Dashboard not found" }, { status: 404 });
  if (name.length >= 2) tab.name = name;
  if (Array.isArray(body.widgetIds)) {
    tab.widgetIds = [...new Set(body.widgetIds.map(String).filter(Boolean))].slice(0, 250);
  }
  if (body.deviceVisibility && typeof body.deviceVisibility === "object") {
    tab.deviceVisibility = Object.fromEntries(
      Object.entries(body.deviceVisibility)
        .filter(([, visible]) => visible === false),
    );
  } else {
    delete tab.deviceVisibility;
  }
  if (Number.isFinite(Number(body.order))) tab.order = Math.max(0, Number(body.order));
  user!.personalTabs = [...(user!.personalTabs || [])]
    .sort((a, b) => a.order - b.order)
    .map((item, order) => ({ ...item, order }));
  await writeAuthConfig(config);
  return NextResponse.json({ ok: true, tab });
}

export async function DELETE(request: Request) {
  const session = await readSessionFromCookies();
  if (!allowed(session)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const body = await request.json().catch(() => ({})) as { id?: string };
  const config = await readAuthConfig();
  const user = config.users.find((item) => item.id === session!.sub);
  if (!user?.personalTabs?.some((item) => item.id === body.id)) return NextResponse.json({ error: "Dashboard not found" }, { status: 404 });
  user.personalTabs = user.personalTabs.filter((item) => item.id !== body.id).map((item, order) => ({ ...item, order }));
  user.personalTabOrder = (user.personalTabOrder || []).filter((id) => id !== body.id);
  if (user.personalLayouts) delete user.personalLayouts[String(body.id)];
  await writeAuthConfig(config);
  return NextResponse.json({ ok: true });
}
