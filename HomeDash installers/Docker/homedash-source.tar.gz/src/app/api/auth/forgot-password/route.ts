import { NextResponse } from "next/server";
import { readAuthConfig, takeRateLimit, writeAuthConfig } from "@/lib/auth";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "local";
  const limited = takeRateLimit(`forgot:${ip}`, 8, 60_000);
  if (!limited.ok) return NextResponse.json({ error: "Too many requests. Try again shortly." }, { status: 429 });
  const body = await request.json().catch(() => ({})) as { username?: string };
  const username = String(body.username || "").trim().toLowerCase();
  if (username) {
    const config = await readAuthConfig();
    const user = config.users.find((item) => item.username.toLowerCase() === username && !item.disabled);
    if (user) {
      user.passwordResetRequestedAt = new Date().toISOString();
      await writeAuthConfig(config);
    }
  }
  return NextResponse.json({ ok: true, message: "If that account exists, the administrator will see the reset request." });
}
