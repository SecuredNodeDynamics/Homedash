import { NextResponse } from "next/server";
import {
  findUserByUsername,
  hasUsers,
  maybeBootstrapAdminFromEnv,
  takeRateLimit,
  verifyPassword,
  readAuthConfig,
  effectivePermissions,
  effectiveRestrictions,
} from "@/lib/auth";
import { buildSessionToken, isRequestSecure, sessionCookieOptions } from "@/lib/auth/cookies";
import { SESSION_COOKIE } from "@/lib/auth/types";

export const runtime = "nodejs";

export async function POST(request: Request) {
  await maybeBootstrapAdminFromEnv();

  const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "local";
  const limited = takeRateLimit(`login:${ip}`, 20, 60_000);
  if (!limited.ok) {
    return NextResponse.json(
      { error: "Too many attempts. Try again shortly." },
      { status: 429, headers: { "Retry-After": String(limited.retryAfterSec) } },
    );
  }

  if (!(await hasUsers())) {
    return NextResponse.json({ error: "Setup required", setup: true }, { status: 409 });
  }

  let body: { username?: string; password?: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const username = String(body.username || "").trim();
  const password = String(body.password || "");
  if (!username || !password) {
    return NextResponse.json({ error: "Username and password required" }, { status: 400 });
  }

  const user = await findUserByUsername(username);
  if (!user || !(await verifyPassword(password, user.passwordHash))) {
    return NextResponse.json({ error: "Invalid username or password" }, { status: 401 });
  }
  if (user.disabled) return NextResponse.json({ error: "Account disabled" }, { status: 403 });

  const authConfig = await readAuthConfig();
  const permissions = effectivePermissions(user, authConfig);
  const restrictions = effectiveRestrictions(user, authConfig);
  const token = await buildSessionToken({ ...user, permissions, ...restrictions, mustChangePassword: user.mustChangePassword });
  const res = NextResponse.json({
    ok: true,
    user: { id: user.id, username: user.username, role: user.role },
    mustChangePassword: Boolean(user.mustChangePassword),
  });
  res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions(isRequestSecure(request)));
  return res;
}
