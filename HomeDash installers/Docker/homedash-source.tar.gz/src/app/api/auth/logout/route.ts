import { NextResponse } from "next/server";
import { SESSION_COOKIE } from "@/lib/auth/types";
import { isRequestSecure } from "@/lib/auth/cookies";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const res = NextResponse.json({ ok: true });
  res.cookies.set(SESSION_COOKIE, "", {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    secure: isRequestSecure(request),
    maxAge: 0,
  });
  return res;
}
