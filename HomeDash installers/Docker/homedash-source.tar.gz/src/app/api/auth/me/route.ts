import { NextResponse } from "next/server";
import { maybeBootstrapAdminFromEnv, hasUsers, readAuthConfig } from "@/lib/auth";
import { readSessionFromCookies } from "@/lib/auth/cookies";

export const runtime = "nodejs";

export async function GET() {
  await maybeBootstrapAdminFromEnv();
  const session = await readSessionFromCookies();
  if (!session) {
    return NextResponse.json(
      { authenticated: false, setupRequired: !(await hasUsers()) },
      { status: 401 },
    );
  }
  const config = await readAuthConfig();
  const user = config.users.find((item) => item.id === session.sub);
  return NextResponse.json({
    authenticated: true,
    user: {
      id: session.sub,
      username: user?.username || session.username,
      displayName: user?.displayName || "",
      profileImageUrl: user?.profileImageUrl || "",
      role: session.role,
      permissions: session.permissions,
      restrictedTabIds: session.restrictedTabIds || [],
      restrictedWidgetIds: session.restrictedWidgetIds || [],
      restrictedLayoutTabIds: session.restrictedLayoutTabIds || [],
      personalTabIds: (user?.personalTabs || []).map((tab) => tab.id),
    },
  });
}
