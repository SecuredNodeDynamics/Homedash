import { NextResponse } from "next/server";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { readAuthConfig, writeAuthConfig } from "@/lib/auth";
import type { ProfileBackground } from "@/lib/auth/types";
import type { BookmarkGroup, BookmarkItem, ThemeSettings } from "@/lib/types";
import { normalizeBookmarkGroups, normalizeBookmarks } from "@/lib/bookmarks";
import { normalizeThemeBackground } from "@/lib/theme";

export const runtime = "nodejs";

function cleanBackground(value: unknown): ProfileBackground {
  const input = value && typeof value === "object" ? value as Record<string, unknown> : {};
  return {
    enabled: input.enabled === true,
    background: String(input.background || "").trim().slice(0, 80) || undefined,
    backgroundImageUrl: String(input.backgroundImageUrl || "").trim().slice(0, 2048) || undefined,
    backgroundImageOpacity: Math.max(0, Math.min(1, Number(input.backgroundImageOpacity) || 0)),
    backgroundImageBlur: Math.max(0, Math.min(24, Number(input.backgroundImageBlur) || 0)),
  };
}

export async function GET() {
  const session = await readSessionFromCookies();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const config = await readAuthConfig();
  const user = config.users.find((item) => item.id === session.sub);
  if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });
  const isolatedBookmarks = user.role === "admin" || user.personalBookmarksIsolated === true;
  return NextResponse.json({
    background: user.profileBackground || { enabled: false },
    theme: user.profileTheme || {},
    bookmarks: isolatedBookmarks ? user.personalBookmarks || [] : [],
    bookmarkGroups: isolatedBookmarks ? user.personalBookmarkGroups || [] : [],
  });
}

export async function PUT(request: Request) {
  const session = await readSessionFromCookies();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = await request.json().catch(() => ({})) as {
    background?: unknown;
    theme?: Partial<ThemeSettings>;
    bookmarks?: BookmarkItem[];
    bookmarkGroups?: BookmarkGroup[];
  };
  const config = await readAuthConfig();
  const user = config.users.find((item) => item.id === session.sub);
  if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });
  if (body.background !== undefined) user.profileBackground = cleanBackground(body.background);
  if (body.theme && typeof body.theme === "object") {
    user.profileTheme = normalizeThemeBackground(body.theme as ThemeSettings);
  }
  if (Array.isArray(body.bookmarks) || Array.isArray(body.bookmarkGroups)) {
    const mayUseStoredBookmarks = user.role === "admin" || user.personalBookmarksIsolated === true;
    const groups = normalizeBookmarkGroups(
      body.bookmarkGroups || (mayUseStoredBookmarks ? user.personalBookmarkGroups : []),
    );
    user.personalBookmarkGroups = groups;
    user.personalBookmarks = normalizeBookmarks(
      body.bookmarks || (mayUseStoredBookmarks ? user.personalBookmarks : []),
      groups,
    );
    user.personalBookmarksIsolated = true;
  }
  await writeAuthConfig(config);
  return NextResponse.json({
    ok: true,
    background: user.profileBackground,
    theme: user.profileTheme || {},
    bookmarks: user.personalBookmarks || [],
    bookmarkGroups: user.personalBookmarkGroups || [],
  });
}
