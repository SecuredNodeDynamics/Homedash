import { NextResponse } from "next/server";
import {
  effectivePermissions,
  effectiveRestrictions,
  readAuthConfig,
  writeAuthConfig,
} from "@/lib/auth";
import {
  buildSessionToken,
  isRequestSecure,
  readSessionFromCookies,
  sessionCookieOptions,
} from "@/lib/auth/cookies";
import { SESSION_COOKIE } from "@/lib/auth/types";

export const runtime = "nodejs";

export async function GET() {
  const session = await readSessionFromCookies();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const config = await readAuthConfig();
  const user = config.users.find((item) => item.id === session.sub);
  if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });
  return NextResponse.json({
    username: user.username,
    displayName: user.displayName || "",
    profileImageUrl: user.profileImageUrl || "",
  });
}

export async function PUT(request: Request) {
  const session = await readSessionFromCookies();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = await request.json().catch(() => ({})) as {
    username?: string;
    displayName?: string;
    profileImageUrl?: string;
  };
  const username = String(body.username || "").trim();
  const displayName = String(body.displayName || "").trim().slice(0, 80);
  const profileImageUrl = String(body.profileImageUrl || "").trim().slice(0, 2048);
  if (username.length < 2 || username.length > 64) {
    return NextResponse.json({ error: "Username must be 2–64 characters" }, { status: 400 });
  }
  if (!/^[a-zA-Z0-9._-]+$/.test(username)) {
    return NextResponse.json(
      { error: "Username may only contain letters, numbers, . _ -" },
      { status: 400 },
    );
  }

  const config = await readAuthConfig();
  const user = config.users.find((item) => item.id === session.sub);
  if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });
  const duplicate = config.users.some(
    (item) => item.id !== user.id && item.username.toLowerCase() === username.toLowerCase(),
  );
  if (duplicate) return NextResponse.json({ error: "That username is already in use" }, { status: 409 });

  user.username = username;
  user.displayName = displayName || undefined;
  user.profileImageUrl = profileImageUrl || undefined;
  await writeAuthConfig(config);

  const token = await buildSessionToken({
    ...user,
    permissions: effectivePermissions(user, config),
    ...effectiveRestrictions(user, config),
  });
  const response = NextResponse.json({
    ok: true,
    username: user.username,
    displayName: user.displayName || "",
    profileImageUrl: user.profileImageUrl || "",
  });
  response.cookies.set(SESSION_COOKIE, token, sessionCookieOptions(isRequestSecure(request)));
  return response;
}
