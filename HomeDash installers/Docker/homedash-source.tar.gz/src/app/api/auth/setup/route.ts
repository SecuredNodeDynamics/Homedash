import { NextResponse } from "next/server";
import {
  createAdminUser,
  hasUsers,
  maybeBootstrapAdminFromEnv,
  takeRateLimit,
} from "@/lib/auth";
import { buildSessionToken, isRequestSecure, sessionCookieOptions } from "@/lib/auth/cookies";
import { SESSION_COOKIE } from "@/lib/auth/types";

export const runtime = "nodejs";

export async function POST(request: Request) {
  await maybeBootstrapAdminFromEnv();

  const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "local";
  const limited = takeRateLimit(`setup:${ip}`, 5, 60_000);
  if (!limited.ok) {
    return NextResponse.json(
      { error: "Too many attempts. Try again shortly." },
      { status: 429, headers: { "Retry-After": String(limited.retryAfterSec) } },
    );
  }

  if (await hasUsers()) {
    return NextResponse.json({ error: "Setup already completed" }, { status: 409 });
  }

  let body: { username?: string; password?: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const username = String(body.username || "").trim();
  const password = String(body.password || "");
  try {
    const user = await createAdminUser(username, password);
    const token = await buildSessionToken(user);
    const res = NextResponse.json({
      ok: true,
      user: { id: user.id, username: user.username, role: user.role },
    });
    res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions(isRequestSecure(request)));
    return res;
  } catch (cause) {
    const message = cause instanceof Error ? cause.message : "Setup failed";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
