import { promises as fs } from "fs";
import path from "path";
import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const REPORT_NAME = /^homedash-compliance-\d{8}T\d{6}Z\.md$/;
const MAX_REPORT_BYTES = 2 * 1024 * 1024;

export async function GET() {
  const reportDir =
    process.env.COMPLIANCE_REPORT_DIR ||
    path.join(process.cwd(), "compliance-reports");

  try {
    const names = (await fs.readdir(reportDir))
      .filter((name) => REPORT_NAME.test(name))
      .sort()
      .reverse();
    const filename = names[0];
    if (!filename) {
      return NextResponse.json(
        { error: "No compliance report has been generated yet." },
        { status: 404, headers: { "Cache-Control": "private, no-store" } },
      );
    }

    const reportPath = path.join(reportDir, filename);
    const stats = await fs.stat(reportPath);
    if (!stats.isFile() || stats.size > MAX_REPORT_BYTES) {
      return NextResponse.json(
        { error: "The latest compliance report is invalid or too large." },
        { status: 422, headers: { "Cache-Control": "private, no-store" } },
      );
    }

    const markdown = await fs.readFile(reportPath, "utf8");
    const aiPromptPath = reportPath.replace(/\.md$/, "-ai-prompt.txt");
    const aiPrompt = await fs.readFile(aiPromptPath, "utf8").catch(() => [
      "You are acting as a senior SaaS security and SOC 2 readiness advisor.",
      "Explain the findings clearly, prioritize remediation, separate technical fixes from manual policy evidence, and do not represent this automated report as certification.",
      "",
      "----- BEGIN HOMEDASH COMPLIANCE REPORT -----",
      markdown,
      "----- END HOMEDASH COMPLIANCE REPORT -----",
    ].join("\n"));
    return NextResponse.json(
      {
        filename,
        modifiedAt: stats.mtime.toISOString(),
        size: stats.size,
        markdown,
        aiPrompt,
      },
      { headers: { "Cache-Control": "private, no-store, max-age=0" } },
    );
  } catch (error) {
    const missing =
      typeof error === "object" &&
      error !== null &&
      "code" in error &&
      (error as { code?: string }).code === "ENOENT";
    return NextResponse.json(
      {
        error: missing
          ? "No compliance report has been generated yet."
          : "The compliance report could not be read.",
      },
      {
        status: missing ? 404 : 500,
        headers: { "Cache-Control": "private, no-store" },
      },
    );
  }
}
