import { NextResponse } from "next/server";
import packageJson from "../../../../../package.json";

export const runtime = "nodejs";

export async function GET() {
  return NextResponse.json({
    service: "homedash",
    controllerApi: 1,
    version: packageJson.version,
  });
}
