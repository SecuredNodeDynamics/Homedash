import { NextResponse } from "next/server";
import { searchLocalIcons } from "@/lib/icons-library";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const q = (searchParams.get("q") || "").trim().toLowerCase();
    const limit = Math.min(Number(searchParams.get("limit") || 240) || 240, 500);
    const { icons, matched, total } = await searchLocalIcons(q, limit);

    return NextResponse.json(
      {
        source: "local",
        total,
        matched,
        truncated: icons.length < matched,
        icons: icons.map((icon) => ({
          name: icon.name,
          url: icon.url,
          page: icon.url,
          filename: icon.filename,
        })),
      },
      {
        headers: {
          "Cache-Control": "no-store",
        },
      },
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : "Icon search failed";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
