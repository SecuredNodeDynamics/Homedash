import { NextResponse } from "next/server";
import { readTabLayout, writeTabLayout } from "@/lib/config";
import type { LayoutConfig } from "@/lib/types";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { parseInstanceId } from "@/lib/instances";
import { readAuthConfig, writeAuthConfig } from "@/lib/auth";
import { personalTabOwner } from "@/lib/auth/personal-dashboards";
import { resolveVerticalOverlaps } from "@/lib/auto-layout";

export async function GET(request: Request) {
  const tabId = new URL(request.url).searchParams.get("tab");
  if (!tabId) {
    return NextResponse.json({ error: "Missing tab id" }, { status: 400 });
  }
  const session = await readSessionFromCookies();
  const config = session ? await readAuthConfig() : null;
  const user = config?.users.find((item) => item.id === session?.sub);
  const owner = personalTabOwner(tabId, user, config?.users);
  if (owner) {
    return NextResponse.json(owner.personalLayouts?.[tabId] || { lg: [], md: [], sm: [] });
  }
  if (session?.role !== "admin" && session?.restrictedTabIds?.includes(tabId)) {
    return NextResponse.json({ error: "Tab access restricted" }, { status: 403 });
  }
  const restrictedWidgets = new Set(session?.role === "admin" ? [] : (session?.restrictedWidgetIds || []));
  const stored = await readTabLayout(tabId);
  const filterItems = <T extends { i: string }>(items: T[] | undefined) =>
    items?.filter((item) => !restrictedWidgets.has(parseInstanceId(item.i).widgetId));
  const layout: LayoutConfig = {
    ...stored,
    xxl: filterItems(stored.xxl),
    xl: filterItems(stored.xl),
    lg: filterItems(stored.lg) || [],
    md: filterItems(stored.md) || [],
    sm: filterItems(stored.sm) || [],
    mdLandscape: filterItems(stored.mdLandscape),
    smLandscape: filterItems(stored.smLandscape),
  };
  return NextResponse.json(layout);
}

export async function PUT(request: Request) {
  const body = (await request.json()) as { tabId?: string; layout?: LayoutConfig };
  if (!body.tabId || !body.layout?.lg || !body.layout?.md || !body.layout?.sm) {
    return NextResponse.json({ error: "Invalid layout payload" }, { status: 400 });
  }
  const session = await readSessionFromCookies();
  const config = session ? await readAuthConfig() : null;
  const user = config?.users.find((item) => item.id === session?.sub);
  const owner = personalTabOwner(body.tabId, user, config?.users);
  const personal = Boolean(owner);
  const canManageLayout = session && (
    session.role === "admin" ||
    session.permissions?.includes("*") ||
    session.permissions?.includes("layout.manage") ||
    personal
  );
  if (!canManageLayout) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  if (session.role !== "admin" && session.restrictedLayoutTabIds?.includes(body.tabId)) {
    return NextResponse.json({ error: "Layout editing is restricted for this tab" }, { status: 403 });
  }
  // Normalize all breakpoints / orientation slots so presets persist even when empty arrays.
  const lockedRaw = body.layout.locked;
  const locked: LayoutConfig["locked"] = {};
  if (lockedRaw && typeof lockedRaw === "object") {
    for (const bp of ["xxl", "xl", "lg", "md", "sm", "mdLandscape", "smLandscape"] as const) {
      if (lockedRaw[bp]) locked[bp] = true;
    }
  }
  const layout: LayoutConfig = {
    xxl: resolveVerticalOverlaps(Array.isArray(body.layout.xxl) ? body.layout.xxl : []),
    xl: resolveVerticalOverlaps(Array.isArray(body.layout.xl) ? body.layout.xl : []),
    lg: resolveVerticalOverlaps(body.layout.lg),
    md: resolveVerticalOverlaps(body.layout.md),
    sm: resolveVerticalOverlaps(body.layout.sm),
    ...(Array.isArray(body.layout.mdLandscape) && body.layout.mdLandscape.length
      ? { mdLandscape: resolveVerticalOverlaps(body.layout.mdLandscape) }
      : {}),
    ...(Array.isArray(body.layout.smLandscape) && body.layout.smLandscape.length
      ? { smLandscape: resolveVerticalOverlaps(body.layout.smLandscape) }
      : {}),
    ...(Object.keys(locked).length ? { locked } : {}),
    // Pass through so writeTabLayout's normalize pass can tell a real grid-cols
    // change from a plain re-save (see migrateLayoutToCurrentCols).
    ...(body.layout.savedCols ? { savedCols: body.layout.savedCols } : {}),
  };
  if (personal && owner && config) {
    owner.personalLayouts = { ...(owner.personalLayouts || {}), [body.tabId]: layout };
    await writeAuthConfig(config);
  } else {
    await writeTabLayout(body.tabId, layout);
  }
  return NextResponse.json({ ok: true });
}
