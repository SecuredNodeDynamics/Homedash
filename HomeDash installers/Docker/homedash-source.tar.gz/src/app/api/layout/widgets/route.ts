import { NextResponse } from "next/server";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { readSettings, writeSettings } from "@/lib/config";
import { createServerInstance, removeCardFromTabWidgetIds, withUpdatedTab } from "@/lib/edit-layout";
import { parseInstanceId } from "@/lib/instances";
import { getWidget } from "@/widgets/registry";
import { readAuthConfig, writeAuthConfig } from "@/lib/auth";
import { personalTabOwner } from "@/lib/auth/personal-dashboards";

export const runtime = "nodejs";

async function authorize(tabId: string) {
  const session = await readSessionFromCookies();
  const config = session ? await readAuthConfig() : null;
  const user = config?.users.find((item) => item.id === session?.sub);
  const owner = personalTabOwner(tabId, user, config?.users);
  const personal = Boolean(owner);
  const allowed = session && (
    session.role === "admin" ||
    session.permissions?.includes("*") ||
    session.permissions?.includes("layout.manage") ||
    personal
  );
  if (!allowed) return null;
  if (!personal && session.role !== "admin" && session.restrictedLayoutTabIds?.includes(tabId)) return null;
  return { session, config, user: owner || user, personal };
}

async function updateWidgets(request: Request) {
  const body = await request.json().catch(() => ({})) as {
    action?: string;
    tabId?: string;
    widgetId?: string;
    instanceId?: string;
    another?: boolean;
  };
  const tabId = String(body.tabId || "");
  const auth = await authorize(tabId);
  if (!auth) return NextResponse.json({ error: "Layout editing is not allowed for this tab" }, { status: 403 });
  const { session } = auth;

  const settings = await readSettings();
  const tab = auth.personal
    ? auth.user?.personalTabs?.find((item) => item.id === tabId)
    : settings.tabs.find((item) => item.id === tabId);
  if (!tab) return NextResponse.json({ error: "Tab not found" }, { status: 404 });

  if (body.action === "remove") {
    const instanceId = String(body.instanceId || "");
    if (!instanceId) return NextResponse.json({ error: "Missing widget card" }, { status: 400 });
    const nextTab = {
      ...tab,
      widgetIds: removeCardFromTabWidgetIds(tab.widgetIds, instanceId, settings.widgetInstances || []),
    };
    if (auth.personal && auth.user && auth.config) {
      auth.user.personalTabs = (auth.user.personalTabs || []).map((item) => item.id === nextTab.id ? nextTab : item);
      await writeAuthConfig(auth.config);
    } else {
      await writeSettings(withUpdatedTab(settings, nextTab));
    }
    return NextResponse.json({ ok: true, tab: nextTab });
  }

  const widgetId = String(body.widgetId || "");
  const manifest = getWidget(widgetId)?.manifest;
  if (!manifest) return NextResponse.json({ error: "Widget is not installed" }, { status: 400 });
  if (session.role !== "admin" && session.restrictedWidgetIds?.includes(widgetId)) {
    return NextResponse.json({ error: "Widget access restricted" }, { status: 403 });
  }

  let nextSettings = settings;
  let nextTab = tab;
  let instanceId = widgetId;
  let label = manifest.name;

  const requestedInstanceId = String(body.instanceId || "");
  if (requestedInstanceId) {
    const requestedInstance = (nextSettings.widgetInstances || []).find(
      (instance) => instance.id === requestedInstanceId && instance.widgetId === widgetId,
    );
    if (!requestedInstance) {
      return NextResponse.json({ error: "Widget server was not found" }, { status: 404 });
    }
    instanceId = requestedInstance.id;
    label = requestedInstance.label || manifest.name;
    nextSettings = {
      ...nextSettings,
      enabledWidgets: nextSettings.enabledWidgets.includes(widgetId)
        ? nextSettings.enabledWidgets
        : [...nextSettings.enabledWidgets, widgetId],
    };
    if (!nextTab.widgetIds.includes(instanceId)) {
      nextTab = { ...nextTab, widgetIds: [...nextTab.widgetIds, instanceId] };
    }
  } else if (body.another) {
    const created = createServerInstance(nextSettings, widgetId, manifest.name);
    nextSettings = created.settings;
    instanceId = created.instance.id;
    label = created.instance.label;
    const existing = (nextSettings.widgetInstances || []).filter(
      (instance) => instance.widgetId === widgetId && instance.id !== instanceId,
    );
    nextTab = tab.widgetIds.includes(widgetId)
      ? {
          ...tab,
          widgetIds: [
            ...tab.widgetIds.filter((id) => id !== widgetId),
            ...(existing.length ? existing.map((instance) => instance.id) : [widgetId]),
            instanceId,
          ],
        }
      : { ...tab, widgetIds: [...tab.widgetIds, instanceId] };
  } else {
    nextSettings = {
      ...nextSettings,
      enabledWidgets: nextSettings.enabledWidgets.includes(widgetId)
        ? nextSettings.enabledWidgets
        : [...nextSettings.enabledWidgets, widgetId],
    };
    if (!nextTab.widgetIds.some((id) => parseInstanceId(id).widgetId === widgetId)) {
      nextTab = { ...nextTab, widgetIds: [...nextTab.widgetIds, widgetId] };
    }
  }

  const payload = withUpdatedTab(nextSettings, nextTab);
  if (auth.personal && auth.user && auth.config) {
    auth.user.personalTabs = (auth.user.personalTabs || []).map((item) => item.id === nextTab.id ? nextTab : item);
    await writeAuthConfig(auth.config);
  } else {
    await writeSettings(payload);
  }
  return NextResponse.json({
    ok: true,
    tab: nextTab,
    instanceId,
    label,
    enabledWidgets: payload.enabledWidgets,
    widgetInstances: payload.widgetInstances,
  });
}

export async function POST(request: Request) {
  try {
    return await updateWidgets(request);
  } catch (error) {
    const detail = error instanceof Error ? error.message : String(error);
    console.error("Widget layout update failed:", error);
    return NextResponse.json(
      {
        error: detail
          ? `Could not save the widget: ${detail}`
          : "Could not save the widget layout",
      },
      { status: 500 },
    );
  }
}
