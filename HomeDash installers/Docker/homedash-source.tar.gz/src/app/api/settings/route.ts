import { NextResponse } from "next/server";
import { requireApiSession } from "@/lib/auth/require-api-session";
import { filterSettingsForSession } from "@/lib/auth/resource-access";
import { readSettings, writeSettings } from "@/lib/config";
import { isTrustedOrigin } from "@/lib/security/origin";
import type { AppSettings } from "@/lib/types";

export async function GET() {
  const { session, error } = await requireApiSession("settings.view");

  if (error) {
    return error;
  }

  const settings = filterSettingsForSession(
    await readSettings(),
    session,
  );

  return NextResponse.json(settings);
}

export async function PUT(request: Request) {
  const { error } = await requireApiSession("settings.manage");

  if (error) {
    return error;
  }

  if (!isTrustedOrigin(request)) {
    return NextResponse.json(
      { error: "Cross-origin settings request rejected" },
      { status: 403 },
    );
  }

  let body: AppSettings;

  try {
    body = (await request.json()) as AppSettings;
  } catch {
    return NextResponse.json(
      { error: "Invalid settings payload" },
      { status: 400 },
    );
  }

  if (
    !body?.appName ||
    !body?.theme ||
    !Array.isArray(body.enabledWidgets)
  ) {
    return NextResponse.json(
      { error: "Invalid settings payload" },
      { status: 400 },
    );
  }

  if (body.tabs && !Array.isArray(body.tabs)) {
    return NextResponse.json(
      { error: "Invalid tabs payload" },
      { status: 400 },
    );
  }

  await writeSettings(body);

  return NextResponse.json({ ok: true });
}