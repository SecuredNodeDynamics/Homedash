import { NextResponse } from "next/server";
import { requireApiSession } from "@/lib/auth/require-api-session";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { isTrustedOrigin } from "@/lib/security/origin";
import {
  deleteUploadByUrl,
  MAX_UPLOAD_BYTES,
  saveUpload,
  type UploadKind,
} from "@/lib/uploads";

export const runtime = "nodejs";

const KINDS = new Set<UploadKind>([
  "logo",
  "favicon",
  "background",
  "widget-icon",
  "profile-image",
]);

async function requireUploadPermission(kind: UploadKind) {
  if (kind === "profile-image") {
    const session = await readSessionFromCookies();

    if (!session) {
      return {
        session: null,
        error: NextResponse.json(
          { error: "Unauthorized" },
          { status: 401 },
        ),
      };
    }

    if (session.mustChangePassword) {
      return {
        session: null,
        error: NextResponse.json(
          { error: "Password change required" },
          { status: 403 },
        ),
      };
    }

    return { session, error: null };
  }

  return requireApiSession("settings.manage");
}

export async function POST(request: Request) {
  if (!isTrustedOrigin(request)) {
    return NextResponse.json(
      { error: "Cross-origin upload request rejected" },
      { status: 403 },
    );
  }

  let form: FormData;

  try {
    form = await request.formData();
  } catch {
    return NextResponse.json(
      { error: "Invalid upload request" },
      { status: 400 },
    );
  }

  const kindRaw = String(form.get("kind") || "");

  if (!KINDS.has(kindRaw as UploadKind)) {
    return NextResponse.json(
      { error: "Invalid upload kind" },
      { status: 400 },
    );
  }

  const kind = kindRaw as UploadKind;
  const { session, error: authError } = await requireUploadPermission(kind);

  if (authError) {
    return authError;
  }

  let key = String(form.get("key") || "");
  const gallery = String(form.get("gallery") || "") === "1";
  const file = form.get("file");

  if (!(file instanceof File)) {
    return NextResponse.json(
      { error: "Missing file" },
      { status: 400 },
    );
  }

  if (kind === "profile-image") {
    key = session!.sub;
  }

  if (file.size <= 0) {
    return NextResponse.json(
      { error: "Empty file" },
      { status: 400 },
    );
  }

  if (file.size > MAX_UPLOAD_BYTES) {
    return NextResponse.json(
      { error: "File exceeds the 25 MB limit" },
      { status: 413 },
    );
  }

  try {
    const saved = await saveUpload(kind, file, { key, gallery });
    return NextResponse.json(saved);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Upload failed";

    const status = message.includes("25 MB")
      ? 413
      : message.includes("not writable")
        ? 500
        : 400;

    return NextResponse.json({ error: message }, { status });
  }
}

export async function DELETE(request: Request) {
  if (!isTrustedOrigin(request)) {
    return NextResponse.json(
      { error: "Cross-origin upload deletion rejected" },
      { status: 403 },
    );
  }

  const session = await readSessionFromCookies();

  if (!session) {
    return NextResponse.json(
      { error: "Unauthorized" },
      { status: 401 },
    );
  }

  if (session.mustChangePassword) {
    return NextResponse.json(
      { error: "Password change required" },
      { status: 403 },
    );
  }

  try {
    const url = new URL(request.url).searchParams.get("url") || "";

    if (!url) {
      return NextResponse.json(
        { error: "Missing url" },
        { status: 400 },
      );
    }

    const ok = await deleteUploadByUrl(url);

    if (!ok) {
      return NextResponse.json(
        { error: "Invalid upload url" },
        { status: 400 },
      );
    }

    return NextResponse.json({ ok: true });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Delete failed";

    return NextResponse.json(
      { error: message },
      { status: 400 },
    );
  }
}