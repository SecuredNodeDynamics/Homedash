import { NextResponse } from "next/server";
import {
  readSettings,
  readWidgetConfig,
  resolveBookmarksWidgetTitle,
  writeSettings,
  writeWidgetConfig,
} from "@/lib/config";
import { parseInstanceId } from "@/lib/instances";
import { applyNodeTitleToInstance, isNodeTitleWidget } from "@/lib/widget-titles";
import { readSessionFromCookies } from "@/lib/auth/cookies";

type Ctx = { params: Promise<{ id: string }> };

async function authorize() {
  const session = await readSessionFromCookies();
  return session && (session.role === "admin" || session.permissions?.includes("*") || session.permissions?.includes("widgets.manage"));
}

export async function GET(_req: Request, ctx: Ctx) {
  if (!(await authorize())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id } = await ctx.params;
  const config = await readWidgetConfig(id);
  return NextResponse.json(config);
}

export async function PUT(req: Request, ctx: Ctx) {
  if (!(await authorize())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id } = await ctx.params;
  const body = (await req.json()) as Record<string, string>;
  if (!body || typeof body !== "object") {
    return NextResponse.json({ error: "Invalid config" }, { status: 400 });
  }
  await writeWidgetConfig(id, body);

  const widgetId = parseInstanceId(id).widgetId;
  if (widgetId === "bookmarks" || isNodeTitleWidget(widgetId)) {
    const settings = await readSettings();
    const previous = settings.widgetInstances || [];
    const widgetInstances = previous.map((inst) => {
      if (inst.id !== id) return inst;
      if (widgetId === "bookmarks") {
        const label = resolveBookmarksWidgetTitle(body.groupId, settings.bookmarkGroups);
        return { ...inst, label };
      }
      return applyNodeTitleToInstance({ ...inst, widgetId }, body);
    });
    const changed = widgetInstances.some((inst, index) => inst.label !== previous[index]?.label);
    if (changed) {
      await writeSettings({ ...settings, widgetInstances });
    }
  }

  return NextResponse.json({ ok: true });
}
