import { NextResponse } from "next/server";
import {
  arrGrabRelease,
  arrInteractiveSearch,
  arrManagerMissing,
  arrMediaAction,
  type ArrMediaAction,
} from "@/lib/widgets/arr";

function kindFromId(value: string): "radarr" | "sonarr" | null {
  return value === "radarr" || value === "sonarr" ? value : null;
}

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const kind = kindFromId(id);
    if (!kind) return NextResponse.json({ error: "Unsupported media manager" }, { status: 404 });
    const url = new URL(request.url);
    const instance = url.searchParams.get("instance") || kind;
    const action = url.searchParams.get("action") || "missing";
    if (action === "missing") {
      return NextResponse.json({ items: await arrManagerMissing(instance, kind) });
    }
    if (action === "search") {
      const targetId = Number(url.searchParams.get("targetId"));
      return NextResponse.json({ releases: await arrInteractiveSearch(instance, kind, targetId) });
    }
    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Media manager request failed" },
      { status: 502 },
    );
  }
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const kind = kindFromId(id);
    if (!kind) return NextResponse.json({ error: "Unsupported media manager" }, { status: 404 });
    const body = (await request.json()) as {
      instance?: string;
      guid?: string;
      indexerId?: number;
      action?: ArrMediaAction;
      targetId?: number;
    };
    if (body.action) {
      return NextResponse.json(
        await arrMediaAction(
          body.instance || kind,
          kind,
          body.action,
          Number(body.targetId),
        ),
      );
    }
    return NextResponse.json(
      await arrGrabRelease(
        body.instance || kind,
        kind,
        String(body.guid || ""),
        Number(body.indexerId),
      ),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Could not grab release" },
      { status: 502 },
    );
  }
}
