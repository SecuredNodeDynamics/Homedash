import { NextResponse } from "next/server";
import { portedWidgetStatus } from "@/lib/widgets/ported";
import { cachedStatus } from "@/lib/status-cache";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { readAuthConfig } from "@/lib/auth";
import { readSettings } from "@/lib/config";
import { profileBookmarks } from "@/lib/auth/profile-bookmarks";

const supported = new Set([
  "net-topology",
  "bookmarks",
  "invest-stocks",
  "invest-crypto",
  "invest-news",
  "nextcloud",
  "youtube",
  "downtify",
  "bazarr",
  "lidarr",
  "tracearr",
  "navidrome",
  "dispatcharr",
]);

const ttlById: Record<string, number> = {
  "invest-news": 60_000,
  "invest-stocks": 45_000,
  "invest-crypto": 60_000,
  lidarr: 45_000,
  navidrome: 45_000,
};

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!supported.has(id)) return NextResponse.json({ error: "Unknown widget" }, { status: 404 });
  const instance = new URL(request.url).searchParams.get("instance") || id;
  const ttlMs = ttlById[id] ?? 30_000;
  try {
    if (id === "bookmarks") {
      const session = await readSessionFromCookies();
      if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
      const auth = await readAuthConfig();
      const user = auth.users.find((item) => item.id === session.sub);
      if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });
      const settings = await readSettings();
      const profileSettings = {
        ...settings,
        ...profileBookmarks(user, settings),
      };
      return NextResponse.json(
        await portedWidgetStatus(id, instance, profileSettings),
        { headers: { "Cache-Control": "private, no-store" } },
      );
    }
    return NextResponse.json(
      await cachedStatus(`${id}:${instance}`, ttlMs, () => portedWidgetStatus(id, instance)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Widget request failed" },
      { status: 502 },
    );
  }
}
