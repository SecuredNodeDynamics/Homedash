import { NextResponse } from "next/server";
import { setAdguardToggle, type AdguardToggle } from "@/lib/widgets/adguard";

const toggles = new Set<AdguardToggle>(["filtering", "safebrowsing", "parental"]);
const MAX_PAUSE_MS = 24 * 60 * 60 * 1000;

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const instanceId = String(body.instance || "adguard-control");
    const toggle = String(body.toggle || "") as AdguardToggle;
    const enabled = Boolean(body.enabled);
    const duration = Math.max(0, Math.min(Number(body.duration) || 0, MAX_PAUSE_MS));

    if (!toggles.has(toggle)) {
      return NextResponse.json({ error: "Invalid AdGuard control" }, { status: 400 });
    }

    await setAdguardToggle(instanceId, toggle, enabled, duration);
    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to update AdGuard" },
      { status: 502 },
    );
  }
}
