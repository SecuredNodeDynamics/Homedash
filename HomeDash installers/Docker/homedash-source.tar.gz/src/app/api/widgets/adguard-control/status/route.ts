import { NextResponse } from "next/server";
import { fetchAdguardStatus } from "@/lib/widgets/adguard";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const instanceId = searchParams.get("instance") || "adguard-control";

  try {
    return NextResponse.json(
      await cachedStatus(`adguard-control:${instanceId}`, 15_000, () =>
        fetchAdguardStatus(instanceId),
      ),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load AdGuard" },
      { status: 502 },
    );
  }
}
