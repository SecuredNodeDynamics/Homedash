import { NextResponse } from "next/server";
import { aiChat, type AiMessage } from "@/lib/widgets/ai-chat";

export async function POST(request: Request) {
  try {
    const body = await request.json() as {
      instance?: string;
      messages?: AiMessage[];
      dashboardContext?: string;
      attachments?: Array<{ name?: string; type?: string; data?: string; size?: number }>;
    };
    return NextResponse.json(await aiChat(
      body.instance || "ai-chat",
      body.messages || [],
      String(body.dashboardContext || "").slice(0, 16_000),
      body.attachments || [],
    ));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "AI request failed" },
      { status: 502 },
    );
  }
}
