import { NextResponse } from "next/server";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { readWidgetConfig, writeWidgetConfig } from "@/lib/config";
import { aiChatInfo, type AiProvider } from "@/lib/widgets/ai-chat";

const PROVIDERS: AiProvider[] = ["openai", "gemini", "claude", "perplexity"];

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "ai-chat";
    return NextResponse.json(await aiChatInfo(instance));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load AI provider" },
      { status: 500 },
    );
  }
}

export async function POST(request: Request) {
  try {
    if (!(await readSessionFromCookies())) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    const body = await request.json() as { instance?: string; provider?: string };
    const instance = String(body.instance || "ai-chat");
    const requested = String(body.provider || "").toLowerCase() as AiProvider;
    if (!PROVIDERS.includes(requested)) {
      return NextResponse.json({ error: "Unsupported AI provider" }, { status: 400 });
    }

    const config = await readWidgetConfig(instance);
    const current = PROVIDERS.includes(config.provider as AiProvider)
      ? config.provider as AiProvider
      : "openai";
    const currentApiKey = String(config.apiKey || config[`${current}ApiKey`] || "");
    const currentModel = String(config.model || config[`${current}Model`] || "");
    const currentEnabled = String(config.enabled || config[`${current}Enabled`] || "true");
    const targetApiKey = requested === current
      ? currentApiKey
      : String(config[`${requested}ApiKey`] || "");
    const targetModel = requested === current
      ? currentModel
      : String(config[`${requested}Model`] || "");
    const targetEnabled = requested === current
      ? currentEnabled
      : String(config[`${requested}Enabled`] || "true");

    await writeWidgetConfig(instance, {
      ...config,
      [`${current}ApiKey`]: currentApiKey,
      [`${current}Model`]: currentModel,
      [`${current}Enabled`]: currentEnabled,
      provider: requested,
      apiKey: targetApiKey,
      model: targetModel,
      enabled: targetEnabled,
    });
    return NextResponse.json(await aiChatInfo(instance));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to switch AI provider" },
      { status: 500 },
    );
  }
}
