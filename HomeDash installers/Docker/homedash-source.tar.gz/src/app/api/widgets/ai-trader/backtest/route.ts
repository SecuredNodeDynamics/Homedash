import { NextResponse } from "next/server";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { cryptoChart } from "@/lib/widgets/invest-crypto";
import { stocksChart } from "@/lib/widgets/invest-stocks";
import {
  optimizeBacktest,
  runBacktest,
  type BacktestInput,
  type TraderStrategy,
} from "@/lib/widgets/ai-trader";

export const runtime = "nodejs";

export async function POST(request: Request) {
  if (!(await readSessionFromCookies())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  try {
    const body = await request.json() as Partial<BacktestInput> & {
      assetType?: "stock" | "crypto";
      asset?: string;
      range?: number;
      optimize?: boolean;
      stockDataInstance?: string;
    };
    const asset = String(body.asset || "").trim();
    if (!asset) return NextResponse.json({ error: "Choose an asset" }, { status: 400 });
    const assetType = body.assetType === "stock" ? "stock" : "crypto";
    const range = Math.max(7, Math.min(365, Number(body.range) || 30));
    const chart = assetType === "stock"
      ? await stocksChart(asset, `${range}d`, String(body.stockDataInstance || "invest-stocks"))
      : await cryptoChart(asset, range);
    const prices = Array.isArray(chart.prices)
      ? (assetType === "stock" ? chart.prices.slice(-range) : chart.prices)
      : [];
    const input: BacktestInput = {
      prices,
      strategy: (["sma", "rsi", "momentum"].includes(String(body.strategy))
        ? body.strategy : "sma") as TraderStrategy,
      capital: Number(body.capital) || 10_000,
      feePct: Number(body.feePct) || 0,
      stopLossPct: Number(body.stopLossPct) || 0,
      takeProfitPct: Number(body.takeProfitPct) || 0,
      fast: Number(body.fast) || 5,
      slow: Number(body.slow) || 20,
      period: Number(body.period) || 14,
      buyThreshold: Number(body.buyThreshold) || (body.strategy === "momentum" ? 2 : 30),
      sellThreshold: Number(body.sellThreshold) || (body.strategy === "momentum" ? -2 : 70),
    };
    if (body.optimize) {
      const ranked = optimizeBacktest(input);
      return NextResponse.json({ result: ranked[0], ranked, asset, assetType, range });
    }
    return NextResponse.json({ result: runBacktest(input), asset, assetType, range });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Backtest failed" },
      { status: 502 },
    );
  }
}
