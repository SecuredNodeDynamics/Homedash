import { NextResponse } from "next/server";
import { readWidgetConfig } from "@/lib/config";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "ai-trader";
    const config = await readWidgetConfig(instance);
    return NextResponse.json({
      stockDataInstance: String(config.stockDataInstance || "invest-stocks"),
      defaultCapital: Math.max(100, Number(config.defaultCapital) || 10_000),
    });
  } catch {
    return NextResponse.json({ stockDataInstance: "invest-stocks", defaultCapital: 10_000 });
  }
}
