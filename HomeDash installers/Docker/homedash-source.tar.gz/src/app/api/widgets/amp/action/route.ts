import { NextResponse } from "next/server";
import { controlAmpInstance } from "@/lib/widgets/amp";

const ACTIONS = new Set(["start", "stop", "restart", "kill", "update", "manage"]);

export async function POST(request: Request) {
  try {
    const body = await request.json() as { instance?: string; instanceName?: string; serverId?: string; action?: string };
    if (!body.instanceName || !body.action || !ACTIONS.has(body.action)) {
      return NextResponse.json({ error: "Invalid AMP action" }, { status: 400 });
    }
    const result = await controlAmpInstance(
      body.instance || "amp",
      body.instanceName,
      body.action as "start" | "stop" | "restart" | "kill" | "update" | "manage",
      body.serverId || "",
    );
    return NextResponse.json({ ok: true, result });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "AMP action failed" },
      { status: 502 },
    );
  }
}
