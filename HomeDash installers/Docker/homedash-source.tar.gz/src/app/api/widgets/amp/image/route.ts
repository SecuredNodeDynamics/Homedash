import { NextResponse } from "next/server";
import { fetchAmpImage } from "@/lib/widgets/amp";

export async function GET(request: Request) {
  try {
    const params = new URL(request.url).searchParams;
    const instance = params.get("instance") || "amp";
    const server = params.get("server") || "";
    if (!server) {
      return NextResponse.json({ error: "Missing AMP server" }, { status: 400 });
    }
    const image = await fetchAmpImage(instance, server);
    return new NextResponse(new Uint8Array(image.bytes), {
      headers: {
        "Content-Type": image.contentType,
        "Cache-Control": "private, max-age=300",
      },
    });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "AMP cover unavailable" },
      { status: 502 },
    );
  }
}
