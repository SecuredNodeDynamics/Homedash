import { NextResponse } from "next/server";
import { fetchAmpStatus } from "@/lib/widgets/amp";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "amp";
    return NextResponse.json(await fetchAmpStatus(instance));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "AMP unavailable" },
      { status: 502 },
    );
  }
}
