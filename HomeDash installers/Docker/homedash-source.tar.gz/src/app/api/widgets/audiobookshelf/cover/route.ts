import { NextResponse } from "next/server";
import { audiobookshelfCover } from "@/lib/widgets/audiobookshelf";

const COVER_PLACEHOLDER = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 280 420">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop stop-color="#182331"/>
      <stop offset="1" stop-color="#0b1119"/>
    </linearGradient>
  </defs>
  <rect width="280" height="420" rx="18" fill="url(#g)"/>
  <rect x="75" y="102" width="130" height="170" rx="12" fill="none" stroke="#62748a" stroke-width="8"/>
  <path d="M104 102v170M123 143h55M123 173h55M123 203h38" fill="none" stroke="#62748a" stroke-width="8" stroke-linecap="round"/>
  <text x="140" y="324" text-anchor="middle" fill="#91a1b5" font-family="system-ui,sans-serif" font-size="18">Cover unavailable</text>
</svg>`;

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const instance = url.searchParams.get("instance") || "audiobookshelf";
    const id = url.searchParams.get("id") || "";
    const width = Number(url.searchParams.get("width") || "400") || 400;
    const response = await audiobookshelfCover(instance, id, width);
    return new Response(response.body, {
      headers: {
        "Content-Type": response.headers.get("content-type") || "image/jpeg",
        "Cache-Control": "private, max-age=600",
      },
    });
  } catch {
    return new NextResponse(COVER_PLACEHOLDER, {
      status: 200,
      headers: {
        "Content-Type": "image/svg+xml; charset=utf-8",
        "Cache-Control": "private, max-age=300",
        "X-Homedash-Image-Fallback": "1",
      },
    });
  }
}
