import { NextResponse } from "next/server";
import { audiobookshelfStatus } from "@/lib/widgets/audiobookshelf";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const instance = url.searchParams.get("instance") || "audiobookshelf";
    const tab = url.searchParams.get("tab") || "library";
    const libraryId = url.searchParams.get("libraryId") || undefined;
    return NextResponse.json(
      await cachedStatus(
        `audiobookshelf:${instance}:${tab}:${libraryId || ""}`,
        30_000,
        () => audiobookshelfStatus(instance, { tab, libraryId }),
      ),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load Audiobookshelf" },
      { status: 502 },
    );
  }
}
