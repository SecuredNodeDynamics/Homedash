import { NextResponse } from "next/server";
import { bookorbitCover } from "@/lib/widgets/bookorbit";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const instance = url.searchParams.get("instance") || "bookorbit";
    const book = url.searchParams.get("book") || "";
    const response = await bookorbitCover(instance, book);
    return new Response(response.body, {
      headers: {
        "Content-Type": response.headers.get("content-type") || "image/jpeg",
        "Cache-Control": "private, max-age=600",
      },
    });
  } catch {
    return new NextResponse(null, { status: 404 });
  }
}
