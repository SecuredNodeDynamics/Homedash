import { NextResponse } from "next/server";
import { bookorbitStatus } from "@/lib/widgets/bookorbit";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const instance = url.searchParams.get("instance") || "bookorbit";
    const tab = url.searchParams.get("tab") || "overview";
    return NextResponse.json(
      await cachedStatus(`bookorbit:${instance}:${tab}`, 30_000, () =>
        bookorbitStatus(instance, tab),
      ),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load" },
      { status: 502 },
    );
  }
}
