import { NextResponse } from "next/server";
import { fetchCheckmkStatus } from "@/lib/widgets/checkmk";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "checkmk";
    return NextResponse.json(
      await cachedStatus(`checkmk:${instance}`, 45_000, () => fetchCheckmkStatus(instance)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load Checkmk" },
      { status: 502 },
    );
  }
}
