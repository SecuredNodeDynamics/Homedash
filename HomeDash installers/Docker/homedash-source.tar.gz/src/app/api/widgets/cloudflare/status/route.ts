import { NextResponse } from "next/server";
import { fetchCloudflareStatus } from "@/lib/widgets/cloudflare";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const instanceId = searchParams.get("instance") || "cloudflare";
  try {
    return NextResponse.json(
      await cachedStatus(`cloudflare:${instanceId}`, 45_000, () =>
        fetchCloudflareStatus(instanceId),
      ),
    );
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to load Cloudflare" },
      { status: 502 },
    );
  }
}
