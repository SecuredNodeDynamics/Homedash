import { NextResponse } from "next/server";
import { readWidgetConfig } from "@/lib/config";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "code-debugger";
    const config = await readWidgetConfig(instance);
    const provider = config.provider === "perplexity" ? "perplexity" : "gemini";
    return NextResponse.json({
      provider,
      configured: {
        gemini: Boolean(String(config.geminiApiKey || (provider === "gemini" ? config.apiKey : "") || "").trim()),
        perplexity: Boolean(String(config.perplexityApiKey || (provider === "perplexity" ? config.apiKey : "") || "").trim()),
      },
    });
  } catch {
    return NextResponse.json({ provider: "gemini", configured: { gemini: false, perplexity: false } });
  }
}
