import { promises as fs } from "fs";
import path from "path";
import { NextResponse } from "next/server";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { atomicWriteJson } from "@/lib/atomic-file";
import { getConfigDir } from "@/lib/config";

export const runtime = "nodejs";

type Language = "html" | "css" | "java" | "nodejs";
type CodeDocument = {
  id: string;
  name: string;
  language: Language;
  code: string;
  updatedAt: number;
};

const LANGUAGES = new Set<Language>(["html", "css", "java", "nodejs"]);

function safeInstance(value: string) {
  return value.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 120) || "code-notes";
}

function fileFor(instance: string) {
  return path.join(getConfigDir(), "code-notes", `${safeInstance(instance)}.json`);
}

function normalize(input: unknown): CodeDocument[] {
  if (!Array.isArray(input)) return [];
  return input.slice(0, 100).flatMap((raw) => {
    if (!raw || typeof raw !== "object") return [];
    const item = raw as Partial<CodeDocument>;
    const language = String(item.language || "") as Language;
    if (!LANGUAGES.has(language)) return [];
    return [{
      id: String(item.id || crypto.randomUUID()).slice(0, 100),
      name: String(item.name || "Untitled").slice(0, 120),
      language,
      code: String(item.code || "").slice(0, 500_000),
      updatedAt: Number(item.updatedAt) || Date.now(),
    }];
  });
}

export async function GET(request: Request) {
  if (!(await readSessionFromCookies())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const instance = new URL(request.url).searchParams.get("instance") || "code-notes";
  try {
    const documents = normalize(
      JSON.parse(await fs.readFile(fileFor(instance), "utf8")),
    );
    return NextResponse.json({ documents });
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") {
      return NextResponse.json({ documents: [] });
    }
    return NextResponse.json({ error: "Failed to load code notes" }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  if (!(await readSessionFromCookies())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  try {
    const body = await request.json() as { instance?: string; documents?: unknown };
    const documents = normalize(body.documents);
    const filePath = fileFor(String(body.instance || "code-notes"));
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    await atomicWriteJson(filePath, documents);
    return NextResponse.json({ ok: true, documents });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to save code notes" },
      { status: 500 },
    );
  }
}
