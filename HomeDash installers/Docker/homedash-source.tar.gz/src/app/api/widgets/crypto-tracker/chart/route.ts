import { NextResponse } from "next/server";
import { cryptoChart } from "@/lib/widgets/invest-crypto";

export async function GET(request: Request) {
  try {
    const params = new URL(request.url).searchParams;
    return NextResponse.json(
      await cryptoChart(params.get("id") || "", Number(params.get("days") || "7")),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load chart" },
      { status: 502 },
    );
  }
}
