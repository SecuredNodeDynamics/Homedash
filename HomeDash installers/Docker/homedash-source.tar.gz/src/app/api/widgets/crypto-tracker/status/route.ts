import { NextResponse } from "next/server";
import { cachedStatus } from "@/lib/status-cache";
import { cryptoStatus } from "@/lib/widgets/invest-crypto";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "crypto-tracker";
    return NextResponse.json(
      await cachedStatus(`crypto-tracker:${instance}`, 60_000, () => cryptoStatus(instance)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load crypto tracker" },
      { status: 502 },
    );
  }
}
