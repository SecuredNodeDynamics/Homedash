import { NextResponse } from "next/server";
import { dispatcharrStatus } from "@/lib/widgets/dispatcharr";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "dispatcharr";
    return NextResponse.json(
      await cachedStatus(`dispatcharr:${instance}`, 30_000, () => dispatcharrStatus(instance)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load Dispatcharr" },
      { status: 502 },
    );
  }
}
