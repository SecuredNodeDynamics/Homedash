import { NextResponse } from "next/server";
import {
  dockerContainerAction,
  isDockerAction,
} from "@/lib/widgets/docker";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const instanceId = String(body.instance || "docker");
    const containerId = String(body.containerId || "");
    const action = String(body.action || "");

    if (!isDockerAction(action)) {
      return NextResponse.json({ error: "Invalid Docker action" }, { status: 400 });
    }
    if (!containerId) {
      return NextResponse.json({ error: "Missing container id" }, { status: 400 });
    }

    await dockerContainerAction(instanceId, containerId, action);
    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to update Docker container" },
      { status: 502 },
    );
  }
}
