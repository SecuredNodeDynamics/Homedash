import { NextResponse } from "next/server";
import { createDockerExecSession } from "@/lib/widgets/docker";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const instanceId = String(body.instance || "docker");
    const containerId = String(body.containerId || "");
    const cmd = Array.isArray(body.cmd) ? body.cmd.map(String) : undefined;
    if (!containerId) {
      return NextResponse.json({ error: "Missing container id" }, { status: 400 });
    }
    const session = await createDockerExecSession(instanceId, containerId, cmd);
    const proto = request.headers.get("x-forwarded-proto") || "http";
    const host = request.headers.get("x-forwarded-host") || request.headers.get("host") || "localhost";
    const wsProto = proto === "https" ? "wss" : "ws";
    return NextResponse.json({
      ticket: session.ticket,
      wsUrl: `${wsProto}://${host}${session.wsPath}`,
      wsPath: session.wsPath,
    });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to create exec session" },
      { status: 502 },
    );
  }
}
