import { NextResponse } from "next/server";
import { fetchDockerLogs } from "@/lib/widgets/docker";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const instanceId = searchParams.get("instance") || "docker";
  const containerId = searchParams.get("id") || "";
  const tail = Number(searchParams.get("tail") || 200);
  try {
    if (!containerId) {
      return NextResponse.json({ error: "Missing container id" }, { status: 400 });
    }
    const logs = await fetchDockerLogs(instanceId, containerId, tail);
    return NextResponse.json({ logs });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to load logs" },
      { status: 502 },
    );
  }
}
