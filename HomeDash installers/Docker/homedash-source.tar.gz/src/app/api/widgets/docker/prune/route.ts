import { NextResponse } from "next/server";
import { pruneDockerImages } from "@/lib/widgets/docker";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const instanceId = String(body.instance || "docker");
    const target = String(body.target || "images");
    if (target !== "images") {
      return NextResponse.json({ error: "Unsupported prune target" }, { status: 400 });
    }
    const result = await pruneDockerImages(instanceId);
    return NextResponse.json(result);
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to prune images" },
      { status: 502 },
    );
  }
}
