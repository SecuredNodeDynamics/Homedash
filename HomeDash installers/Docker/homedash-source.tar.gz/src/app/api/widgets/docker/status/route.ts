import { NextResponse } from "next/server";
import { fetchDockerStatus } from "@/lib/widgets/docker";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const instanceId = searchParams.get("instance") || "docker";
  try {
    const data = await cachedStatus(`docker:${instanceId}`, 30_000, () =>
      fetchDockerStatus(instanceId),
    );
    return NextResponse.json(data);
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to load Docker" },
      { status: 502 },
    );
  }
}
