import { NextResponse } from "next/server";
import { deleteDockerVolume, fetchDockerVolumes } from "@/lib/widgets/docker";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const instanceId = searchParams.get("instance") || "docker";
  try {
    const volumes = await fetchDockerVolumes(instanceId);
    return NextResponse.json({ volumes });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to load volumes" },
      { status: 502 },
    );
  }
}

export async function DELETE(request: Request) {
  try {
    const body = await request.json();
    const instanceId = String(body.instance || "docker");
    const name = String(body.name || "");
    const force = Boolean(body.force);
    if (!name) return NextResponse.json({ error: "Missing volume name" }, { status: 400 });
    await deleteDockerVolume(instanceId, name, force);
    return NextResponse.json({ ok: true });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to delete volume" },
      { status: 502 },
    );
  }
}
