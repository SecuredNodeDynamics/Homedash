import { NextResponse } from "next/server";
import {
  downtifyDownload,
  downtifyLibrary,
  downtifySearch,
  type DowntifySong,
} from "@/lib/widgets/downtify";

type ActionBody = {
  instance?: string;
  action?: "search" | "library" | "download";
  query?: string;
  item?: DowntifySong;
  clientId?: string;
};

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as ActionBody;
    const instance = body.instance || "downtify";
    const action = body.action || "search";

    if (action === "library") {
      return NextResponse.json(await downtifyLibrary(instance));
    }
    if (action === "search") {
      return NextResponse.json(await downtifySearch(instance, body.query || ""));
    }
    if (action === "download") {
      if (!body.item) throw new Error("Download item missing");
      return NextResponse.json(
        await downtifyDownload(instance, { item: body.item, clientId: body.clientId }),
      );
    }
    throw new Error(`Unknown action: ${action}`);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Downtify action failed" },
      { status: 502 },
    );
  }
}
