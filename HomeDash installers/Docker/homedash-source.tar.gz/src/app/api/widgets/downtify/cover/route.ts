import { NextResponse } from "next/server";
import { downtifyCover } from "@/lib/widgets/downtify";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const instance = url.searchParams.get("instance") || "downtify";
    const file = url.searchParams.get("file") || "";
    const imageUrl = url.searchParams.get("url") || "";
    const artist = url.searchParams.get("artist") || "";
    const size = Number(url.searchParams.get("size") || "240") || 240;
    const response = await downtifyCover(instance, { file, url: imageUrl, artist, size });
    const body = Buffer.from(await response.arrayBuffer());
    return new Response(body, {
      headers: {
        "Content-Type": response.headers.get("content-type") || "image/jpeg",
        "Cache-Control": "private, max-age=600",
      },
    });
  } catch {
    return new NextResponse(null, { status: 404 });
  }
}
