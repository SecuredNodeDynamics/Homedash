import { NextResponse } from "next/server";
import { downtifyStatus } from "@/lib/widgets/downtify";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "downtify";
    return NextResponse.json(
      await cachedStatus(`downtify:${instance}`, 30_000, () => downtifyStatus(instance)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load Downtify" },
      { status: 502 },
    );
  }
}
