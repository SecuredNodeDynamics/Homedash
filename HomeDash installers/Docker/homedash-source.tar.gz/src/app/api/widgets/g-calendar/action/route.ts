import { NextResponse } from "next/server";
import { performGCalAction, type GCalActionKind } from "@/lib/widgets/google-calendar";

const VALID_ACTIONS: GCalActionKind[] = ["create-event", "update-event", "delete-event"];

export async function POST(request: Request) {
  let body: { instance?: string; action?: string } & Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const instanceId = String(body.instance || "g-calendar");
  const action = body.action as GCalActionKind;

  if (!VALID_ACTIONS.includes(action)) {
    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  }

  const { instance: _instance, action: _action, ...payload } = body;

  try {
    const result = await performGCalAction(instanceId, action, payload);
    return NextResponse.json({ ok: true, result });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Action failed" },
      { status: 502 },
    );
  }
}
