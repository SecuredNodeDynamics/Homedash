import { NextResponse } from "next/server";
import { fetchGCalStatus } from "@/lib/widgets/google-calendar";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const instanceId = searchParams.get("instance") || "g-calendar";

  try {
    return NextResponse.json(
      await cachedStatus(`g-calendar:${instanceId}`, 30_000, () => fetchGCalStatus(instanceId)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load Google Calendar" },
      { status: 502 },
    );
  }
}
