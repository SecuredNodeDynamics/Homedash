import { NextResponse } from "next/server";
import { callHomeAssistantService } from "@/lib/widgets/homeassistant";
export async function POST(request: Request) {
  try {
    const body = await request.json();
    if (!body.entityId) throw new Error("Missing entity");
    await callHomeAssistantService(String(body.instance || "homeassistant"), String(body.entityId), body.service);
    return NextResponse.json({ ok: true });
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "Action failed" }, { status: 502 }); }
}
