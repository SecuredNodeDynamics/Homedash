import { cameraSnapshot } from "@/lib/widgets/homeassistant";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const instance = url.searchParams.get("instance") || "homeassistant";
    const entity = url.searchParams.get("entity") || "";
    const stream = url.searchParams.get("stream") === "1";
    const response = await cameraSnapshot(instance, entity, stream);
    return new Response(response.body, {
      headers: {
        "Content-Type": response.headers.get("content-type") || "image/jpeg",
        "Cache-Control": stream ? "no-store" : "private, max-age=2",
      },
    });
  } catch {
    return new Response(null, { status: 404 });
  }
}
