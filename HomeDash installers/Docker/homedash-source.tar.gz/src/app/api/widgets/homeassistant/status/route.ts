import { NextResponse } from "next/server";
import { fetchHomeAssistantStatus } from "@/lib/widgets/homeassistant";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  const instanceId = new URL(request.url).searchParams.get("instance") || "homeassistant";
  try {
    return NextResponse.json(
      await cachedStatus(`homeassistant:${instanceId}`, 22_500, () =>
        fetchHomeAssistantStatus(instanceId),
      ),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load Home Assistant" },
      { status: 502 },
    );
  }
}
