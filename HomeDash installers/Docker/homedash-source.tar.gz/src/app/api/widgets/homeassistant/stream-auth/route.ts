import { NextResponse } from "next/server";
import { cameraStreamAuth } from "@/lib/widgets/homeassistant";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "homeassistant";
    return NextResponse.json(await cameraStreamAuth(instance));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load stream auth" },
      { status: 502 },
    );
  }
}
