import { NextResponse } from "next/server";
import { immichAlbum } from "@/lib/widgets/media";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const instance = url.searchParams.get("instance") || "immich";
    const albumId = url.searchParams.get("id") || "";
    if (!albumId) {
      return NextResponse.json({ error: "Missing album id" }, { status: 400 });
    }
    return NextResponse.json(await immichAlbum(instance, albumId));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load album" },
      { status: 502 },
    );
  }
}
