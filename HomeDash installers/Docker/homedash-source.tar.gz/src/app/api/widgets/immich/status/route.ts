import { NextResponse } from "next/server";
import { immichStatus } from "@/lib/widgets/media";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "immich";
    return NextResponse.json(
      await cachedStatus(`immich:${instance}`, 60_000, () => immichStatus(instance)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load" },
      { status: 502 },
    );
  }
}
