import { NextResponse } from "next/server";
import { cryptoChart } from "@/lib/widgets/invest-crypto";

export async function GET(request: Request) {
  try {
    const params = new URL(request.url).searchParams;
    const id = params.get("id") || "";
    const days = Number(params.get("days") || "1");
    return NextResponse.json(await cryptoChart(id, days));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load chart" },
      { status: 502 },
    );
  }
}
