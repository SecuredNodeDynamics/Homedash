import { NextResponse } from "next/server";
import { cryptoStatus } from "@/lib/widgets/invest-crypto";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "invest-crypto";
    return NextResponse.json(
      await cachedStatus(`invest-crypto:${instance}`, 60_000, () => cryptoStatus(instance)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load crypto" },
      { status: 502 },
    );
  }
}
