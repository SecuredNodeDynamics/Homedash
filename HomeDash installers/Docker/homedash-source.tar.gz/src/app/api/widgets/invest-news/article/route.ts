import { lookup } from "node:dns/promises";
import { isIP } from "node:net";
import { NextResponse } from "next/server";

function privateAddress(address: string) {
  if (address === "::1" || address === "0.0.0.0") return true;
  if (address.startsWith("fc") || address.startsWith("fd") || address.startsWith("fe80:")) return true;
  if (address.startsWith("::ffff:")) return privateAddress(address.slice(7));
  const parts = address.split(".").map(Number);
  if (parts.length !== 4) return false;
  return (
    parts[0] === 10 ||
    parts[0] === 127 ||
    parts[0] === 0 ||
    (parts[0] === 169 && parts[1] === 254) ||
    (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) ||
    (parts[0] === 192 && parts[1] === 168)
  );
}

async function assertPublicUrl(value: string) {
  const url = new URL(value);
  if (!["http:", "https:"].includes(url.protocol)) throw new Error("Unsupported article URL");
  if (url.username || url.password) throw new Error("Article URL credentials are not allowed");
  if (url.port && !["80", "443"].includes(url.port)) throw new Error("Unsupported article URL port");
  const addresses = isIP(url.hostname)
    ? [{ address: url.hostname }]
    : await lookup(url.hostname, { all: true });
  if (!addresses.length || addresses.some((entry) => privateAddress(entry.address))) {
    throw new Error("Private article addresses are not allowed");
  }
  return url;
}

function decodeText(value: string) {
  return value
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, "\"")
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&#(\d+);/g, (_, code: string) => String.fromCharCode(Number(code)))
    .replace(/\s+/g, " ")
    .trim();
}

function extractArticle(html: string) {
  const jsonBlocks = Array.from(
    html.matchAll(/<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi),
  );
  for (const match of jsonBlocks) {
    try {
      const parsed = JSON.parse(match[1]) as unknown;
      const queue = Array.isArray(parsed) ? [...parsed] : [parsed];
      while (queue.length) {
        const value = queue.shift();
        if (!value || typeof value !== "object") continue;
        const record = value as Record<string, unknown>;
        if (typeof record.articleBody === "string" && record.articleBody.length > 300) {
          return decodeText(record.articleBody);
        }
        if (Array.isArray(record["@graph"])) queue.push(...record["@graph"]);
      }
    } catch {
      // Some publishers emit malformed or multiple JSON values.
    }
  }

  const cleaned = html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<nav[\s\S]*?<\/nav>/gi, " ")
    .replace(/<footer[\s\S]*?<\/footer>/gi, " ");
  const article = cleaned.match(/<article\b[^>]*>([\s\S]*?)<\/article>/i)?.[1] || cleaned;
  const paragraphs = Array.from(article.matchAll(/<p\b[^>]*>([\s\S]*?)<\/p>/gi))
    .map((match) => decodeText(match[1]))
    .filter((paragraph) => paragraph.length >= 45);
  return paragraphs.join(" ").slice(0, 30_000);
}

async function fetchArticle(initialUrl: string) {
  let current = await assertPublicUrl(initialUrl);
  for (let redirect = 0; redirect < 4; redirect += 1) {
    const response = await fetch(current, {
      cache: "no-store",
      redirect: "manual",
      signal: AbortSignal.timeout(15_000),
      headers: {
        Accept: "text/html,application/xhtml+xml",
        "User-Agent": "Mozilla/5.0 (compatible; HomedashArticleBrief/1.0)",
      },
    });
    if (response.status >= 300 && response.status < 400) {
      const location = response.headers.get("location");
      if (!location) throw new Error("Publisher returned an invalid redirect");
      current = await assertPublicUrl(new URL(location, current).toString());
      continue;
    }
    if (!response.ok) throw new Error(`Publisher returned HTTP ${response.status}`);
    const contentType = response.headers.get("content-type") || "";
    if (!contentType.includes("text/html") && !contentType.includes("application/xhtml")) {
      throw new Error("Publisher did not return an HTML article");
    }
    const html = (await response.text()).slice(0, 2_000_000);
    return { content: extractArticle(html), resolvedUrl: current.toString() };
  }
  throw new Error("Too many publisher redirects");
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { url?: string };
    if (!body.url) return NextResponse.json({ error: "Article URL required" }, { status: 400 });
    const article = await fetchArticle(body.url);
    if (article.content.length < 120) {
      throw new Error("The publisher did not expose enough article text for an extended report");
    }
    return NextResponse.json(article);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to retrieve article" },
      { status: 502 },
    );
  }
}
