import { NextResponse } from "next/server";
import { stocksChart } from "@/lib/widgets/invest-stocks";

export async function GET(request: Request) {
  try {
    const params = new URL(request.url).searchParams;
    const symbol = params.get("symbol") || params.get("id") || "";
    const tab = params.get("tab") || "live";
    const instance = params.get("instance") || "invest-stocks";
    return NextResponse.json(await stocksChart(symbol, tab, instance));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load chart" },
      { status: 502 },
    );
  }
}
