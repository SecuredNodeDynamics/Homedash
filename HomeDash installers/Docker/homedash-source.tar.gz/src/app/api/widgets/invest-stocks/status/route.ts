import { NextResponse } from "next/server";
import { stocksStatus } from "@/lib/widgets/invest-stocks";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "invest-stocks";
    return NextResponse.json(
      await cachedStatus(`invest-stocks:${instance}`, 45_000, () => stocksStatus(instance)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load stocks" },
      { status: 502 },
    );
  }
}
