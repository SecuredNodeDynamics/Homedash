import { NextResponse } from "next/server";
import {
  JcmProxyError,
  jcmAction,
  jcmImage,
  jcmMissing,
  jcmProxy,
  jcmStatus,
  jcmStatusFresh,
} from "@/lib/widgets/jellyfin-collections-mgr";

function fail(error: unknown, fallback: string) {
  const status = error instanceof JcmProxyError ? error.status : 502;
  const drift = error instanceof JcmProxyError ? error.drift : undefined;
  return NextResponse.json(
    { error: error instanceof Error ? error.message : fallback, drift },
    { status: status >= 400 && status < 600 ? status : 502 },
  );
}

export async function GET(request: Request) {
  try {
    const params = new URL(request.url).searchParams;
    const instanceId = params.get("instance") || "jellyfin-collections-mgr";

    const img = params.get("img");
    if (img) {
      try {
        const image = await jcmImage(instanceId, img);
        return new NextResponse(image.body, {
          headers: { "Content-Type": image.type, "Cache-Control": "private, max-age=3600" },
        });
      } catch {
        return new NextResponse(null, { status: 404 });
      }
    }

    if (params.get("missing")) return NextResponse.json(await jcmMissing(instanceId, params.get("fresh") === "1"));

    const proxy = params.get("proxy");
    if (proxy) return NextResponse.json(await jcmProxy(instanceId, "GET", proxy));

    const data = params.get("fresh") === "1" ? await jcmStatusFresh(instanceId) : await jcmStatus(instanceId);
    return NextResponse.json(data);
  } catch (error) {
    return fail(error, "Failed to load Collection Manager");
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      instance?: string;
      action?: string;
      force?: boolean;
      path?: string;
      body?: Record<string, unknown>;
    };
    const instanceId = body.instance || "jellyfin-collections-mgr";

    if (body.action === "proxy") {
      return NextResponse.json(await jcmProxy(instanceId, "POST", String(body.path || ""), body.body || {}));
    }

    const result = await jcmAction(instanceId, body.action || "", Boolean(body.force));
    const status = await jcmStatusFresh(instanceId).catch(() => null);
    return NextResponse.json({ ...result, status }, { status: result.ok ? 200 : 409 });
  } catch (error) {
    return fail(error, "Action failed");
  }
}
