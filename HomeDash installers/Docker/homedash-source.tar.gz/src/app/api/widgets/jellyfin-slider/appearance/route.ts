import { NextResponse } from "next/server";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { readWidgetConfig } from "@/lib/config";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  if (!(await readSessionFromCookies())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const instanceId = new URL(request.url).searchParams.get("instance") || "jellyfin-slider";
  const config = await readWidgetConfig(instanceId);
  const speed = Math.max(150, Math.min(1200, Number(config.caseViewSpeed) || 520));
  return NextResponse.json(
    {
      caseView: String(config.caseView ?? "false").toLowerCase() === "true",
      caseViewSpeed: speed,
      musicShelf: String(config.musicShelf ?? "false").toLowerCase() === "true",
    },
    { headers: { "Cache-Control": "no-store, max-age=0" } },
  );
}
