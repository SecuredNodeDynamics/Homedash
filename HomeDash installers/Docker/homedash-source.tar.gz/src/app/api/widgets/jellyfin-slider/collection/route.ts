import { NextResponse } from "next/server";
import { fetchJellyfinCollection } from "@/lib/widgets/jellyfin-slider";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const instanceId = searchParams.get("instance") || "jellyfin-slider";
    const id = searchParams.get("id") || "";
    const server = Number(searchParams.get("server") || 0);
    if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
    return NextResponse.json(await fetchJellyfinCollection(instanceId, id, server));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load collection" },
      { status: 502 },
    );
  }
}
