import { jellyfinAudioStreamResponse } from "@/lib/widgets/jellyfin-slider";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const instanceId = searchParams.get("instance") || "jellyfin-slider";
    const itemId = searchParams.get("itemId") || "";
    const server = Number(searchParams.get("server") || 0);
    if (!itemId) {
      return Response.json({ error: "itemId required" }, { status: 400 });
    }
    const upstream = await jellyfinAudioStreamResponse(
      instanceId,
      itemId,
      server,
      request.headers.get("range"),
    );
    const headers = new Headers();
    for (const key of [
      "accept-ranges",
      "content-length",
      "content-range",
      "content-type",
      "etag",
      "last-modified",
    ]) {
      const value = upstream.headers.get(key);
      if (value) headers.set(key, value);
    }
    headers.set("Cache-Control", "private, no-store");
    return new Response(upstream.body, {
      status: upstream.status === 206 ? 206 : 200,
      headers,
    });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Audio demo failed" },
      { status: 502 },
    );
  }
}
