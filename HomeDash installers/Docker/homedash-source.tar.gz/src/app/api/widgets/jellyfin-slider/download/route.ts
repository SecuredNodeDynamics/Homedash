import { jellyfinDownloadResponse } from "@/lib/widgets/jellyfin-slider";

// Jellyfin's own filename (from its Content-Disposition header) is the most
// reliable source for the real container extension. Content-Type is a
// fallback for the rare server/proxy that omits Content-Disposition.
const MIME_EXTENSIONS: Record<string, string> = {
  "video/x-matroska": "mkv",
  "video/mp4": "mp4",
  "video/quicktime": "mov",
  "video/x-msvideo": "avi",
  "video/webm": "webm",
  "video/mpeg": "mpeg",
  "video/x-ms-wmv": "wmv",
  "audio/mpeg": "mp3",
  "audio/mp4": "m4a",
  "audio/flac": "flac",
  "audio/x-flac": "flac",
  "audio/ogg": "ogg",
  "audio/wav": "wav",
  "audio/x-wav": "wav",
};

function fileExtension(name: string) {
  const match = /\.([a-zA-Z0-9]{2,5})$/.exec(name);
  return match ? match[1].toLowerCase() : "";
}

function upstreamExtension(upstream: Response) {
  const disposition = upstream.headers.get("content-disposition");
  if (disposition) {
    const match = /filename\*?=(?:UTF-8'')?"?([^";]+)"?/i.exec(disposition);
    if (match) {
      let raw = match[1];
      try {
        raw = decodeURIComponent(raw);
      } catch {
        /* keep raw as-is */
      }
      const ext = fileExtension(raw);
      if (ext) return ext;
    }
  }
  const contentType = upstream.headers.get("content-type")?.split(";")[0]?.trim().toLowerCase();
  return (contentType && MIME_EXTENSIONS[contentType]) || "";
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const instanceId = searchParams.get("instance") || "jellyfin-slider";
    const itemId = searchParams.get("itemId") || "";
    const server = Number(searchParams.get("server") || 0);
    const requestedFilename = searchParams.get("filename") || "download";
    if (!itemId) {
      return new Response(JSON.stringify({ error: "itemId required" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }
    const upstream = await jellyfinDownloadResponse(instanceId, itemId, server);
    const headers = new Headers();
    const contentType = upstream.headers.get("content-type");
    const contentEncoding = upstream.headers.get("content-encoding");
    const contentLength = upstream.headers.get("content-length");
    if (contentType) headers.set("Content-Type", contentType);
    // Only trust the upstream Content-Length when the body wasn't compressed.
    // fetch() auto-decompresses gzip/br bodies but can't rewrite the
    // upstream-reported length, so forwarding it as-is would promise the
    // browser a byte count that doesn't match what actually streams down.
    // Chrome/Edge/Safari truncate (and thus corrupt) the saved .mkv/.mp4 when
    // that count is off; Firefox doesn't enforce it, which is why only
    // Firefox produced an intact file before. Omitting Content-Length falls
    // back to chunked transfer encoding, which every browser downloads to
    // completion correctly.
    if (contentLength && !contentEncoding) headers.set("Content-Length", contentLength);

    // The widget builds friendly download names like "Show - S01E02 - Title"
    // that never include a file extension. Firefox's download manager
    // sniffs the Content-Type and silently appends the right extension when
    // one is missing, but Chrome/Edge/Safari save the name exactly as given
    // -- producing an extension-less file the OS can't associate with a
    // player. Append the real container extension (from Jellyfin's own
    // Content-Disposition, or the Content-Type as a fallback) whenever the
    // requested name doesn't already end in it.
    const ext = upstreamExtension(upstream);
    const hasExt = fileExtension(requestedFilename);
    const filename = ext && hasExt !== ext ? `${requestedFilename}.${ext}` : requestedFilename;

    const safeFilename = filename.replace(/[^\w.\- ()[\]]+/g, "_");
    headers.set(
      "Content-Disposition",
      `attachment; filename="${safeFilename}"; filename*=UTF-8''${encodeURIComponent(filename)}`,
    );
    headers.set("Cache-Control", "private, no-store");
    return new Response(upstream.body, { status: 200, headers });
  } catch (error) {
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : "Download failed",
      }),
      { status: 502, headers: { "Content-Type": "application/json" } },
    );
  }
}
