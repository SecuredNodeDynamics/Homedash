import { NextResponse } from "next/server";
import { fetchJellyfinItems } from "@/lib/widgets/jellyfin-slider";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const instanceId = searchParams.get("instance") || "jellyfin-slider";
    const section = searchParams.get("section") || "";
    const server = Number(searchParams.get("server") || 0);
    return NextResponse.json(await fetchJellyfinItems(instanceId, section, server));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load items" },
      { status: 502 },
    );
  }
}
