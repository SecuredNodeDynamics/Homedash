import { NextResponse } from "next/server";
import { triggerJellyfinLibraryScan } from "@/lib/widgets/jellyfin-slider";

export async function POST(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const instanceId = searchParams.get("instance") || "jellyfin-slider";
    const section = searchParams.get("section") || "";
    const server = Number(searchParams.get("server") || 0);
    const result = await triggerJellyfinLibraryScan(instanceId, section, server);
    return NextResponse.json(
      { ok: true, ...result },
      { headers: { "Cache-Control": "no-store, max-age=0" } },
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to sync library" },
      { status: 502 },
    );
  }
}
