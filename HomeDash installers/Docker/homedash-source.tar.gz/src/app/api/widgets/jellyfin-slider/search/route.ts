import { NextResponse } from "next/server";
import { searchJellyfin } from "@/lib/widgets/jellyfin-slider";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const instanceId = searchParams.get("instance") || "jellyfin-slider";
    const q = searchParams.get("q") || "";
    const server = Number(searchParams.get("server") || 0);
    if (!q.trim()) return NextResponse.json({ items: [] });
    return NextResponse.json(await searchJellyfin(instanceId, q.trim(), server));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Search failed" },
      { status: 502 },
    );
  }
}
