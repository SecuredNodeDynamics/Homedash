import { NextResponse } from "next/server";
import {
  fetchJellyfinEpisodes,
  fetchJellyfinSeasons,
} from "@/lib/widgets/jellyfin-slider";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const instanceId = searchParams.get("instance") || "jellyfin-slider";
    const seriesId = searchParams.get("seriesId") || "";
    const seasonId = searchParams.get("seasonId") || "";
    const server = Number(searchParams.get("server") || 0);
    if (!seriesId) return NextResponse.json({ error: "seriesId required" }, { status: 400 });
    if (seasonId) {
      return NextResponse.json(await fetchJellyfinEpisodes(instanceId, seriesId, seasonId, server));
    }
    return NextResponse.json(await fetchJellyfinSeasons(instanceId, seriesId, server));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load seasons" },
      { status: 502 },
    );
  }
}
