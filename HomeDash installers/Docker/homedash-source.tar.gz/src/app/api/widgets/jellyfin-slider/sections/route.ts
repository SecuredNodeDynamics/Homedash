import { NextResponse } from "next/server";
import { fetchJellyfinSections } from "@/lib/widgets/jellyfin-slider";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const instanceId = searchParams.get("instance") || "jellyfin-slider";
    const server = Number(searchParams.get("server") || 0);
    return NextResponse.json(await fetchJellyfinSections(instanceId, server), {
      headers: { "Cache-Control": "no-store, max-age=0" },
    });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load sections" },
      { status: 502 },
    );
  }
}
