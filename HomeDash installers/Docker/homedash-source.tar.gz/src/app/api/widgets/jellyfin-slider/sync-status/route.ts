import { NextResponse } from "next/server";
import { getJellyfinScanStatus } from "@/lib/widgets/jellyfin-slider";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const instanceId = searchParams.get("instance") || "jellyfin-slider";
    const server = Number(searchParams.get("server") || 0);
    const status = await getJellyfinScanStatus(instanceId, server);
    return NextResponse.json(status, { headers: { "Cache-Control": "no-store, max-age=0" } });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to check sync status" },
      { status: 502 },
    );
  }
}
