import { NextResponse } from "next/server";
import { fetchJellyfinTracks } from "@/lib/widgets/jellyfin-slider";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const instanceId = searchParams.get("instance") || "jellyfin-slider";
    const albumId = searchParams.get("albumId") || "";
    const server = Number(searchParams.get("server") || 0);
    if (!albumId) return NextResponse.json({ error: "albumId required" }, { status: 400 });
    return NextResponse.json(await fetchJellyfinTracks(instanceId, albumId, server));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load tracks" },
      { status: 502 },
    );
  }
}
