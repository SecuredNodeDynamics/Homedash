import { NextResponse } from "next/server";
import { fetchJellyfinTrailer } from "@/lib/widgets/jellyfin-slider";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const instanceId = searchParams.get("instance") || "jellyfin-slider";
    const itemId = searchParams.get("itemId") || "";
    const server = Number(searchParams.get("server") || 0);
    if (!itemId) {
      return NextResponse.json({ error: "itemId required" }, { status: 400 });
    }
    const trailer = await fetchJellyfinTrailer(instanceId, itemId, server);
    return NextResponse.json({ trailer });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load trailer" },
      { status: 502 },
    );
  }
}
