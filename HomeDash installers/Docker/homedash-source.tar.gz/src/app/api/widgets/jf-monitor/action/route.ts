import { NextResponse } from "next/server";
import {
  jfMonitorGroupMessage,
  jfMonitorSessionCommand,
  jfMonitorSessionMessage,
  jfMonitorSyncAll,
  jfMonitorSyncLibrary,
} from "@/lib/widgets/jf-monitor";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      instance?: string;
      action?: string;
      sessionId?: string;
      libraryId?: string;
      command?: string;
      text?: string;
    };
    const instanceId = body.instance || "jf-monitor";
    const action = body.action || "";

    if (action === "sync-all") {
      return NextResponse.json(await jfMonitorSyncAll(instanceId));
    }
    if (action === "sync-library") {
      if (!body.libraryId) return NextResponse.json({ error: "libraryId required" }, { status: 400 });
      return NextResponse.json(await jfMonitorSyncLibrary(instanceId, body.libraryId));
    }
    if (action === "session-command") {
      if (!body.sessionId || !body.command) {
        return NextResponse.json({ error: "sessionId and command required" }, { status: 400 });
      }
      return NextResponse.json(
        await jfMonitorSessionCommand(instanceId, body.sessionId, body.command),
      );
    }
    if (action === "session-message") {
      if (!body.sessionId) {
        return NextResponse.json({ error: "sessionId required" }, { status: 400 });
      }
      return NextResponse.json(
        await jfMonitorSessionMessage(instanceId, body.sessionId, body.text || ""),
      );
    }
    if (action === "group-message") {
      return NextResponse.json(await jfMonitorGroupMessage(instanceId, body.text || ""));
    }

    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Action failed" },
      { status: 502 },
    );
  }
}
