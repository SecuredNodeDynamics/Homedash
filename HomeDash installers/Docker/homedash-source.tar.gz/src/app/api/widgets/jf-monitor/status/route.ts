import { NextResponse } from "next/server";
import { jfMonitorStatus } from "@/lib/widgets/jf-monitor";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const instanceId = new URL(request.url).searchParams.get("instance") || "jf-monitor";
    return NextResponse.json(
      await cachedStatus(`jf-monitor:${instanceId}`, 15_000, () => jfMonitorStatus(instanceId)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load Jellyfin" },
      { status: 502 },
    );
  }
}
