import { NextResponse } from "next/server";
import { jfMonitorSyncStatus } from "@/lib/widgets/jf-monitor";

// Intentionally NOT wrapped in cachedStatus (unlike /status): this is only
// polled while a sync is actively running, at a short interval, and needs to
// reflect Jellyfin's live scan percentage rather than a stale snapshot.
export async function GET(request: Request) {
  try {
    const instanceId = new URL(request.url).searchParams.get("instance") || "jf-monitor";
    return NextResponse.json(await jfMonitorSyncStatus(instanceId));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load sync status" },
      { status: 502 },
    );
  }
}
