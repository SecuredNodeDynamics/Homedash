import { NextResponse } from "next/server";
import { lidarrStatus } from "@/lib/widgets/arr";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "lidarr";
    return NextResponse.json(
      await cachedStatus(`lidarr:${instance}`, 45_000, () => lidarrStatus(instance)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load Lidarr" },
      { status: 502 },
    );
  }
}
