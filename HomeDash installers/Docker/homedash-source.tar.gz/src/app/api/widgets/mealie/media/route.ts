import { NextResponse } from "next/server";
import { mealieMedia } from "@/lib/widgets/mealie";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const instance = url.searchParams.get("instance") || "mealie";
    const id = url.searchParams.get("id") || "";
    const variant = url.searchParams.get("variant") || "min-original.webp";
    const response = await mealieMedia(instance, id, variant);
    return new Response(response.body, {
      headers: {
        "Content-Type": response.headers.get("content-type") || "image/webp",
        "Cache-Control": "private, max-age=600",
      },
    });
  } catch {
    return new NextResponse(null, { status: 404 });
  }
}
