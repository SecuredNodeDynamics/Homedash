import { NextResponse } from "next/server";
import { mealieStatus } from "@/lib/widgets/mealie";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "mealie";
    return NextResponse.json(
      await cachedStatus(`mealie:${instance}`, 60_000, () => mealieStatus(instance)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load Mealie" },
      { status: 502 },
    );
  }
}
