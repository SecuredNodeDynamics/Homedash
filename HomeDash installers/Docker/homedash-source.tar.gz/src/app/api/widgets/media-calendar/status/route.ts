import { NextResponse } from "next/server";
import { calendarStatus } from "@/lib/widgets/calendar";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "media-calendar";
    return NextResponse.json(
      await cachedStatus(`media-calendar:${instance}`, 60_000, () => calendarStatus(instance)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load calendar" },
      { status: 502 },
    );
  }
}
