import { NextResponse } from "next/server";
import { performN8nAction, type N8nActionKind } from "@/lib/widgets/n8n";

const VALID_ACTIONS: N8nActionKind[] = [
  "activate-workflow",
  "deactivate-workflow",
  "archive-workflow",
  "unarchive-workflow",
  "delete-workflow",
  "retry-execution",
  "stop-execution",
  "delete-execution",
];

export async function POST(request: Request) {
  let body: { instance?: string; action?: string; id?: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const instanceId = body.instance || "n8n-monitor";
  const action = body.action as N8nActionKind;
  const id = String(body.id || "");

  if (!VALID_ACTIONS.includes(action)) {
    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  }
  if (!id) {
    return NextResponse.json({ error: "Missing id" }, { status: 400 });
  }

  try {
    const result = await performN8nAction(instanceId, action, id);
    return NextResponse.json({ ok: true, result });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Action failed" },
      { status: 502 },
    );
  }
}
