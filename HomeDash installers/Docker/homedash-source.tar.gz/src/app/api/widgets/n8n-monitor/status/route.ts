import { NextResponse } from "next/server";
import { fetchN8nStatus } from "@/lib/widgets/n8n";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const instanceId = searchParams.get("instance") || "n8n-monitor";

  try {
    return NextResponse.json(
      await cachedStatus(`n8n-monitor:${instanceId}`, 45_000, () => fetchN8nStatus(instanceId)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load n8n" },
      { status: 502 },
    );
  }
}
