import { NextResponse } from "next/server";
import { navidromeCover } from "@/lib/widgets/navidrome";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const instance = url.searchParams.get("instance") || "navidrome";
    const id = url.searchParams.get("id") || "";
    const size = Number(url.searchParams.get("size") || "200") || 200;
    const response = await navidromeCover(instance, id, size);
    return new Response(response.body, {
      headers: {
        "Content-Type": response.headers.get("content-type") || "image/jpeg",
        "Cache-Control": "private, max-age=600",
      },
    });
  } catch {
    return new NextResponse(null, { status: 404 });
  }
}
