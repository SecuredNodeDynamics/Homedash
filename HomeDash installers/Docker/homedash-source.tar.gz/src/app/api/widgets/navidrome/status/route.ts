import { NextResponse } from "next/server";
import { navidromeStatus } from "@/lib/widgets/navidrome";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const instance = url.searchParams.get("instance") || "navidrome";
    const tab = url.searchParams.get("tab");
    return NextResponse.json(
      await cachedStatus(`navidrome:${instance}:${tab || ""}`, 45_000, () =>
        navidromeStatus(instance, tab),
      ),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load Navidrome" },
      { status: 502 },
    );
  }
}
