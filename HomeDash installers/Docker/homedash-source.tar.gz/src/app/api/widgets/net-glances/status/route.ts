import { NextResponse } from "next/server";
import { fetchNetGlancesStatus } from "@/lib/widgets/net-glances";
import { cachedStatus } from "@/lib/status-cache";

const INTERVALS = new Set([900, 3600, 21600, 86400]);

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const instanceId = searchParams.get("instance") || "net-glances";
  const requested = Number(searchParams.get("interval"));
  const interval = INTERVALS.has(requested) ? requested : 3600;

  try {
    return NextResponse.json(
      await cachedStatus(`net-glances:${instanceId}:${interval}`, 30_000, () =>
        fetchNetGlancesStatus(instanceId, interval),
      ),
    );
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to load Glances" },
      { status: 502 },
    );
  }
}
