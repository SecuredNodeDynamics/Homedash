import { NextRequest, NextResponse } from "next/server";
import {
  clearNameOverride,
  exportNameOverrides,
  importNameOverrides,
  MAX_NAME_LENGTH,
  setNameOverride,
} from "@/lib/net-scan/name-overrides";

/** Exports every saved name override for one widget instance, for backup/restore. */
export async function GET(req: NextRequest) {
  const instanceId = req.nextUrl.searchParams.get("instance");
  if (!instanceId) {
    return NextResponse.json({ error: "instance is required" }, { status: 400 });
  }

  try {
    const overrides = await exportNameOverrides(instanceId);
    return NextResponse.json({ instanceId, overrides, exportedAt: new Date().toISOString() });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Could not export names";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

/** Saves (or replaces) the friendly name for one device on one widget instance. */
export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const { instanceId, key, name } = (body ?? {}) as Record<string, unknown>;
  if (typeof instanceId !== "string" || !instanceId) {
    return NextResponse.json({ error: "instanceId is required" }, { status: 400 });
  }
  if (typeof key !== "string" || !key) {
    return NextResponse.json({ error: "key (device MAC or IP) is required" }, { status: 400 });
  }
  if (typeof name !== "string" || !name.trim()) {
    return NextResponse.json({ error: "name is required" }, { status: 400 });
  }

  try {
    const overrides = await setNameOverride(instanceId, key, name.trim().slice(0, MAX_NAME_LENGTH));
    return NextResponse.json({ ok: true, overrides });
  } catch (err) {
    // "Invalid instance id" means the caller sent something storePath()
    // rejects (bad shape / traversal attempt) — that's genuinely a bad
    // request, 400. Anything else (fs permissions, disk full, etc.) is a
    // server-side problem, so it gets a 500 and its real message instead
    // of being flattened into the same generic 400 as a bad instanceId.
    const message = err instanceof Error ? err.message : "Could not save name";
    const status = message === "Invalid instance id" ? 400 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}

/** Clears a saved name override, letting the device fall back to its scanned/detected name. */
export async function DELETE(req: NextRequest) {
  const instanceId = req.nextUrl.searchParams.get("instance");
  const key = req.nextUrl.searchParams.get("key");
  if (!instanceId || !key) {
    return NextResponse.json({ error: "instance and key are required" }, { status: 400 });
  }

  try {
    const overrides = await clearNameOverride(instanceId, key);
    return NextResponse.json({ ok: true, overrides });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Could not clear name";
    const status = message === "Invalid instance id" ? 400 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}

/**
 * Bulk-imports name overrides, e.g. restoring a file saved by GET above
 * after the store's data directory got wiped (see name-overrides.ts's
 * top-of-file comment on the temp-dir fallback). Body: { instanceId,
 * overrides: Record<string, string>, mode?: "merge" | "replace" }.
 * `mode` defaults to "merge" so restoring a backup can't silently drop
 * names saved after the backup was taken; pass "replace" to make the
 * imported file the new source of truth instead.
 */
export async function PUT(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const { instanceId, overrides, mode } = (body ?? {}) as Record<string, unknown>;
  if (typeof instanceId !== "string" || !instanceId) {
    return NextResponse.json({ error: "instanceId is required" }, { status: 400 });
  }
  if (!overrides || typeof overrides !== "object" || Array.isArray(overrides)) {
    return NextResponse.json({ error: "overrides must be an object mapping device key to name" }, { status: 400 });
  }
  const importMode = mode === "replace" ? "replace" : "merge";

  try {
    const result = await importNameOverrides(instanceId, overrides as Record<string, unknown>, importMode);
    return NextResponse.json({ ok: true, ...result });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Could not import names";
    const status = message === "Invalid instance id" ? 400 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}
