import { NextRequest, NextResponse } from "next/server";
import { deleteOverride, readOverrides, upsertOverride, type HostOverride } from "@/lib/net-scan/overrides";

function isNonEmptyString(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0;
}

/** GET: list all persisted manual overrides (used by the widget's edit UI to pre-fill a form). */
export async function GET() {
  const overrides = await readOverrides();
  return NextResponse.json({ overrides });
}

/** PUT: add a new override or update an existing one (matched by ip, else by name). */
export async function PUT(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Request body must be JSON" }, { status: 400 });
  }
  if (!body || typeof body !== "object") {
    return NextResponse.json({ error: "Request body must be a JSON object" }, { status: 400 });
  }

  const input = body as Record<string, unknown>;
  if (!isNonEmptyString(input.ip) && !isNonEmptyString(input.name)) {
    return NextResponse.json({ error: "Provide at least a name or an ip" }, { status: 400 });
  }

  const entry: HostOverride = {};
  for (const field of ["ip", "name", "role", "mac", "icon", "localUrl", "tunnelUrl"] as const) {
    if (isNonEmptyString(input[field])) entry[field] = (input[field] as string).trim();
  }

  try {
    const overrides = await upsertOverride(entry);
    return NextResponse.json({ overrides });
  } catch (reason) {
    return NextResponse.json(
      { error: reason instanceof Error ? reason.message : "Failed to save override" },
      { status: 500 },
    );
  }
}

/** DELETE: remove an override by ?ip= or ?name= (reverts a scanned host to auto-discovered, or drops a manual-only entry). */
export async function DELETE(req: NextRequest) {
  const ip = req.nextUrl.searchParams.get("ip") || undefined;
  const name = req.nextUrl.searchParams.get("name") || undefined;
  if (!ip && !name) {
    return NextResponse.json({ error: "Provide ?ip= or ?name= to identify the override" }, { status: 400 });
  }

  const overrides = await deleteOverride({ ip: ip || undefined, name: name || undefined });
  return NextResponse.json({ overrides });
}
