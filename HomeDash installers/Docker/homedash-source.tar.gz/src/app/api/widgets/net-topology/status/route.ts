import { NextRequest, NextResponse } from "next/server";
import { getScan } from "@/lib/net-scan/scan";
import { getNameOverrides, hostKey } from "@/lib/net-scan/name-overrides";
import { getSubnetOverride } from "@/lib/net-scan/subnet-config";

type HostOverride = {
  name?: string;
  role?: string;
  ip?: string;
  mac?: string;
  icon?: string;
  localUrl?: string;
  tunnelUrl?: string;
};

type ResponseHost = {
  name: string;
  role?: string;
  ip?: string;
  mac?: string;
  icon?: string;
  localUrl?: string;
  tunnelUrl?: string;
  source: "scan" | "manual";
  // True when `name` came from a saved in-widget name edit rather than the
  // scan's resolved hostname or a "hosts" JSON override. Independent of
  // `source`, since a scanned host can still have a user-edited name.
  nameEdited?: boolean;
};

function parseOverrides(raw: string | undefined): HostOverride[] {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export async function GET(req: NextRequest) {
  // The subnet to scan no longer depends on the host platform passing a
  // widget-settings value through at all. Precedence: an explicit
  // ?subnet= query param (handy for direct API testing) wins first; then
  // the value saved via the widget's own subnet-settings popup (see
  // lib/net-scan/subnet-config.ts), which is what the shipped widget UI
  // actually sets; then getScan()'s own NET_TOPOLOGY_SUBNET / auto-detect
  // fallback.
  const overrides = parseOverrides(req.nextUrl.searchParams.get("hosts") ?? undefined);
  const queryStringSubnet = req.nextUrl.searchParams.get("subnet") || undefined;
  const instanceId = req.nextUrl.searchParams.get("instance") || "net-topology";

  const [savedSubnet, names] = await Promise.all([
    getSubnetOverride(instanceId),
    getNameOverrides(instanceId),
  ]);

  const subnetOverride = queryStringSubnet || savedSubnet;
  const subnetSource = queryStringSubnet ? "override" : savedSubnet ? "saved-override" : undefined;

  const scan = await getScan({ subnet: subnetOverride, subnetSource });

  const overrideByIp = new Map(overrides.filter((o) => o.ip).map((o) => [o.ip as string, o]));

  const scannedHosts: ResponseHost[] = scan.hosts.map((h) => {
    const override = overrideByIp.get(h.ip);
    // A saved in-widget name edit wins over both the scan's resolved
    // hostname and the (legacy, best-effort) "hosts" JSON override — it's
    // the most direct, most recent thing the user did about this device's
    // name. Everything else about the "hosts" override (role/icon/urls)
    // still applies as before.
    const key = hostKey({ mac: override?.mac || h.mac, ip: h.ip });
    const savedName = key ? names[key] : undefined;
    return {
      ip: h.ip,
      mac: override?.mac || h.mac,
      name: savedName || override?.name || h.name,
      role: override?.role,
      icon: override?.icon,
      localUrl: override?.localUrl || `http://${h.ip}`,
      tunnelUrl: override?.tunnelUrl,
      source: override ? "manual" : "scan",
      nameEdited: Boolean(savedName),
    };
  });

  // Overrides for devices that weren't picked up by the scan (e.g. offline,
  // or a manually-added service that isn't a discrete LAN host) still show up.
  const scannedIps = new Set(scan.hosts.map((h) => h.ip));
  const manualOnly: ResponseHost[] = overrides
    .filter((o) => !o.ip || !scannedIps.has(o.ip))
    .map((o) => {
      const key = hostKey({ mac: o.mac, ip: o.ip });
      const savedName = key ? names[key] : undefined;
      return {
        name: savedName || o.name || o.ip || "Unnamed host",
        role: o.role,
        ip: o.ip,
        mac: o.mac,
        icon: o.icon,
        localUrl: o.localUrl,
        tunnelUrl: o.tunnelUrl,
        source: "manual",
        nameEdited: Boolean(savedName),
      };
    });

  return NextResponse.json({
    subnet: scan.subnet,
    // Exposed so the widget can show *why* this subnet was picked — in
    // particular, distinguishing "your ?subnet= override actually arrived"
    // (source: "override") from "nothing arrived, so we fell back to
    // auto-detection and landed on what looks like Docker's own bridge
    // network" (source: "detected-docker-range"). See scan.ts.
    subnetSource: scan.subnetSource,
    subnetWarning: scan.subnetWarning,
    hosts: [...scannedHosts, ...manualOnly],
    scannedAt: scan.scannedAt,
  });
}

export async function POST(req: NextRequest) {
  // Manual rescan trigger (e.g. a "Rescan" button in the widget). Must
  // apply the same subnet precedence as GET so a forced rescan targets
  // the same resolved subnet (query param / saved widget setting / env /
  // auto-detect).
  const queryStringSubnet = req.nextUrl.searchParams.get("subnet") || undefined;
  const instanceId = req.nextUrl.searchParams.get("instance") || "net-topology";
  const savedSubnet = queryStringSubnet ? undefined : await getSubnetOverride(instanceId);
  const subnetOverride = queryStringSubnet || savedSubnet;
  const subnetSource = queryStringSubnet ? "override" : savedSubnet ? "saved-override" : undefined;

  const scan = await getScan({ force: true, subnet: subnetOverride, subnetSource });
  return NextResponse.json({
    scannedAt: scan.scannedAt,
    count: scan.hosts.length,
    subnet: scan.subnet,
    subnetSource: scan.subnetSource,
    subnetWarning: scan.subnetWarning,
  });
}
