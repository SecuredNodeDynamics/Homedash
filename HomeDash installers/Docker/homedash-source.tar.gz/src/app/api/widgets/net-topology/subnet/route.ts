import { NextRequest, NextResponse } from "next/server";
import { clearSubnetOverride, getSubnetOverride, setSubnetOverride } from "@/lib/net-scan/subnet-config";

/** Reads the saved subnet override for one widget instance, if any (null when unset). */
export async function GET(req: NextRequest) {
  const instanceId = req.nextUrl.searchParams.get("instance");
  if (!instanceId) {
    return NextResponse.json({ error: "instance is required" }, { status: 400 });
  }

  try {
    const subnet = await getSubnetOverride(instanceId);
    return NextResponse.json({ instanceId, subnet: subnet ?? null });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Could not read subnet setting";
    const status = message === "Invalid instance id" ? 400 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}

/** Saves the subnet override for one widget instance. Body: { instanceId, subnet }. */
export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const { instanceId, subnet } = (body ?? {}) as Record<string, unknown>;
  if (typeof instanceId !== "string" || !instanceId) {
    return NextResponse.json({ error: "instanceId is required" }, { status: 400 });
  }
  if (typeof subnet !== "string" || !subnet.trim()) {
    return NextResponse.json({ error: "subnet is required" }, { status: 400 });
  }

  try {
    const saved = await setSubnetOverride(instanceId, subnet);
    return NextResponse.json({ ok: true, subnet: saved });
  } catch (err) {
    // "Invalid instance id" and the CIDR-validation error are both genuine
    // bad requests (400); anything else (fs permissions, disk full) is a
    // server-side problem and keeps its own message with a 500.
    const message = err instanceof Error ? err.message : "Could not save subnet setting";
    const status = message === "Invalid instance id" || message.startsWith("Subnet must be") ? 400 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}

/** Clears the saved subnet override, letting resolution fall back to NET_TOPOLOGY_SUBNET / auto-detection. */
export async function DELETE(req: NextRequest) {
  const instanceId = req.nextUrl.searchParams.get("instance");
  if (!instanceId) {
    return NextResponse.json({ error: "instance is required" }, { status: 400 });
  }

  try {
    await clearSubnetOverride(instanceId);
    return NextResponse.json({ ok: true });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Could not clear subnet setting";
    const status = message === "Invalid instance id" ? 400 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}
