import { NextResponse } from "next/server";
import { nextcloudAction } from "@/lib/widgets/nextcloud";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      instance?: string;
      op?: string;
      action?: string;
      payload?: Record<string, unknown>;
      [key: string]: unknown;
    };
    const instanceId = body.instance || "nextcloud";
    const op = String(body.op || body.action || "");
    if (!op) return NextResponse.json({ error: "op required" }, { status: 400 });
    const { instance: _i, op: _o, action: _a, payload, ...rest } = body;
    return NextResponse.json(await nextcloudAction(instanceId, op, { ...(payload || {}), ...rest }));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Action failed" },
      { status: 502 },
    );
  }
}
