import { NextResponse } from "next/server";
import { nextcloudStatus } from "@/lib/widgets/nextcloud";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const instance = url.searchParams.get("instance") || "nextcloud";
    const tab = url.searchParams.get("tab") || "overview";
    const filesMode = url.searchParams.get("filesMode") || undefined;
    const filesPath = url.searchParams.get("filesPath") || undefined;
    const talkRoom = url.searchParams.get("talkRoom") || undefined;
    const contactsQuery = url.searchParams.get("contactsQuery") || undefined;
    const ttlMs = talkRoom ? 2_000 : 30_000;
    return NextResponse.json(
      await cachedStatus(
        `nextcloud:${instance}:${tab}:${filesMode || ""}:${filesPath || ""}:${talkRoom || ""}:${contactsQuery || ""}`,
        ttlMs,
        () =>
          nextcloudStatus(instance, {
            tab,
            filesMode,
            filesPath,
            talkRoom,
            contactsQuery,
          }),
      ),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load Nextcloud" },
      { status: 502 },
    );
  }
}
