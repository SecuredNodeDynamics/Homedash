import { NextResponse } from "next/server";
import { pagespeedRunTest } from "@/lib/widgets/pagespeed";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      instance?: string;
      action?: string;
      url?: string;
      strategy?: "mobile" | "desktop";
    };
    const instanceId = body.instance || "pagespeed";
    const action = body.action || "";

    if (action === "run-test") {
      if (!body.url) return NextResponse.json({ error: "url required" }, { status: 400 });
      return NextResponse.json(
        await pagespeedRunTest(instanceId, body.url, body.strategy === "desktop" ? "desktop" : "mobile"),
      );
    }

    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "PageSpeed test failed" },
      { status: 502 },
    );
  }
}
