import { NextResponse } from "next/server";
import { pagespeedDefaults } from "@/lib/widgets/pagespeed";

export async function GET(request: Request) {
  try {
    const instanceId = new URL(request.url).searchParams.get("instance") || "pagespeed";
    return NextResponse.json(await pagespeedDefaults(instanceId));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load PageSpeed config" },
      { status: 502 },
    );
  }
}
