import { NextResponse } from "next/server";
import { setPiholeBlocking } from "@/lib/widgets/pihole";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const instanceId = String(body.instance || "pihole");
    const enabled = Boolean(body.enabled);
    const seconds = Number(body.seconds || 0);
    await setPiholeBlocking(instanceId, enabled, seconds);
    return NextResponse.json({ ok: true });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to update blocking" },
      { status: 502 },
    );
  }
}
