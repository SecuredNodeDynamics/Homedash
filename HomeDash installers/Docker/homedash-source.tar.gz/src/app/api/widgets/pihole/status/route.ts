import { NextResponse } from "next/server";
import { fetchPiholeStatus } from "@/lib/widgets/pihole";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const instanceId = searchParams.get("instance") || "pihole";
  try {
    const data = await cachedStatus(`pihole:${instanceId}`, 15_000, () =>
      fetchPiholeStatus(instanceId),
    );
    return NextResponse.json(data);
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to load Pi-hole" },
      { status: 502 },
    );
  }
}
