import { NextResponse } from "next/server";
import { plexSliderImage } from "@/lib/widgets/plex-slider";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const instanceId = url.searchParams.get("instance") || "plex-slider";
    const path = url.searchParams.get("path") || url.searchParams.get("url") || "";
    const w = Number(url.searchParams.get("w") || url.searchParams.get("width") || 320);
    const h = Number(url.searchParams.get("h") || url.searchParams.get("height") || 480);
    const direct = url.searchParams.get("direct") === "1";
    const response = await plexSliderImage(instanceId, path, w, h, direct);
    return new Response(response.body, {
      headers: {
        "Content-Type": response.headers.get("content-type") || "image/jpeg",
        "Cache-Control": "private, max-age=300",
      },
    });
  } catch {
    return new NextResponse(null, { status: 404 });
  }
}
