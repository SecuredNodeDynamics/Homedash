import { NextResponse } from "next/server";
import { plexSliderItems } from "@/lib/widgets/plex-slider";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const instanceId = searchParams.get("instance") || "plex-slider";
    const sectionKey = searchParams.get("section") || searchParams.get("sectionKey") || "";
    const limit = searchParams.get("limit");
    return NextResponse.json(
      await plexSliderItems(instanceId, {
        sectionKey,
        limit: limit ? Number(limit) : undefined,
      }),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load items" },
      { status: 502 },
    );
  }
}
