import { NextResponse } from "next/server";
import { plexSliderSearch } from "@/lib/widgets/plex-slider";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const instanceId = searchParams.get("instance") || "plex-slider";
    const q = searchParams.get("q") || "";
    if (!q.trim()) return NextResponse.json({ items: [] });
    return NextResponse.json(await plexSliderSearch(instanceId, q.trim()));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Search failed" },
      { status: 502 },
    );
  }
}
