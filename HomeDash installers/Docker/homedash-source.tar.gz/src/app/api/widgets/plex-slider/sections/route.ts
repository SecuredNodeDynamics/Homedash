import { NextResponse } from "next/server";
import { plexSliderSections } from "@/lib/widgets/plex-slider";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const instanceId = searchParams.get("instance") || "plex-slider";
    return NextResponse.json(await plexSliderSections(instanceId));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load sections" },
      { status: 502 },
    );
  }
}
