import { NextResponse } from "next/server";
import { plexRefresh } from "@/lib/widgets/plex";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      instance?: string;
      action?: string;
      sectionKey?: string;
    };
    const instanceId = body.instance || "plex";
    const action = body.action || "refresh";

    if (action === "refresh" || action === "refresh-all" || action === "refresh-section") {
      const sectionKey =
        action === "refresh-all" ? undefined : body.sectionKey || undefined;
      if (action === "refresh-section" && !sectionKey) {
        return NextResponse.json({ error: "sectionKey required" }, { status: 400 });
      }
      return NextResponse.json(await plexRefresh(instanceId, sectionKey));
    }

    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Action failed" },
      { status: 502 },
    );
  }
}
