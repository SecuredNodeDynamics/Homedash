import { NextResponse } from "next/server";
import { plexArt } from "@/lib/widgets/plex";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const instance = url.searchParams.get("instance") || "plex";
    const path = url.searchParams.get("path") || "";
    const response = await plexArt(instance, path);
    return new Response(response.body, {
      headers: {
        "Content-Type": response.headers.get("content-type") || "image/jpeg",
        "Cache-Control": "private, max-age=300",
      },
    });
  } catch {
    return new NextResponse(null, { status: 404 });
  }
}
