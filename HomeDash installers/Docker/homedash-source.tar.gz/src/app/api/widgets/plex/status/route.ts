import { NextResponse } from "next/server";
import { plexStatus } from "@/lib/widgets/plex";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "plex";
    return NextResponse.json(
      await cachedStatus(`plex:${instance}`, 30_000, () => plexStatus(instance)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load" },
      { status: 502 },
    );
  }
}
