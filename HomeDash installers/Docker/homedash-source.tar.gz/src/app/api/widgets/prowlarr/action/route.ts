import { NextResponse } from "next/server";
import { prowlarrSync } from "@/lib/widgets/arr";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { instance?: string };
    const instance = body.instance || "prowlarr";
    return NextResponse.json(await prowlarrSync(instance));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Sync failed" },
      { status: 502 },
    );
  }
}
