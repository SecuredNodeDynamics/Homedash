import { NextResponse } from "next/server";
import {
  prowlarrIndexerAction,
  prowlarrIndexerDetails,
  type ProwlarrIndexerAction,
} from "@/lib/widgets/arr";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const instance = url.searchParams.get("instance") || "prowlarr";
    const indexerId = Number(url.searchParams.get("indexerId"));
    return NextResponse.json(await prowlarrIndexerDetails(instance, indexerId));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load indexer" },
      { status: 500 },
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      instance?: string;
      indexerId?: number;
      action?: ProwlarrIndexerAction;
      indexer?: Record<string, unknown>;
    };
    const action = body.action;
    if (!action || !["test", "update", "delete"].includes(action)) {
      return NextResponse.json({ error: "Invalid indexer action" }, { status: 400 });
    }
    return NextResponse.json(
      await prowlarrIndexerAction(
        body.instance || "prowlarr",
        Number(body.indexerId),
        action,
        body.indexer,
      ),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Indexer action failed" },
      { status: 500 },
    );
  }
}
