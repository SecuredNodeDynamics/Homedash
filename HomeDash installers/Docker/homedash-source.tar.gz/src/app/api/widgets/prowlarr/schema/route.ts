import { NextResponse } from "next/server";
import {
  prowlarrIndexerSchemaAction,
  prowlarrIndexerSchemaDetails,
  prowlarrIndexerSchemas,
  type ProwlarrSchemaAction,
} from "@/lib/widgets/arr";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const instance = url.searchParams.get("instance") || "prowlarr";
    const definitionName = url.searchParams.get("definitionName");
    if (definitionName) {
      return NextResponse.json(await prowlarrIndexerSchemaDetails(instance, definitionName));
    }
    return NextResponse.json(await prowlarrIndexerSchemas(instance));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load indexer catalog" },
      { status: 500 },
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      instance?: string;
      action?: ProwlarrSchemaAction;
      indexer?: Record<string, unknown>;
    };
    const action = body.action;
    if (!action || !["test", "create"].includes(action)) {
      return NextResponse.json({ error: "Invalid action" }, { status: 400 });
    }
    if (!body.indexer || typeof body.indexer !== "object") {
      return NextResponse.json({ error: "Indexer configuration is required" }, { status: 400 });
    }
    return NextResponse.json(
      await prowlarrIndexerSchemaAction(body.instance || "prowlarr", action, body.indexer),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Indexer action failed" },
      { status: 500 },
    );
  }
}
