import { NextResponse } from "next/server";
import { prowlarrStatus } from "@/lib/widgets/arr";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "prowlarr";
    // No outer response cache: soft-timeout may return statsPending, and the
    // expensive indexerstats call is cached separately for 5 minutes.
    return NextResponse.json(await prowlarrStatus(instance));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load Prowlarr" },
      { status: 502 },
    );
  }
}
