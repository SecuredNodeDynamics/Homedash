import { NextResponse } from "next/server";
import { runGuestAction, type GuestAction } from "@/lib/widgets/proxmox";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      instance?: string;
      type?: string;
      vmid?: number;
      action?: GuestAction;
    };
    const instanceId = body.instance || "proxmox-nodes";
    const type = body.type || "qemu";
    const vmid = Number(body.vmid || 0);
    const action = body.action;
    if (!action) {
      return NextResponse.json({ error: "action required" }, { status: 400 });
    }
    const noVmidActions = ["delete-backup", "create-backup-job", "update-backup-job", "delete-backup-job"];
    if (!vmid && !noVmidActions.includes(action)) {
      return NextResponse.json({ error: "vmid required" }, { status: 400 });
    }
    return NextResponse.json(await runGuestAction(instanceId, type, vmid, action, body));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Guest action failed" },
      { status: 502 },
    );
  }
}
