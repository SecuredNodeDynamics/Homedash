import { NextResponse } from "next/server";
import { fetchGuestDetails } from "@/lib/widgets/proxmox";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const instanceId = searchParams.get("instance") || "proxmox-nodes";
  const type = searchParams.get("type") || "qemu";
  const vmid = Number(searchParams.get("vmid") || 0);
  if (!vmid) return NextResponse.json({ error: "vmid required" }, { status: 400 });
  try {
    return NextResponse.json(await fetchGuestDetails(instanceId, type, vmid));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load guest" },
      { status: 502 },
    );
  }
}
