import { NextResponse } from "next/server";
import {
  deleteLynisReport,
  fetchDiskSmart,
  fetchDiskTempHistory,
  proxmenuxProxy,
  runDiskSmartTest,
  runLynisScan,
} from "@/lib/widgets/proxmox";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const instanceId = searchParams.get("instance") || "proxmox-nodes";
  const path = searchParams.get("path");
  const disk = searchParams.get("disk");
  const kind = searchParams.get("kind");

  try {
    if (kind === "smart" && disk) {
      return NextResponse.json(await fetchDiskSmart(instanceId, disk));
    }
    if (kind === "temp" && disk) {
      return NextResponse.json(
        await fetchDiskTempHistory(instanceId, disk, searchParams.get("timeframe") || "hour"),
      );
    }
    if (!path || !path.startsWith("/api/")) {
      return NextResponse.json({ error: "path must start with /api/" }, { status: 400 });
    }
    return NextResponse.json(await proxmenuxProxy(instanceId, path));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "ProxMenux request failed" },
      { status: 502 },
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      instance?: string;
      kind?: string;
      disk?: string;
      testType?: "short" | "long";
      path?: string;
      body?: unknown;
    };
    const instanceId = body.instance || "proxmox-nodes";
    if (body.kind === "lynis-run") {
      return NextResponse.json(await runLynisScan(instanceId));
    }
    if (body.kind === "smart-test" && body.disk) {
      return NextResponse.json(await runDiskSmartTest(instanceId, body.disk, body.testType || "short"));
    }
    if (body.path?.startsWith("/api/")) {
      return NextResponse.json(
        await proxmenuxProxy(instanceId, body.path, { method: "POST", body: body.body ?? {} }),
      );
    }
    return NextResponse.json({ error: "Unsupported ProxMenux action" }, { status: 400 });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "ProxMenux action failed" },
      { status: 502 },
    );
  }
}

export async function DELETE(request: Request) {
  try {
    const body = (await request.json()) as { instance?: string; kind?: string; path?: string };
    const instanceId = body.instance || "proxmox-nodes";
    if (body.kind === "lynis-report") {
      return NextResponse.json(await deleteLynisReport(instanceId));
    }
    if (body.path?.startsWith("/api/")) {
      return NextResponse.json(await proxmenuxProxy(instanceId, body.path, { method: "DELETE" }));
    }
    return NextResponse.json({ error: "Unsupported delete" }, { status: 400 });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "ProxMenux delete failed" },
      { status: 502 },
    );
  }
}
