import { NextResponse } from "next/server";
import { fetchProxmoxStatus } from "@/lib/widgets/proxmox";
import { cachedStatus } from "@/lib/status-cache";

// Last full payload per instance. If Proxmox is briefly unreachable we keep serving
// this (flagged stale) instead of a 502, so widgets don't blank out on a hiccup.
const lastPayload = new Map<string, { at: number; payload: Record<string, unknown> }>();
const STALE_MAX_MS = 10 * 60_000;

export async function GET(request: Request) {
  const instanceId = new URL(request.url).searchParams.get("instance") || "proxmox-nodes";
  try {
    const payload = (await cachedStatus(`proxmox-nodes:${instanceId}`, 15_000, () =>
      fetchProxmoxStatus(instanceId),
    )) as unknown as Record<string, unknown>;
    lastPayload.set(instanceId, { at: Date.now(), payload });
    return NextResponse.json(payload);
  } catch (error) {
    const prev = lastPayload.get(instanceId);
    if (prev && Date.now() - prev.at < STALE_MAX_MS) {
      return NextResponse.json({ ...prev.payload, stale: true });
    }
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load Proxmox" },
      { status: 502 },
    );
  }
}
