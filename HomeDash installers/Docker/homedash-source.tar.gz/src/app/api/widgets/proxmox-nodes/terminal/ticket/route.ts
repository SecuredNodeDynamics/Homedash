import { NextResponse } from "next/server";
import { issuePrxTerminalTicket, loadProxmoxConfig } from "@/lib/widgets/proxmox";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      instance?: string;
      mode?: "host" | "guest";
      type?: string;
      vmid?: number;
    };
    const instanceId = body.instance || "proxmox-nodes";
    const cfg = await loadProxmoxConfig(instanceId);
    const ticket = await issuePrxTerminalTicket(cfg);
    return NextResponse.json({
      ...ticket,
      mode: body.mode || "host",
      type: body.type,
      vmid: body.vmid,
      enterCmd:
        body.mode === "guest" && (body.type === "lxc" || body.type === "ct") && body.vmid
          ? `pct enter ${body.vmid}\r`
          : null,
      prxHref: cfg.prxFallbackUrl || cfg.prxUrl || null,
    });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Terminal ticket failed" },
      { status: 502 },
    );
  }
}
