import { NextResponse } from "next/server";
import { qbitAction, qbitAddTorrent } from "@/lib/widgets/qbit";

const actions = new Set(["resume", "pause", "recheck", "delete"]);
const stopConditions = new Set(["None", "MetadataReceived", "FilesChecked"]);
const contentLayouts = new Set(["Original", "Subfolder", "NoSubfolder"]);

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const action = String(body.action || "");

    if (action === "add") {
      const urls = String(body.urls || "").trim();
      if (!urls) {
        return NextResponse.json({ error: "Add at least one torrent link" }, { status: 400 });
      }
      await qbitAddTorrent(String(body.instance || "qbit"), {
        urls,
        autoTMM: Boolean(body.autoTMM),
        savepath: body.savepath ? String(body.savepath) : undefined,
        rename: body.rename ? String(body.rename) : undefined,
        category: body.category ? String(body.category) : undefined,
        startTorrent: body.startTorrent !== false,
        addToTopOfQueue: Boolean(body.addToTopOfQueue),
        stopCondition: stopConditions.has(body.stopCondition) ? body.stopCondition : "None",
        skipChecking: Boolean(body.skipChecking),
        contentLayout: contentLayouts.has(body.contentLayout) ? body.contentLayout : "Original",
        sequentialDownload: Boolean(body.sequentialDownload),
        firstLastPiecePrio: Boolean(body.firstLastPiecePrio),
        dlLimitKib: body.dlLimitKib ? Number(body.dlLimitKib) : undefined,
        upLimitKib: body.upLimitKib ? Number(body.upLimitKib) : undefined,
      });
      return NextResponse.json({ ok: true });
    }

    const hashes = String(body.hashes || "");
    if (!actions.has(action) || !hashes) {
      return NextResponse.json({ error: "Invalid qBittorrent action" }, { status: 400 });
    }
    await qbitAction(String(body.instance || "qbit"), action, hashes, Boolean(body.deleteFiles));
    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to update qBittorrent" },
      { status: 502 },
    );
  }
}
