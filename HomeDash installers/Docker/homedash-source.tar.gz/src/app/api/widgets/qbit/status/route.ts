import { NextResponse } from "next/server";
import { fetchQbitStatus } from "@/lib/widgets/qbit";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  const instanceId = new URL(request.url).searchParams.get("instance") || "qbit";
  try {
    return NextResponse.json(
      await cachedStatus(`qbit:${instanceId}`, 7_500, () => fetchQbitStatus(instanceId)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load qBittorrent" },
      { status: 502 },
    );
  }
}
