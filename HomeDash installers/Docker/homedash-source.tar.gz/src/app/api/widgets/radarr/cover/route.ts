import { NextResponse } from "next/server";
import { arrCover } from "@/lib/widgets/arr";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const instanceId = url.searchParams.get("instance") || "radarr";
    const path = url.searchParams.get("path") || "";
    const response = await arrCover(instanceId, path);
    return new Response(response.body, {
      headers: {
        "Content-Type": response.headers.get("content-type") || "image/jpeg",
        "Cache-Control": "private, max-age=600",
      },
    });
  } catch {
    return new NextResponse(null, { status: 404 });
  }
}
