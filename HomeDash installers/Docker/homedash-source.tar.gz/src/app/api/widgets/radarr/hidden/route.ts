import { NextResponse } from "next/server";
import { listHidden, setHidden } from "@/lib/widgets/arr-hidden";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "radarr";
    return NextResponse.json({ hidden: await listHidden("radarr", instance) });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load hidden list" },
      { status: 500 },
    );
  }
}

export async function POST(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "radarr";
    const body = (await request.json()) as { id?: unknown; title?: unknown; hidden?: unknown };
    const id = typeof body.id === "string" ? body.id.slice(0, 200) : "";
    if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });
    const title = typeof body.title === "string" ? body.title.slice(0, 200) : "";
    return NextResponse.json({ hidden: await setHidden("radarr", instance, id, title, body.hidden !== false) });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to save hidden list" },
      { status: 500 },
    );
  }
}
