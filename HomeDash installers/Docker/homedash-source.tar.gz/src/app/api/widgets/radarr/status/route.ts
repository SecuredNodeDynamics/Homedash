import { NextResponse } from "next/server";
import { arrStatus } from "@/lib/widgets/arr";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "radarr";
    return NextResponse.json(
      await cachedStatus(`radarr:${instance}`, 15_000, () => arrStatus(instance, "radarr")),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load radarr" },
      { status: 502 },
    );
  }
}
