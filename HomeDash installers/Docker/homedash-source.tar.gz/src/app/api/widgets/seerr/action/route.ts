import { NextResponse } from "next/server";
import {
  seerrCreateRequest,
  seerrArrLink,
  seerrDeleteRequest,
  seerrLibraries,
  seerrMediaDetail,
  seerrProcessing,
  seerrRemoveFromArr,
  seerrRetryRequest,
  seerrRequestAction,
  seerrServiceDetail,
  seerrServices,
  seerrSetLibraryEnabled,
  seerrSyncLibraries,
  seerrSyncStatus,
  seerrStartLibraryScan,
  seerrCancelLibraryScan,
} from "@/lib/widgets/seerr";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const instanceId = searchParams.get("instance") || "seerr";
    const kind = searchParams.get("kind") || "";

    if (kind === "media") {
      const mediaType = searchParams.get("type") || "movie";
      const mediaId = Number(searchParams.get("id") || 0);
      if (!mediaId) return NextResponse.json({ error: "id required" }, { status: 400 });
      return NextResponse.json(await seerrMediaDetail(instanceId, mediaType, mediaId));
    }

    if (kind === "arr-link") {
      const requestId = Number(searchParams.get("id") || 0);
      if (!requestId) return NextResponse.json({ error: "id required" }, { status: 400 });
      return NextResponse.json(await seerrArrLink(instanceId, requestId));
    }

    if (kind === "processing") {
      return NextResponse.json(await seerrProcessing(instanceId));
    }

    if (kind === "services") {
      const type = (searchParams.get("type") || "radarr") as "radarr" | "sonarr";
      const id = searchParams.get("id");
      if (id) return NextResponse.json(await seerrServiceDetail(instanceId, type, Number(id)));
      return NextResponse.json(await seerrServices(instanceId, type));
    }

    if (kind === "libraries") {
      return NextResponse.json(await seerrLibraries(instanceId));
    }

    if (kind === "sync-status") {
      return NextResponse.json(await seerrSyncStatus(instanceId));
    }

    return NextResponse.json({ error: "Unknown kind" }, { status: 400 });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Lookup failed" },
      { status: 502 },
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      instance?: string;
      action?: string;
      requestId?: number;
      mediaType?: string;
      mediaId?: number;
      seasons?: number[];
      serverId?: number | null;
      rootFolder?: string | null;
      libraryId?: string;
      enabled?: boolean;
    };
    const instanceId = body.instance || "seerr";
    const action = body.action || "";

    if (action === "approve" || action === "decline") {
      if (!body.requestId) {
        return NextResponse.json({ error: "requestId required" }, { status: 400 });
      }
      return NextResponse.json(await seerrRequestAction(instanceId, body.requestId, action));
    }

    if (action === "delete") {
      if (!body.requestId) {
        return NextResponse.json({ error: "requestId required" }, { status: 400 });
      }
      return NextResponse.json(await seerrDeleteRequest(instanceId, body.requestId));
    }

    if (action === "retry") {
      if (!body.requestId) {
        return NextResponse.json({ error: "requestId required" }, { status: 400 });
      }
      return NextResponse.json(await seerrRetryRequest(instanceId, body.requestId));
    }

    if (action === "remove-arr") {
      if (!body.requestId) {
        return NextResponse.json({ error: "requestId required" }, { status: 400 });
      }
      return NextResponse.json(await seerrRemoveFromArr(instanceId, body.requestId));
    }

    if (action === "request") {
      if (!body.mediaType || !body.mediaId) {
        return NextResponse.json({ error: "mediaType and mediaId required" }, { status: 400 });
      }
      return NextResponse.json(
        await seerrCreateRequest(instanceId, {
          mediaType: body.mediaType,
          mediaId: body.mediaId,
          seasons: body.seasons,
          serverId: body.serverId,
          rootFolder: body.rootFolder,
        }),
      );
    }

    if (action === "sync-libraries") {
      return NextResponse.json(await seerrSyncLibraries(instanceId));
    }

    if (action === "toggle-library") {
      if (!body.libraryId) {
        return NextResponse.json({ error: "libraryId required" }, { status: 400 });
      }
      return NextResponse.json(
        await seerrSetLibraryEnabled(instanceId, body.libraryId, !!body.enabled),
      );
    }

    if (action === "start-scan") {
      return NextResponse.json(await seerrStartLibraryScan(instanceId));
    }

    if (action === "cancel-scan") {
      return NextResponse.json(await seerrCancelLibraryScan(instanceId));
    }

    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Action failed" },
      { status: 502 },
    );
  }
}
