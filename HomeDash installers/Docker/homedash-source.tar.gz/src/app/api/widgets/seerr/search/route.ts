import { NextResponse } from "next/server";
import { seerrSearch } from "@/lib/widgets/seerr";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const instanceId = searchParams.get("instance") || "seerr";
    const q = searchParams.get("q") || "";
    return NextResponse.json(await seerrSearch(instanceId, q));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Search failed" },
      { status: 502 },
    );
  }
}
