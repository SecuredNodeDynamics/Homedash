import { NextResponse } from "next/server";
import { seerrStatus } from "@/lib/widgets/seerr";

export async function GET(request: Request) {
  try {
    const instanceId = new URL(request.url).searchParams.get("instance") || "seerr";
    return NextResponse.json(await seerrStatus(instanceId));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load Seerr" },
      { status: 502 },
    );
  }
}
