import { NextResponse } from "next/server";
import { shelfmarkCover } from "@/lib/widgets/shelfmark";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const instance = url.searchParams.get("instance") || "shelfmark";
    const path = url.searchParams.get("path") || url.searchParams.get("preview") || "";
    const response = await shelfmarkCover(instance, path);
    return new Response(response.body, {
      headers: {
        "Content-Type": response.headers.get("content-type") || "image/jpeg",
        "Cache-Control": "private, max-age=300",
      },
    });
  } catch {
    return new NextResponse(null, { status: 404 });
  }
}
