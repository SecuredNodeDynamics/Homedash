import { NextResponse } from "next/server";
import { shelfmarkStatus } from "@/lib/widgets/shelfmark";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const instance = url.searchParams.get("instance") || "shelfmark";
    const tab = url.searchParams.get("tab") || "overview";
    return NextResponse.json(
      await cachedStatus(`shelfmark:${instance}:${tab}`, 15_000, () =>
        shelfmarkStatus(instance, tab),
      ),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load" },
      { status: 502 },
    );
  }
}
