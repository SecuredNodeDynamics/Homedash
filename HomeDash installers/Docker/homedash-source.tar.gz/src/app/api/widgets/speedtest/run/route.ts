import { NextResponse } from "next/server";
import { runSpeedtest } from "@/lib/widgets/speedtest";
export async function POST(request: Request) {
  try {
    const body = await request.json();
    return NextResponse.json(await runSpeedtest(String(body.instance || "speedtest")));
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "Failed to run Speedtest" }, { status: 502 }); }
}
