import { NextResponse } from "next/server";
import { fetchSpeedtestStatus } from "@/lib/widgets/speedtest";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "speedtest";
    return NextResponse.json(
      await cachedStatus(`speedtest:${instance}`, 60_000, () => fetchSpeedtestStatus(instance)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load Speedtest" },
      { status: 502 },
    );
  }
}
