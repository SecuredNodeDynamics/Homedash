import { NextResponse } from "next/server";
import { fetchGameDetail } from "@/lib/widgets/sports";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const sportPath = url.searchParams.get("sportPath");
    const leaguePath = url.searchParams.get("leaguePath");
    const eventId = url.searchParams.get("eventId");
    const teamA = url.searchParams.get("teamA");
    const teamB = url.searchParams.get("teamB");
    if (!sportPath || !leaguePath || !eventId || !teamA || !teamB) {
      return NextResponse.json(
        { error: "sportPath, leaguePath, eventId, teamA and teamB are required" },
        { status: 400 },
      );
    }
    const detail = await cachedStatus(
      `sports-tracker:game:${sportPath}:${leaguePath}:${eventId}`,
      60_000,
      () => fetchGameDetail(sportPath, leaguePath, eventId, [teamA, teamB]),
    );
    return NextResponse.json(detail);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load game" },
      { status: 502 },
    );
  }
}
