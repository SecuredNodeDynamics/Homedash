import { NextResponse } from "next/server";
import { fetchNews } from "@/lib/widgets/sports";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const sportPath = url.searchParams.get("sportPath");
    const leaguePath = url.searchParams.get("leaguePath");
    if (!sportPath || !leaguePath) {
      return NextResponse.json({ error: "sportPath and leaguePath are required" }, { status: 400 });
    }
    const items = await cachedStatus(`sports-tracker:news:${sportPath}:${leaguePath}`, 5 * 60_000, () =>
      fetchNews(sportPath, leaguePath),
    );
    return NextResponse.json({ items });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load news" },
      { status: 502 },
    );
  }
}
