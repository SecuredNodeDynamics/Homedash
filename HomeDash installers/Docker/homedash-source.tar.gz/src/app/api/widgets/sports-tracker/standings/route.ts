import { NextResponse } from "next/server";
import { fetchStandings } from "@/lib/widgets/sports";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const sportPath = url.searchParams.get("sportPath");
    const leaguePath = url.searchParams.get("leaguePath");
    if (!sportPath || !leaguePath) {
      return NextResponse.json({ error: "sportPath and leaguePath are required" }, { status: 400 });
    }
    const groups = await cachedStatus(`sports-tracker:standings:${sportPath}:${leaguePath}`, 10 * 60_000, () =>
      fetchStandings(sportPath, leaguePath),
    );
    return NextResponse.json({ groups });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load standings" },
      { status: 502 },
    );
  }
}
