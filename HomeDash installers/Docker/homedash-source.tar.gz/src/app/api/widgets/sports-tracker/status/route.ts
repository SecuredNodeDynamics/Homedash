import { NextResponse } from "next/server";
import { sportsStatus } from "@/lib/widgets/sports";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "sports-tracker";
    return NextResponse.json(
      await cachedStatus(`sports-tracker:${instance}`, 30_000, () => sportsStatus()),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load sports data" },
      { status: 502 },
    );
  }
}
