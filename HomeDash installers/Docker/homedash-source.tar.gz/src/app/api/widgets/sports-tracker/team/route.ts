import { NextResponse } from "next/server";
import { TEAM_LEAGUES, fetchTeamDetail, type TeamSport } from "@/lib/widgets/sports";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const sport = url.searchParams.get("sport") as TeamSport | null;
    const league = url.searchParams.get("league");
    const team = url.searchParams.get("team");
    if (!sport || !league || !team || !(sport in TEAM_LEAGUES)) {
      return NextResponse.json({ error: "A valid sport, league and team are required" }, { status: 400 });
    }
    const option = TEAM_LEAGUES[sport].find((entry) => entry.leaguePath === league);
    if (!option) {
      return NextResponse.json({ error: "Unknown league for that sport" }, { status: 400 });
    }
    const detail = await cachedStatus(`sports-tracker:team:${sport}:${league}:${team}`, 60_000, () =>
      fetchTeamDetail(option.sportPath, option.leaguePath, team),
    );
    return NextResponse.json(detail);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load team" },
      { status: 502 },
    );
  }
}
