import { NextResponse } from "next/server";
import { TEAM_LEAGUES, fetchTeams, type TeamSport } from "@/lib/widgets/sports";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const sport = url.searchParams.get("sport") as TeamSport | null;
    const league = url.searchParams.get("league");
    if (!sport || !league || !(sport in TEAM_LEAGUES)) {
      return NextResponse.json({ error: "A valid sport and league are required" }, { status: 400 });
    }
    const option = TEAM_LEAGUES[sport].find((entry) => entry.leaguePath === league);
    if (!option) {
      return NextResponse.json({ error: "Unknown league for that sport" }, { status: 400 });
    }
    // Team lists change rarely (trades/relocations aside) — cache for hours.
    const teams = await cachedStatus(`sports-tracker:teams:${sport}:${league}`, 6 * 60 * 60_000, () =>
      fetchTeams(option.sportPath, option.leaguePath),
    );
    return NextResponse.json({ teams });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load teams" },
      { status: 502 },
    );
  }
}
