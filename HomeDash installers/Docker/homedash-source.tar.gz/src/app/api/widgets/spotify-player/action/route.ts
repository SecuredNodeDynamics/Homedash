import { NextResponse } from "next/server";
import { performSpotifyAction, type SpotifyActionKind } from "@/lib/widgets/spotify";

const VALID_ACTIONS: SpotifyActionKind[] = [
  "play",
  "pause",
  "next",
  "previous",
  "seek",
  "volume",
  "shuffle",
  "repeat",
  "transfer-playback",
  "play-playlist",
  "play-track",
];

export async function POST(request: Request) {
  let body: { instance?: string; action?: string } & Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const instanceId = String(body.instance || "spotify-player");
  const action = body.action as SpotifyActionKind;

  if (!VALID_ACTIONS.includes(action)) {
    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  }

  const { instance: _instance, action: _action, ...payload } = body;

  try {
    const result = await performSpotifyAction(instanceId, action, payload);
    return NextResponse.json({ ok: true, result });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Action failed" },
      { status: 502 },
    );
  }
}
