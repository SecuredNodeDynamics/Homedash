import { NextResponse } from "next/server";
import { fetchSpotifyStatus } from "@/lib/widgets/spotify";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const instanceId = searchParams.get("instance") || "spotify-player";

  try {
    return NextResponse.json(
      await cachedStatus(`spotify-player:${instanceId}`, 8_000, () => fetchSpotifyStatus(instanceId)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load Spotify" },
      { status: 502 },
    );
  }
}
