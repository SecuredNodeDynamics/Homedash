import { NextResponse } from "next/server";
import { fetchTailscaleStatus } from "@/lib/widgets/tailscale";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const instanceId = searchParams.get("instance") || "tailscale";

  try {
    return NextResponse.json(
      await cachedStatus(`tailscale:${instanceId}`, 30_000, () =>
        fetchTailscaleStatus(instanceId),
      ),
    );
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to load Tailscale" },
      { status: 502 },
    );
  }
}
