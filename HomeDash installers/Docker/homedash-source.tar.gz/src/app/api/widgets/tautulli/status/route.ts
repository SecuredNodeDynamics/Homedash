import { NextResponse } from "next/server";
import { tautulliStatus } from "@/lib/widgets/media";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "tautulli";
    return NextResponse.json(
      await cachedStatus(`tautulli:${instance}`, 15_000, () => tautulliStatus(instance)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load" },
      { status: 502 },
    );
  }
}
