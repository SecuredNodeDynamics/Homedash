import { NextResponse } from "next/server";
import { tdarrStatus } from "@/lib/widgets/media";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "tdarr";
    return NextResponse.json(
      await cachedStatus(`tdarr:${instance}`, 30_000, () => tdarrStatus(instance)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load" },
      { status: 502 },
    );
  }
}
