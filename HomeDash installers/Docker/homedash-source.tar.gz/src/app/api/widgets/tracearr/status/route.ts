import { NextResponse } from "next/server";
import { tracearrStatus } from "@/lib/widgets/tracearr";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "tracearr";
    return NextResponse.json(
      await cachedStatus(`tracearr:${instance}`, 30_000, () => tracearrStatus(instance)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load Tracearr" },
      { status: 502 },
    );
  }
}
