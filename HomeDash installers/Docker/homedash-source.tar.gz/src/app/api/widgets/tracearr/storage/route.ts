import { NextResponse } from "next/server";
import { tracearrStorage } from "@/lib/widgets/tracearr";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const instance = url.searchParams.get("instance") || "tracearr";
    const period = url.searchParams.get("period") || "30d";
    return NextResponse.json(await tracearrStorage(instance, period));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load storage" },
      { status: 502 },
    );
  }
}
