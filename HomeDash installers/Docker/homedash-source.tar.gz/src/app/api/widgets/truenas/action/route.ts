import { NextResponse } from "next/server";
import { runTruenasAction } from "@/lib/widgets/truenas";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { instance?: string; action?: string; appId?: string };
    const instanceId = body.instance || "truenas";
    if (!body.action) {
      return NextResponse.json({ error: "action required" }, { status: 400 });
    }
    return NextResponse.json(await runTruenasAction(instanceId, body.action, body.appId));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "TrueNAS action failed" },
      { status: 502 },
    );
  }
}
