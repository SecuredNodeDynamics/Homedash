import { NextResponse } from "next/server";
import { fetchTruenasStatus } from "@/lib/widgets/truenas";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const instance = new URL(request.url).searchParams.get("instance") || "truenas";
    return NextResponse.json(
      await cachedStatus(`truenas:${instance}`, 30_000, () => fetchTruenasStatus(instance)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load TrueNAS" },
      { status: 502 },
    );
  }
}
