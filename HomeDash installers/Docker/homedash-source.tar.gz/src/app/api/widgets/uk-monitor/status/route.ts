import { NextResponse } from "next/server";
import { fetchKumaStatus } from "@/lib/widgets/kuma";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const instanceId = searchParams.get("instance") || "uk-monitor";

  try {
    return NextResponse.json(
      await cachedStatus(`uk-monitor:${instanceId}`, 45_000, () => fetchKumaStatus(instanceId)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load Uptime Kuma" },
      { status: 502 },
    );
  }
}
