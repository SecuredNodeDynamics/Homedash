import { NextResponse } from "next/server";
import {
  fetchVaultwardenMyOrganizations,
  fetchVaultwardenOrgMembers,
  isVaultwardenOrgMemberAction,
  vaultwardenOrgMemberAction,
} from "@/lib/widgets/vaultwarden";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const instanceId = searchParams.get("instance") || "vaultwarden";
  const orgId = searchParams.get("orgId") || "";
  try {
    if (orgId) {
      const members = await fetchVaultwardenOrgMembers(instanceId, orgId);
      return NextResponse.json({ members });
    }
    const organizations = await fetchVaultwardenMyOrganizations(instanceId);
    return NextResponse.json({ organizations });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to load organizations" },
      { status: 502 },
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const instanceId = String(body.instance || "vaultwarden");
    const orgId = String(body.orgId || "");
    const memberId = String(body.memberId || "");
    const action = String(body.action || "");

    if (!orgId) {
      return NextResponse.json({ error: "Missing organization id" }, { status: 400 });
    }
    if (!isVaultwardenOrgMemberAction(action)) {
      return NextResponse.json({ error: "Invalid member action" }, { status: 400 });
    }
    if (!memberId) {
      return NextResponse.json({ error: "Missing member id" }, { status: 400 });
    }

    await vaultwardenOrgMemberAction(instanceId, orgId, memberId, action);
    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to update member" },
      { status: 502 },
    );
  }
}
