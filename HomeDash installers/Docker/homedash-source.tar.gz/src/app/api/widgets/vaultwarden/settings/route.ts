import { NextResponse } from "next/server";
import { fetchVaultwardenConfig, updateVaultwardenConfig } from "@/lib/widgets/vaultwarden";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const instanceId = searchParams.get("instance") || "vaultwarden";
  try {
    const config = await fetchVaultwardenConfig(instanceId);
    return NextResponse.json({ config });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to load config" },
      { status: 502 },
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const instanceId = String(body.instance || "vaultwarden");
    const patch = body.patch && typeof body.patch === "object" ? body.patch : null;
    if (!patch || !Object.keys(patch).length) {
      return NextResponse.json({ error: "Missing config patch" }, { status: 400 });
    }
    const config = await updateVaultwardenConfig(instanceId, patch);
    return NextResponse.json({ ok: true, config });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to update config" },
      { status: 502 },
    );
  }
}
