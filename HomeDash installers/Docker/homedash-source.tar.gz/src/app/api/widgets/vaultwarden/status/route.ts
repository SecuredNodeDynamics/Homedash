import { NextResponse } from "next/server";
import { fetchVaultwardenStatus } from "@/lib/widgets/vaultwarden";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const instanceId = searchParams.get("instance") || "vaultwarden";
  try {
    const data = await cachedStatus(`vaultwarden:${instanceId}`, 30_000, () => fetchVaultwardenStatus(instanceId));
    return NextResponse.json(data);
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to load Vaultwarden" },
      { status: 502 },
    );
  }
}
