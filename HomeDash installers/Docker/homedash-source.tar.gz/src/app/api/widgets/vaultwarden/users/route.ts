import { NextResponse } from "next/server";
import { fetchVaultwardenUsers, isVaultwardenUserAction, vaultwardenUserAction } from "@/lib/widgets/vaultwarden";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const instanceId = searchParams.get("instance") || "vaultwarden";
  try {
    const users = await fetchVaultwardenUsers(instanceId);
    return NextResponse.json({ users });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to load users" },
      { status: 502 },
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const instanceId = String(body.instance || "vaultwarden");
    const userId = String(body.userId || "");
    const action = String(body.action || "");

    if (!isVaultwardenUserAction(action)) {
      return NextResponse.json({ error: "Invalid user action" }, { status: 400 });
    }
    if (!userId) {
      return NextResponse.json({ error: "Missing user id" }, { status: 400 });
    }

    await vaultwardenUserAction(instanceId, userId, action);
    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to update user" },
      { status: 502 },
    );
  }
}
