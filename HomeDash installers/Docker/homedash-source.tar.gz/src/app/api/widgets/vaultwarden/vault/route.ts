import { NextResponse } from "next/server";
import { fetchVaultwardenVaultSummary } from "@/lib/widgets/vaultwarden";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const instanceId = searchParams.get("instance") || "vaultwarden";
  try {
    const summary = await fetchVaultwardenVaultSummary(instanceId);
    return NextResponse.json(summary);
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to load vault summary" },
      { status: 502 },
    );
  }
}
