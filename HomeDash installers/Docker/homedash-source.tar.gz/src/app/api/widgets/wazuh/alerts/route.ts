import { NextResponse } from "next/server";
import { fetchWazuhAlerts } from "@/lib/widgets/wazuh";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const instanceId = searchParams.get("instance") || "wazuh";
  const tab = searchParams.get("tab") || "all";
  const agent = searchParams.get("agent") || "all";
  const range = searchParams.get("range") || "24h";
  let searchAfter: unknown[] | null = null;
  const rawAfter = searchParams.get("searchAfter");
  if (rawAfter) {
    try {
      searchAfter = JSON.parse(rawAfter) as unknown[];
    } catch {
      searchAfter = null;
    }
  }

  try {
    return NextResponse.json(
      await fetchWazuhAlerts(instanceId, { tab, agent, range, searchAfter }),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load alerts" },
      { status: 502 },
    );
  }
}
