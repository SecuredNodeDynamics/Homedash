import { NextResponse } from "next/server";
import { fetchWazuhStatus } from "@/lib/widgets/wazuh";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  const instanceId = new URL(request.url).searchParams.get("instance") || "wazuh";
  try {
    return NextResponse.json(
      await cachedStatus(`wazuh:${instanceId}`, 45_000, () => fetchWazuhStatus(instanceId)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load Wazuh" },
      { status: 502 },
    );
  }
}
