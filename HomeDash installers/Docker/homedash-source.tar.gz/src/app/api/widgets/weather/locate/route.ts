import { NextResponse } from "next/server";
import { reverseGeocode } from "@/lib/widgets/weather";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const latitude = Number(searchParams.get("lat"));
    const longitude = Number(searchParams.get("lon"));
    if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
      return NextResponse.json({ error: "lat and lon are required" }, { status: 400 });
    }
    const place = await reverseGeocode(latitude, longitude);
    return NextResponse.json({ latitude, longitude, place });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Locate failed" },
      { status: 502 },
    );
  }
}
