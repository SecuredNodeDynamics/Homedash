import { NextResponse } from "next/server";
import { fetchWeatherStatus } from "@/lib/widgets/weather";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const instance = searchParams.get("instance") || "weather";
    const lat = searchParams.get("lat");
    const lon = searchParams.get("lon");
    const overrides =
      lat != null && lon != null && lat !== "" && lon !== ""
        ? { latitude: Number(lat), longitude: Number(lon) }
        : undefined;

    return NextResponse.json(
      await cachedStatus(
        `weather:${instance}:${lat || ""}:${lon || ""}`,
        60_000,
        () => fetchWeatherStatus(instance, overrides),
      ),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load weather" },
      { status: 502 },
    );
  }
}
