import { NextResponse } from "next/server";
import { wizarrCreateInvite, wizarrDeleteInvite } from "@/lib/widgets/wizarr";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      instance?: string;
      action?: string;
      id?: string;
      server_ids?: string | number;
      duration?: string;
      allow_downloads?: boolean;
      allow_live_tv?: boolean;
      expires_in_days?: number;
      label?: string;
    };
    const instanceId = body.instance || "wizarr";
    const action = body.action || "";

    if (action === "create") {
      if (body.server_ids == null || body.server_ids === "") {
        return NextResponse.json({ error: "server_ids required" }, { status: 400 });
      }
      return NextResponse.json(
        await wizarrCreateInvite(instanceId, {
          server_ids: body.server_ids,
          duration: body.duration || "unlimited",
          allow_downloads: !!body.allow_downloads,
          allow_live_tv: !!body.allow_live_tv,
          expires_in_days: body.expires_in_days,
          label: body.label,
        }),
      );
    }

    if (action === "delete") {
      if (!body.id) return NextResponse.json({ error: "id required" }, { status: 400 });
      return NextResponse.json(await wizarrDeleteInvite(instanceId, String(body.id)));
    }

    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Action failed" },
      { status: 502 },
    );
  }
}
