import { NextResponse } from "next/server";
import { wizarrStatus } from "@/lib/widgets/wizarr";
import { cachedStatus } from "@/lib/status-cache";

export async function GET(request: Request) {
  try {
    const instanceId = new URL(request.url).searchParams.get("instance") || "wizarr";
    return NextResponse.json(
      await cachedStatus(`wizarr:${instanceId}`, 30_000, () => wizarrStatus(instanceId)),
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to load Wizarr" },
      { status: 502 },
    );
  }
}
