import { NextResponse } from "next/server";
import { youtubeChannelFeed, youtubeSearch } from "@/lib/widgets/youtube";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const instance = url.searchParams.get("instance") || "youtube";
    const q = url.searchParams.get("q") || "";
    const mode = url.searchParams.get("mode") || "search";

    if (mode === "channels") {
      return NextResponse.json(await youtubeChannelFeed(instance));
    }
    return NextResponse.json(await youtubeSearch(instance, q));
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "YouTube request failed" },
      { status: 502 },
    );
  }
}
