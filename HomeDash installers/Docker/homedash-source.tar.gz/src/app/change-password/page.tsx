import { redirect } from "next/navigation";
import { ForcedPasswordChangeForm } from "@/components/ForcedPasswordChangeForm";
import { readSessionFromCookies } from "@/lib/auth/cookies";

export const dynamic = "force-dynamic";
export default async function ChangePasswordPage() {
  const session = await readSessionFromCookies();
  if (!session) redirect("/login");
  if (!session.mustChangePassword) redirect("/");
  return <ForcedPasswordChangeForm />;
}
