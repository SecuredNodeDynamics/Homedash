import type { Metadata } from "next";
import localFont from "next/font/local";
import "./globals.css";
import { readSettings } from "@/lib/config";
import { themeHasBackgroundImage, themeHeaderLayout, themeHeaderTabActiveStyle, themeHeaderTabStyle, themeToCssVars } from "@/lib/theme";
import { AppChrome } from "@/components/AppChrome";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { filterSettingsForSession } from "@/lib/auth/resource-access";
import { readAuthConfig } from "@/lib/auth";
import { withPersonalTabs } from "@/lib/auth/personal-dashboards";
import { profileBookmarks } from "@/lib/auth/profile-bookmarks";

export const dynamic = "force-dynamic";

const manrope = localFont({
  src: [
    { path: "../../public/fonts/manrope-latin-400-normal.woff2", weight: "400" },
    { path: "../../public/fonts/manrope-latin-500-normal.woff2", weight: "500" },
    { path: "../../public/fonts/manrope-latin-600-normal.woff2", weight: "600" },
    { path: "../../public/fonts/manrope-latin-700-normal.woff2", weight: "700" },
  ],
  variable: "--font-manrope",
  display: "swap",
});

export async function generateMetadata(): Promise<Metadata> {
  const settings = await readSettings();
  const icons = settings.faviconUrl?.trim()
    ? [{ url: settings.faviconUrl.trim() }]
    : undefined;
  return {
    title: settings.appName || "Homedash",
    description: "Self-hosted widget dashboard",
    icons,
  };
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const session = await readSessionFromCookies();
  let settings = filterSettingsForSession(await readSettings(), session);
  if (session) {
    const config = await readAuthConfig();
    const user = config.users.find((item) => item.id === session.sub);
    settings = withPersonalTabs(settings, user, config.users);
    if (user?.profileTheme) {
      settings.theme = { ...settings.theme, ...user.profileTheme };
    }
    if (user) {
      const personal = profileBookmarks(user, settings);
      settings.bookmarkGroups = personal.bookmarkGroups;
      settings.bookmarks = personal.bookmarks;
    }
    const profile = user?.profileBackground;
    if (profile?.enabled) {
      settings.theme = {
        ...settings.theme,
        ...(profile.background ? { background: profile.background } : {}),
        backgroundImageMode: "static",
        backgroundImageUrls: [],
        backgroundImageUrl: profile.backgroundImageUrl || "",
        backgroundImageOpacity: profile.backgroundImageOpacity ?? settings.theme.backgroundImageOpacity,
        backgroundImageBlur: profile.backgroundImageBlur ?? settings.theme.backgroundImageBlur,
      };
    }
  }
  return (
    <html lang="en" className={manrope.variable}>
      <body
        style={themeToCssVars(settings.theme)}
        data-hd-bg-image={themeHasBackgroundImage(settings.theme) ? "1" : "0"}
        data-hd-bg-pattern={
          settings.theme.backgroundPatternEnabled
            ? (settings.theme.backgroundPatternStyle || "dots")
            : "none"
        }
        data-hd-bg-pattern-animation={
          settings.theme.backgroundPatternEnabled && settings.theme.backgroundPatternAnimationEnabled
            ? (settings.theme.backgroundPatternAnimation || "drift")
            : "none"
        }
        data-hd-header={themeHeaderLayout(settings.theme)}
        data-hd-tabs={themeHeaderTabStyle(settings.theme)}
        data-hd-tab-active={themeHeaderTabActiveStyle(settings.theme)}
        data-theme={settings.theme.mode}
        className={settings.theme.mode === "light" ? "light" : "dark"}
      >
        <div className="hd-bg-pattern" aria-hidden="true" />
        <AppChrome settings={settings}>{children}</AppChrome>
      </body>
    </html>
  );
}
