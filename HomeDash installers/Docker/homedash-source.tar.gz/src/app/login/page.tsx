import { redirect } from "next/navigation";
import { hasUsers, maybeBootstrapAdminFromEnv } from "@/lib/auth";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { readSettings } from "@/lib/config";
import { AuthForm } from "@/components/AuthForm";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

function safeNext(raw: string | string[] | undefined): string {
  const value = Array.isArray(raw) ? raw[0] : raw;
  if (!value || !value.startsWith("/") || value.startsWith("//")) return "/";
  if (value.startsWith("/login") || value.startsWith("/setup")) return "/";
  return value;
}

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string | string[] }>;
}) {
  await maybeBootstrapAdminFromEnv();
  if (!(await hasUsers())) {
    redirect("/setup");
  }
  const session = await readSessionFromCookies();
  const params = await searchParams;
  const nextPath = safeNext(params.next);
  if (session) redirect(nextPath);

  const settings = await readSettings();
  return (
    <AuthForm
      mode="login"
      appName={settings.appName || "Homedash"}
      logoUrl={settings.logoUrl}
      nextPath={nextPath}
    />
  );
}
