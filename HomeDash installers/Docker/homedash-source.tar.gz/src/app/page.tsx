import { redirect } from "next/navigation";
import { ensureTabLayoutsSeeded, readSettings } from "@/lib/config";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { filterSettingsForSession } from "@/lib/auth/resource-access";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  await ensureTabLayoutsSeeded();
  const settings = filterSettingsForSession(await readSettings(), await readSessionFromCookies());
  const first = settings.tabs[0];
  redirect(first ? `/t/${first.id}` : "/settings");
}
