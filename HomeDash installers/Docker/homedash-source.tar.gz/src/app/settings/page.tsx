import { readSettings } from "@/lib/config";
import { listWidgets } from "@/widgets/registry";
import { SettingsForm } from "@/components/SettingsForm";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { filterSettingsForSession } from "@/lib/auth/resource-access";
import { readAuthConfig } from "@/lib/auth";
import { profileBookmarks } from "@/lib/auth/profile-bookmarks";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const session = await readSessionFromCookies();
  let settings = filterSettingsForSession(await readSettings(), session);
  let personalTabs: typeof settings.tabs = [];
  let personalTabOrder: string[] = [];
  const globalProfileDefaults = {
    theme: settings.theme,
    bookmarks: settings.bookmarks,
    bookmarkGroups: settings.bookmarkGroups,
  };
  if (session) {
    const auth = await readAuthConfig();
    const user = auth.users.find((item) => item.id === session.sub);
    if (user) {
      personalTabs = user.personalTabs || [];
      personalTabOrder = user.personalTabOrder || [];
      const personal = profileBookmarks(user, settings);
      settings = {
        ...settings,
        theme: { ...settings.theme, ...(user.profileTheme || {}) },
        ...personal,
      };
    }
  }
  const restrictedWidgets = new Set(session?.role === "admin" ? [] : (session?.restrictedWidgetIds || []));
  const widgets = listWidgets().filter((widget) => !restrictedWidgets.has(widget.id));
  return (
    <SettingsForm
      initial={settings}
      personalTabs={personalTabs}
      personalTabOrder={personalTabOrder}
      globalProfileDefaults={globalProfileDefaults}
      widgets={widgets}
    />
  );
}
