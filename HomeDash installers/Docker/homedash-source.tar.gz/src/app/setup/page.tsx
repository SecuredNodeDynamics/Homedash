import { redirect } from "next/navigation";
import { hasUsers, maybeBootstrapAdminFromEnv } from "@/lib/auth";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { readSettings } from "@/lib/config";
import { AuthForm } from "@/components/AuthForm";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export default async function SetupPage() {
  await maybeBootstrapAdminFromEnv();
  if (await hasUsers()) {
    const session = await readSessionFromCookies();
    redirect(session ? "/" : "/login");
  }
  const settings = await readSettings();
  return (
    <AuthForm
      mode="setup"
      appName={settings.appName || "Homedash"}
      logoUrl={settings.logoUrl}
    />
  );
}
