import { notFound } from "next/navigation";
import { ensureTabLayoutsSeeded, readSettings, readTabLayout, syncBookmarkInstanceLabels } from "@/lib/config";
import { DashboardBoard } from "@/components/DashboardBoard";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { filterSettingsForSession } from "@/lib/auth/resource-access";
import { readAuthConfig } from "@/lib/auth";
import { withPersonalTabs, emptyPersonalLayout, personalTabOwner } from "@/lib/auth/personal-dashboards";
import { profileBookmarks } from "@/lib/auth/profile-bookmarks";

export const dynamic = "force-dynamic";

export default async function TabPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  await ensureTabLayoutsSeeded();
  const session = await readSessionFromCookies();
  let settings = filterSettingsForSession(
    await syncBookmarkInstanceLabels(await readSettings()),
    session,
  );
  const config = session ? await readAuthConfig() : null;
  const user = config?.users.find((item) => item.id === session?.sub);
  settings = withPersonalTabs(settings, user, config?.users);
  if (user?.profileTheme) {
    settings = { ...settings, theme: { ...settings.theme, ...user.profileTheme } };
  }
  if (user) {
    settings = { ...settings, ...profileBookmarks(user, settings) };
  }
  const tab = settings.tabs.find((t) => t.id === slug);
  if (!tab) notFound();
  const owner = personalTabOwner(tab.id, user, config?.users);
  const layout = owner ? owner.personalLayouts?.[tab.id] || emptyPersonalLayout() : await readTabLayout(tab.id);
  return (
    <DashboardBoard
      settings={settings}
      tab={tab}
      initialLayout={layout}
      isPersonalTab={Boolean(owner)}
    />
  );
}
