import { notFound } from "next/navigation";
import { listWidgets } from "@/widgets/registry";
import { WidgetPreviewStage } from "@/components/WidgetPreviewStage";

export const dynamic = "force-dynamic";

export default async function WidgetPreviewPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  if (!listWidgets().some((widget) => widget.id === id)) notFound();
  return <WidgetPreviewStage widgetId={id} />;
}
