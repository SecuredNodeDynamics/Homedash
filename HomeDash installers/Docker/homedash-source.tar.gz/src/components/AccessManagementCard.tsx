"use client";

import { useCallback, useEffect, useState } from "react";
import { createPortal } from "react-dom";

type Permission = "dashboard.view" | "settings.view" | "settings.manage" | "layout.manage" | "widgets.manage" | "widgets.control" | "terminals.use" | "proxmox.control" | "dashboards.personal" | "backups.manage" | "users.manage";
type Group = { id: string; name: string; permissions: Permission[]; restrictedTabIds: string[]; restrictedWidgetIds: string[]; restrictedLayoutTabIds: string[] };
type User = { id: string; username: string; role: "admin" | "user"; groupIds: string[]; permissions: Permission[]; restrictedTabIds: string[]; restrictedWidgetIds: string[]; restrictedLayoutTabIds: string[]; disabled?: boolean; passwordResetRequestedAt?: string; mustChangePassword?: boolean };
type Resource = { id: string; name: string; category?: string };
const LABELS: Record<Permission, string> = {
  "dashboard.view": "View dashboard", "settings.view": "View settings", "settings.manage": "Change settings",
  "layout.manage": "Edit layouts", "widgets.manage": "Manage widgets", "widgets.control": "Control widget services", "terminals.use": "Use widget terminals", "proxmox.control": "Control Proxmox power", "dashboards.personal": "Create personal dashboards", "backups.manage": "Backups & restore", "users.manage": "Users & groups",
};

function RestrictionPicker({
  tabs,
  widgets,
  restrictedTabIds,
  restrictedWidgetIds,
  onTabsChange,
  onWidgetsChange,
}: {
  tabs: Resource[];
  widgets: Resource[];
  restrictedTabIds: string[];
  restrictedWidgetIds: string[];
  onTabsChange: (ids: string[]) => void;
  onWidgetsChange: (ids: string[]) => void;
}) {
  const toggleId = (ids: string[], id: string) => ids.includes(id) ? ids.filter((item) => item !== id) : [...ids, id];
  return (
    <div className="hd-access-resources">
      <div className="hd-access-resource-column">
        <div className="hd-access-resource-title"><strong>Restricted tabs</strong><span>{restrictedTabIds.length} blocked</span></div>
        <div className="hd-access-resource-options">
          {tabs.map((tab) => <label className={restrictedTabIds.includes(tab.id) ? "is-restricted" : ""} key={tab.id}><input type="checkbox" checked={restrictedTabIds.includes(tab.id)} onChange={() => onTabsChange(toggleId(restrictedTabIds, tab.id))} />{tab.name}</label>)}
        </div>
      </div>
      <div className="hd-access-resource-column">
        <div className="hd-access-resource-title"><strong>Restricted widgets</strong><span>{restrictedWidgetIds.length} blocked</span></div>
        <div className="hd-access-resource-options hd-access-resource-options--widgets">
          {widgets.map((widget) => <label className={restrictedWidgetIds.includes(widget.id) ? "is-restricted" : ""} key={widget.id}><input type="checkbox" checked={restrictedWidgetIds.includes(widget.id)} onChange={() => onWidgetsChange(toggleId(restrictedWidgetIds, widget.id))} /><span>{widget.name}<small>{widget.category || ""}</small></span></label>)}
        </div>
      </div>
    </div>
  );
}

function LayoutTabPicker({
  tabs,
  restrictedLayoutTabIds,
  onChange,
}: {
  tabs: Resource[];
  restrictedLayoutTabIds: string[];
  onChange: (ids: string[]) => void;
}) {
  const toggle = (tabId: string) =>
    onChange(restrictedLayoutTabIds.includes(tabId)
      ? restrictedLayoutTabIds.filter((id) => id !== tabId)
      : [...restrictedLayoutTabIds, tabId]);
  return (
    <div className="hd-access-layout-scope">
      <div className="hd-access-resource-title"><strong>Editable layout tabs</strong><span>{tabs.length - restrictedLayoutTabIds.length} of {tabs.length} enabled</span></div>
      <p>Checked tabs can be rearranged when this account also has the Edit layouts permission.</p>
      <div className="hd-access-resource-options">
        {tabs.map((tab) => {
          const editable = !restrictedLayoutTabIds.includes(tab.id);
          return <label className={editable ? "is-editable" : "is-restricted"} key={tab.id}><input type="checkbox" checked={editable} onChange={() => toggle(tab.id)} />{tab.name}</label>;
        })}
      </div>
    </div>
  );
}

export function AccessManagementCard() {
  const [users, setUsers] = useState<User[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [tabs, setTabs] = useState<Resource[]>([]);
  const [widgets, setWidgets] = useState<Resource[]>([]);
  const [authorized, setAuthorized] = useState<boolean | null>(null);
  const [message, setMessage] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [groupIds, setGroupIds] = useState<string[]>([]);
  const [groupName, setGroupName] = useState("");
  const [groupPermissions, setGroupPermissions] = useState<Permission[]>(["dashboard.view"]);
  const [userRestrictedTabs, setUserRestrictedTabs] = useState<string[]>([]);
  const [userRestrictedWidgets, setUserRestrictedWidgets] = useState<string[]>([]);
  const [userRestrictedLayoutTabs, setUserRestrictedLayoutTabs] = useState<string[]>([]);
  const [groupRestrictedTabs, setGroupRestrictedTabs] = useState<string[]>([]);
  const [groupRestrictedWidgets, setGroupRestrictedWidgets] = useState<string[]>([]);
  const [groupRestrictedLayoutTabs, setGroupRestrictedLayoutTabs] = useState<string[]>([]);
  const [editing, setEditing] = useState<User | null>(null);
  const [editingGroup, setEditingGroup] = useState<Group | null>(null);
  const [editPassword, setEditPassword] = useState("");
  const [resetUser, setResetUser] = useState<User | null>(null);
  const [temporaryPassword, setTemporaryPassword] = useState("");

  const load = useCallback(async () => {
    const response = await fetch("/api/admin/access");
    if (!response.ok) { setAuthorized(false); return; }
    setAuthorized(true);
    const data = await response.json();
    setUsers((data.users || []).map((user: User) => ({ ...user, restrictedTabIds: user.restrictedTabIds || [], restrictedWidgetIds: user.restrictedWidgetIds || [], restrictedLayoutTabIds: user.restrictedLayoutTabIds || [] })));
    setGroups((data.groups || []).map((group: Group) => ({ ...group, restrictedTabIds: group.restrictedTabIds || [], restrictedWidgetIds: group.restrictedWidgetIds || [], restrictedLayoutTabIds: group.restrictedLayoutTabIds || [] })));
    setPermissions(data.permissions || []); setTabs(data.tabs || []); setWidgets(data.widgets || []);
  }, []);
  useEffect(() => { void load(); }, [load]);

  async function mutate(method: string, body: unknown) {
    const response = await fetch("/api/admin/access", { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const data = await response.json();
    setMessage(response.ok ? "Access settings saved." : data.error || "Request failed");
    if (response.ok) await load();
    return response.ok;
  }
  function toggle<T extends string>(items: T[], value: T) { return items.includes(value) ? items.filter((item) => item !== value) : [...items, value]; }
  function generateTemporaryPassword() {
    const upper = "ABCDEFGHJKLMNPQRSTUVWXYZ";
    const lower = "abcdefghijkmnopqrstuvwxyz";
    const digits = "23456789";
    const all = upper + lower + digits;
    const randomFrom = (alphabet: string) => {
      const value = crypto.getRandomValues(new Uint32Array(1))[0]!;
      return alphabet[value % alphabet.length]!;
    };
    const chars = [randomFrom(upper), randomFrom(lower), randomFrom(digits), randomFrom(all), randomFrom(all), randomFrom(all)];
    for (let index = chars.length - 1; index > 0; index -= 1) {
      const value = crypto.getRandomValues(new Uint32Array(1))[0]!;
      const target = value % (index + 1);
      [chars[index], chars[target]] = [chars[target]!, chars[index]!];
    }
    setPassword(chars.join(""));
  }
  if (authorized === false) return null;

  return (
    <article className="hd-panel-card hd-access-card">
      <div className="hd-panel-card__head hd-access-card__head">
        <div><div className="hd-settings__kicker">Access control</div><h2>Users & groups</h2><p>Create accounts and assign server-enforced permissions.</p></div>
        <span className="hd-access-card__count">{users.length} {users.length === 1 ? "user" : "users"} · {groups.length} {groups.length === 1 ? "group" : "groups"}</span>
      </div>
      {message ? <div className="hd-settings__toast">{message}</div> : null}
      <div className="hd-access-grid">
        <section className="hd-access-pane">
          <h3 className="hd-access-pane__title">Create user</h3>
          <div className="hd-access-form-row">
            <input value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Username" aria-label="Username" autoComplete="off" />
            <div className="hd-access-password-field">
              <input value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Temporary password" aria-label="Temporary password" type="text" minLength={6} autoComplete="off" />
              <button className="hd-btn" type="button" onClick={generateTemporaryPassword}>Generate</button>
            </div>
          </div>
          {groups.length ? (
            <div className="hd-access-field-group">
              <span className="hd-access-field-label">Assign to groups</span>
              <div className="hd-access-checks">
                {groups.map((group) => <label key={group.id}><input type="checkbox" checked={groupIds.includes(group.id)} onChange={() => setGroupIds(toggle(groupIds, group.id))} />{group.name}</label>)}
              </div>
            </div>
          ) : null}
          <details className="hd-access-restriction-details">
            <summary><span className="hd-access-restriction-details__label">Resource access & layout scope</span><span className="hd-access-count" aria-label="restrictions set">{userRestrictedTabs.length + userRestrictedWidgets.length + userRestrictedLayoutTabs.length}</span></summary>
            <p>Checked resources will be hidden and blocked for this user in addition to restrictions inherited from groups.</p>
            <RestrictionPicker tabs={tabs} widgets={widgets} restrictedTabIds={userRestrictedTabs} restrictedWidgetIds={userRestrictedWidgets} onTabsChange={setUserRestrictedTabs} onWidgetsChange={setUserRestrictedWidgets} />
            <LayoutTabPicker tabs={tabs} restrictedLayoutTabIds={userRestrictedLayoutTabs} onChange={setUserRestrictedLayoutTabs} />
          </details>
          <button className="hd-btn hd-btn--primary hd-access-submit" type="button" disabled={password.length < 6 || !username.trim()} onClick={async () => { if (await mutate("POST", { kind: "user", username, password, groupIds, restrictedTabIds: userRestrictedTabs, restrictedWidgetIds: userRestrictedWidgets, restrictedLayoutTabIds: userRestrictedLayoutTabs, temporary: true })) { setUsername(""); setPassword(""); setGroupIds([]); setUserRestrictedTabs([]); setUserRestrictedWidgets([]); setUserRestrictedLayoutTabs([]); } }}>Create user</button>
          <div className="hd-access-list-head"><strong>Users</strong><span>{users.length}</span></div>
          <div className="hd-access-list">
            {users.map((user) => (
              <div className="hd-access-item" key={user.id}>
                <div>
                  <div className="hd-access-user-title">
                    <strong>{user.username}</strong>
                    <span className="hd-access-group-pills">
                      {user.groupIds.length ? user.groupIds.map((groupId) => {
                        const group = groups.find((item) => item.id === groupId);
                        return group ? <span className="hd-access-group-pill" key={groupId}>{group.name}</span> : null;
                      }) : <span className="hd-access-group-pill hd-access-group-pill--empty">No group</span>}
                    </span>
                  </div>
                  <span className="hd-access-item__meta">{user.role}{user.disabled ? " · disabled" : ""}{user.passwordResetRequestedAt ? " · password reset requested" : ""}{user.mustChangePassword ? " · temporary password active" : ""}</span>
                </div>
                <div className="hd-access-item__actions">
                  <button type="button" className={`hd-btn${user.passwordResetRequestedAt ? " hd-btn--primary" : ""}`} onClick={() => { setResetUser(user); setTemporaryPassword(""); }}>PW Reset</button>
                  <button type="button" className="hd-btn" onClick={() => { setEditing({ ...user, groupIds: [...user.groupIds], permissions: [...(user.permissions || [])] }); setEditPassword(""); }}>Edit</button>
                  {user.role !== "admin" ? <button type="button" className="hd-btn" onClick={() => mutate("DELETE", { kind: "user", id: user.id })}>Delete</button> : null}
                </div>
              </div>
            ))}
          </div>
        </section>
        <section className="hd-access-pane">
          <h3 className="hd-access-pane__title">Create group</h3>
          <input value={groupName} onChange={(e) => setGroupName(e.target.value)} placeholder="Group name" aria-label="Group name" autoComplete="off" />
          <div className="hd-access-field-group">
            <span className="hd-access-field-label">Permissions</span>
            <div className="hd-access-checks hd-access-checks--permissions">
              {permissions.map((permission) => <label key={permission}><input type="checkbox" checked={groupPermissions.includes(permission)} onChange={() => setGroupPermissions(toggle(groupPermissions, permission))} />{LABELS[permission]}</label>)}
            </div>
          </div>
          <details className="hd-access-restriction-details">
            <summary><span className="hd-access-restriction-details__label">Resource access & layout scope</span><span className="hd-access-count" aria-label="restrictions set">{groupRestrictedTabs.length + groupRestrictedWidgets.length + groupRestrictedLayoutTabs.length}</span></summary>
            <p>Checked resources will be hidden and blocked for every member of this group.</p>
            <RestrictionPicker tabs={tabs} widgets={widgets} restrictedTabIds={groupRestrictedTabs} restrictedWidgetIds={groupRestrictedWidgets} onTabsChange={setGroupRestrictedTabs} onWidgetsChange={setGroupRestrictedWidgets} />
            <LayoutTabPicker tabs={tabs} restrictedLayoutTabIds={groupRestrictedLayoutTabs} onChange={setGroupRestrictedLayoutTabs} />
          </details>
          <button className="hd-btn hd-btn--primary hd-access-submit" type="button" disabled={!groupName.trim()} onClick={async () => { if (await mutate("POST", { kind: "group", name: groupName, permissions: groupPermissions, restrictedTabIds: groupRestrictedTabs, restrictedWidgetIds: groupRestrictedWidgets, restrictedLayoutTabIds: groupRestrictedLayoutTabs })) { setGroupName(""); setGroupRestrictedTabs([]); setGroupRestrictedWidgets([]); setGroupRestrictedLayoutTabs([]); } }}>Create group</button>
          <div className="hd-access-list-head"><strong>Groups</strong><span>{groups.length}</span></div>
          <div className="hd-access-list">
            {!groups.length ? <p className="hd-access-empty">No groups yet. Create one above to share permissions across accounts.</p> : null}
            {groups.map((group) => (
              <div className="hd-access-item hd-access-item--group" key={group.id}>
                <div><strong>{group.name}</strong><span className="hd-access-item__meta">{group.permissions.map((p) => LABELS[p]).join(" · ") || "No access"}</span></div>
                <div className="hd-access-item__actions">
                  <button type="button" className="hd-btn" onClick={() => setEditingGroup({ ...group, permissions: [...group.permissions], restrictedTabIds: [...group.restrictedTabIds], restrictedWidgetIds: [...group.restrictedWidgetIds], restrictedLayoutTabIds: [...group.restrictedLayoutTabIds] })}>Edit</button>
                  <button type="button" className="hd-btn" onClick={() => mutate("DELETE", { kind: "group", id: group.id })}>Delete</button>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
      {editing ? createPortal(
        <div className="hd-modal-scrim" role="presentation" onClick={() => setEditing(null)}>
          <div className="hd-modal hd-access-edit-modal" role="dialog" aria-modal="true" aria-labelledby="hd-edit-user-title" onClick={(event) => event.stopPropagation()}>
            <header className="hd-modal__head">
              <div><div className="hd-settings__kicker">Account access</div><h2 id="hd-edit-user-title">Edit {editing.username}</h2><p>Changes take effect the next time this user signs in.</p></div>
              <button className="hd-btn" type="button" onClick={() => setEditing(null)}>Close</button>
            </header>
            <div className="hd-access-edit-grid">
              <label><span>Username</span><input value={editing.username} onChange={(e) => setEditing({ ...editing, username: e.target.value })} /></label>
              <label><span>Role</span><select value={editing.role} onChange={(e) => setEditing({ ...editing, role: e.target.value as User["role"] })}><option value="user">User</option><option value="admin">Administrator</option></select></label>
              <label className="hd-access-edit-grid__wide"><span>New password <em>Leave blank to keep the current password</em></span><input type="password" value={editPassword} onChange={(e) => setEditPassword(e.target.value)} placeholder="Minimum 8 characters" /></label>
            </div>
            <section className="hd-access-edit-section">
              <h3>Groups</h3>
              <div className="hd-access-checks">
                {groups.map((group) => <label key={group.id}><input type="checkbox" checked={editing.groupIds.includes(group.id)} onChange={() => setEditing({ ...editing, groupIds: toggle(editing.groupIds, group.id) })} />{group.name}</label>)}
                {!groups.length ? <span className="hd-admin__muted">No groups created yet.</span> : null}
              </div>
            </section>
            <section className="hd-access-edit-section">
              <h3>Direct permissions</h3>
              <p>These are added to permissions inherited from groups. Administrators always have full access.</p>
              <div className="hd-access-checks hd-access-checks--permissions">
                {permissions.map((permission) => <label key={permission}><input type="checkbox" disabled={editing.role === "admin"} checked={editing.role === "admin" || editing.permissions.includes(permission)} onChange={() => setEditing({ ...editing, permissions: toggle(editing.permissions, permission) })} />{LABELS[permission]}</label>)}
              </div>
            </section>
            <section className="hd-access-edit-section">
              <h3>Tab & widget restrictions</h3>
              <p>These restrictions are added to any restrictions inherited from assigned groups.</p>
              <RestrictionPicker tabs={tabs} widgets={widgets} restrictedTabIds={editing.restrictedTabIds} restrictedWidgetIds={editing.restrictedWidgetIds} onTabsChange={(ids) => setEditing({ ...editing, restrictedTabIds: ids })} onWidgetsChange={(ids) => setEditing({ ...editing, restrictedWidgetIds: ids })} />
              <LayoutTabPicker tabs={tabs} restrictedLayoutTabIds={editing.restrictedLayoutTabIds} onChange={(ids) => setEditing({ ...editing, restrictedLayoutTabIds: ids })} />
            </section>
            <label className="hd-access-disabled-toggle"><input type="checkbox" checked={!editing.disabled} onChange={(e) => setEditing({ ...editing, disabled: !e.target.checked })} /><span><strong>Account enabled</strong><small>Disabled users cannot sign in.</small></span></label>
            <footer className="hd-modal__actions">
              <button className="hd-btn" type="button" onClick={() => setEditing(null)}>Cancel</button>
              <button className="hd-btn hd-btn--primary" type="button" onClick={async () => {
                if (await mutate("PATCH", { kind: "user", id: editing.id, username: editing.username, role: editing.role, disabled: editing.disabled, groupIds: editing.groupIds, permissions: editing.permissions, restrictedTabIds: editing.restrictedTabIds, restrictedWidgetIds: editing.restrictedWidgetIds, restrictedLayoutTabIds: editing.restrictedLayoutTabIds, password: editPassword })) setEditing(null);
              }}>Save user</button>
            </footer>
          </div>
        </div>,
        document.body,
      ) : null}
      {editingGroup ? createPortal(
        <div className="hd-modal-scrim" role="presentation" onClick={() => setEditingGroup(null)}>
          <div className="hd-modal hd-access-edit-modal" role="dialog" aria-modal="true" aria-labelledby="hd-edit-group-title" onClick={(event) => event.stopPropagation()}>
            <header className="hd-modal__head"><div><div className="hd-settings__kicker">Group access</div><h2 id="hd-edit-group-title">Edit {editingGroup.name}</h2><p>Update inherited permissions and resource restrictions for every group member.</p></div><button className="hd-btn" type="button" onClick={() => setEditingGroup(null)}>Close</button></header>
            <div className="hd-access-edit-grid"><label className="hd-access-edit-grid__wide"><span>Group name</span><input value={editingGroup.name} onChange={(event) => setEditingGroup({ ...editingGroup, name: event.target.value })} /></label></div>
            <section className="hd-access-edit-section"><h3>Permissions</h3><div className="hd-access-checks hd-access-checks--permissions">{permissions.map((permission) => <label key={permission}><input type="checkbox" checked={editingGroup.permissions.includes(permission)} onChange={() => setEditingGroup({ ...editingGroup, permissions: toggle(editingGroup.permissions, permission) })} />{LABELS[permission]}</label>)}</div></section>
            <section className="hd-access-edit-section"><h3>Tab & widget restrictions</h3><p>Checked resources are hidden and blocked for every member of this group.</p><RestrictionPicker tabs={tabs} widgets={widgets} restrictedTabIds={editingGroup.restrictedTabIds} restrictedWidgetIds={editingGroup.restrictedWidgetIds} onTabsChange={(ids) => setEditingGroup({ ...editingGroup, restrictedTabIds: ids })} onWidgetsChange={(ids) => setEditingGroup({ ...editingGroup, restrictedWidgetIds: ids })} /><LayoutTabPicker tabs={tabs} restrictedLayoutTabIds={editingGroup.restrictedLayoutTabIds} onChange={(ids) => setEditingGroup({ ...editingGroup, restrictedLayoutTabIds: ids })} /></section>
            <footer className="hd-modal__actions"><button className="hd-btn" type="button" onClick={() => setEditingGroup(null)}>Cancel</button><button className="hd-btn hd-btn--primary" type="button" onClick={async () => { if (await mutate("PATCH", { kind: "group", id: editingGroup.id, name: editingGroup.name, permissions: editingGroup.permissions, restrictedTabIds: editingGroup.restrictedTabIds, restrictedWidgetIds: editingGroup.restrictedWidgetIds, restrictedLayoutTabIds: editingGroup.restrictedLayoutTabIds })) setEditingGroup(null); }}>Save group</button></footer>
          </div>
        </div>,
        document.body,
      ) : null}
      {resetUser ? createPortal(
        <div className="hd-modal-scrim" role="presentation" onClick={() => setResetUser(null)}>
          <div className="hd-modal hd-access-reset-modal" role="dialog" aria-modal="true" onClick={(event) => event.stopPropagation()}>
            <header className="hd-modal__head"><div><div className="hd-settings__kicker">Password recovery</div><h2>Temporary password</h2><p>Set a one-time password for {resetUser.username}. They must replace it immediately after signing in.</p></div><button className="hd-btn" type="button" onClick={() => setResetUser(null)}>Close</button></header>
            {resetUser.passwordResetRequestedAt ? <div className="hd-access-reset-status">Reset requested {new Date(resetUser.passwordResetRequestedAt).toLocaleString()}</div> : null}
            <label className="hd-auth__field"><span>Temporary password</span><input type="password" autoFocus minLength={8} value={temporaryPassword} onChange={(event) => setTemporaryPassword(event.target.value)} placeholder="Minimum 8 characters" /></label>
            <footer className="hd-modal__actions"><button className="hd-btn" type="button" onClick={() => setResetUser(null)}>Cancel</button><button className="hd-btn hd-btn--primary" type="button" disabled={temporaryPassword.length < 8} onClick={async () => { if (await mutate("PATCH", { kind: "user", id: resetUser.id, password: temporaryPassword, temporary: true })) setResetUser(null); }}>Set temporary password</button></footer>
          </div>
        </div>,
        document.body,
      ) : null}
    </article>
  );
}
