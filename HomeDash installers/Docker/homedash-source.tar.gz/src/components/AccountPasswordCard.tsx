"use client";

import { useState } from "react";
import type { FormEvent } from "react";

export function AccountPasswordCard({
  username,
  role,
}: {
  username?: string;
  role?: string;
}) {
  const [currentPassword, setCurrentPassword] = useState("");
  const [nextPassword, setNextPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setMessage("");
    if (nextPassword !== confirm) {
      setError("New passwords do not match");
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/auth/change-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword, nextPassword }),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) {
        setError(json.error || "Password change failed");
        return;
      }
      setMessage("Password updated");
      setCurrentPassword("");
      setNextPassword("");
      setConfirm("");
    } catch {
      setError("Network error");
    } finally {
      setBusy(false);
    }
  }

  return (
    <article className="hd-panel-card hd-account-password-card">
      <header>
        <div className="hd-account-password-card__title">
          <h2>Account</h2>
          {username ? <span className="hd-account-password-card__user">{username}</span> : null}
        </div>
        <p>
          {role === "admin"
            ? `Change the administrator password${username ? ` for ${username}` : ""}.`
            : `Change the password${username ? ` for ${username}` : " for your account"}.`}
        </p>
      </header>
      <form className="hd-auth__form" onSubmit={onSubmit}>
        <label className="hd-auth__field">
          <span>Current password</span>
          <input
            type="password"
            autoComplete="current-password"
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            required
          />
        </label>
        <label className="hd-auth__field">
          <span>New password</span>
          <input
            type="password"
            autoComplete="new-password"
            value={nextPassword}
            onChange={(e) => setNextPassword(e.target.value)}
            required
            minLength={8}
          />
        </label>
        <label className="hd-auth__field">
          <span>Confirm new password</span>
          <input
            type="password"
            autoComplete="new-password"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            required
            minLength={8}
          />
        </label>
        {error ? <div className="hd-auth__error">{error}</div> : null}
        {message ? <div className="hd-ok">{message}</div> : null}
        <button className="hd-btn hd-btn--primary" type="submit" disabled={busy}>
          {busy ? "Saving…" : "Update password"}
        </button>
      </form>
    </article>
  );
}
