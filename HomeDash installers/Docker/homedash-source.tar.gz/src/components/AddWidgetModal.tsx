"use client";

import { useEffect, useId, useMemo, useState } from "react";
import type { DashboardTab, WidgetInstance, WidgetManifest } from "@/lib/types";
import { isMultiInstanceWidget } from "@/lib/instances";
import { resolveWidgetIcon } from "@/lib/widget-icons";
import { tabHasWidgetPackage } from "@/lib/edit-layout";

export type AddWidgetChoice =
  | { kind: "package"; manifest: WidgetManifest; instanceId?: string; instanceLabel?: string }
  | { kind: "another"; manifest: WidgetManifest };

function TileMark({
  widgetId,
  name,
  customIcon,
}: {
  widgetId: string;
  name: string;
  customIcon?: string;
}) {
  const src = resolveWidgetIcon(widgetId, customIcon);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    setFailed(false);
  }, [src]);

  const initials = name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() || "")
    .join("") || "?";

  return (
    <span className="hd-widget-mark hd-widget-mark--lg" aria-hidden="true">
      {src && !failed ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={src} alt="" onError={() => setFailed(true)} />
      ) : (
        <span className="hd-widget-mark__fallback">{initials}</span>
      )}
    </span>
  );
}

function WidgetTile({
  manifest,
  onTab,
  instanceId,
  instanceLabel,
  customIcon,
  selected,
  onToggle,
}: {
  manifest: WidgetManifest;
  onTab: boolean;
  instanceId?: string;
  instanceLabel?: string;
  customIcon?: string;
  selected: boolean;
  onToggle: (choice: AddWidgetChoice) => void;
}) {
  const actionLabel = onTab ? "Already on page" : "Add";
  const body = (
    <>
      <TileMark widgetId={manifest.id} name={manifest.name} customIcon={customIcon} />
      <strong className="hd-modal__tile-title">{instanceLabel || manifest.name}</strong>
      {instanceLabel ? <small>{manifest.name}</small> : null}
      <span className={`hd-modal__tile-count${onTab ? " is-repeat" : ""}`}>
        {actionLabel}
      </span>
    </>
  );

  return (
    <button
      type="button"
      className={`hd-modal__tile${selected ? " is-selected" : ""}`}
      disabled={onTab}
      title={
        onTab ? `${instanceLabel || manifest.name} is already on this page` : manifest.description || manifest.name
      }
      onClick={() =>
        onToggle({
          kind: "package",
          manifest,
          instanceId,
          instanceLabel,
        })
      }
    >
      {body}
    </button>
  );
}

export function AddWidgetModal({
  tab,
  manifests,
  widgetInstances = [],
  widgetIcons = {},
  onAdd,
  onClose,
}: {
  tab: DashboardTab;
  manifests: WidgetManifest[];
  widgetInstances?: WidgetInstance[];
  widgetIcons?: Record<string, string>;
  onAdd: (choices: AddWidgetChoice[]) => void;
  onClose: () => void;
}) {
  const titleId = useId();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<string>("all");
  const [selected, setSelected] = useState<Record<string, AddWidgetChoice>>({});

  const choiceKey = (choice: AddWidgetChoice) =>
    choice.kind === "package"
      ? choice.instanceId || choice.manifest.id
      : `another:${choice.manifest.id}`;

  function toggleChoice(choice: AddWidgetChoice) {
    const key = choiceKey(choice);
    setSelected((previous) => {
      const next = { ...previous };
      if (next[key]) delete next[key];
      else next[key] = choice;
      return next;
    });
  }

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [onClose]);

  const categories = useMemo(() => {
    const set = new Set<string>();
    for (const m of manifests) set.add(m.category || "General");
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [manifests]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return manifests
      .filter((m) => category === "all" || (m.category || "General") === category)
      .filter((m) => {
        if (!q) return true;
        return (
          m.name.toLowerCase().includes(q) ||
          m.id.toLowerCase().includes(q) ||
          (m.description || "").toLowerCase().includes(q)
        );
      })
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [manifests, query, category]);

  return (
    <div className="hd-modal-scrim" role="presentation" onClick={onClose}>
      <div
        className="hd-modal hd-modal--add-widget"
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        onClick={(e) => e.stopPropagation()}
      >
        <header className="hd-modal__head">
          <div>
            <div className="hd-settings__kicker">{tab.name}</div>
            <h2 id={titleId}>Add widgets</h2>
            <p>Select one or several widgets, then add them together. Each widget will be placed in the next available grid space.</p>
          </div>
          <button type="button" className="hd-btn" onClick={onClose}>
            Close
          </button>
        </header>

        <div className="hd-modal__toolbar hd-modal__toolbar--add">
          <input
            className="hd-search hd-search--modal"
            type="search"
            placeholder="Search widgets…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            aria-label="Search widgets"
            autoFocus
          />
          <div className="hd-filter-tabs hd-filter-tabs--wrap" role="tablist" aria-label="Widget categories">
            <button
              type="button"
              role="tab"
              aria-selected={category === "all"}
              className={`hd-filter-tab${category === "all" ? " is-active" : ""}`}
              onClick={() => setCategory("all")}
            >
              All
            </button>
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                role="tab"
                aria-selected={category === cat}
                className={`hd-filter-tab${category === cat ? " is-active" : ""}`}
                onClick={() => setCategory(cat)}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="hd-modal__grid hd-modal__grid--widgets">
          {filtered.flatMap((manifest) => {
            const instances = isMultiInstanceWidget(manifest.id)
              ? widgetInstances.filter((instance) => instance.widgetId === manifest.id)
              : [];
            if (instances.length) {
              return instances.map((instance) => (
                <WidgetTile
                  key={instance.id}
                  manifest={manifest}
                  instanceId={instance.id}
                  instanceLabel={instance.label}
                  onTab={tab.widgetIds.some((entry) => entry === instance.id || entry === manifest.id)}
                  selected={Boolean(selected[instance.id])}
                  customIcon={widgetIcons[instance.id] || widgetIcons[manifest.id]}
                  onToggle={toggleChoice}
                />
              ));
            }
            return (
              <WidgetTile
                key={manifest.id}
                manifest={manifest}
                onTab={tabHasWidgetPackage(tab, manifest.id)}
                selected={Boolean(selected[manifest.id])}
                customIcon={widgetIcons[manifest.id]}
                onToggle={toggleChoice}
              />
            );
          })}
          {!filtered.length ? (
            <div className="hd-modal__status hd-modal__status--span">No widgets match your search.</div>
          ) : null}
        </div>
        <footer className="hd-modal__selection-footer">
          <span>
            <strong>{Object.keys(selected).length}</strong>
            {Object.keys(selected).length === 1 ? " widget selected" : " widgets selected"}
          </span>
          <div>
            <button
              className="hd-btn"
              type="button"
              disabled={!Object.keys(selected).length}
              onClick={() => setSelected({})}
            >
              Clear
            </button>
            <button
              className="hd-btn hd-btn--primary"
              type="button"
              disabled={!Object.keys(selected).length}
              onClick={() => onAdd(Object.values(selected))}
            >
              Add selected
            </button>
          </div>
        </footer>
      </div>
    </div>
  );
}
