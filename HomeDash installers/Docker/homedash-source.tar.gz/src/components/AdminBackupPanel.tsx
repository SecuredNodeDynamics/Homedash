"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { CleanupCard, CleanupJobPanel, useCleanupJob } from "@/components/CleanupPanel";
import { SystemBackupCard } from "@/components/SystemBackupCard";
import { BookmarksBackupCard } from "@/components/BookmarksBackupCard";

type Overview = {
  appName: string;
  tabCount: number;
  enabledWidgets: number;
  layoutTabs: number;
  widgetConfigs: number;
  uploadFiles: number;
  savedBackups: number;
  latestBackupAt: string | null;
};

type BackupItem = {
  id: string;
  filename: string;
  kind: "full" | "widgets";
  label: string;
  exportedAt: string;
  size: number;
  widgetCount: number;
  hasSettings: boolean;
  hasLayouts: boolean;
};

type WidgetItem = {
  id: string;
  label: string;
  widgetId: string;
};

function formatBytes(n: number) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

function formatWhen(iso: string | null | undefined) {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleString(undefined, {
      dateStyle: "medium",
      timeStyle: "short",
    });
  } catch {
    return iso;
  }
}

function downloadJson(filename: string, data: unknown) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export function AdminBackupPanel() {
  const router = useRouter();
  const cleanup = useCleanupJob();
  const fileRef = useRef<HTMLInputElement>(null);
  const [configTab, setConfigTab] = useState<"backup" | "restore">("backup");
  const [overview, setOverview] = useState<Overview | null>(null);
  const [backups, setBackups] = useState<BackupItem[]>([]);
  const [widgets, setWidgets] = useState<WidgetItem[]>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [widgetQuery, setWidgetQuery] = useState("");
  const [label, setLabel] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [importParts, setImportParts] = useState({
    settings: true,
    layouts: true,
    widgets: true,
  });
  const [pendingImport, setPendingImport] = useState<{
    filename: string;
    raw: string;
    kind: string;
    widgetCount: number;
    hasSettings: boolean;
    hasLayouts: boolean;
  } | null>(null);

  const load = useCallback(async () => {
    const res = await fetch("/api/admin/backup");
    if (!res.ok) throw new Error("Failed to load admin backup status");
    const json = (await res.json()) as {
      overview: Overview;
      backups: BackupItem[];
      widgets: WidgetItem[];
    };
    setOverview(json.overview);
    setBackups(json.backups);
    setWidgets(json.widgets);
  }, []);

  useEffect(() => {
    void load().catch((err) => {
      setError(err instanceof Error ? err.message : "Failed to load");
    });
  }, [load]);

  const filteredWidgets = useMemo(() => {
    const q = widgetQuery.trim().toLowerCase();
    if (!q) return widgets;
    return widgets.filter(
      (w) =>
        w.id.toLowerCase().includes(q) ||
        w.label.toLowerCase().includes(q) ||
        w.widgetId.toLowerCase().includes(q),
    );
  }, [widgets, widgetQuery]);

  function clearFlash() {
    setMessage("");
    setError("");
  }

  async function createBackup(opts: {
    kind: "full" | "widgets";
    widgetIds?: string[];
    download?: boolean;
    save?: boolean;
  }) {
    clearFlash();
    setBusy(opts.kind === "full" ? "full" : "widgets");
    try {
      const res = await fetch("/api/admin/backup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          kind: opts.kind,
          widgetIds: opts.widgetIds,
          label: label.trim() || undefined,
          save: opts.save !== false,
          download: Boolean(opts.download),
        }),
      });
      const json = (await res.json().catch(() => ({}))) as {
        error?: string;
        saved?: BackupItem;
        filename?: string;
        backup?: unknown;
      };
      if (!res.ok) throw new Error(json.error || "Backup failed");
      if (opts.download && json.backup) {
        downloadJson(json.filename || "homedash-backup.json", json.backup);
      }
      setMessage(
        opts.download
          ? `Exported ${json.filename || "backup"}`
          : `Saved snapshot${json.saved ? `: ${json.saved.filename}` : ""}`,
      );
      setLabel("");
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Backup failed");
    } finally {
      setBusy(null);
    }
  }

  async function exportSaved(id: string, filename: string) {
    clearFlash();
    setBusy(`export:${id}`);
    try {
      const res = await fetch(`/api/admin/backup/${encodeURIComponent(id)}`);
      if (!res.ok) {
        const json = (await res.json().catch(() => ({}))) as { error?: string };
        throw new Error(json.error || "Export failed");
      }
      const text = await res.text();
      const blob = new Blob([text], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      setMessage(`Downloaded ${filename}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Export failed");
    } finally {
      setBusy(null);
    }
  }

  async function deleteSaved(id: string) {
    if (!window.confirm(`Delete backup “${id}”? This cannot be undone.`)) return;
    clearFlash();
    setBusy(`delete:${id}`);
    try {
      const res = await fetch(`/api/admin/backup/${encodeURIComponent(id)}`, { method: "DELETE" });
      const json = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(json.error || "Delete failed");
      setMessage("Backup deleted");
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Delete failed");
    } finally {
      setBusy(null);
    }
  }

  async function restoreSaved(id: string) {
    if (
      !window.confirm(
        "Restore this backup? Current settings/layouts/widget configs will be overwritten for the selected parts.",
      )
    ) {
      return;
    }
    clearFlash();
    setBusy(`restore:${id}`);
    try {
      const res = await fetch("/api/admin/backup/restore", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          backupId: id,
          parts: { settings: true, layouts: true, widgets: true },
        }),
      });
      const json = (await res.json().catch(() => ({}))) as {
        error?: string;
        result?: { settings: boolean; layouts: number; widgets: number };
      };
      if (!res.ok) throw new Error(json.error || "Restore failed");
      const r = json.result;
      setMessage(
        `Restored${r?.settings ? " settings" : ""}${r?.layouts ? ` · ${r.layouts} layouts` : ""}${
          r?.widgets ? ` · ${r.widgets} widgets` : ""
        }`,
      );
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Restore failed");
    } finally {
      setBusy(null);
    }
  }

  function onPickFile(file: File | null) {
    clearFlash();
    setPendingImport(null);
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const raw = String(reader.result || "");
        const parsed = JSON.parse(raw) as {
          kind?: string;
          widgets?: Record<string, unknown>;
          settings?: unknown;
          layouts?: unknown;
        };
        if (!parsed || typeof parsed !== "object") throw new Error("Invalid file");
        setPendingImport({
          filename: file.name,
          raw,
          kind: parsed.kind === "widgets" ? "widgets" : "full",
          widgetCount: parsed.widgets ? Object.keys(parsed.widgets).length : 0,
          hasSettings: Boolean(parsed.settings),
          hasLayouts: Boolean(parsed.layouts),
        });
        setImportParts({
          settings: Boolean(parsed.settings),
          layouts: Boolean(parsed.layouts),
          widgets: true,
        });
      } catch {
        setError("Could not read that backup file (need Homedash JSON export)");
      }
    };
    reader.readAsText(file);
  }

  async function runImport(saveImport: boolean) {
    if (!pendingImport) return;
    if (
      !window.confirm(
        "Import and restore this backup? Matching parts of your live config will be overwritten.",
      )
    ) {
      return;
    }
    clearFlash();
    setBusy("import");
    try {
      const res = await fetch("/api/admin/backup/restore", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          backup: pendingImport.raw,
          saveImport,
          parts: importParts,
        }),
      });
      const json = (await res.json().catch(() => ({}))) as {
        error?: string;
        result?: { settings: boolean; layouts: number; widgets: number };
      };
      if (!res.ok) throw new Error(json.error || "Import failed");
      const r = json.result;
      setMessage(
        `Imported ${pendingImport.filename}${r?.settings ? " · settings" : ""}${
          r?.layouts ? ` · ${r.layouts} layouts` : ""
        }${r?.widgets ? ` · ${r.widgets} widgets` : ""}`,
      );
      setPendingImport(null);
      if (fileRef.current) fileRef.current.value = "";
      await load();
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Import failed");
    } finally {
      setBusy(null);
    }
  }

  function toggleWidget(id: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function selectFiltered(on: boolean) {
    setSelected((prev) => {
      const next = new Set(prev);
      for (const w of filteredWidgets) {
        if (on) next.add(w.id);
        else next.delete(w.id);
      }
      return next;
    });
  }

  const selectedCount = selected.size;

  return (
    <section className="hd-admin">
      <article className="hd-panel-card hd-admin__hero">
        <div className="hd-admin__intro">
          <div>
            <div className="hd-settings__kicker">Operations</div>
            <h2 className="hd-admin__title">Admin control</h2>
            <p>
              Snapshot settings, layouts, and widget credentials. Export copies off-box, and import them
              if a deploy goes sideways. Auth passwords are never included.
            </p>
          </div>
          {(message || error) && (
            <div className={`hd-admin__flash${error ? " hd-admin__flash--error" : ""}`} role="status">
              {error || message}
            </div>
          )}
        </div>

        <div className="hd-admin__overview">
          <div className="hd-admin__stats" aria-label="Config overview">
            <div className="hd-admin__stat">
              <span className="hd-admin__stat-value">{overview?.tabCount ?? "—"}</span>
              <span className="hd-admin__stat-label">Tabs</span>
            </div>
            <div className="hd-admin__stat">
              <span className="hd-admin__stat-value">{overview?.layoutTabs ?? "—"}</span>
              <span className="hd-admin__stat-label">Layouts</span>
            </div>
            <div className="hd-admin__stat">
              <span className="hd-admin__stat-value">{overview?.widgetConfigs ?? "—"}</span>
              <span className="hd-admin__stat-label">Configs</span>
            </div>
            <div className="hd-admin__stat">
              <span className="hd-admin__stat-value">{overview?.savedBackups ?? "—"}</span>
              <span className="hd-admin__stat-label">Backups</span>
            </div>
          </div>
          <div className="hd-admin__latest">
            <span className="hd-admin__latest-label">Latest snapshot</span>
            <span className="hd-admin__latest-value">{formatWhen(overview?.latestBackupAt)}</span>
          </div>
        </div>
      </article>

      <div className="hd-admin__grid">
        <div className="hd-admin__pair">
          <article className="hd-panel-card hd-admin__card">
            <header>
              <h2>Config backup &amp; restore</h2>
              <p>Snapshot settings, page layouts, and widget credentials to a file — or restore from one.</p>
            </header>
            <div className="hd-card-tabs" role="tablist" aria-label="Config backup views">
              <button
                type="button"
                role="tab"
                aria-selected={configTab === "backup"}
                className={`hd-card-tab${configTab === "backup" ? " is-active" : ""}`}
                onClick={() => setConfigTab("backup")}
              >
                Backup
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={configTab === "restore"}
                className={`hd-card-tab${configTab === "restore" ? " is-active" : ""}`}
                onClick={() => setConfigTab("restore")}
              >
                Restore
              </button>
            </div>
            {configTab === "backup" ? (
              <>
                <div className="hd-admin__card-body">
                  <div className="hd-field">
                    <label htmlFor="admin-backup-label">Optional label</label>
                    <input
                      id="admin-backup-label"
                      type="text"
                      value={label}
                      placeholder="e.g. Before Immich tweak"
                      onChange={(e) => setLabel(e.target.value)}
                    />
                  </div>
                  <p className="hd-admin__hint">
                    Saves onto the server under config backups. Export downloads a JSON copy as well.
                  </p>
                </div>
                <div className="hd-admin__actions">
                  <button
                    className="hd-btn hd-btn--primary"
                    type="button"
                    disabled={Boolean(busy)}
                    onClick={() => void createBackup({ kind: "full", save: true, download: true })}
                  >
                    {busy === "full" ? "Working…" : "Save & export"}
                  </button>
                  <button
                    className="hd-btn"
                    type="button"
                    disabled={Boolean(busy)}
                    onClick={() => void createBackup({ kind: "full", save: true, download: false })}
                  >
                    Save only
                  </button>
                  <button
                    className="hd-btn"
                    type="button"
                    disabled={Boolean(busy)}
                    onClick={() => void createBackup({ kind: "full", save: false, download: true })}
                  >
                    Export only
                  </button>
                </div>
              </>
            ) : (
              <>
                <div className="hd-admin__card-body">
                  <div className="hd-field">
                    <span className="hd-admin__field-label" id="admin-import-label">
                      Backup file
                    </span>
                    <input
                      id="admin-import-file"
                      ref={fileRef}
                      className="hd-admin__file-input"
                      type="file"
                      accept="application/json,.json"
                      aria-labelledby="admin-import-label"
                      onChange={(e) => onPickFile(e.target.files?.[0] || null)}
                    />
                    <button
                      className={`hd-admin__dropzone${pendingImport ? " is-filled" : ""}`}
                      type="button"
                      onClick={() => fileRef.current?.click()}
                    >
                      {pendingImport ? (
                        <>
                          <strong>{pendingImport.filename}</strong>
                          <span>
                            {pendingImport.kind} · {pendingImport.widgetCount} widgets
                            {pendingImport.hasSettings ? " · settings" : ""}
                            {pendingImport.hasLayouts ? " · layouts" : ""}
                          </span>
                        </>
                      ) : (
                        <>
                          <strong>Choose backup JSON</strong>
                          <span>Click to browse · previously exported Homedash backup</span>
                        </>
                      )}
                    </button>
                  </div>
                  {pendingImport ? (
                    <div className="hd-admin__import-preview">
                      <div className="hd-admin__checks">
                        <label className={!pendingImport.hasSettings ? "is-disabled" : undefined}>
                          <input
                            type="checkbox"
                            checked={importParts.settings}
                            disabled={!pendingImport.hasSettings}
                            onChange={(e) => setImportParts((p) => ({ ...p, settings: e.target.checked }))}
                          />
                          Settings & appearance
                        </label>
                        <label className={!pendingImport.hasLayouts ? "is-disabled" : undefined}>
                          <input
                            type="checkbox"
                            checked={importParts.layouts}
                            disabled={!pendingImport.hasLayouts}
                            onChange={(e) => setImportParts((p) => ({ ...p, layouts: e.target.checked }))}
                          />
                          Page layouts
                        </label>
                        <label>
                          <input
                            type="checkbox"
                            checked={importParts.widgets}
                            onChange={(e) => setImportParts((p) => ({ ...p, widgets: e.target.checked }))}
                          />
                          Widget credentials
                        </label>
                      </div>
                    </div>
                  ) : (
                    <p className="hd-admin__hint">Pick a file to unlock restore options.</p>
                  )}
                </div>
                <div className="hd-admin__actions">
                  <button
                    className="hd-btn hd-btn--primary"
                    type="button"
                    disabled={Boolean(busy) || !pendingImport}
                    onClick={() => void runImport(true)}
                  >
                    {busy === "import" ? "Restoring…" : "Restore & keep copy"}
                  </button>
                  <button
                    className="hd-btn"
                    type="button"
                    disabled={Boolean(busy) || !pendingImport}
                    onClick={() => void runImport(false)}
                  >
                    Restore only
                  </button>
                </div>
              </>
            )}
          </article>

          <CleanupCard {...cleanup} />
        </div>

        <div className="hd-admin__pair">
          <SystemBackupCard />
          <BookmarksBackupCard />
        </div>

        <CleanupJobPanel job={cleanup.job} />

        <article className="hd-panel-card hd-admin__card hd-admin__card--span">
          <header className="hd-panel-card__row">
            <div>
              <h2>Widget configs</h2>
              <p>Back up one widget or a selection — credentials only, no layouts.</p>
            </div>
            <div className="hd-admin__actions hd-admin__actions--compact">
              <button className="hd-btn" type="button" onClick={() => selectFiltered(true)}>
                Select shown
              </button>
              <button className="hd-btn" type="button" onClick={() => selectFiltered(false)}>
                Clear
              </button>
            </div>
          </header>
          <div className="hd-field">
            <label htmlFor="admin-widget-search">Filter widgets</label>
            <input
              id="admin-widget-search"
              className="hd-search"
              type="search"
              placeholder="Search by name or id…"
              value={widgetQuery}
              onChange={(e) => setWidgetQuery(e.target.value)}
            />
          </div>
          <div className="hd-admin__widget-list" role="group" aria-label="Widget configs">
            {filteredWidgets.length === 0 ? (
              <div className="hd-admin__hint">No widget config files found.</div>
            ) : (
              filteredWidgets.map((w) => (
                <label key={w.id} className={`hd-admin__widget${selected.has(w.id) ? " is-on" : ""}`}>
                  <input
                    type="checkbox"
                    checked={selected.has(w.id)}
                    onChange={() => toggleWidget(w.id)}
                  />
                  <span className="hd-admin__widget-text">
                    <strong>{w.label}</strong>
                    <span>{w.id}</span>
                  </span>
                </label>
              ))
            )}
          </div>
          <div className="hd-admin__actions">
            <button
              className="hd-btn hd-btn--primary"
              type="button"
              disabled={Boolean(busy) || selectedCount === 0}
              onClick={() =>
                void createBackup({
                  kind: "widgets",
                  widgetIds: [...selected],
                  save: true,
                  download: true,
                })
              }
            >
              {busy === "widgets" ? "Saving…" : `Save & export ${selectedCount || ""} selected`}
            </button>
            <button
              className="hd-btn"
              type="button"
              disabled={Boolean(busy) || selectedCount === 0}
              onClick={() =>
                void createBackup({
                  kind: "widgets",
                  widgetIds: [...selected],
                  save: true,
                  download: false,
                })
              }
            >
              Save selected
            </button>
            <button
              className="hd-btn"
              type="button"
              disabled={Boolean(busy) || widgets.length === 0}
              onClick={() => {
                setSelected(new Set(widgets.map((w) => w.id)));
                void createBackup({
                  kind: "widgets",
                  widgetIds: widgets.map((w) => w.id),
                  save: true,
                  download: true,
                });
              }}
            >
              Backup all widgets
            </button>
          </div>
        </article>

        <article className="hd-panel-card hd-admin__card hd-admin__card--span">
          <header>
            <h2>Saved snapshots</h2>
            <p>Stored on the server under config backups. Export anytime or restore in place.</p>
          </header>
          {backups.length === 0 ? (
            <p className="hd-admin__hint">No snapshots yet — create a full backup above.</p>
          ) : (
            <div className="hd-admin__table-wrap">
              <table className="hd-admin__table">
                <thead>
                  <tr>
                    <th>Snapshot</th>
                    <th>When</th>
                    <th>Size</th>
                    <th>Contents</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {backups.map((b) => (
                    <tr key={b.id}>
                      <td>
                        <strong>{b.label}</strong>
                        <div className="hd-admin__muted">{b.filename}</div>
                      </td>
                      <td>{formatWhen(b.exportedAt)}</td>
                      <td>{formatBytes(b.size)}</td>
                      <td>
                        <span className={`hd-admin__pill hd-admin__pill--${b.kind}`}>{b.kind}</span>
                        {b.hasSettings ? <span className="hd-admin__pill">settings</span> : null}
                        {b.hasLayouts ? <span className="hd-admin__pill">layouts</span> : null}
                        <span className="hd-admin__pill">{b.widgetCount} widgets</span>
                      </td>
                      <td className="hd-admin__row-actions">
                        <button
                          className="hd-btn"
                          type="button"
                          disabled={Boolean(busy)}
                          onClick={() => void exportSaved(b.id, b.filename)}
                        >
                          Export
                        </button>
                        <button
                          className="hd-btn hd-btn--primary"
                          type="button"
                          disabled={Boolean(busy)}
                          onClick={() => void restoreSaved(b.id)}
                        >
                          Restore
                        </button>
                        <button
                          className="hd-btn"
                          type="button"
                          disabled={Boolean(busy)}
                          onClick={() => void deleteSaved(b.id)}
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </article>
      </div>
    </section>
  );
}
