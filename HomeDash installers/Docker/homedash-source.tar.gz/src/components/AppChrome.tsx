"use client";

import { useEffect, useId, useLayoutEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import type { AppSettings } from "@/lib/types";
import { hydratePrivacyBlur, useDashboardStore } from "@/lib/store";
import { applyThemeToDocument } from "@/lib/theme";
import { isTabVisibleOn } from "@/lib/tabs";
import { pickBreakpoint, type Breakpoint } from "@/lib/breakpoints";
import { PrivacyBlurController } from "./PrivacyBlurController";
import { BackgroundRotator } from "./BackgroundRotator";
import {
  enabledHeaderQuickLinks,
  normalizeHeaderQuickLinksPlacement,
  openQuickLinkForDevice,
} from "@/lib/header-quick-links";
import { DashboardSearch } from "./DashboardSearch";

/** Viewport widths at/under this always use the hamburger (tablet + phone). */
const NAV_COMPACT_MQ = 1099;
/** Extra gap required between header regions before we treat them as overlapping. */
const NAV_OVERLAP_GAP = 10;

export function AppChrome({
  settings,
  children,
}: {
  settings: AppSettings;
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const menuId = useId();
  const [menuOpen, setMenuOpen] = useState(false);
  const [viewportBp, setViewportBp] = useState<Breakpoint | null>(null);
  const [overflowCompact, setOverflowCompact] = useState(false);
  const headerRef = useRef<HTMLElement | null>(null);
  const headerStartRef = useRef<HTMLDivElement | null>(null);
  const headerCenterRef = useRef<HTMLDivElement | null>(null);
  const headerEndRef = useRef<HTMLDivElement | null>(null);
  const editMode = useDashboardStore((s) => s.editMode);
  const layout = useDashboardStore((s) => s.layout);
  const activeTabId = useDashboardStore((s) => s.activeTabId);
  const privacyBlur = useDashboardStore((s) => s.privacyBlur);
  const previewTheme = useDashboardStore((s) => s.previewTheme);
  const editBreakpoint = useDashboardStore((s) => s.editBreakpoint);
  const setEditMode = useDashboardStore((s) => s.setEditMode);
  const markDirty = useDashboardStore((s) => s.markDirty);
  const triggerAutoLayout = useDashboardStore((s) => s.triggerAutoLayout);
  const triggerAlignTops = useDashboardStore((s) => s.triggerAlignTops);
  const togglePrivacyBlur = useDashboardStore((s) => s.togglePrivacyBlur);
  const settingsCardEditMode = useDashboardStore((s) => s.settingsCardEditMode);
  const setSettingsCardEditMode = useDashboardStore((s) => s.setSettingsCardEditMode);
  const settingsCardEditablePanel = useDashboardStore((s) => s.settingsCardEditablePanel);
  const triggerSettingsCardSave = useDashboardStore((s) => s.triggerSettingsCardSave);
  const triggerSettingsCardCancel = useDashboardStore((s) => s.triggerSettingsCardCancel);
  const isDashboard = pathname.startsWith("/t/");
  const isSettings = pathname.startsWith("/settings");
  const isAuthPage = pathname === "/login" || pathname === "/setup";
  const [authUser, setAuthUser] = useState<{ username: string; displayName: string; profileImageUrl: string; role: string; permissions: string[]; restrictedLayoutTabIds: string[]; personalTabIds: string[] } | null>(null);
  const hasAuthPermission = (permission: string) =>
    authUser?.role === "admin" || authUser?.permissions.includes("*") || authUser?.permissions.includes(permission);
  const currentTabId = pathname.startsWith("/t/") ? pathname.slice(3).split("/")[0] || "" : "";
  const isPersonalTab = Boolean(currentTabId && authUser?.personalTabIds.includes(currentTabId));
  const canManageLayout = Boolean(
    (hasAuthPermission("layout.manage") || isPersonalTab) &&
    (!currentTabId || isPersonalTab || authUser?.role === "admin" || !authUser?.restrictedLayoutTabIds.includes(currentTabId)),
  );
  const canViewSettings = Boolean(hasAuthPermission("settings.view"));

  useEffect(() => {
    hydratePrivacyBlur();
  }, []);

  useEffect(() => {
    if (isAuthPage) return;
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("/api/auth/me");
        if (!res.ok) return;
        const json = (await res.json()) as { user?: { username?: string; displayName?: string; profileImageUrl?: string; role?: string; permissions?: string[]; restrictedLayoutTabIds?: string[]; personalTabIds?: string[] } };
        if (!cancelled && json.user?.username) {
          setAuthUser({
            username: json.user.username,
            displayName: String(json.user.displayName || ""),
            profileImageUrl: String(json.user.profileImageUrl || ""),
            role: String(json.user.role || "user"),
            permissions: Array.isArray(json.user.permissions) ? json.user.permissions : [],
            restrictedLayoutTabIds: Array.isArray(json.user.restrictedLayoutTabIds) ? json.user.restrictedLayoutTabIds : [],
            personalTabIds: Array.isArray(json.user.personalTabIds) ? json.user.personalTabIds : [],
          });
        }
      } catch {
        // ignore
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [isAuthPage, pathname]);

  useEffect(() => {
    if (authUser && editMode && !canManageLayout) setEditMode(false);
  }, [authUser, editMode, canManageLayout, setEditMode]);

  async function logout() {
    setMenuOpen(false);
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } catch {
      // still redirect
    }
    router.replace("/login");
    router.refresh();
  }

  useEffect(() => {
    const sync = () => setViewportBp(pickBreakpoint(window.innerWidth));
    const syncAfterRotate = () => {
      sync();
      requestAnimationFrame(() => {
        sync();
        window.setTimeout(sync, 50);
        window.setTimeout(sync, 150);
        window.setTimeout(sync, 350);
      });
    };
    sync();
    window.addEventListener("resize", sync);
    window.addEventListener("orientationchange", syncAfterRotate);
    let mql: MediaQueryList | null = null;
    try {
      mql = window.matchMedia("(hover: hover) and (pointer: fine)");
      mql.addEventListener("change", sync);
    } catch {
      /* ignore */
    }
    let orientMql: MediaQueryList | null = null;
    try {
      orientMql = window.matchMedia("(orientation: landscape)");
      orientMql.addEventListener("change", syncAfterRotate);
    } catch {
      /* ignore */
    }
    const screenOrientation = window.screen?.orientation;
    const onScreenOrient = () => syncAfterRotate();
    try {
      screenOrientation?.addEventListener?.("change", onScreenOrient);
    } catch {
      /* ignore */
    }
    return () => {
      window.removeEventListener("resize", sync);
      window.removeEventListener("orientationchange", syncAfterRotate);
      try {
        mql?.removeEventListener("change", sync);
      } catch {
        /* ignore */
      }
      try {
        orientMql?.removeEventListener("change", syncAfterRotate);
      } catch {
        /* ignore */
      }
      try {
        screenOrientation?.removeEventListener?.("change", onScreenOrient);
      } catch {
        /* ignore */
      }
    };
  }, []);

  const liveTheme = previewTheme || settings.theme;

  useEffect(() => {
    applyThemeToDocument(liveTheme);
  }, [liveTheme]);

  const navBp = editMode && editBreakpoint ? editBreakpoint : viewportBp;

  const tabs = useMemo(() => {
    const sorted = [...(settings.tabs || [])].sort((a, b) => a.order - b.order);
    if (!navBp) return sorted;
    return sorted.filter((tab) => isTabVisibleOn(tab, navBp));
  }, [settings.tabs, navBp]);

  useEffect(() => {
    if (!navBp || isSettings || !pathname.startsWith("/t/")) return;
    const slug = pathname.slice(3).split("/")[0];
    if (!slug) return;
    const current = (settings.tabs || []).find((t) => t.id === slug);
    if (!current || isTabVisibleOn(current, navBp)) return;
    const fallback = tabs[0];
    if (fallback) router.replace(`/t/${fallback.id}`);
  }, [navBp, isSettings, pathname, settings.tabs, tabs, router]);

  useEffect(() => {
    setMenuOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMenuOpen(false);
    };
    document.addEventListener("keydown", onKey);
    const { overflow, touchAction } = document.body.style;
    document.body.style.overflow = "hidden";
    document.body.style.touchAction = "none";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = overflow;
      document.body.style.touchAction = touchAction;
    };
  }, [menuOpen]);

  async function saveLayout() {
    if (!layout || !activeTabId) return;
    const res = await fetch("/api/layout", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tabId: activeTabId, layout }),
    });
    if (!res.ok) {
      alert("Failed to save layout");
      return;
    }
    markDirty(false);
    setEditMode(false);
    useDashboardStore.setState({ editBreakpoint: null });
    setMenuOpen(false);
    router.refresh();
  }

  function cancelEdit() {
    setEditMode(false);
    markDirty(false);
    setMenuOpen(false);
    // Drop in-memory edits and reload the persisted layout.
    useDashboardStore.setState({ layout: null, dirty: false, editBreakpoint: null });
    router.refresh();
  }

  const quickLinks = useMemo(
    () => enabledHeaderQuickLinks(liveTheme.headerQuickLinks, liveTheme.headerQuickLinkItems),
    [liveTheme.headerQuickLinks, liveTheme.headerQuickLinkItems],
  );
  const quickLinksPlacement = normalizeHeaderQuickLinksPlacement(liveTheme.headerQuickLinksPlacement);
  const navCompact = overflowCompact || viewportBp === "sm" || viewportBp === "md";

  useLayoutEffect(() => {
    if (isAuthPage) return;

    const header = headerRef.current;
    const start = headerStartRef.current;
    const center = headerCenterRef.current;
    const end = headerEndRef.current;
    if (!header || !start || !center || !end) return;

    let frame = 0;

    const check = () => {
      // Tablet/phone: CSS media query owns compact chrome.
      if (window.innerWidth <= NAV_COMPACT_MQ) {
        setOverflowCompact(false);
        return;
      }

      // Measure in expanded geometry before paint to avoid flicker.
      const hadCompactClass = header.classList.contains("hd-header--compact");
      if (hadCompactClass) header.classList.remove("hd-header--compact");
      void header.offsetWidth;

      const styles = getComputedStyle(header);
      const padX = (parseFloat(styles.paddingLeft) || 0) + (parseFloat(styles.paddingRight) || 0);
      const gap = parseFloat(styles.columnGap || styles.gap) || 12;
      const available = Math.max(0, header.clientWidth - padX);
      const need = start.scrollWidth + center.scrollWidth + end.scrollWidth + gap * 2;

      const tabsEl = center.querySelector(".hd-tabs");
      const qlEl = end.querySelector(".hd-quick-links--header");
      const actionsEl = end.querySelector(".hd-actions--desktop");
      const rightEl = qlEl || actionsEl;

      let collide = false;
      if (tabsEl instanceof HTMLElement && rightEl instanceof HTMLElement) {
        const tr = tabsEl.getBoundingClientRect();
        const rr = rightEl.getBoundingClientRect();
        collide = tr.right + NAV_OVERLAP_GAP > rr.left;
      }
      if (tabsEl instanceof HTMLElement) {
        const brandEl = start.querySelector(".hd-brand") || start;
        const br = brandEl.getBoundingClientRect();
        const tr = tabsEl.getBoundingClientRect();
        if (br.right + NAV_OVERLAP_GAP > tr.left) collide = true;
      }

      const tabsOverflow = Boolean(
        tabsEl instanceof HTMLElement && tabsEl.scrollWidth > tabsEl.clientWidth + 2,
      );
      const headerOverflow = header.scrollWidth > header.clientWidth + 1;
      const shouldCompact = need > available + 1 || collide || tabsOverflow || headerOverflow;

      if (shouldCompact) header.classList.add("hd-header--compact");
      else header.classList.remove("hd-header--compact");

      setOverflowCompact((prev) => (prev === shouldCompact ? prev : shouldCompact));
    };

    const schedule = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(check);
    };

    check();
    const ro = new ResizeObserver(schedule);
    ro.observe(header);
    ro.observe(start);
    ro.observe(center);
    ro.observe(end);
    window.addEventListener("resize", schedule);
    void document.fonts?.ready?.then(schedule);

    return () => {
      cancelAnimationFrame(frame);
      ro.disconnect();
      window.removeEventListener("resize", schedule);
    };
  }, [
    isAuthPage,
    tabs,
    quickLinks.length,
    quickLinksPlacement,
    editMode,
    isDashboard,
    isSettings,
    authUser?.username,
  ]);

  useEffect(() => {
    if (!navCompact) setMenuOpen(false);
  }, [navCompact]);

  const headerQuickLinkButtons =
    quickLinks.length > 0 ? (
      <div
        className={`hd-quick-links hd-quick-links--header hd-quick-links--${quickLinksPlacement}`}
        role="navigation"
        aria-label="Quick links"
      >
        {quickLinks.map((link) => (
          <a
            key={link.id}
            className="hd-quick-link"
            href={link.href}
            target="_blank"
            rel="noopener noreferrer"
            title={link.label}
            aria-label={link.label}
            onClick={(event) => {
              if (!openQuickLinkForDevice(link.id, link.href)) return;
              event.preventDefault();
            }}
          >
            {link.icon}
          </a>
        ))}
      </div>
    ) : null;

  const headerSearchAndQuickLinks = (
    <div className="hd-header-search-links">
      <DashboardSearch settings={settings} appearance={liveTheme.search} />
      {headerQuickLinkButtons}
    </div>
  );

  const drawerQuickLinks =
    quickLinks.length > 0 ? (
      <div className="hd-drawer__section hd-drawer__section--quick-links">
        <div className="hd-drawer__label">Quick links</div>
        <nav className="hd-drawer__quick-links hd-drawer__quick-links--grid" aria-label="Quick links">
          {quickLinks.map((link) => (
            <a
              key={link.id}
              className="hd-drawer__quick-link hd-drawer__quick-link--icon"
              href={link.href}
              target="_blank"
              rel="noopener noreferrer"
              title={link.label}
              aria-label={link.label}
              onClick={(event) => {
                setMenuOpen(false);
                if (!openQuickLinkForDevice(link.id, link.href)) return;
                event.preventDefault();
              }}
            >
              <span className="hd-drawer__quick-link-icon" aria-hidden="true">
                {link.icon}
              </span>
            </a>
          ))}
        </nav>
      </div>
    ) : null;

  const layoutEditButtons = (
    <>
      <button className="hd-btn" type="button" onClick={cancelEdit}>
        Cancel
      </button>
      <button className="hd-btn" type="button" onClick={() => triggerAlignTops()}>
        Align tops
      </button>
      <button className="hd-btn" type="button" onClick={() => triggerAutoLayout()}>
        Auto Layout
      </button>
      <button className="hd-btn hd-btn--primary" type="button" onClick={saveLayout}>
        Save layout
      </button>
    </>
  );

  const editLayoutIcon = (
    <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
      <path
        fill="currentColor"
        d="M4 3h7a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Zm10 0h6a1 1 0 0 1 1 1v5.17l-2 2V5h-5V3ZM4 12h5a1 1 0 0 1 1 1v7a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-7a1 1 0 0 1 1-1Zm13.59.59a2 2 0 0 1 2.82 0l1 1a2 2 0 0 1 0 2.82l-5.88 5.88a1 1 0 0 1-.47.26l-3.75.94a.65.65 0 0 1-.79-.79l.94-3.75a1 1 0 0 1 .26-.47l5.87-5.89Zm1.41 1.42-5.67 5.67-.35 1.39 1.39-.35 5.67-5.67a.5.5 0 0 0 0-.71l-.33-.33a.5.5 0 0 0-.71 0Z"
      />
    </svg>
  );

  const settingsIcon = (
    <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
      <path
        fill="currentColor"
        d="M19.14 12.94c.04-.31.06-.63.06-.94s-.02-.63-.06-.94l2.03-1.58a.5.5 0 0 0 .12-.64l-1.92-3.32a.5.5 0 0 0-.6-.22l-2.39.96a7.05 7.05 0 0 0-1.63-.94l-.36-2.54A.5.5 0 0 0 14.9 2h-3.8a.5.5 0 0 0-.49.42l-.36 2.54c-.59.24-1.13.55-1.63.94l-2.39-.96a.5.5 0 0 0-.6.22L3.71 8.02a.5.5 0 0 0 .12.64l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94L3.83 14.7a.5.5 0 0 0-.12.64l1.92 3.32c.14.24.43.34.68.22l2.39-.96c.5.39 1.04.7 1.63.94l.36 2.54c.05.24.25.42.49.42h3.8c.24 0 .44-.18.49-.42l.36-2.54c.59-.24 1.13-.55 1.63-.94l2.39.96c.25.12.54.02.68-.22l1.92-3.32a.5.5 0 0 0-.12-.64l-2.03-1.58ZM12 15.5A3.5 3.5 0 1 1 12 8.5a3.5 3.5 0 0 1 0 7Z"
      />
    </svg>
  );

  const settingsButtonDesktop = canViewSettings ? (
    <Link
      href="/settings"
      className={`hd-btn hd-btn--icon${isSettings ? " hd-btn--primary" : ""}`}
      aria-current={isSettings ? "page" : undefined}
      aria-label="Settings"
      title="Settings"
    >
      {settingsIcon}
    </Link>
  ) : null;

  const settingsEditLayoutButtonDesktop = (
    <button
      className="hd-btn hd-btn--primary hd-btn--icon"
      type="button"
      aria-label="Edit layout"
      title="Edit layout"
      onClick={() => {
        setSettingsCardEditMode(true);
        setMenuOpen(false);
      }}
    >
      {editLayoutIcon}
    </button>
  );

  const settingsEditLayoutButtonDrawer = (
    <button
      className="hd-btn hd-btn--primary"
      type="button"
      onClick={() => {
        setSettingsCardEditMode(true);
        setMenuOpen(false);
      }}
    >
      Edit layout
    </button>
  );

  const settingsCardLayoutEditButtons = (
    <>
      <button
        className="hd-btn"
        type="button"
        onClick={() => {
          triggerSettingsCardCancel();
          setMenuOpen(false);
        }}
      >
        Cancel
      </button>
      <button
        className="hd-btn hd-btn--primary"
        type="button"
        onClick={() => {
          triggerSettingsCardSave();
          setMenuOpen(false);
        }}
      >
        Save layout
      </button>
    </>
  );

  const layoutActionsDesktop = isDashboard && canManageLayout ? (
    editMode ? (
      layoutEditButtons
    ) : (
      <button
        className="hd-btn hd-btn--primary hd-btn--icon"
        type="button"
        aria-label="Edit layout"
        title="Edit layout"
        onClick={() => {
          setEditMode(true);
          setMenuOpen(false);
        }}
      >
        {editLayoutIcon}
      </button>
    )
  ) : isSettings && canManageLayout && settingsCardEditablePanel ? (
    settingsCardEditMode ? settingsCardLayoutEditButtons : settingsEditLayoutButtonDesktop
  ) : null;

  const layoutActionsDrawer = isDashboard && canManageLayout ? (
    editMode ? (
      layoutEditButtons
    ) : (
      <button
        className="hd-btn hd-btn--primary"
        type="button"
        onClick={() => {
          setEditMode(true);
          setMenuOpen(false);
        }}
      >
        Edit layout
      </button>
    )
  ) : isSettings && canManageLayout && settingsCardEditablePanel ? (
    settingsCardEditMode ? settingsCardLayoutEditButtons : settingsEditLayoutButtonDrawer
  ) : null;

  const privacyButton = (
    <button
      className={`hd-btn hd-privacy-btn${privacyBlur ? " is-active" : ""}`}
      type="button"
      aria-pressed={privacyBlur}
      title={privacyBlur ? "Show IPs, URLs, and credentials" : "Blur IPs, URLs, and credentials"}
      onClick={() => togglePrivacyBlur()}
    >
      <svg viewBox="0 0 24 24" width="15" height="15" aria-hidden="true">
        {privacyBlur ? (
          <path
            fill="currentColor"
            d="M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7ZM2 4.27l2.28 2.28.46.46A11.8 11.8 0 0 0 1 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3 2 4.27ZM7.53 9.8l1.55 1.55c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3 .22 0 .44-.03.65-.08l1.55 1.55c-.67.33-1.41.53-2.2.53-2.76 0-5-2.24-5-5 0-.79.2-1.53.53-2.2Zm4.31-.78 3.15 3.15.02-.16c0-1.66-1.34-3-3-3l-.17.01Z"
          />
        ) : (
          <path
            fill="currentColor"
            d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5ZM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5Zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3Z"
          />
        )}
      </svg>
      <span>{privacyBlur ? "Show sensitive" : "Blur IPs / Creds / URLs"}</span>
    </button>
  );

  const logoutTitle = authUser ? `Signed in as ${authUser.username}` : "Sign out";

  const logoutButtonDesktop = (
    <button
      className="hd-btn hd-btn--icon"
      type="button"
      onClick={logout}
      aria-label="Logout"
      title={logoutTitle}
    >
      <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
        <path
          fill="currentColor"
          d="M10 17v-3h4v-4h-4V7l-5 5 5 5Zm9-14H9c-1.1 0-2 .9-2 2v3h2V5h10v14H9v-3H7v3c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2Z"
        />
      </svg>
    </button>
  );

  const logoutButtonDrawer = (
    <button className="hd-btn" type="button" onClick={logout} title={logoutTitle}>
      Logout
    </button>
  );

  if (isAuthPage) {
    return (
      <div className="hd-shell hd-shell--auth">
        <BackgroundRotator theme={liveTheme} />
        {children}
      </div>
    );
  }

  return (
    <div className="hd-shell">
      <BackgroundRotator theme={liveTheme} />
      <PrivacyBlurController />
      <header
        ref={headerRef}
        className={`hd-header hd-header--ql-${quickLinksPlacement}${
          overflowCompact ? " hd-header--compact" : ""
        }`}
      >
        <div className="hd-header-start" ref={headerStartRef}>
          <Link href="/" className="hd-brand" onClick={() => setMenuOpen(false)}>
            {settings.logoUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img className="hd-logo" src={settings.logoUrl} alt="" />
            ) : (
              <div className="hd-logo-fallback">{(settings.appName || "H").charAt(0)}</div>
            )}
            <div className="hd-app-name">{settings.appName || "Homedash"}</div>
          </Link>
          {quickLinksPlacement === "left" ? headerSearchAndQuickLinks : null}
        </div>

        <div className="hd-header-center" ref={headerCenterRef}>
          <nav className="hd-tabs" aria-label="Dashboard tabs">
            {tabs.map((tab) => {
              const href = `/t/${tab.id}`;
              const active = !isSettings && (pathname === href || activeTabId === tab.id);
              return (
                <Link
                  key={tab.id}
                  href={href}
                  className={`hd-tab${active ? " is-active" : ""}`}
                  aria-current={active ? "page" : undefined}
                >
                  {tab.name}
                </Link>
              );
            })}
          </nav>
          {quickLinksPlacement === "center" ? headerSearchAndQuickLinks : null}
        </div>

        <div className="hd-header-end" ref={headerEndRef}>
          {quickLinksPlacement === "right" ? headerSearchAndQuickLinks : null}
          {authUser ? (
            <div className="hd-header-user" title={`Signed in as ${authUser.username}`} aria-label={`Signed in as ${authUser.username}`}>
              <span className="hd-header-user__avatar" aria-hidden="true">
                {authUser.profileImageUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={authUser.profileImageUrl} alt="" />
                ) : (
                  (authUser.displayName || authUser.username).charAt(0).toUpperCase()
                )}
              </span>
              <span className="hd-header-user__copy">
                <small>Signed in</small>
                <strong>{authUser.displayName || authUser.username}</strong>
              </span>
            </div>
          ) : null}
          <div className="hd-actions hd-actions--desktop">
            {layoutActionsDesktop}
            {settingsButtonDesktop}
            {isSettings && authUser?.role === "admin" ? privacyButton : null}
            {logoutButtonDesktop}
          </div>
          <div className="hd-header-end__mobile">
            <DashboardSearch
              settings={settings}
              appearance={liveTheme.search}
              compact
              onOpen={() => setMenuOpen(false)}
            />
            {isDashboard && editMode ? (
              <button
                className="hd-btn hd-btn--primary hd-btn--save-layout-header"
                type="button"
                onClick={() => void saveLayout()}
              >
                Save layout
              </button>
            ) : null}
            {isSettings && authUser?.role === "admin" ? (
              <button
                className={`hd-btn hd-privacy-btn hd-privacy-btn--icon${privacyBlur ? " is-active" : ""}`}
                type="button"
                aria-pressed={privacyBlur}
                aria-label={privacyBlur ? "Show sensitive info" : "Blur IPs, URLs, and credentials"}
                title={privacyBlur ? "Show sensitive info" : "Blur IPs / Creds / URLs"}
                onClick={() => togglePrivacyBlur()}
              >
                <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
                  {privacyBlur ? (
                    <path
                      fill="currentColor"
                      d="M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7ZM2 4.27l2.28 2.28.46.46A11.8 11.8 0 0 0 1 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3 2 4.27ZM7.53 9.8l1.55 1.55c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3 .22 0 .44-.03.65-.08l1.55 1.55c-.67.33-1.41.53-2.2.53-2.76 0-5-2.24-5-5 0-.79.2-1.53.53-2.2Zm4.31-.78 3.15 3.15.02-.16c0-1.66-1.34-3-3-3l-.17.01Z"
                    />
                  ) : (
                    <path
                      fill="currentColor"
                      d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5ZM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5Zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3Z"
                    />
                  )}
                </svg>
              </button>
            ) : null}
            <button
              className={`hd-burger${menuOpen ? " is-open" : ""}`}
              type="button"
              aria-label={menuOpen ? "Close menu" : "Open menu"}
              aria-expanded={menuOpen}
              aria-controls={menuId}
              onClick={() => setMenuOpen((open) => !open)}
            >
              <span className="hd-burger__lines" aria-hidden="true">
                <span />
                <span />
                <span />
              </span>
            </button>
          </div>
        </div>
      </header>

      <div
        className={`hd-nav-scrim${menuOpen ? " is-open" : ""}`}
        aria-hidden={!menuOpen}
        onClick={() => setMenuOpen(false)}
      />

      <aside
        id={menuId}
        className={`hd-drawer${menuOpen ? " is-open" : ""}`}
        aria-hidden={!menuOpen}
        aria-label="Navigation menu"
      >
        <div className="hd-drawer__head">
          <div className="hd-drawer__title">Menu</div>
          <button className="hd-btn hd-btn--ghost" type="button" onClick={() => setMenuOpen(false)}>
            Close
          </button>
        </div>

        <div className="hd-drawer__scroll">
          {drawerQuickLinks}

          <div className="hd-drawer__section hd-drawer__section--tabs">
            <div className="hd-drawer__label">Tabs</div>
            <nav className="hd-drawer__nav" aria-label="Tabs">
              {tabs.map((tab) => {
                const href = `/t/${tab.id}`;
                const active = pathname === href;
                return (
                  <Link
                    key={tab.id}
                    href={href}
                    className={`hd-drawer__link${active ? " is-active" : ""}`}
                    aria-current={active ? "page" : undefined}
                    onClick={() => setMenuOpen(false)}
                  >
                    <span>{tab.name}</span>
                    {active ? <span className="hd-drawer__now">Current</span> : null}
                  </Link>
                );
              })}
            </nav>
          </div>

          {layoutActionsDrawer ? (
            <div className="hd-drawer__section">
              <div className="hd-drawer__label">Layout</div>
              <div className="hd-drawer__actions">{layoutActionsDrawer}</div>
            </div>
          ) : null}

          <div className="hd-drawer__section">
            <div className="hd-drawer__label">Account</div>
            <div className="hd-drawer__actions">
              {authUser ? (
                <div className="hd-drawer__user">Signed in as {authUser.username}</div>
              ) : null}
              {canViewSettings ? (
                <Link
                  href="/settings"
                  className={`hd-btn${isSettings ? " hd-btn--primary" : ""}`}
                  aria-current={isSettings ? "page" : undefined}
                  onClick={() => setMenuOpen(false)}
                >
                  {settingsIcon}
                  Settings
                </Link>
              ) : null}
              {logoutButtonDrawer}
            </div>
          </div>
        </div>
      </aside>

      <main className={`hd-main${isSettings ? " hd-main--settings" : ""}`}>{children}</main>
    </div>
  );
}
