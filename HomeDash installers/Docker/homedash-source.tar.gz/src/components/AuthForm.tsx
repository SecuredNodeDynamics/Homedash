"use client";

import { useEffect, useState } from "react";
import type { FormEvent } from "react";
import { useRouter } from "next/navigation";

type Mode = "login" | "setup";

type CapacitorBridge = {
  isNativePlatform?: () => boolean;
  getPlatform?: () => string;
  Plugins?: {
    Preferences?: {
      remove: (opts: { key: string }) => Promise<void>;
    };
  };
};

declare global {
  interface Window {
    Capacitor?: CapacitorBridge;
  }
}

const SERVER_PREF_KEY = "homedash.serverUrl";

/** Native Capacitor shell, or login opened with ?hd_client=capacitor from the app. */
function isHomedashAppClient(): boolean {
  try {
    if (window.Capacitor?.isNativePlatform?.()) return true;
    return new URLSearchParams(window.location.search).get("hd_client") === "capacitor";
  } catch {
    return false;
  }
}

async function returnToConnectScreen() {
  const cap = window.Capacitor;
  try {
    await cap?.Plugins?.Preferences?.remove({ key: SERVER_PREF_KEY });
  } catch {
    /* connect UI also clears via #change-server */
  }
  const platform = cap?.getPlatform?.() || "";
  window.location.href =
    platform === "ios"
      ? "capacitor://localhost/index.html#change-server"
      : "http://localhost/index.html#change-server";
}

export function AuthForm({
  mode,
  appName,
  logoUrl,
  nextPath = "/",
}: {
  mode: Mode;
  appName: string;
  logoUrl?: string | null;
  nextPath?: string;
}) {
  const router = useRouter();
  const [username, setUsername] = useState(mode === "setup" ? "admin" : "");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [showChangeServer, setShowChangeServer] = useState(false);
  const [forgotOpen, setForgotOpen] = useState(false);
  const [forgotUser, setForgotUser] = useState("");
  const [forgotStatus, setForgotStatus] = useState("");

  useEffect(() => {
    setShowChangeServer(isHomedashAppClient());
  }, []);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError("");
    if (mode === "setup" && password !== confirm) {
      setError("Passwords do not match");
      return;
    }
    setBusy(true);
    try {
      const endpoint = mode === "setup" ? "/api/auth/setup" : "/api/auth/login";
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const json = (await res.json().catch(() => ({}))) as {
        error?: string;
        setup?: boolean;
        mustChangePassword?: boolean;
      };
      if (!res.ok) {
        if (json.setup) {
          router.replace("/setup");
          return;
        }
        setError(json.error || "Request failed");
        return;
      }
      router.replace(json.mustChangePassword ? "/change-password" : (nextPath.startsWith("/") ? nextPath : "/"));
      router.refresh();
    } catch {
      setError("Network error");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="hd-auth">
      <div className="hd-auth__card">
        <div className="hd-auth__brand">
          {logoUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img className="hd-auth__logo" src={logoUrl} alt="" />
          ) : (
            <div className="hd-auth__logo-fallback">{(appName || "H").charAt(0)}</div>
          )}
          <div>
            <div className="hd-auth__app">{appName || "Homedash"}</div>
            <div className="hd-auth__sub">
              {mode === "setup" ? "Create the admin account" : "Sign in to continue"}
            </div>
          </div>
        </div>

        <form className="hd-auth__form" onSubmit={onSubmit}>
          <label className="hd-auth__field">
            <span>Username</span>
            <input
              autoComplete="username"
              autoFocus
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              minLength={2}
              maxLength={64}
              pattern="[A-Za-z0-9._\-]+"
              title="Letters, numbers, . _ -"
            />
          </label>
          <label className="hd-auth__field">
            <span>Password</span>
            <input
              type="password"
              autoComplete={mode === "setup" ? "new-password" : "current-password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={mode === "setup" ? 8 : 6}
            />
          </label>
          {mode === "setup" ? (
            <label className="hd-auth__field">
              <span>Confirm password</span>
              <input
                type="password"
                autoComplete="new-password"
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                required
                minLength={8}
              />
            </label>
          ) : null}

          {error ? <div className="hd-auth__error">{error}</div> : null}

          <button className="hd-btn hd-btn--primary hd-auth__submit" type="submit" disabled={busy}>
            {busy ? "Please wait…" : mode === "setup" ? "Create admin" : "Sign in"}
          </button>
          {mode === "login" ? <button type="button" className="hd-auth__forgot" onClick={() => { setForgotUser(username); setForgotStatus(""); setForgotOpen(true); }}>Forgot password?</button> : null}

          {showChangeServer ? (
            <button
              type="button"
              className="hd-auth__change-server"
              disabled={busy}
              onClick={() => {
                void returnToConnectScreen();
              }}
            >
              Change server
            </button>
          ) : null}
        </form>
      </div>
      {forgotOpen ? (
        <div className="hd-modal-scrim" role="presentation" onClick={() => setForgotOpen(false)}>
          <div className="hd-modal hd-auth__forgot-modal" role="dialog" aria-modal="true" onClick={(event) => event.stopPropagation()}>
            <header className="hd-modal__head"><div><div className="hd-settings__kicker">Account recovery</div><h2>Request password reset</h2><p>Enter your username. An administrator will assign a temporary password.</p></div><button className="hd-btn" type="button" onClick={() => setForgotOpen(false)}>Close</button></header>
            <label className="hd-auth__field"><span>Username</span><input autoFocus value={forgotUser} onChange={(event) => setForgotUser(event.target.value)} /></label>
            {forgotStatus ? <div className="hd-auth__notice">{forgotStatus}</div> : null}
            <button className="hd-btn hd-btn--primary" type="button" disabled={!forgotUser.trim()} onClick={async () => {
              const response = await fetch("/api/auth/forgot-password", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username: forgotUser }) });
              const data = await response.json().catch(() => ({}));
              setForgotStatus(data.message || data.error || "Request submitted.");
            }}>Submit reset request</button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
