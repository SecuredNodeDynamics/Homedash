"use client";

import { useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import type { ThemeSettings } from "@/lib/types";
import { normalizeThemeBackground, themeBackgroundUrls } from "@/lib/theme";

function pickNextIndex(length: number, current: number) {
  if (length <= 1) return 0;
  let next = current;
  while (next === current) {
    next = Math.floor(Math.random() * length);
  }
  return next;
}

/**
 * Crossfades through wallpaper URLs when theme.backgroundImageMode === "rotate".
 * Static mode is handled by body::before CSS vars.
 */
export function BackgroundRotator({ theme }: { theme: ThemeSettings }) {
  const normalized = useMemo(() => normalizeThemeBackground(theme), [theme]);
  const urls = useMemo(() => themeBackgroundUrls(normalized), [normalized]);
  const enabled = normalized.backgroundImageMode === "rotate" && urls.length > 0;
  const intervalMs = (normalized.backgroundImageRotateSeconds || 120) * 1000;
  const transition = normalized.backgroundImageTransition || "fade";
  const transitionMs = normalized.backgroundImageTransitionMs || 1400;
  const urlsKey = urls.join("|");

  const [aUrl, setAUrl] = useState("");
  const [bUrl, setBUrl] = useState("");
  const [showA, setShowA] = useState(true);
  const indexRef = useRef(0);
  const showARef = useRef(true);

  useEffect(() => {
    showARef.current = showA;
  }, [showA]);

  useEffect(() => {
    if (!enabled) {
      setAUrl("");
      setBUrl("");
      setShowA(true);
      indexRef.current = 0;
      return;
    }
    const start = Math.floor(Math.random() * urls.length);
    indexRef.current = start;
    setAUrl(urls[start]);
    setBUrl("");
    setShowA(true);
    showARef.current = true;
  }, [enabled, urlsKey]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!enabled || urls.length < 2) return;

    const timer = window.setInterval(() => {
      const next = pickNextIndex(urls.length, indexRef.current);
      indexRef.current = next;
      const nextUrl = urls[next];
      const currentlyA = showARef.current;
      if (currentlyA) {
        setBUrl(nextUrl);
        window.requestAnimationFrame(() => {
          window.requestAnimationFrame(() => {
            setShowA(false);
            showARef.current = false;
          });
        });
      } else {
        setAUrl(nextUrl);
        window.requestAnimationFrame(() => {
          window.requestAnimationFrame(() => {
            setShowA(true);
            showARef.current = true;
          });
        });
      }
    }, intervalMs);

    return () => window.clearInterval(timer);
  }, [enabled, urlsKey, intervalMs, urls]);

  useEffect(() => {
    if (!enabled) return;
    for (const url of urls) {
      const img = new Image();
      img.src = url;
    }
  }, [enabled, urlsKey]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!enabled) return null;

  const opacity = normalized.backgroundImageOpacity ?? 0.35;
  const blur = normalized.backgroundImageBlur ?? 0;

  function layerStyle(url: string, visible: boolean): CSSProperties | undefined {
    if (!url) return undefined;
    const safe = url.replace(/[)\\s]/g, (ch) => encodeURIComponent(ch));
    const style: CSSProperties = {
      backgroundImage: `url(${safe})`,
      ["--hd-bg-layer-opacity" as string]: String(opacity),
      ["--hd-bg-layer-blur" as string]: blur ? `${blur}px` : "0px",
      transitionDuration: `${transitionMs}ms`,
    };
    if (transition === "blur") {
      // Hidden layers get an extra soft blur on top of the theme blur.
      style.filter = visible
        ? blur
          ? `blur(${blur}px)`
          : undefined
        : `blur(${Math.max(blur, 14)}px)`;
    } else if (blur) {
      style.filter = `blur(${blur}px)`;
    }
    return style;
  }

  function layerClass(visible: boolean) {
    return [
      "hd-bg-rotator__layer",
      `is-${transition}`,
      visible ? "is-visible is-front" : "is-hidden",
    ].join(" ");
  }

  return (
    <div
      className={`hd-bg-rotator is-${transition}`}
      style={{ ["--hd-bg-transition-ms" as string]: `${transitionMs}ms` }}
      aria-hidden="true"
    >
      {aUrl ? <div className={layerClass(showA)} style={layerStyle(aUrl, showA)} /> : null}
      {bUrl ? <div className={layerClass(!showA)} style={layerStyle(bUrl, !showA)} /> : null}
    </div>
  );
}
