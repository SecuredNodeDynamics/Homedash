"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";

function downloadJson(filename: string, data: unknown) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

type Pending = {
  filename: string;
  raw: string;
  bookmarkCount: number;
  groupCount: number;
};

/** Backup + restore for just the bookmark catalog & groups, separate from the full system backup. */
export function BookmarksBackupCard() {
  const router = useRouter();
  const fileRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [pending, setPending] = useState<Pending | null>(null);
  const [merge, setMerge] = useState(false);

  function clearFlash() {
    setMessage("");
    setError("");
  }

  async function runBackup() {
    clearFlash();
    setBusy("backup");
    try {
      const res = await fetch("/api/admin/backup/bookmarks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ save: true, download: true }),
      });
      const json = (await res.json().catch(() => ({}))) as {
        error?: string;
        filename?: string;
        backup?: unknown;
      };
      if (!res.ok) throw new Error(json.error || "Backup failed");
      if (json.backup) downloadJson(json.filename || "homedash-bookmarks.json", json.backup);
      setMessage(`Backed up and exported ${json.filename || "bookmarks backup"}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Backup failed");
    } finally {
      setBusy(null);
    }
  }

  function onPickFile(file: File | null) {
    clearFlash();
    setPending(null);
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const raw = String(reader.result || "");
        const parsed = JSON.parse(raw) as {
          kind?: string;
          bookmarks?: unknown[];
          bookmarkGroups?: unknown[];
        };
        if (!parsed || typeof parsed !== "object" || parsed.kind !== "bookmarks") {
          throw new Error("Not a bookmarks backup file");
        }
        setPending({
          filename: file.name,
          raw,
          bookmarkCount: Array.isArray(parsed.bookmarks) ? parsed.bookmarks.length : 0,
          groupCount: Array.isArray(parsed.bookmarkGroups) ? parsed.bookmarkGroups.length : 0,
        });
      } catch {
        setError("Could not read that file (need a Homedash bookmarks export)");
      }
    };
    reader.readAsText(file);
  }

  async function runRestore() {
    if (!pending) return;
    if (
      !window.confirm(
        merge
          ? "Merge these bookmarks into your current catalog? Matching ids will be overwritten."
          : "Replace your current bookmarks & groups with this backup?",
      )
    ) {
      return;
    }
    clearFlash();
    setBusy("restore");
    try {
      const res = await fetch("/api/admin/backup/bookmarks/restore", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ backup: pending.raw, merge }),
      });
      const json = (await res.json().catch(() => ({}))) as {
        error?: string;
        result?: { bookmarks: number; groups: number };
      };
      if (!res.ok) throw new Error(json.error || "Restore failed");
      const r = json.result;
      setMessage(`Restored ${r?.bookmarks ?? 0} bookmarks · ${r?.groups ?? 0} groups`);
      setPending(null);
      if (fileRef.current) fileRef.current.value = "";
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Restore failed");
    } finally {
      setBusy(null);
    }
  }

  return (
    <article className="hd-panel-card hd-admin__card">
      <header>
        <h2>Bookmarks backup &amp; restore</h2>
        <p>Snapshot just your bookmark catalog and groups, separate from the full system backup.</p>
      </header>
      <div className="hd-admin__card-body">
        {message || error ? (
          <div className={`hd-admin__flash${error ? " hd-admin__flash--error" : ""}`} role="status">
            {error || message}
          </div>
        ) : null}
        <input
          ref={fileRef}
          className="hd-admin__file-input"
          type="file"
          accept="application/json,.json"
          onChange={(e) => onPickFile(e.target.files?.[0] || null)}
        />
        <button
          className={`hd-admin__dropzone${pending ? " is-filled" : ""}`}
          type="button"
          onClick={() => fileRef.current?.click()}
        >
          {pending ? (
            <>
              <strong>{pending.filename}</strong>
              <span>
                {pending.bookmarkCount} bookmarks · {pending.groupCount} groups
              </span>
            </>
          ) : (
            <>
              <strong>Choose bookmarks JSON</strong>
              <span>Click to browse · previously exported bookmarks backup</span>
            </>
          )}
        </button>
        {pending ? (
          <div className="hd-admin__checks">
            <label>
              <input type="checkbox" checked={merge} onChange={(e) => setMerge(e.target.checked)} />
              Merge with current bookmarks instead of replacing
            </label>
          </div>
        ) : null}
      </div>
      <div className="hd-admin__actions">
        <button
          className="hd-btn hd-btn--primary"
          type="button"
          disabled={Boolean(busy)}
          onClick={() => void runBackup()}
        >
          {busy === "backup" ? "Backing up…" : "Back up bookmarks now"}
        </button>
        <button
          className="hd-btn"
          type="button"
          disabled={Boolean(busy) || !pending}
          onClick={() => void runRestore()}
        >
          {busy === "restore" ? "Restoring…" : "Restore from file"}
        </button>
      </div>
    </article>
  );
}
