"use client";

import { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import type { BookmarkGroup, BookmarkItem } from "@/lib/types";
import { DEFAULT_BOOKMARK_GROUP_ID, uniqueBookmarkGroupId } from "@/lib/bookmarks";
import { UnsavedChangesDialog } from "@/components/UnsavedChangesDialog";

function newId() {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }
  return `bm-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function emptyDraft(groupId: string): BookmarkItem {
  return {
    id: newId(),
    name: "",
    icon: "",
    ip: "",
    localUrl: "",
    publicUrl: "",
    category: "",
    groupId,
  };
}

export function BookmarksEditor({
  bookmarks,
  groups,
  onChangeBookmarks,
  onChangeGroups,
  onPickIcon,
  onUploadIcon,
  iconAssignment,
  onIconAssignmentConsumed,
  query,
  formOpen,
  onFormOpenChange,
  addToken,
}: {
  bookmarks: BookmarkItem[];
  groups: BookmarkGroup[];
  onChangeBookmarks: (next: BookmarkItem[]) => void;
  onChangeGroups: (next: BookmarkGroup[]) => void;
  onPickIcon: (bookmarkId: string) => void;
  onUploadIcon: (file: File) => Promise<string>;
  iconAssignment: { id: string; url: string } | null;
  onIconAssignmentConsumed: () => void;
  query: string;
  formOpen: boolean;
  onFormOpenChange: (open: boolean) => void;
  addToken: number;
}) {
  const sortedGroups = useMemo(
    () => [...groups].sort((a, b) => a.order - b.order),
    [groups],
  );
  const [activeGroupId, setActiveGroupId] = useState<string>("all");
  const [groupModal, setGroupModal] = useState<{ mode: "create" } | { mode: "edit"; id: string } | null>(null);
  const [groupName, setGroupName] = useState("");
  const [groupMembers, setGroupMembers] = useState<Set<string>>(() => new Set());
  const [groupQuery, setGroupQuery] = useState("");
  const [groupError, setGroupError] = useState("");
  const [groupDeleteId, setGroupDeleteId] = useState<string | null>(null);
  const [draft, setDraft] = useState<BookmarkItem>(() =>
    emptyDraft(sortedGroups[0]?.id || DEFAULT_BOOKMARK_GROUP_ID),
  );
  const [editingId, setEditingId] = useState<string | null>(null);
  const [initialDraft, setInitialDraft] = useState<BookmarkItem | null>(null);
  const [confirmClose, setConfirmClose] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState("");

  useEffect(() => {
    if (!iconAssignment) return;
    const { id, url } = iconAssignment;
    if (draft.id === id) {
      setDraft((prev) => ({ ...prev, icon: url }));
    }
    onIconAssignmentConsumed();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [iconAssignment]);

  useEffect(() => {
    if (!addToken) return;
    setEditingId(null);
    const fallback =
      activeGroupId !== "all"
        ? activeGroupId
        : sortedGroups[0]?.id || DEFAULT_BOOKMARK_GROUP_ID;
    const next = emptyDraft(fallback);
    setDraft(next);
    setInitialDraft(next);
  }, [addToken, activeGroupId, sortedGroups]);

  useEffect(() => {
    if (!formOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !confirmClose) requestClose();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [formOpen, editingId, confirmClose, draft, initialDraft]);

  const draftDirty = !!initialDraft && JSON.stringify(draft) !== JSON.stringify(initialDraft);
  const draftCanSave = !!draft.name.trim() && !!(draft.localUrl?.trim() || draft.publicUrl.trim());

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return bookmarks.filter((item) => {
      if (activeGroupId !== "all" && (item.groupId || "") !== activeGroupId) return false;
      if (!q) return true;
      const groupName = sortedGroups.find((g) => g.id === item.groupId)?.name || "";
      const hay = [item.name, item.ip, item.publicUrl, item.category, groupName]
        .join(" ")
        .toLowerCase();
      return hay.includes(q);
    });
  }, [bookmarks, query, activeGroupId, sortedGroups]);

  const groupPickList = useMemo(() => {
    const q = groupQuery.trim().toLowerCase();
    if (!q) return bookmarks;
    return bookmarks.filter((item) =>
      [item.name, item.ip, item.publicUrl, item.localUrl, item.category].join(" ").toLowerCase().includes(q),
    );
  }, [bookmarks, groupQuery]);

  useEffect(() => {
    if (!groupModal && !groupDeleteId) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      if (groupDeleteId) setGroupDeleteId(null);
      else closeGroupModal();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [groupModal, groupDeleteId]);

  function closeForm() {
    setConfirmClose(false);
    setEditingId(null);
    setInitialDraft(null);
    setDraft(emptyDraft(sortedGroups[0]?.id || DEFAULT_BOOKMARK_GROUP_ID));
    onFormOpenChange(false);
  }

  function requestClose() {
    if (draftDirty) setConfirmClose(true);
    else closeForm();
  }

  function startEdit(item: BookmarkItem) {
    setEditingId(item.id);
    const next = { ...item, groupId: item.groupId || sortedGroups[0]?.id };
    setDraft(next);
    setInitialDraft(next);
    onFormOpenChange(true);
  }

  function saveDraft() {
    const name = draft.name.trim();
    const publicUrl = draft.publicUrl.trim();
    const localUrl = draft.localUrl?.trim() || "";
    if (!name || (!publicUrl && !localUrl)) return;

    const nextItem: BookmarkItem = {
      id: draft.id || newId(),
      name,
      publicUrl,
      icon: draft.icon?.trim() || undefined,
      ip: draft.ip?.trim() || undefined,
      localUrl: localUrl || undefined,
      category: draft.category?.trim() || undefined,
      groupId: draft.groupId || sortedGroups[0]?.id || DEFAULT_BOOKMARK_GROUP_ID,
    };

    if (editingId) {
      onChangeBookmarks(bookmarks.map((item) => (item.id === editingId ? nextItem : item)));
    } else {
      onChangeBookmarks([...bookmarks, nextItem]);
    }
    closeForm();
  }

  function removeItem(id: string) {
    onChangeBookmarks(bookmarks.filter((item) => item.id !== id));
    if (editingId === id) closeForm();
  }

  function moveItem(id: string, dir: -1 | 1) {
    const index = bookmarks.findIndex((item) => item.id === id);
    const target = index + dir;
    if (index < 0 || target < 0 || target >= bookmarks.length) return;
    const next = [...bookmarks];
    const [item] = next.splice(index, 1);
    next.splice(target, 0, item);
    onChangeBookmarks(next);
  }

  function openCreateGroup() {
    setGroupName("");
    setGroupMembers(new Set());
    setGroupQuery("");
    setGroupError("");
    setGroupModal({ mode: "create" });
  }

  function openEditGroup(id: string) {
    const group = sortedGroups.find((g) => g.id === id);
    if (!group) return;
    setGroupName(group.name);
    setGroupMembers(new Set(bookmarks.filter((b) => b.groupId === id).map((b) => b.id)));
    setGroupQuery("");
    setGroupError("");
    setGroupModal({ mode: "edit", id });
  }

  function closeGroupModal() {
    setGroupModal(null);
    setGroupError("");
  }

  function toggleGroupMember(id: string) {
    setGroupMembers((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function saveGroup() {
    if (!groupModal) return;
    const name = groupName.trim();
    if (!name) {
      setGroupError("Give the group a name.");
      return;
    }
    const editingGroupId = groupModal.mode === "edit" ? groupModal.id : null;
    const clash = sortedGroups.some(
      (g) => g.id !== editingGroupId && g.name.trim().toLowerCase() === name.toLowerCase(),
    );
    if (clash) {
      setGroupError("A group with that name already exists.");
      return;
    }

    if (!editingGroupId) {
      const id = uniqueBookmarkGroupId(name, sortedGroups);
      onChangeGroups([...sortedGroups, { id, name, order: sortedGroups.length }]);
      if (groupMembers.size) {
        onChangeBookmarks(
          bookmarks.map((item) => (groupMembers.has(item.id) ? { ...item, groupId: id } : item)),
        );
      }
      setActiveGroupId(id);
    } else {
      const fallback =
        sortedGroups.find((g) => g.id !== editingGroupId)?.id || DEFAULT_BOOKMARK_GROUP_ID;
      onChangeGroups(sortedGroups.map((g) => (g.id === editingGroupId ? { ...g, name } : g)));
      onChangeBookmarks(
        bookmarks.map((item) => {
          const inGroup = item.groupId === editingGroupId;
          const wanted = groupMembers.has(item.id);
          if (wanted && !inGroup) return { ...item, groupId: editingGroupId };
          if (!wanted && inGroup) return { ...item, groupId: fallback };
          return item;
        }),
      );
    }
    closeGroupModal();
  }

  function removeGroup(id: string) {
    if (sortedGroups.length <= 1) return;
    const remaining = sortedGroups
      .filter((g) => g.id !== id)
      .map((g, order) => ({ ...g, order }));
    const fallback = remaining[0]?.id || DEFAULT_BOOKMARK_GROUP_ID;
    onChangeGroups(remaining);
    onChangeBookmarks(
      bookmarks.map((item) => (item.groupId === id ? { ...item, groupId: fallback } : item)),
    );
    if (activeGroupId === id) setActiveGroupId("all");
    setGroupDeleteId(null);
  }

  async function handleUpload(file: File | null) {
    if (!file) return;
    setUploading(true);
    setUploadError("");
    try {
      const url = await onUploadIcon(file);
      setDraft((prev) => ({ ...prev, icon: url }));
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setUploading(false);
    }
  }

  function groupLabel(groupId?: string) {
    return sortedGroups.find((g) => g.id === groupId)?.name || "Ungrouped";
  }

  return (
    <div className="hd-bookmarks">
      <article className="hd-panel-card hd-bookmarks__groups">
        <header className="hd-bookmarks__groups-head">
          <div>
            <h2>Bookmark groups</h2>
            <p>Group your bookmarks, then pick a group on each Bookmarks widget card.</p>
          </div>
          <button className="hd-btn hd-btn--primary" type="button" onClick={openCreateGroup}>
            + New group
          </button>
        </header>
        <div className="hd-bookmarks__group-list">
          {sortedGroups.map((group) => {
            const members = bookmarks.filter((b) => b.groupId === group.id);
            const count = members.length;
            return (
              <div key={group.id} className="hd-bookmarks__group-tile">
                <div className="hd-bookmarks__group-tile-top">
                  <span className="hd-bookmarks__group-title" title={group.name}>
                    {group.name}
                  </span>
                  <span className="hd-bookmarks__group-count">
                    {count} bookmark{count === 1 ? "" : "s"}
                  </span>
                </div>
                <div className="hd-bookmarks__group-logos" aria-hidden>
                  {members.slice(0, 5).map((m) => (
                    <span key={m.id} className="hd-bookmarks__group-logo">
                      {m.icon ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={m.icon} alt="" />
                      ) : (
                        (m.name || "?").charAt(0).toUpperCase()
                      )}
                    </span>
                  ))}
                  {count > 5 ? <span className="hd-bookmarks__group-more">+{count - 5}</span> : null}
                  {!count ? <span className="hd-bookmarks__group-empty">Empty group</span> : null}
                </div>
                <div className="hd-bookmarks__group-actions">
                  <button type="button" className="hd-btn" onClick={() => openEditGroup(group.id)}>
                    Edit
                  </button>
                  <button
                    type="button"
                    className="hd-btn hd-btn--danger-soft"
                    disabled={sortedGroups.length <= 1}
                    title={sortedGroups.length <= 1 ? "Keep at least one group" : `Delete ${group.name}`}
                    onClick={() => setGroupDeleteId(group.id)}
                  >
                    Delete
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </article>

      <div className="hd-bookmarks__meta">
        <div className="hd-bookmarks__filters" role="tablist" aria-label="Filter by group">
          <button
            type="button"
            className={`hd-bookmarks__filter${activeGroupId === "all" ? " is-active" : ""}`}
            onClick={() => setActiveGroupId("all")}
          >
            All
          </button>
          {sortedGroups.map((group) => (
            <button
              key={group.id}
              type="button"
              className={`hd-bookmarks__filter${activeGroupId === group.id ? " is-active" : ""}`}
              onClick={() => setActiveGroupId(group.id)}
            >
              {group.name}
            </button>
          ))}
        </div>
        <span className="hd-bookmarks__count">
          {filtered.length}
          {query.trim() && filtered.length !== bookmarks.length ? ` / ${bookmarks.length}` : ""}{" "}
          bookmark{filtered.length === 1 ? "" : "s"}
        </span>
      </div>

      <div className="hd-bookmarks__grid">
        {!filtered.length ? (
          <div className="hd-bookmarks__empty">
            {bookmarks.length
              ? "No bookmarks match that filter."
              : "No bookmarks yet. Click Add Bookmark to create one."}
          </div>
        ) : (
          filtered.map((item) => (
            <article
              key={item.id}
              className={`hd-bookmarks__card${editingId === item.id ? " is-editing" : ""}`}
            >
              <div className="hd-bookmarks__card-logo">
                {item.icon ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={item.icon} alt="" />
                ) : (
                  <span>{(item.name || "?").charAt(0).toUpperCase()}</span>
                )}
              </div>
              <div className="hd-bookmarks__card-name">{item.name}</div>
              <div className="hd-bookmarks__card-role">{groupLabel(item.groupId)}</div>
              {item.ip ? <div className="hd-bookmarks__card-ip">{item.ip}</div> : null}
              <a className="hd-bookmarks__card-url" href={item.publicUrl || item.localUrl} target="_blank" rel="noreferrer">
                Open
              </a>
              <div className="hd-bookmarks__card-actions">
                <button type="button" className="hd-btn" onClick={() => moveItem(item.id, -1)}>
                  ↑
                </button>
                <button type="button" className="hd-btn" onClick={() => moveItem(item.id, 1)}>
                  ↓
                </button>
                <button type="button" className="hd-btn" onClick={() => startEdit(item)}>
                  Edit
                </button>
                <button type="button" className="hd-btn" onClick={() => removeItem(item.id)}>
                  Remove
                </button>
              </div>
            </article>
          ))
        )}
      </div>

      {formOpen && typeof document !== "undefined"
        ? createPortal(
            <div
              className="hd-modal-scrim"
              role="presentation"
              onClick={requestClose}
            >
              <div
                className="hd-modal hd-modal--bookmark"
                role="dialog"
                aria-modal="true"
                aria-labelledby="hd-bookmark-form-title"
                onClick={(e) => e.stopPropagation()}
              >
                <header className="hd-modal__head">
                  <div>
                    <h2 id="hd-bookmark-form-title">{editingId ? "Edit bookmark" : "Add bookmark"}</h2>
                    <p>Assign it to a group so the matching widget card can show it.</p>
                  </div>
                  <button type="button" className="hd-btn" onClick={requestClose}>
                    Close
                  </button>
                </header>
                <div className="hd-bookmarks__form">
                  <div className="hd-field-row">
                    <div className="hd-field hd-field--wide">
                      <label htmlFor="bm-name">Name</label>
                      <input
                        id="bm-name"
                        type="text"
                        value={draft.name}
                        placeholder="Jellyfin"
                        autoFocus
                        onChange={(e) => setDraft((prev) => ({ ...prev, name: e.target.value }))}
                      />
                    </div>
                    <div className="hd-field">
                      <label htmlFor="bm-group">Group</label>
                      <select
                        id="bm-group"
                        value={draft.groupId || sortedGroups[0]?.id || ""}
                        onChange={(e) => setDraft((prev) => ({ ...prev, groupId: e.target.value }))}
                      >
                        {sortedGroups.map((group) => (
                          <option key={group.id} value={group.id}>
                            {group.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="hd-field">
                      <label htmlFor="bm-category">Category tag</label>
                      <input
                        id="bm-category"
                        type="text"
                        value={draft.category || ""}
                        placeholder="Media server"
                        onChange={(e) => setDraft((prev) => ({ ...prev, category: e.target.value }))}
                      />
                    </div>
                    <div className="hd-field hd-field--wide">
                      <label htmlFor="bm-url">Cloudflare / Public URL</label>
                      <input
                        id="bm-url"
                        type="url"
                        value={draft.publicUrl}
                        placeholder="https://jellyfin.example.com"
                        onChange={(e) => setDraft((prev) => ({ ...prev, publicUrl: e.target.value }))}
                      />
                    </div>
                    <div className="hd-field">
                      <label htmlFor="bm-ip">IP</label>
                      <input
                        id="bm-ip"
                        type="text"
                        value={draft.ip || ""}
                        placeholder="10.128.1.52"
                        onChange={(e) => setDraft((prev) => ({ ...prev, ip: e.target.value }))}
                      />
                    </div>
                    <div className="hd-field hd-field--wide">
                      <label htmlFor="bm-local">Local URL</label>
                      <input
                        id="bm-local"
                        type="url"
                        value={draft.localUrl || ""}
                        placeholder="http://10.128.1.52:8096"
                        onChange={(e) => setDraft((prev) => ({ ...prev, localUrl: e.target.value }))}
                      />
                    </div>
                    <div className="hd-field hd-field--wide">
                      <label htmlFor="bm-logo">Logo</label>
                      <div className="hd-asset-row">
                        {draft.icon ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img className="hd-bookmarks__logo-preview" src={draft.icon} alt="" />
                        ) : (
                          <span className="hd-bookmarks__logo-fallback">?</span>
                        )}
                        <input
                          id="bm-logo"
                          type="url"
                          value={draft.icon || ""}
                          placeholder="Icon URL or pick from library"
                          onChange={(e) => setDraft((prev) => ({ ...prev, icon: e.target.value }))}
                        />
                        <button type="button" className="hd-btn" onClick={() => onPickIcon(draft.id)}>
                          Pick icon
                        </button>
                        <label className="hd-btn">
                          {uploading ? "Uploading…" : "Upload"}
                          <input
                            type="file"
                            accept="image/*,.svg,.webp,.png,.jpg,.jpeg,.gif"
                            hidden
                            onChange={(e) => {
                              const file = e.target.files?.[0] || null;
                              e.target.value = "";
                              void handleUpload(file);
                            }}
                          />
                        </label>
                      </div>
                      {uploadError ? <div className="hd-asset-error">{uploadError}</div> : null}
                    </div>
                  </div>

                  <div className="hd-bookmarks__form-actions">
                    <button type="button" className="hd-btn" onClick={requestClose}>
                      Cancel
                    </button>
                    <button
                      type="button"
                      className="hd-btn hd-btn--primary"
                      onClick={saveDraft}
                      disabled={!draftCanSave}
                    >
                      {editingId ? "Update bookmark" : "Add bookmark"}
                    </button>
                  </div>
                </div>
              </div>
            </div>,
            document.body,
          )
        : null}
      {groupModal && typeof document !== "undefined"
        ? createPortal(
            <div className="hd-modal-scrim" role="presentation" onClick={closeGroupModal}>
              <div
                className="hd-modal hd-modal--bookmark-group"
                role="dialog"
                aria-modal="true"
                aria-labelledby="hd-bookmark-group-title"
                onClick={(e) => e.stopPropagation()}
              >
                <header className="hd-modal__head">
                  <div>
                    <h2 id="hd-bookmark-group-title">
                      {groupModal.mode === "edit" ? "Edit group" : "Create bookmark group"}
                    </h2>
                    <p>
                      {groupModal.mode === "edit"
                        ? "Rename the group and choose which bookmarks belong to it."
                        : "Name your group and optionally add bookmarks you already have."}
                    </p>
                  </div>
                  <button type="button" className="hd-btn" onClick={closeGroupModal}>
                    Close
                  </button>
                </header>

                <div className="hd-field">
                  <label htmlFor="bm-group-name">Group name</label>
                  <input
                    id="bm-group-name"
                    type="text"
                    value={groupName}
                    placeholder="Media, Network, Development…"
                    autoFocus
                    maxLength={60}
                    onChange={(e) => {
                      setGroupName(e.target.value);
                      if (groupError) setGroupError("");
                    }}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        saveGroup();
                      }
                    }}
                  />
                  {groupError ? <div className="hd-asset-error">{groupError}</div> : null}
                </div>

                <div className="hd-bookmarks__assign">
                  <div className="hd-bookmarks__assign-head">
                    <strong>
                      {groupModal.mode === "edit" ? "Bookmarks in this group" : "Add existing bookmarks"}
                    </strong>
                    <span className="hd-bookmarks__assign-count">{groupMembers.size} selected</span>
                  </div>
                  <div className="hd-bookmarks__assign-tools">
                    <input
                      type="search"
                      className="hd-search"
                      value={groupQuery}
                      placeholder="Search bookmarks…"
                      aria-label="Search bookmarks"
                      onChange={(e) => setGroupQuery(e.target.value)}
                    />
                    <button
                      type="button"
                      className="hd-btn"
                      onClick={() =>
                        setGroupMembers((prev) => {
                          const next = new Set(prev);
                          groupPickList.forEach((b) => next.add(b.id));
                          return next;
                        })
                      }
                    >
                      Select shown
                    </button>
                    <button type="button" className="hd-btn" onClick={() => setGroupMembers(new Set())}>
                      Clear
                    </button>
                  </div>
                  <div className="hd-bookmarks__assign-list" role="group" aria-label="Bookmarks">
                    {groupPickList.length ? (
                      groupPickList.map((item) => {
                        const checked = groupMembers.has(item.id);
                        const currentGroup = groupLabel(item.groupId);
                        const editingId2 = groupModal.mode === "edit" ? groupModal.id : null;
                        const elsewhere = item.groupId !== editingId2;
                        return (
                          <label
                            key={item.id}
                            className={`hd-bookmarks__assign-row${checked ? " is-checked" : ""}`}
                          >
                            <input
                              type="checkbox"
                              checked={checked}
                              onChange={() => toggleGroupMember(item.id)}
                            />
                            <span className="hd-bookmarks__assign-logo">
                              {item.icon ? (
                                // eslint-disable-next-line @next/next/no-img-element
                                <img src={item.icon} alt="" />
                              ) : (
                                (item.name || "?").charAt(0).toUpperCase()
                              )}
                            </span>
                            <span className="hd-bookmarks__assign-name">{item.name}</span>
                            {elsewhere ? (
                              <span className="hd-bookmarks__assign-tag">in {currentGroup}</span>
                            ) : null}
                          </label>
                        );
                      })
                    ) : (
                      <div className="hd-bookmarks__empty">
                        {bookmarks.length ? "No bookmarks match that search." : "No bookmarks yet — add some first."}
                      </div>
                    )}
                  </div>
                  <p className="hd-bookmarks__assign-note">
                    A bookmark lives in one group, so selected bookmarks move here from their current group.
                    {groupModal.mode === "edit" ? " Unticked bookmarks move back to another group." : ""}
                  </p>
                </div>

                <div className="hd-bookmarks__form-actions">
                  <button type="button" className="hd-btn" onClick={closeGroupModal}>
                    Cancel
                  </button>
                  <button
                    type="button"
                    className="hd-btn hd-btn--primary"
                    onClick={saveGroup}
                    disabled={!groupName.trim()}
                  >
                    {groupModal.mode === "edit" ? "Save group" : "Create group"}
                  </button>
                </div>
              </div>
            </div>,
            document.body,
          )
        : null}

      {groupDeleteId && typeof document !== "undefined"
        ? createPortal(
            <div className="hd-modal-scrim" role="presentation" onClick={() => setGroupDeleteId(null)}>
              <div
                className="hd-modal hd-modal--bookmark-confirm"
                role="alertdialog"
                aria-modal="true"
                onClick={(e) => e.stopPropagation()}
              >
                <header className="hd-modal__head">
                  <div>
                    <h2>Delete “{groupLabel(groupDeleteId)}”?</h2>
                    <p>
                      Its bookmarks are not deleted — they move to “
                      {sortedGroups.find((g) => g.id !== groupDeleteId)?.name || "General"}”.
                    </p>
                  </div>
                </header>
                <div className="hd-bookmarks__form-actions">
                  <button type="button" className="hd-btn" onClick={() => setGroupDeleteId(null)}>
                    Cancel
                  </button>
                  <button
                    type="button"
                    className="hd-btn hd-btn--danger"
                    onClick={() => removeGroup(groupDeleteId)}
                  >
                    Delete group
                  </button>
                </div>
              </div>
            </div>,
            document.body,
          )
        : null}
      <UnsavedChangesDialog
        open={confirmClose}
        saveDisabled={!draftCanSave || uploading}
        saving={uploading}
        onSave={saveDraft}
        onDiscard={closeForm}
        onKeepEditing={() => setConfirmClose(false)}
      />
    </div>
  );
}
