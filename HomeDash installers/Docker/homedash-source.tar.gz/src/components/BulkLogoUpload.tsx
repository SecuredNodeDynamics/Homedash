"use client";

import { useRef, useState } from "react";

type UploadedLogo = { name: string; url: string };

export function BulkLogoUpload({ onUploaded }: { onUploaded?: (message: string) => void }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<File[]>([]);
  const [uploaded, setUploaded] = useState<UploadedLogo[]>([]);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState("");
  const [error, setError] = useState("");

  function choose(fileList: FileList | null) {
    const next = Array.from(fileList || []).slice(0, 50);
    setFiles(next);
    setUploaded([]);
    setError(fileList && fileList.length > 50 ? "Choose no more than 50 logos at once" : "");
  }

  async function uploadAll() {
    if (!files.length || busy) return;
    setBusy(true);
    setError("");
    const completed: UploadedLogo[] = [];
    try {
      for (let index = 0; index < files.length; index += 1) {
        const file = files[index];
        setProgress(`Uploading ${index + 1} of ${files.length}: ${file.name}`);
        if (file.size <= 0) throw new Error(`${file.name} is empty`);
        if (file.size > 25 * 1024 * 1024) throw new Error(`${file.name} exceeds the 25 MB limit`);
        const data = new FormData();
        data.set("kind", "widget-icon");
        data.set("key", `library-${file.name}`);
        data.set("file", file);
        const response = await fetch("/api/uploads", { method: "POST", body: data });
        const raw = await response.text();
        let body: { error?: string; url?: string } = {};
        try { body = raw ? JSON.parse(raw) : {}; } catch { /* report status below */ }
        if (!response.ok) {
          throw new Error(body.error || `Upload failed for ${file.name} (HTTP ${response.status})`);
        }
        if (!body.url) throw new Error(`${file.name} uploaded but returned no logo URL`);
        completed.push({ name: file.name, url: body.url });
        setUploaded([...completed]);
      }
      setFiles([]);
      if (inputRef.current) inputRef.current.value = "";
      onUploaded?.(`${completed.length} logo${completed.length === 1 ? "" : "s"} added to the icon library`);
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Logo upload failed");
    } finally {
      setBusy(false);
      setProgress("");
    }
  }

  return (
    <article className="hd-panel-card hd-bulk-logos">
      <header>
        <h2>Logo library</h2>
        <p>Upload multiple logos once, then select them from any widget or bookmark icon picker.</p>
      </header>
      <input
        ref={inputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp,image/gif,image/svg+xml,image/x-icon,.ico"
        multiple
        hidden
        onChange={(event) => choose(event.target.files)}
      />
      <button type="button" className="hd-bulk-logos__picker" disabled={busy} onClick={() => inputRef.current?.click()}>
        <strong>{files.length ? `${files.length} logo${files.length === 1 ? "" : "s"} selected` : "Choose logo files"}</strong>
        <span>PNG, JPG, WebP, GIF, SVG, or ICO · up to 50 files</span>
      </button>
      {files.length ? (
        <div className="hd-bulk-logos__selection">
          {files.slice(0, 8).map((file) => <span key={`${file.name}-${file.lastModified}`}>{file.name}</span>)}
          {files.length > 8 ? <span>+{files.length - 8} more</span> : null}
        </div>
      ) : null}
      {uploaded.length ? (
        <div className="hd-bulk-logos__results">
          {uploaded.map((logo) => (
            <div key={logo.url} title={logo.name}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={logo.url} alt="" />
            </div>
          ))}
        </div>
      ) : null}
      {progress ? <div className="hd-asset-hint">{progress}</div> : null}
      {error ? <div className="hd-asset-error">{error}</div> : null}
      <div className="hd-bulk-logos__actions">
        <button type="button" className="hd-btn" disabled={busy || !files.length} onClick={() => { setFiles([]); setError(""); if (inputRef.current) inputRef.current.value = ""; }}>Clear</button>
        <button type="button" className="hd-btn hd-btn--primary" disabled={busy || !files.length} onClick={() => void uploadAll()}>
          {busy ? "Uploading…" : "Upload to logo library"}
        </button>
      </div>
    </article>
  );
}
