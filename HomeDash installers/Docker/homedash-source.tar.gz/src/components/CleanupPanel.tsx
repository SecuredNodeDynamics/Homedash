"use client";

import { useEffect, useRef, useState } from "react";
import type { CleanupSchedule, WidgetAgentJob } from "@/lib/widget-agent";

const ACTIVE_CLEANUP_KEY = "homedash.cleanup.active-job";

export type CleanupOptions = {
  dockerImages: boolean;
  containersNetworks: boolean;
  dockerVolumes: boolean;
  packageCache: boolean;
  systemLogs: boolean;
};

const DEFAULT_OPTIONS: CleanupOptions = {
  dockerImages: true,
  containersNetworks: true,
  dockerVolumes: false,
  packageCache: true,
  systemLogs: true,
};

const LOG_RETENTION_CHOICES = [
  { value: "1", label: "Older than 1 day" },
  { value: "3", label: "Older than 3 days" },
  { value: "7", label: "Older than 7 days" },
  { value: "14", label: "Older than 14 days" },
  { value: "30", label: "Older than 30 days" },
];

const CLEANUP_OPTION_LIST: { key: keyof CleanupOptions; label: string; hint: string }[] = [
  { key: "dockerImages", label: "Images & build cache", hint: "Unused Docker images and the local build cache." },
  { key: "containersNetworks", label: "Containers & networks", hint: "Stopped containers and unused Docker networks." },
  { key: "dockerVolumes", label: "Docker volumes", hint: "Any volume not attached to a running container." },
  { key: "packageCache", label: "Package cache", hint: "Cached apt package files on the host." },
  { key: "systemLogs", label: "Journal logs", hint: "Old systemd journal entries, per the retention below." },
];

type DiskUsage = { total: number; used: number; free: number } | null;

function formatBytes(n: number) {
  if (n < 1024) return `${n} B`;
  const units = ["KB", "MB", "GB", "TB"];
  let value = n / 1024;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }
  return `${value.toFixed(value >= 10 ? 0 : 1)} ${units[unit]}`;
}

const WEEKDAY_LABELS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

export type ScheduleInput = {
  frequency: "daily" | "weekly";
  time: string;
  dayOfWeek: number;
  options: CleanupOptions;
  logRetentionDays: number;
};

function summarizeScheduleTasks(schedule: CleanupSchedule): string {
  const tasks = CLEANUP_OPTION_LIST.filter((opt) => schedule.options[opt.key]).map((opt) => opt.label);
  return tasks.length ? tasks.join(", ") : "No tasks selected";
}

function formatScheduleFrequency(schedule: CleanupSchedule): string {
  if (schedule.frequency === "weekly") return `Weekly · ${WEEKDAY_LABELS[schedule.dayOfWeek] ?? "?"} · ${schedule.time}`;
  return `Daily · ${schedule.time}`;
}

function formatRelativeWhen(iso: string | null | undefined): string {
  if (!iso) return "never";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "never";
  const diffMs = date.getTime() - Date.now();
  const minutes = Math.round(Math.abs(diffMs) / 60_000);
  const label = minutes < 1 ? "under a minute" : minutes < 60 ? `${minutes}m` : minutes < 1440 ? `${Math.round(minutes / 60)}h` : `${Math.round(minutes / 1440)}d`;
  return diffMs >= 0 ? `in ${label}` : `${label} ago`;
}

/** Fetch + mutate cleanup schedules; only polls while `active` (Schedule tab open). */
export function useCleanupSchedules(active: boolean) {
  const [schedules, setSchedules] = useState<CleanupSchedule[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    try {
      const response = await fetch("/api/admin/system/cleanup/schedules", { cache: "no-store" });
      const body = await response.json().catch(() => ({}));
      if (response.ok) setSchedules((body.schedules as CleanupSchedule[]) || []);
    } catch {
      // Host agent temporarily unreachable — keep showing the last known list.
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (!active) return;
    void load();
    const timer = setInterval(() => void load(), 60_000);
    return () => clearInterval(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active]);

  async function createSchedule(input: ScheduleInput): Promise<boolean> {
    setSaving(true);
    setError("");
    try {
      const response = await fetch("/api/admin/system/cleanup/schedules", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(input),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error || "Could not create the schedule");
      await load();
      return true;
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Could not create the schedule");
      return false;
    } finally {
      setSaving(false);
    }
  }

  async function updateSchedule(id: string, input: Partial<ScheduleInput> & { enabled?: boolean }): Promise<boolean> {
    setSaving(true);
    setError("");
    try {
      const response = await fetch(`/api/admin/system/cleanup/schedules/${encodeURIComponent(id)}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(input),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error || "Could not update the schedule");
      await load();
      return true;
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Could not update the schedule");
      return false;
    } finally {
      setSaving(false);
    }
  }

  async function deleteSchedule(id: string): Promise<void> {
    setDeletingId(id);
    setError("");
    try {
      const response = await fetch(`/api/admin/system/cleanup/schedules/${encodeURIComponent(id)}`, {
        method: "DELETE",
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error || "Could not remove the schedule");
      setSchedules((prev) => (prev ? prev.filter((s) => s.id !== id) : prev));
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Could not remove the schedule");
    } finally {
      setDeletingId(null);
    }
  }

  function toggleEnabled(id: string, enabled: boolean) {
    return updateSchedule(id, { enabled });
  }

  return { schedules, loading, error, saving, deletingId, createSchedule, updateSchedule, deleteSchedule, toggleEnabled };
}

/**
 * Shared state + polling logic for the cleanup job, used by both the compact
 * CleanupCard (dropped next to the backup cards) and the full-width
 * CleanupJobPanel (progress/log, rendered underneath).
 */
export function useCleanupJob() {
  const [job, setJob] = useState<WidgetAgentJob | null>(null);
  const [starting, setStarting] = useState(false);
  const [error, setError] = useState("");
  const [options, setOptions] = useState<CleanupOptions>(DEFAULT_OPTIONS);
  const [logRetentionDays, setLogRetentionDays] = useState("3");
  const [disk, setDisk] = useState<DiskUsage>(null);
  const [diskLoading, setDiskLoading] = useState(true);
  const active = !!job && !["complete", "failed"].includes(job.status);
  const lastDiskRefreshJobId = useRef<string | null>(null);

  async function loadDiskUsage() {
    try {
      const response = await fetch("/api/admin/system/status", { cache: "no-store" });
      const body = await response.json().catch(() => ({}));
      if (response.ok && body.disk) setDisk(body.disk as DiskUsage);
    } catch {
      // Host agent temporarily unreachable — keep showing the last known reading.
    } finally {
      setDiskLoading(false);
    }
  }

  useEffect(() => {
    void loadDiskUsage();
  }, []);

  // Once a cleanup job finishes, refresh so the meter reflects reclaimed space.
  useEffect(() => {
    if (job?.status === "complete" && job.id !== lastDiskRefreshJobId.current) {
      lastDiskRefreshJobId.current = job.id;
      void loadDiskUsage();
    }
  }, [job?.status, job?.id]);

  async function recoverJob() {
    const saved = window.localStorage.getItem(ACTIVE_CLEANUP_KEY);
    const path = saved
      ? `/api/admin/widgets/jobs/${encodeURIComponent(saved)}`
      : "/api/admin/widgets/jobs/active";
    try {
      const response = await fetch(path, { cache: "no-store" });
      const body = await response.json().catch(() => ({}));
      const recovered = body.job as WidgetAgentJob | null;
      if (response.ok && recovered?.operation === "cleanup") {
        setJob(recovered);
        if (!["complete", "failed"].includes(recovered.status)) {
          window.localStorage.setItem(ACTIVE_CLEANUP_KEY, recovered.id);
        } else {
          window.localStorage.removeItem(ACTIVE_CLEANUP_KEY);
        }
      } else if (saved) {
        window.localStorage.removeItem(ACTIVE_CLEANUP_KEY);
      }
    } catch {
      // Host agent temporarily unreachable; the button below still works.
    }
  }

  useEffect(() => {
    void recoverJob();
  }, []);

  useEffect(() => {
    if (!active || !job) return;
    let stopped = false;
    let timer: ReturnType<typeof setTimeout>;
    const poll = async () => {
      try {
        const response = await fetch(`/api/admin/widgets/jobs/${encodeURIComponent(job.id)}`, { cache: "no-store" });
        const body = await response.json().catch(() => ({}));
        if (response.ok && body.job && !stopped) {
          const next = body.job as WidgetAgentJob;
          setJob(next);
          if (["complete", "failed"].includes(next.status)) {
            window.localStorage.removeItem(ACTIVE_CLEANUP_KEY);
            return;
          }
        }
      } catch {
        // Transient — keep polling.
      }
      if (!stopped) timer = setTimeout(poll, 1800);
    };
    timer = setTimeout(poll, 900);
    return () => {
      stopped = true;
      clearTimeout(timer);
    };
  }, [active, job?.id]);

  function toggleOption(key: keyof CleanupOptions) {
    setOptions((prev) => ({ ...prev, [key]: !prev[key] }));
  }

  async function runCleanup() {
    if (active || starting) return;
    if (!Object.values(options).some(Boolean)) {
      setError("Choose at least one cleanup task to run");
      return;
    }
    setStarting(true);
    setError("");
    try {
      const response = await fetch("/api/admin/system/cleanup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ options, logRetentionDays: Number(logRetentionDays) }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error || `Cleanup failed to start (HTTP ${response.status})`);
      const next = body.job as WidgetAgentJob;
      setJob(next);
      window.localStorage.setItem(ACTIVE_CLEANUP_KEY, next.id);
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Could not start cleanup");
    } finally {
      setStarting(false);
    }
  }

  return {
    job,
    starting,
    error,
    active,
    options,
    toggleOption,
    logRetentionDays,
    setLogRetentionDays,
    runCleanup,
    disk,
    diskLoading,
    refreshDisk: loadDiskUsage,
  };
}

type CleanupCardProps = ReturnType<typeof useCleanupJob>;

/** Compact action card — meant to sit in the row next to the backup cards. */
export function CleanupCard({
  starting,
  active,
  error,
  options,
  toggleOption,
  logRetentionDays,
  setLogRetentionDays,
  runCleanup,
  disk,
  diskLoading,
  refreshDisk,
}: CleanupCardProps) {
  const [tab, setTab] = useState<"run" | "schedule">("run");
  const schedules = useCleanupSchedules(tab === "schedule");
  const percentUsed = disk && disk.total > 0 ? Math.min(100, Math.round((disk.used / disk.total) * 100)) : null;
  const meterTone = percentUsed == null ? "" : percentUsed >= 90 ? "is-critical" : percentUsed >= 75 ? "is-warning" : "";

  return (
    <article className="hd-panel-card hd-admin__card">
      <header>
        <h2>Cleanup</h2>
        <p>Prune unused Docker resources and clear caches and old logs to reclaim disk space.</p>
      </header>
      <div className="hd-card-tabs" role="tablist" aria-label="Cleanup views">
        <button
          type="button"
          role="tab"
          aria-selected={tab === "run"}
          className={`hd-card-tab${tab === "run" ? " is-active" : ""}`}
          onClick={() => setTab("run")}
        >
          Cleanup
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={tab === "schedule"}
          className={`hd-card-tab${tab === "schedule" ? " is-active" : ""}`}
          onClick={() => setTab("schedule")}
        >
          Schedule
        </button>
      </div>
      {tab === "run" ? (
        <>
          <div className="hd-admin__card-body">
            <div className="hd-storage-meter">
              <div className="hd-storage-meter__head">
                <span className="hd-admin__field-label">Storage</span>
                <button
                  type="button"
                  className="hd-storage-meter__refresh"
                  onClick={() => void refreshDisk()}
                  disabled={diskLoading}
                  aria-label="Refresh storage usage"
                  title="Refresh"
                >
                  ⟳
                </button>
              </div>
              {disk ? (
                <>
                  <div className={`hd-storage-meter__track ${meterTone}`}>
                    <span style={{ width: `${percentUsed ?? 0}%` }} />
                  </div>
                  <div className="hd-storage-meter__legend">
                    <span>
                      <strong>{formatBytes(disk.used)}</strong> used of {formatBytes(disk.total)}
                      {percentUsed != null ? ` (${percentUsed}%)` : ""}
                    </span>
                    <span>{formatBytes(disk.free)} free</span>
                  </div>
                </>
              ) : (
                <p className="hd-admin__hint">
                  {diskLoading ? "Checking storage…" : "Storage usage is unavailable right now."}
                </p>
              )}
            </div>
            <p className="hd-admin__hint">
              Safe to run anytime — keeps images used by running containers. Your dashboard settings, layouts, and
              widget data are never touched.
            </p>
            <div className="hd-admin__field-label">Cleanup tasks</div>
            <div className="hd-cleanup-grid">
              {CLEANUP_OPTION_LIST.map((opt) => (
                <label key={opt.key} className={`hd-cleanup-option${options[opt.key] ? " is-on" : ""}`}>
                  <input
                    type="checkbox"
                    checked={options[opt.key]}
                    onChange={() => toggleOption(opt.key)}
                  />
                  <span className="hd-cleanup-option__text">
                    <strong>{opt.label}</strong>
                    <span>{opt.hint}</span>
                  </span>
                </label>
              ))}
            </div>
            {options.dockerVolumes ? (
              <p className="hd-admin__hint">
                Volume pruning removes any Docker volume not attached to a running container — double-check nothing
                else on the host depends on one before running this.
              </p>
            ) : null}
            {options.systemLogs ? (
              <div className="hd-field">
                <label htmlFor="admin-cleanup-log-retention">Journal log retention</label>
                <select
                  id="admin-cleanup-log-retention"
                  value={logRetentionDays}
                  onChange={(e) => setLogRetentionDays(e.target.value)}
                >
                  {LOG_RETENTION_CHOICES.map((choice) => (
                    <option key={choice.value} value={choice.value}>
                      {choice.label}
                    </option>
                  ))}
                </select>
              </div>
            ) : null}
            {error ? <div className="hd-modal__error">{error}</div> : null}
          </div>
          <div className="hd-admin__actions">
            <button
              type="button"
              className="hd-btn hd-btn--primary"
              disabled={active || starting}
              onClick={() => void runCleanup()}
            >
              {starting ? "Starting…" : active ? "Cleanup running…" : "Run cleanup"}
            </button>
          </div>
        </>
      ) : (
        <CleanupScheduleTab {...schedules} />
      )}
    </article>
  );
}

type CleanupScheduleTabProps = ReturnType<typeof useCleanupSchedules>;

function defaultScheduleForm(): ScheduleInput {
  return { frequency: "daily", time: "03:00", dayOfWeek: 0, options: { ...DEFAULT_OPTIONS }, logRetentionDays: 3 };
}

function scheduleFormFrom(schedule: CleanupSchedule): ScheduleInput {
  return {
    frequency: schedule.frequency,
    time: schedule.time,
    dayOfWeek: schedule.dayOfWeek,
    options: { ...schedule.options },
    logRetentionDays: schedule.logRetentionDays,
  };
}

/** Schedule tab — list of recurring cleanup jobs, plus an inline add/edit form. */
function CleanupScheduleTab({
  schedules,
  loading,
  error,
  saving,
  deletingId,
  createSchedule,
  updateSchedule,
  deleteSchedule,
  toggleEnabled,
}: CleanupScheduleTabProps) {
  const [editingId, setEditingId] = useState<string | null>(null); // null = closed, "new" = add form, else schedule id
  const [form, setForm] = useState<ScheduleInput>(defaultScheduleForm());
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  function openAdd() {
    setForm(defaultScheduleForm());
    setConfirmDeleteId(null);
    setEditingId("new");
  }

  function openEdit(schedule: CleanupSchedule) {
    setForm(scheduleFormFrom(schedule));
    setConfirmDeleteId(null);
    setEditingId(schedule.id);
  }

  function toggleFormOption(key: keyof CleanupOptions) {
    setForm((prev) => ({ ...prev, options: { ...prev.options, [key]: !prev.options[key] } }));
  }

  async function submitForm() {
    const ok = editingId === "new" ? await createSchedule(form) : await updateSchedule(editingId as string, form);
    if (ok) setEditingId(null);
  }

  return (
    <div className="hd-admin__card-body hd-cleanup-schedule">
      <p className="hd-admin__hint">
        Run cleanup automatically on a recurring basis, using the same tasks and retention as a manual run.
      </p>

      {schedules === null && loading ? (
        <p className="hd-admin__hint">Loading schedules…</p>
      ) : schedules && schedules.length ? (
        <div className="hd-schedule-list">
          {schedules.map((schedule) => (
            <div key={schedule.id} className={`hd-schedule-item${schedule.enabled ? "" : " is-disabled"}`}>
              <div className="hd-schedule-item__head">
                <strong>{formatScheduleFrequency(schedule)}</strong>
                <label className="hd-switch" title={schedule.enabled ? "On" : "Off"}>
                  <input
                    type="checkbox"
                    checked={schedule.enabled}
                    disabled={saving}
                    onChange={() => void toggleEnabled(schedule.id, !schedule.enabled)}
                  />
                  <span />
                </label>
              </div>
              <div className="hd-schedule-item__tasks">{summarizeScheduleTasks(schedule)}</div>
              <div className="hd-schedule-item__meta">
                {schedule.enabled ? `Next run ${formatRelativeWhen(schedule.nextRunAt)}` : "Paused"} · Last run{" "}
                {formatRelativeWhen(schedule.lastRunAt)}
              </div>
              <div className="hd-admin__row-actions">
                <button type="button" className="hd-btn hd-btn--sm" onClick={() => openEdit(schedule)}>
                  Edit
                </button>
                {confirmDeleteId === schedule.id ? (
                  <button
                    type="button"
                    className="hd-btn hd-btn--sm hd-btn--danger"
                    disabled={deletingId === schedule.id}
                    onClick={() => void deleteSchedule(schedule.id).then(() => setConfirmDeleteId(null))}
                  >
                    {deletingId === schedule.id ? "Removing…" : "Confirm remove"}
                  </button>
                ) : (
                  <button type="button" className="hd-btn hd-btn--sm" onClick={() => setConfirmDeleteId(schedule.id)}>
                    Remove
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="hd-admin__hint">No scheduled cleanups yet — add one to run cleanup automatically.</p>
      )}

      {error ? <div className="hd-modal__error">{error}</div> : null}

      {editingId ? (
        <div className="hd-cleanup-schedule__form">
          <div className="hd-field-row">
            <div className="hd-field">
              <label htmlFor="cleanup-sched-freq">Frequency</label>
              <select
                id="cleanup-sched-freq"
                value={form.frequency}
                onChange={(e) => setForm((prev) => ({ ...prev, frequency: e.target.value as ScheduleInput["frequency"] }))}
              >
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
              </select>
            </div>
            {form.frequency === "weekly" ? (
              <div className="hd-field">
                <label htmlFor="cleanup-sched-day">Day</label>
                <select
                  id="cleanup-sched-day"
                  value={form.dayOfWeek}
                  onChange={(e) => setForm((prev) => ({ ...prev, dayOfWeek: Number(e.target.value) }))}
                >
                  {WEEKDAY_LABELS.map((label, index) => (
                    <option key={label} value={index}>
                      {label}
                    </option>
                  ))}
                </select>
              </div>
            ) : null}
            <div className="hd-field">
              <label htmlFor="cleanup-sched-time">Time</label>
              <input
                id="cleanup-sched-time"
                type="time"
                value={form.time}
                onChange={(e) => setForm((prev) => ({ ...prev, time: e.target.value }))}
              />
            </div>
          </div>

          <div className="hd-admin__field-label">Cleanup tasks</div>
          <div className="hd-cleanup-grid">
            {CLEANUP_OPTION_LIST.map((opt) => (
              <label key={opt.key} className={`hd-cleanup-option${form.options[opt.key] ? " is-on" : ""}`}>
                <input type="checkbox" checked={form.options[opt.key]} onChange={() => toggleFormOption(opt.key)} />
                <span className="hd-cleanup-option__text">
                  <strong>{opt.label}</strong>
                  <span>{opt.hint}</span>
                </span>
              </label>
            ))}
          </div>
          {form.options.systemLogs ? (
            <div className="hd-field">
              <label htmlFor="cleanup-sched-retention">Journal log retention</label>
              <select
                id="cleanup-sched-retention"
                value={form.logRetentionDays}
                onChange={(e) => setForm((prev) => ({ ...prev, logRetentionDays: Number(e.target.value) }))}
              >
                {LOG_RETENTION_CHOICES.map((choice) => (
                  <option key={choice.value} value={choice.value}>
                    {choice.label}
                  </option>
                ))}
              </select>
            </div>
          ) : null}

          <div className="hd-admin__actions">
            <button
              type="button"
              className="hd-btn hd-btn--primary"
              disabled={saving || !Object.values(form.options).some(Boolean)}
              onClick={() => void submitForm()}
            >
              {saving ? "Saving…" : editingId === "new" ? "Add schedule" : "Save changes"}
            </button>
            <button type="button" className="hd-btn" disabled={saving} onClick={() => setEditingId(null)}>
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <div className="hd-admin__actions">
          <button type="button" className="hd-btn hd-btn--primary" onClick={openAdd}>
            Add schedule
          </button>
        </div>
      )}
    </div>
  );
}

/** Full-width progress/log panel — rendered underneath the row once a job exists. */
export function CleanupJobPanel({ job }: { job: WidgetAgentJob | null }) {
  const jobLogRef = useRef<HTMLPreElement>(null);
  const jobLogPinnedRef = useRef(true);
  const lastJobIdRef = useRef<string | null>(null);

  // Keep the cleanup log scrolled to the latest line as it streams in, unless
  // the user has manually scrolled up to read earlier output.
  useEffect(() => {
    const node = jobLogRef.current;
    if (!node || !jobLogPinnedRef.current) return;
    node.scrollTop = node.scrollHeight;
  }, [job?.log]);

  // A brand-new job should always start pinned to the bottom.
  useEffect(() => {
    if (job && job.id !== lastJobIdRef.current) {
      lastJobIdRef.current = job.id;
      jobLogPinnedRef.current = true;
      const node = jobLogRef.current;
      if (node) node.scrollTop = node.scrollHeight;
    }
  }, [job?.id]);

  if (!job) return null;

  return (
    <section className={`hd-panel-card hd-system-job is-${job.status}`}>
      <header>
        <div>
          <div className="hd-settings__kicker">Cleanup job</div>
          <h2>{job.message}</h2>
        </div>
        <span className="hd-system-job__status">{job.status}</span>
      </header>
      <div className="hd-system-job__track"><span /></div>
      <details
        open={job.status === "failed"}
        onToggle={(event) => {
          if (!event.currentTarget.open) return;
          jobLogPinnedRef.current = true;
          const node = jobLogRef.current;
          if (node) node.scrollTop = node.scrollHeight;
        }}
      >
        <summary>Cleanup log</summary>
        <pre
          ref={jobLogRef}
          onScroll={(event) => {
            const node = event.currentTarget;
            jobLogPinnedRef.current = node.scrollHeight - node.scrollTop - node.clientHeight < 24;
          }}
        >
          {job.log?.length ? job.log.join("\n") : "Waiting for the host cleanup service…"}
        </pre>
      </details>
    </section>
  );
}
