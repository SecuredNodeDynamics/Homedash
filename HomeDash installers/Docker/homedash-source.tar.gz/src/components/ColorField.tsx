"use client";

import { useEffect, useId, useLayoutEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";

const PRESET_SWATCHES = [
  // Ink / dashboard darks
  "#000000",
  "#060714",
  "#0b0f15",
  "#0c1016",
  "#121820",
  "#1a2230",
  "#243044",
  "#2f3b52",
  // Neutrals
  "#64748b",
  "#94a3b8",
  "#cbd5e1",
  "#e2e8f0",
  "#f1f5f9",
  "#ffffff",
  // Warm
  "#e5a00d",
  "#f59e0b",
  "#fb923c",
  "#f97316",
  "#ef4444",
  "#f43f5e",
  "#e11d48",
  "#be123c",
  // Cool
  "#22d3ee",
  "#06b6d4",
  "#0ea5e9",
  "#3b82f6",
  "#6366f1",
  "#8b5cf6",
  "#a855f7",
  "#d946ef",
  // Nature
  "#84cc16",
  "#22c55e",
  "#10b981",
  "#14b8a6",
  "#65a30d",
  "#15803d",
  // Soft fills (common glass cards)
  "rgb(12, 16, 22)",
  "rgb(18, 24, 32)",
  "rgb(24, 30, 40)",
  "rgba(18, 24, 32, 0.86)",
  "rgba(18, 24, 32, 0.66)",
  "rgba(255, 255, 255, 0.10)",
  "rgba(255, 255, 255, 0.16)",
  "rgba(0, 0, 0, 0.35)",
];

function clampByte(n: number) {
  return Math.max(0, Math.min(255, Math.round(n)));
}

function parseColor(input: string): { r: number; g: number; b: number; a: number } | null {
  const value = input.trim();
  if (!value) return null;

  const hex = value.match(/^#([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i);
  if (hex) {
    let h = hex[1];
    if (h.length === 3) {
      h = h
        .split("")
        .map((ch) => ch + ch)
        .join("");
    }
    const hasAlpha = h.length === 8;
    const r = parseInt(h.slice(0, 2), 16);
    const g = parseInt(h.slice(2, 4), 16);
    const b = parseInt(h.slice(4, 6), 16);
    const a = hasAlpha ? parseInt(h.slice(6, 8), 16) / 255 : 1;
    return { r, g, b, a };
  }

  const rgb = value.match(
    /^rgba?\(\s*([0-9.]+)\s*,\s*([0-9.]+)\s*,\s*([0-9.]+)(?:\s*,\s*([0-9.]+))?\s*\)$/i,
  );
  if (rgb) {
    return {
      r: clampByte(Number(rgb[1])),
      g: clampByte(Number(rgb[2])),
      b: clampByte(Number(rgb[3])),
      a: rgb[4] == null ? 1 : Math.max(0, Math.min(1, Number(rgb[4]))),
    };
  }

  return null;
}

function toHex({ r, g, b }: { r: number; g: number; b: number }) {
  return `#${[r, g, b]
    .map((n) => clampByte(n).toString(16).padStart(2, "0"))
    .join("")}`;
}

function formatColor(
  parts: { r: number; g: number; b: number; a: number },
  preferAlpha: boolean,
) {
  if (preferAlpha || parts.a < 0.999) {
    const a = Math.round(parts.a * 1000) / 1000;
    return `rgba(${parts.r}, ${parts.g}, ${parts.b}, ${a})`;
  }
  return toHex(parts);
}

type PopoverPos = { top: number; left: number; width: number };

export function ColorField({
  id,
  label,
  value,
  placeholder,
  allowEmpty = false,
  preferAlpha = false,
  onChange,
}: {
  id: string;
  label: string;
  value: string;
  placeholder?: string;
  allowEmpty?: boolean;
  /** Prefer rgba() output (good for translucent surfaces). */
  preferAlpha?: boolean;
  onChange: (value: string) => void;
}) {
  const panelId = useId();
  const rootRef = useRef<HTMLDivElement>(null);
  const rowRef = useRef<HTMLDivElement>(null);
  const popoverRef = useRef<HTMLDivElement>(null);
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState<PopoverPos | null>(null);
  const parsed = useMemo(() => parseColor(value), [value]);
  const swatch = parsed ? formatColor({ ...parsed, a: 1 }, false) : "transparent";
  const nativeHex = parsed ? toHex(parsed) : "#808080";
  const alphaPct = Math.round((parsed?.a ?? 1) * 100);

  useLayoutEffect(() => {
    if (!open) {
      setPos(null);
      return;
    }

    const update = () => {
      const anchor = rowRef.current;
      if (!anchor) return;
      const rect = anchor.getBoundingClientRect();
      const gap = 8;
      const margin = 12;
      const width = Math.min(Math.max(rect.width, 280), window.innerWidth - margin * 2);
      const estimatedHeight = popoverRef.current?.offsetHeight || 280;
      const spaceBelow = window.innerHeight - rect.bottom - margin;
      const spaceAbove = rect.top - margin;
      const placeBelow = spaceBelow >= estimatedHeight || spaceBelow >= spaceAbove;
      const top = placeBelow
        ? rect.bottom + gap
        : Math.max(margin, rect.top - gap - estimatedHeight);
      const left = Math.min(
        Math.max(margin, rect.left),
        window.innerWidth - width - margin,
      );
      setPos({ top, left, width });
    };

    update();
    // Re-measure after paint so estimatedHeight matches real popover size.
    const raf = window.requestAnimationFrame(update);
    window.addEventListener("resize", update);
    window.addEventListener("scroll", update, true);
    return () => {
      window.cancelAnimationFrame(raf);
      window.removeEventListener("resize", update);
      window.removeEventListener("scroll", update, true);
    };
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onPointer = (event: MouseEvent) => {
      const target = event.target as Node;
      if (rootRef.current?.contains(target)) return;
      if (popoverRef.current?.contains(target)) return;
      setOpen(false);
    };
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", onPointer);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onPointer);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  function applyParsed(next: { r: number; g: number; b: number; a: number }) {
    onChange(formatColor(next, preferAlpha || next.a < 0.999));
  }

  const popover =
    open && typeof document !== "undefined"
      ? createPortal(
          <div
            id={panelId}
            ref={popoverRef}
            className="hd-color-popover hd-color-popover--portal"
            role="dialog"
            aria-label={`${label} color picker`}
            style={
              pos
                ? {
                    top: pos.top,
                    left: pos.left,
                    width: pos.width,
                  }
                : { visibility: "hidden", top: 0, left: 0 }
            }
          >
            <div className="hd-color-popover__tools">
              <label className="hd-color-popover__native">
                <span>Spectrum</span>
                <input
                  type="color"
                  value={nativeHex}
                  onChange={(e) => {
                    const next = parseColor(e.target.value);
                    if (!next) return;
                    applyParsed({ ...next, a: parsed?.a ?? 1 });
                  }}
                />
              </label>
              <label className="hd-color-popover__alpha">
                <span>Alpha ({alphaPct}%)</span>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={alphaPct}
                  disabled={!parsed && !value}
                  onChange={(e) => {
                    const base = parsed || parseColor(nativeHex);
                    if (!base) return;
                    applyParsed({ ...base, a: Number(e.target.value) / 100 });
                  }}
                />
              </label>
            </div>

            <div className="hd-color-popover__grid" role="listbox" aria-label="Color presets">
              {PRESET_SWATCHES.map((color) => {
                const active = value.trim().toLowerCase() === color.toLowerCase();
                return (
                  <button
                    key={color}
                    type="button"
                    role="option"
                    aria-selected={active}
                    title={color}
                    className={`hd-color-popover__chip${active ? " is-active" : ""}`}
                    style={{ background: color }}
                    onClick={() => {
                      onChange(color);
                      setOpen(false);
                    }}
                  />
                );
              })}
            </div>

            <div className="hd-color-popover__hint">
              Pick a swatch, use the spectrum, or type any hex / rgb / rgba code.
            </div>
          </div>,
          document.body,
        )
      : null;

  return (
    <div className="hd-field hd-color-field" ref={rootRef}>
      <label htmlFor={id}>{label}</label>
      <div className="hd-color-field__row" ref={rowRef}>
        <button
          type="button"
          className="hd-color-field__swatch"
          aria-label={`Open color picker for ${label}`}
          aria-expanded={open}
          aria-controls={panelId}
          style={{
            background:
              parsed == null
                ? "repeating-conic-gradient(#555 0% 25%, #333 0% 50%) 50% / 12px 12px"
                : parsed.a < 0.999
                  ? `linear-gradient(${formatColor(parsed, true)}, ${formatColor(parsed, true)}), repeating-conic-gradient(#555 0% 25%, #333 0% 50%) 50% / 12px 12px`
                  : swatch,
          }}
          onClick={() => setOpen((v) => !v)}
        />
        <input
          id={id}
          type="text"
          spellCheck={false}
          inputMode="text"
          autoComplete="off"
          placeholder={placeholder || "#rrggbb or rgba(…)"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onFocus={() => setOpen(true)}
        />
        {allowEmpty && value ? (
          <button
            type="button"
            className="hd-btn hd-color-field__clear"
            onClick={() => onChange("")}
            title="Clear color"
          >
            Clear
          </button>
        ) : null}
      </div>
      {popover}
    </div>
  );
}
