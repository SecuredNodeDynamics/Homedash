"use client";

import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import GridLayout, { WidthProvider, type Layout } from "react-grid-layout";
import type { AppSettings, DashboardTab, GridItem, LayoutConfig, WidgetChromeSettings } from "@/lib/types";
import { getWidget, listWidgets } from "@/widgets/registry";
import { useDashboardStore } from "@/lib/store";
import { WidgetFrame } from "./WidgetFrame";
import { DeferredWidget } from "./DeferredWidget";
import { WidgetConfigModal } from "./WidgetConfigModal";
import { AddWidgetModal, type AddWidgetChoice } from "./AddWidgetModal";
import { alignItemsByPriority, alignLayoutTops, buildAutoLayoutForBreakpoint, findOpenSlot, pushHiddenBelowVisible, resolveOverlapsAroundPinnedItem, resolveVerticalOverlaps, snapItemToNearbyRow } from "@/lib/auto-layout";
import { fieldsForWidget, parseInstanceId, resolveTabCards } from "@/lib/instances";
import {
  pruneLayoutIds,
  withUpdatedTab,
} from "@/lib/edit-layout";
import { resolveWidgetIcon } from "@/lib/widget-icons";
import { resolveWidgetChrome, mergeWidgetChromeEntry, isChromeExpandActive } from "@/lib/theme";
import { MobileScrollFocus } from "./MobileScrollFocus";
import { WidgetScrollChain } from "./WidgetScrollChain";
import { subscribeTouchPrimary } from "@/lib/pointer";
import {
  BREAKPOINT_LABELS,
  BREAKPOINT_ORDER,
  ORIENTATION_LABELS,
  copyDesktopToBreakpoint,
  ensureBreakpointLayout,
  hasStoredBreakpoint,
  isBreakpointLocked,
  layoutForBreakpoint,
  pickBreakpoint,
  readOrientationMedia,
  resolveGridCols,
  resolveLayoutSlot,
  setBreakpointLocked,
  supportsOrientation,
  type Breakpoint,
  type LayoutSlot,
  type Orientation,
} from "@/lib/breakpoints";

const ResponsiveGrid = WidthProvider(GridLayout);

const ROW_HEIGHT = 56;
const MARGIN = 14;
const MARGIN_Y = MARGIN;

/** Manual resize ceiling — stale auto-layout maxH must never block edit. */
const EDIT_MAX_H = 72;

/** Extra empty rows below content so you can drop widgets onto free cells. */
const EDIT_GRID_PAD_ROWS = 10;
const EDIT_GRID_MIN_ROWS = 18;

function EditLayoutGrid({ cols, rows }: { cols: number; rows: number }) {
  const cells = useMemo(() => Array.from({ length: cols * rows }, (_, i) => i), [cols, rows]);
  return (
    <div className="hd-edit-grid" aria-hidden>
      <div className="hd-edit-grid__cols">
        {Array.from({ length: cols }, (_, i) => (
          <span key={i} className="hd-edit-grid__col-label">
            {i + 1}
          </span>
        ))}
      </div>
      <div className="hd-edit-grid__cells">
        {cells.map((i) => (
          <span key={i} className="hd-edit-grid__cell" />
        ))}
      </div>
    </div>
  );
}

/** Widgets that fill their grid cell and scroll internally when content overflows. */
const FILL_CELL_WIDGETS = new Set([
  "notes",
  "todo",
  "grocery-list",
  "seerr",
  "wizarr",
  "qbit",
  "media-calendar",
  "prowlarr",
  "bookmarks",
  "downtify",
  "immich",
  "navidrome",
  "mealie",
  "tautulli",
  "plex",
  "plex-slider",
  "jellyfin-slider",
  "bookorbit",
  "shelfmark",
  "homeassistant",
  "nextcloud",
  "audiobookshelf",
  "youtube",
  "tailscale",
  "radarr",
  "sonarr",
  "lidarr",
  "proxmox-nodes",
  "wazuh",
  "cloudflare",
  "checkmk",
  "dispatcharr",
  "tracearr",
  "truenas",
  "uk-monitor",
  "jf-monitor",
  "net-topology",
  "invest-stocks",
  "invest-crypto",
  "invest-news",
]);

function contentPxToGridH(px: number) {
  // Snap Expand to whole grid rows so card bottoms land on zone lines,
  // never between them. RGL cell height = h * (rowHeight + margin) - margin.
  const unit = ROW_HEIGHT + MARGIN_Y;
  return Math.max(1, Math.min(72, Math.ceil((Math.max(1, px) + MARGIN_Y) / unit)));
}

/** View-only: apply Expand heights and pack stacked cards so shrink/grow leaves no gap. */
function packExpandLayout(
  items: GridItem[],
  expandIds: Set<string>,
  heightOverrides: Record<string, number>,
): GridItem[] {
  const next = items.map((item) => ({
    ...item,
    h: expandIds.has(item.i) && heightOverrides[item.i] != null ? heightOverrides[item.i] : item.h,
  }));
  const ordered = [...next].sort((a, b) => a.y - b.y || a.x - b.x);
  const placed: GridItem[] = [];
  for (const item of ordered) {
    item.y = placed
      .filter((other) => item.x < other.x + other.w && item.x + item.w > other.x)
      .reduce((max, other) => Math.max(max, other.y + other.h), 0);
    placed.push(item);
  }
  return next;
}

/**
 * Interactive workspaces own an internal viewport and scroll their content.
 * Measuring them as intrinsic content creates a height feedback loop (editors
 * and chat history become taller, then RGL makes their 100%-height root taller).
 */
const FIXED_VIEWPORT_WIDGETS = new Set([
  "ai-chat",
  "ai-trader",
  "code-notes",
  "code-debugger",
]);

function toGridItems(next: Layout[], previous: GridItem[] = []): GridItem[] {
  const prev = new Map(previous.map((item) => [item.i, item]));
  return next.map((item) => {
    const prior = prev.get(item.i);
    const nextItem: GridItem = {
      i: item.i,
      x: item.x,
      y: item.y,
      w: item.w,
      h: item.h,
      minW: item.minW,
      minH: item.minH,
      maxW: item.maxW,
      maxH: item.maxH,
    };
    if (prior?.sizeLocked) nextItem.sizeLocked = true;
    if (prior?.hidden) nextItem.hidden = true;
    if (prior?.order != null) nextItem.order = prior.order;
    return nextItem;
  });
}

export function DashboardBoard({
  settings,
  tab,
  initialLayout,
  isPersonalTab = false,
}: {
  settings: AppSettings;
  tab: DashboardTab;
  initialLayout: LayoutConfig;
  isPersonalTab?: boolean;
}) {
  const editMode = useDashboardStore((s) => s.editMode);
  const dirty = useDashboardStore((s) => s.dirty);
  const setLayout = useDashboardStore((s) => s.setLayout);
  const setLayoutQuiet = useDashboardStore((s) => s.setLayoutQuiet);
  const setActiveTabId = useDashboardStore((s) => s.setActiveTabId);
  const storeLayout = useDashboardStore((s) => s.layout);
  const activeTabId = useDashboardStore((s) => s.activeTabId);
  const editBreakpoint = useDashboardStore((s) => s.editBreakpoint);
  const setEditBreakpoint = useDashboardStore((s) => s.setEditBreakpoint);
  const editOrientation = useDashboardStore((s) => s.editOrientation);
  const setEditOrientation = useDashboardStore((s) => s.setEditOrientation);
  const autoLayoutToken = useDashboardStore((s) => s.autoLayoutToken);
  const alignTopsToken = useDashboardStore((s) => s.alignTopsToken);
  const triggerAutoLayout = useDashboardStore((s) => s.triggerAutoLayout);
  const triggerAlignTops = useDashboardStore((s) => s.triggerAlignTops);
  /** null until measured — avoids lg→xl jump on every reload */
  const [width, setWidth] = useState<number | null>(null);
  const [viewportOrientation, setViewportOrientation] = useState<Orientation>("portrait");
  const minSizeLock = useRef(new Map<string, number>());
  /** True while the user is dragging/resizing — blocks content-fit from fighting the gesture. */
  const interactingRef = useRef(false);
  /** Ignore RGL onLayoutChange echoes after programmatic layout writes (Auto Layout / Align tops). */
  const suppressLayoutCommitRef = useRef(0);
  /** Live RGL layout during drag/resize so controlled mode doesn't snap back. */
  const [liveLayout, setLiveLayout] = useState<GridItem[] | null>(null);
  /** On touch devices, tap a widget first to reveal its resize handles. */
  const [resizeTargetId, setResizeTargetId] = useState<string | null>(null);
  const [touchEdit, setTouchEdit] = useState(false);

  const [boardSettings, setBoardSettings] = useState(settings);
  const [boardTab, setBoardTab] = useState(tab);
  const gridCols = useMemo(() => resolveGridCols(boardSettings.gridCols), [boardSettings.gridCols]);
  const [addOpen, setAddOpen] = useState(false);
  const [canManageWidgets, setCanManageWidgets] = useState(false);
  const [canEditWidgetPlacement, setCanEditWidgetPlacement] = useState(false);
  const [restrictedWidgetIds, setRestrictedWidgetIds] = useState<string[]>([]);
  const [configTarget, setConfigTarget] = useState<{
    instanceId: string;
    label: string;
    widgetId: string;
  } | null>(null);
  const [busy, setBusy] = useState(false);
  /** Live content-fit heights for Expand widgets. Ephemeral — not written to disk. */
  const [heightOverrides, setHeightOverrides] = useState<Record<string, number>>({});
  const expandIdsRef = useRef<Set<string>>(new Set());
  /** Tracks which server layout payload we've already applied — prevents Save exit race. */
  const appliedLayoutSig = useRef<string | null>(null);
  const layoutSig = useMemo(() => JSON.stringify(initialLayout), [initialLayout]);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/auth/me")
      .then((response) => response.json())
      .then((data) => {
        if (cancelled) return;
        const role = String(data.user?.role || "user");
        const permissions = Array.isArray(data.user?.permissions) ? data.user.permissions : [];
        const full = role === "admin" || permissions.includes("*");
        const restrictedLayoutTabs = Array.isArray(data.user?.restrictedLayoutTabIds) ? data.user.restrictedLayoutTabIds : [];
        const personalTabs = Array.isArray(data.user?.personalTabIds) ? data.user.personalTabIds : [];
        const personal = personalTabs.includes(tab.id);
        setRestrictedWidgetIds(Array.isArray(data.user?.restrictedWidgetIds) ? data.user.restrictedWidgetIds : []);
        setCanManageWidgets(full || permissions.includes("widgets.manage"));
        setCanEditWidgetPlacement(
          full ||
            (permissions.includes("layout.manage") && !restrictedLayoutTabs.includes(tab.id)) ||
            personal,
        );
      })
      .catch(() => {
        if (!cancelled) {
          setCanManageWidgets(false);
          setCanEditWidgetPlacement(false);
          setRestrictedWidgetIds([]);
        }
      });
    return () => { cancelled = true; };
  }, [tab.id]);

  useEffect(() => {
    setActiveTabId(tab.id);
    minSizeLock.current.clear();
    setBoardSettings(settings);
    setBoardTab(tab);
    useDashboardStore.setState({
      layout: initialLayout,
      dirty: false,
      editBreakpoint: null,
      editOrientation: null,
    });
    appliedLayoutSig.current = layoutSig;
    // Reset from disk when switching tabs only.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab.id, setActiveTabId]);

  useEffect(() => {
    let targetId = "";
    try {
      targetId = window.sessionStorage.getItem("homedash:focus-widget") || "";
      if (targetId) window.sessionStorage.removeItem("homedash:focus-widget");
    } catch {
      return;
    }
    if (!targetId) return;
    let attempts = 0;
    const focus = () => {
      const target = document.querySelector<HTMLElement>(
        `[data-instance-id="${CSS.escape(targetId)}"]`,
      );
      if (target) {
        target.scrollIntoView({ behavior: "smooth", block: "center" });
        target.classList.add("hd-widget--search-hit");
        window.setTimeout(() => target.classList.remove("hd-widget--search-hit"), 1800);
      } else if (attempts++ < 25) {
        window.setTimeout(focus, 100);
      }
    };
    window.setTimeout(focus, 80);
  }, [tab.id]);

  // Adopt server layout only when the persisted payload actually changes (e.g. after
  // router.refresh). Do NOT re-apply when merely leaving edit mode — that raced Save
  // and restored a stale initialLayout, shrinking cards the user just saved.
  useEffect(() => {
    if (editMode || dirty) return;
    if (appliedLayoutSig.current === layoutSig) {
      setBoardSettings(settings);
      setBoardTab(tab);
      return;
    }
    appliedLayoutSig.current = layoutSig;
    minSizeLock.current.clear();
    setBoardSettings(settings);
    setBoardTab(tab);
    useDashboardStore.setState({ layout: initialLayout, dirty: false });
  }, [layoutSig, initialLayout, settings, tab, editMode, dirty]);

  useEffect(() => {
    if (editMode) {
      setHeightOverrides({});
      return;
    }
    setAddOpen(false);
    setConfigTarget(null);
    setResizeTargetId(null);
    setLiveLayout(null);
    interactingRef.current = false;
  }, [editMode]);

  useEffect(() => {
    const touchEditing = editMode && touchEdit;
    document.body.classList.toggle("hd-layout-editing", editMode);
    document.body.classList.toggle("hd-layout-editing-touch", touchEditing);
    document.documentElement.classList.toggle("hd-layout-editing-touch", touchEditing);

    const androidWindow = window as typeof window & {
      HomedashAndroid?: { setLayoutEditing?: (editing: boolean) => void };
    };
    androidWindow.HomedashAndroid?.setLayoutEditing?.(editMode);

    return () => {
      document.body.classList.remove("hd-layout-editing");
      document.body.classList.remove("hd-layout-editing-touch");
      document.documentElement.classList.remove("hd-layout-editing-touch");
      androidWindow.HomedashAndroid?.setLayoutEditing?.(false);
    };
  }, [editMode, touchEdit]);

  useEffect(() => subscribeTouchPrimary(setTouchEdit), []);

  useEffect(() => {
    if (!editMode || !resizeTargetId) return;
    const onPointerDown = (event: PointerEvent) => {
      const target = event.target as Element | null;
      if (!target?.closest) return;
      if (target.closest(".react-resizable-handle")) return;
      if (target.closest(".hd-edit-banner")) return;
      if (target.closest(".hd-widget__edit-actions")) return;
      if (target.closest(".hd-modal-scrim") || target.closest("[role='dialog']")) return;
      const item = target.closest(".react-grid-item");
      if (item?.classList.contains("is-resize-selected")) return;
      if (item) return; // selection is handled on the item itself
      setResizeTargetId(null);
    };
    document.addEventListener("pointerdown", onPointerDown);
    return () => document.removeEventListener("pointerdown", onPointerDown);
  }, [editMode, resizeTargetId]);

  useLayoutEffect(() => {
    const sync = () => {
      setWidth(window.innerWidth);
      setViewportOrientation(readOrientationMedia());
    };
    /** Dimensions + orientation media often lag behind the orientationchange event. */
    const syncAfterRotate = () => {
      sync();
      requestAnimationFrame(() => {
        sync();
        window.setTimeout(sync, 50);
        window.setTimeout(sync, 150);
        window.setTimeout(sync, 350);
      });
    };
    sync();
    window.addEventListener("resize", sync);
    window.addEventListener("orientationchange", syncAfterRotate);
    let mql: MediaQueryList | null = null;
    try {
      mql = window.matchMedia("(orientation: landscape)");
      mql.addEventListener("change", syncAfterRotate);
    } catch {
      /* ignore */
    }
    let pointerMql: MediaQueryList | null = null;
    try {
      pointerMql = window.matchMedia("(hover: hover) and (pointer: fine)");
      pointerMql.addEventListener("change", sync);
    } catch {
      /* ignore */
    }
    const screenOrientation = window.screen?.orientation;
    const onScreenOrient = () => syncAfterRotate();
    try {
      screenOrientation?.addEventListener?.("change", onScreenOrient);
    } catch {
      /* ignore */
    }
    return () => {
      window.removeEventListener("resize", sync);
      window.removeEventListener("orientationchange", syncAfterRotate);
      try {
        mql?.removeEventListener("change", syncAfterRotate);
      } catch {
        /* ignore */
      }
      try {
        pointerMql?.removeEventListener("change", sync);
      } catch {
        /* ignore */
      }
      try {
        screenOrientation?.removeEventListener?.("change", onScreenOrient);
      } catch {
        /* ignore */
      }
    };
  }, []);

  const cards = useMemo(
    () =>
      resolveTabCards(
        boardTab,
        isPersonalTab
          ? Array.from(
              new Set([
                ...boardSettings.enabledWidgets,
                ...boardTab.widgetIds.map((entry) => parseInstanceId(entry).widgetId),
              ]),
            )
          : boardSettings.enabledWidgets,
        boardSettings.widgetInstances || [],
        (widgetId) => getWidget(widgetId)?.manifest,
      ),
    [boardTab, boardSettings.enabledWidgets, boardSettings.widgetInstances, isPersonalTab],
  );

  const viewportBp = width == null ? null : pickBreakpoint(width);
  const bp: Breakpoint | null =
    editMode && editBreakpoint ? editBreakpoint : viewportBp;
  const orientation: Orientation =
    editMode && editOrientation
      ? editOrientation
      : editMode && editBreakpoint && !supportsOrientation(editBreakpoint)
        ? "portrait"
        : viewportOrientation;
  const slot: LayoutSlot | null = bp ? resolveLayoutSlot(bp, orientation) : null;
  const layout = activeTabId === tab.id && storeLayout ? storeLayout : initialLayout;

  // Expand heights are per-device; drop overrides when the active breakpoint changes.
  useEffect(() => {
    setHeightOverrides({});
  }, [bp, slot]);

  // Hybrid scroll: page scroll by default; focus a widget to unlock inner lists.
  // Always on mobile/tablet (sm/md). On desktop (lg+) only when the primary input is touch.
  const hybridScrollTouch = Boolean(
    !editMode && (bp === "sm" || bp === "md" || touchEdit),
  );
  useEffect(() => {
    if (hybridScrollTouch) {
      document.body.setAttribute("data-hd-mobile-scroll", "hybrid");
    } else {
      document.body.removeAttribute("data-hd-mobile-scroll");
    }
    return () => document.body.removeAttribute("data-hd-mobile-scroll");
  }, [hybridScrollTouch]);

  // Entering edit mode: default picker to the live viewport breakpoint/orientation and seed if empty.
  useEffect(() => {
    if (!editMode || !viewportBp) return;
    if (!editBreakpoint) {
      setEditBreakpoint(viewportBp);
      if (supportsOrientation(viewportBp)) setEditOrientation(viewportOrientation);
      else setEditOrientation("portrait");
      return;
    }
    if (editOrientation == null && supportsOrientation(editBreakpoint)) {
      setEditOrientation(viewportOrientation);
      return;
    }
    const activeSlot = resolveLayoutSlot(
      editBreakpoint,
      supportsOrientation(editBreakpoint) ? editOrientation || "portrait" : "portrait",
    );
    const current = useDashboardStore.getState().layout || layout;
    if (hasStoredBreakpoint(current, activeSlot)) return;
    const seeded = ensureBreakpointLayout(current, activeSlot, gridCols);
    if (seeded !== current) setLayout(seeded);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    editMode,
    viewportBp,
    viewportOrientation,
    editBreakpoint,
    editOrientation,
    setEditBreakpoint,
    setEditOrientation,
    setLayout,
  ]);

  function selectEditBreakpoint(next: Breakpoint) {
    const nextOrient: Orientation = supportsOrientation(next)
      ? editOrientation || viewportOrientation
      : "portrait";
    const nextSlot = resolveLayoutSlot(next, nextOrient);
    const current = useDashboardStore.getState().layout || layout;
    const seeded = ensureBreakpointLayout(current, nextSlot, gridCols);
    if (seeded !== current) setLayout(seeded);
    setEditBreakpoint(next);
    setEditOrientation(nextOrient);
  }

  function selectEditOrientation(next: Orientation) {
    if (!bp || !supportsOrientation(bp)) return;
    const nextSlot = resolveLayoutSlot(bp, next);
    const current = useDashboardStore.getState().layout || layout;
    const seeded = ensureBreakpointLayout(current, nextSlot, gridCols);
    if (seeded !== current) setLayout(seeded);
    setEditOrientation(next);
  }

  function copyFromDesktop() {
    if (!bp || !slot || bp === "lg") return;
    const current = useDashboardStore.getState().layout || layout;
    if (isBreakpointLocked(current, slot)) return;
    suppressLayoutCommitRef.current = 2;
    setLiveLayout(null);
    setLayout(copyDesktopToBreakpoint(current, slot, gridCols));
  }

  const currentLayout = useMemo(() => {
    if (!bp || !slot) return [];
    const items = layoutForBreakpoint(layout, slot, gridCols);
    const byId = new Map(items.map((item) => [item.i, item]));
    const cols = gridCols[bp];
    const occupied: GridItem[] = [];
    const result: GridItem[] = [];

    for (const card of cards) {
      const existing = byId.get(card.instanceId);
      if (existing) {
        // Edit mode: allow any size. View mode: keep manifest floor (not inflated content-fit mins).
        const floorMinH = editMode ? 1 : Math.max(1, card.manifest.defaultSize.minH ?? 2);
        const floorMinW = editMode ? 1 : Math.max(1, card.manifest.defaultSize.minW ?? 1);
        const sizeLocked = Boolean(existing.sizeLocked);
        const item = {
          ...existing,
          w: Math.min(existing.w, cols),
          x: Math.min(existing.x, Math.max(0, cols - Math.min(existing.w, cols))),
          minW: Math.min(floorMinW, existing.w),
          minH: Math.min(floorMinH, existing.h),
          // Free resize from leftover auto-layout caps (maxH:10 etc.); size lock still wins.
          ...(editMode && !sizeLocked ? { maxW: cols, maxH: EDIT_MAX_H } : {}),
          // RGL per-item flag — size-locked cards stay draggable but not resizable.
          ...(editMode && sizeLocked ? { isResizable: false } : {}),
        };
        occupied.push(item);
        result.push(item);
        continue;
      }

      const size = card.manifest.defaultSize;
      const scale = cols / gridCols.lg;
      const w = Math.min(cols, Math.max(size.minW || 1, Math.round(size.w * scale)));
      const h = size.h;
      const slot = findOpenSlot(occupied, w, h, cols);
      const item: GridItem = {
        i: card.instanceId,
        x: slot.x,
        y: slot.y,
        w,
        h,
        minW: size.minW,
        minH: size.minH,
      };
      occupied.push(item);
      result.push(item);
    }

    return resolveVerticalOverlaps(result);
  }, [cards, layout, bp, slot, editMode, gridCols]);

  const missingWidgetKey = useMemo(() => {
    if (!bp || !slot) return "";
    const known = new Set(layoutForBreakpoint(layout, slot, gridCols).map((item) => item.i));
    return cards
      .map((card) => card.instanceId)
      .filter((id) => !known.has(id))
      .sort()
      .join("|");
  }, [bp, slot, cards, layout, gridCols]);

  const currentLayoutRef = useRef(currentLayout);
  currentLayoutRef.current = currentLayout;

  useEffect(() => {
    if (!autoLayoutToken || !editMode || !bp || !slot) return;
    const current = useDashboardStore.getState().layout || layout;
    if (isBreakpointLocked(current, slot)) return;
    const withBp = ensureBreakpointLayout(current, slot, gridCols);
    // Pack from what is actually on screen (includes ephemeral placements for
    // cards missing from an incomplete breakpoint layout), not only stored items.
    const onScreen = liveLayout ?? currentLayoutRef.current;
    const onScreenById = new Map(onScreen.map((item) => [item.i, item]));
    const packed = buildAutoLayoutForBreakpoint(
      cards.map((card) => {
        const existing = onScreenById.get(card.instanceId);
        return {
          instanceId: card.instanceId,
          widgetId: card.widgetId,
          manifest: card.manifest,
          order: existing?.order,
          sizeLocked: Boolean(existing?.sizeLocked),
          hidden: Boolean(existing?.hidden),
          lockedW: existing?.w,
          lockedH: existing?.h,
        };
      }),
      gridCols[bp],
      onScreen,
      // New seed every click so arrangement + sizes change each time.
      { seed: Date.now() ^ (autoLayoutToken * 2654435761) },
    );
    // RGL echoes onLayoutChange with the previous positions after a prop update —
    // ignore those commits so Auto Layout is not immediately overwritten.
    suppressLayoutCommitRef.current = 2;
    setLiveLayout(null);
    setLayout({
      ...withBp,
      [slot]: packed,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps -- only re-run when Auto Layout is clicked
  }, [autoLayoutToken, editMode, bp, slot, setLayout]);

  useEffect(() => {
    if (!alignTopsToken || !editMode || !bp || !slot) return;
    const current = useDashboardStore.getState().layout || layout;
    if (isBreakpointLocked(current, slot)) return;
    const withBp = ensureBreakpointLayout(current, slot, gridCols);
    const onScreen = liveLayout ?? currentLayoutRef.current;
    const aligned = alignLayoutTops(onScreen, 1, gridCols[bp]);
    suppressLayoutCommitRef.current = 2;
    setLiveLayout(null);
    setLayout({
      ...withBp,
      [slot]: aligned,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [alignTopsToken, editMode, bp, slot, setLayout]);

  function toggleBreakpointLock() {
    if (!bp || !slot) return;
    const current = useDashboardStore.getState().layout || layout;
    const locking = !isBreakpointLocked(current, slot);
    // Materialize what's on screen so lock freezes the real placement, not a scaled fallback.
    const withBp = ensureBreakpointLayout(current, slot, gridCols);
    const onScreen = currentLayoutRef.current;
    const items = locking
      ? onScreen.length
        ? onScreen.map((item) => ({ ...item }))
        : layoutForBreakpoint(withBp, slot, gridCols)
      : layoutForBreakpoint(withBp, slot, gridCols);
    setLayout(setBreakpointLocked({ ...withBp, [slot]: items }, slot, locking));
  }

  function patchGridItem(instanceId: string, patch: Partial<GridItem>) {
    if (!bp || !slot) return;
    const current = useDashboardStore.getState().layout || layout;
    if (isBreakpointLocked(current, slot)) return;
    const withBp = ensureBreakpointLayout(current, slot, gridCols);
    const items = layoutForBreakpoint(withBp, slot, gridCols);
    const onScreen = liveLayout ?? currentLayoutRef.current;
    const applyPatch = (item: GridItem): GridItem => {
      const next = { ...item, ...patch };
      if (patch.sizeLocked === false) delete next.sizeLocked;
      if (patch.hidden === false) delete next.hidden;
      if (patch.order === undefined && "order" in patch) delete next.order;
      return next;
    };
    let nextItems: GridItem[];
    if (items.some((item) => item.i === instanceId)) {
      nextItems = items.map((item) => (item.i === instanceId ? applyPatch(item) : item));
    } else {
      const ephemeral = onScreen.find((item) => item.i === instanceId);
      nextItems = ephemeral ? [...items, applyPatch(ephemeral)] : items;
    }
    // Hiding/unhiding a card can change the hidden set — repack hidden cards
    // below the visible ones so hiding never leaves a blank gap in the grid.
    if ("hidden" in patch) {
      nextItems = pushHiddenBelowVisible(nextItems, gridCols[bp]);
    }
    // Keep live layout in sync if present.
    if (liveLayout) {
      let nextLive = liveLayout.map((item) => (item.i === instanceId ? applyPatch(item) : item));
      if ("hidden" in patch) {
        nextLive = pushHiddenBelowVisible(nextLive, gridCols[bp]);
      }
      setLiveLayout(nextLive);
    }
    setLayout({ ...withBp, [slot]: nextItems });
  }

  function toggleSizeLock(instanceId: string) {
    const onScreen = liveLayout ?? currentLayoutRef.current;
    const existing = onScreen.find((item) => item.i === instanceId);
    patchGridItem(instanceId, { sizeLocked: !existing?.sizeLocked });
  }

  function toggleHidden(instanceId: string) {
    const onScreen = liveLayout ?? currentLayoutRef.current;
    const existing = onScreen.find((item) => item.i === instanceId);
    patchGridItem(instanceId, { hidden: !existing?.hidden });
  }

  function setCardOrder(instanceId: string, order: number | undefined) {
    if (!bp || !slot) return;
    const current = useDashboardStore.getState().layout || layout;
    if (isBreakpointLocked(current, slot)) return;
    const withBp = ensureBreakpointLayout(current, slot, gridCols);
    const stored = layoutForBreakpoint(withBp, slot, gridCols);
    const source = stored.some((item) => item.i === instanceId)
      ? stored
      : (liveLayout ?? currentLayoutRef.current);
    const patched = source.map((item) => {
      if (item.i !== instanceId) return { ...item };
      const next = { ...item };
      if (order === undefined) delete next.order;
      else next.order = order;
      return next;
    });
    const aligned = alignItemsByPriority(patched, gridCols[bp]);
    setLiveLayout(null);
    setLayout({ ...withBp, [slot]: aligned });
  }

  // Persist smart placements for newly added widgets so they don't jump on re-render.
  // View mode must never rewrite the store — display uses ephemeral placements instead.
  useEffect(() => {
    if (!editMode) return;
    if (!bp || !slot || !missingWidgetKey) return;
    const current = useDashboardStore.getState().layout || layout;
    if (isBreakpointLocked(current, slot)) return;
    const withBp = ensureBreakpointLayout(current, slot, gridCols);
    const items = layoutForBreakpoint(withBp, slot, gridCols);
    const known = new Set(items.map((item) => item.i));
    const missing = currentLayoutRef.current.filter((item) => !known.has(item.i));
    if (!missing.length) {
      if (withBp !== current) setLayoutQuiet(withBp);
      return;
    }
    setLayout({
      ...withBp,
      [slot]: [...items, ...missing],
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps -- layout is read from the store; depending on it loops
  }, [bp, slot, missingWidgetKey, editMode, setLayout, gridCols, setLayoutQuiet]);

  function commitLayout(next: GridItem[], pinnedId?: string) {
    if (!bp || !slot) return;
    const current = useDashboardStore.getState().layout || layout;
    if (isBreakpointLocked(current, slot)) return;
    setLayout({
      ...current,
      [slot]: pinnedId
        ? resolveOverlapsAroundPinnedItem(next, pinnedId)
        : resolveVerticalOverlaps(next),
    });
  }

  async function persistSettings(nextSettings: AppSettings, nextTab: DashboardTab) {
    const payload = withUpdatedTab(nextSettings, nextTab);
    const prevSettings = boardSettings;
    const prevTab = boardTab;
    setBoardSettings(payload);
    setBoardTab(nextTab);
    setBusy(true);
    try {
      const res = await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error("Failed to save settings");
      return true;
    } catch {
      setBoardSettings(prevSettings);
      setBoardTab(prevTab);
      alert("Failed to update widgets");
      return false;
    } finally {
      setBusy(false);
    }
  }

  async function saveWidgetChrome(
    instanceId: string,
    widgetId: string,
    patch: Partial<WidgetChromeSettings>,
  ) {
    const widgetChrome = { ...(boardSettings.widgetChrome || {}) };
    const fallback = instanceId !== widgetId ? widgetChrome[widgetId] : undefined;
    const merged = mergeWidgetChromeEntry(widgetChrome[instanceId], patch, fallback);
    if (!merged) delete widgetChrome[instanceId];
    else widgetChrome[instanceId] = merged;
    return persistSettings({ ...boardSettings, widgetChrome }, boardTab);
  }

  function placeNewCard(instanceId: string, widgetId: string) {
    if (!bp || !slot) return;
    const manifest = getWidget(widgetId)?.manifest;
    if (!manifest) return;
    const current = useDashboardStore.getState().layout || layout;
    const withBp = ensureBreakpointLayout(current, slot, gridCols);
    const items = layoutForBreakpoint(withBp, slot, gridCols);
    if (items.some((item) => item.i === instanceId)) {
      setLayout(withBp);
      return;
    }
    const cols = gridCols[bp];
    const size = manifest.defaultSize;
    const scale = cols / gridCols.lg;
    const w = Math.min(cols, Math.max(size.minW || 1, Math.round(size.w * scale)));
    const h = size.h;
    const open = findOpenSlot(items, w, h, cols);
    setLayout({
      ...withBp,
      [slot]: [
        ...items,
        {
          i: instanceId,
          x: open.x,
          y: open.y,
          w,
          h,
          minW: size.minW,
          minH: size.minH,
        },
      ],
    });
  }

  async function handleRemove(instanceId: string, label: string) {
    if (busy) return;
    if (!window.confirm(`Remove “${label}” from the ${boardTab.name} tab?`)) return;
    setBusy(true);
    const response = await fetch("/api/layout/widgets", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "remove", tabId: boardTab.id, instanceId }),
    }).catch(() => null);
    const data = await response?.json().catch(() => ({}));
    setBusy(false);
    if (!response?.ok || !data?.tab) {
      alert(data?.error || "Failed to remove widget");
      return;
    }
    setBoardTab(data.tab);
    setBoardSettings(withUpdatedTab(boardSettings, data.tab));
    const current = useDashboardStore.getState().layout || layout;
    setLayout(pruneLayoutIds(current, new Set([instanceId])));
  }

  async function handleDisable(widgetId: string, label: string) {
    if (busy) return;
    if (
      !window.confirm(
        `Disable “${label}” everywhere? It will hide on all tabs. Credentials are kept.`,
      )
    ) {
      return;
    }
    const nextSettings: AppSettings = {
      ...boardSettings,
      enabledWidgets: boardSettings.enabledWidgets.filter((id) => id !== widgetId),
    };
    const ok = await persistSettings(nextSettings, boardTab);
    if (!ok) return;
    const dropIds = new Set(
      cards.filter((card) => card.widgetId === widgetId).map((card) => card.instanceId),
    );
    const current = useDashboardStore.getState().layout || layout;
    setLayout(pruneLayoutIds(current, dropIds));
  }

  async function handleAdd(choices: AddWidgetChoice[]) {
    if (busy || !choices.length) return;
    setBusy(true);
    let latestSettings = boardSettings;
    let latestTab = boardTab;
    const added: Array<{ instanceId: string; label: string; widgetId: string }> = [];
    try {
      for (const choice of choices) {
        const { manifest } = choice;
        const response = await fetch("/api/layout/widgets", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "add",
            tabId: boardTab.id,
            widgetId: manifest.id,
            instanceId: choice.kind === "package" ? choice.instanceId : undefined,
            another: choice.kind === "another",
          }),
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok || !data?.tab || !data?.instanceId) {
          throw new Error(data?.error || `Failed to add ${manifest.name}`);
        }
        latestTab = data.tab;
        latestSettings = {
          ...latestSettings,
          enabledWidgets: data.enabledWidgets || latestSettings.enabledWidgets,
          widgetInstances: data.widgetInstances || latestSettings.widgetInstances,
          tabs: latestSettings.tabs.map((item) => item.id === data.tab.id ? data.tab : item),
        };
        placeNewCard(data.instanceId, manifest.id);
        added.push({
          instanceId: data.instanceId,
          label: data.label || manifest.name,
          widgetId: manifest.id,
        });
      }
      setBoardSettings(latestSettings);
      setBoardTab(latestTab);
      setAddOpen(false);
      if (canManageWidgets && added.length === 1) {
        setConfigTarget(added[0]);
      }
    } catch (error) {
      alert(error instanceof Error ? error.message : "Failed to add selected widgets");
    } finally {
      setBusy(false);
    }
  }

  /** Layout lock freezes drag/resize/auto-layout for the active slot. */
  const bpLocked = Boolean(slot && isBreakpointLocked(layout, slot));

  /**
   * Expand: grow/shrink the live grid `h` to fit content without dirtying
   * the saved layout (avoids the old content-fit drift bug).
   */
  const onContentFitHeight = useCallback((instanceId: string, size: { height: number }) => {
    if (interactingRef.current) return;
    const nextH = contentPxToGridH(size.height);
    setHeightOverrides((prev) => {
      if (prev[instanceId] === nextH) return prev;
      return { ...prev, [instanceId]: nextH };
    });
  }, []);

  useEffect(() => {
    minSizeLock.current.clear();
  }, [editMode]);

  function onInteractionStart() {
    interactingRef.current = true;
  }

  /** Keep Expand-driven heights out of persisted layout commits. */
  function withoutExpandHeights(items: GridItem[]): GridItem[] {
    const expandIds = expandIdsRef.current;
    if (!expandIds.size) return items;
    const baseline = currentLayoutRef.current;
    return items.map((item) => {
      if (!expandIds.has(item.i)) return item;
      const base = baseline.find((entry) => entry.i === item.i);
      return base ? { ...item, h: base.h } : item;
    });
  }

  function onLayoutChange(next: Layout[]) {
    if (!editMode || bpLocked) return;
    if (suppressLayoutCommitRef.current > 0) {
      suppressLayoutCommitRef.current -= 1;
      return;
    }
    // While dragging/resizing, keep a local live layout so RGL stays controlled
    // without hammering the store (which was snapping resize back).
    if (interactingRef.current) {
      setLiveLayout(toGridItems(next, liveLayout ?? currentLayoutRef.current));
      return;
    }
    commitLayout(withoutExpandHeights(toGridItems(next, liveLayout ?? currentLayoutRef.current)));
  }

  function onDragStop(next: Layout[], _old: Layout, item: Layout) {
    interactingRef.current = false;
    if (!editMode || bpLocked) {
      setLiveLayout(null);
      return;
    }
    const snapped = snapItemToNearbyRow(
      withoutExpandHeights(toGridItems(next, liveLayout ?? currentLayoutRef.current)),
      item.i,
      1,
    );
    setLiveLayout(null);
    commitLayout(snapped, item.i);
  }

  function onResizeStop(next: Layout[], _old: Layout, item: Layout) {
    interactingRef.current = false;
    if (!editMode || bpLocked) {
      setLiveLayout(null);
      return;
    }
    minSizeLock.current.delete(`${item.i}:e`);
    minSizeLock.current.delete(`${item.i}:v`);
    const prior = (liveLayout ?? currentLayoutRef.current).find((entry) => entry.i === item.i);
    // Persist the user-chosen size with free mins so the next drag can shrink further.
    // Drop maxW/maxH so stale auto-layout caps don't return on the next load.
    // Size-locked cards should not reach resize, but preserve the flag if present.
    const items = toGridItems(next, liveLayout ?? currentLayoutRef.current).map((entry) => {
      if (entry.i !== item.i) return entry;
      const cleared: GridItem = {
        i: entry.i,
        x: entry.x,
        y: entry.y,
        w: entry.w,
        h: entry.h,
        minW: 1,
        minH: 1,
      };
      if (prior?.sizeLocked) cleared.sizeLocked = true;
      if (prior?.hidden) cleared.hidden = true;
      if (prior?.order != null) cleared.order = prior.order;
      return cleared;
    });
    // Keep the resized card's h; strip ephemeral Expand heights on siblings.
    const baseline = currentLayoutRef.current;
    const expandIds = expandIdsRef.current;
    const persisted = items.map((entry) => {
      if (entry.i === item.i || !expandIds.has(entry.i)) return entry;
      const base = baseline.find((b) => b.i === entry.i);
      return base ? { ...entry, h: base.h } : entry;
    });
    // Manual resize becomes the new baseline; Expand can still grow above it afterward.
    if (expandIds.has(item.i)) {
      const resized = persisted.find((entry) => entry.i === item.i);
      if (resized) {
        setHeightOverrides((prev) => ({ ...prev, [item.i]: resized.h }));
      }
    }
    const snapped = snapItemToNearbyRow(persisted, item.i, 1);
    setLiveLayout(null);
    commitLayout(snapped, item.i);
  }

  if (width == null || !bp) {
    return <div className="hd-board" aria-hidden />;
  }

  const previewingAway = Boolean(
    editMode &&
      viewportBp &&
      (bp !== viewportBp ||
        (supportsOrientation(bp) && orientation !== viewportOrientation)),
  );
  const gridLayout = liveLayout ?? currentLayout;
  const deviceLabel = `${BREAKPOINT_LABELS[bp]}${
    supportsOrientation(bp) ? ` ${ORIENTATION_LABELS[orientation]}` : ""
  }`;
  const visibleCards = editMode
    ? cards
    : cards.filter((card) => {
        const item = gridLayout.find((entry) => entry.i === card.instanceId);
        return !item?.hidden;
      });
  const expandIds = new Set(
    editMode
      ? []
      : visibleCards
          .filter((card) =>
            !FIXED_VIEWPORT_WIDGETS.has(card.widgetId)
            && isChromeExpandActive(
              resolveWidgetChrome(boardSettings.widgetChrome, card.instanceId, card.widgetId)
                .expand,
              bp,
            ),
          )
          .map((card) => card.instanceId),
  );
  expandIdsRef.current = expandIds;
  // Plain compute (not useMemo) — this block runs only after the width/bp early-return above.
  // Saved x/y/w/h stay in Edit mode. View + Expand packs stacked cards to
  // content height so a shorter tab does not leave a hole above the next card.
  let renderLayout = editMode ? gridLayout : gridLayout.filter((item) => !item.hidden);
  if (!editMode && expandIds.size > 0 && Object.keys(heightOverrides).length > 0) {
    renderLayout = packExpandLayout(renderLayout, expandIds, heightOverrides);
  }
  const editGridRows = Math.max(
    gridLayout.reduce((max, item) => Math.max(max, item.y + item.h), 0) + EDIT_GRID_PAD_ROWS,
    EDIT_GRID_MIN_ROWS,
  );
  const configManifest = configTarget ? getWidget(configTarget.widgetId)?.manifest : null;

  if (!cards.length && !editMode) {
    return (
      <div className="hd-empty">
        No widgets on the <strong>{tab.name}</strong> tab yet. Open Settings → Tabs to assign some, or
        use Edit layout → Add widget.
      </div>
    );
  }

  return (
    <div className="hd-board">
      <MobileScrollFocus enabled={hybridScrollTouch} />
      <WidgetScrollChain enabled={!editMode} />
      {editMode ? (
        <div className="hd-edit-banner">
          <div className="hd-edit-banner__text">
            Editing <strong>{boardTab.name}</strong>
            <span className="hd-edit-banner__bp-meta">
              {" "}
              · {BREAKPOINT_LABELS[bp]}
              {supportsOrientation(bp) ? ` ${ORIENTATION_LABELS[orientation]}` : ""} ({gridCols[bp]}{" "}
              cols)
              {bpLocked ? (
                <span className="hd-edit-banner__lock-note"> — locked</span>
              ) : null}
              {previewingAway ? (
                <span className="hd-edit-banner__preview-note"> — previewing layout</span>
              ) : null}
            </span>
            {!bpLocked ? (
              <div className="hd-edit-banner__touch-hint">
                Select a widget, then hold the center handle to move, or drag an edge/corner to resize.
              </div>
            ) : null}
            {bpLocked ? (
              <div className="hd-edit-banner__touch-hint">
                This device layout is locked. Unlock to move or resize widgets.
              </div>
            ) : null}
          </div>
          <div className="hd-edit-banner__bps" role="tablist" aria-label="Layout size preset">
            {BREAKPOINT_ORDER.map((key) => {
              const keySlot = resolveLayoutSlot(
                key,
                supportsOrientation(key) ? orientation : "portrait",
              );
              const stored = hasStoredBreakpoint(layout, keySlot);
              const locked = isBreakpointLocked(layout, keySlot);
              return (
                <button
                  key={key}
                  type="button"
                  role="tab"
                  aria-selected={bp === key}
                  className={`hd-edit-bp${bp === key ? " is-active" : ""}${stored ? " has-layout" : ""}${locked ? " is-locked" : ""}`}
                  onClick={() => selectEditBreakpoint(key)}
                  title={`${BREAKPOINT_LABELS[key]} · ${gridCols[key]} columns${stored ? "" : " (not saved yet)"}${locked ? " · locked" : ""}`}
                >
                  {BREAKPOINT_LABELS[key]}
                </button>
              );
            })}
          </div>
          {supportsOrientation(bp) ? (
            <div className="hd-edit-banner__orient" role="tablist" aria-label="Layout orientation">
              {(["portrait", "landscape"] as const).map((key) => {
                const keySlot = resolveLayoutSlot(bp, key);
                const stored = hasStoredBreakpoint(layout, keySlot);
                return (
                  <button
                    key={key}
                    type="button"
                    role="tab"
                    aria-selected={orientation === key}
                    className={`hd-edit-bp hd-edit-orient${orientation === key ? " is-active" : ""}${stored ? " has-layout" : ""}`}
                    onClick={() => selectEditOrientation(key)}
                    title={`${ORIENTATION_LABELS[key]} layout for ${BREAKPOINT_LABELS[bp]}`}
                  >
                    {ORIENTATION_LABELS[key]}
                  </button>
                );
              })}
            </div>
          ) : null}
          <div className="hd-edit-banner__actions">
            <button
              className={`hd-btn${bpLocked ? " hd-btn--primary" : ""}`}
              type="button"
              onClick={toggleBreakpointLock}
              title={
                bpLocked
                  ? `Unlock ${BREAKPOINT_LABELS[bp]} layout`
                  : `Lock ${BREAKPOINT_LABELS[bp]} layout so it cannot shift`
              }
            >
              {bpLocked ? "Unlock layout" : "Lock layout"}
            </button>
            {canEditWidgetPlacement ? (
              <button
                className="hd-btn hd-btn--primary"
                type="button"
                disabled={busy || bpLocked}
                onClick={() => setAddOpen(true)}
              >
                Add widget
              </button>
            ) : null}
            {bp !== "lg" ? (
              <button className="hd-btn" type="button" disabled={bpLocked} onClick={copyFromDesktop}>
                Copy Desktop
              </button>
            ) : null}
            <button
              className="hd-btn"
              type="button"
              disabled={bpLocked}
              title="Fix overlaps, close gaps, and pack widgets tighter"
              onClick={() => triggerAlignTops()}
            >
              Align tops
            </button>
            <button
              className="hd-btn"
              type="button"
              disabled={bpLocked}
              onClick={() => triggerAutoLayout()}
            >
              Auto Layout
            </button>
          </div>
        </div>
      ) : null}

      {!cards.length && editMode ? (
        <div
          className="hd-board__canvas hd-board__canvas--editing"
          style={
            {
              "--hd-edit-cols": gridCols[bp],
              "--hd-edit-rows": editGridRows,
              "--hd-edit-row": `${ROW_HEIGHT}px`,
              "--hd-edit-gap": `${MARGIN}px`,
            } as CSSProperties
          }
        >
          <EditLayoutGrid cols={gridCols[bp]} rows={editGridRows} />
          <div className="hd-empty hd-empty--edit">
            {canEditWidgetPlacement ? <>No widgets on this tab yet. Click <strong>Add widget</strong> to place one.</> : "No widgets are available on this tab."}
          </div>
        </div>
      ) : (
        <div
          className={`hd-board__canvas${editMode ? " hd-board__canvas--editing" : ""}`}
          style={
            editMode
              ? ({
                  "--hd-edit-cols": gridCols[bp],
                  "--hd-edit-rows": editGridRows,
                  "--hd-edit-row": `${ROW_HEIGHT}px`,
                  "--hd-edit-gap": `${MARGIN}px`,
                } as CSSProperties)
              : undefined
          }
        >
          {editMode ? <EditLayoutGrid cols={gridCols[bp]} rows={editGridRows} /> : null}
          <ResponsiveGrid
          className={`layout${touchEdit ? " layout--touch-edit" : ""}`}
          layout={renderLayout}
          cols={gridCols[bp]}
          rowHeight={ROW_HEIGHT}
          margin={[MARGIN, MARGIN]}
          containerPadding={[0, 0]}
          isDraggable={editMode && !bpLocked}
          isResizable={editMode && !bpLocked}
          compactType={null}
          allowOverlap={editMode}
          preventCollision={false}
          onLayoutChange={onLayoutChange}
          onDragStart={onInteractionStart}
          onResizeStart={onInteractionStart}
          onDragStop={onDragStop}
          onResizeStop={onResizeStop}
          // Touch: only the center handle moves a card so page scroll stays free.
          {...(touchEdit ? { draggableHandle: ".hd-widget__drag-handle" } : {})}
          draggableCancel="input, textarea, select, button, a, .hd-btn, .hd-switch, .react-resizable-handle, .pve-tab, .pve-g-row, [role='tab'], [role='button']:not(.hd-widget__drag-handle), .hd-widget__edit-actions, .hd-widget__edit-btn, .hd-widget__order, .hd-widget__order-input"
          resizeHandles={
            touchEdit ? ["se", "sw", "ne", "nw"] : ["n", "s", "e", "w", "ne", "nw", "se", "sw"]
          }
        >
          {visibleCards.map((card) => {
            const mod = getWidget(card.widgetId);
            if (!mod) return null;
            const layoutItem = gridLayout.find((item) => item.i === card.instanceId);
            const chrome = resolveWidgetChrome(
              boardSettings.widgetChrome,
              card.instanceId,
              card.widgetId,
            );
            // Expand: view-only content-fit for the active device. Edit layout
            // keeps saved grid sizes so cards don't auto-grow / overlap while dragging.
            const fitHeightRequested =
              !editMode
              && !FIXED_VIEWPORT_WIDGETS.has(card.widgetId)
              && isChromeExpandActive(chrome.expand, bp);
            const fitHeight = fitHeightRequested;
            const configFields = fieldsForWidget(card.manifest);
            const resizeSelected = editMode && touchEdit && resizeTargetId === card.instanceId;
            const deviceHidden = Boolean(layoutItem?.hidden);
            return (
              <div
                key={card.instanceId}
                className={[
                  resizeSelected ? "is-resize-selected" : "",
                  editMode && deviceHidden ? "is-device-hidden" : "",
                ]
                  .filter(Boolean)
                  .join(" ") || undefined}
                onClick={(event) => {
                  if (!editMode || !touchEdit || bpLocked) return;
                  // Don't steal clicks from edit action buttons / drag handle.
                  const target = event.target as Element | null;
                  if (target?.closest?.(".hd-widget__edit-actions, .hd-widget__drag-handle, .react-resizable-handle")) {
                    return;
                  }
                  setResizeTargetId(card.instanceId);
                }}
              >
                {resizeSelected ? (
                  <div
                    className="hd-widget__drag-handle"
                    role="button"
                    tabIndex={0}
                    aria-label="Hold and drag to move widget"
                    title="Hold and drag to move"
                  >
                    <span className="hd-widget__drag-handle-grip" aria-hidden>
                      <span />
                      <span />
                      <span />
                      <span />
                      <span />
                      <span />
                    </span>
                    <span className="hd-widget__drag-handle-label">Hold to move</span>
                  </div>
                ) : null}
                <WidgetFrame
                  manifest={card.manifest}
                  title={card.label}
                  instanceId={card.instanceId}
                  iconUrl={resolveWidgetIcon(
                    card.widgetId,
                    boardSettings.widgetIcons?.[card.instanceId],
                    boardSettings.widgetIcons?.[card.widgetId],
                  )}
                  showIcon={chrome.showIcon}
                  showTitle={chrome.showTitle}
                  editMode={editMode}
                  autoHeight={fitHeight}
                  sizeLocked={Boolean(layoutItem?.sizeLocked)}
                  hiddenOnDevice={deviceHidden}
                  deviceLabel={deviceLabel}
                  order={layoutItem?.order}
                  onToggleSizeLock={
                    editMode && !bpLocked ? () => toggleSizeLock(card.instanceId) : undefined
                  }
                  onToggleHidden={
                    editMode && !bpLocked ? () => toggleHidden(card.instanceId) : undefined
                  }
                  onOrderChange={
                    editMode && !bpLocked
                      ? (nextOrder) => setCardOrder(card.instanceId, nextOrder)
                      : undefined
                  }
                  onContentSize={
                    fitHeight ? (size) => onContentFitHeight(card.instanceId, size) : undefined
                  }
                  globalAccent={boardSettings.theme.cardAccent || "rainbow"}
                  globalAccentColor={boardSettings.theme.cardAccentColor || boardSettings.theme.accent}
                  themeAccent={boardSettings.theme.accent}
                  widgetAccent={
                    boardSettings.widgetAccents?.[card.instanceId] ||
                    boardSettings.widgetAccents?.[card.widgetId]
                  }
                  hasConfigFields={canManageWidgets && (configFields.length > 0 || card.widgetId === "proxmox-nodes")}
                  onEditConfig={
                    editMode && canManageWidgets
                      ? () =>
                          setConfigTarget({
                            instanceId: card.instanceId,
                            label: card.label,
                            widgetId: card.widgetId,
                          })
                      : undefined
                  }
                  onRemove={editMode && canEditWidgetPlacement ? () => handleRemove(card.instanceId, card.label) : undefined}
                  onDisable={
                    editMode && canManageWidgets ? () => handleDisable(card.widgetId, card.manifest.name) : undefined
                  }
                >
                  <DeferredWidget widgetId={card.widgetId} load={mod.load} />
                </WidgetFrame>
              </div>
            );
          })}
        </ResponsiveGrid>
        </div>
      )}

      {addOpen && canEditWidgetPlacement ? (
        <AddWidgetModal
          tab={boardTab}
          manifests={listWidgets().filter((manifest) => !restrictedWidgetIds.includes(manifest.id))}
          widgetInstances={boardSettings.widgetInstances}
          widgetIcons={boardSettings.widgetIcons}
          onClose={() => setAddOpen(false)}
          onAdd={handleAdd}
        />
      ) : null}

      {configTarget && configManifest && canManageWidgets ? (
        <WidgetConfigModal
          instanceId={configTarget.instanceId}
          label={configTarget.label}
          manifest={configManifest}
          showIcon={
            resolveWidgetChrome(
              boardSettings.widgetChrome,
              configTarget.instanceId,
              configTarget.widgetId,
            ).showIcon
          }
          showTitle={
            resolveWidgetChrome(
              boardSettings.widgetChrome,
              configTarget.instanceId,
              configTarget.widgetId,
            ).showTitle
          }
          expand={
            resolveWidgetChrome(
              boardSettings.widgetChrome,
              configTarget.instanceId,
              configTarget.widgetId,
            ).expand
          }
          onUpdateChrome={(patch) =>
            saveWidgetChrome(configTarget.instanceId, configTarget.widgetId, patch)
          }
          onClose={() => setConfigTarget(null)}
        />
      ) : null}
    </div>
  );
}
