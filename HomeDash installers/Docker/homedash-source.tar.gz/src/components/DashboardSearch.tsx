"use client";

import { useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { createPortal } from "react-dom";
import { useRouter } from "next/navigation";
import type { AppSettings, SearchSettings } from "@/lib/types";
import { enabledHeaderQuickLinks } from "@/lib/header-quick-links";
import widgetCatalog from "@/widgets/catalog.json";
import { normalizeSearchSettings, searchShadowValue } from "@/lib/search-settings";

type SearchResult = {
  id: string;
  kind: "Dashboard" | "Widget" | "Bookmark" | "Quick link";
  title: string;
  detail: string;
  href?: string;
  tabId?: string;
  widgetId?: string;
};

const SEARCH_URL = "https://www.google.com/search?q=";

function SearchGlyph({ size = 18 }: { size?: number }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} aria-hidden="true">
      <path
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        d="m21 21-4.35-4.35m2.35-5.15A7.5 7.5 0 1 1 4 11.5a7.5 7.5 0 0 1 15 0Z"
      />
    </svg>
  );
}

function matches(result: SearchResult, query: string) {
  const words = query.toLocaleLowerCase().split(/\s+/).filter(Boolean);
  const haystack = `${result.title} ${result.detail} ${result.kind}`.toLocaleLowerCase();
  return words.every((word) => haystack.includes(word));
}

export function DashboardSearch({
  settings,
  appearance,
  compact = false,
  onOpen,
}: {
  settings: AppSettings;
  appearance?: Partial<SearchSettings>;
  compact?: boolean;
  onOpen?: () => void;
}) {
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [activeIndex, setActiveIndex] = useState(0);
  const searchSettings = normalizeSearchSettings(appearance || settings.theme.search);

  const entries = useMemo<SearchResult[]>(() => {
    const widgetNames = new Map(widgetCatalog.map((item) => [item.id, item.name]));
    const instances = new Map(settings.widgetInstances.map((item) => [item.id, item]));
    const results: SearchResult[] = [];

    for (const tab of settings.tabs) {
      results.push({
        id: `tab:${tab.id}`,
        kind: "Dashboard",
        title: tab.name,
        detail: `${tab.widgetIds.length} widget${tab.widgetIds.length === 1 ? "" : "s"}`,
        tabId: tab.id,
      });
      for (const cardId of tab.widgetIds) {
        const instance = instances.get(cardId);
        const widgetId = instance?.widgetId || cardId;
        const title = instance?.label || widgetNames.get(widgetId) || widgetId;
        results.push({
          id: `widget:${tab.id}:${cardId}`,
          kind: "Widget",
          title,
          detail: `${tab.name} dashboard`,
          tabId: tab.id,
          widgetId: cardId,
        });
      }
    }

    for (const bookmark of settings.bookmarks || []) {
      results.push({
        id: `bookmark:${bookmark.id}`,
        kind: "Bookmark",
        title: bookmark.name,
        detail: bookmark.category || bookmark.publicUrl || bookmark.localUrl || "Saved bookmark",
        href: bookmark.publicUrl || bookmark.localUrl,
      });
    }

    for (const link of enabledHeaderQuickLinks(
      settings.theme.headerQuickLinks,
      settings.theme.headerQuickLinkItems,
    )) {
      results.push({
        id: `quick:${link.id}`,
        kind: "Quick link",
        title: link.label,
        detail: link.href,
        href: link.href,
      });
    }
    return results;
  }, [settings]);

  const results = useMemo(
    () =>
      (query.trim() ? entries.filter((entry) => matches(entry, query)) : entries)
        .slice(0, searchSettings.maxResults),
    [entries, query, searchSettings.maxResults],
  );

  const searchStyle = {
    "--hd-search-popup-bg": searchSettings.popupBackground,
    "--hd-search-popup-opacity": `${Math.round(searchSettings.popupOpacity * 100)}%`,
    "--hd-search-popup-blur": `${searchSettings.popupBlur}px`,
    "--hd-search-backdrop-bg": searchSettings.backdropBackground,
    "--hd-search-backdrop-opacity": `${Math.round(searchSettings.backdropOpacity * 100)}%`,
    "--hd-search-backdrop-blur": `${searchSettings.backdropBlur}px`,
    "--hd-search-border-color": searchSettings.borderColor,
    "--hd-search-border-width": `${searchSettings.borderWidth}px`,
    "--hd-search-radius": `${searchSettings.radius}px`,
    "--hd-search-width": `${searchSettings.width}px`,
    "--hd-search-shadow": searchShadowValue(searchSettings.shadow),
  } as CSSProperties;

  function show() {
    onOpen?.();
    setOpen(true);
    setQuery("");
    setActiveIndex(0);
  }

  function close() {
    setOpen(false);
  }

  function focusWidget(widgetId: string) {
    let attempts = 0;
    const find = () => {
      const target = Array.from(
        document.querySelectorAll<HTMLElement>("[data-instance-id]"),
      ).find((item) => item.dataset.instanceId === widgetId);
      if (target) {
        target.scrollIntoView({ behavior: "smooth", block: "center" });
        target.classList.add("hd-widget--search-hit");
        window.setTimeout(() => target.classList.remove("hd-widget--search-hit"), 1800);
      } else if (attempts++ < 20) {
        window.setTimeout(find, 100);
      }
    };
    window.setTimeout(find, 50);
  }

  function choose(result: SearchResult) {
    close();
    if (result.href) {
      window.open(result.href, "_blank", "noopener,noreferrer");
      return;
    }
    if (result.tabId) {
      router.push(`/t/${result.tabId}`);
      if (result.widgetId) focusWidget(result.widgetId);
    }
  }

  function searchInternet() {
    const value = query.trim();
    if (!value) return;
    window.open(`${SEARCH_URL}${encodeURIComponent(value)}`, "_blank", "noopener,noreferrer");
    close();
  }

  useEffect(() => {
    if (compact) return;
    const onKey = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        open ? close() : show();
      }
      if (event.key === "Escape" && open) close();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [compact, open]);

  useEffect(() => {
    if (!open) return;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    requestAnimationFrame(() => inputRef.current?.focus());
    return () => {
      document.body.style.overflow = overflow;
    };
  }, [open]);

  useEffect(() => setActiveIndex(0), [query]);

  return (
    <>
      <button
        className={`hd-quick-link hd-dashboard-search__trigger${compact ? " hd-dashboard-search__trigger--compact" : ""}`}
        type="button"
        onClick={show}
        aria-label="Search dashboard and internet"
        title="Search (Ctrl/⌘ K)"
      >
        <SearchGlyph />
      </button>

      {open && typeof document !== "undefined" ? createPortal(
        <div
          className={`hd-dashboard-search hd-dashboard-search--${searchSettings.resultDensity}`}
          role="presentation"
          style={searchStyle}
          onMouseDown={close}
        >
          <section
            className="hd-dashboard-search__panel"
            role="dialog"
            aria-modal="true"
            aria-label="Search dashboard and internet"
            onMouseDown={(event) => event.stopPropagation()}
          >
            <div className="hd-dashboard-search__input-wrap">
              <SearchGlyph size={20} />
              <input
                ref={inputRef}
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "ArrowDown") {
                    event.preventDefault();
                    setActiveIndex((index) => Math.min(index + 1, Math.max(0, results.length - 1)));
                  } else if (event.key === "ArrowUp") {
                    event.preventDefault();
                    setActiveIndex((index) => Math.max(index - 1, 0));
                  } else if (event.key === "Enter") {
                    event.preventDefault();
                    if (results[activeIndex]) choose(results[activeIndex]);
                    else if (searchSettings.showWebSearch) searchInternet();
                  }
                }}
                placeholder="Search dashboards, widgets, bookmarks, or the web…"
                aria-label="Search"
                autoComplete="off"
              />
              {searchSettings.showWebSearch ? (
                <button
                  type="button"
                  className="hd-dashboard-search__web-action"
                  onClick={searchInternet}
                  disabled={!query.trim()}
                  title="Search the internet"
                >
                  <span>Web</span>
                  <svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true">
                    <path
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.8"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M14 5h5v5m0-5-8 8M19 14v4a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h4"
                    />
                  </svg>
                </button>
              ) : null}
              <button type="button" className="hd-dashboard-search__close" onClick={close} aria-label="Close search">
                Esc
              </button>
            </div>

            {searchSettings.showResultHeader ? (
              <div className="hd-dashboard-search__results-head">
                <span>{query.trim() ? "Matching results" : "Quick access"}</span>
                {searchSettings.showResultCount ? (
                  <small>{results.length} {results.length === 1 ? "result" : "results"}</small>
                ) : null}
              </div>
            ) : null}

            <div className="hd-dashboard-search__results" role="listbox">
              {results.map((result, index) => (
                <button
                  key={result.id}
                  type="button"
                  role="option"
                  aria-selected={activeIndex === index}
                  className={`hd-dashboard-search__result${activeIndex === index ? " is-active" : ""}`}
                  onMouseEnter={() => setActiveIndex(index)}
                  onClick={() => choose(result)}
                >
                  {searchSettings.showIcons ? (
                    <span className="hd-dashboard-search__result-icon" aria-hidden="true">
                      {result.kind === "Dashboard" ? "⌂" : result.kind === "Widget" ? "▦" : result.kind === "Bookmark" ? "★" : "↗"}
                    </span>
                  ) : null}
                  <span className="hd-dashboard-search__result-copy">
                    <strong>{result.title}</strong>
                    {searchSettings.showDescriptions ? <small>{result.detail}</small> : null}
                  </span>
                  {searchSettings.showResultTypes ? (
                    <span className="hd-dashboard-search__kind">{result.kind}</span>
                  ) : null}
                </button>
              ))}
              {query.trim() && results.length === 0 ? (
                <div className="hd-dashboard-search__empty">No dashboard matches. Search the internet instead.</div>
              ) : null}
            </div>

            {searchSettings.showKeyboardHints ? (
              <footer>
                <span><kbd>↑</kbd><kbd>↓</kbd> navigate</span>
                <span><kbd>Enter</kbd> open</span>
                {searchSettings.showWebSearch ? <span><strong>Web</strong> internet</span> : null}
                <span><kbd>Esc</kbd> close</span>
              </footer>
            ) : null}
          </section>
        </div>,
        document.body,
      ) : null}
    </>
  );
}
