"use client";

import { useCallback, useEffect, useMemo, useRef, useState, type ComponentType } from "react";
import { lazy, Suspense } from "react";

type Props = {
  widgetId: string;
  load: () => Promise<{ default: ComponentType }>;
  /** IntersectionObserver rootMargin before mounting. Default "200px". */
  rootMargin?: string;
};

function WidgetSkeleton() {
  return (
    <div className="hd-widget-body hd-widget-body--deferred" aria-busy="true">
      <div className="hd-widget-empty">Loading…</div>
    </div>
  );
}

/**
 * Mount a widget only when near the viewport, then load its JS chunk via
 * React.lazy. Keeps offscreen cards from paying parse/network/mount cost.
 */
export function DeferredWidget({ widgetId, load, rootMargin = "200px" }: Props) {
  const [near, setNear] = useState(false);
  const [rootEl, setRootEl] = useState<Element | null>(null);
  const rootRef = useCallback((node: Element | null) => {
    setRootEl(node);
  }, []);
  const mountedRef = useRef(false);

  useEffect(() => {
    if (near || !rootEl) return;
    if (typeof IntersectionObserver === "undefined") {
      setNear(true);
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          mountedRef.current = true;
          setNear(true);
          observer.disconnect();
        }
      },
      { root: null, rootMargin, threshold: 0 },
    );
    observer.observe(rootEl);
    return () => observer.disconnect();
  }, [near, rootEl, rootMargin]);

  const LazyWidget = useMemo(() => lazy(load), [load, widgetId]);

  if (!near) {
    return (
      <div className="hd-widget-body hd-widget-body--deferred" ref={rootRef} aria-busy="true">
        <div className="hd-widget-empty">Loading…</div>
      </div>
    );
  }

  return (
    <Suspense fallback={<WidgetSkeleton />}>
      <LazyWidget />
    </Suspense>
  );
}
