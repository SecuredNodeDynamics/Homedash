"use client";

import { useEffect, useId, useState } from "react";
import type { AppSettings, DashboardTab, LayoutConfig } from "@/lib/types";
import { useDashboardStore } from "@/lib/store";
import { DashboardBoard } from "./DashboardBoard";

/**
 * Lets a tab's widget layout (size/position, per device) be edited from inside
 * Settings — without leaving the page. Wraps the same DashboardBoard used on
 * the live dashboard (breakpoint switch, lock, add widget, align tops, auto
 * layout all come along for free); this modal only supplies the outer
 * Save/Cancel actions and fetches/persists the layout via /api/layout.
 */
export function EditTabLayoutModal({
  settings,
  tab,
  isPersonalTab = false,
  onClose,
}: {
  settings: AppSettings;
  tab: DashboardTab;
  isPersonalTab?: boolean;
  onClose: () => void;
}) {
  const titleId = useId();
  const [layout, setLayoutState] = useState<LayoutConfig | null>(null);
  const [loadError, setLoadError] = useState(false);
  const [saving, setSaving] = useState(false);
  const setEditMode = useDashboardStore((s) => s.setEditMode);

  useEffect(() => {
    let cancelled = false;
    fetch(`/api/layout?tab=${encodeURIComponent(tab.id)}`)
      .then((res) => {
        if (!res.ok) throw new Error("Failed to load layout");
        return res.json() as Promise<LayoutConfig>;
      })
      .then((data) => {
        if (!cancelled) setLayoutState(data);
      })
      .catch(() => {
        if (!cancelled) setLoadError(true);
      });
    return () => {
      cancelled = true;
    };
  }, [tab.id]);

  // Enter edit mode for the lifetime of this modal; always leave it clean on close.
  useEffect(() => {
    setEditMode(true);
    return () => {
      setEditMode(false);
      useDashboardStore.setState({
        layout: null,
        dirty: false,
        activeTabId: null,
        editBreakpoint: null,
        editOrientation: null,
      });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- run once per mount/unmount
  }, []);

  async function handleSave() {
    const { layout: current, activeTabId } = useDashboardStore.getState();
    if (!current || !activeTabId) {
      onClose();
      return;
    }
    setSaving(true);
    try {
      const res = await fetch("/api/layout", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tabId: activeTabId, layout: current }),
      });
      if (!res.ok) {
        alert("Failed to save layout");
        return;
      }
      onClose();
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="hd-modal-scrim" role="presentation" onClick={onClose}>
      <div
        className="hd-modal hd-modal--edit-layout"
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        onClick={(e) => e.stopPropagation()}
      >
        <header className="hd-modal__head">
          <div>
            <div className="hd-settings__kicker">{tab.name}</div>
            <h2 id={titleId}>Edit layout</h2>
            <p>Resize and reposition this tab&rsquo;s widget cards, per device size.</p>
          </div>
          <div className="hd-modal__head-actions">
            <button className="hd-btn" type="button" onClick={onClose} disabled={saving}>
              Cancel
            </button>
            <button
              className="hd-btn hd-btn--primary"
              type="button"
              disabled={saving || !layout}
              onClick={() => void handleSave()}
            >
              {saving ? "Saving…" : "Save layout"}
            </button>
          </div>
        </header>
        <div className="hd-modal__edit-layout-body">
          {loadError ? (
            <div className="hd-modal__status">Could not load this tab&rsquo;s layout.</div>
          ) : !layout ? (
            <div className="hd-modal__status">Loading layout…</div>
          ) : (
            <DashboardBoard
              settings={settings}
              tab={tab}
              initialLayout={layout}
              isPersonalTab={isPersonalTab}
            />
          )}
        </div>
      </div>
    </div>
  );
}
