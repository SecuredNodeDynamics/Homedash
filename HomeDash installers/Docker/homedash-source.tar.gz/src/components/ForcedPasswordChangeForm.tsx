"use client";
import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";

export function ForcedPasswordChangeForm() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [verify, setVerify] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(event: FormEvent) {
    event.preventDefault();
    if (password !== verify) return setError("Passwords do not match");
    setBusy(true); setError("");
    const response = await fetch("/api/auth/change-password", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ nextPassword: password }) });
    const data = await response.json().catch(() => ({}));
    setBusy(false);
    if (!response.ok) return setError(data.error || "Password change failed");
    router.replace("/"); router.refresh();
  }
  return <div className="hd-auth"><div className="hd-auth__card"><div className="hd-auth__brand"><div className="hd-auth__logo-fallback">↻</div><div><div className="hd-auth__app">Create a new password</div><div className="hd-auth__sub">Your temporary password must be replaced before continuing.</div></div></div><form className="hd-auth__form" onSubmit={submit}><label className="hd-auth__field"><span>New password</span><input type="password" minLength={8} required autoFocus value={password} onChange={(e) => setPassword(e.target.value)} /></label><label className="hd-auth__field"><span>Verify new password</span><input type="password" minLength={8} required value={verify} onChange={(e) => setVerify(e.target.value)} /></label>{error ? <div className="hd-auth__error">{error}</div> : null}<button className="hd-btn hd-btn--primary hd-auth__submit" disabled={busy}>{busy ? "Saving…" : "Set new password"}</button></form></div></div>;
}
