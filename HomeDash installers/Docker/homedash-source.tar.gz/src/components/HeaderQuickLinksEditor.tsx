"use client";

import { useEffect, useRef, useState } from "react";
import type { CSSProperties } from "react";
import { createPortal } from "react-dom";
import type { HeaderQuickLinkItem, HeaderQuickLinks } from "@/lib/header-quick-links";
import {
  HEADER_QUICK_LINKS,
  normalizeHeaderQuickLinkItems,
} from "@/lib/header-quick-links";

function makeId(label: string, items: HeaderQuickLinkItem[]) {
  const base =
    label
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 50) || "custom-link";
  let id = base;
  let suffix = 2;
  while (items.some((item) => item.id === id)) id = `${base}-${suffix++}`;
  return id;
}

function IconPreview({ item }: { item: HeaderQuickLinkItem }) {
  const builtIn = HEADER_QUICK_LINKS.find((link) => link.id === item.id);
  const icon = String(item.icon || "").trim();
  if (/^(https?:\/\/|\/)/i.test(icon)) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={icon} alt="" />;
  }
  return <>{icon || builtIn?.icon || "↗"}</>;
}

export function HeaderQuickLinksEditor({
  items,
  legacy,
  onChange,
}: {
  items?: HeaderQuickLinkItem[];
  legacy?: HeaderQuickLinks;
  onChange: (items: HeaderQuickLinkItem[]) => void;
}) {
  const links = normalizeHeaderQuickLinkItems(items, legacy);
  const uploadInputRef = useRef<HTMLInputElement>(null);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [draft, setDraft] = useState<HeaderQuickLinkItem | null>(null);
  const [iconPickerOpen, setIconPickerOpen] = useState(false);
  const [iconQuery, setIconQuery] = useState("");
  const [iconResults, setIconResults] = useState<Array<{ name: string; url: string }>>([]);
  const [iconLoading, setIconLoading] = useState(false);
  const [iconError, setIconError] = useState("");
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (!iconPickerOpen) return;
    let alive = true;
    setIconLoading(true);
    setIconError("");
    const timer = window.setTimeout(async () => {
      try {
        const response = await fetch(
          `/api/dashboard-icons?q=${encodeURIComponent(iconQuery.trim())}&limit=240`,
          { cache: "no-store" },
        );
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.error || "Icon search failed");
        if (alive) setIconResults(Array.isArray(data.icons) ? data.icons : []);
      } catch (error) {
        if (alive) {
          setIconResults([]);
          setIconError(error instanceof Error ? error.message : "Icon search failed");
        }
      } finally {
        if (alive) setIconLoading(false);
      }
    }, iconQuery.trim() ? 220 : 0);
    return () => {
      alive = false;
      window.clearTimeout(timer);
    };
  }, [iconPickerOpen, iconQuery]);

  function patch(index: number, update: Partial<HeaderQuickLinkItem>) {
    onChange(links.map((item, itemIndex) => itemIndex === index ? { ...item, ...update } : item));
  }

  function move(index: number, direction: -1 | 1) {
    const target = index + direction;
    if (target < 0 || target >= links.length) return;
    const next = [...links];
    [next[index], next[target]] = [next[target], next[index]];
    onChange(next);
  }

  function openAdd() {
    setEditingIndex(null);
    setDraft({
      id: "",
      label: "",
      href: "",
      enabled: true,
      icon: "↗",
      color: "#43e5ff",
    });
  }

  function openEdit(index: number) {
    setEditingIndex(index);
    setDraft({ ...links[index] });
  }

  function closeEditor() {
    if (iconPickerOpen) return;
    setEditingIndex(null);
    setDraft(null);
    setIconError("");
  }

  function saveDraft() {
    if (!draft) return;
    const label = draft.label.trim() || "Quick Link";
    const href = draft.href.trim();
    const next = {
      ...draft,
      id: editingIndex == null ? makeId(label, links) : draft.id,
      label,
      href,
    };
    if (editingIndex == null) onChange([...links, next]);
    else onChange(links.map((item, index) => index === editingIndex ? next : item));
    setEditingIndex(null);
    setDraft(null);
  }

  function openPicker() {
    setIconPickerOpen(true);
    setIconQuery(draft?.label || "");
    setIconResults([]);
    setIconError("");
  }

  function closePicker() {
    setIconPickerOpen(false);
    setIconQuery("");
    setIconResults([]);
    setIconError("");
  }

  async function uploadIcon(file: File | undefined) {
    if (!file || !draft) return;
    if (file.size > 25 * 1024 * 1024) {
      setIconError("File exceeds the 25 MB limit");
      return;
    }
    setUploading(true);
    setIconError("");
    try {
      const body = new FormData();
      body.set("kind", "widget-icon");
      body.set("key", `quick-link-${draft.id || makeId(draft.label, links) || Date.now()}`);
      body.set("file", file);
      const response = await fetch("/api/uploads", { method: "POST", body });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || "Upload failed");
      setDraft((current) => current ? { ...current, icon: String(data.url || "") } : current);
      closePicker();
    } catch (error) {
      setIconError(error instanceof Error ? error.message : "Upload failed");
    } finally {
      setUploading(false);
      if (uploadInputRef.current) uploadInputRef.current.value = "";
    }
  }

  return (
    <div className="hd-quick-link-editor">
      <div className="hd-quick-link-editor__actions">
        <span>{links.length} configured · {links.filter((item) => item.enabled).length} shown</span>
        <div>
          <button className="hd-btn" type="button" onClick={() => onChange(normalizeHeaderQuickLinkItems(undefined, legacy))}>
            Reset built-ins
          </button>
          <button className="hd-btn hd-btn--primary" type="button" onClick={openAdd}>
            + Add quick link
          </button>
        </div>
      </div>

      <div className="hd-quick-link-editor__grid">
        {links.map((item, index) => (
          <article
            className={`hd-quick-link-card${item.enabled ? " is-enabled" : " is-hidden"}`}
            key={item.id}
            style={{ "--quick-link-accent": item.color || "#43e5ff" } as CSSProperties}
          >
            <button className="hd-quick-link-card__main" type="button" onClick={() => openEdit(index)}>
              <span className="hd-quick-link-card__icon" aria-hidden><IconPreview item={item} /></span>
              <span className="hd-quick-link-card__copy">
                <strong>{item.label || "Untitled link"}</strong>
                <small>{item.enabled ? "Visible in header" : "Hidden from header"}</small>
              </span>
              <span className="hd-quick-link-card__edit" aria-hidden>✎</span>
            </button>
            <div className="hd-quick-link-card__controls">
              <label className="hd-quick-link-editor__switch" title={item.enabled ? "Hide link" : "Show link"}>
                <input
                  type="checkbox"
                  checked={item.enabled}
                  onChange={(event) => patch(index, { enabled: event.target.checked })}
                />
                <span aria-hidden />
              </label>
              <div className="hd-quick-link-editor__order">
                <button type="button" disabled={index === 0} onClick={() => move(index, -1)} aria-label={`Move ${item.label} earlier`}>←</button>
                <button type="button" disabled={index === links.length - 1} onClick={() => move(index, 1)} aria-label={`Move ${item.label} later`}>→</button>
              </div>
            </div>
          </article>
        ))}
        {!links.length ? <div className="hd-quick-link-editor__empty">No quick links yet. Add one to begin.</div> : null}
      </div>

      <input
        ref={uploadInputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp,image/gif,image/svg+xml,image/x-icon,.ico"
        hidden
        onChange={(event) => void uploadIcon(event.target.files?.[0])}
      />

      {draft && typeof document !== "undefined"
        ? createPortal(
            <div className="hd-modal-scrim hd-quick-link-form-scrim" role="presentation" onClick={closeEditor}>
              <div className="hd-modal hd-modal--quick-link" role="dialog" aria-modal="true" aria-labelledby="hd-quick-link-form-title" onClick={(event) => event.stopPropagation()}>
                <header className="hd-modal__head">
                  <div>
                    <div className="hd-settings__kicker">Header Shortcut</div>
                    <h2 id="hd-quick-link-form-title">{editingIndex == null ? "Add quick link" : "Edit quick link"}</h2>
                    <p>Choose where it goes and how it appears in the dashboard header.</p>
                  </div>
                  <button type="button" className="hd-btn" onClick={closeEditor}>Close</button>
                </header>

                <div className="hd-quick-link-form">
                  <div className="hd-quick-link-form__preview" style={{ "--quick-link-accent": draft.color || "#43e5ff" } as CSSProperties}>
                    <span className="hd-quick-link-form__preview-icon"><IconPreview item={draft} /></span>
                    <div><strong>{draft.label || "Quick Link"}</strong><span>{draft.enabled ? "Visible in header" : "Hidden from header"}</span></div>
                  </div>
                  <div className="hd-field">
                    <label htmlFor="quickLinkLabel">Label</label>
                    <input id="quickLinkLabel" type="text" value={draft.label} maxLength={80} placeholder="My quick link" autoFocus onChange={(event) => setDraft({ ...draft, label: event.target.value })} />
                  </div>
                  <div className="hd-field">
                    <label htmlFor="quickLinkUrl">Destination URL</label>
                    <input id="quickLinkUrl" type="url" value={draft.href} maxLength={2048} placeholder="https://example.com/" onChange={(event) => setDraft({ ...draft, href: event.target.value })} />
                  </div>
                  <div className="hd-field">
                    <label htmlFor="quickLinkIcon">Icon glyph or URL</label>
                    <div className="hd-quick-link-form__icon-row">
                      <input id="quickLinkIcon" type="text" value={draft.icon || ""} maxLength={2048} placeholder="🔗 or icon URL" onChange={(event) => setDraft({ ...draft, icon: event.target.value })} />
                      <button className="hd-btn" type="button" onClick={openPicker}>Select logo</button>
                      <button className="hd-btn" type="button" disabled={uploading} onClick={() => uploadInputRef.current?.click()}>{uploading ? "Uploading…" : "Upload"}</button>
                    </div>
                  </div>
                  <div className="hd-field-row">
                    <div className="hd-field">
                      <label htmlFor="quickLinkColor">Accent</label>
                      <div className="hd-quick-link-form__color">
                        <input id="quickLinkColor" type="color" value={/^#[0-9a-f]{6}$/i.test(draft.color || "") ? draft.color : "#43e5ff"} onChange={(event) => setDraft({ ...draft, color: event.target.value })} />
                        <span>{draft.color || "#43e5ff"}</span>
                      </div>
                    </div>
                    <div className="hd-field">
                      <label>Visibility</label>
                      <button type="button" className={`hd-quick-link-form__visibility${draft.enabled ? " is-on" : ""}`} onClick={() => setDraft({ ...draft, enabled: !draft.enabled })}>
                        <span aria-hidden /> {draft.enabled ? "Shown in header" : "Hidden from header"}
                      </button>
                    </div>
                  </div>
                  {iconError ? <div className="hd-asset-error">{iconError}</div> : null}
                </div>

                <footer className="hd-quick-link-form__footer">
                  {editingIndex != null ? (
                    <button type="button" className="hd-btn hd-btn--danger" onClick={() => {
                      onChange(links.filter((_, index) => index !== editingIndex));
                      setEditingIndex(null);
                      setDraft(null);
                    }}>Delete link</button>
                  ) : <span />}
                  <div>
                    <button type="button" className="hd-btn" onClick={closeEditor}>Cancel</button>
                    <button type="button" className="hd-btn hd-btn--primary" disabled={!draft.label.trim() || !draft.href.trim()} onClick={saveDraft}>
                      {editingIndex == null ? "Add link" : "Save changes"}
                    </button>
                  </div>
                </footer>
              </div>
            </div>,
            document.body,
          )
        : null}

      {iconPickerOpen && draft && typeof document !== "undefined"
        ? createPortal(
            <div className="hd-modal-scrim hd-modal-scrim--icons" role="presentation" onClick={closePicker}>
              <div className="hd-modal hd-modal--icons" role="dialog" aria-modal="true" aria-labelledby="hd-quick-link-icon-title" onClick={(event) => event.stopPropagation()}>
                <header className="hd-modal__head">
                  <div>
                    <div className="hd-settings__kicker">Quick Link Logo</div>
                    <h2 id="hd-quick-link-icon-title">Select a logo</h2>
                    <p>Search the local dashboard icon library or upload your own image.</p>
                  </div>
                  <button type="button" className="hd-btn" onClick={closePicker}>Close</button>
                </header>
                <div className="hd-quick-link-editor__picker-tools">
                  <input className="hd-search" type="search" placeholder="Search icons…" value={iconQuery} onChange={(event) => setIconQuery(event.target.value)} autoFocus />
                  <button className="hd-btn hd-btn--primary" type="button" disabled={uploading} onClick={() => uploadInputRef.current?.click()}>
                    {uploading ? "Uploading…" : "Upload my logo"}
                  </button>
                </div>
                {iconError ? <div className="hd-asset-error">{iconError}</div> : null}
                <div className="hd-icon-grid">
                  {iconLoading ? <div className="hd-icon-grid__empty">Loading icons…</div> : null}
                  {!iconLoading && !iconResults.length ? <div className="hd-icon-grid__empty">No matching icons found.</div> : null}
                  {iconResults.map((icon) => (
                    <button key={icon.name} type="button" className="hd-icon-grid__item" title={icon.name} onClick={() => {
                      setDraft({ ...draft, icon: icon.url });
                      closePicker();
                    }}>
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={icon.url} alt="" loading="lazy" />
                      <span>{icon.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>,
            document.body,
          )
        : null}
    </div>
  );
}
