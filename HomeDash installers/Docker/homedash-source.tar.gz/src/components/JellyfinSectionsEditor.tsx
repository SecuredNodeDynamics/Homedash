"use client";

import { useMemo, useState } from "react";

export type JellyfinSectionDraft = {
  key: string;
  title: string;
  itemTypes: string;
  parentId: string;
  limit: string;
};

const ITEM_TYPES = [
  { value: "Movie", label: "Movies" },
  { value: "Series", label: "TV" },
  { value: "MusicAlbum", label: "Music" },
  { value: "BoxSet", label: "Collections" },
] as const;

const DEFAULT_FIELDS =
  "ProductionYear,ImageTags,BackdropImageTags,Overview,Genres,RunTimeTicks,OfficialRating,Type,ChildCount,AlbumArtist,Artists,AlbumPrimaryImageTag,ParentId";

function slugKey(title: string, used: string[]) {
  const base =
    title
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "") || "section";
  if (!used.includes(base)) return base;
  let n = 2;
  while (used.includes(`${base}-${n}`)) n += 1;
  return `${base}-${n}`;
}

export function parseSectionsDraft(sectionsJson: string | undefined): JellyfinSectionDraft[] {
  if (!sectionsJson?.trim()) {
    return [
      { key: "movies", title: "Movies", itemTypes: "Movie", parentId: "", limit: "25" },
      { key: "tv", title: "TV", itemTypes: "Series", parentId: "", limit: "25" },
      { key: "music", title: "Music", itemTypes: "MusicAlbum", parentId: "", limit: "25" },
    ];
  }
  try {
    const parsed = JSON.parse(sectionsJson) as Array<Record<string, unknown>>;
    if (!Array.isArray(parsed) || !parsed.length) return parseSectionsDraft("");
    return parsed.map((section, index) => ({
      key: String(section.key || `section-${index + 1}`),
      title: String(section.title || section.key || `Section ${index + 1}`),
      itemTypes: String(section.itemTypes || "Movie"),
      parentId: String(section.parentId || ""),
      limit: String(section.limit ?? 25),
    }));
  } catch {
    return parseSectionsDraft("");
  }
}

export function serializeSectionsDraft(sections: JellyfinSectionDraft[]) {
  const used: string[] = [];
  return JSON.stringify(
    sections
      .filter((section) => section.title.trim())
      .map((section) => {
        const title = section.title.trim();
        const key = section.key.trim() || slugKey(title, used);
        used.push(key);
        const limit = Number(section.limit);
        const entry: Record<string, string | number> = {
          key,
          title,
          itemTypes: section.itemTypes || "Movie",
          limit: Number.isFinite(limit) && limit > 0 ? Math.min(200, Math.round(limit)) : 25,
          fields: DEFAULT_FIELDS,
        };
        if (section.parentId.trim()) entry.parentId = section.parentId.trim();
        return entry;
      }),
  );
}

export function JellyfinSectionsEditor({
  value,
  onChange,
}: {
  value: string;
  onChange: (sectionsJson: string) => void;
}) {
  const sections = useMemo(() => parseSectionsDraft(value), [value]);
  const [libraryOpen, setLibraryOpen] = useState<number | null>(null);

  function commit(next: JellyfinSectionDraft[]) {
    onChange(serializeSectionsDraft(next));
  }

  function updateAt(index: number, patch: Partial<JellyfinSectionDraft>) {
    const next = sections.map((section, i) => {
      if (i !== index) return section;
      const merged = { ...section, ...patch };
      if (patch.title != null && (!section.key || section.key === slugKey(section.title, []))) {
        const used = sections.filter((_, j) => j !== index).map((s) => s.key);
        merged.key = slugKey(patch.title, used);
      }
      return merged;
    });
    commit(next);
  }

  function addSection() {
    const used = sections.map((s) => s.key);
    const title = `Section ${sections.length + 1}`;
    commit([
      ...sections,
      {
        key: slugKey(title, used),
        title,
        itemTypes: "Movie",
        parentId: "",
        limit: "25",
      },
    ]);
  }

  function removeAt(index: number) {
    if (sections.length <= 1) return;
    if (libraryOpen === index) setLibraryOpen(null);
    commit(sections.filter((_, i) => i !== index));
  }

  function move(index: number, delta: number) {
    const target = index + delta;
    if (target < 0 || target >= sections.length) return;
    const next = [...sections];
    const [row] = next.splice(index, 1);
    next.splice(target, 0, row);
    commit(next);
    if (libraryOpen === index) setLibraryOpen(target);
    else if (libraryOpen === target) setLibraryOpen(index);
  }

  return (
    <div className="hd-jf-sections">
      <div className="hd-jf-sections__head">
        <div>
          <strong>Slider tabs</strong>
          <p>{sections.length} tabs · name, type, and max items</p>
        </div>
        <button className="hd-btn" type="button" onClick={addSection}>
          Add tab
        </button>
      </div>

      <div className="hd-jf-sections__list" role="list">
        {sections.map((section, index) => {
          const showLibrary = libraryOpen === index || Boolean(section.parentId.trim());
          return (
            <div className="hd-jf-section" key={`${section.key}-${index}`} role="listitem">
              <div className="hd-jf-section__row">
                <span className="hd-jf-section__index" aria-hidden>
                  {index + 1}
                </span>
                <input
                  className="hd-jf-section__title"
                  type="text"
                  aria-label={`Tab ${index + 1} name`}
                  value={section.title}
                  placeholder="Tab name"
                  onChange={(e) => updateAt(index, { title: e.target.value })}
                />
                <select
                  className="hd-jf-section__type"
                  aria-label={`Tab ${index + 1} media type`}
                  value={section.itemTypes}
                  onChange={(e) => updateAt(index, { itemTypes: e.target.value })}
                >
                  {ITEM_TYPES.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
                <label className="hd-jf-section__limit-wrap" title="Maximum media items in this category">
                  <span>Items</span>
                  <input
                    className="hd-jf-section__limit"
                    type="number"
                    min={1}
                    max={200}
                    aria-label={`Tab ${index + 1} max items`}
                    value={section.limit}
                    onChange={(e) => updateAt(index, { limit: e.target.value })}
                  />
                </label>
                <div className="hd-jf-section__tools">
                  <button
                    className="hd-btn hd-btn--ghost"
                    type="button"
                    aria-label="Library ID"
                    title="Optional library / folder ID"
                    aria-pressed={showLibrary}
                    onClick={() => setLibraryOpen((cur) => (cur === index ? null : index))}
                  >
                    Lib
                  </button>
                  <button
                    className="hd-btn hd-btn--ghost"
                    type="button"
                    aria-label="Move up"
                    disabled={index === 0}
                    onClick={() => move(index, -1)}
                  >
                    ↑
                  </button>
                  <button
                    className="hd-btn hd-btn--ghost"
                    type="button"
                    aria-label="Move down"
                    disabled={index === sections.length - 1}
                    onClick={() => move(index, 1)}
                  >
                    ↓
                  </button>
                  <button
                    className="hd-chip hd-chip--danger"
                    type="button"
                    disabled={sections.length <= 1}
                    onClick={() => removeAt(index)}
                  >
                    ×
                  </button>
                </div>
              </div>

              {showLibrary ? (
                <div className="hd-jf-section__library">
                  <input
                    type="text"
                    aria-label={`Tab ${index + 1} library ID`}
                    value={section.parentId}
                    placeholder="Library / folder ID (optional)"
                    spellCheck={false}
                    onChange={(e) => updateAt(index, { parentId: e.target.value })}
                  />
                </div>
              ) : null}
            </div>
          );
        })}
      </div>
    </div>
  );
}
