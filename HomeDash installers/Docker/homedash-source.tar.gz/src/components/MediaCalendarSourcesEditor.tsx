"use client";

import "@/styles/widgets/calendar.widget.css";

import { useMemo, useState } from "react";

export type CalendarSourceDraft = {
  type: "sonarr" | "radarr" | "lidarr" | "seerr";
  label: string;
  color: string;
  url: string;
  fallbackUrl: string;
  key: string;
};

const SOURCE_TYPES = [
  { value: "sonarr", label: "Sonarr", color: "#2dd4bf" },
  { value: "radarr", label: "Radarr", color: "#fb923c" },
  { value: "lidarr", label: "Lidarr", color: "#c084fc" },
  { value: "seerr", label: "Seerr", color: "#a78bfa" },
] as const;

const DEFAULT_COLORS: Record<CalendarSourceDraft["type"], string> = {
  sonarr: "#2dd4bf",
  radarr: "#fb923c",
  lidarr: "#c084fc",
  seerr: "#a78bfa",
};

const FLAT_KEYS = [
  "sonarrUrl",
  "sonarrKey",
  "sonarrFallbackUrl",
  "sonarr2Url",
  "sonarr2Key",
  "sonarr2FallbackUrl",
  "radarrUrl",
  "radarrKey",
  "radarrFallbackUrl",
  "radarr2Url",
  "radarr2Key",
  "radarr2FallbackUrl",
  "lidarrUrl",
  "lidarrKey",
  "lidarrFallbackUrl",
  "seerrUrl",
  "seerrKey",
  "seerrFallbackUrl",
] as const;

function sourcesFromFlat(config: Record<string, string>): CalendarSourceDraft[] {
  const rows: CalendarSourceDraft[] = [];
  const push = (
    type: CalendarSourceDraft["type"],
    label: string,
    url?: string,
    key?: string,
    fallbackUrl?: string,
  ) => {
    if (!url?.trim() && !key?.trim()) return;
    rows.push({
      type,
      label,
      color: DEFAULT_COLORS[type],
      url: url || "",
      fallbackUrl: fallbackUrl || "",
      key: key || "",
    });
  };
  push("sonarr", "Sonarr 1", config.sonarrUrl, config.sonarrKey, config.sonarrFallbackUrl);
  push("sonarr", "Sonarr 2", config.sonarr2Url, config.sonarr2Key, config.sonarr2FallbackUrl);
  push("radarr", "Radarr 1", config.radarrUrl, config.radarrKey, config.radarrFallbackUrl);
  push("radarr", "Radarr 2", config.radarr2Url, config.radarr2Key, config.radarr2FallbackUrl);
  push("lidarr", "Lidarr", config.lidarrUrl, config.lidarrKey, config.lidarrFallbackUrl);
  push("seerr", "Seerr", config.seerrUrl, config.seerrKey, config.seerrFallbackUrl);
  return rows;
}

export function parseCalendarSources(config: Record<string, string> | undefined): CalendarSourceDraft[] {
  const cfg = (config || {}) as Record<string, unknown>;

  const fromArray = (parsed: unknown): CalendarSourceDraft[] | null => {
    if (!Array.isArray(parsed) || !parsed.length) return null;
    return parsed.map((source, index) => {
      const row = (source || {}) as Record<string, unknown>;
      const type = String(row.type || "sonarr") as CalendarSourceDraft["type"];
      const safeType = SOURCE_TYPES.some((t) => t.value === type) ? type : "sonarr";
      return {
        type: safeType,
        label: String(row.label || `${SOURCE_TYPES.find((t) => t.value === safeType)?.label} ${index + 1}`),
        color: String(row.color || DEFAULT_COLORS[safeType]),
        url: String(row.url || ""),
        fallbackUrl: String(row.fallbackUrl || ""),
        key: String(row.key || ""),
      };
    });
  };

  try {
    if (typeof cfg.sourcesJson === "string" && cfg.sourcesJson.trim()) {
      const parsed = fromArray(JSON.parse(cfg.sourcesJson));
      if (parsed) return parsed;
    }
  } catch {
    /* fall through */
  }

  const fromSources = fromArray(cfg.sources);
  if (fromSources) return fromSources;

  const fromFlat = sourcesFromFlat(
    Object.fromEntries(
      Object.entries(cfg).filter((entry): entry is [string, string] => typeof entry[1] === "string"),
    ),
  );
  if (fromFlat.length) return fromFlat;

  return [
    {
      type: "sonarr",
      label: "Sonarr 1",
      color: DEFAULT_COLORS.sonarr,
      url: "",
      fallbackUrl: "",
      key: "",
    },
  ];
}

/** Build the widget config patch: sources array + clear legacy flat keys. */
export function serializeCalendarSources(sources: CalendarSourceDraft[]): Record<string, string> {
  // Keep incomplete rows while the settings form is being edited. The calendar
  // resolver already ignores rows without both a URL and API key, and dropping
  // them here made a newly added (blank) source disappear immediately.
  const cleaned = sources.map((source) => ({
    type: source.type,
    label: source.label.trim() || SOURCE_TYPES.find((t) => t.value === source.type)?.label || source.type,
    color: source.color || DEFAULT_COLORS[source.type],
    url: source.url.trim(),
    ...(source.fallbackUrl.trim() ? { fallbackUrl: source.fallbackUrl.trim() } : {}),
    key: source.key.trim(),
  }));

  const patch: Record<string, string> = {
    sourcesJson: JSON.stringify(cleaned),
  };
  for (const key of FLAT_KEYS) patch[key] = "";
  return patch;
}

export function MediaCalendarSourcesEditor({
  value,
  onChange,
}: {
  value: Record<string, string>;
  onChange: (patch: Record<string, string>) => void;
}) {
  const sources = useMemo(() => parseCalendarSources(value), [value]);
  const [fallbackOpen, setFallbackOpen] = useState<number | null>(null);

  function commit(next: CalendarSourceDraft[]) {
    onChange(serializeCalendarSources(next));
  }

  function updateAt(index: number, patch: Partial<CalendarSourceDraft>) {
    commit(
      sources.map((source, i) => {
        if (i !== index) return source;
        const merged = { ...source, ...patch };
        if (patch.type && patch.type !== source.type) {
          merged.color = DEFAULT_COLORS[patch.type];
          if (!patch.label && (!source.label || source.label.startsWith(SOURCE_TYPES.find((t) => t.value === source.type)?.label || ""))) {
            merged.label = SOURCE_TYPES.find((t) => t.value === patch.type!)?.label || patch.type;
          }
        }
        return merged;
      }),
    );
  }

  function addSource() {
    commit([
      ...sources,
      {
        type: "sonarr",
        label: `Sonarr ${sources.filter((s) => s.type === "sonarr").length + 1}`,
        color: DEFAULT_COLORS.sonarr,
        url: "",
        fallbackUrl: "",
        key: "",
      },
    ]);
  }

  function removeAt(index: number) {
    if (sources.length <= 1) return;
    if (fallbackOpen === index) setFallbackOpen(null);
    commit(sources.filter((_, i) => i !== index));
  }

  function move(index: number, delta: number) {
    const target = index + delta;
    if (target < 0 || target >= sources.length) return;
    const next = [...sources];
    const [row] = next.splice(index, 1);
    next.splice(target, 0, row);
    commit(next);
    if (fallbackOpen === index) setFallbackOpen(target);
    else if (fallbackOpen === target) setFallbackOpen(index);
  }

  return (
    <div className="hd-mcal-sources">
      <div className="hd-mcal-sources__head">
        <div>
          <strong>Calendar sources</strong>
          <p>{sources.length} services · URL + API key per row</p>
        </div>
        <button className="hd-btn" type="button" onClick={addSource}>
          Add source
        </button>
      </div>

      <div className="hd-mcal-sources__list" role="list">
        {sources.map((source, index) => {
          const showFallback = fallbackOpen === index || Boolean(source.fallbackUrl.trim());
          return (
            <div className="hd-mcal-source" key={`${source.type}-${index}`} role="listitem">
              <div className="hd-mcal-source__row">
                <span
                  className="hd-mcal-source__swatch"
                  style={{ background: source.color || DEFAULT_COLORS[source.type] }}
                  aria-hidden
                />
                <select
                  className="hd-mcal-source__type"
                  aria-label={`Source ${index + 1} type`}
                  value={source.type}
                  onChange={(e) =>
                    updateAt(index, { type: e.target.value as CalendarSourceDraft["type"] })
                  }
                >
                  {SOURCE_TYPES.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
                <input
                  className="hd-mcal-source__label"
                  type="text"
                  aria-label={`Source ${index + 1} label`}
                  value={source.label}
                  placeholder="Label"
                  onChange={(e) => updateAt(index, { label: e.target.value })}
                />
                <input
                  className="hd-mcal-source__url"
                  type="url"
                  aria-label={`Source ${index + 1} URL`}
                  value={source.url}
                  placeholder="https://…"
                  spellCheck={false}
                  onChange={(e) => updateAt(index, { url: e.target.value })}
                />
                <input
                  className="hd-mcal-source__key"
                  type="password"
                  aria-label={`Source ${index + 1} API key`}
                  value={source.key}
                  placeholder="API key"
                  autoComplete="off"
                  spellCheck={false}
                  onChange={(e) => updateAt(index, { key: e.target.value })}
                />
                <div className="hd-mcal-source__tools">
                  <button
                    className="hd-btn hd-btn--ghost"
                    type="button"
                    aria-label="Fallback URL"
                    title="Optional fallback URL"
                    aria-pressed={showFallback}
                    onClick={() => setFallbackOpen((cur) => (cur === index ? null : index))}
                  >
                    FB
                  </button>
                  <button
                    className="hd-btn hd-btn--ghost"
                    type="button"
                    aria-label="Move up"
                    disabled={index === 0}
                    onClick={() => move(index, -1)}
                  >
                    ↑
                  </button>
                  <button
                    className="hd-btn hd-btn--ghost"
                    type="button"
                    aria-label="Move down"
                    disabled={index === sources.length - 1}
                    onClick={() => move(index, 1)}
                  >
                    ↓
                  </button>
                  <button
                    className="hd-chip hd-chip--danger"
                    type="button"
                    disabled={sources.length <= 1}
                    onClick={() => removeAt(index)}
                  >
                    ×
                  </button>
                </div>
              </div>

              {showFallback ? (
                <div className="hd-mcal-source__fallback">
                  <input
                    type="url"
                    aria-label={`Source ${index + 1} fallback URL`}
                    value={source.fallbackUrl}
                    placeholder="Fallback URL (optional)"
                    spellCheck={false}
                    onChange={(e) => updateAt(index, { fallbackUrl: e.target.value })}
                  />
                </div>
              ) : null}
            </div>
          );
        })}
      </div>
    </div>
  );
}
