"use client";

import { useEffect } from "react";

const FOCUS = "hd-widget--scroll-focus";
const LONG_PRESS_MS = 480;
const MOVE_CANCEL_PX = 12;
const EDGE_EPS = 1.5;

function clearScrollFocus(except?: Element | null) {
  document.querySelectorAll(`.hd-widget.${FOCUS}`).forEach((el) => {
    if (except && el === except) return;
    el.classList.remove(FOCUS);
    el.removeAttribute("data-scroll-focus");
  });
}

function focusWidget(widget: HTMLElement) {
  clearScrollFocus();
  widget.classList.add(FOCUS);
  widget.setAttribute("data-scroll-focus", "true");
}

function isTouchPointer(pointerType: string) {
  return pointerType === "touch";
}

function contentOverflowsY(el: HTMLElement) {
  return el.scrollHeight > el.clientHeight + EDGE_EPS;
}

function canScrollY(el: HTMLElement) {
  const style = window.getComputedStyle(el);
  const overflowY = style.overflowY;
  if (overflowY !== "auto" && overflowY !== "scroll" && overflowY !== "overlay") return false;
  return contentOverflowsY(el);
}

const PINNED_LIST_SELECTOR = ".pve-ov-scroll, .pve-g-list, .pve-st-list, .pve-hw-scroll";
const SCROLL_PORT_SELECTOR =
  `${PINNED_LIST_SELECTOR}, .hd-widget-scroll, [class*='-scroll'], .pve-body, .hd-widget-body, .uk-scroll, .ts-scroll`;

/**
 * Nearest element that currently scrolls vertically (overflow auto/scroll).
 * Prefer dedicated list ports over outer Proxmox chrome so KPI cards and the
 * node header stay pinned while lists scroll.
 */
function findScrollPort(start: Element | null, widget: HTMLElement): HTMLElement | null {
  const hasPinnedLists = Boolean(widget.querySelector(PINNED_LIST_SELECTOR));

  let node: Element | null = start;
  while (node && node instanceof HTMLElement && widget.contains(node)) {
    if (canScrollY(node)) {
      const isOuterChrome =
        node.classList.contains("hd-widget-body") ||
        node.classList.contains("pve-shell") ||
        (hasPinnedLists && node.classList.contains("pve-body"));
      if (!isOuterChrome) return node;
    }
    if (node === widget) break;
    node = node.parentElement;
  }

  for (const sel of [".pve-ov-scroll", ".pve-g-list", ".pve-st-list", ".pve-hw-scroll", ".pve-body"]) {
    const el = widget.querySelector(sel);
    if (el instanceof HTMLElement && canScrollY(el)) return el;
  }
  return null;
}

/**
 * Content taller than the box — works even while hybrid mode locks overflow to
 * hidden, so we can decide whether focusing the widget is useful.
 */
function findOverflowPort(start: Element | null, widget: HTMLElement): HTMLElement | null {
  const hasPinnedLists = Boolean(widget.querySelector(PINNED_LIST_SELECTOR));

  let node: Element | null = start;
  while (node && node instanceof HTMLElement && widget.contains(node)) {
    if (node.matches(SCROLL_PORT_SELECTOR) && contentOverflowsY(node)) {
      const isOuterChrome =
        node.classList.contains("hd-widget-body") ||
        node.classList.contains("pve-shell") ||
        (hasPinnedLists && node.classList.contains("pve-body"));
      if (!isOuterChrome) return node;
    }
    if (node === widget) break;
    node = node.parentElement;
  }

  for (const sel of [".pve-ov-scroll", ".pve-g-list", ".pve-st-list", ".pve-hw-scroll"]) {
    const el = widget.querySelector(sel);
    if (el instanceof HTMLElement && contentOverflowsY(el)) return el;
  }

  const nodes = widget.querySelectorAll(SCROLL_PORT_SELECTOR);
  for (const el of nodes) {
    if (!(el instanceof HTMLElement) || !contentOverflowsY(el)) continue;
    const isOuterChrome =
      el.classList.contains("hd-widget-body") ||
      el.classList.contains("pve-shell") ||
      (hasPinnedLists && el.classList.contains("pve-body"));
    if (!isOuterChrome) return el;
  }
  return null;
}

function atScrollTop(el: HTMLElement) {
  return el.scrollTop <= EDGE_EPS;
}

function atScrollBottom(el: HTMLElement) {
  return el.scrollTop + el.clientHeight >= el.scrollHeight - EDGE_EPS;
}

function scrollPageBy(deltaY: number) {
  if (!deltaY) return;
  window.scrollBy({ top: deltaY, left: 0, behavior: "auto" });
}

/**
 * If the inner port is at an edge and the user keeps scrolling that way,
 * move the page and release widget focus so scrolling doesn't get stuck.
 */
function chainIfAtEdge(port: HTMLElement, deltaY: number, widget: HTMLElement | null): boolean {
  if (deltaY > 0 && atScrollBottom(port)) {
    scrollPageBy(deltaY);
    if (widget) clearScrollFocus();
    return true;
  }
  if (deltaY < 0 && atScrollTop(port)) {
    scrollPageBy(deltaY);
    if (widget) clearScrollFocus();
    return true;
  }
  return false;
}

/**
 * Hybrid scroll focus: page scroll wins until a widget is focused.
 * - Touch: long-press a widget (not a control) to unlock its inner scroll.
 * - Mouse / pen: only focus widgets that actually have overflow content.
 * Wheel over a non-scrollable widget always moves the page.
 * At list edges, scroll chains to the page and focus clears.
 */
export function MobileScrollFocus({ enabled }: { enabled: boolean }) {
  useEffect(() => {
    if (!enabled) {
      clearScrollFocus();
      return;
    }

    const interactive =
      "button, a, input, textarea, select, label, [role='button'], [role='tab'], .react-resizable-handle, .hd-widget__edit-actions, .hd-widget__drag-handle";

    let pressTimer: number | null = null;
    let startX = 0;
    let startY = 0;
    let pressWidget: HTMLElement | null = null;
    let armed = false;

    let touchLastY = 0;
    let touchActive = false;
    let touchWidget: HTMLElement | null = null;

    const clearPress = () => {
      if (pressTimer != null) {
        window.clearTimeout(pressTimer);
        pressTimer = null;
      }
      pressWidget = null;
      armed = false;
    };

    const onPointerDown = (event: PointerEvent) => {
      if (event.pointerType === "mouse" && event.button !== 0) return;
      const target = event.target as Element | null;
      if (!target?.closest) return;

      const widget = target.closest(".react-grid-item .hd-widget") as HTMLElement | null;

      if (!widget) {
        clearPress();
        clearScrollFocus();
        touchActive = false;
        touchWidget = null;
        return;
      }

      if (target.closest(interactive)) {
        clearPress();
        if (!widget.classList.contains(FOCUS)) clearScrollFocus();
        return;
      }

      if (widget.classList.contains(FOCUS)) {
        clearPress();
        if (isTouchPointer(event.pointerType)) {
          touchActive = true;
          touchWidget = widget;
          touchLastY = event.clientY;
        }
        return;
      }

      if (!isTouchPointer(event.pointerType)) {
        clearPress();
        // Only focus when the widget has something to scroll — otherwise leave
        // page scrolling alone under the cursor.
        if (findOverflowPort(target, widget)) {
          focusWidget(widget);
        }
        return;
      }

      clearPress();
      touchActive = false;
      touchWidget = null;
      pressWidget = widget;
      startX = event.clientX;
      startY = event.clientY;
      armed = true;
      pressTimer = window.setTimeout(() => {
        if (!armed || !pressWidget) return;
        if (findOverflowPort(null, pressWidget)) {
          focusWidget(pressWidget);
        }
        clearPress();
      }, LONG_PRESS_MS);
    };

    const onPointerMove = (event: PointerEvent) => {
      if (!armed || !pressWidget) return;
      const dx = Math.abs(event.clientX - startX);
      const dy = Math.abs(event.clientY - startY);
      if (dx > MOVE_CANCEL_PX || dy > MOVE_CANCEL_PX) {
        clearPress();
      }
    };

    const onPointerUp = () => {
      clearPress();
      touchActive = false;
      touchWidget = null;
    };

    const onTouchMove = (event: TouchEvent) => {
      if (!touchActive || !touchWidget || !touchWidget.classList.contains(FOCUS)) return;
      if (event.touches.length !== 1) return;

      const y = event.touches[0].clientY;
      const fingerDelta = y - touchLastY;
      touchLastY = y;
      if (!fingerDelta) return;

      const target = event.target as Element | null;
      const port = findScrollPort(target, touchWidget) || findOverflowPort(target, touchWidget);
      if (!port) {
        scrollPageBy(-fingerDelta);
        clearScrollFocus();
        event.preventDefault();
        touchActive = false;
        touchWidget = null;
        return;
      }

      const scrollDelta = -fingerDelta;
      if (chainIfAtEdge(port, scrollDelta, touchWidget)) {
        event.preventDefault();
        touchActive = false;
        touchWidget = null;
      }
    };

    const onWheel = (event: WheelEvent) => {
      const target = event.target as Element | null;
      if (!target?.closest) return;
      const widget = target.closest(".react-grid-item .hd-widget") as HTMLElement | null;
      if (!widget) return;
      if (target.closest(interactive)) return;

      const overflowPort = findOverflowPort(target, widget);

      // Nothing to scroll inside this widget → always move the page.
      if (!overflowPort) {
        if (widget.classList.contains(FOCUS)) clearScrollFocus();
        scrollPageBy(event.deltaY);
        event.preventDefault();
        return;
      }

      const focused = widget.classList.contains(FOCUS);
      const port = focused ? findScrollPort(target, widget) || overflowPort : overflowPort;

      // At an edge in this direction → continue on the page.
      if (chainIfAtEdge(port, event.deltaY, widget)) {
        event.preventDefault();
        return;
      }

      // Inner content can scroll — enter focus and apply the delta (hybrid locks
      // overflow until focused, so the browser won't do it for us this frame).
      if (!focused) focusWidget(widget);
      port.scrollTop += event.deltaY;
      event.preventDefault();
    };

    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") clearScrollFocus();
    };

    document.addEventListener("pointerdown", onPointerDown, true);
    document.addEventListener("pointermove", onPointerMove, true);
    document.addEventListener("pointerup", onPointerUp, true);
    document.addEventListener("pointercancel", onPointerUp, true);
    document.addEventListener("touchmove", onTouchMove, { capture: true, passive: false });
    document.addEventListener("wheel", onWheel, { capture: true, passive: false });
    document.addEventListener("keydown", onKey);
    return () => {
      clearPress();
      document.removeEventListener("pointerdown", onPointerDown, true);
      document.removeEventListener("pointermove", onPointerMove, true);
      document.removeEventListener("pointerup", onPointerUp, true);
      document.removeEventListener("pointercancel", onPointerUp, true);
      document.removeEventListener("touchmove", onTouchMove, true);
      document.removeEventListener("wheel", onWheel, true);
      document.removeEventListener("keydown", onKey);
      clearScrollFocus();
    };
  }, [enabled]);

  return null;
}
