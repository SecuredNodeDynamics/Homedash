"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import type { DashboardTab } from "@/lib/types";

export function PersonalDashboardsCard() {
  const router = useRouter();
  const [allowed, setAllowed] = useState(false);
  const [tabs, setTabs] = useState<DashboardTab[]>([]);
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");

  async function load() {
    const me = await fetch("/api/auth/me").then((response) => response.json()).catch(() => ({}));
    const permissions = Array.isArray(me.user?.permissions) ? me.user.permissions : [];
    const can = Boolean(me.user?.username);
    setAllowed(can);
    if (!can) return;
    const data = await fetch("/api/auth/dashboards").then((response) => response.json()).catch(() => ({}));
    setTabs(data.tabs || []);
  }

  useEffect(() => { void load(); }, []);
  if (!allowed) return null;

  async function create() {
    const response = await fetch("/api/auth/dashboards", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name }),
    });
    const data = await response.json();
    if (!response.ok) return setMessage(data.error || "Could not create dashboard");
    setName("");
    await load();
    router.refresh();
  }

  async function rename(tab: DashboardTab) {
    const nextName = window.prompt("Dashboard name", tab.name)?.trim();
    if (!nextName || nextName === tab.name) return;
    const response = await fetch("/api/auth/dashboards", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: tab.id, name: nextName }),
    });
    if (!response.ok) return setMessage("Could not rename dashboard");
    await load();
    router.refresh();
  }

  async function remove(tab: DashboardTab) {
    if (!window.confirm(`Delete your “${tab.name}” dashboard?`)) return;
    const response = await fetch("/api/auth/dashboards", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: tab.id }),
    });
    if (!response.ok) return setMessage("Could not delete dashboard");
    await load();
    router.refresh();
  }

  return (
    <article className="hd-panel-card hd-personal-dashboards">
      <header><h2>Your private tabs</h2><p>Create account-owned tabs. Only you and administrators can see them.</p></header>
      <div className="hd-field-row">
        <div className="hd-field"><label htmlFor="personalDashboardName">Dashboard name</label><input id="personalDashboardName" value={name} onChange={(event) => setName(event.target.value)} placeholder="My dashboard" /></div>
        <button className="hd-btn hd-btn--primary" type="button" disabled={name.trim().length < 2} onClick={() => void create()}>Create private tab</button>
      </div>
      <div className="hd-access-list">
        {tabs.map((tab) => (
          <div className="hd-access-row" key={tab.id}>
            <div><strong>{tab.name}</strong><small>Private tab · visible to you and administrators</small></div>
            <div className="hd-access-row__actions">
              <Link className="hd-btn hd-btn--primary" href={`/t/${tab.id}`}>Open</Link>
              <button className="hd-btn" type="button" onClick={() => void rename(tab)}>Rename</button>
              <button className="hd-btn" type="button" onClick={() => void remove(tab)}>Delete</button>
            </div>
          </div>
        ))}
        {!tabs.length ? <p>No private tabs yet.</p> : null}
      </div>
      {message ? <div className="hd-auth__notice">{message}</div> : null}
    </article>
  );
}
