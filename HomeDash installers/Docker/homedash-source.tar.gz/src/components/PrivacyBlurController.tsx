"use client";

import { useEffect } from "react";
import { usePathname } from "next/navigation";
import { hydratePrivacyBlur, useDashboardStore } from "@/lib/store";

const IP_RE = /\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d?\d)\b/;
const URL_RE = /(?:https?:\/\/|www\.)[^\s<>"']+/i;
const HOST_RE = /\b(?:[a-z0-9-]+\.)+(?:com|net|org|io|dev|local|lan|home|internal)\b/i;
const OCTET_RE = /^\.\d{1,3}$/;
const ATTR = "data-hd-privacy-auto";

function looksSensitive(text: string) {
  const t = text.trim();
  if (!t || t.length < 3) return false;
  return IP_RE.test(t) || URL_RE.test(t) || HOST_RE.test(t) || OCTET_RE.test(t);
}

function clearAutoMarks(root: ParentNode) {
  root.querySelectorAll(`[${ATTR}]`).forEach((el) => {
    el.removeAttribute(ATTR);
  });
}

function collectSensitiveLeaves(root: HTMLElement): Set<Element> {
  const found = new Set<Element>();
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
  let node = walker.nextNode();
  while (node) {
    const el = node as Element;
    if (
      el.closest(
        "script, style, svg, .hd-privacy-btn, .hd-header, .hd-drawer, .hd-nav-scrim, .hd-modal-scrim--icons",
      )
    ) {
      node = walker.nextNode();
      continue;
    }

    const ownText = Array.from(el.childNodes)
      .filter((n) => n.nodeType === Node.TEXT_NODE)
      .map((n) => n.textContent || "")
      .join("")
      .trim();
    const sample = ownText || (el.children.length === 0 ? ((el as HTMLElement).innerText || "").trim() : "");
    if (sample && looksSensitive(sample)) {
      found.add(el);
    }
    node = walker.nextNode();
  }

  // Drop nested marks — keep outermost only
  for (const el of [...found]) {
    let ancestor = el.parentElement;
    while (ancestor && ancestor !== root) {
      if (found.has(ancestor)) {
        found.delete(el);
        break;
      }
      ancestor = ancestor.parentElement;
    }
  }
  return found;
}

/** Add/remove marks only when membership changes — never flash by clearing all. */
function syncSensitiveMarks(root: HTMLElement) {
  const next = collectSensitiveLeaves(root);
  const prev = root.querySelectorAll(`[${ATTR}]`);

  prev.forEach((el) => {
    if (!next.has(el)) el.removeAttribute(ATTR);
  });
  next.forEach((el) => {
    if (el.getAttribute(ATTR) !== "1") el.setAttribute(ATTR, "1");
  });
}

/** Keeps document privacy attribute + auto-marks IP/URL text for blur. */
export function PrivacyBlurController() {
  const privacyBlur = useDashboardStore((s) => s.privacyBlur);
  const pathname = usePathname();

  useEffect(() => {
    hydratePrivacyBlur();
  }, []);

  useEffect(() => {
    document.documentElement.dataset.hdPrivacy = privacyBlur ? "on" : "off";
    document.documentElement.classList.toggle("hd-privacy-on", privacyBlur);
  }, [privacyBlur]);

  useEffect(() => {
    const root = document.querySelector(".hd-main") as HTMLElement | null;
    if (!root) return;

    if (!privacyBlur) {
      clearAutoMarks(root);
      return;
    }

    let timer = 0;
    let paused = false;

    const run = () => {
      paused = true;
      try {
        syncSensitiveMarks(root);
      } finally {
        // Ignore mutation noise from our own attribute writes
        window.setTimeout(() => {
          paused = false;
        }, 0);
      }
    };

    run();

    const mo = new MutationObserver((mutations) => {
      if (paused) return;
      // Ignore pure attribute flips on our privacy marker
      const meaningful = mutations.some((m) => {
        if (m.type === "attributes") {
          return m.attributeName !== ATTR;
        }
        return true;
      });
      if (!meaningful) return;
      window.clearTimeout(timer);
      timer = window.setTimeout(run, 320);
    });

    mo.observe(root, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: [ATTR],
    });

    return () => {
      window.clearTimeout(timer);
      mo.disconnect();
    };
  }, [privacyBlur, pathname]);

  return null;
}
