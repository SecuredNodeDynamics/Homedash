"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

type Profile = {
  username: string;
  displayName: string;
  profileImageUrl: string;
};

export function ProfileAccountCard() {
  const router = useRouter();
  const [profile, setProfile] = useState<Profile>({
    username: "",
    displayName: "",
    profileImageUrl: "",
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    fetch("/api/auth/profile", { cache: "no-store" })
      .then(async (response) => {
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.error || "Could not load profile");
        setProfile({
          username: String(data.username || ""),
          displayName: String(data.displayName || ""),
          profileImageUrl: String(data.profileImageUrl || ""),
        });
      })
      .catch((cause) => setError(cause instanceof Error ? cause.message : "Could not load profile"))
      .finally(() => setLoading(false));
  }, []);

  async function upload(file: File | undefined) {
    if (!file) return;
    setUploading(true);
    setError("");
    setMessage("");
    try {
      const body = new FormData();
      body.set("kind", "profile-image");
      body.set("file", file);
      const response = await fetch("/api/uploads", { method: "POST", body });
      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data.url) throw new Error(data.error || "Image upload failed");
      setProfile((current) => ({ ...current, profileImageUrl: String(data.url) }));
      setMessage("Profile image uploaded. Save your profile to apply it.");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Image upload failed");
    } finally {
      setUploading(false);
    }
  }

  async function save() {
    setSaving(true);
    setError("");
    setMessage("");
    try {
      const response = await fetch("/api/auth/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(profile),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || "Could not save profile");
      setProfile({
        username: String(data.username || ""),
        displayName: String(data.displayName || ""),
        profileImageUrl: String(data.profileImageUrl || ""),
      });
      setMessage("Profile updated");
      router.refresh();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Could not save profile");
    } finally {
      setSaving(false);
    }
  }

  const initial = (profile.displayName || profile.username || "?").trim().charAt(0).toUpperCase();

  return (
    <article className="hd-panel-card hd-profile-account">
      <header>
        <h2>Profile</h2>
        <p>Update the identity shown for your HomeDash account.</p>
      </header>
      <div className="hd-profile-account__identity">
        <span className="hd-profile-account__avatar" aria-hidden="true">
          {profile.profileImageUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={profile.profileImageUrl} alt="" />
          ) : initial}
        </span>
        <div>
          <label className="hd-btn" aria-disabled={uploading || loading}>
            {uploading ? "Uploading…" : "Upload profile image"}
            <input
              type="file"
              accept="image/png,image/jpeg,image/webp,image/gif"
              hidden
              disabled={uploading || loading}
              onChange={(event) => void upload(event.target.files?.[0])}
            />
          </label>
          {profile.profileImageUrl ? (
            <button
              className="hd-btn"
              type="button"
              disabled={loading}
              onClick={() => setProfile((current) => ({ ...current, profileImageUrl: "" }))}
            >
              Remove image
            </button>
          ) : null}
        </div>
      </div>
      <div className="hd-field-row">
        <div className="hd-field">
          <label htmlFor="profileUsername">Username</label>
          <input
            id="profileUsername"
            type="text"
            autoComplete="username"
            minLength={2}
            maxLength={64}
            value={profile.username}
            disabled={loading}
            onChange={(event) => setProfile({ ...profile, username: event.target.value })}
          />
          <small>Used when signing in. Letters, numbers, periods, underscores, and dashes only.</small>
        </div>
        <div className="hd-field">
          <label htmlFor="profileDisplayName">Display name</label>
          <input
            id="profileDisplayName"
            type="text"
            maxLength={80}
            placeholder="How your name should appear"
            value={profile.displayName}
            disabled={loading}
            onChange={(event) => setProfile({ ...profile, displayName: event.target.value })}
          />
        </div>
      </div>
      {error ? <div className="hd-auth__error">{error}</div> : null}
      {message ? <div className="hd-ok">{message}</div> : null}
      <div className="hd-modal__actions">
        <button
          className="hd-btn hd-btn--primary"
          type="button"
          disabled={loading || saving || profile.username.trim().length < 2}
          onClick={() => void save()}
        >
          {saving ? "Saving…" : "Save profile"}
        </button>
      </div>
    </article>
  );
}
