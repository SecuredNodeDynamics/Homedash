"use client";

import { useMemo, useState, type InputHTMLAttributes } from "react";

export type ProxmoxConfigDraft = {
  pveUrl: string;
  fallbackUrl: string;
  openFallbackUrl: string;
  tokenId: string;
  tokenSecret: string;
  pveNode: string;
  prxUrl: string;
  prxFallbackUrl: string;
  prxOpenFallbackUrl: string;
  prxToken: string;
  glancesUrl: string;
  glancesFallbackUrl: string;
  iface: string;
  cpuSensor: string;
  backupMount: string;
  color: string;
};

export function parseProxmoxConfig(config: Record<string, string> | undefined): ProxmoxConfigDraft {
  const cfg = config || {};
  return {
    pveUrl: cfg.pveUrl || "",
    fallbackUrl: cfg.fallbackUrl || "",
    openFallbackUrl: cfg.openFallbackUrl || "",
    tokenId: cfg.tokenId || "",
    tokenSecret: cfg.tokenSecret || "",
    pveNode: cfg.pveNode || "",
    prxUrl: cfg.prxUrl || "",
    prxFallbackUrl: cfg.prxFallbackUrl || "",
    prxOpenFallbackUrl: cfg.prxOpenFallbackUrl || "",
    prxToken: cfg.prxToken || "",
    glancesUrl: cfg.glancesUrl || "",
    glancesFallbackUrl: cfg.glancesFallbackUrl || "",
    iface: cfg.iface || "",
    cpuSensor: cfg.cpuSensor || "",
    backupMount: cfg.backupMount || "",
    color: cfg.color || "",
  };
}

export function serializeProxmoxConfig(draft: ProxmoxConfigDraft): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [key, value] of Object.entries(draft) as Array<[keyof ProxmoxConfigDraft, string]>) {
    out[key] = value.trim();
  }
  return out;
}

function Field({
  label,
  ...props
}: InputHTMLAttributes<HTMLInputElement> & { label: string }) {
  return (
    <label className="hd-pve-cfg__field">
      <span>{label}</span>
      <input {...props} />
    </label>
  );
}

export function ProxmoxConfigEditor({
  value,
  onChange,
}: {
  value: Record<string, string>;
  onChange: (patch: Record<string, string>) => void;
}) {
  const draft = useMemo(() => parseProxmoxConfig(value), [value]);
  const [showAdvanced, setShowAdvanced] = useState(() =>
    Boolean(draft.iface || draft.cpuSensor || draft.backupMount || draft.color),
  );
  const [showOptional, setShowOptional] = useState(() =>
    Boolean(
      draft.fallbackUrl ||
        draft.openFallbackUrl ||
        draft.pveNode ||
        draft.prxUrl ||
        draft.prxToken ||
        draft.glancesUrl ||
        draft.iface ||
        draft.cpuSensor ||
        draft.backupMount ||
        draft.color,
    ),
  );

  function patch(partial: Partial<ProxmoxConfigDraft>) {
    onChange(serializeProxmoxConfig({ ...draft, ...partial }));
  }

  return (
    <div className="hd-pve-cfg">
      <div className="hd-pve-cfg__head">
        <div>
          <strong>Proxmox connection</strong>
          <p>API URL + token · optional ProxMenux / Glances</p>
        </div>
        <button
          className="hd-btn hd-btn--ghost"
          type="button"
          aria-pressed={showOptional}
          onClick={() => setShowOptional((v) => !v)}
        >
          {showOptional ? "Hide extras" : "More options"}
        </button>
      </div>

      <div className="hd-pve-cfg__body">
        <div className="hd-pve-cfg__row hd-pve-cfg__row--primary">
          <Field
            label="Private - IP"
            type="url"
            value={draft.pveUrl}
            placeholder="https://10.0.0.1:8006"
            spellCheck={false}
            autoComplete="off"
            onChange={(e) => patch({ pveUrl: e.target.value })}
          />
          <Field
            label="Token ID"
            type="text"
            value={draft.tokenId}
            placeholder="user@pam!token"
            spellCheck={false}
            autoComplete="off"
            onChange={(e) => patch({ tokenId: e.target.value })}
          />
          <Field
            label="Token secret"
            type="password"
            value={draft.tokenSecret}
            placeholder="••••••••"
            autoComplete="off"
            spellCheck={false}
            onChange={(e) => patch({ tokenSecret: e.target.value })}
          />
        </div>

        {showOptional ? (
          <>
            <div className="hd-pve-cfg__row">
              <Field
                label="Fallback Public URL"
                type="url"
                value={draft.fallbackUrl}
                placeholder="https://pve.example.com"
                spellCheck={false}
                autoComplete="off"
                onChange={(e) => patch({ fallbackUrl: e.target.value })}
              />
              <Field
                label="OPEN - Public URL"
                type="url"
                value={draft.openFallbackUrl}
                placeholder="https://… (Cloudflare)"
                spellCheck={false}
                autoComplete="off"
                onChange={(e) => patch({ openFallbackUrl: e.target.value })}
              />
              <Field
                label="Node name"
                type="text"
                value={draft.pveNode}
                placeholder="pve (auto if blank)"
                spellCheck={false}
                autoComplete="off"
                onChange={(e) => patch({ pveNode: e.target.value })}
              />
            </div>

            <div className="hd-pve-cfg__group">
              <span className="hd-pve-cfg__group-label">ProxMenux</span>
              <div className="hd-pve-cfg__row">
                <Field
                  label="URL"
                  type="url"
                  value={draft.prxUrl}
                  placeholder="http://10.0.0.1:8080"
                  spellCheck={false}
                  autoComplete="off"
                  onChange={(e) => patch({ prxUrl: e.target.value })}
                />
                <Field
                  label="Fallback"
                  type="url"
                  value={draft.prxFallbackUrl}
                  placeholder="optional"
                  spellCheck={false}
                  autoComplete="off"
                  onChange={(e) => patch({ prxFallbackUrl: e.target.value })}
                />
                <Field
                  label="OPEN - Public URL"
                  type="url"
                  value={draft.prxOpenFallbackUrl}
                  placeholder="optional"
                  spellCheck={false}
                  autoComplete="off"
                  onChange={(e) => patch({ prxOpenFallbackUrl: e.target.value })}
                />
                <Field
                  label="API key"
                  type="password"
                  value={draft.prxToken}
                  placeholder="optional"
                  autoComplete="off"
                  spellCheck={false}
                  onChange={(e) => patch({ prxToken: e.target.value })}
                />
              </div>
            </div>

            <div className="hd-pve-cfg__group">
              <span className="hd-pve-cfg__group-label">Glances</span>
              <div className="hd-pve-cfg__row">
                <Field
                  label="URL"
                  type="url"
                  value={draft.glancesUrl}
                  placeholder="http://10.0.0.1:61208"
                  spellCheck={false}
                  autoComplete="off"
                  onChange={(e) => patch({ glancesUrl: e.target.value })}
                />
                <Field
                  label="Fallback"
                  type="url"
                  value={draft.glancesFallbackUrl}
                  placeholder="optional"
                  spellCheck={false}
                  autoComplete="off"
                  onChange={(e) => patch({ glancesFallbackUrl: e.target.value })}
                />
              </div>
            </div>

            <div className="hd-pve-cfg__advanced-toggle">
              <button
                className="hd-btn hd-btn--ghost"
                type="button"
                aria-pressed={showAdvanced}
                onClick={() => setShowAdvanced((v) => !v)}
              >
                {showAdvanced ? "Hide advanced" : "Advanced"}
              </button>
            </div>

            {showAdvanced ? (
              <div className="hd-pve-cfg__row hd-pve-cfg__row--advanced">
                <Field
                  label="Primary iface"
                  type="text"
                  value={draft.iface}
                  placeholder="vmbr0"
                  spellCheck={false}
                  autoComplete="off"
                  onChange={(e) => patch({ iface: e.target.value })}
                />
                <Field
                  label="CPU sensor"
                  type="text"
                  value={draft.cpuSensor}
                  placeholder="Package id 0"
                  spellCheck={false}
                  autoComplete="off"
                  onChange={(e) => patch({ cpuSensor: e.target.value })}
                />
                <Field
                  label="Backup mount"
                  type="text"
                  value={draft.backupMount}
                  placeholder="/mnt/backup"
                  spellCheck={false}
                  autoComplete="off"
                  onChange={(e) => patch({ backupMount: e.target.value })}
                />
                <Field
                  label="Accent"
                  type="text"
                  value={draft.color}
                  placeholder="#6ee7b7"
                  spellCheck={false}
                  autoComplete="off"
                  onChange={(e) => patch({ color: e.target.value })}
                />
              </div>
            ) : null}
          </>
        ) : null}
      </div>
    </div>
  );
}
