"use client";

import { Children, useEffect, useRef, useState } from "react";
import GridLayout, { WidthProvider, type Layout } from "react-grid-layout";
import {
  SETTINGS_CARD_COLS,
  SETTINGS_CARD_MARGIN,
  SETTINGS_CARD_ROW_HEIGHT,
  readSettingsCardLayout,
  reconcileSettingsCardLayout,
  writeSettingsCardLayout,
  type SettingsCardGridItem,
} from "@/lib/settings-card-layout";

const ResponsiveGrid = WidthProvider(GridLayout);

/**
 * Wraps a Settings panel's cards. Uses a remembered per-`panelId` grid after
 * the user saves a custom layout. Until then, the original masonry section is
 * shown so unmodified Settings pages stay unchanged.
 */
export function SettingsCardGridSection({
  panelId,
  editMode,
  saveToken,
  cancelToken,
  onSaved,
  onCancelled,
  children,
}: {
  panelId: string;
  editMode: boolean;
  saveToken: number;
  cancelToken: number;
  onSaved: () => void;
  onCancelled: () => void;
  children: React.ReactNode;
}) {
  const items = Children.toArray(children);
  const ids = items.map((_, index) => `card-${index}`);
  const idsKey = ids.join("|");

  const [layout, setLayout] = useState<SettingsCardGridItem[]>(() =>
    reconcileSettingsCardLayout(readSettingsCardLayout(panelId), ids),
  );
  const [hasSavedLayout, setHasSavedLayout] = useState(
    () => readSettingsCardLayout(panelId) != null,
  );
  const committedRef = useRef(layout);
  const layoutRef = useRef(layout);
  const lastPanelRef = useRef(panelId);
  const lastSaveToken = useRef(saveToken);
  const lastCancelToken = useRef(cancelToken);
  layoutRef.current = layout;

  // Panel switched (or the set of cards changed, e.g. role-gated cards) —
  // reload/reconcile from storage rather than carrying over stale positions.
  useEffect(() => {
    if (lastPanelRef.current === panelId) return;
    lastPanelRef.current = panelId;
    const stored = readSettingsCardLayout(panelId);
    const next = reconcileSettingsCardLayout(stored, ids);
    setHasSavedLayout(stored != null);
    setLayout(next);
    committedRef.current = next;
    layoutRef.current = next;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [panelId]);

  useEffect(() => {
    setLayout((prev) => {
      const next = reconcileSettingsCardLayout(prev, ids);
      committedRef.current = next;
      layoutRef.current = next;
      return next;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [idsKey]);

  useEffect(() => {
    if (saveToken === lastSaveToken.current) return;
    lastSaveToken.current = saveToken;
    const next = layoutRef.current;
    writeSettingsCardLayout(panelId, next);
    committedRef.current = next;
    setHasSavedLayout(true);
    onSaved();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [saveToken]);

  useEffect(() => {
    if (cancelToken === lastCancelToken.current) return;
    lastCancelToken.current = cancelToken;
    setLayout(committedRef.current);
    layoutRef.current = committedRef.current;
    onCancelled();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cancelToken]);

  if (!editMode && !hasSavedLayout) {
    return <section className="hd-panel-grid hd-panel-grid--masonry">{children}</section>;
  }

  return (
    <div className={`hd-settings-card-grid-wrap${editMode ? " is-editing" : ""}`}>
      <ResponsiveGrid
        className="hd-settings-card-grid"
        cols={SETTINGS_CARD_COLS}
        rowHeight={SETTINGS_CARD_ROW_HEIGHT}
        margin={[SETTINGS_CARD_MARGIN, SETTINGS_CARD_MARGIN]}
        layout={layout as Layout[]}
        isDraggable={editMode}
        isResizable={editMode}
        draggableHandle=".hd-settings-card-grid__handle"
        compactType={editMode ? "vertical" : null}
        onLayoutChange={(next) => {
          if (!editMode) return;
          const mapped = next.map((item) => ({ i: item.i, x: item.x, y: item.y, w: item.w, h: item.h }));
          layoutRef.current = mapped;
          setLayout(mapped);
        }}
      >
        {items.map((child, index) => (
          <div key={ids[index]} className="hd-settings-card-grid__item">
            {editMode ? (
              <div className="hd-settings-card-grid__handle" title="Drag to move" aria-hidden="true">
                ⠿
              </div>
            ) : null}
            <div className="hd-settings-card-grid__body">{child}</div>
          </div>
        ))}
      </ResponsiveGrid>
    </div>
  );
}
