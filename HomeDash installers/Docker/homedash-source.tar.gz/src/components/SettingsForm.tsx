"use client";

import { useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { createPortal } from "react-dom";
import { useRouter } from "next/navigation";
import type {
  AppSettings,
  BackgroundImageMode,
  BackgroundImageTransition,
  BackgroundPatternStyle,
  BackgroundPatternAnimation,
  BackgroundPatternTravelDirection,
  CardBorderStyle,
  CardShadowStyle,
  DashboardTab,
  HeaderLayoutMode,
  HeaderQuickLinksPlacement,
  HeaderTabActiveStyle,
  HeaderTabStyle,
  SearchResultDensity,
  SearchSettings,
  SearchShadowStyle,
  WidgetAccentMode,
  WidgetChromeSettings,
  WidgetInstance,
  WidgetManifest,
} from "@/lib/types";
import { DEFAULT_THEME, slugifyTabName } from "@/lib/tabs";
import { BREAKPOINT_HINTS, BREAKPOINT_LABELS, BREAKPOINT_ORDER, DEFAULT_COLS, GRID_COLS_LIMITS, clampGridCols, resolveGridCols, type Breakpoint, type GridColsConfig } from "@/lib/breakpoints";
import {
  formatInstanceId,
  instancesForWidget,
  isMultiInstanceWidget,
  parseInstanceId,
  slugInstanceKey,
} from "@/lib/instances";
import { iconForWidget, initialsForWidget, resolveWidgetIcon } from "@/lib/widget-icons";
import { mergeWidgetChromeEntry } from "@/lib/theme";
import { ColorField } from "@/components/ColorField";
import { parseCalendarSources, serializeCalendarSources } from "@/components/MediaCalendarSourcesEditor";
import { BookmarksEditor } from "@/components/BookmarksEditor";
import { AccountPasswordCard } from "@/components/AccountPasswordCard";
import { ProfileAccountCard } from "@/components/ProfileAccountCard";
import { AccessManagementCard } from "@/components/AccessManagementCard";
import { AdminBackupPanel } from "@/components/AdminBackupPanel";
import { WidgetManager } from "@/components/WidgetManager";
import { SystemUpdatePanel } from "@/components/SystemUpdatePanel";
import { WidgetSettingsModal } from "@/components/WidgetSettingsModal";
import { EditTabLayoutModal } from "@/components/EditTabLayoutModal";
import { SettingsCardGridSection } from "@/components/SettingsCardGridSection";
import { HeaderQuickLinksEditor } from "@/components/HeaderQuickLinksEditor";
import { useDashboardStore } from "@/lib/store";
import {
  normalizeHeaderQuickLinkItems,
  normalizeHeaderQuickLinks,
  normalizeHeaderQuickLinksPlacement,
} from "@/lib/header-quick-links";
import { resolveBookmarksWidgetTitle, withBookmarkTitlesFromConfigs } from "@/lib/bookmarks";
import { DEFAULT_SEARCH_SETTINGS, normalizeSearchSettings } from "@/lib/search-settings";
import {
  isNodeTitleWidget,
  resolveNodeWidgetTitle,
  withNodeTitlesFromConfigs,
} from "@/lib/widget-titles";

type UploadKind = "logo" | "favicon" | "background";
type SettingsPanel = "general" | "profile" | "appearance" | "search" | "bookmarks" | "tabs" | "widgets" | "manager" | "system" | "admin";
type IconPickerTarget =
  | { kind: "widget" | "bookmark"; id: string }
  | { kind: "ai-provider"; id: string; provider: string }
  | null;

function WidgetBrandMark({
  widgetId,
  name,
  iconUrl,
  size = "md",
}: {
  widgetId: string;
  name: string;
  iconUrl?: string | null;
  size?: "sm" | "md" | "lg";
}) {
  const src = resolveWidgetIcon(widgetId, iconUrl);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    setFailed(false);
  }, [src]);
  return (
    <span className={`hd-widget-mark hd-widget-mark--${size}`} aria-hidden="true">
      {src && !failed ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={src} alt="" onError={() => setFailed(true)} />
      ) : (
        <span className="hd-widget-mark__fallback">{initialsForWidget(name)}</span>
      )}
    </span>
  );
}

function AssetField({
  id,
  label,
  value,
  placeholder,
  kind,
  preview,
  onChange,
  onUploaded,
}: {
  id: string;
  label: string;
  value: string;
  placeholder: string;
  kind: UploadKind;
  preview?: "logo" | "favicon" | "background";
  onChange: (value: string) => void;
  onUploaded: (message: string) => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");

  async function onFile(file: File | undefined) {
    if (!file) return;
    setError("");
    if (file.size > 25 * 1024 * 1024) {
      setError("File exceeds the 25 MB limit");
      return;
    }
    setUploading(true);
    try {
      const body = new FormData();
      body.set("kind", kind);
      body.set("file", file);
      const res = await fetch("/api/uploads", { method: "POST", body });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Upload failed");
      onChange(String(data.url || ""));
      onUploaded(`Uploaded ${kind}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setUploading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  return (
    <div className="hd-field">
      <label htmlFor={id}>{label}</label>
      <div className="hd-asset-row">
        <input
          id={id}
          type="text"
          inputMode="url"
          placeholder={placeholder}
          value={value}
          onChange={(e) => onChange(e.target.value)}
        />
        <button className="hd-btn" type="button" disabled={uploading} onClick={() => inputRef.current?.click()}>
          {uploading ? "Uploading…" : "Upload"}
        </button>
        <input
          ref={inputRef}
          type="file"
          accept="image/png,image/jpeg,image/webp,image/gif,image/svg+xml,image/x-icon,.ico"
          hidden
          onChange={(e) => onFile(e.target.files?.[0])}
        />
      </div>
      <div className="hd-asset-hint">URL or upload · max 25 MB</div>
      {value && preview ? (
        <div className={`hd-asset-preview hd-asset-preview--${preview}`}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={value} alt="" />
        </div>
      ) : null}
      {error ? <div className="hd-asset-error">{error}</div> : null}
    </div>
  );
}

function BackgroundGalleryField({
  urls,
  onChange,
  onUploaded,
}: {
  urls: string[];
  onChange: (urls: string[]) => void;
  onUploaded: (message: string) => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState("");
  const [error, setError] = useState("");

  async function onFiles(fileList: FileList | null) {
    if (!fileList?.length) return;
    const files = Array.from(fileList);
    setError("");
    setUploading(true);
    const added: string[] = [];
    try {
      for (let i = 0; i < files.length; i += 1) {
        const file = files[i];
        setProgress(`Uploading ${i + 1} of ${files.length}…`);
        if (file.size > 25 * 1024 * 1024) {
          throw new Error(`${file.name} exceeds the 25 MB limit`);
        }
        const body = new FormData();
        body.set("kind", "background");
        body.set("gallery", "1");
        body.set("file", file);
        const res = await fetch("/api/uploads", { method: "POST", body });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.error || `Upload failed for ${file.name}`);
        const url = String(data.url || "");
        if (url) added.push(url);
      }
      if (added.length) {
        onChange([...urls, ...added]);
        onUploaded(
          added.length === 1
            ? "Added 1 rotating background"
            : `Added ${added.length} rotating backgrounds`,
        );
      }
    } catch (err) {
      if (added.length) onChange([...urls, ...added]);
      setError(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setUploading(false);
      setProgress("");
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  async function removeAt(index: number) {
    const url = urls[index];
    const next = urls.filter((_, i) => i !== index);
    onChange(next);
    if (url.startsWith("/api/uploads/")) {
      await fetch(`/api/uploads?url=${encodeURIComponent(url)}`, { method: "DELETE" }).catch(() => undefined);
    }
  }

  return (
    <div className="hd-field">
      <label>Rotating images</label>
      <div className="hd-asset-row">
        <button className="hd-btn" type="button" disabled={uploading} onClick={() => inputRef.current?.click()}>
          {uploading ? progress || "Uploading…" : "Upload images"}
        </button>
        <input
          ref={inputRef}
          type="file"
          accept="image/png,image/jpeg,image/webp,image/gif"
          multiple
          hidden
          onChange={(e) => onFiles(e.target.files)}
        />
      </div>
      <div className="hd-asset-hint">
        Bulk upload · soft fade every 2 minutes by default · max 25 MB each
        {urls.length ? ` · ${urls.length} image${urls.length === 1 ? "" : "s"}` : ""}
      </div>
      {urls.length ? (
        <div className="hd-bg-gallery">
          {urls.map((url, index) => (
            <div key={`${url}-${index}`} className="hd-bg-gallery__item">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={url} alt="" />
              <button
                className="hd-bg-gallery__remove"
                type="button"
                title="Remove"
                aria-label="Remove background"
                onClick={() => removeAt(index)}
              >
                ×
              </button>
            </div>
          ))}
        </div>
      ) : (
        <div className="hd-asset-hint">No gallery images yet — upload a few to start rotating.</div>
      )}
      {error ? <div className="hd-asset-error">{error}</div> : null}
    </div>
  );
}

function uniqueTabId(name: string, existing: DashboardTab[]) {
  const base = slugifyTabName(name);
  let id = base;
  let n = 2;
  const ids = new Set(existing.map((t) => t.id));
  while (ids.has(id)) {
    id = `${base}-${n++}`;
  }
  return id;
}

export function SettingsForm({
  initial,
  personalTabs: initialPersonalTabs,
  personalTabOrder: initialPersonalTabOrder,
  globalProfileDefaults,
  widgets,
}: {
  initial: AppSettings;
  personalTabs: DashboardTab[];
  personalTabOrder: string[];
  globalProfileDefaults: Pick<AppSettings, "theme" | "bookmarks" | "bookmarkGroups">;
  widgets: WidgetManifest[];
}) {
  const router = useRouter();
  const [panel, setPanel] = useState<SettingsPanel>("profile");
  const [accessPermissions, setAccessPermissions] = useState<string[]>(["*"]);
  const [accessRole, setAccessRole] = useState("user");
  const [accessUsername, setAccessUsername] = useState("");
  useEffect(() => {
    fetch("/api/auth/me").then((response) => response.json()).then((data) => {
      const role = String(data.user?.role || "user");
      setAccessRole(role);
      setAccessUsername(String(data.user?.username || ""));
      setAccessPermissions(Array.isArray(data.user?.permissions) ? data.user.permissions : []);
      setPanel((current) => {
        if (role === "admin" && current === "profile") return "general";
        if (role !== "admin" && current === "general") return "profile";
        return current;
      });
    }).catch(() => {});
  }, []);
  const hasAccess = (permission: string) => accessRole === "admin" || accessPermissions.includes("*") || accessPermissions.includes(permission);
  const canManageSettings = hasAccess("settings.manage");
  const profileEditablePanel = panel === "profile" || panel === "appearance" || panel === "bookmarks";
  const [form, setForm] = useState<AppSettings>({
    ...initial,
    faviconUrl: initial.faviconUrl || "",
    tabs: initial.tabs?.length ? initial.tabs : [],
    widgetAccents: initial.widgetAccents || {},
    widgetIcons: initial.widgetIcons || {},
    widgetChrome: initial.widgetChrome || {},
    widgetInstances: initial.widgetInstances || [],
    bookmarks: initial.bookmarks || [],
    bookmarkGroups: initial.bookmarkGroups?.length
      ? initial.bookmarkGroups
      : [{ id: "general", name: "General", order: 0 }],
    gridCols: resolveGridCols(initial.gridCols),
    theme: {
      ...DEFAULT_THEME,
      ...initial.theme,
      buttonAccentColor: initial.theme.buttonAccentColor || "",
      cardAccent: initial.theme.cardAccent || "rainbow",
      cardAccentColor: initial.theme.cardAccentColor || initial.theme.accent || "#e5a00d",
      backgroundImageMode: initial.theme.backgroundImageMode === "rotate" ? "rotate" : "static",
      backgroundImageUrls: Array.isArray(initial.theme.backgroundImageUrls)
        ? initial.theme.backgroundImageUrls
        : [],
      backgroundImageRotateSeconds: initial.theme.backgroundImageRotateSeconds || 120,
      backgroundPatternEnabled: initial.theme.backgroundPatternEnabled ?? false,
      backgroundPatternStyle: initial.theme.backgroundPatternStyle || "dots",
      backgroundPatternColor: initial.theme.backgroundPatternColor || "#60a5fa",
      backgroundPatternOpacity: initial.theme.backgroundPatternOpacity ?? 0.18,
      backgroundPatternSize: initial.theme.backgroundPatternSize ?? 28,
      backgroundPatternWeight: initial.theme.backgroundPatternWeight ?? 1,
      backgroundPatternAnimationEnabled: initial.theme.backgroundPatternAnimationEnabled ?? false,
      backgroundPatternAnimation: initial.theme.backgroundPatternAnimation || "drift",
      backgroundPatternAnimationSeconds: initial.theme.backgroundPatternAnimationSeconds ?? 18,
      backgroundPatternAnimationDirection: initial.theme.backgroundPatternAnimationDirection || "normal",
      backgroundPatternAnimationStrength: initial.theme.backgroundPatternAnimationStrength ?? 24,
      backgroundPatternAnimationColor: initial.theme.backgroundPatternAnimationColor || "#22d3ee",
      backgroundPatternAnimationColorSecondary:
        initial.theme.backgroundPatternAnimationColorSecondary || "#8b5cf6",
      backgroundPatternAnimationTravelDirection:
        initial.theme.backgroundPatternAnimationTravelDirection || "right",
      cardBackground: initial.theme.cardBackground || DEFAULT_THEME.cardBackground,
      cardOpacity: initial.theme.cardOpacity ?? DEFAULT_THEME.cardOpacity,
      cardBlur: initial.theme.cardBlur ?? DEFAULT_THEME.cardBlur,
      cardSaturate: initial.theme.cardSaturate ?? DEFAULT_THEME.cardSaturate,
      cardBorderStyle: initial.theme.cardBorderStyle || DEFAULT_THEME.cardBorderStyle,
      cardBorderColor: initial.theme.cardBorderColor || "",
      cardShadow: initial.theme.cardShadow || DEFAULT_THEME.cardShadow,
      headerLayout: initial.theme.headerLayout || DEFAULT_THEME.headerLayout,
      headerBackground: initial.theme.headerBackground || DEFAULT_THEME.headerBackground,
      headerOpacity: initial.theme.headerOpacity ?? DEFAULT_THEME.headerOpacity,
      headerBlur: initial.theme.headerBlur ?? DEFAULT_THEME.headerBlur,
      headerBorderStyle: initial.theme.headerBorderStyle || DEFAULT_THEME.headerBorderStyle,
      headerBorderColor: initial.theme.headerBorderColor || "",
      headerRadius: initial.theme.headerRadius ?? DEFAULT_THEME.headerRadius,
      headerShadow: initial.theme.headerShadow || DEFAULT_THEME.headerShadow,
      headerTabStyle: initial.theme.headerTabStyle || DEFAULT_THEME.headerTabStyle,
      headerTabActiveStyle: initial.theme.headerTabActiveStyle || DEFAULT_THEME.headerTabActiveStyle,
      headerTabRadius: initial.theme.headerTabRadius ?? DEFAULT_THEME.headerTabRadius,
      headerQuickLinks: normalizeHeaderQuickLinks(initial.theme.headerQuickLinks),
      headerQuickLinkItems: normalizeHeaderQuickLinkItems(
        initial.theme.headerQuickLinkItems,
        initial.theme.headerQuickLinks,
      ),
      headerQuickLinksPlacement: normalizeHeaderQuickLinksPlacement(
        initial.theme.headerQuickLinksPlacement,
      ),
      search: normalizeSearchSettings(initial.theme.search),
    },
  });
  const [selectedTabId, setSelectedTabId] = useState(initial.tabs?.[0]?.id || "");
  const [layoutEditorTabId, setLayoutEditorTabId] = useState<string | null>(null);
  const [privateTabs, setPrivateTabs] = useState<DashboardTab[]>(initialPersonalTabs);
  const [tabOrder, setTabOrder] = useState<string[]>(() => {
    const ids = [...initial.tabs, ...initialPersonalTabs].map((tab) => tab.id);
    return [
      ...initialPersonalTabOrder.filter((id) => ids.includes(id)),
      ...ids.filter((id) => !initialPersonalTabOrder.includes(id)),
    ];
  });
  const [widgetConfigs, setWidgetConfigs] = useState<Record<string, Record<string, string>>>({});
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [widgetQuery, setWidgetQuery] = useState("");
  const [bookmarkQuery, setBookmarkQuery] = useState("");
  const [bookmarkFormOpen, setBookmarkFormOpen] = useState(false);
  const [bookmarkAddToken, setBookmarkAddToken] = useState(0);
  const [widgetCategory, setWidgetCategory] = useState("all");
  const [addServerOpen, setAddServerOpen] = useState(false);
  const [settingsModalId, setSettingsModalId] = useState<string | null>(null);
  const [iconPickerFor, setIconPickerFor] = useState<IconPickerTarget>(null);
  const [bookmarkIconAssignment, setBookmarkIconAssignment] = useState<{ id: string; url: string } | null>(
    null,
  );
  const [iconQuery, setIconQuery] = useState("");
  const [iconResults, setIconResults] = useState<{ name: string; url: string; page: string }[]>([]);
  const [iconTotal, setIconTotal] = useState(0);
  const [iconMatched, setIconMatched] = useState(0);
  const [iconTruncated, setIconTruncated] = useState(false);
  const [iconLoading, setIconLoading] = useState(false);
  const [iconError, setIconError] = useState("");
  const setPreviewTheme = useDashboardStore((s) => s.setPreviewTheme);

  useEffect(() => {
    setPreviewTheme(form.theme);
    return () => setPreviewTheme(null);
  }, [form.theme, setPreviewTheme]);

  const categorized = useMemo(() => {
    const map = new Map<string, WidgetManifest[]>();
    for (const w of widgets) {
      const cat = w.category || "General";
      if (!map.has(cat)) map.set(cat, []);
      map.get(cat)!.push(w);
    }
    return Array.from(map.entries());
  }, [widgets]);

  const widgetCategories = useMemo(
    () => categorized.map(([category, items]) => ({ category, count: items.length })),
    [categorized],
  );

  const multiServerWidgets = useMemo(
    () => widgets.filter((w) => isMultiInstanceWidget(w.id)),
    [widgets],
  );

  const settingsModalTarget = useMemo(() => {
    if (!settingsModalId) return null;
    for (const widget of widgets) {
      const multi = isMultiInstanceWidget(widget.id);
      const instances = multi ? instancesForWidget(form.widgetInstances || [], widget.id) : [];
      const cards =
        multi && instances.length > 0
          ? instances
          : [
              {
                id: widget.id,
                widgetId: widget.id,
                key: "default",
                label: widget.name,
              },
            ];
      const inst = cards.find((entry) => entry.id === settingsModalId);
      if (!inst) continue;
      const isMultiCard = multi && instances.length > 0;
      const canRemove = isMultiCard && instances.length > 1;
      const iconId = isMultiCard ? inst.id : widget.id;
      const accentId = isMultiCard ? inst.id : widget.id;
      const accent =
        form.widgetAccents?.[accentId] ||
        (isMultiCard ? form.widgetAccents?.[widget.id] : undefined);
      const accentMode = (accent?.mode || "inherit") as WidgetAccentMode;
      const storedIcon = form.widgetIcons?.[iconId] || "";
      const defaultIcon =
        (isMultiCard ? form.widgetIcons?.[widget.id] : null) || iconForWidget(widget.id);
      const resolvedIcon =
        storedIcon || (isMultiCard ? form.widgetIcons?.[widget.id] || "" : "") || "";
      const chrome =
        form.widgetChrome?.[iconId] ||
        (isMultiCard ? form.widgetChrome?.[widget.id] : undefined);
      return {
        widget,
        instance: inst,
        isMultiCard,
        canRemove,
        iconId,
        accentId,
        accentMode,
        accentColor: accent?.color || form.theme.cardAccentColor || form.theme.accent,
        storedIcon,
        defaultIcon,
        resolvedIcon,
        chrome,
        showIcon: chrome?.showIcon !== false,
        showTitle: chrome?.showTitle !== false,
        expand: chrome?.expand,
      };
    }
    return null;
  }, [
    settingsModalId,
    widgets,
    form.widgetInstances,
    form.widgetAccents,
    form.widgetIcons,
    form.widgetChrome,
    form.theme.cardAccentColor,
    form.theme.accent,
  ]);

  useEffect(() => {
    if (!addServerOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setAddServerOpen(false);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [addServerOpen]);

  useEffect(() => {
    if (!iconPickerFor) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeIconPicker();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [iconPickerFor]);

  useEffect(() => {
    if (!iconPickerFor) return;
    let alive = true;
    setIconLoading(true);
    setIconError("");
    const timer = window.setTimeout(async () => {
      try {
        const res = await fetch(
          `/api/dashboard-icons?q=${encodeURIComponent(iconQuery.trim())}&limit=240`,
          { cache: "no-store" },
        );
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.error || "Icon search failed");
        if (!alive) return;
        setIconResults(Array.isArray(data.icons) ? data.icons : []);
        setIconTotal(typeof data.total === "number" ? data.total : 0);
        setIconMatched(typeof data.matched === "number" ? data.matched : 0);
        setIconTruncated(Boolean(data.truncated));
      } catch (err) {
        if (!alive) return;
        setIconResults([]);
        setIconTotal(0);
        setIconMatched(0);
        setIconTruncated(false);
        setIconError(err instanceof Error ? err.message : "Icon search failed");
      } finally {
        if (alive) setIconLoading(false);
      }
    }, iconQuery.trim() ? 220 : 0);
    return () => {
      alive = false;
      window.clearTimeout(timer);
    };
  }, [iconPickerFor, iconQuery]);

  function openIconPicker(target: Exclude<IconPickerTarget, null>, seedQuery = "") {
    setIconQuery(seedQuery);
    setIconResults([]);
    setIconTotal(0);
    setIconMatched(0);
    setIconTruncated(false);
    setIconError("");
    setIconLoading(true);
    setIconPickerFor(target);
  }

  const allEditableTabs = [...form.tabs, ...privateTabs].sort((a, b) => {
    const ai = tabOrder.indexOf(a.id);
    const bi = tabOrder.indexOf(b.id);
    return (ai < 0 ? Number.MAX_SAFE_INTEGER : ai) - (bi < 0 ? Number.MAX_SAFE_INTEGER : bi);
  });
  const selectedTab = allEditableTabs.find((t) => t.id === selectedTabId) || allEditableTabs[0];
  const selectedTabIsPrivate = Boolean(
    selectedTab && privateTabs.some((tab) => tab.id === selectedTab.id),
  );

  // Header's "Edit layout" button (shown while on a Settings panel whose
  // cards support rearranging) toggles a drag/resize grid for that panel's
  // own cards — separate from the per-tab widget layout editor above, which
  // has its own dedicated "Edit Layout" button in the Tabs panel.
  const CARD_LAYOUT_PANELS = useMemo<Set<SettingsPanel>>(
    () => new Set(["profile", "general", "appearance", "search"]),
    [],
  );
  const settingsCardEditMode = useDashboardStore((s) => s.settingsCardEditMode);
  const setSettingsCardEditMode = useDashboardStore((s) => s.setSettingsCardEditMode);
  const setSettingsCardEditablePanel = useDashboardStore((s) => s.setSettingsCardEditablePanel);
  const settingsCardSaveToken = useDashboardStore((s) => s.settingsCardSaveToken);
  const settingsCardCancelToken = useDashboardStore((s) => s.settingsCardCancelToken);
  useEffect(() => {
    setSettingsCardEditablePanel(CARD_LAYOUT_PANELS.has(panel));
    setSettingsCardEditMode(false);
  }, [panel, CARD_LAYOUT_PANELS, setSettingsCardEditablePanel, setSettingsCardEditMode]);

  useEffect(() => {
    let alive = true;
    const ids = new Set<string>();
    for (const w of widgets) {
      const instances = instancesForWidget(form.widgetInstances || [], w.id);
      if (isMultiInstanceWidget(w.id) && instances.length) {
        instances.forEach((i) => ids.add(i.id));
      } else {
        ids.add(w.id);
      }
    }
    Promise.all(
      Array.from(ids).map(async (id) => {
        const res = await fetch(`/api/widgets/${encodeURIComponent(id)}/config`);
        const cfg = res.ok ? await res.json() : {};
        return [id, cfg] as const;
      }),
    ).then((pairs) => {
      if (!alive) return;
      const normalized = pairs.map(([id, cfg]) => {
        const widgetId = parseInstanceId(id).widgetId || id;
        if (widgetId !== "media-calendar" || !cfg || typeof cfg !== "object") {
          return [id, cfg] as const;
        }
        const record = cfg as Record<string, string>;
        if (record.sourcesJson?.trim()) return [id, record] as const;
        const seeded = serializeCalendarSources(parseCalendarSources(record));
        return [id, { ...record, ...seeded }] as const;
      });
      setWidgetConfigs(Object.fromEntries(normalized));
    });
    return () => {
      alive = false;
    };
  }, [widgets, form.widgetInstances]);

  function update<K extends keyof AppSettings>(key: K, value: AppSettings[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function updateTheme<K extends keyof AppSettings["theme"]>(key: K, value: AppSettings["theme"][K]) {
    setForm((prev) => ({ ...prev, theme: { ...prev.theme, [key]: value } }));
  }

  function updateSearch<K extends keyof SearchSettings>(key: K, value: SearchSettings[K]) {
    setForm((prev) => ({
      ...prev,
      theme: {
        ...prev.theme,
        search: { ...normalizeSearchSettings(prev.theme.search), [key]: value },
      },
    }));
  }

  function updateGridCol(bp: Breakpoint, value: number) {
    setForm((prev) => ({
      ...prev,
      gridCols: {
        ...resolveGridCols(prev.gridCols),
        [bp]: clampGridCols(bp, value),
      },
    }));
  }

  function applyGridPreset(preset: GridColsConfig) {
    setForm((prev) => ({ ...prev, gridCols: resolveGridCols(preset) }));
  }

  function setTabs(next: DashboardTab[]) {
    setForm((prev) => ({
      ...prev,
      tabs: next.map((tab, order) => ({ ...tab, order })),
    }));
  }

  function updateEditableTab(id: string, updater: (tab: DashboardTab) => DashboardTab) {
    if (privateTabs.some((tab) => tab.id === id)) {
      setPrivateTabs((previous) => previous.map((tab) => tab.id === id ? updater(tab) : tab));
      return;
    }
    setTabs(form.tabs.map((tab) => tab.id === id ? updater(tab) : tab));
  }

  function renameTab(id: string, name: string) {
    updateEditableTab(id, (tab) => ({ ...tab, name }));
  }

  function setTabDeviceVisibility(id: string, bp: Breakpoint, visible: boolean) {
    updateEditableTab(
      id,
      (tab) => {
        const next = { ...(tab.deviceVisibility || {}) };
        if (visible) delete next[bp];
        else next[bp] = false;
        const deviceVisibility = Object.keys(next).length ? next : undefined;
        return { ...tab, deviceVisibility };
      },
    );
  }

  async function addTab() {
    const name = `Tab ${allEditableTabs.length + 1}`;
    if (accessRole !== "admin") {
      setMessage("");
      try {
        const response = await fetch("/api/auth/dashboards", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name }),
        });
        const json = await response.json();
        if (!response.ok || !json.tab) {
          throw new Error(json.error || "Could not create personal tab");
        }
        const tab = json.tab as DashboardTab;
        setPrivateTabs((previous) => [...previous, tab]);
        setTabOrder((previous) => [...previous, tab.id]);
        setSelectedTabId(tab.id);
        setPanel("tabs");
        setMessage(`Created private tab “${tab.name}”`);
      } catch (error) {
        setMessage(error instanceof Error ? error.message : "Could not create personal tab");
      }
      return;
    }
    const tab: DashboardTab = {
      id: uniqueTabId(name, [...form.tabs, ...privateTabs]),
      name,
      order: form.tabs.length,
      widgetIds: [],
    };
    setTabs([...form.tabs, tab]);
    setTabOrder((previous) => [...previous, tab.id]);
    setSelectedTabId(tab.id);
    setPanel("tabs");
  }

  function removeTab(id: string) {
    if (privateTabs.some((tab) => tab.id === id)) {
      void removePrivateTab(id);
      return;
    }
    if (form.tabs.length <= 1) {
      setMessage("Keep at least one tab");
      return;
    }
    const next = form.tabs.filter((t) => t.id !== id);
    setTabs(next);
    setTabOrder((previous) => previous.filter((tabId) => tabId !== id));
    if (selectedTabId === id) setSelectedTabId(next[0]?.id || "");
  }

  function moveTab(id: string, dir: -1 | 1) {
    const ordered = allEditableTabs.map((tab) => tab.id);
    const index = ordered.indexOf(id);
    const target = index + dir;
    if (index < 0 || target < 0 || target >= ordered.length) return;
    const next = [...ordered];
    const [item] = next.splice(index, 1);
    next.splice(target, 0, item);
    setTabOrder(next);
    const rank = new Map(next.map((tabId, order) => [tabId, order]));
    setTabs([...form.tabs].sort((a, b) => (rank.get(a.id) || 0) - (rank.get(b.id) || 0)));
    setPrivateTabs((previous) =>
      [...previous]
        .sort((a, b) => (rank.get(a.id) || 0) - (rank.get(b.id) || 0))
        .map((tab, order) => ({ ...tab, order })),
    );
  }

  async function makeTabPrivate(tab: DashboardTab) {
    if (accessRole !== "admin") return;
    if (!window.confirm(`Make “${tab.name}” private to your administrator profile? Other users will no longer see this tab.`)) {
      return;
    }
    setSaving(true);
    setMessage("");
    try {
      const response = await fetch("/api/auth/dashboards", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "make-private", tabId: tab.id }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(String(data.error || "Could not make tab private"));
      const next = form.tabs.filter((item) => item.id !== tab.id);
      setTabs(next);
      setPrivateTabs((previous) => [...previous, { ...tab, order: previous.length }]);
      setSelectedTabId(tab.id);
      setMessage(`“${tab.name}” is now private to your profile`);
      router.refresh();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Could not make tab private");
    } finally {
      setSaving(false);
    }
  }

  async function makeTabShared(tab: DashboardTab) {
    setSaving(true);
    setMessage("");
    try {
      const response = await fetch("/api/auth/dashboards", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "make-shared", tabId: tab.id }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(String(data.error || "Could not make tab shared"));
      setPrivateTabs((previous) => previous.filter((item) => item.id !== tab.id));
      setTabs([...form.tabs, { ...tab, order: form.tabs.length }]);
      setSelectedTabId(tab.id);
      setMessage(`“${tab.name}” is now shared`);
      router.refresh();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Could not make tab shared");
    } finally {
      setSaving(false);
    }
  }

  async function removePrivateTab(id: string) {
    const tab = privateTabs.find((item) => item.id === id);
    if (!tab || !window.confirm(`Delete your private “${tab.name}” tab?`)) return;
    const response = await fetch("/api/auth/dashboards", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    });
    if (!response.ok) {
      setMessage("Could not delete private tab");
      return;
    }
    const next = privateTabs.filter((item) => item.id !== id);
    setPrivateTabs(next);
    setTabOrder((previous) => previous.filter((tabId) => tabId !== id));
    if (selectedTabId === id) setSelectedTabId(form.tabs[0]?.id || next[0]?.id || "");
    setMessage(`“${tab.name}” was deleted`);
    router.refresh();
  }

  function toggleWidgetOnTab(widgetId: string) {
    if (!selectedTab) return;
    const has = selectedTab.widgetIds.includes(widgetId);
    const widgetIds = has
      ? selectedTab.widgetIds.filter((id) => id !== widgetId)
      : [...selectedTab.widgetIds, widgetId];
    updateEditableTab(selectedTab.id, (tab) => ({ ...tab, widgetIds }));
    if (!has && !form.enabledWidgets.includes(widgetId)) {
      update("enabledWidgets", [...form.enabledWidgets, widgetId]);
    }
  }

  function toggleWidgetEnabled(id: string) {
    setForm((prev) => {
      const enabled = prev.enabledWidgets.includes(id)
        ? prev.enabledWidgets.filter((w) => w !== id)
        : [...prev.enabledWidgets, id];
      return { ...prev, enabledWidgets: enabled };
    });
  }

  function updateWidgetField(id: string, key: string, value: string) {
    setWidgetConfigs((prev) => ({
      ...prev,
      [id]: { ...(prev[id] || {}), [key]: value },
    }));
    const widgetId = parseInstanceId(id).widgetId;
    if (widgetId === "bookmarks" && key === "groupId") {
      renameServerInstance(id, resolveBookmarksWidgetTitle(value, form.bookmarkGroups));
    }
    if (isNodeTitleWidget(widgetId) && key === "nodeName") {
      renameServerInstance(id, resolveNodeWidgetTitle(widgetId, value));
    }
  }

  function setInstances(next: WidgetInstance[]) {
    setForm((prev) => ({ ...prev, widgetInstances: next }));
  }

  function addServerInstance(widgetId: string, widgetName: string) {
    const current = instancesForWidget(form.widgetInstances || [], widgetId);
    const keys = current.map((i) => i.key);
    // Bookmarks / Speedtest / Glances titles are derived from config — don't number them.
    const label =
      widgetId === "bookmarks" || isNodeTitleWidget(widgetId)
        ? widgetName
        : `${widgetName} ${current.length + 1}`;
    const key = slugInstanceKey(label, keys);
    const id = formatInstanceId(widgetId, key);
    const inst: WidgetInstance = { id, widgetId, key, label };
    setInstances([...(form.widgetInstances || []).filter((i) => i.widgetId !== widgetId), ...current, inst]);
    setWidgetConfigs((prev) => ({ ...prev, [id]: prev[id] || {} }));

    // Add the new card to tabs that already host this package.
    setTabs(
      form.tabs.map((tab) => {
        const hasPackage = tab.widgetIds.some((entry) => parseInstanceId(entry).widgetId === widgetId);
        if (!hasPackage) return tab;
        if (tab.widgetIds.includes(id) || tab.widgetIds.includes(widgetId)) {
          // If tab still has bare package id, keep it (expand at render). Else append instance.
          if (tab.widgetIds.includes(widgetId)) return tab;
          return { ...tab, widgetIds: [...tab.widgetIds, id] };
        }
        return { ...tab, widgetIds: [...tab.widgetIds, id] };
      }),
    );
    if (!form.enabledWidgets.includes(widgetId)) {
      update("enabledWidgets", [...form.enabledWidgets, widgetId]);
    }
    setAddServerOpen(false);
    setWidgetCategory(widgets.find((w) => w.id === widgetId)?.category || "all");
    setMessage(`Added ${label}`);
  }

  function removeServerInstance(instanceId: string) {
    const { widgetId } = parseInstanceId(instanceId);
    const remaining = (form.widgetInstances || []).filter((i) => i.id !== instanceId);
    const still = remaining.filter((i) => i.widgetId === widgetId);
    if (still.length < 1 && isMultiInstanceWidget(widgetId)) {
      setMessage("Keep at least one server card");
      return;
    }
    setInstances(remaining);
    setTabs(
      form.tabs.map((tab) => ({
        ...tab,
        widgetIds: tab.widgetIds.filter((id) => id !== instanceId),
      })),
    );
  }

  function renameServerInstance(instanceId: string, label: string) {
    setInstances(
      (form.widgetInstances || []).map((inst) => (inst.id === instanceId ? { ...inst, label } : inst)),
    );
  }

  function updateWidgetAccent(id: string, mode: WidgetAccentMode, color?: string) {
    setForm((prev) => {
      const current = prev.widgetAccents?.[id] || { mode: "inherit" as WidgetAccentMode };
      const next = {
        mode,
        color: color ?? current.color ?? prev.theme.cardAccentColor ?? prev.theme.accent,
      };
      const widgetAccents = { ...(prev.widgetAccents || {}) };
      if (mode === "inherit" && !color) {
        delete widgetAccents[id];
      } else {
        widgetAccents[id] = next;
      }
      return { ...prev, widgetAccents };
    });
  }

  function updateWidgetIcon(id: string, url: string) {
    setForm((prev) => {
      const widgetIcons = { ...(prev.widgetIcons || {}) };
      const trimmed = url.trim();
      if (!trimmed) delete widgetIcons[id];
      else widgetIcons[id] = trimmed;
      return { ...prev, widgetIcons };
    });
  }

  function closeIconPicker() {
    setIconPickerFor(null);
    setIconQuery("");
    setIconResults([]);
    setIconTotal(0);
    setIconMatched(0);
    setIconTruncated(false);
    setIconError("");
  }

  function applyPickedIcon(url: string) {
    if (!iconPickerFor) return;
    if (iconPickerFor.kind === "widget") {
      updateWidgetIcon(iconPickerFor.id, url);
    } else if (iconPickerFor.kind === "ai-provider") {
      setWidgetConfigs((prev) => ({
        ...prev,
        [iconPickerFor.id]: {
          ...(prev[iconPickerFor.id] || {}),
          [`${iconPickerFor.provider}Logo`]: url,
        },
      }));
    } else {
      setBookmarkIconAssignment({ id: iconPickerFor.id, url });
    }
    closeIconPicker();
  }

  async function uploadBookmarkIcon(file: File) {
    const body = new FormData();
    body.set("kind", "widget-icon");
    body.set("key", `bookmark-${Date.now()}`);
    body.set("file", file);
    const res = await fetch("/api/uploads", { method: "POST", body });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `Upload failed (HTTP ${res.status})`);
    if (!data.url) throw new Error("Upload completed but returned no icon URL");
    return String(data.url || "");
  }

  function updateWidgetChrome(
    id: string,
    patch: Partial<WidgetChromeSettings>,
    fallback?: WidgetChromeSettings,
  ) {
    setForm((prev) => {
      const widgetChrome = { ...(prev.widgetChrome || {}) };
      const merged = mergeWidgetChromeEntry(widgetChrome[id], patch, fallback);
      if (!merged) delete widgetChrome[id];
      else widgetChrome[id] = merged;
      return { ...prev, widgetChrome };
    });
  }

  async function onSave(e: React.FormEvent) {
    e.preventDefault();
    if (!canManageSettings && !profileEditablePanel) {
      setMessage("Read-only access: you do not have permission to save changes.");
      return;
    }
    if (panel === "admin") return;
    setSaving(true);
    setMessage("");
    try {
      const payload = withNodeTitlesFromConfigs(
        withBookmarkTitlesFromConfigs(form, widgetConfigs),
        widgetConfigs,
      );
      if (payload !== form) setForm(payload);
      const preferencesRes = await fetch("/api/auth/preferences", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          theme: payload.theme,
          bookmarks: payload.bookmarks,
          bookmarkGroups: payload.bookmarkGroups,
        }),
      });
      if (!preferencesRes.ok) throw new Error("Profile save failed");

      for (const tab of privateTabs) {
        const privateTabResponse = await fetch("/api/auth/dashboards", {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(tab),
        });
        if (!privateTabResponse.ok) {
          throw new Error(`Could not save private tab “${tab.name}”`);
        }
      }
      const tabOrderResponse = await fetch("/api/auth/dashboards", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ orderIds: tabOrder }),
      });
      if (!tabOrderResponse.ok) throw new Error("Could not save tab order");

      if (!canManageSettings) {
        setMessage("Profile settings saved");
        router.refresh();
        return;
      }

      const globalPayload = {
        ...payload,
        theme: globalProfileDefaults.theme,
        bookmarks: globalProfileDefaults.bookmarks,
        bookmarkGroups: globalProfileDefaults.bookmarkGroups,
      };
      const res = await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(globalPayload),
      });
      if (!res.ok) throw new Error("Save failed");

      await Promise.all(
        Object.entries(widgetConfigs).map(([id, cfg]) => {
          const widgetId = parseInstanceId(id).widgetId || id;
          let payload: Record<string, unknown> = { ...cfg };
          if (widgetId === "jellyfin-slider") {
            payload = { ...cfg, serversJson: "" };
          }
          if (widgetId === "media-calendar") {
            let sources: unknown[] = [];
            try {
              if (cfg.sourcesJson?.trim()) {
                const parsed = JSON.parse(cfg.sourcesJson);
                if (Array.isArray(parsed)) sources = parsed;
              } else if (Array.isArray((cfg as Record<string, unknown>).sources)) {
                sources = (cfg as Record<string, unknown>).sources as unknown[];
              }
            } catch {
              sources = [];
            }
            payload = {
              ...cfg,
              sources,
              sourcesJson: JSON.stringify(sources),
            };
          }
          return fetch(`/api/widgets/${id}/config`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          });
        }),
      );

      setMessage("Settings saved");
      router.refresh();
    } catch {
      setMessage("Could not save settings");
    } finally {
      setSaving(false);
    }
  }

  const filteredWidgets = useMemo(() => {
    const q = widgetQuery.trim().toLowerCase();
    return categorized
      .filter(([category]) => widgetCategory === "all" || category === widgetCategory)
      .map(([category, items]) => {
        if (!q) return [category, items] as const;
        return [
          category,
          items.filter(
            (w) =>
              w.name.toLowerCase().includes(q) ||
              w.id.toLowerCase().includes(q) ||
              w.description.toLowerCase().includes(q),
          ),
        ] as const;
      })
      .filter(([, items]) => items.length > 0);
  }, [categorized, widgetQuery, widgetCategory]);

  const allPanels: { id: SettingsPanel; label: string; hint: string }[] = [
    { id: "general", label: "General", hint: "Identity & branding" },
    { id: "profile", label: "Profile", hint: "Your account & password" },
    { id: "appearance", label: "Appearance", hint: "Theme & background" },
    { id: "search", label: "Search", hint: "Popup style & content" },
    { id: "bookmarks", label: "BookMarks", hint: "Links for the bookmarks widget" },
    { id: "tabs", label: "Tabs", hint: "Pages & widget placement" },
    { id: "widgets", label: "Widgets", hint: "Enable & credentials" },
    { id: "manager", label: "Widget Manager", hint: "Install, update & repair" },
    { id: "system", label: "System", hint: "Dashboard updates" },
    { id: "admin", label: "Admin", hint: "Backup, export & restore" },
  ];
  const panels = allPanels.filter((item) => {
    if (item.id === "general") return accessRole === "admin";
    if (item.id === "system") return accessRole === "admin";
    if (item.id === "profile") return accessRole !== "admin";
    if (item.id === "tabs") return true;
    if (item.id === "widgets" || item.id === "manager") return hasAccess("widgets.manage");
    if (item.id === "admin") return hasAccess("backups.manage");
    return true;
  });
  const searchAppearance = normalizeSearchSettings(form.theme.search);

  return (
    <form className={`hd-settings${canManageSettings || profileEditablePanel ? "" : " hd-settings--readonly"}`} onSubmit={onSave}>
      <div
        className={`hd-settings__hero${panel === "widgets" || panel === "manager" || panel === "system" || panel === "bookmarks" || panel === "admin" ? " hd-settings__hero--widgets" : ""}`}
      >
        <div className="hd-settings__hero-main">
          <div>
            <div className="hd-settings__kicker">Control center</div>
            <h1>Settings</h1>
            <p>
              {panel === "system"
                ? "Upload verified Homedash application updates while preserving all persistent configuration and credentials."
                : panel === "admin"
                ? "Back up config and widget credentials, export copies, and restore after a bad update."
                : "Configure identity, tabs, theme, and widget packages for this dashboard."}
            </p>
          </div>
          <div className="hd-settings__hero-actions">
            {panel === "manager" ? <div id="hd-widget-manager-hero-tools" /> : null}
            {panel === "widgets" ? (
              <input
                className="hd-search hd-search--hero"
                type="search"
                placeholder="Search widgets…"
                value={widgetQuery}
                onChange={(e) => setWidgetQuery(e.target.value)}
                aria-label="Search widgets"
              />
            ) : null}
            {panel === "bookmarks" ? (
              <input
                className="hd-search hd-search--hero"
                type="search"
                placeholder="Search bookmarks…"
                value={bookmarkQuery}
                onChange={(e) => setBookmarkQuery(e.target.value)}
                aria-label="Search bookmarks"
              />
            ) : null}
            <div className="hd-settings__hero-btns">
              {panel === "bookmarks" ? (
                <button
                  className="hd-btn"
                  type="button"
                  onClick={() => {
                    setBookmarkAddToken((n) => n + 1);
                    setBookmarkFormOpen(true);
                  }}
                >
                  Add Bookmark
                </button>
              ) : null}
              {(canManageSettings || profileEditablePanel) && panel !== "profile" && panel !== "admin" && panel !== "manager" ? (
                <button className="hd-btn hd-btn--primary" type="submit" disabled={saving}>
                  {saving ? "Saving…" : "Save changes"}
                </button>
              ) : null}
            </div>
            {message ? <span className="hd-settings__toast">{message}</span> : null}
          </div>
        </div>

        {panel === "widgets" ? (
          <div className="hd-filter-bar">
            <div className="hd-filter-tabs" role="tablist" aria-label="Widget groups">
              <button
                type="button"
                role="tab"
                aria-selected={widgetCategory === "all"}
                className={`hd-filter-tab${widgetCategory === "all" ? " is-active" : ""}`}
                onClick={() => setWidgetCategory("all")}
              >
                All
                <em>{widgets.length}</em>
              </button>
              {widgetCategories.map(({ category, count }) => (
                <button
                  key={category}
                  type="button"
                  role="tab"
                  aria-selected={widgetCategory === category}
                  className={`hd-filter-tab${widgetCategory === category ? " is-active" : ""}`}
                  onClick={() => setWidgetCategory(category)}
                >
                  {category}
                  <em>{count}</em>
                </button>
              ))}
            </div>
            <button
              type="button"
              className="hd-btn hd-btn--primary hd-filter-bar__add"
              onClick={() => setAddServerOpen(true)}
            >
              Add Widget
            </button>
          </div>
        ) : null}
      </div>

      {addServerOpen ? (
        <div
          className="hd-modal-scrim"
          role="presentation"
          onClick={() => setAddServerOpen(false)}
        >
          <div
            className="hd-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="hd-add-server-title"
            onClick={(e) => e.stopPropagation()}
          >
            <header className="hd-modal__head">
              <div>
                <div className="hd-settings__kicker">Multi-instance widgets</div>
                <h2 id="hd-add-server-title">Add another widget card</h2>
                <p>Choose a widget package to create another independently configured card.</p>
              </div>
              <button
                type="button"
                className="hd-btn"
                onClick={() => setAddServerOpen(false)}
              >
                Close
              </button>
            </header>
            <div className="hd-modal__grid">
              {multiServerWidgets.map((widget) => {
                const count = instancesForWidget(form.widgetInstances || [], widget.id).length;
                return (
                  <button
                    key={widget.id}
                    type="button"
                    className="hd-modal__tile"
                    onClick={() => addServerInstance(widget.id, widget.name)}
                    title={`Add another ${widget.name} card`}
                  >
                    <WidgetBrandMark
                      widgetId={widget.id}
                      name={widget.name}
                      iconUrl={form.widgetIcons?.[widget.id]}
                      size="lg"
                    />
                    <strong className="hd-modal__tile-title">{widget.name}</strong>
                    <span className="hd-modal__tile-count">
                      {count} card{count === 1 ? "" : "s"}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      ) : null}

      {iconPickerFor && typeof document !== "undefined"
        ? createPortal(
            <div
              className="hd-modal-scrim hd-modal-scrim--icons"
              role="presentation"
              onClick={() => closeIconPicker()}
            >
              <div
                className="hd-modal hd-modal--icons"
                role="dialog"
                aria-modal="true"
                aria-labelledby="hd-icon-picker-title"
                onClick={(e) => e.stopPropagation()}
              >
                <header className="hd-modal__head">
                  <div>
                    <div className="hd-settings__kicker">Dashboard Icons</div>
                    <h2 id="hd-icon-picker-title">Pick a logo</h2>
                    <p>
                      Search your local <code>icons</code> library
                      {iconPickerFor?.kind === "bookmark" ? " for this bookmark" : " for this widget"}
                      {iconTotal ? ` · ${iconTotal.toLocaleString()} icons` : ""}.
                    </p>
                  </div>
                  <button type="button" className="hd-btn" onClick={() => closeIconPicker()}>
                    Close
                  </button>
                </header>
                <input
                  className="hd-search"
                  type="search"
                  placeholder="Search local icons… e.g. proxmox, jellyfin, pi-hole"
                  value={iconQuery}
                  onChange={(e) => setIconQuery(e.target.value)}
                  autoFocus
                />
                {iconError ? <div className="hd-asset-error">{iconError}</div> : null}
                {!iconLoading && iconResults.length && iconTruncated ? (
                  <div className="hd-asset-hint">
                    {iconQuery.trim()
                      ? `Showing ${iconResults.length.toLocaleString()} of ${iconMatched.toLocaleString()} matches — refine your search.`
                      : `Showing ${iconResults.length.toLocaleString()} of ${iconTotal.toLocaleString()} icons — type a name to find the rest.`}
                  </div>
                ) : null}
                <div className="hd-icon-grid">
                  {iconLoading ? <div className="hd-icon-grid__empty">Loading icons…</div> : null}
                  {!iconLoading && !iconResults.length ? (
                    <div className="hd-icon-grid__empty">
                      {iconQuery.trim()
                        ? "No icons matched that search. Clear the box to browse the library."
                        : "No icons found in the local library. Check that /icons is mounted, or upload an icon from the bookmark/widget form."}
                    </div>
                  ) : null}
                  {iconResults.map((icon) => (
                    <button
                      key={icon.name}
                      type="button"
                      className="hd-icon-grid__item"
                      title={icon.name}
                      onClick={() => {
                        applyPickedIcon(icon.url);
                        setMessage(`Logo set to ${icon.name}`);
                      }}
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={icon.url} alt="" loading="lazy" />
                      <span>{icon.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>,
            document.body,
          )
        : null}

      <div className="hd-settings__layout">
        <aside className="hd-settings__nav" aria-label="Settings sections">
          {panels.map((item) => (
            <button
              key={item.id}
              type="button"
              className={`hd-settings__nav-item${panel === item.id ? " is-active" : ""}`}
              onClick={() => setPanel(item.id)}
            >
              <strong>{item.label}</strong>
              <span>{item.hint}</span>
            </button>
          ))}
        </aside>

        <div className="hd-settings__content">
          {!canManageSettings && !profileEditablePanel ? <div className="hd-settings__readonly-banner">Read-only settings access</div> : null}
          {panel === "profile" && accessRole !== "admin" ? (
            <SettingsCardGridSection
              panelId="profile"
              editMode={settingsCardEditMode}
              saveToken={settingsCardSaveToken}
              cancelToken={settingsCardCancelToken}
              onSaved={() => setSettingsCardEditMode(false)}
              onCancelled={() => setSettingsCardEditMode(false)}
            >
              <ProfileAccountCard />
              <AccountPasswordCard username={accessUsername} role={accessRole} />
            </SettingsCardGridSection>
          ) : null}

          {panel === "general" && accessRole === "admin" ? (
            <SettingsCardGridSection
              panelId="general"
              editMode={settingsCardEditMode}
              saveToken={settingsCardSaveToken}
              cancelToken={settingsCardCancelToken}
              onSaved={() => setSettingsCardEditMode(false)}
              onCancelled={() => setSettingsCardEditMode(false)}
            >
              <article className="hd-panel-card">
                <header>
                  <h2>Application</h2>
                  <p>Name shown in the header and browser title.</p>
                </header>
                <div className="hd-field">
                  <label htmlFor="appName">Application name</label>
                  <input id="appName" type="text" value={form.appName} onChange={(e) => update("appName", e.target.value)} required />
                </div>
              </article>
              <article className="hd-panel-card">
                <header>
                  <h2>Local dashboard access</h2>
                  <p>Choose whether local HTTP visits move to your configured Cloudflare tunnel.</p>
                </header>
                <div className="hd-widget-card__chrome-toggle">
                  <div>
                    <span
                      className="hd-widget-card__chrome-label"
                      id="redirect-local-to-public"
                    >
                      Redirect local IP to Cloudflare
                    </span>
                    <div className="hd-widget-card__title-hint">
                      Turn this off to keep the dashboard on its local IP address.
                    </div>
                  </div>
                  <label
                    className="hd-switch"
                    title={form.redirectLocalToPublic ? "On" : "Off"}
                  >
                    <input
                      type="checkbox"
                      checked={form.redirectLocalToPublic}
                      aria-labelledby="redirect-local-to-public"
                      onChange={(e) => update("redirectLocalToPublic", e.target.checked)}
                    />
                    <span />
                  </label>
                </div>
              </article>
              <article className="hd-panel-card">
                <header>
                  <h2>Brand assets</h2>
                  <p>Logo and favicon via URL or upload.</p>
                </header>
                <AssetField
                  id="logoUrl"
                  label="Logo"
                  value={form.logoUrl}
                  placeholder="https://… or upload"
                  kind="logo"
                  preview="logo"
                  onChange={(value) => update("logoUrl", value)}
                  onUploaded={setMessage}
                />
                <AssetField
                  id="faviconUrl"
                  label="Favicon"
                  value={form.faviconUrl || ""}
                  placeholder="https://… or upload"
                  kind="favicon"
                  preview="favicon"
                  onChange={(value) => update("faviconUrl", value)}
                  onUploaded={setMessage}
                />
              </article>
              <AccountPasswordCard username={accessUsername} role={accessRole} />
              <AccessManagementCard />
            </SettingsCardGridSection>
          ) : null}

          {panel === "appearance" ? (
            <SettingsCardGridSection
              panelId="appearance"
              editMode={settingsCardEditMode}
              saveToken={settingsCardSaveToken}
              cancelToken={settingsCardCancelToken}
              onSaved={() => setSettingsCardEditMode(false)}
              onCancelled={() => setSettingsCardEditMode(false)}
            >
              <article className="hd-panel-card">
                <header>
                  <h2>Global Theme</h2>
                  <p>Set the dashboard's overall colors, surfaces, and font.</p>
                </header>
                <div className="hd-field-row">
                  <div className="hd-field">
                    <label htmlFor="mode">Mode</label>
                    <select id="mode" value={form.theme.mode} onChange={(e) => updateTheme("mode", e.target.value as "dark" | "light")}>
                      <option value="dark">Dark</option>
                      <option value="light">Light</option>
                    </select>
                  </div>
                  <ColorField
                    id="accent"
                    label="Accent"
                    value={form.theme.accent}
                    onChange={(value) => updateTheme("accent", value)}
                  />
                </div>
                <ColorField
                  id="buttonAccentColor"
                  label="Button accent color (optional)"
                  value={form.theme.buttonAccentColor || ""}
                  placeholder="Leave blank to use Accent"
                  allowEmpty
                  onChange={(value) => updateTheme("buttonAccentColor", value)}
                />
                <ColorField
                  id="background"
                  label="Background color"
                  value={form.theme.background}
                  placeholder="#0b0f15"
                  onChange={(value) => updateTheme("background", value)}
                />
                <ColorField
                  id="surface"
                  label="Surface (panels / settings)"
                  value={form.theme.surface}
                  placeholder="rgba(18, 24, 32, 0.66)"
                  preferAlpha
                  onChange={(value) => updateTheme("surface", value)}
                />
                <div className="hd-field">
                  <label htmlFor="font">Font family</label>
                  <input id="font" type="text" value={form.theme.font} onChange={(e) => updateTheme("font", e.target.value)} />
                </div>
              </article>
              <article className="hd-panel-card">
                <header>
                  <h2>Header bar</h2>
                  <p>Top bar layout, chrome, and tab styles — updates live.</p>
                </header>
                <div className="hd-field">
                  <label>Bar placement</label>
                  <div className="hd-bg-mode" role="group" aria-label="Header placement">
                    <button
                      type="button"
                      className={`hd-bg-mode__btn${(form.theme.headerLayout || "flush") === "flush" ? " is-active" : ""}`}
                      onClick={() => updateTheme("headerLayout", "flush" as HeaderLayoutMode)}
                    >
                      Flush edges
                    </button>
                    <button
                      type="button"
                      className={`hd-bg-mode__btn${form.theme.headerLayout === "floating" ? " is-active" : ""}`}
                      onClick={() => updateTheme("headerLayout", "floating" as HeaderLayoutMode)}
                    >
                      Floating
                    </button>
                  </div>
                </div>
                <ColorField
                  id="headerBackground"
                  label="Background color"
                  value={form.theme.headerBackground || ""}
                  placeholder="rgb(8, 12, 18)"
                  preferAlpha
                  onChange={(value) => updateTheme("headerBackground", value)}
                />
                <div className="hd-field">
                  <label htmlFor="headerOpacity">
                    Opacity ({Math.round((form.theme.headerOpacity ?? 0.72) * 100)}%)
                  </label>
                  <input
                    id="headerOpacity"
                    type="range"
                    min={0}
                    max={100}
                    value={Math.round((form.theme.headerOpacity ?? 0.72) * 100)}
                    onChange={(e) => updateTheme("headerOpacity", Number(e.target.value) / 100)}
                  />
                </div>
                <div className="hd-field">
                  <label htmlFor="headerBlur">Blur ({form.theme.headerBlur ?? 16}px)</label>
                  <input
                    id="headerBlur"
                    type="range"
                    min={0}
                    max={40}
                    value={form.theme.headerBlur ?? 16}
                    onChange={(e) => updateTheme("headerBlur", Number(e.target.value))}
                  />
                </div>
                <div className="hd-field-row">
                  <div className="hd-field">
                    <label htmlFor="headerBorderStyle">Border type</label>
                    <select
                      id="headerBorderStyle"
                      value={form.theme.headerBorderStyle || "soft"}
                      onChange={(e) => updateTheme("headerBorderStyle", e.target.value as CardBorderStyle)}
                    >
                      <option value="none">None</option>
                      <option value="soft">Soft</option>
                      <option value="glass">Glass</option>
                      <option value="solid">Solid</option>
                      <option value="strong">Strong</option>
                      <option value="dashed">Dashed</option>
                    </select>
                  </div>
                  <div className="hd-field">
                    <label htmlFor="headerShadow">Shadow</label>
                    <select
                      id="headerShadow"
                      value={form.theme.headerShadow || "none"}
                      onChange={(e) => updateTheme("headerShadow", e.target.value as CardShadowStyle)}
                    >
                      <option value="none">None</option>
                      <option value="soft">Soft</option>
                      <option value="lift">Lift</option>
                    </select>
                  </div>
                </div>
                <ColorField
                  id="headerBorderColor"
                  label="Border color (optional)"
                  value={form.theme.headerBorderColor || ""}
                  placeholder="Leave blank for border-type default"
                  allowEmpty
                  preferAlpha
                  onChange={(value) => updateTheme("headerBorderColor", value)}
                />
                <div className="hd-field">
                  <label htmlFor="headerRadius">
                    Corner radius ({form.theme.headerRadius ?? 18}px)
                    {(form.theme.headerLayout || "flush") === "flush" ? " — used when floating" : ""}
                  </label>
                  <input
                    id="headerRadius"
                    type="range"
                    min={0}
                    max={32}
                    value={form.theme.headerRadius ?? 18}
                    onChange={(e) => updateTheme("headerRadius", Number(e.target.value))}
                  />
                </div>
                <div className="hd-cards-accent">
                  <div className="hd-cards-accent__head">
                    <strong>Tabs</strong>
                    <span>Style of the dashboard tab row in the header.</span>
                  </div>
                  <div className="hd-field-row">
                    <div className="hd-field">
                      <label htmlFor="headerTabStyle">Tab layout</label>
                      <select
                        id="headerTabStyle"
                        value={form.theme.headerTabStyle || "pill"}
                        onChange={(e) => updateTheme("headerTabStyle", e.target.value as HeaderTabStyle)}
                      >
                        <option value="pill">Pill track</option>
                        <option value="segment">Segmented</option>
                        <option value="chip">Separate chips</option>
                        <option value="underline">Underline</option>
                      </select>
                    </div>
                    <div className="hd-field">
                      <label htmlFor="headerTabActiveStyle">Active tab</label>
                      <select
                        id="headerTabActiveStyle"
                        value={form.theme.headerTabActiveStyle || "accent"}
                        onChange={(e) =>
                          updateTheme("headerTabActiveStyle", e.target.value as HeaderTabActiveStyle)
                        }
                      >
                        <option value="accent">Accent fill</option>
                        <option value="soft">Soft accent</option>
                        <option value="outline">Outline</option>
                        <option value="plain">Plain</option>
                      </select>
                    </div>
                  </div>
                  <div className="hd-field">
                    <label htmlFor="headerTabRadius">
                      Tab radius (
                      {(form.theme.headerTabRadius ?? 999) >= 40
                        ? "pill"
                        : `${form.theme.headerTabRadius ?? 999}px`}
                      )
                    </label>
                    <input
                      id="headerTabRadius"
                      type="range"
                      min={0}
                      max={40}
                      value={Math.min(40, form.theme.headerTabRadius ?? 40)}
                      onChange={(e) => {
                        const n = Number(e.target.value);
                        updateTheme("headerTabRadius", n >= 40 ? 999 : n);
                      }}
                    />
                  </div>
                </div>
                <div className="hd-cards-accent" style={{ marginTop: 14 }}>
                  <div className="hd-cards-accent__head">
                    <strong>Quick links</strong>
                    <span>Desktop icon row placement. Tablet/mobile: listed in the menu.</span>
                  </div>
                  <div className="hd-field" style={{ marginTop: 10 }}>
                    <label>Placement</label>
                    <div className="hd-bg-mode hd-bg-mode--3" role="group" aria-label="Quick links placement">
                      {(
                        [
                          { id: "left", label: "Left", hint: "Right of logo" },
                          { id: "center", label: "Center", hint: "Under tabs" },
                          { id: "right", label: "Right", hint: "Before actions" },
                        ] as const
                      ).map((opt) => {
                        const active =
                          normalizeHeaderQuickLinksPlacement(form.theme.headerQuickLinksPlacement) ===
                          opt.id;
                        return (
                          <button
                            key={opt.id}
                            type="button"
                            className={`hd-bg-mode__btn${active ? " is-active" : ""}`}
                            onClick={() =>
                              updateTheme("headerQuickLinksPlacement", opt.id as HeaderQuickLinksPlacement)
                            }
                          >
                            <strong style={{ display: "block" }}>{opt.label}</strong>
                            <span style={{ display: "block", fontSize: "0.72rem", fontWeight: 500, opacity: 0.72 }}>
                              {opt.hint}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                  <HeaderQuickLinksEditor
                    items={form.theme.headerQuickLinkItems}
                    legacy={form.theme.headerQuickLinks}
                    onChange={(items) => updateTheme("headerQuickLinkItems", items)}
                  />
                </div>
              </article>
              <article className="hd-panel-card">
                <header>
                  <h2>Cards</h2>
                  <p>Global look for every card — widgets, settings panels, modals, and more.</p>
                </header>
                <div className="hd-card-theme-preview" aria-hidden="true">
                  <div
                    className={`hd-widget hd-accent-${form.theme.cardAccent === "off" ? "off" : form.theme.cardAccent === "solid" ? "solid" : "rainbow"}`}
                    style={
                      (form.theme.cardAccent || "rainbow") === "solid"
                        ? ({ ["--hd-widget-accent-color" as string]: form.theme.cardAccentColor || form.theme.accent } as CSSProperties)
                        : undefined
                    }
                  >
                    <div className="hd-widget__head">
                      <div className="hd-widget__identity">
                        <div className="hd-widget__title">Preview card</div>
                      </div>
                    </div>
                    <div className="hd-widget-body">
                      <span className="hd-card-theme-preview__copy">
                        Border, fill, blur, and shadow update here in realtime.
                      </span>
                    </div>
                  </div>
                </div>
                <ColorField
                  id="cardBackground"
                  label="Background color"
                  value={form.theme.cardBackground || ""}
                  placeholder="rgb(12, 16, 22) or #0c1016"
                  preferAlpha
                  onChange={(value) => updateTheme("cardBackground", value)}
                />
                <div className="hd-field">
                  <label htmlFor="cardOpacity">
                    Opacity ({Math.round((form.theme.cardOpacity ?? 0.85) * 100)}%)
                  </label>
                  <input
                    id="cardOpacity"
                    type="range"
                    min={0}
                    max={100}
                    value={Math.round((form.theme.cardOpacity ?? 0.85) * 100)}
                    onChange={(e) => updateTheme("cardOpacity", Number(e.target.value) / 100)}
                  />
                </div>
                <div className="hd-field">
                  <label htmlFor="cardBlur">Blur ({form.theme.cardBlur ?? 18}px)</label>
                  <input
                    id="cardBlur"
                    type="range"
                    min={0}
                    max={40}
                    value={form.theme.cardBlur ?? 18}
                    onChange={(e) => updateTheme("cardBlur", Number(e.target.value))}
                  />
                </div>
                <div className="hd-field">
                  <label htmlFor="cardSaturate">Glass saturate ({form.theme.cardSaturate ?? 120}%)</label>
                  <input
                    id="cardSaturate"
                    type="range"
                    min={100}
                    max={200}
                    value={form.theme.cardSaturate ?? 120}
                    onChange={(e) => updateTheme("cardSaturate", Number(e.target.value))}
                  />
                </div>
                <div className="hd-field-row">
                  <div className="hd-field">
                    <label htmlFor="cardBorderStyle">Border type</label>
                    <select
                      id="cardBorderStyle"
                      value={form.theme.cardBorderStyle || "glass"}
                      onChange={(e) => updateTheme("cardBorderStyle", e.target.value as CardBorderStyle)}
                    >
                      <option value="none">None</option>
                      <option value="soft">Soft</option>
                      <option value="glass">Glass</option>
                      <option value="solid">Solid</option>
                      <option value="strong">Strong</option>
                      <option value="dashed">Dashed</option>
                    </select>
                  </div>
                  <div className="hd-field">
                    <label htmlFor="cardShadow">Shadow</label>
                    <select
                      id="cardShadow"
                      value={form.theme.cardShadow || "none"}
                      onChange={(e) => updateTheme("cardShadow", e.target.value as CardShadowStyle)}
                    >
                      <option value="none">None</option>
                      <option value="soft">Soft</option>
                      <option value="lift">Lift</option>
                    </select>
                  </div>
                </div>
                <ColorField
                  id="cardBorderColor"
                  label="Border color (optional)"
                  value={form.theme.cardBorderColor || ""}
                  placeholder="Leave blank for border-type default"
                  allowEmpty
                  preferAlpha
                  onChange={(value) => updateTheme("cardBorderColor", value)}
                />
                <div className="hd-field">
                  <label htmlFor="radius">Corner radius ({form.theme.radius}px)</label>
                  <input
                    id="radius"
                    type="range"
                    min={0}
                    max={32}
                    value={form.theme.radius}
                    onChange={(e) => updateTheme("radius", Number(e.target.value))}
                  />
                </div>
                <div className="hd-cards-accent">
                  <div className="hd-cards-accent__head">
                    <strong>Accent bar</strong>
                    <span>Left edge stripe on dashboard widgets. Override per widget under Widgets.</span>
                  </div>
                  <div className="hd-field">
                    <label htmlFor="cardAccent">Default accent</label>
                    <select
                      id="cardAccent"
                      value={form.theme.cardAccent || "rainbow"}
                      onChange={(e) => updateTheme("cardAccent", e.target.value as AppSettings["theme"]["cardAccent"])}
                    >
                      <option value="rainbow">Rainbow</option>
                      <option value="solid">Solid color</option>
                      <option value="off">Off</option>
                    </select>
                  </div>
                  {(form.theme.cardAccent || "rainbow") === "solid" ? (
                    <ColorField
                      id="cardAccentColor"
                      label="Accent bar color"
                      value={form.theme.cardAccentColor || form.theme.accent}
                      onChange={(value) => updateTheme("cardAccentColor", value)}
                    />
                  ) : null}
                  <div className="hd-accent-preview" data-mode={form.theme.cardAccent || "rainbow"}>
                    <div
                      className="hd-accent-preview__bar"
                      style={
                        (form.theme.cardAccent || "rainbow") === "solid"
                          ? { background: form.theme.cardAccentColor || form.theme.accent }
                          : undefined
                      }
                    />
                    <div className="hd-accent-preview__body">
                      <strong>Preview</strong>
                      <span>
                        {(form.theme.cardAccent || "rainbow") === "off"
                          ? "No accent bar"
                          : (form.theme.cardAccent || "rainbow") === "solid"
                            ? "Solid accent bar"
                            : "Rainbow accent bar"}
                      </span>
                    </div>
                  </div>
                </div>
              </article>
              <article className="hd-panel-card">
                <header>
                  <h2>Backdrop</h2>
                  <p>Static wallpaper or a rotating gallery with configurable transitions.</p>
                </header>
                <div className="hd-field">
                  <label htmlFor="backgroundImageMode">Background mode</label>
                  <div className="hd-bg-mode" role="group" aria-label="Background mode">
                    <button
                      type="button"
                      className={`hd-bg-mode__btn${(form.theme.backgroundImageMode || "static") === "static" ? " is-active" : ""}`}
                      onClick={() => updateTheme("backgroundImageMode", "static" as BackgroundImageMode)}
                    >
                      Static image
                    </button>
                    <button
                      type="button"
                      className={`hd-bg-mode__btn${form.theme.backgroundImageMode === "rotate" ? " is-active" : ""}`}
                      onClick={() => updateTheme("backgroundImageMode", "rotate" as BackgroundImageMode)}
                    >
                      Rotating gallery
                    </button>
                  </div>
                </div>
                {(form.theme.backgroundImageMode || "static") === "static" ? (
                  <AssetField
                    id="backgroundImageUrl"
                    label="Background image"
                    value={form.theme.backgroundImageUrl || ""}
                    placeholder="https://…/wallpaper.jpg or upload"
                    kind="background"
                    preview="background"
                    onChange={(value) => updateTheme("backgroundImageUrl", value)}
                    onUploaded={setMessage}
                  />
                ) : (
                  <>
                    <BackgroundGalleryField
                      urls={form.theme.backgroundImageUrls || []}
                      onChange={(urls) => updateTheme("backgroundImageUrls", urls)}
                      onUploaded={setMessage}
                    />
                    <div className="hd-field">
                      <label htmlFor="backgroundImageRotateSeconds">
                        Rotate every ({Math.round((form.theme.backgroundImageRotateSeconds ?? 120) / 60)} min)
                      </label>
                      <input
                        id="backgroundImageRotateSeconds"
                        type="range"
                        min={1}
                        max={30}
                        value={Math.max(1, Math.round((form.theme.backgroundImageRotateSeconds ?? 120) / 60))}
                        onChange={(e) =>
                          updateTheme("backgroundImageRotateSeconds", Number(e.target.value) * 60)
                        }
                      />
                    </div>
                    <div className="hd-field">
                      <label htmlFor="backgroundImageTransition">Transition</label>
                      <select
                        id="backgroundImageTransition"
                        value={form.theme.backgroundImageTransition || "fade"}
                        onChange={(e) =>
                          updateTheme(
                            "backgroundImageTransition",
                            e.target.value as BackgroundImageTransition,
                          )
                        }
                      >
                        <option value="fade">Fade</option>
                        <option value="slide">Slide</option>
                        <option value="zoom">Zoom</option>
                        <option value="blur">Blur</option>
                      </select>
                    </div>
                    <div className="hd-field">
                      <label htmlFor="backgroundImageTransitionMs">
                        Transition speed (
                        {((form.theme.backgroundImageTransitionMs ?? 1400) / 1000).toFixed(1)}s)
                      </label>
                      <input
                        id="backgroundImageTransitionMs"
                        type="range"
                        min={3}
                        max={50}
                        step={1}
                        value={Math.round((form.theme.backgroundImageTransitionMs ?? 1400) / 100)}
                        onChange={(e) =>
                          updateTheme("backgroundImageTransitionMs", Number(e.target.value) * 100)
                        }
                      />
                    </div>
                  </>
                )}
                <div className="hd-field">
                  <label htmlFor="backgroundImageOpacity">
                    Opacity ({Math.round((form.theme.backgroundImageOpacity ?? 0.35) * 100)}%)
                  </label>
                  <input
                    id="backgroundImageOpacity"
                    type="range"
                    min={0}
                    max={100}
                    value={Math.round((form.theme.backgroundImageOpacity ?? 0.35) * 100)}
                    onChange={(e) => updateTheme("backgroundImageOpacity", Number(e.target.value) / 100)}
                  />
                </div>
                <div className="hd-field">
                  <label htmlFor="backgroundImageBlur">
                    Blur ({form.theme.backgroundImageBlur ?? 0}px)
                  </label>
                  <input
                    id="backgroundImageBlur"
                    type="range"
                    min={0}
                    max={24}
                    value={form.theme.backgroundImageBlur ?? 0}
                    onChange={(e) => updateTheme("backgroundImageBlur", Number(e.target.value))}
                  />
                </div>
              </article>
              <article className="hd-panel-card">
                <header>
                  <h2>Background graphics</h2>
                  <p>Add a lightweight pattern above the wallpaper and behind every widget.</p>
                </header>
                <label className="hd-toggle">
                  <input
                    type="checkbox"
                    checked={Boolean(form.theme.backgroundPatternEnabled)}
                    onChange={(e) => updateTheme("backgroundPatternEnabled", e.target.checked)}
                  />
                  <span>
                    <strong>Show background graphics</strong>
                    <span>Enable the decorative layer across the entire dashboard.</span>
                  </span>
                </label>
                <div className="hd-field">
                  <label htmlFor="backgroundPatternStyle">Pattern</label>
                  <select
                    id="backgroundPatternStyle"
                    value={form.theme.backgroundPatternStyle || "dots"}
                    disabled={!form.theme.backgroundPatternEnabled}
                    onChange={(e) =>
                      updateTheme("backgroundPatternStyle", e.target.value as BackgroundPatternStyle)
                    }
                  >
                    <option value="dots">Dot matrix</option>
                    <option value="grid">Square grid</option>
                    <option value="diagonal">Diagonal lines</option>
                    <option value="crosshatch">X crosshatch</option>
                    <option value="blueprint">Blueprint grid</option>
                    <option value="diamonds">Diamond lattice</option>
                    <option value="waves">Arc waves</option>
                    <option value="radial">Concentric rings</option>
                  </select>
                </div>
                <ColorField
                  id="backgroundPatternColor"
                  label="Pattern color"
                  value={form.theme.backgroundPatternColor || "#60a5fa"}
                  placeholder="#60a5fa"
                  onChange={(value) => updateTheme("backgroundPatternColor", value)}
                />
                <div className="hd-field">
                  <label htmlFor="backgroundPatternOpacity">
                    Opacity ({Math.round((form.theme.backgroundPatternOpacity ?? 0.18) * 100)}%)
                  </label>
                  <input
                    id="backgroundPatternOpacity"
                    type="range"
                    min={1}
                    max={60}
                    disabled={!form.theme.backgroundPatternEnabled}
                    value={Math.round((form.theme.backgroundPatternOpacity ?? 0.18) * 100)}
                    onChange={(e) =>
                      updateTheme("backgroundPatternOpacity", Number(e.target.value) / 100)
                    }
                  />
                </div>
                <div className="hd-field-row">
                  <div className="hd-field">
                    <label htmlFor="backgroundPatternSize">
                      Scale ({form.theme.backgroundPatternSize ?? 28}px)
                    </label>
                    <input
                      id="backgroundPatternSize"
                      type="range"
                      min={8}
                      max={120}
                      disabled={!form.theme.backgroundPatternEnabled}
                      value={form.theme.backgroundPatternSize ?? 28}
                      onChange={(e) => updateTheme("backgroundPatternSize", Number(e.target.value))}
                    />
                  </div>
                  <div className="hd-field">
                    <label htmlFor="backgroundPatternWeight">
                      Line weight ({(form.theme.backgroundPatternWeight ?? 1).toFixed(1)}px)
                    </label>
                    <input
                      id="backgroundPatternWeight"
                      type="range"
                      min={5}
                      max={40}
                      step={5}
                      disabled={!form.theme.backgroundPatternEnabled}
                      value={Math.round((form.theme.backgroundPatternWeight ?? 1) * 10)}
                      onChange={(e) =>
                        updateTheme("backgroundPatternWeight", Number(e.target.value) / 10)
                      }
                    />
                  </div>
                </div>
                <label className="hd-toggle">
                  <input
                    type="checkbox"
                    checked={Boolean(form.theme.backgroundPatternAnimationEnabled)}
                    disabled={!form.theme.backgroundPatternEnabled}
                    onChange={(e) =>
                      updateTheme("backgroundPatternAnimationEnabled", e.target.checked)
                    }
                  />
                  <span>
                    <strong>Animate graphics</strong>
                    <span>Add subtle motion without moving or resizing dashboard widgets.</span>
                  </span>
                </label>
                <div className="hd-field">
                  <label htmlFor="backgroundPatternAnimation">Animation effect</label>
                  <select
                    id="backgroundPatternAnimation"
                    value={form.theme.backgroundPatternAnimation || "drift"}
                    disabled={
                      !form.theme.backgroundPatternEnabled
                      || !form.theme.backgroundPatternAnimationEnabled
                    }
                    onChange={(e) =>
                      updateTheme(
                        "backgroundPatternAnimation",
                        e.target.value as BackgroundPatternAnimation,
                      )
                    }
                  >
                    <option value="drift">Horizontal drift</option>
                    <option value="diagonal-drift">Diagonal drift</option>
                    <option value="pulse">Soft pulse</option>
                    <option value="breathe">Breathe and glow</option>
                    <option value="scan">Scanning light</option>
                    <option value="rotate">Slow rotation</option>
                    <option value="wave-3d">3D energy waves</option>
                    <option value="ripple-3d">3D expanding ripples</option>
                    <option value="wave-4d">4D directional wave</option>
                  </select>
                </div>
                <div className="hd-field-row">
                  <ColorField
                    id="backgroundPatternAnimationColor"
                    label="Animation color"
                    value={form.theme.backgroundPatternAnimationColor || "#22d3ee"}
                    placeholder="#22d3ee"
                    onChange={(value) => updateTheme("backgroundPatternAnimationColor", value)}
                  />
                  <ColorField
                    id="backgroundPatternAnimationColorSecondary"
                    label="Animation highlight"
                    value={form.theme.backgroundPatternAnimationColorSecondary || "#8b5cf6"}
                    placeholder="#8b5cf6"
                    onChange={(value) =>
                      updateTheme("backgroundPatternAnimationColorSecondary", value)
                    }
                  />
                </div>
                <div className="hd-field-row">
                  <div className="hd-field">
                    <label htmlFor="backgroundPatternAnimationSeconds">
                      Cycle time ({form.theme.backgroundPatternAnimationSeconds ?? 18}s)
                    </label>
                    <input
                      id="backgroundPatternAnimationSeconds"
                      type="range"
                      min={3}
                      max={120}
                      disabled={
                        !form.theme.backgroundPatternEnabled
                        || !form.theme.backgroundPatternAnimationEnabled
                      }
                      value={form.theme.backgroundPatternAnimationSeconds ?? 18}
                      onChange={(e) =>
                        updateTheme("backgroundPatternAnimationSeconds", Number(e.target.value))
                      }
                    />
                  </div>
                  <div className="hd-field">
                    <label htmlFor="backgroundPatternAnimationStrength">
                      Movement ({form.theme.backgroundPatternAnimationStrength ?? 24}px)
                    </label>
                    <input
                      id="backgroundPatternAnimationStrength"
                      type="range"
                      min={4}
                      max={100}
                      disabled={
                        !form.theme.backgroundPatternEnabled
                        || !form.theme.backgroundPatternAnimationEnabled
                      }
                      value={form.theme.backgroundPatternAnimationStrength ?? 24}
                      onChange={(e) =>
                        updateTheme("backgroundPatternAnimationStrength", Number(e.target.value))
                      }
                    />
                  </div>
                </div>
                <div className="hd-field">
                  <label htmlFor="backgroundPatternAnimationTravelDirection">Wave direction</label>
                  <select
                    id="backgroundPatternAnimationTravelDirection"
                    value={form.theme.backgroundPatternAnimationTravelDirection || "right"}
                    disabled={
                      !form.theme.backgroundPatternEnabled
                      || !form.theme.backgroundPatternAnimationEnabled
                    }
                    onChange={(e) =>
                      updateTheme(
                        "backgroundPatternAnimationTravelDirection",
                        e.target.value as BackgroundPatternTravelDirection,
                      )
                    }
                  >
                    <option value="right">Right</option>
                    <option value="left">Left</option>
                    <option value="up">Up</option>
                    <option value="down">Down</option>
                    <option value="up-right">Up and right</option>
                    <option value="up-left">Up and left</option>
                    <option value="down-right">Down and right</option>
                    <option value="down-left">Down and left</option>
                  </select>
                </div>
                <div className="hd-field">
                  <label htmlFor="backgroundPatternAnimationDirection">Direction</label>
                  <select
                    id="backgroundPatternAnimationDirection"
                    value={form.theme.backgroundPatternAnimationDirection || "normal"}
                    disabled={
                      !form.theme.backgroundPatternEnabled
                      || !form.theme.backgroundPatternAnimationEnabled
                    }
                    onChange={(e) =>
                      updateTheme(
                        "backgroundPatternAnimationDirection",
                        e.target.value as "normal" | "reverse" | "alternate",
                      )
                    }
                  >
                    <option value="normal">Forward</option>
                    <option value="reverse">Reverse</option>
                    <option value="alternate">Alternate</option>
                  </select>
                </div>
              </article>
              <article className="hd-panel-card">
                <header>
                  <h2>Grid</h2>
                  <p>Column counts for each device layout — used by Edit layout and the dashboard board.</p>
                </header>
                <div className="hd-grid-presets" role="group" aria-label="Grid presets">
                  <button
                    type="button"
                    className="hd-grid-presets__btn"
                    onClick={() =>
                      applyGridPreset({ xxl: 6, xl: 5, lg: 4, md: 2, sm: 1 })
                    }
                  >
                    Compact
                  </button>
                  <button
                    type="button"
                    className="hd-grid-presets__btn"
                    onClick={() => applyGridPreset({ ...DEFAULT_COLS })}
                  >
                    Default
                  </button>
                  <button
                    type="button"
                    className="hd-grid-presets__btn"
                    onClick={() =>
                      applyGridPreset({ xxl: 12, xl: 8, lg: 8, md: 3, sm: 1 })
                    }
                  >
                    Roomy
                  </button>
                </div>
                <div className="hd-grid-cols">
                  {BREAKPOINT_ORDER.map((bp) => {
                    const cols = resolveGridCols(form.gridCols);
                    const value = cols[bp];
                    const { min, max } = GRID_COLS_LIMITS[bp];
                    return (
                      <div key={bp} className="hd-grid-cols__row">
                        <div className="hd-grid-cols__meta">
                          <div className="hd-grid-cols__title">{BREAKPOINT_LABELS[bp]}</div>
                          <div className="hd-grid-cols__hint">{BREAKPOINT_HINTS[bp]}</div>
                        </div>
                        <div className="hd-grid-cols__controls">
                          <button
                            type="button"
                            className="hd-grid-cols__step"
                            aria-label={`Fewer columns for ${BREAKPOINT_LABELS[bp]}`}
                            disabled={value <= min}
                            onClick={() => updateGridCol(bp, value - 1)}
                          >
                            −
                          </button>
                          <input
                            className="hd-grid-cols__value"
                            type="number"
                            min={min}
                            max={max}
                            value={value}
                            aria-label={`${BREAKPOINT_LABELS[bp]} columns`}
                            onChange={(e) => updateGridCol(bp, Number(e.target.value))}
                          />
                          <button
                            type="button"
                            className="hd-grid-cols__step"
                            aria-label={`More columns for ${BREAKPOINT_LABELS[bp]}`}
                            disabled={value >= max}
                            onClick={() => updateGridCol(bp, value + 1)}
                          >
                            +
                          </button>
                        </div>
                        <div
                          className="hd-grid-cols__preview"
                          style={{ "--hd-preview-cols": value } as CSSProperties}
                          aria-hidden
                        >
                          {Array.from({ length: value }, (_, i) => (
                            <span key={i} className="hd-grid-cols__preview-cell" />
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
                <p className="hd-grid-cols__note">
                  Changing columns rescales saved layouts on the next load. Re-check Edit layout after saving.
                </p>
              </article>
            </SettingsCardGridSection>
          ) : null}

          {panel === "search" ? (
            <SettingsCardGridSection
              panelId="search"
              editMode={settingsCardEditMode}
              saveToken={settingsCardSaveToken}
              cancelToken={settingsCardCancelToken}
              onSaved={() => setSettingsCardEditMode(false)}
              onCancelled={() => setSettingsCardEditMode(false)}
            >
              <article className="hd-panel-card">
                <header className="hd-panel-card__row">
                  <div>
                    <h2>Popup surface</h2>
                    <p>Size, color, glass, border, corners, and depth.</p>
                  </div>
                  <button
                    className="hd-btn"
                    type="button"
                    onClick={() => updateTheme("search", { ...DEFAULT_SEARCH_SETTINGS })}
                  >
                    Reset
                  </button>
                </header>
                <ColorField
                  id="searchPopupBackground"
                  label="Popup background"
                  value={searchAppearance.popupBackground}
                  onChange={(value) => updateSearch("popupBackground", value)}
                />
                <div className="hd-field">
                  <label htmlFor="searchPopupOpacity">
                    Popup opacity ({Math.round(searchAppearance.popupOpacity * 100)}%)
                  </label>
                  <input
                    id="searchPopupOpacity"
                    type="range"
                    min="20"
                    max="100"
                    value={Math.round(searchAppearance.popupOpacity * 100)}
                    onChange={(e) => updateSearch("popupOpacity", Number(e.target.value) / 100)}
                  />
                </div>
                <div className="hd-field-row">
                  <div className="hd-field">
                    <label htmlFor="searchPopupBlur">Popup blur ({searchAppearance.popupBlur}px)</label>
                    <input
                      id="searchPopupBlur"
                      type="range"
                      min="0"
                      max="40"
                      value={searchAppearance.popupBlur}
                      onChange={(e) => updateSearch("popupBlur", Number(e.target.value))}
                    />
                  </div>
                  <div className="hd-field">
                    <label htmlFor="searchWidth">Width ({searchAppearance.width}px)</label>
                    <input
                      id="searchWidth"
                      type="range"
                      min="440"
                      max="920"
                      step="10"
                      value={searchAppearance.width}
                      onChange={(e) => updateSearch("width", Number(e.target.value))}
                    />
                  </div>
                </div>
                <ColorField
                  id="searchBorderColor"
                  label="Border color"
                  value={searchAppearance.borderColor}
                  onChange={(value) => updateSearch("borderColor", value)}
                />
                <div className="hd-field-row">
                  <div className="hd-field">
                    <label htmlFor="searchBorderWidth">Border ({searchAppearance.borderWidth}px)</label>
                    <input
                      id="searchBorderWidth"
                      type="range"
                      min="0"
                      max="4"
                      value={searchAppearance.borderWidth}
                      onChange={(e) => updateSearch("borderWidth", Number(e.target.value))}
                    />
                  </div>
                  <div className="hd-field">
                    <label htmlFor="searchRadius">Corners ({searchAppearance.radius}px)</label>
                    <input
                      id="searchRadius"
                      type="range"
                      min="0"
                      max="40"
                      value={searchAppearance.radius}
                      onChange={(e) => updateSearch("radius", Number(e.target.value))}
                    />
                  </div>
                </div>
                <div className="hd-field">
                  <label htmlFor="searchShadow">Shadow</label>
                  <select
                    id="searchShadow"
                    value={searchAppearance.shadow}
                    onChange={(e) => updateSearch("shadow", e.target.value as SearchShadowStyle)}
                  >
                    <option value="none">None</option>
                    <option value="soft">Soft</option>
                    <option value="strong">Strong</option>
                  </select>
                </div>
              </article>

              <article className="hd-panel-card">
                <header>
                  <h2>Backdrop</h2>
                  <p>Control the layer behind the popup and how much of the dashboard remains visible.</p>
                </header>
                <ColorField
                  id="searchBackdropBackground"
                  label="Backdrop color"
                  value={searchAppearance.backdropBackground}
                  onChange={(value) => updateSearch("backdropBackground", value)}
                />
                <div className="hd-field">
                  <label htmlFor="searchBackdropOpacity">
                    Backdrop opacity ({Math.round(searchAppearance.backdropOpacity * 100)}%)
                  </label>
                  <input
                    id="searchBackdropOpacity"
                    type="range"
                    min="0"
                    max="100"
                    value={Math.round(searchAppearance.backdropOpacity * 100)}
                    onChange={(e) => updateSearch("backdropOpacity", Number(e.target.value) / 100)}
                  />
                </div>
                <div className="hd-field">
                  <label htmlFor="searchBackdropBlur">Backdrop blur ({searchAppearance.backdropBlur}px)</label>
                  <input
                    id="searchBackdropBlur"
                    type="range"
                    min="0"
                    max="40"
                    value={searchAppearance.backdropBlur}
                    onChange={(e) => updateSearch("backdropBlur", Number(e.target.value))}
                  />
                </div>
              </article>

              <article className="hd-panel-card">
                <header>
                  <h2>Results layout</h2>
                  <p>Choose information density and how many matches are shown.</p>
                </header>
                <div className="hd-field">
                  <label htmlFor="searchDensity">Row spacing</label>
                  <select
                    id="searchDensity"
                    value={searchAppearance.resultDensity}
                    onChange={(e) => updateSearch("resultDensity", e.target.value as SearchResultDensity)}
                  >
                    <option value="compact">Compact</option>
                    <option value="comfortable">Comfortable</option>
                    <option value="roomy">Roomy</option>
                  </select>
                </div>
                <div className="hd-field">
                  <label htmlFor="searchMaxResults">Maximum results ({searchAppearance.maxResults})</label>
                  <input
                    id="searchMaxResults"
                    type="range"
                    min="3"
                    max="15"
                    value={searchAppearance.maxResults}
                    onChange={(e) => updateSearch("maxResults", Number(e.target.value))}
                  />
                </div>
              </article>

              <article className="hd-panel-card">
                <header>
                  <h2>Visible content</h2>
                  <p>Show only the interface details that are useful to you.</p>
                </header>
                <div className="hd-search-visibility">
                  {([
                    ["showResultHeader", "Results heading", "Quick access or matching results label"],
                    ["showResultCount", "Result count", "Number shown beside the results heading"],
                    ["showIcons", "Result icons", "Dashboard, widget, bookmark, and link symbols"],
                    ["showDescriptions", "Descriptions", "Dashboard name, category, or destination"],
                    ["showResultTypes", "Type badges", "Dashboard, Widget, Bookmark, or Quick link"],
                    ["showWebSearch", "Web search", "Internet-search action in the main field"],
                    ["showKeyboardHints", "Keyboard hints", "Navigation shortcuts at the bottom"],
                  ] as const).map(([key, label, hint]) => (
                    <label className="hd-toggle" key={key}>
                      <input
                        type="checkbox"
                        checked={searchAppearance[key]}
                        onChange={(e) => updateSearch(key, e.target.checked)}
                      />
                      <span>
                        <strong>{label}</strong>
                        <span>{hint}</span>
                      </span>
                    </label>
                  ))}
                </div>
              </article>
            </SettingsCardGridSection>
          ) : null}

          {panel === "bookmarks" ? (
            <section className="hd-panel-grid hd-panel-grid--single">
              <BookmarksEditor
                bookmarks={form.bookmarks || []}
                groups={form.bookmarkGroups || []}
                onChangeBookmarks={(next) => update("bookmarks", next)}
                onChangeGroups={(next) => update("bookmarkGroups", next)}
                onPickIcon={(bookmarkId) => openIconPicker({ kind: "bookmark", id: bookmarkId })}
                onUploadIcon={uploadBookmarkIcon}
                iconAssignment={bookmarkIconAssignment}
                onIconAssignmentConsumed={() => setBookmarkIconAssignment(null)}
                query={bookmarkQuery}
                formOpen={bookmarkFormOpen}
                onFormOpenChange={setBookmarkFormOpen}
                addToken={bookmarkAddToken}
              />
            </section>
          ) : null}

          {panel === "tabs" ? (
            <section className="hd-tabs-studio">
              {hasAccess("layout.manage") ? (
                <>
              <article className="hd-panel-card hd-tabs-studio__tab-list">
                <header className="hd-panel-card__row">
                  <div>
                    <h2>Dashboard tabs</h2>
                    <p>Matched to your Homepage Network → Demo layout. Rename, reorder, or add pages.</p>
                  </div>
                  <button className="hd-btn hd-btn--primary" type="button" onClick={addTab}>
                    Add tab
                  </button>
                </header>
                <div className="hd-tab-list">
                  {allEditableTabs.map((tab, index) => {
                    const isPrivate = privateTabs.some((item) => item.id === tab.id);
                    return (
                    <button
                      key={tab.id}
                      type="button"
                      className={`hd-tab-list__item${selectedTab?.id === tab.id ? " is-active" : ""}`}
                      onClick={() => setSelectedTabId(tab.id)}
                    >
                      <span className="hd-tab-list__index">{index + 1}</span>
                      <span className="hd-tab-list__meta">
                        <strong>
                          {tab.name}
                          {isPrivate ? <span className="hd-tab-private-badge">Private</span> : null}
                        </strong>
                        <em>{tab.widgetIds.length} widgets · /t/{tab.id}{isPrivate ? " · visible to you and administrators" : ""}</em>
                      </span>
                    </button>
                    );
                  })}
                </div>
              </article>

              {selectedTab ? (
                <article className="hd-panel-card hd-tabs-studio__editor">
                  <header>
                    <h2>Edit “{selectedTab.name}”</h2>
                    <p>
                      {selectedTabIsPrivate
                        ? "Private to your profile. Configure this tab and choose which widgets appear on it."
                        : "Shared dashboard tab. Configure it and choose which widgets appear on it."}
                    </p>
                  </header>
                  <div className="hd-field">
                    <label htmlFor="tabName">Tab name</label>
                    <input
                      id="tabName"
                      type="text"
                      value={selectedTab.name}
                      onChange={(e) => renameTab(selectedTab.id, e.target.value)}
                    />
                  </div>
                  <div className="hd-tab-visibility">
                    <div className="hd-tab-visibility__head">
                      <strong>Device visibility</strong>
                      <span>Show or hide this tab (and its widgets) per screen size.</span>
                    </div>
                    <div className="hd-tab-visibility__grid">
                      {BREAKPOINT_ORDER.map((bp) => {
                        const visible = selectedTab.deviceVisibility?.[bp] !== false;
                        return (
                          <div key={bp} className="hd-tab-visibility__row">
                            <div className="hd-tab-visibility__label">
                              <strong>{BREAKPOINT_LABELS[bp]}</strong>
                              <em>{BREAKPOINT_HINTS[bp]}</em>
                            </div>
                            <div className="hd-tab-visibility__toggle" role="group" aria-label={`${BREAKPOINT_LABELS[bp]} visibility`}>
                              <button
                                type="button"
                                className={`hd-tab-visibility__btn${visible ? " is-active" : ""}`}
                                onClick={() => setTabDeviceVisibility(selectedTab.id, bp, true)}
                              >
                                Show
                              </button>
                              <button
                                type="button"
                                className={`hd-tab-visibility__btn${!visible ? " is-active is-hide" : ""}`}
                                onClick={() => setTabDeviceVisibility(selectedTab.id, bp, false)}
                              >
                                Hide
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  <div className="hd-tab-toolbar">
                    <button className="hd-btn" type="button" onClick={() => moveTab(selectedTab.id, -1)}>
                      Move up
                    </button>
                    <button className="hd-btn" type="button" onClick={() => moveTab(selectedTab.id, 1)}>
                      Move down
                    </button>
                    <button className="hd-btn" type="button" onClick={() => removeTab(selectedTab.id)}>
                      Delete tab
                    </button>
                    <button
                      className="hd-btn"
                      type="button"
                      title="Resize and reposition this tab's widget cards"
                      onClick={() => setLayoutEditorTabId(selectedTab.id)}
                    >
                      Edit Layout
                    </button>
                    {accessRole === "admin" && !selectedTabIsPrivate ? (
                      <button
                        className="hd-btn hd-btn--primary"
                        type="button"
                        disabled={saving || form.tabs.length <= 1}
                        title={form.tabs.length <= 1 ? "Keep at least one shared dashboard tab" : "Only you and administrators will see this tab"}
                        onClick={() => void makeTabPrivate(selectedTab)}
                      >
                        Make private to my profile
                      </button>
                    ) : null}
                    {selectedTabIsPrivate ? (
                      <button
                        className="hd-btn hd-btn--primary"
                        type="button"
                        disabled={saving}
                        onClick={() => void makeTabShared(selectedTab)}
                      >
                        Make shared
                      </button>
                    ) : null}
                  </div>
                  <div className="hd-widget-assign">
                    {categorized.map(([category, items]) => (
                      <div key={category} className="hd-widget-assign__group">
                        <div className="hd-widget-assign__title">{category}</div>
                        <div className="hd-widget-assign__grid">
                          {items.map((widget) => {
                            const onTab = selectedTab.widgetIds.includes(widget.id);
                            return (
                              <label key={widget.id} className={`hd-assign-chip${onTab ? " is-on" : ""}`}>
                                <input
                                  type="checkbox"
                                  checked={onTab}
                                  onChange={() => toggleWidgetOnTab(widget.id)}
                                />
                                <span>
                                  <strong>{widget.name}</strong>
                                  <em>{widget.id}</em>
                                </span>
                              </label>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                </article>
              ) : null}
                </>
              ) : null}
            </section>
          ) : null}

          {panel === "widgets" ? (
            <section className="hd-widgets-studio">
              <div className="hd-widget-cards">
                {filteredWidgets.flatMap(([category, items]) =>
                  items.flatMap((widget) => {
                    const enabled = form.enabledWidgets.includes(widget.id);
                    const multi = isMultiInstanceWidget(widget.id);
                    const instances = multi
                      ? instancesForWidget(form.widgetInstances || [], widget.id)
                      : [];
                    const cards =
                      multi && instances.length > 0
                        ? instances
                        : [
                            {
                              id: widget.id,
                              widgetId: widget.id,
                              key: "default",
                              label: widget.name,
                            },
                          ];

                    return cards.map((inst) => {
                      const isMultiCard = multi && instances.length > 0;
                      const onTabs = form.tabs
                        .filter((t) =>
                          t.widgetIds.some((entry) => {
                            if (isMultiCard) return entry === inst.id || entry === widget.id;
                            return parseInstanceId(entry).widgetId === widget.id;
                          }),
                        )
                        .map((t) => t.name);
                      const placement = onTabs.length ? onTabs.join(", ") : "Unassigned";
                      const canRemove = isMultiCard && instances.length > 1;
                      const iconId = isMultiCard ? inst.id : widget.id;
                      const storedIcon = form.widgetIcons?.[iconId] || "";
                      const resolvedIcon =
                        storedIcon ||
                        (isMultiCard ? form.widgetIcons?.[widget.id] || "" : "") ||
                        "";

                      return (
                        <article
                          key={inst.id}
                          className={`hd-widget-card hd-widget-card--compact${enabled ? " is-enabled" : ""}${
                            isMultiCard ? " hd-widget-card--server" : ""
                          }`}
                        >
                          <header className="hd-widget-card__head">
                            <WidgetBrandMark
                              widgetId={widget.id}
                              name={widget.name}
                              iconUrl={resolvedIcon}
                            />
                            <div className="hd-widget-card__title">
                              <strong>{isMultiCard ? inst.label || widget.name : widget.name}</strong>
                              <div className="hd-widget-card__identity">
                                {isMultiCard ? (
                                  <span className="hd-widget-card__package">{widget.name}</span>
                                ) : null}
                                <span className="hd-widget-card__cat">{category}</span>
                              </div>
                            </div>
                            <label
                              className="hd-switch"
                              title={enabled ? "Enabled" : "Disabled"}
                              onClick={(e) => e.stopPropagation()}
                            >
                              <input
                                type="checkbox"
                                checked={enabled}
                                onChange={() => toggleWidgetEnabled(widget.id)}
                              />
                              <span />
                            </label>
                          </header>

                          <p className="hd-widget-card__desc">{widget.description}</p>

                          <div className="hd-widget-card__chips">
                            <span className="hd-chip" title={inst.id}>
                              {inst.id}
                            </span>
                            <span
                              className={`hd-chip${onTabs.length ? "" : " hd-chip--muted"}`}
                              title={placement}
                            >
                              {placement}
                            </span>
                          </div>

                          <div className="hd-widget-card__actions">
                            {canRemove ? (
                              <button
                                className="hd-btn hd-btn--sm hd-chip--danger"
                                type="button"
                                onClick={() => removeServerInstance(inst.id)}
                              >
                                Remove
                              </button>
                            ) : (
                              <span />
                            )}
                            <button
                              className="hd-btn hd-btn--sm hd-btn--primary"
                              type="button"
                              onClick={() => setSettingsModalId(inst.id)}
                            >
                              Configure
                            </button>
                          </div>
                        </article>
                      );
                    });
                  }),
                )}
              </div>

              {settingsModalTarget ? (
                <WidgetSettingsModal
                  widget={settingsModalTarget.widget}
                  instance={settingsModalTarget.instance}
                  isMultiCard={settingsModalTarget.isMultiCard}
                  canRemove={settingsModalTarget.canRemove}
                  bookmarkGroups={form.bookmarkGroups || []}
                  config={widgetConfigs[settingsModalTarget.instance.id] || {}}
                  showIcon={settingsModalTarget.showIcon}
                  showTitle={settingsModalTarget.showTitle}
                  expand={settingsModalTarget.expand}
                  accentMode={settingsModalTarget.accentMode}
                  accentColor={settingsModalTarget.accentColor}
                  storedIcon={settingsModalTarget.storedIcon}
                  defaultIcon={settingsModalTarget.defaultIcon}
                  brandMark={
                    <WidgetBrandMark
                      widgetId={settingsModalTarget.widget.id}
                      name={settingsModalTarget.widget.name}
                      iconUrl={settingsModalTarget.resolvedIcon}
                      size="lg"
                    />
                  }
                  escapeDisabled={Boolean(iconPickerFor)}
                  onClose={() => setSettingsModalId(null)}
                  onRename={(label) => renameServerInstance(settingsModalTarget.instance.id, label)}
                  onUpdateField={(key, value) =>
                    updateWidgetField(settingsModalTarget.instance.id, key, value)
                  }
                  onPatchConfig={(patch) => {
                    const id = settingsModalTarget.instance.id;
                    setWidgetConfigs((prev) => ({
                      ...prev,
                      [id]: {
                        ...(prev[id] || {}),
                        ...patch,
                      },
                    }));
                  }}
                  onUpdateChrome={(patch) =>
                    updateWidgetChrome(
                      settingsModalTarget.iconId,
                      patch,
                      settingsModalTarget.chrome,
                    )
                  }
                  onUpdateAccent={(mode, color) =>
                    updateWidgetAccent(settingsModalTarget.accentId, mode, color)
                  }
                  onUpdateIcon={(url) => updateWidgetIcon(settingsModalTarget.iconId, url)}
                  onUploaded={setMessage}
                  onBrowseIcon={() => {
                    const config = widgetConfigs[settingsModalTarget.instance.id] || {};
                    if (settingsModalTarget.widget.id === "ai-chat") {
                      const provider = config.provider || "openai";
                      openIconPicker(
                        { kind: "ai-provider", id: settingsModalTarget.instance.id, provider },
                        provider === "openai" ? "openai" : provider,
                      );
                      return;
                    }
                    const fromDefault =
                      (iconForWidget(settingsModalTarget.widget.id) || "")
                        .split("/")
                        .pop()
                        ?.replace(/\.(svg|png|webp|jpg|jpeg|gif|ico)$/i, "") || "";
                    const seed =
                      fromDefault && !fromDefault.includes("homepage") ? fromDefault : "";
                    openIconPicker({ kind: "widget", id: settingsModalTarget.iconId }, seed);
                  }}
                  onRemove={() => removeServerInstance(settingsModalTarget.instance.id)}
                />
              ) : null}
            </section>
          ) : null}

          {panel === "admin" ? (
            <div className="hd-admin-wrap">
              <AdminBackupPanel />
            </div>
          ) : null}

          {panel === "manager" ? (
            <WidgetManager
              defaultLogo={form.logoUrl}
              widgetIcons={form.widgetIcons}
              onWidgetIconChange={updateWidgetIcon}
            />
          ) : null}

          {panel === "system" ? <SystemUpdatePanel /> : null}
        </div>
      </div>

      {layoutEditorTabId && typeof document !== "undefined"
        ? createPortal(
            (() => {
              const editorTab = allEditableTabs.find((t) => t.id === layoutEditorTabId);
              if (!editorTab) return null;
              const editorIsPersonal = privateTabs.some((t) => t.id === editorTab.id);
              return (
                <EditTabLayoutModal
                  settings={form}
                  tab={editorTab}
                  isPersonalTab={editorIsPersonal}
                  onClose={() => setLayoutEditorTabId(null)}
                />
              );
            })(),
            document.body,
          )
        : null}
    </form>
  );
}
