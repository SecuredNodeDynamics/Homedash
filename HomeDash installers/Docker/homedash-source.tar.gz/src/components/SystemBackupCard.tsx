"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";

function downloadJson(filename: string, data: unknown) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/**
 * Single-card, one-click full system backup + restore.
 * Complements the more granular "Full config backup" / "Import & restore"
 * cards above with a quick save-and-go path for the whole system.
 */
export function SystemBackupCard() {
  const router = useRouter();
  const fileRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [pending, setPending] = useState<{ filename: string; raw: string } | null>(null);

  function clearFlash() {
    setMessage("");
    setError("");
  }

  async function runBackup() {
    clearFlash();
    setBusy("backup");
    try {
      const res = await fetch("/api/admin/backup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kind: "full", save: true, download: true }),
      });
      const json = (await res.json().catch(() => ({}))) as {
        error?: string;
        filename?: string;
        backup?: unknown;
      };
      if (!res.ok) throw new Error(json.error || "Backup failed");
      if (json.backup) downloadJson(json.filename || "homedash-system-backup.json", json.backup);
      setMessage(`Backed up and exported ${json.filename || "system backup"}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Backup failed");
    } finally {
      setBusy(null);
    }
  }

  function onPickFile(file: File | null) {
    clearFlash();
    setPending(null);
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const raw = String(reader.result || "");
        const parsed = JSON.parse(raw);
        if (!parsed || typeof parsed !== "object") throw new Error("Invalid file");
        setPending({ filename: file.name, raw });
      } catch {
        setError("Could not read that backup file (need a Homedash JSON export)");
      }
    };
    reader.readAsText(file);
  }

  async function runRestore() {
    if (!pending) return;
    if (
      !window.confirm(
        "Restore the full system backup? Settings, page layouts, and widget credentials will be overwritten.",
      )
    ) {
      return;
    }
    clearFlash();
    setBusy("restore");
    try {
      const res = await fetch("/api/admin/backup/restore", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          backup: pending.raw,
          parts: { settings: true, layouts: true, widgets: true },
        }),
      });
      const json = (await res.json().catch(() => ({}))) as {
        error?: string;
        result?: { settings: boolean; layouts: number; widgets: number };
      };
      if (!res.ok) throw new Error(json.error || "Restore failed");
      const r = json.result;
      setMessage(
        `Restored${r?.settings ? " settings" : ""}${r?.layouts ? ` · ${r.layouts} layouts` : ""}${
          r?.widgets ? ` · ${r.widgets} widgets` : ""
        }`,
      );
      setPending(null);
      if (fileRef.current) fileRef.current.value = "";
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Restore failed");
    } finally {
      setBusy(null);
    }
  }

  return (
    <article className="hd-panel-card hd-admin__card">
      <header>
        <h2>System backup &amp; restore</h2>
        <p>One click to snapshot everything — settings, layouts, and widget credentials — or restore from a file.</p>
      </header>
      <div className="hd-admin__card-body">
        {message || error ? (
          <div className={`hd-admin__flash${error ? " hd-admin__flash--error" : ""}`} role="status">
            {error || message}
          </div>
        ) : null}
        <input
          ref={fileRef}
          className="hd-admin__file-input"
          type="file"
          accept="application/json,.json"
          onChange={(e) => onPickFile(e.target.files?.[0] || null)}
        />
        <button
          className={`hd-admin__dropzone${pending ? " is-filled" : ""}`}
          type="button"
          onClick={() => fileRef.current?.click()}
        >
          {pending ? (
            <>
              <strong>{pending.filename}</strong>
              <span>Ready to restore</span>
            </>
          ) : (
            <>
              <strong>Choose backup JSON</strong>
              <span>Click to browse · restores the whole system</span>
            </>
          )}
        </button>
      </div>
      <div className="hd-admin__actions">
        <button
          className="hd-btn hd-btn--primary"
          type="button"
          disabled={Boolean(busy)}
          onClick={() => void runBackup()}
        >
          {busy === "backup" ? "Backing up…" : "Back up system now"}
        </button>
        <button
          className="hd-btn"
          type="button"
          disabled={Boolean(busy) || !pending}
          onClick={() => void runRestore()}
        >
          {busy === "restore" ? "Restoring…" : "Restore from file"}
        </button>
      </div>
    </article>
  );
}
