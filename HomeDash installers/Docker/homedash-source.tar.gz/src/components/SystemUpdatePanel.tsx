"use client";

import { useEffect, useRef, useState } from "react";
import type { WidgetAgentJob } from "@/lib/widget-agent";

type SystemStatus = {
  version: string;
  agent: { ok: boolean; version: number; error?: string };
};

const ACTIVE_UPDATE_KEY = "homedash.system-update.active-job";

export function SystemUpdatePanel() {
  const fileRef = useRef<HTMLInputElement>(null);
  const [status, setStatus] = useState<SystemStatus | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [confirmed, setConfirmed] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");
  const [job, setJob] = useState<WidgetAgentJob | null>(null);
  const active = !!job && !["complete", "failed"].includes(job.status);
  const [reloadState, setReloadState] = useState<"idle" | "waiting" | "stalled">("idle");
  const reloadStartedRef = useRef(false);
  const jobLogRef = useRef<HTMLPreElement>(null);
  const jobLogPinnedRef = useRef(true);
  const lastJobIdRef = useRef<string | null>(null);
  const [copyState, setCopyState] = useState<"idle" | "copied" | "error">("idle");
  const copyResetRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Keep the update log scrolled to the latest line as it streams in, unless
  // the user has manually scrolled up to read earlier output — in which
  // case leave the scroll position alone so we don't yank them back down.
  useEffect(() => {
    const node = jobLogRef.current;
    if (!node || !jobLogPinnedRef.current) return;
    node.scrollTop = node.scrollHeight;
  }, [job?.log]);

  // A brand-new job (applied/recovered) should always start pinned to the
  // bottom — otherwise a scroll-up from a previous job would silently
  // suppress auto-scroll forever, with no way to tell why.
  useEffect(() => {
    if (job && job.id !== lastJobIdRef.current) {
      lastJobIdRef.current = job.id;
      jobLogPinnedRef.current = true;
      const node = jobLogRef.current;
      if (node) node.scrollTop = node.scrollHeight;
    }
  }, [job?.id]);

  async function copyJobLog() {
    const text = job?.log?.length ? job.log.join("\n") : "";
    if (!text) return;
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(text);
      } else {
        // Fallback for browsers/contexts without the async Clipboard API.
        const textarea = document.createElement("textarea");
        textarea.value = text;
        textarea.style.position = "fixed";
        textarea.style.opacity = "0";
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand("copy");
        document.body.removeChild(textarea);
      }
      setCopyState("copied");
    } catch {
      setCopyState("error");
    } finally {
      if (copyResetRef.current) clearTimeout(copyResetRef.current);
      copyResetRef.current = setTimeout(() => setCopyState("idle"), 2000);
    }
  }

  useEffect(() => {
    return () => {
      if (copyResetRef.current) clearTimeout(copyResetRef.current);
    };
  }, []);

  async function loadStatus() {
    const response = await fetch("/api/admin/system/status", { cache: "no-store" });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(body.error || "Could not load system status");
    setStatus(body as SystemStatus);
  }

  async function recoverJob() {
    const saved = window.localStorage.getItem(ACTIVE_UPDATE_KEY);
    const path = saved
      ? `/api/admin/widgets/jobs/${encodeURIComponent(saved)}`
      : "/api/admin/widgets/jobs/active";
    try {
      const response = await fetch(path, { cache: "no-store" });
      const body = await response.json().catch(() => ({}));
      const recovered = body.job as WidgetAgentJob | null;
      if (response.ok && recovered?.operation === "system-update") {
        setJob(recovered);
        if (!["complete", "failed"].includes(recovered.status)) {
          window.localStorage.setItem(ACTIVE_UPDATE_KEY, recovered.id);
        } else {
          window.localStorage.removeItem(ACTIVE_UPDATE_KEY);
        }
      } else if (saved) {
        window.localStorage.removeItem(ACTIVE_UPDATE_KEY);
      }
    } catch {
      // The dashboard is temporarily unavailable while its container restarts.
    }
  }

  useEffect(() => {
    void loadStatus().catch((nextError) => setError(nextError instanceof Error ? nextError.message : "Could not load system status"));
    void recoverJob();
  }, []);

  useEffect(() => {
    if (!active || !job) return;
    let stopped = false;
    let timer: ReturnType<typeof setTimeout>;
    const poll = async () => {
      try {
        const response = await fetch(`/api/admin/widgets/jobs/${encodeURIComponent(job.id)}`, { cache: "no-store" });
        const body = await response.json().catch(() => ({}));
        if (response.ok && body.job && !stopped) {
          const next = body.job as WidgetAgentJob;
          setJob(next);
          if (["complete", "failed"].includes(next.status)) {
            window.localStorage.removeItem(ACTIVE_UPDATE_KEY);
            void loadStatus().catch(() => undefined);
            return;
          }
        }
      } catch {
        // Expected while docker compose replaces the Homedash container.
      }
      if (!stopped) timer = setTimeout(poll, 2200);
    };
    timer = setTimeout(poll, 1200);
    return () => {
      stopped = true;
      clearTimeout(timer);
    };
  }, [active, job?.id]);

  // `docker compose up -d` has already returned by the time the job reports
  // "complete", but the new container still needs a moment to finish booting
  // Next.js. This page's already-loaded JS/CSS is from the old version, so
  // without a hard reload the user only ever sees the update land once they
  // manually refresh (or close/reopen the app wrapping this page). Poll the
  // status endpoint until the freshly-restarted server answers, then reload.
  useEffect(() => {
    if (job?.status !== "complete" || reloadStartedRef.current) return;
    reloadStartedRef.current = true;
    setReloadState("waiting");
    let stopped = false;
    const maxAttempts = 60;
    let attempt = 0;

    const poll = async () => {
      attempt += 1;
      try {
        const response = await fetch("/api/admin/system/status", { cache: "no-store" });
        if (response.ok && !stopped) {
          // Give the server a beat to finish serving its new static assets
          // before we reload against it.
          await new Promise((resolve) => setTimeout(resolve, 500));
          if (!stopped) window.location.reload();
          return;
        }
      } catch {
        // Expected while docker compose swaps the container.
      }
      if (stopped) return;
      if (attempt >= maxAttempts) {
        setReloadState("stalled");
        return;
      }
      setTimeout(poll, 1500);
    };

    const initialDelay = setTimeout(poll, 1500);
    return () => {
      stopped = true;
      clearTimeout(initialDelay);
    };
  }, [job?.status]);

  async function applyUpdate() {
    if (!file || !confirmed || active) return;
    setUploading(true);
    setError("");
    try {
      const data = new FormData();
      data.set("package", file);
      data.set("confirm", "true");
      const response = await fetch("/api/admin/system/update", { method: "POST", body: data });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error || `Update upload failed (HTTP ${response.status})`);
      const next = body.job as WidgetAgentJob;
      setJob(next);
      window.localStorage.setItem(ACTIVE_UPDATE_KEY, next.id);
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Could not apply update");
    } finally {
      setUploading(false);
    }
  }

  const agentReady = Boolean(status?.agent.ok && status.agent.version >= 3);
  return (
    <div className="hd-system-update">
      <section className="hd-panel-card hd-system-update__summary">
        <div>
          <div className="hd-settings__kicker">Dashboard updates</div>
          <h2>System update</h2>
          <p>Install verified Homedash application updates without replacing persistent configuration or credentials.</p>
        </div>
        <div className={`hd-system-update__agent${agentReady ? " is-ready" : " is-error"}`}>
          <span aria-hidden="true">{agentReady ? "✓" : "!"}</span>
          <div>
            <strong>{agentReady ? "Update service ready" : "Update service needs attention"}</strong>
            <small>
              {status?.agent.ok
                ? `Homedash ${status.version} · host agent v${status.agent.version}`
                : status?.agent.error || "Checking host update service…"}
            </small>
          </div>
        </div>
      </section>

      {job ? (
        <section className={`hd-panel-card hd-system-job is-${job.status}`}>
          <header>
            <div>
              <div className="hd-settings__kicker">Update job</div>
              <h2>{job.message}</h2>
            </div>
            <span className="hd-system-job__status">{job.status}</span>
          </header>
          <div className="hd-system-job__track"><span /></div>
          <details
            open={job.status === "failed"}
            onToggle={(event) => {
              if (!event.currentTarget.open) return;
              // Opening the panel mid-job should jump straight to the latest
              // output (tail -f style) instead of stranding the user at
              // whatever was logged before they expanded it.
              jobLogPinnedRef.current = true;
              const node = jobLogRef.current;
              if (node) node.scrollTop = node.scrollHeight;
            }}
          >
            <summary>
              <span className="hd-btn hd-system-job__logtoggle">View log</span>
              <button
                type="button"
                className="hd-btn hd-system-job__copy"
                disabled={!job.log?.length}
                onClick={(event) => {
                  // Keep this click from bubbling to <summary>, which would
                  // otherwise toggle the details open/closed on every copy.
                  event.preventDefault();
                  event.stopPropagation();
                  void copyJobLog();
                }}
              >
                {copyState === "copied" ? "Copied" : copyState === "error" ? "Copy failed" : "Copy log"}
              </button>
            </summary>
            <pre
              ref={jobLogRef}
              onScroll={(event) => {
                const node = event.currentTarget;
                jobLogPinnedRef.current = node.scrollHeight - node.scrollTop - node.clientHeight < 24;
              }}
            >
              {job.log?.length ? job.log.join("\n") : "Waiting for the host update service…"}
            </pre>
          </details>
          {job.rolledBack ? <div className="hd-system-job__rollback">The previous application version was restored automatically.</div> : null}
          {reloadState === "waiting" ? (
            <div className="hd-system-job__reload">Update installed — reloading the dashboard…</div>
          ) : null}
          {reloadState === "stalled" ? (
            <div className="hd-system-job__reload hd-system-job__reload--stalled">
              Update installed, but the dashboard didn&apos;t come back automatically.{" "}
              <button type="button" className="hd-btn hd-btn--sm" onClick={() => window.location.reload()}>
                Reload now
              </button>
            </div>
          ) : null}
        </section>
      ) : null}

      <section className="hd-panel-card hd-system-update__upload">
        <header>
          <h2>Upload update package</h2>
          <p>Only use <code>.hdupdate</code> files supplied by your Homedash administrator.</p>
        </header>
        <input
          ref={fileRef}
          type="file"
          accept=".hdupdate,application/gzip"
          hidden
          onChange={(event) => {
            setFile(event.target.files?.[0] || null);
            setConfirmed(false);
            setError("");
          }}
        />
        <button type="button" className="hd-system-update__drop" disabled={active || uploading} onClick={() => fileRef.current?.click()}>
          <span>{file ? file.name : "Choose a Homedash update package"}</span>
          <small>{file ? `${(file.size / (1024 * 1024)).toFixed(2)} MB` : ".hdupdate · maximum 100 MB"}</small>
        </button>
        <div className="hd-system-update__preserved">
          <strong>Preserved during every update</strong>
          <span>Users and passwords</span><span>Dashboard settings and layouts</span>
          <span>Widget credentials and API keys</span><span>Uploads, icons, and backups</span>
        </div>
        <label className="hd-system-update__confirm">
          <input type="checkbox" checked={confirmed} disabled={!file || active} onChange={(event) => setConfirmed(event.target.checked)} />
          <span>I understand Homedash will create a source backup, rebuild Docker, and briefly restart the dashboard.</span>
        </label>
        {error ? <div className="hd-modal__error">{error}</div> : null}
        {!agentReady && status ? (
          <div className="hd-system-update__warning">Install host update agent v3 before applying dashboard packages.</div>
        ) : null}
        <div className="hd-system-update__actions">
          <button type="button" className="hd-btn hd-btn--primary" disabled={!file || !confirmed || !agentReady || active || uploading} onClick={() => void applyUpdate()}>
            {uploading ? "Uploading…" : active ? "Update running…" : "Verify and apply update"}
          </button>
        </div>
      </section>
    </div>
  );
}
