"use client";

import { useEffect, useId } from "react";
import { createPortal } from "react-dom";

export function UnsavedChangesDialog({
  open,
  saving = false,
  saveDisabled = false,
  onSave,
  onDiscard,
  onKeepEditing,
}: {
  open: boolean;
  saving?: boolean;
  saveDisabled?: boolean;
  onSave: () => void;
  onDiscard: () => void;
  onKeepEditing: () => void;
}) {
  const titleId = useId();

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        event.stopImmediatePropagation();
        onKeepEditing();
      }
    };
    document.addEventListener("keydown", onKey, true);
    return () => document.removeEventListener("keydown", onKey, true);
  }, [open, onKeepEditing]);

  if (!open || typeof document === "undefined") return null;
  return createPortal(
    <div className="hd-modal-scrim hd-unsaved-scrim" role="presentation" onMouseDown={onKeepEditing}>
      <div
        className="hd-modal hd-unsaved-modal"
        role="alertdialog"
        aria-modal="true"
        aria-labelledby={titleId}
        onMouseDown={(event) => event.stopPropagation()}
      >
        <div className="hd-unsaved-modal__mark" aria-hidden="true">!</div>
        <div className="hd-unsaved-modal__copy">
          <div className="hd-settings__kicker">Unsaved changes</div>
          <h2 id={titleId}>Save your changes?</h2>
          <p>You have changes that have not been saved. Save them now, discard them, or return to editing.</p>
        </div>
        <div className="hd-unsaved-modal__actions">
          <button type="button" className="hd-btn" onClick={onKeepEditing}>Keep editing</button>
          <button type="button" className="hd-btn hd-chip--danger" onClick={onDiscard}>Discard</button>
          <button
            type="button"
            className="hd-btn hd-btn--primary"
            disabled={saving || saveDisabled}
            onClick={onSave}
          >
            {saving ? "Saving…" : "Save changes"}
          </button>
        </div>
      </div>
    </div>,
    document.body,
  );
}
