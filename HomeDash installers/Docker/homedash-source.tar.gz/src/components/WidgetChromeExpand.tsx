"use client";

import {
  BREAKPOINT_LABELS,
  BREAKPOINT_ORDER,
  type Breakpoint,
} from "@/lib/breakpoints";
import type { WidgetChromeSettings } from "@/lib/types";
import {
  isChromeExpandOn,
  normalizeChromeExpand,
  toggleChromeExpandDevice,
  type ChromeExpand,
} from "@/lib/theme";

export function WidgetChromeExpand({
  idPrefix,
  expand,
  onChange,
}: {
  idPrefix: string;
  expand: WidgetChromeSettings["expand"] | undefined;
  onChange: (expand: ChromeExpand | false) => void;
}) {
  const normalized = normalizeChromeExpand(expand);
  const enabled = isChromeExpandOn(normalized);
  const allDevices = normalized === true;
  const selected = new Set(Array.isArray(normalized) ? normalized : []);

  function setMaster(on: boolean) {
    onChange(on ? true : false);
  }

  function setAllDevices() {
    onChange(true);
  }

  function toggleDevice(bp: Breakpoint) {
    if (!enabled) {
      onChange([bp]);
      return;
    }
    if (allDevices) {
      // Leaving "All" starts from every device minus the one clicked.
      const next = BREAKPOINT_ORDER.filter((entry) => entry !== bp);
      onChange(normalizeChromeExpand(next) ?? false);
      return;
    }
    onChange(toggleChromeExpandDevice(normalized, bp) ?? false);
  }

  return (
    <>
      <div
        className="hd-widget-card__chrome-toggle"
        title="Grow or shrink the card so all content is visible without scrolling inside the widget."
      >
        <span className="hd-widget-card__chrome-label" id={`${idPrefix}-chrome-expand`}>
          Expand
        </span>
        <label className="hd-switch" title={enabled ? "On" : "Off"}>
          <input
            type="checkbox"
            checked={enabled}
            aria-labelledby={`${idPrefix}-chrome-expand`}
            onChange={(e) => setMaster(e.target.checked)}
          />
          <span />
        </label>
      </div>

      <div className="hd-widget-card__expand">
        {enabled ? (
          <div
            className="hd-widget-card__expand-devices"
            role="group"
            aria-label="Expand on devices"
          >
            <button
              type="button"
              className={`hd-widget-card__expand-chip${allDevices ? " is-active" : ""}`}
              aria-pressed={allDevices}
              onClick={setAllDevices}
            >
              All
            </button>
            {BREAKPOINT_ORDER.map((bp) => {
              const active = allDevices || selected.has(bp);
              return (
                <button
                  type="button"
                  key={bp}
                  className={`hd-widget-card__expand-chip${active ? " is-active" : ""}`}
                  aria-pressed={active}
                  onClick={() => toggleDevice(bp)}
                >
                  {BREAKPOINT_LABELS[bp]}
                </button>
              );
            })}
          </div>
        ) : null}

        <p className="hd-widget-card__chrome-hint">
          Expand fits the card to its content (including when a widget’s internal tabs change height).
          Choose All devices, or only the sizes where it should apply. Applies in view mode only —
          edit layout keeps your saved grid sizes.
        </p>
      </div>
    </>
  );
}
