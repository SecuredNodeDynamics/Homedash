"use client";

import { useEffect, useId, useState } from "react";
import { useRouter } from "next/navigation";
import type { BookmarkGroup, WidgetChromeSettings, WidgetConfigField, WidgetManifest } from "@/lib/types";
import { fieldsForWidget } from "@/lib/instances";
import { isNodeTitleWidget } from "@/lib/widget-titles";
import { ColorField } from "@/components/ColorField";
import { WidgetChromeExpand } from "@/components/WidgetChromeExpand";
import { ProxmoxConfigEditor } from "@/components/ProxmoxConfigEditor";
import { UnsavedChangesDialog } from "@/components/UnsavedChangesDialog";
import type { ChromeExpand } from "@/lib/theme";

function fieldInputType(field: WidgetConfigField) {
  if (field.type === "password") return "password";
  if (field.type === "number") return "number";
  if (field.type === "url") return "url";
  return "text";
}

function fieldIsMultiline(field: WidgetConfigField) {
  const key = field.key.toLowerCase();
  return key.includes("json") || key.includes("groups") || key.includes("hosts") || key.includes("feeds") || key.includes("cookies");
}

export function WidgetConfigModal({
  instanceId,
  label,
  manifest,
  showIcon,
  showTitle,
  expand,
  onUpdateChrome,
  onClose,
}: {
  instanceId: string;
  label: string;
  manifest: WidgetManifest;
  showIcon: boolean;
  showTitle: boolean;
  expand: WidgetChromeSettings["expand"];
  onUpdateChrome: (patch: Partial<WidgetChromeSettings>) => Promise<boolean> | boolean;
  onClose: () => void;
}) {
  const router = useRouter();
  const titleId = useId();
  const fields = fieldsForWidget(manifest).filter(
    (field) => !(manifest.id === "jellyfin-slider"
      && (field.key === "caseView" || field.key === "musicShelf")),
  );
  const isProxmox = manifest.id === "proxmox-nodes";
  const hasConfigEditor = fields.length > 0 || isProxmox;
  const [values, setValues] = useState<Record<string, string>>({});
  const [initialValues, setInitialValues] = useState<Record<string, string>>({});
  const [bookmarkGroups, setBookmarkGroups] = useState<BookmarkGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [detecting, setDetecting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmClose, setConfirmClose] = useState(false);
  const [chromeDraft, setChromeDraft] = useState<{
    showIcon: boolean;
    showTitle: boolean;
    expand: WidgetChromeSettings["expand"];
  }>({ showIcon, showTitle, expand });
  const [initialChrome, setInitialChrome] = useState({ showIcon, showTitle, expand });

  const updateConfigField = (key: string, value: string) => {
    setValues((prev) => {
      if (manifest.id !== "ai-chat") return { ...prev, [key]: value };
      const provider = prev.provider || "openai";
      if (key === "provider") {
        return {
          ...prev,
          [`${provider}ApiKey`]: prev.apiKey || "",
          [`${provider}Model`]: prev.model || "",
          [`${provider}Enabled`]: prev.enabled || "true",
          provider: value,
          apiKey: prev[`${value}ApiKey`] || "",
          model: prev[`${value}Model`] || "",
          enabled: prev[`${value}Enabled`] || "true",
        };
      }
      if (key === "apiKey" || key === "model" || key === "enabled") {
        return {
          ...prev,
          [key]: value,
          [`${provider}${
            key === "apiKey" ? "ApiKey" : key === "model" ? "Model" : "Enabled"
          }`]: value,
        };
      }
      return { ...prev, [key]: value };
    });
  };

  useEffect(() => {
    setChromeDraft({ showIcon, showTitle, expand });
    setInitialChrome({ showIcon, showTitle, expand });
  }, [showIcon, showTitle, expand, instanceId]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    const load = async () => {
      const configRes = await fetch(`/api/widgets/${encodeURIComponent(instanceId)}/config`);
      if (!configRes.ok) throw new Error("Failed to load config");
      const data = (await configRes.json()) as Record<string, string>;
      if (cancelled) return;
      setValues(data || {});
      setInitialValues(data || {});

      if (manifest.id === "bookmarks") {
        const settingsRes = await fetch("/api/settings");
        if (settingsRes.ok) {
          const settings = (await settingsRes.json()) as { bookmarkGroups?: BookmarkGroup[] };
          if (!cancelled) setBookmarkGroups(settings.bookmarkGroups || []);
        }
      }
    };
    load()
      .catch((err: Error) => {
        if (!cancelled) setError(err.message || "Failed to load config");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [instanceId, manifest.id]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !confirmClose) requestClose();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [confirmClose, values, initialValues, chromeDraft, initialChrome]);

  const dirty = !loading && (
    JSON.stringify(values) !== JSON.stringify(initialValues)
    || JSON.stringify(chromeDraft) !== JSON.stringify(initialChrome)
  );

  function requestClose() {
    if (dirty) setConfirmClose(true);
    else onClose();
  }

  async function onSave(e?: React.FormEvent) {
    e?.preventDefault();
    setSaving(true);
    setError(null);
    try {
      if (hasConfigEditor) {
        const res = await fetch(`/api/widgets/${encodeURIComponent(instanceId)}/config`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(values),
        });
        if (!res.ok) throw new Error("Failed to save credentials");
        window.dispatchEvent(new CustomEvent("homedash:widget-config-saved", {
          detail: { instanceId },
        }));
      }
      const chromeOk = await onUpdateChrome({
        showIcon: chromeDraft.showIcon,
        showTitle: chromeDraft.showTitle,
        expand: chromeDraft.expand ?? false,
      });
      if (!chromeOk) throw new Error("Failed to save appearance");
      if (manifest.id === "bookmarks" || isNodeTitleWidget(manifest.id)) {
        router.refresh();
      }
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save");
    } finally {
      setSaving(false);
    }
  }

  async function detectWeatherLocation() {
    if (typeof window === "undefined" || typeof navigator === "undefined" || !navigator.geolocation) {
      setError("Geolocation is not available in this browser");
      return;
    }
    if (!window.isSecureContext) {
      setError(
        "Browser location needs HTTPS (or localhost). Use a city name like Portland, OR, or paste lat/lon.",
      );
      return;
    }
    setDetecting(true);
    setError(null);
    try {
      const coords = await new Promise<GeolocationCoordinates>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(
          (pos) => resolve(pos.coords),
          (err) => reject(new Error(err.message || "Location permission denied")),
          { enableHighAccuracy: true, timeout: 12_000, maximumAge: 60_000 },
        );
      });
      const latitude = Number(coords.latitude.toFixed(5));
      const longitude = Number(coords.longitude.toFixed(5));
      let place = "";
      try {
        const res = await fetch(
          `/api/widgets/weather/locate?lat=${encodeURIComponent(String(latitude))}&lon=${encodeURIComponent(String(longitude))}`,
        );
        const data = await res.json().catch(() => ({}));
        if (res.ok && data.place) place = String(data.place);
      } catch {
        // coords alone are enough
      }
      setValues((prev) => ({
        ...prev,
        latitude: String(latitude),
        longitude: String(longitude),
        ...(place ? { location: place } : {}),
      }));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not detect location");
    } finally {
      setDetecting(false);
    }
  }

  return (
    <div className="hd-modal-scrim" role="presentation" onClick={requestClose}>
      <form
        className="hd-modal hd-modal--config"
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        onClick={(e) => e.stopPropagation()}
        onSubmit={onSave}
      >
        <header className="hd-modal__head">
          <div>
            <div className="hd-settings__kicker">Widget settings</div>
            <h2 id={titleId}>{label}</h2>
            <p>
              {manifest.id === "weather"
                ? "Allow browser location, or set a city / coordinates. Detect fills lat/lon automatically."
                : "Update connection and appearance for this card. Changes save immediately."}
            </p>
          </div>
        </header>

        <div className="hd-modal__fields" style={{ paddingBottom: 0 }}>
          <div className="hd-field hd-field--wide">
            <div className="hd-settings__kicker">Appearance</div>
            <div className="hd-widget-card__chrome">
              <div className="hd-widget-card__chrome-toggle">
                <span className="hd-widget-card__chrome-label" id={`${instanceId}-chrome-logo`}>
                  Show logo
                </span>
                <label className="hd-switch" title={chromeDraft.showIcon ? "On" : "Off"}>
                  <input
                    type="checkbox"
                    checked={chromeDraft.showIcon}
                    aria-labelledby={`${instanceId}-chrome-logo`}
                    onChange={(e) => {
                      const showIcon = e.target.checked;
                      setChromeDraft((prev) => ({ ...prev, showIcon }));
                    }}
                  />
                  <span />
                </label>
              </div>
              <div className="hd-widget-card__chrome-toggle">
                <span className="hd-widget-card__chrome-label" id={`${instanceId}-chrome-title`}>
                  Show title
                </span>
                <label className="hd-switch" title={chromeDraft.showTitle ? "On" : "Off"}>
                  <input
                    type="checkbox"
                    checked={chromeDraft.showTitle}
                    aria-labelledby={`${instanceId}-chrome-title`}
                    onChange={(e) => {
                      const showTitle = e.target.checked;
                      setChromeDraft((prev) => ({ ...prev, showTitle }));
                    }}
                  />
                  <span />
                </label>
              </div>
              <WidgetChromeExpand
                idPrefix={instanceId}
                expand={chromeDraft.expand}
                onChange={(next) => {
                  const expand: ChromeExpand | undefined = next === false ? undefined : next;
                  setChromeDraft((prev) => ({ ...prev, expand }));
                }}
              />
              {manifest.id === "jellyfin-slider" ? (
                <>
                  <div className="hd-widget-card__chrome-toggle">
                    <span className="hd-widget-card__chrome-label" id={`${instanceId}-case-view`}>
                      Case View
                    </span>
                    <label className="hd-switch" title={values.caseView === "true" ? "On" : "Off"}>
                      <input
                        type="checkbox"
                        checked={values.caseView === "true"}
                        aria-labelledby={`${instanceId}-case-view`}
                        onChange={(e) =>
                          updateConfigField("caseView", e.target.checked ? "true" : "false")
                        }
                      />
                      <span />
                    </label>
                  </div>
                  <div className="hd-widget-card__chrome-toggle">
                    <label className="hd-widget-card__chrome-label" htmlFor={`${instanceId}-case-speed`}>
                      Case speed
                    </label>
                    <select
                      id={`${instanceId}-case-speed`}
                      value={values.caseViewSpeed || "520"}
                      disabled={values.caseView !== "true"}
                      onChange={(e) => updateConfigField("caseViewSpeed", e.target.value)}
                    >
                      <option value="200">Fast</option>
                      <option value="350">Quick</option>
                      <option value="520">Normal</option>
                      <option value="750">Smooth</option>
                      <option value="1000">Slow</option>
                    </select>
                  </div>
                  <div className="hd-widget-card__chrome-toggle">
                    <span className="hd-widget-card__chrome-label" id={`${instanceId}-music-shelf`}>
                      Shelf
                    </span>
                    <label className="hd-switch" title={values.musicShelf === "true" ? "On" : "Off"}>
                      <input
                        type="checkbox"
                        checked={values.musicShelf === "true"}
                        disabled={values.caseView !== "true"}
                        aria-labelledby={`${instanceId}-music-shelf`}
                        onChange={(e) =>
                          updateConfigField("musicShelf", e.target.checked ? "true" : "false")
                        }
                      />
                      <span />
                    </label>
                  </div>
                </>
              ) : null}
            </div>
          </div>
        </div>

        {manifest.id === "weather" && !loading ? (
          <div className="hd-modal__fields" style={{ paddingBottom: 0 }}>
            <div className="hd-field hd-field--wide">
              <button
                type="button"
                className="hd-btn hd-btn--primary"
                disabled={detecting}
                onClick={() => void detectWeatherLocation()}
              >
                {detecting ? "Detecting…" : "Detect my location"}
              </button>
            </div>
          </div>
        ) : null}

        {loading ? (
          <div className="hd-modal__status">Loading…</div>
        ) : !hasConfigEditor ? (
          <div className="hd-modal__status">This widget has no credential fields.</div>
        ) : isProxmox ? (
          <div className="hd-modal__fields">
            <div className="hd-field hd-field--wide">
              <ProxmoxConfigEditor
                value={values}
                onChange={(patch) => setValues((prev) => ({ ...prev, ...patch }))}
              />
            </div>
          </div>
        ) : (
          <div className="hd-modal__fields">
            {fields.map((field) => {
              const multiline = fieldIsMultiline(field);
              const value = values[field.key] || "";
              const isBookmarkGroup = manifest.id === "bookmarks" && field.key === "groupId";
              const isColor = field.type === "color";
              const isCheckbox = field.type === "checkbox";
              return (
                <div className={`hd-field${multiline || isColor || isCheckbox ? " hd-field--wide" : ""}`} key={field.key}>
                  {isColor ? (
                    <ColorField
                      id={`cfg-${instanceId}-${field.key}`}
                      label={field.label}
                      value={value}
                      placeholder={field.placeholder || "#22c55e"}
                      allowEmpty
                      onChange={(next) =>
                        updateConfigField(field.key, next)
                      }
                    />
                  ) : isCheckbox ? (
                    <div className="hd-widget-card__chrome-toggle">
                      <span className="hd-widget-card__chrome-label" id={`cfg-${instanceId}-${field.key}`}>
                        {field.label}
                      </span>
                      <label className="hd-switch" title={value === "true" ? "On" : "Off"}>
                        <input
                          type="checkbox"
                          checked={value === "true"}
                          aria-labelledby={`cfg-${instanceId}-${field.key}`}
                          onChange={(e) =>
                            updateConfigField(field.key, e.target.checked ? "true" : "false")
                          }
                        />
                        <span />
                      </label>
                    </div>
                  ) : (
                    <>
                  <label htmlFor={`cfg-${instanceId}-${field.key}`}>{field.label}</label>
                  {isBookmarkGroup ? (
                    <select
                      id={`cfg-${instanceId}-${field.key}`}
                      value={value}
                      onChange={(e) =>
                        updateConfigField(field.key, e.target.value)
                      }
                    >
                      <option value="">All bookmarks</option>
                      {bookmarkGroups.map((group) => (
                        <option key={group.id} value={group.id}>
                          {group.name}
                        </option>
                      ))}
                    </select>
                  ) : multiline ? (
                    <textarea
                      id={`cfg-${instanceId}-${field.key}`}
                      rows={4}
                      placeholder={field.placeholder}
                      spellCheck={false}
                      value={value}
                      onChange={(e) =>
                        updateConfigField(field.key, e.target.value)
                      }
                    />
                  ) : field.type === "select" && field.options?.length ? (
                    <select
                      id={`cfg-${instanceId}-${field.key}`}
                      value={value}
                      onChange={(e) =>
                        updateConfigField(field.key, e.target.value)
                      }
                    >
                      {!field.required ? <option value="">—</option> : null}
                      {field.options.map((opt) => (
                        <option key={opt.value} value={opt.value}>
                          {opt.label}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <input
                      id={`cfg-${instanceId}-${field.key}`}
                      type={fieldInputType(field)}
                      placeholder={field.placeholder}
                      autoComplete="off"
                      spellCheck={false}
                      value={value}
                      onChange={(e) =>
                        updateConfigField(field.key, e.target.value)
                      }
                    />
                  )}
                    </>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {error ? <div className="hd-modal__error">{error}</div> : null}

        <footer className="hd-modal__foot">
          <button type="button" className="hd-btn" onClick={requestClose}>
            Cancel
          </button>
          <button
            type="submit"
            className="hd-btn hd-btn--primary"
            disabled={saving || loading}
          >
            {saving ? "Saving…" : "Save"}
          </button>
        </footer>
      </form>
      <UnsavedChangesDialog
        open={confirmClose}
        saving={saving}
        saveDisabled={loading}
        onSave={() => void onSave()}
        onDiscard={onClose}
        onKeepEditing={() => setConfirmClose(false)}
      />
    </div>
  );
}
