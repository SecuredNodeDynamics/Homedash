"use client";

import { useEffect, useLayoutEffect, useMemo, useRef, useState, type CSSProperties, type ReactNode } from "react";
import type { WidgetAccentSettings, WidgetManifest } from "@/lib/types";
import { resolveWidgetAccent } from "@/lib/theme";
import { WidgetInstanceProvider } from "@/widgets/_shared/instance-context";

const AI_CHAT_BRANDS: Record<string, { title: string; icon: string }> = {
  openai: { title: "ChatGPT", icon: "/icons/ai-openai.svg" },
  gemini: { title: "Gemini", icon: "/icons/ai-gemini.svg" },
  claude: { title: "Claude", icon: "/icons/ai-claude.svg" },
  perplexity: { title: "Perplexity", icon: "/icons/ai-perplexity.svg" },
};

export function WidgetFrame({
  manifest,
  children,
  editMode,
  title,
  instanceId,
  iconUrl,
  showIcon = true,
  showTitle = true,
  autoHeight = false,
  onContentSize,
  globalAccent = "rainbow",
  globalAccentColor,
  themeAccent = "#e5a00d",
  widgetAccent,
  hasConfigFields = false,
  onEditConfig,
  onRemove,
  onDisable,
  sizeLocked = false,
  hiddenOnDevice = false,
  deviceLabel = "this device",
  order,
  onToggleSizeLock,
  onToggleHidden,
  onOrderChange,
}: {
  manifest: WidgetManifest;
  children: ReactNode;
  editMode?: boolean;
  title?: string;
  instanceId?: string;
  iconUrl?: string | null;
  showIcon?: boolean;
  showTitle?: boolean;
  autoHeight?: boolean;
  onContentSize?: (size: { height: number; width: number }) => void;
  globalAccent?: "rainbow" | "solid" | "off";
  globalAccentColor?: string;
  themeAccent?: string;
  widgetAccent?: WidgetAccentSettings;
  hasConfigFields?: boolean;
  onEditConfig?: () => void;
  onRemove?: () => void;
  onDisable?: () => void;
  sizeLocked?: boolean;
  hiddenOnDevice?: boolean;
  deviceLabel?: string;
  order?: number;
  onToggleSizeLock?: () => void;
  onToggleHidden?: () => void;
  onOrderChange?: (order: number | undefined) => void;
}) {
  const hostClass = manifest.hostClass?.trim() ?? "";
  const accent = resolveWidgetAccent(globalAccent, globalAccentColor, themeAccent, widgetAccent);
  const resolvedInstanceId = instanceId || manifest.id;
  const rootRef = useRef<HTMLElement>(null);
  const [aiChatProvider, setAiChatProvider] = useState("openai");
  const [aiChatLogo, setAiChatLogo] = useState("");
  const aiChatBrand = manifest.id === "ai-chat"
    ? AI_CHAT_BRANDS[aiChatProvider] || AI_CHAT_BRANDS.openai
    : null;
  const frameIconUrl = (aiChatBrand ? aiChatLogo || aiChatBrand.icon : null) || iconUrl;
  const frameTitle = aiChatBrand?.title || title || manifest.name;
  // Proxmox (and similar) render their own branded header — keep the glass frame
  // head for edit actions only, and pass chrome flags into the widget via context.
  const selfBranded = manifest.id === "proxmox-nodes";
  const frameShowIcon = selfBranded ? false : showIcon;
  const frameShowTitle = selfBranded ? false : showTitle;
  const showHead = frameShowIcon || frameShowTitle || Boolean(editMode);
  const style: CSSProperties | undefined =
    accent.mode === "solid"
      ? ({ ["--hd-widget-accent-color" as string]: accent.color } as CSSProperties)
      : undefined;
  const instanceValue = useMemo(
    () => ({
      instanceId: resolvedInstanceId,
      widgetId: manifest.id,
      label: title || manifest.name,
      iconUrl: iconUrl || null,
      showIcon,
      showTitle,
    }),
    [resolvedInstanceId, manifest.id, manifest.name, title, iconUrl, showIcon, showTitle],
  );

  useEffect(() => {
    if (manifest.id !== "ai-chat") return;
    let active = true;
    void fetch(`/api/widgets/ai-chat/info?instance=${encodeURIComponent(resolvedInstanceId)}`)
      .then((response) => response.json())
      .then((data) => {
        if (active && !data.error) {
          setAiChatProvider(String(data.provider || "openai"));
          setAiChatLogo(String(data.logo || ""));
        }
      })
      .catch(() => undefined);
    const onProvider = (event: Event) => {
      const detail = (event as CustomEvent<{ instanceId?: string; provider?: string }>).detail;
      if (detail?.instanceId === resolvedInstanceId && detail.provider) {
        setAiChatProvider(detail.provider);
        setAiChatLogo(String((detail as { logo?: string }).logo || ""));
      }
    };
    window.addEventListener("homedash:ai-chat-provider", onProvider);
    return () => {
      active = false;
      window.removeEventListener("homedash:ai-chat-provider", onProvider);
    };
  }, [manifest.id, resolvedInstanceId]);

  useLayoutEffect(() => {
    if (!autoHeight || !onContentSize) return;
    const root = rootRef.current;
    if (!root) return;

    let frame = 0;
    const measure = () => {
      const content = root.querySelector(".hd-widget__content") as HTMLElement | null;
      const body = root.querySelector(".hd-widget-body") as HTMLElement | null;
      if (!body) return;

      const cardWidth = Math.max(1, root.clientWidth);

      const rootPrev = {
        height: root.style.height,
        minHeight: root.style.minHeight,
        maxHeight: root.style.maxHeight,
        overflow: root.style.overflow,
      };
      const contentPrev = content
        ? {
            overflow: content.style.overflow,
            height: content.style.height,
            maxHeight: content.style.maxHeight,
            flex: content.style.flex,
            minHeight: content.style.minHeight,
          }
        : null;
      const prev = {
        overflow: body.style.overflow,
        overflowY: body.style.overflowY,
        height: body.style.height,
        maxHeight: body.style.maxHeight,
        width: body.style.width,
        maxWidth: body.style.maxWidth,
        flex: body.style.flex,
        minHeight: body.style.minHeight,
      };

      const nested = Array.from(
        body.querySelectorAll<HTMLElement>(
          "[class*='-host'], [class*='-shell'], [class*='-body'], [class*='-scroll'], .pve-overview-tab, .pve-hw-tab, .pve-network-tab, .pve-storage-tab, .pve-guests-tab, .pve-bk-tab, .pve-sec-tab, .pve-bk-panel, .pve-bk-subpane, .wz-alerts-panel, .wz-alert-list, .cmk-svc-list",
        ),
      );
      const nestedPrev = nested.map((el) => ({
        el,
        overflow: el.style.overflow,
        overflowY: el.style.overflowY,
        height: el.style.height,
        maxHeight: el.style.maxHeight,
        minHeight: el.style.minHeight,
        flex: el.style.flex,
      }));

      // Collapse the card off the grid-cell stretch so scrollHeight reflects
      // content (needed to retract after tabs/content get shorter).
      root.style.height = "auto";
      root.style.minHeight = "0";
      root.style.maxHeight = "none";
      root.style.overflow = "visible";
      if (content) {
        content.style.overflow = "visible";
        content.style.flex = "0 0 auto";
        content.style.minHeight = "0";
        content.style.height = "auto";
        content.style.maxHeight = "none";
      }

      body.style.setProperty("overflow", "visible", "important");
      body.style.setProperty("overflow-y", "visible", "important");
      body.style.flex = "0 0 auto";
      body.style.minHeight = "0";
      body.style.height = "auto";
      body.style.maxHeight = "none";
      body.style.width = `${cardWidth}px`;
      body.style.maxWidth = `${cardWidth}px`;

      for (const el of nested) {
        el.style.setProperty("overflow", "visible", "important");
        el.style.setProperty("overflow-y", "visible", "important");
        el.style.setProperty("height", "auto", "important");
        el.style.setProperty("max-height", "none", "important");
        el.style.minHeight = "0";
        el.style.flex = "0 0 auto";
      }

      // Measure intrinsic content, not the grid cell. The RGL wrapper has a
      // fixed pixel height, so root.getBoundingClientRect() stays at the saved
      // card size and Expand never grows.
      const head = root.querySelector(".hd-widget__head") as HTMLElement | null;
      const height = Math.max(
        1,
        Math.ceil(
          (head?.getBoundingClientRect().height || 0) +
            (body.scrollHeight || body.offsetHeight || 0),
        ),
      );

      body.style.width = "max-content";
      body.style.maxWidth = "none";
      const bodyWidth = Math.ceil(Math.max(body.scrollWidth, cardWidth * 0.5));

      root.style.height = rootPrev.height;
      root.style.minHeight = rootPrev.minHeight;
      root.style.maxHeight = rootPrev.maxHeight;
      root.style.overflow = rootPrev.overflow;
      if (content && contentPrev) {
        content.style.overflow = contentPrev.overflow;
        content.style.height = contentPrev.height;
        content.style.maxHeight = contentPrev.maxHeight;
        content.style.flex = contentPrev.flex;
        content.style.minHeight = contentPrev.minHeight;
      }

      body.style.removeProperty("overflow");
      body.style.removeProperty("overflow-y");
      if (prev.overflow) body.style.overflow = prev.overflow;
      if (prev.overflowY) body.style.overflowY = prev.overflowY;
      body.style.height = prev.height;
      body.style.maxHeight = prev.maxHeight;
      body.style.width = prev.width;
      body.style.maxWidth = prev.maxWidth;
      body.style.flex = prev.flex;
      body.style.minHeight = prev.minHeight;

      for (const item of nestedPrev) {
        item.el.style.removeProperty("overflow");
        item.el.style.removeProperty("overflow-y");
        item.el.style.removeProperty("height");
        item.el.style.removeProperty("max-height");
        if (item.overflow) item.el.style.overflow = item.overflow;
        if (item.overflowY) item.el.style.overflowY = item.overflowY;
        if (item.height) item.el.style.height = item.height;
        if (item.maxHeight) item.el.style.maxHeight = item.maxHeight;
        item.el.style.minHeight = item.minHeight;
        item.el.style.flex = item.flex;
      }

      if (height > 0) onContentSize({ height, width: bodyWidth });
    };

    const schedule = () => {
      cancelAnimationFrame(frame);
      frame = window.requestAnimationFrame(measure);
    };

    const ro = new ResizeObserver(schedule);
    ro.observe(root);
    const body = root.querySelector(".hd-widget-body");
    if (body) {
      ro.observe(body);
      const mo = new MutationObserver(schedule);
      mo.observe(body, { childList: true, subtree: true, characterData: true });
      measure();
      const t1 = window.setTimeout(measure, 50);
      const t2 = window.setTimeout(measure, 250);
      const t3 = window.setTimeout(measure, 800);
      return () => {
        ro.disconnect();
        mo.disconnect();
        cancelAnimationFrame(frame);
        window.clearTimeout(t1);
        window.clearTimeout(t2);
        window.clearTimeout(t3);
      };
    }

    measure();
    return () => {
      ro.disconnect();
      cancelAnimationFrame(frame);
    };
  }, [autoHeight, onContentSize, children, showHead]);

  return (
    <section
      ref={rootRef}
      className={[
        "hd-widget",
        "widget-card",
        hostClass,
        autoHeight ? "hd-widget--auto-height" : "",
        !showHead ? "hd-widget--no-head" : "",
        editMode ? "hd-widget--editing" : "",
        editMode && hiddenOnDevice ? "hd-widget--device-hidden" : "",
        accent.mode === "off" ? "hd-accent-off" : "",
        accent.mode === "solid" ? "hd-accent-solid" : "",
        accent.mode === "rainbow" ? "hd-accent-rainbow" : "",
      ]
        .filter(Boolean)
        .join(" ")}
      data-widget-id={manifest.id}
      data-instance-id={resolvedInstanceId}
      data-accent={accent.mode}
      data-editing={editMode ? "true" : undefined}
      data-device-hidden={editMode && hiddenOnDevice ? "true" : undefined}
      style={style}
    >
      {showHead ? (
        <div className="hd-widget__head">
          <div className="hd-widget__identity">
            {frameShowIcon && frameIconUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img className="hd-widget__icon" src={frameIconUrl} alt="" />
            ) : null}
            {frameShowTitle ? <div className="hd-widget__title">{frameTitle}</div> : null}
          </div>
          {editMode ? (
            <div
              className="hd-widget__edit-actions"
              onMouseDown={(e) => e.stopPropagation()}
              onTouchStart={(e) => e.stopPropagation()}
              onClick={(e) => e.stopPropagation()}
            >
              {onOrderChange ? (
                <label
                  className="hd-widget__order"
                  title="Priority order for this device only (lower first). Other device layouts keep their own #."
                >
                  <span className="hd-widget__order-label">#</span>
                  <input
                    type="number"
                    min={1}
                    step={1}
                    inputMode="numeric"
                    className="hd-widget__order-input"
                    placeholder="—"
                    value={order ?? ""}
                    aria-label="Priority order for this device layout"
                    onChange={(e) => {
                      const raw = e.target.value.trim();
                      if (!raw) {
                        onOrderChange(undefined);
                        return;
                      }
                      const n = Number(raw);
                      if (!Number.isFinite(n)) return;
                      onOrderChange(Math.max(1, Math.round(n)));
                    }}
                  />
                </label>
              ) : null}
              {onToggleSizeLock ? (
                <button
                  type="button"
                  className={`hd-widget__edit-btn${sizeLocked ? " is-active" : ""}`}
                  title={
                    sizeLocked
                      ? "Unlock size for this device (Auto Layout may resize)"
                      : "Lock size for this device (Auto Layout keeps w/h)"
                  }
                  aria-label={
                    sizeLocked ? "Unlock widget size for this device" : "Lock widget size for this device"
                  }
                  aria-pressed={sizeLocked}
                  onClick={onToggleSizeLock}
                >
                  {sizeLocked ? (
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
                      <rect x="5" y="11" width="14" height="10" rx="2" />
                      <path d="M8 11V8a4 4 0 0 1 8 0v3" />
                    </svg>
                  ) : (
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
                      <rect x="5" y="11" width="14" height="10" rx="2" />
                      <path d="M8 11V8a4 4 0 0 1 7.5-1.8" />
                    </svg>
                  )}
                </button>
              ) : null}
              {onToggleHidden ? (
                <button
                  type="button"
                  className={`hd-widget__edit-btn${hiddenOnDevice ? " is-active is-hidden-device" : ""}`}
                  title={
                    hiddenOnDevice
                      ? `Show on ${deviceLabel}`
                      : `Hide on ${deviceLabel}`
                  }
                  aria-label={
                    hiddenOnDevice
                      ? `Show widget on ${deviceLabel}`
                      : `Hide widget on ${deviceLabel}`
                  }
                  aria-pressed={hiddenOnDevice}
                  onClick={onToggleHidden}
                >
                  {hiddenOnDevice ? (
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
                      <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94" />
                      <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19" />
                      <path d="M14.12 14.12a3 3 0 1 1-4.24-4.24" />
                      <path d="M1 1l22 22" />
                    </svg>
                  ) : (
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
                      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                      <circle cx="12" cy="12" r="3" />
                    </svg>
                  )}
                </button>
              ) : null}
              {onEditConfig ? (
                <button
                  type="button"
                  className="hd-widget__edit-btn"
                  title="Widget settings"
                  aria-label="Edit widget settings"
                  onClick={onEditConfig}
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
                    <circle cx="12" cy="12" r="3" />
                    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
                  </svg>
                </button>
              ) : null}
              {onRemove ? (
                <button
                  type="button"
                  className="hd-widget__edit-btn"
                  title="Remove from this tab"
                  aria-label="Remove from this tab"
                  onClick={onRemove}
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
                    <path d="M3 6h18" />
                    <path d="M8 6V4h8v2" />
                    <path d="M19 6l-1 14H6L5 6" />
                    <path d="M10 11v6M14 11v6" />
                  </svg>
                </button>
              ) : null}
              {onDisable ? (
                <button
                  type="button"
                  className="hd-widget__edit-btn hd-widget__edit-btn--warn"
                  title="Disable everywhere"
                  aria-label="Disable widget package"
                  onClick={onDisable}
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
                    <circle cx="12" cy="12" r="9" />
                    <path d="M5 5l14 14" />
                  </svg>
                </button>
              ) : null}
            </div>
          ) : null}
        </div>
      ) : null}
      <WidgetInstanceProvider value={instanceValue}>
        <div className="hd-widget__content" inert={editMode ? true : undefined}>
          {children}
        </div>
      </WidgetInstanceProvider>
    </section>
  );
}
