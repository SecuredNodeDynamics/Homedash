"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { createPortal } from "react-dom";
import { iconForWidget, initialsForWidget } from "@/lib/widget-icons";

type PackageRecord = {
  id: string;
  name: string;
  version: string;
  category: string;
  file: string;
  sha256: string;
  bytes: number;
  sourceFiles: number;
  installed: boolean;
  installedVersion: string | null;
  updateAvailable: boolean;
  guideUrl: string;
  downloadUrl: string;
  custom?: boolean;
};

type Job = {
  id: string;
  widgetId: string;
  widgetIds?: string[];
  operation?: "install" | "uninstall";
  status: "queued" | "running" | "restarting" | "complete" | "failed";
  step: string;
  message: string;
  log: string[];
  rolledBack?: boolean;
};

type Catalog = {
  homedashVersion: string;
  agent: { ok: boolean; version: number; error?: string };
  packages: PackageRecord[];
};

const ACTIVE_JOB_KEY = "homedash.widget-manager.active-job";

function Brand({
  pkg,
  defaultLogo,
  customLogo,
}: {
  pkg: PackageRecord;
  defaultLogo?: string;
  customLogo?: string;
}) {
  const preferred = iconForWidget(pkg.id);
  const sources = useMemo(
    () => [customLogo, preferred, defaultLogo].filter((value, index, list): value is string =>
      Boolean(value && list.indexOf(value) === index),
    ),
    [customLogo, preferred, defaultLogo],
  );
  const [sourceIndex, setSourceIndex] = useState(0);
  useEffect(() => {
    setSourceIndex(0);
  }, [customLogo, preferred, defaultLogo]);
  const src = sources[sourceIndex];
  return (
    <span className="hd-manager-card__icon" aria-hidden="true">
      {src ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={src} alt="" onError={() => setSourceIndex((index) => index + 1)} />
      ) : (
        <span>{initialsForWidget(pkg.name)}</span>
      )}
    </span>
  );
}

export function WidgetManager({
  defaultLogo,
  widgetIcons = {},
  onWidgetIconChange,
}: {
  defaultLogo?: string;
  widgetIcons?: Record<string, string>;
  onWidgetIconChange?: (id: string, url: string) => void;
}) {
  const router = useRouter();
  const logoFileRef = useRef<HTMLInputElement>(null);
  const packageFileRef = useRef<HTMLInputElement>(null);
  const [catalog, setCatalog] = useState<Catalog | null>(null);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [activeJob, setActiveJob] = useState<Job | null>(null);
  const jobLogRef = useRef<HTMLPreElement>(null);
  const jobLogPinnedRef = useRef(true);
  const lastJobIdRef = useRef<string | null>(null);

  // Keep the job log scrolled to the latest line as it streams in, unless
  // the user has manually scrolled up to read earlier output — in which
  // case leave the scroll position alone so we don't yank them back down.
  useEffect(() => {
    const node = jobLogRef.current;
    if (!node || !jobLogPinnedRef.current) return;
    node.scrollTop = node.scrollHeight;
  }, [activeJob?.log]);

  // A brand-new job (install/uninstall/recovered) should always start
  // pinned to the bottom — otherwise a scroll-up from a previous job
  // would silently suppress auto-scroll forever, with no way to tell why.
  useEffect(() => {
    if (activeJob && activeJob.id !== lastJobIdRef.current) {
      lastJobIdRef.current = activeJob.id;
      jobLogPinnedRef.current = true;
      const node = jobLogRef.current;
      if (node) node.scrollTop = node.scrollHeight;
    }
  }, [activeJob?.id]);
  const [copyState, setCopyState] = useState<"idle" | "copied" | "error">("idle");
  const copyResetRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  async function copyJobLog() {
    const text = activeJob?.log?.length ? activeJob.log.join("\n") : "";
    if (!text) return;
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(text);
      } else {
        // Fallback for browsers/contexts without the async Clipboard API.
        const textarea = document.createElement("textarea");
        textarea.value = text;
        textarea.style.position = "fixed";
        textarea.style.opacity = "0";
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand("copy");
        document.body.removeChild(textarea);
      }
      setCopyState("copied");
    } catch {
      setCopyState("error");
    } finally {
      if (copyResetRef.current) clearTimeout(copyResetRef.current);
      copyResetRef.current = setTimeout(() => setCopyState("idle"), 2000);
    }
  }

  useEffect(() => {
    return () => {
      if (copyResetRef.current) clearTimeout(copyResetRef.current);
    };
  }, []);

  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [savedIcons, setSavedIcons] = useState<Record<string, string>>(widgetIcons);
  const [editingLogo, setEditingLogo] = useState<PackageRecord | null>(null);
  const [logoDraft, setLogoDraft] = useState("");
  const [logoBusy, setLogoBusy] = useState(false);
  const [logoMessage, setLogoMessage] = useState("");
  const [packageModalOpen, setPackageModalOpen] = useState(false);
  const [packageQueue, setPackageQueue] = useState<{ id: string; file: File }[]>([]);
  const [packageBusy, setPackageBusy] = useState(false);
  const [packageError, setPackageError] = useState("");
  const MAX_QUEUED_PACKAGES = 10;
  const managerAgentReady = Boolean(catalog?.agent.ok && catalog.agent.version >= 2);

  useEffect(() => {
    setSavedIcons(widgetIcons);
  }, [widgetIcons]);

  function openLogoEditor(pkg: PackageRecord) {
    setEditingLogo(pkg);
    setLogoDraft(savedIcons[pkg.id] || "");
    setLogoMessage("");
  }

  async function persistLogo(pkg: PackageRecord, url: string) {
    setLogoBusy(true);
    setLogoMessage("");
    try {
      const response = await fetch("/api/admin/widgets/icons", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: pkg.id, url }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error || "Could not save widget logo");
      const savedUrl = String(body.url || "");
      setSavedIcons((current) => {
        const next = { ...current };
        if (savedUrl) next[pkg.id] = savedUrl;
        else delete next[pkg.id];
        return next;
      });
      onWidgetIconChange?.(pkg.id, savedUrl);
      setLogoDraft(savedUrl);
      setLogoMessage(savedUrl ? "Logo saved. Guide pages now use this image." : "Custom logo removed.");
    } catch (nextError) {
      setLogoMessage(nextError instanceof Error ? nextError.message : "Could not save widget logo");
    } finally {
      setLogoBusy(false);
    }
  }

  async function uploadLogo(file: File | undefined) {
    if (!file || !editingLogo) return;
    setLogoBusy(true);
    setLogoMessage("");
    try {
      const data = new FormData();
      data.set("kind", "widget-icon");
      data.set("key", `manager-${editingLogo.id}`);
      data.set("file", file);
      const response = await fetch("/api/uploads", { method: "POST", body: data });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error || "Logo upload failed");
      const url = String(body.url || "");
      setLogoDraft(url);
      await persistLogo(editingLogo, url);
    } catch (nextError) {
      setLogoMessage(nextError instanceof Error ? nextError.message : "Logo upload failed");
      setLogoBusy(false);
    } finally {
      if (logoFileRef.current) logoFileRef.current.value = "";
    }
  }

  async function loadCatalog() {
    try {
      const response = await fetch("/api/admin/widgets/packages", { cache: "no-store" });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error || "Could not load widget packages");
      setCatalog(body as Catalog);
      setError("");
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Could not load widget packages");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadCatalog();
    void recoverActiveJob();
  }, []);

  function rememberJob(job: Job) {
    setActiveJob(job);
    window.localStorage.setItem(ACTIVE_JOB_KEY, job.id);
  }

  function widgetNameFor(widgetId: string) {
    const pkg = catalog?.packages.find((item) => item.id === widgetId);
    if (pkg) return pkg.name;
    return widgetId
      .split("-")
      .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
      .join(" ");
  }

  function jobTitle(job: Job) {
    const verb = job.operation === "uninstall" ? "Uninstalling" : "Installing";
    const ids = job.widgetIds?.length ? job.widgetIds : [job.widgetId];
    if (ids.length > 1) return `${verb} ${ids.length} widgets`;
    return `${verb} ${widgetNameFor(ids[0])}`;
  }

  function clearActiveJob() {
    if (activeJob && !["complete", "failed"].includes(activeJob.status)) {
      if (
        !window.confirm(
          "Clear the update log?\n\nThis only clears the log display in this browser. It does not stop, delete, or roll back anything on the server.",
        )
      ) {
        return;
      }
    }
    setActiveJob(null);
    window.localStorage.removeItem(ACTIVE_JOB_KEY);
  }

  async function recoverActiveJob() {
    const savedId = window.localStorage.getItem(ACTIVE_JOB_KEY);
    if (savedId) {
      try {
        const response = await fetch(`/api/admin/widgets/jobs/${encodeURIComponent(savedId)}`, { cache: "no-store" });
        const body = await response.json().catch(() => ({}));
        if (response.ok && body.job) {
          const job = body.job as Job;
          if (!["complete", "failed"].includes(job.status)) {
            setActiveJob(job);
            return;
          }
        }
      } catch {
        // Fall through to host-side active job discovery.
      }
      window.localStorage.removeItem(ACTIVE_JOB_KEY);
    }
    try {
      const response = await fetch("/api/admin/widgets/jobs/active", { cache: "no-store" });
      const body = await response.json().catch(() => ({}));
      if (response.ok && body.job) rememberJob(body.job as Job);
    } catch {
      // Catalog agent status already reports an unavailable installation service.
    }
  }

  useEffect(() => {
    if (!activeJob || activeJob.status === "complete" || activeJob.status === "failed") return;
    let stopped = false;
    let timer: ReturnType<typeof setTimeout>;
    const poll = async () => {
      try {
        const response = await fetch(`/api/admin/widgets/jobs/${encodeURIComponent(activeJob.id)}`, {
          cache: "no-store",
        });
        const body = await response.json().catch(() => ({}));
        if (response.ok && body.job && !stopped) {
          const job = body.job as Job;
          setActiveJob(job);
          if (job.status === "complete") {
            window.localStorage.removeItem(ACTIVE_JOB_KEY);
            setSelectedIds([]);
            await loadCatalog();
            router.refresh();
            return;
          }
          if (job.status === "failed") {
            window.localStorage.removeItem(ACTIVE_JOB_KEY);
            return;
          }
        }
      } catch {
        // Expected while the Homedash container is being recreated.
      }
      if (!stopped) timer = setTimeout(poll, 2000);
    };
    timer = setTimeout(poll, 1200);
    return () => {
      stopped = true;
      clearTimeout(timer);
    };
  }, [activeJob?.id, activeJob?.status, router]);

  const categories = useMemo(
    () => [...new Set((catalog?.packages || []).map((pkg) => pkg.category).filter(Boolean))].sort(),
    [catalog],
  );
  const packages = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return (catalog?.packages || []).filter(
      (pkg) =>
        (category === "all" || pkg.category === category) &&
        (!needle ||
          pkg.name.toLowerCase().includes(needle) ||
          pkg.id.toLowerCase().includes(needle) ||
          pkg.category.toLowerCase().includes(needle)),
    );
  }, [catalog, category, query]);

  async function install(pkg: PackageRecord) {
    const action = pkg.updateAvailable ? "update" : pkg.installed ? "repair/reinstall" : "install";
    if (
      !window.confirm(
        `${action[0].toUpperCase()}${action.slice(1)} ${pkg.name} ${pkg.version}?\n\n` +
          "Homedash will verify the package, back up affected source, build a candidate image, and restart.",
      )
    ) {
      return;
    }
    setError("");
    try {
      const response = await fetch("/api/admin/widgets/install", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: pkg.id, confirm: true }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error || "Could not start widget installation");
      rememberJob(body.job as Job);
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Could not start widget installation");
    }
  }

  function closePackageModal() {
    if (packageBusy) return;
    setPackageModalOpen(false);
    setPackageQueue([]);
    setPackageError("");
    if (packageFileRef.current) packageFileRef.current.value = "";
  }

  function queueFiles(list: FileList | File[] | null) {
    if (!list) return;
    const incoming = Array.from(list);
    if (!incoming.length) return;
    const rejected = incoming.filter((file) => !file.name.toLowerCase().endsWith(".hdwidget"));
    setPackageQueue((current) => {
      const existingKeys = new Set(current.map((item) => `${item.file.name}:${item.file.size}:${item.file.lastModified}`));
      const additions = incoming
        .filter((file) => file.name.toLowerCase().endsWith(".hdwidget"))
        .filter((file) => !existingKeys.has(`${file.name}:${file.size}:${file.lastModified}`))
        .map((file) => ({
          id: `${file.name}-${file.size}-${file.lastModified}-${Math.random().toString(36).slice(2)}`,
          file,
        }));
      return [...current, ...additions].slice(0, MAX_QUEUED_PACKAGES);
    });
    if (rejected.length) {
      setPackageError(
        rejected.length === incoming.length
          ? "Choose .hdwidget packages"
          : `Skipped ${rejected.length} file${rejected.length === 1 ? "" : "s"} that ${rejected.length === 1 ? "isn't" : "aren't"} .hdwidget packages`,
      );
    } else {
      setPackageError("");
    }
  }

  function removeQueuedPackage(id: string) {
    setPackageQueue((current) => current.filter((item) => item.id !== id));
  }

  async function installQueuedPackages() {
    if (!packageQueue.length || packageBusy) return;
    setPackageBusy(true);
    setPackageError("");
    try {
      const data = new FormData();
      for (const item of packageQueue) data.append("packages", item.file);
      data.set("confirm", "true");
      const response = await fetch("/api/admin/widgets/upload-install-batch", {
        method: "POST",
        body: data,
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error || "Could not start package installation");
      rememberJob(body.job as Job);
      setPackageModalOpen(false);
      setPackageQueue([]);
      if (packageFileRef.current) packageFileRef.current.value = "";
    } catch (nextError) {
      setPackageError(nextError instanceof Error ? nextError.message : "Could not start package installation");
    } finally {
      setPackageBusy(false);
    }
  }

  function toggleSelected(id: string) {
    setSelectedIds((current) =>
      current.includes(id) ? current.filter((value) => value !== id) : [...current, id],
    );
  }

  async function startBulkInstall(ids: string[]) {
    const selected = (catalog?.packages || []).filter((pkg) => ids.includes(pkg.id));
    const eligible = selected.filter((pkg) => !pkg.installed || pkg.updateAvailable);
    if (!eligible.length) return;
    if (!window.confirm(
      `Install or update ${eligible.length} selected widget${eligible.length === 1 ? "" : "s"}?\n\n` +
      "Homedash will back up all affected source, apply every package, build once, and restart.",
    )) return;
    setError("");
    try {
      const response = await fetch("/api/admin/widgets/install-batch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids: eligible.map((pkg) => pkg.id), confirm: true }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error || "Could not start bulk installation");
      rememberJob(body.job as Job);
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Could not start bulk installation");
    }
  }

  async function uninstall(ids: string[]) {
    const selected = (catalog?.packages || []).filter((pkg) => ids.includes(pkg.id) && pkg.installed);
    if (!selected.length) return;
    if (!window.confirm(
      `Uninstall ${selected.map((pkg) => pkg.name).join(", ")}?\n\n` +
      "Widget source will be backed up before removal. Saved dashboard settings are preserved for a future reinstall.",
    )) return;
    setError("");
    try {
      const response = await fetch("/api/admin/widgets/uninstall", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids: selected.map((pkg) => pkg.id), confirm: true }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error || "Could not start widget uninstall");
      rememberJob(body.job as Job);
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : "Could not start widget uninstall");
    }
  }

  if (loading) {
    return <div className="hd-manager-state">Loading widget package catalog…</div>;
  }

  return (
    <section className="hd-manager">
      <div className="hd-manager-overview">
        <article className={`hd-manager-agent${catalog?.agent.ok ? " is-online" : " is-offline"}`}>
          <span className="hd-manager-overview__icon" aria-hidden>{catalog?.agent.ok ? "✓" : "!"}</span>
          <div>
            <div className="hd-settings__kicker">Installation service</div>
            <strong>{catalog?.agent.ok ? "Widget agent online" : "Widget agent unavailable"}</strong>
            <p>
              {catalog?.agent.ok
                ? catalog.agent.version >= 2
                  ? "Verified installs, bulk changes, uninstall, recovery, and rollback are ready."
                  : "Update the host widget agent to enable bulk actions, uninstall, and job recovery."
                : catalog?.agent.error || "Install the host-side widget agent to enable package operations."}
            </p>
          </div>
          <span className="hd-manager-agent__status">
            {catalog?.agent.ok ? (catalog.agent.version >= 2 ? "Ready" : "Upgrade") : "Offline"}
          </span>
        </article>
      </div>

      {activeJob ? (
        <article className={`hd-manager-job is-${activeJob.status}`}>
          <header>
            <div>
              <div className="hd-settings__kicker">
                {activeJob.operation === "uninstall" ? "Uninstall job" : "Installation job"}
              </div>
              <strong>{jobTitle(activeJob)}</strong>
              <p className="hd-manager-job__step">{activeJob.message}</p>
            </div>
            <span>{activeJob.status}</span>
            <div className="hd-manager-job__header-actions">
              <button
                className="hd-btn hd-btn--sm"
                type="button"
                onClick={clearActiveJob}
                title="Clear the update log display without stopping or deleting anything"
              >
                Clear log
              </button>
              <button
                type="button"
                className="hd-btn hd-btn--sm hd-manager-job__copy"
                disabled={!activeJob.log?.length}
                onClick={() => void copyJobLog()}
              >
                {copyState === "copied" ? "Copied" : copyState === "error" ? "Copy failed" : "Copy log"}
              </button>
            </div>
          </header>
          <div className="hd-manager-job__track">
            <i
              style={{
                width:
                  activeJob.status === "complete"
                    ? "100%"
                    : activeJob.step === "verify"
                      ? "16%"
                      : activeJob.step === "backup"
                        ? "32%"
                        : activeJob.step === "install"
                          ? "50%"
                          : activeJob.step === "build"
                            ? "72%"
                            : activeJob.step === "restart"
                              ? "90%"
                              : activeJob.step === "rollback"
                                ? "82%"
                                : "8%",
              }}
            />
          </div>
          <details
            onToggle={(event) => {
              if (!event.currentTarget.open) return;
              // Opening the panel mid-job should jump straight to the latest
              // output (tail -f style) instead of stranding the user at
              // whatever was logged before they expanded it.
              jobLogPinnedRef.current = true;
              const node = jobLogRef.current;
              if (node) node.scrollTop = node.scrollHeight;
            }}
          >
            <summary>
              <span className="hd-btn hd-btn--sm hd-manager-job__logtoggle">Job log</span>
            </summary>
            <pre
              ref={jobLogRef}
              onScroll={(event) => {
                const node = event.currentTarget;
                jobLogPinnedRef.current = node.scrollHeight - node.scrollTop - node.clientHeight < 24;
              }}
            >
              {activeJob.log?.join("\n") || "Waiting for agent output…"}
            </pre>
          </details>
          {activeJob.status === "failed" ? (
            <div className="hd-manager-job__failed">
              Job failed.{activeJob.rolledBack ? " Previous source was restored." : ""}
            </div>
          ) : null}
        </article>
      ) : null}

      {typeof document !== "undefined" && document.getElementById("hd-widget-manager-hero-tools")
        ? createPortal(
            <div className="hd-manager-tools hd-manager-tools--hero">
              <input
                className="hd-search"
                type="search"
                placeholder="Search install packages…"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                aria-label="Search widget packages"
              />
              <select value={category} onChange={(event) => setCategory(event.target.value)} aria-label="Filter widget packages by category">
                <option value="all">All categories</option>
                {categories.map((item) => (
                  <option key={item} value={item}>{item}</option>
                ))}
              </select>
              <button className="hd-btn" type="button" onClick={() => void loadCatalog()}>
                Refresh
              </button>
              <button
                className="hd-btn hd-btn--primary"
                type="button"
                disabled={!catalog?.agent.ok}
                onClick={() => setPackageModalOpen(true)}
              >
                Upload package
              </button>
            </div>,
            document.getElementById("hd-widget-manager-hero-tools")!,
          )
        : null}

      {error ? <div className="hd-manager-error">{error}</div> : null}

      {selectedIds.length ? (
        <div className="hd-manager-selection" role="region" aria-label="Selected widget actions">
          <strong>{selectedIds.length} selected</strong>
          <span>
            {(catalog?.packages || []).filter((pkg) => selectedIds.includes(pkg.id) && (!pkg.installed || pkg.updateAvailable)).length} ready to install/update
          </span>
          <div>
            <button className="hd-btn" type="button" onClick={() => setSelectedIds([])}>Clear</button>
            <button
              className="hd-btn hd-btn--danger"
              type="button"
              disabled={!managerAgentReady || Boolean(activeJob && !["complete", "failed"].includes(activeJob.status)) || !(catalog?.packages || []).some((pkg) => selectedIds.includes(pkg.id) && pkg.installed)}
              onClick={() => void uninstall(selectedIds)}
            >
              Uninstall selected
            </button>
            <button
              className="hd-btn hd-btn--primary"
              type="button"
              disabled={!managerAgentReady || Boolean(activeJob && !["complete", "failed"].includes(activeJob.status)) || !(catalog?.packages || []).some((pkg) => selectedIds.includes(pkg.id) && (!pkg.installed || pkg.updateAvailable))}
              onClick={() => void startBulkInstall(selectedIds)}
            >
              Install/update selected
            </button>
          </div>
        </div>
      ) : null}

      {editingLogo ? (
        <article className="hd-manager-logo-editor">
          <header>
            <div>
              <div className="hd-settings__kicker">Widget branding</div>
              <strong>{editingLogo.name} logo</strong>
            </div>
            <button className="hd-btn hd-btn--sm" type="button" onClick={() => setEditingLogo(null)}>
              Close
            </button>
          </header>
          <div className="hd-manager-logo-editor__body">
            <Brand
              pkg={editingLogo}
              customLogo={logoDraft}
              defaultLogo={defaultLogo}
            />
            <input
              type="url"
              inputMode="url"
              aria-label={`${editingLogo.name} logo URL`}
              placeholder="https://… or /icons/example.png"
              value={logoDraft}
              onChange={(event) => setLogoDraft(event.target.value)}
            />
            <button
              className="hd-btn hd-btn--primary"
              type="button"
              disabled={logoBusy}
              onClick={() => void persistLogo(editingLogo, logoDraft.trim())}
            >
              {logoBusy ? "Saving…" : "Save URL"}
            </button>
            <button
              className="hd-btn"
              type="button"
              disabled={logoBusy}
              onClick={() => logoFileRef.current?.click()}
            >
              Upload image
            </button>
            <input
              ref={logoFileRef}
              type="file"
              accept="image/png,image/jpeg,image/webp,image/gif,image/svg+xml,image/x-icon,.ico"
              hidden
              onChange={(event) => void uploadLogo(event.target.files?.[0])}
            />
            <button
              className="hd-btn"
              type="button"
              disabled={logoBusy || !savedIcons[editingLogo.id]}
              onClick={() => void persistLogo(editingLogo, "")}
            >
              Use default
            </button>
          </div>
          <p>
            Upload an image or enter a URL. Saving updates this manager, the Widget Encyclopedia,
            and the corresponding widget details page.
          </p>
          {logoMessage ? <div className="hd-manager-logo-editor__message">{logoMessage}</div> : null}
        </article>
      ) : null}

      <div className="hd-manager-grid">
        {packages.map((pkg) => {
          const busy =
            Boolean(activeJob) &&
            activeJob?.status !== "complete" &&
            activeJob?.status !== "failed";
          const action = pkg.updateAvailable ? "Update" : pkg.installed ? "Repair" : "Install";
          return (
            <article key={pkg.id} className={`hd-manager-card${selectedIds.includes(pkg.id) ? " is-selected" : ""}`}>
              <label className="hd-manager-card__select">
                <input
                  type="checkbox"
                  checked={selectedIds.includes(pkg.id)}
                  onChange={() => toggleSelected(pkg.id)}
                />
                <span>Select {pkg.name}</span>
              </label>
              <header>
                <Brand pkg={pkg} customLogo={savedIcons[pkg.id]} defaultLogo={defaultLogo} />
                <div>
                  <strong>{pkg.name}</strong>
                  <span>{pkg.id}</span>
                </div>
                <em className={pkg.installed ? "is-installed" : ""}>
                  {pkg.updateAvailable ? "Update" : pkg.installed ? "Installed" : "Available"}
                </em>
              </header>
              <div className="hd-manager-card__meta">
                <span>
                  {pkg.installed
                    ? `Installed v${pkg.installedVersion}`
                    : `Package v${pkg.version}`}
                  {pkg.updateAvailable ? ` · v${pkg.version} available` : ""}
                </span>
                {pkg.custom ? (
                  <span>Custom widget</span>
                ) : (
                  <>
                    <span>{Math.ceil(pkg.bytes / 1024)} KB</span>
                    <span>{pkg.sourceFiles} files</span>
                  </>
                )}
              </div>
              {pkg.custom ? null : <code title={pkg.sha256}>{pkg.sha256.slice(0, 16)}…</code>}
              <div className="hd-manager-card__actions">
                <button
                  className="hd-btn hd-btn--sm"
                  type="button"
                  onClick={() => openLogoEditor(pkg)}
                >
                  Logo
                </button>
                {pkg.custom ? null : (
                  <>
                    <a className="hd-btn hd-btn--sm" href={pkg.guideUrl} target="_blank" rel="noreferrer">
                      Guide
                    </a>
                    <a className="hd-btn hd-btn--sm" href={pkg.downloadUrl} download>
                      Download
                    </a>
                  </>
                )}
                {pkg.installed ? (
                  <button
                    className="hd-btn hd-btn--sm hd-btn--danger"
                    type="button"
                    disabled={!managerAgentReady || busy}
                    onClick={() => void uninstall([pkg.id])}
                  >
                    Uninstall
                  </button>
                ) : null}
                {pkg.custom ? null : (
                  <button
                    className="hd-btn hd-btn--sm hd-btn--primary"
                    type="button"
                    disabled={!catalog?.agent.ok || busy}
                    onClick={() => void install(pkg)}
                  >
                    {action}
                  </button>
                )}
              </div>
            </article>
          );
        })}
      </div>

      {packageModalOpen && typeof document !== "undefined"
        ? createPortal(
            <div className="hd-modal-scrim" role="presentation" onClick={closePackageModal}>
              <div
                className="hd-modal hd-modal--package-upload"
                role="dialog"
                aria-modal="true"
                aria-labelledby="hd-package-upload-title"
                onClick={(event) => event.stopPropagation()}
              >
                <header className="hd-modal__head">
                  <div>
                    <div className="hd-settings__kicker">Local Package Installer</div>
                    <h2 id="hd-package-upload-title">Upload widget package</h2>
                    <p>
                      Install one or more downloaded <code>.hdwidget</code> packages from the Homedash website.
                    </p>
                  </div>
                  <button className="hd-btn" type="button" disabled={packageBusy} onClick={closePackageModal}>Close</button>
                </header>

                <button
                  className={`hd-package-dropzone${packageQueue.length ? " has-file" : ""}`}
                  type="button"
                  disabled={packageBusy || packageQueue.length >= MAX_QUEUED_PACKAGES}
                  onClick={() => packageFileRef.current?.click()}
                  onDragOver={(event) => {
                    if (packageBusy) return;
                    event.preventDefault();
                  }}
                  onDrop={(event) => {
                    if (packageBusy) return;
                    event.preventDefault();
                    queueFiles(event.dataTransfer.files);
                  }}
                >
                  <span className="hd-package-dropzone__icon" aria-hidden>{packageQueue.length ? "✓" : "⇧"}</span>
                  <strong>
                    {packageQueue.length
                      ? `${packageQueue.length} package${packageQueue.length === 1 ? "" : "s"} queued`
                      : "Choose widget packages"}
                  </strong>
                  <span>
                    {packageQueue.length >= MAX_QUEUED_PACKAGES
                      ? `Queue full · up to ${MAX_QUEUED_PACKAGES} packages at a time`
                      : packageQueue.length
                        ? "Drop or choose more .hdwidget files to add to the queue"
                        : `.hdwidget files up to 25 MB · up to ${MAX_QUEUED_PACKAGES} at a time`}
                  </span>
                </button>
                <input
                  ref={packageFileRef}
                  type="file"
                  accept=".hdwidget,application/gzip,application/x-gzip"
                  multiple
                  hidden
                  onChange={(event) => {
                    queueFiles(event.target.files);
                    event.target.value = "";
                  }}
                />

                {packageQueue.length ? (
                  <ul className="hd-package-queue">
                    {packageQueue.map((item) => (
                      <li key={item.id} className="hd-package-queue__item">
                        <span className="hd-package-queue__name" title={item.file.name}>{item.file.name}</span>
                        <span className="hd-package-queue__size">
                          {Math.max(1, Math.ceil(item.file.size / 1024))} KB
                        </span>
                        <button
                          className="hd-package-queue__remove"
                          type="button"
                          disabled={packageBusy}
                          aria-label={`Remove ${item.file.name} from the install queue`}
                          onClick={() => removeQueuedPackage(item.id)}
                        >
                          ×
                        </button>
                      </li>
                    ))}
                  </ul>
                ) : null}

                <div className="hd-package-security">
                  <strong>Verified installation</strong>
                  <p>
                    Homedash checks each archive, checksum, package identity, compatible version,
                    file paths, and credential exclusions before backing up source and rebuilding once
                    for the whole queue.
                  </p>
                </div>
                {packageError ? <div className="hd-manager-error">{packageError}</div> : null}

                <footer className="hd-quick-link-form__footer">
                  <span />
                  <div>
                    <button className="hd-btn" type="button" disabled={packageBusy} onClick={closePackageModal}>Cancel</button>
                    <button
                      className="hd-btn hd-btn--primary"
                      type="button"
                      disabled={!packageQueue.length || packageBusy}
                      onClick={() => void installQueuedPackages()}
                    >
                      {packageBusy
                        ? "Verifying…"
                        : packageQueue.length > 1
                          ? `Verify & install ${packageQueue.length} packages`
                          : "Verify & install"}
                    </button>
                  </div>
                </footer>
              </div>
            </div>,
            document.body,
          )
        : null}
    </section>
  );
}
