"use client";

import { useEffect } from "react";
import { DeferredWidget } from "@/components/DeferredWidget";
import { WidgetFrame } from "@/components/WidgetFrame";
import { iconForWidget } from "@/lib/widget-icons";
import { installWidgetPreviewDemo } from "@/lib/widget-preview-demo";
import { getWidget } from "@/widgets/registry";

const IPV4 = /\b(?:\d{1,3}\.){3}\d{1,3}\b/g;
const IPV6 = /\b(?:(?:[a-f0-9]{1,4}:){3,7}[a-f0-9]{0,4}|[a-f0-9]{0,4}::[a-f0-9:]*)\b/gi;
const PREVIEW_INSTANCES: Record<string, string> = {
  "proxmox-nodes": "proxmox-nodes--lnv1",
};

function redactNetworkAddresses(root: Element) {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  let node = walker.nextNode();
  while (node) {
    const value = node.nodeValue || "";
    const redacted = value.replace(IPV4, "[PRIVATE HOST]").replace(IPV6, "[PRIVATE HOST]");
    if (redacted !== value) node.nodeValue = redacted;
    node = walker.nextNode();
  }
}

export function WidgetPreviewStage({ widgetId }: { widgetId: string }) {
  installWidgetPreviewDemo(widgetId);
  const widget = getWidget(widgetId);

  useEffect(() => {
    const root = document.querySelector(`[data-preview-widget="${CSS.escape(widgetId)}"]`);
    if (!root) return;
    const scrub = () => redactNetworkAddresses(root);
    const observer = new MutationObserver(scrub);
    observer.observe(root, { childList: true, subtree: true, characterData: true });
    scrub();
    const timer = window.setTimeout(() => {
      scrub();
      document.documentElement.dataset.previewReady = "true";
    }, 8000);
    return () => {
      observer.disconnect();
      window.clearTimeout(timer);
    };
  }, [widgetId]);

  if (!widget) return null;
  const { manifest } = widget;
  const instanceId = PREVIEW_INSTANCES[widgetId] || widgetId;
  return (
    <main className="hd-preview-stage">
      <div className="hd-preview-stage__label">
        <span>Homedash widget capture</span>
        <strong>{manifest.name}</strong>
      </div>
      <div className="hd-preview-stage__card" data-preview-widget={widgetId}>
        <WidgetFrame
          manifest={manifest}
          title={manifest.name}
          instanceId={instanceId}
          iconUrl={iconForWidget(widgetId)}
          globalAccent="rainbow"
          themeAccent="#43e5ff"
        >
          <DeferredWidget widgetId={widgetId} load={widget.load} rootMargin="1000px" />
        </WidgetFrame>
      </div>
    </main>
  );
}
