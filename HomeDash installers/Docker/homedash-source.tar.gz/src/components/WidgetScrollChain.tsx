"use client";

import { useEffect } from "react";

const EDGE_EPS = 1.5;

function isScrollableY(el: HTMLElement) {
  const style = window.getComputedStyle(el);
  const overflowY = style.overflowY;
  return overflowY === "auto" || overflowY === "scroll" || overflowY === "overlay";
}

function contentOverflowsY(el: HTMLElement) {
  return el.scrollHeight > el.clientHeight + EDGE_EPS;
}

/**
 * Always-on wheel handoff: if the pointer is over a widget scrollport that has
 * nothing left to scroll (empty or at an edge), continue scrolling the page.
 * Fixes Proxmox `.pve-body` and similar overflow:auto traps that eat the wheel.
 */
export function WidgetScrollChain({ enabled = true }: { enabled?: boolean }) {
  useEffect(() => {
    if (!enabled) return;

    const onWheel = (event: WheelEvent) => {
      if (event.defaultPrevented || event.ctrlKey) return;
      const target = event.target as Element | null;
      if (!target?.closest) return;

      const widget = target.closest(".react-grid-item .hd-widget") as HTMLElement | null;
      if (!widget) return;

      // Skip while interacting with form controls / dialogs inside the widget.
      if (target.closest("input, textarea, select, [contenteditable='true'], .pve-term-backdrop, [role='dialog']")) {
        return;
      }

      let node: Element | null = target;
      let trap: HTMLElement | null = null;
      let scrollable: HTMLElement | null = null;
      const hasPinnedLists = Boolean(
        widget.querySelector(".pve-ov-scroll, .pve-g-list, .pve-st-list, .pve-hw-scroll"),
      );

      while (node && node instanceof HTMLElement && widget.contains(node)) {
        if (isScrollableY(node)) {
          const isOuterChrome =
            node.classList.contains("hd-widget-body") ||
            node.classList.contains("pve-shell") ||
            (hasPinnedLists && node.classList.contains("pve-body"));

          if (contentOverflowsY(node) && !isOuterChrome) {
            scrollable = node;
            break;
          }
          if (!isOuterChrome && !contentOverflowsY(node)) {
            // overflow:auto/scroll but no content overflow — classic wheel trap
            trap = node;
          }
        }
        if (node === widget) break;
        node = node.parentElement;
      }

      if (scrollable) {
        const atTop = scrollable.scrollTop <= EDGE_EPS;
        const atBottom =
          scrollable.scrollTop + scrollable.clientHeight >= scrollable.scrollHeight - EDGE_EPS;
        if ((event.deltaY > 0 && atBottom) || (event.deltaY < 0 && atTop)) {
          window.scrollBy({ top: event.deltaY, left: 0, behavior: "auto" });
          event.preventDefault();
        }
        return;
      }

      if (trap) {
        window.scrollBy({ top: event.deltaY, left: 0, behavior: "auto" });
        event.preventDefault();
      }
    };

    document.addEventListener("wheel", onWheel, { capture: true, passive: false });
    return () => document.removeEventListener("wheel", onWheel, true);
  }, [enabled]);

  return null;
}
