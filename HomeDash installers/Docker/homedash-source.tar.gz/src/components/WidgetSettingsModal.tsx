"use client";

import { useEffect, useId, useRef, useState, type ReactNode } from "react";
import type {
  BookmarkGroup,
  WidgetAccentMode,
  WidgetChromeSettings,
  WidgetConfigField,
  WidgetManifest,
} from "@/lib/types";
import { fieldsForWidget } from "@/lib/instances";
import { isNodeTitleWidget } from "@/lib/widget-titles";
import { ColorField } from "@/components/ColorField";
import { JellyfinSectionsEditor } from "@/components/JellyfinSectionsEditor";
import { MediaCalendarSourcesEditor } from "@/components/MediaCalendarSourcesEditor";
import { ProxmoxConfigEditor } from "@/components/ProxmoxConfigEditor";
import { WidgetChromeExpand } from "@/components/WidgetChromeExpand";
import { UnsavedChangesDialog } from "@/components/UnsavedChangesDialog";

function fieldClassName(field: WidgetConfigField) {
  const key = field.key.toLowerCase();
  const classes = ["hd-field"];
  const multiline =
    key.includes("json") ||
    key.includes("sections") ||
    key.includes("servers") ||
    key.includes("channels") ||
    key.includes("headers") ||
    key.includes("cookies") ||
    key.includes("query") ||
    key.includes("body");
  const wide =
    multiline ||
    field.type === "url" ||
    field.type === "color" ||
    key.includes("url") ||
    key.includes("endpoint") ||
    key.includes("path") ||
    key === "color" ||
    key.endsWith("color");
  const mono =
    multiline ||
    key.includes("json") ||
    key.includes("apikey") ||
    key.includes("token") ||
    key.includes("secret") ||
    key.includes("userid");

  if (wide) classes.push("hd-field--wide");
  if (multiline) classes.push("hd-field--multiline");
  if (mono) classes.push("hd-field--mono");
  return classes.join(" ");
}

function fieldIsMultiline(field: WidgetConfigField) {
  const key = field.key.toLowerCase();
  return (
    key.includes("json") ||
    key.includes("sections") ||
    key.includes("servers") ||
    key.includes("channels") ||
    key.includes("headers") ||
    key.includes("cookies")
  );
}

function WidgetLogoField({
  id,
  label = "Logo",
  value,
  defaultIcon,
  onChange,
  onUploaded,
  onBrowse,
}: {
  id: string;
  label?: string;
  value: string;
  defaultIcon: string | null;
  onChange: (value: string) => void;
  onUploaded: (message: string) => void;
  onBrowse: () => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");
  const preview = value.trim() || defaultIcon || "";

  async function onFile(file: File | undefined) {
    if (!file) return;
    setError("");
    if (file.size > 25 * 1024 * 1024) {
      setError("File exceeds the 25 MB limit");
      return;
    }
    setUploading(true);
    try {
      const body = new FormData();
      body.set("kind", "widget-icon");
      body.set("key", id);
      body.set("file", file);
      const res = await fetch("/api/uploads", { method: "POST", body });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Upload failed");
      onChange(String(data.url || ""));
      onUploaded("Widget logo uploaded");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setUploading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  return (
    <div className="hd-widget-logo">
      <div className="hd-widget-logo__label">
        <span>{label}</span>
        <a href="https://dashboardicons.com/icons" target="_blank" rel="noopener noreferrer">
          Browse Dashboard Icons
        </a>
      </div>
      <div className="hd-widget-logo__row">
        <span className="hd-widget-logo__preview" aria-hidden="true">
          {preview ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={preview} alt="" />
          ) : (
            <span>?</span>
          )}
        </span>
        <input
          className="hd-widget-logo__input"
          type="text"
          inputMode="url"
          placeholder="Paste icon URL or dashboardicons slug"
          value={value}
          onChange={(e) => onChange(e.target.value)}
        />
      </div>
      <div className="hd-widget-logo__actions">
        <button className="hd-btn hd-btn--sm" type="button" onClick={onBrowse}>
          Pick icon
        </button>
        <button
          className="hd-btn hd-btn--sm"
          type="button"
          disabled={uploading}
          onClick={() => inputRef.current?.click()}
        >
          {uploading ? "Uploading…" : "Upload"}
        </button>
        {value ? (
          <button className="hd-btn hd-btn--sm" type="button" onClick={() => onChange("")}>
            Reset
          </button>
        ) : null}
        <input
          ref={inputRef}
          type="file"
          accept="image/png,image/jpeg,image/webp,image/gif,image/svg+xml,image/x-icon,.ico"
          hidden
          onChange={(e) => onFile(e.target.files?.[0])}
        />
      </div>
      <div className="hd-asset-hint">
        Use{" "}
        <a href="https://dashboardicons.com/icons" target="_blank" rel="noopener noreferrer">
          dashboardicons.com
        </a>{" "}
        or upload your own image · max 25 MB
      </div>
      {error ? <div className="hd-asset-error">{error}</div> : null}
    </div>
  );
}

export type WidgetSettingsInstance = {
  id: string;
  widgetId: string;
  key: string;
  label: string;
};

export function WidgetSettingsModal({
  widget,
  instance,
  isMultiCard,
  canRemove,
  bookmarkGroups,
  config,
  showIcon,
  showTitle,
  expand,
  accentMode,
  accentColor,
  storedIcon,
  defaultIcon,
  brandMark,
  escapeDisabled = false,
  onClose,
  onRename,
  onUpdateField,
  onPatchConfig,
  onUpdateChrome,
  onUpdateAccent,
  onUpdateIcon,
  onUploaded,
  onBrowseIcon,
  onRemove,
}: {
  widget: WidgetManifest;
  instance: WidgetSettingsInstance;
  isMultiCard: boolean;
  canRemove: boolean;
  bookmarkGroups: BookmarkGroup[];
  config: Record<string, string>;
  showIcon: boolean;
  showTitle: boolean;
  expand: WidgetChromeSettings["expand"];
  accentMode: WidgetAccentMode;
  accentColor: string;
  storedIcon: string;
  defaultIcon: string | null;
  brandMark: ReactNode;
  escapeDisabled?: boolean;
  onClose: () => void;
  onRename: (label: string) => void;
  onUpdateField: (key: string, value: string) => void;
  onPatchConfig: (patch: Record<string, string>) => void;
  onUpdateChrome: (patch: Partial<WidgetChromeSettings>) => void;
  onUpdateAccent: (mode: WidgetAccentMode, color?: string) => void;
  onUpdateIcon: (url: string) => void;
  onUploaded: (message: string) => void;
  onBrowseIcon: () => void;
  onRemove: () => void;
}) {
  const titleId = useId();
  const initialRef = useRef({
    label: instance.label,
    config: { ...config },
    showIcon,
    showTitle,
    expand,
    accentMode,
    accentColor,
    storedIcon,
  });
  const [confirmClose, setConfirmClose] = useState(false);
  const fields = fieldsForWidget(widget).filter(
    (field) => !(widget.id === "jellyfin-slider"
      && (field.key === "caseView" || field.key === "musicShelf")),
  );
  const aiProvider = config.provider || "openai";
  const aiProviderLabel =
    ({ openai: "ChatGPT", gemini: "Gemini", claude: "Claude", perplexity: "Perplexity" } as Record<string, string>)[aiProvider]
    || "AI provider";
  const aiProviderDefaultIcon =
    ({
      openai: "/icons/ai-openai.svg",
      gemini: "/icons/ai-gemini.svg",
      claude: "/icons/ai-claude.svg",
      perplexity: "/icons/ai-perplexity.svg",
    } as Record<string, string>)[aiProvider] || defaultIcon;
  const hasFields =
    fields.length > 0 || widget.id === "media-calendar" || widget.id === "proxmox-nodes";
  const updateConfigField = (key: string, value: string) => {
    if (widget.id !== "ai-chat") {
      onUpdateField(key, value);
      return;
    }
    const provider = config.provider || "openai";
    if (key === "provider") {
      onPatchConfig({
        [`${provider}ApiKey`]: config.apiKey || "",
        [`${provider}Model`]: config.model || "",
        [`${provider}Enabled`]: config.enabled || "true",
        provider: value,
        apiKey: config[`${value}ApiKey`] || "",
        model: config[`${value}Model`] || "",
        enabled: config[`${value}Enabled`] || "true",
      });
      return;
    }
    if (key === "apiKey" || key === "model" || key === "enabled") {
      onPatchConfig({
        [key]: value,
        [`${provider}${
          key === "apiKey" ? "ApiKey" : key === "model" ? "Model" : "Enabled"
        }`]: value,
      });
      return;
    }
    onUpdateField(key, value);
  };

  const initial = initialRef.current;
  const dirty = JSON.stringify({
    label: instance.label,
    config,
    showIcon,
    showTitle,
    expand,
    accentMode,
    accentColor,
    storedIcon,
  }) !== JSON.stringify(initial);

  function requestClose() {
    if (dirty) setConfirmClose(true);
    else onClose();
  }

  function discardChanges() {
    const resetConfig: Record<string, string> = {};
    for (const key of new Set([...Object.keys(config), ...Object.keys(initial.config)])) {
      resetConfig[key] = initial.config[key] || "";
    }
    onRename(initial.label);
    onPatchConfig(resetConfig);
    onUpdateChrome({ showIcon: initial.showIcon, showTitle: initial.showTitle, expand: initial.expand });
    onUpdateAccent(initial.accentMode, initial.accentColor);
    onUpdateIcon(initial.storedIcon);
    onClose();
  }

  useEffect(() => {
    if (escapeDisabled) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !confirmClose) requestClose();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [escapeDisabled, confirmClose, dirty]);

  return (
    <div className="hd-modal-scrim" role="presentation" onClick={requestClose}>
      <div
        className={`hd-modal hd-widget-settings-modal${
          widget.id === "jellyfin-slider" ? " hd-widget-settings-modal--jellyfin" : ""
        }`}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        onClick={(e) => e.stopPropagation()}
      >
        <header className="hd-modal__head">
          <div className="hd-widget-settings-modal__title">
            {brandMark}
            <div>
              <div className="hd-settings__kicker">{widget.name}</div>
              <h2 id={titleId}>{isMultiCard ? instance.label || widget.name : widget.name}</h2>
              <p>Edit credentials and appearance. Changes apply when you Save settings.</p>
            </div>
          </div>
        </header>

        <div className="hd-widget-settings-modal__body">
          {isMultiCard ? (
            <div className="hd-widget-settings-modal__section">
              <div className="hd-field hd-field--wide">
                <label htmlFor={`${instance.id}-settings-title`}>Widget title</label>
                <input
                  id={`${instance.id}-settings-title`}
                  type="text"
                  value={instance.label}
                  placeholder="Widget title"
                  onChange={(e) => onRename(e.target.value)}
                />
                {widget.id === "jellyfin-slider" || widget.id === "plex-slider" ? (
                  <span className="hd-widget-card__title-hint">
                    Shown on the dashboard (e.g. whose Jellyfin this is)
                  </span>
                ) : null}
                {widget.id === "bookmarks" ? (
                  <span className="hd-widget-card__title-hint">
                    Title follows the bookmark group below
                  </span>
                ) : null}
                {isNodeTitleWidget(widget.id) ? (
                  <span className="hd-widget-card__title-hint">
                    Title follows PVE ID below (e.g. {widget.name} - PVE1)
                  </span>
                ) : null}
              </div>
            </div>
          ) : null}

          <div className="hd-widget-settings-modal__section">
            <WidgetLogoField
              id={widget.id === "ai-chat" ? `${instance.id}-${aiProvider}` : instance.id}
              label={widget.id === "ai-chat" ? `${aiProviderLabel} logo` : "Logo"}
              value={widget.id === "ai-chat" ? config[`${aiProvider}Logo`] || "" : storedIcon}
              defaultIcon={widget.id === "ai-chat" ? aiProviderDefaultIcon : defaultIcon}
              onChange={widget.id === "ai-chat"
                ? (url) => onPatchConfig({ [`${aiProvider}Logo`]: url })
                : onUpdateIcon}
              onUploaded={onUploaded}
              onBrowse={onBrowseIcon}
            />
            <div className="hd-widget-card__chrome">
              <div className="hd-widget-card__chrome-toggle">
                <span className="hd-widget-card__chrome-label" id={`${instance.id}-chrome-logo`}>
                  Show logo
                </span>
                <label className="hd-switch" title={showIcon ? "On" : "Off"}>
                  <input
                    type="checkbox"
                    checked={showIcon}
                    aria-labelledby={`${instance.id}-chrome-logo`}
                    onChange={(e) => onUpdateChrome({ showIcon: e.target.checked })}
                  />
                  <span />
                </label>
              </div>
              <div className="hd-widget-card__chrome-toggle">
                <span className="hd-widget-card__chrome-label" id={`${instance.id}-chrome-title`}>
                  Show title
                </span>
                <label className="hd-switch" title={showTitle ? "On" : "Off"}>
                  <input
                    type="checkbox"
                    checked={showTitle}
                    aria-labelledby={`${instance.id}-chrome-title`}
                    onChange={(e) => onUpdateChrome({ showTitle: e.target.checked })}
                  />
                  <span />
                </label>
              </div>
              <WidgetChromeExpand
                idPrefix={instance.id}
                expand={expand}
                onChange={(next) => onUpdateChrome({ expand: next === false ? false : next })}
              />
              {widget.id === "jellyfin-slider" ? (
                <>
                  <div className="hd-widget-card__chrome-toggle">
                    <span className="hd-widget-card__chrome-label" id={`${instance.id}-case-view`}>
                      Case View
                    </span>
                    <label className="hd-switch" title={config.caseView === "true" ? "On" : "Off"}>
                      <input
                        type="checkbox"
                        checked={config.caseView === "true"}
                        aria-labelledby={`${instance.id}-case-view`}
                        onChange={(e) => {
                          const caseView = e.target.checked ? "true" : "false";
                          onUpdateField("caseView", caseView);
                          void fetch(`/api/widgets/${encodeURIComponent(instance.id)}/config`, {
                            method: "PUT",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ ...config, caseView }),
                          }).then((response) => {
                            if (!response.ok) return;
                            window.dispatchEvent(new CustomEvent("homedash:widget-config-saved", {
                              detail: { instanceId: instance.id, caseView: caseView === "true" },
                            }));
                          });
                        }}
                      />
                      <span />
                    </label>
                  </div>
                  <div className="hd-widget-card__chrome-toggle">
                    <label className="hd-widget-card__chrome-label" htmlFor={`${instance.id}-case-speed`}>
                      Case speed
                    </label>
                    <select
                      id={`${instance.id}-case-speed`}
                      value={config.caseViewSpeed || "520"}
                      disabled={config.caseView !== "true"}
                      onChange={(e) => {
                        const caseViewSpeed = e.target.value;
                        onUpdateField("caseViewSpeed", caseViewSpeed);
                        void fetch(`/api/widgets/${encodeURIComponent(instance.id)}/config`, {
                          method: "PUT",
                          headers: { "Content-Type": "application/json" },
                          body: JSON.stringify({ ...config, caseViewSpeed }),
                        }).then((response) => {
                          if (!response.ok) return;
                          window.dispatchEvent(new CustomEvent("homedash:widget-config-saved", {
                            detail: { instanceId: instance.id, caseViewSpeed: Number(caseViewSpeed) },
                          }));
                        });
                      }}
                    >
                      <option value="200">Fast</option>
                      <option value="350">Quick</option>
                      <option value="520">Normal</option>
                      <option value="750">Smooth</option>
                      <option value="1000">Slow</option>
                    </select>
                  </div>
                  <div className="hd-widget-card__chrome-toggle">
                    <span className="hd-widget-card__chrome-label" id={`${instance.id}-music-shelf`}>
                      Shelf
                    </span>
                    <label className="hd-switch" title={config.musicShelf === "true" ? "On" : "Off"}>
                      <input
                        type="checkbox"
                        checked={config.musicShelf === "true"}
                        disabled={config.caseView !== "true"}
                        aria-labelledby={`${instance.id}-music-shelf`}
                        onChange={(e) => {
                          const musicShelf = e.target.checked ? "true" : "false";
                          onUpdateField("musicShelf", musicShelf);
                          void fetch(`/api/widgets/${encodeURIComponent(instance.id)}/config`, {
                            method: "PUT",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ ...config, musicShelf }),
                          }).then((response) => {
                            if (!response.ok) return;
                            window.dispatchEvent(new CustomEvent("homedash:widget-config-saved", {
                              detail: {
                                instanceId: instance.id,
                                musicShelf: musicShelf === "true",
                              },
                            }));
                          });
                        }}
                      />
                      <span />
                    </label>
                  </div>
                </>
              ) : null}
            </div>
          </div>

          {hasFields ? (
            <div className="hd-widget-settings-modal__section">
              <div className="hd-settings__kicker">Connection</div>
              <div className="hd-widget-card__fields">
                {fields.map((field) => {
                  const multiline = fieldIsMultiline(field);
                  const value = config[field.key] || "";
                  const isBookmarkGroup = widget.id === "bookmarks" && field.key === "groupId";
                  const isColor = field.type === "color";
                  return (
                    <div className={fieldClassName(field)} key={field.key}>
                      {isColor ? (
                        <ColorField
                          id={`${instance.id}-${field.key}`}
                          label={field.label}
                          value={value}
                          placeholder={field.placeholder || "#22c55e"}
                          allowEmpty
                          onChange={(next) => updateConfigField(field.key, next)}
                        />
                      ) : (
                        <>
                          <label htmlFor={`${instance.id}-${field.key}`}>{field.label}</label>
                          {isBookmarkGroup ? (
                            <select
                              id={`${instance.id}-${field.key}`}
                              value={value}
                              onChange={(e) => updateConfigField(field.key, e.target.value)}
                            >
                              <option value="">All bookmarks</option>
                              {bookmarkGroups.map((group) => (
                                <option key={group.id} value={group.id}>
                                  {group.name}
                                </option>
                              ))}
                            </select>
                          ) : multiline ? (
                            <textarea
                              id={`${instance.id}-${field.key}`}
                              rows={4}
                              placeholder={field.placeholder}
                              spellCheck={false}
                              value={value}
                              onChange={(e) => updateConfigField(field.key, e.target.value)}
                            />
                          ) : field.type === "select" && field.options?.length ? (
                            <select
                              id={`${instance.id}-${field.key}`}
                              value={value}
                              onChange={(e) => updateConfigField(field.key, e.target.value)}
                            >
                              {!field.required ? <option value="">—</option> : null}
                              {field.options.map((opt) => (
                                <option key={opt.value} value={opt.value}>
                                  {opt.label}
                                </option>
                              ))}
                            </select>
                          ) : (
                            <input
                              id={`${instance.id}-${field.key}`}
                              type={
                                field.type === "password"
                                  ? "password"
                                  : field.type === "number"
                                    ? "number"
                                    : field.type === "url"
                                      ? "url"
                                      : "text"
                              }
                              placeholder={field.placeholder}
                              autoComplete="off"
                              spellCheck={false}
                              value={value}
                              onChange={(e) => updateConfigField(field.key, e.target.value)}
                            />
                          )}
                        </>
                      )}
                    </div>
                  );
                })}

                {widget.id === "jellyfin-slider" ? (
                  <div className="hd-field hd-field--wide">
                    <JellyfinSectionsEditor
                      value={config.sectionsJson || ""}
                      onChange={(sectionsJson) => {
                        onPatchConfig({
                          sectionsJson,
                          serversJson: "",
                        });
                      }}
                    />
                  </div>
                ) : null}

                {widget.id === "media-calendar" ? (
                  <div className="hd-field hd-field--wide">
                    <MediaCalendarSourcesEditor value={config} onChange={onPatchConfig} />
                  </div>
                ) : null}

                {widget.id === "proxmox-nodes" ? (
                  <div className="hd-field hd-field--wide">
                    <ProxmoxConfigEditor value={config} onChange={onPatchConfig} />
                  </div>
                ) : null}
              </div>
            </div>
          ) : null}

          <div className="hd-widget-settings-modal__section">
            <div className="hd-settings__kicker">Accent</div>
            <footer className="hd-widget-card__foot">
              <label className="hd-widget-card__accent-label" htmlFor={`${instance.id}-accent`}>
                Accent
              </label>
              <select
                id={`${instance.id}-accent`}
                className="hd-widget-card__accent-select"
                value={accentMode}
                onChange={(e) => onUpdateAccent(e.target.value as WidgetAccentMode)}
              >
                <option value="inherit">Inherit</option>
                <option value="rainbow">Rainbow</option>
                <option value="solid">Solid</option>
                <option value="off">Off</option>
              </select>
              {accentMode === "solid" ? (
                <input
                  id={`${instance.id}-accent-color`}
                  className="hd-widget-card__accent-color"
                  type="color"
                  aria-label="Accent color"
                  value={accentColor}
                  onChange={(e) => onUpdateAccent("solid", e.target.value)}
                />
              ) : null}
            </footer>
          </div>
        </div>

        <footer className="hd-widget-settings-modal__foot">
          {canRemove ? (
            <button
              type="button"
              className="hd-btn hd-chip--danger"
              onClick={() => {
                onRemove();
                onClose();
              }}
            >
              Remove server
            </button>
          ) : (
            <span />
          )}
          <button type="button" className="hd-btn hd-btn--primary" onClick={requestClose}>
            Done
          </button>
        </footer>
      </div>
      <UnsavedChangesDialog
        open={confirmClose}
        onSave={onClose}
        onDiscard={discardChanges}
        onKeepEditing={() => setConfirmClose(false)}
      />
    </div>
  );
}
