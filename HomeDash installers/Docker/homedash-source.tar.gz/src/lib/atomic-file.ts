import { promises as fs } from "fs";
import path from "path";
import { randomBytes } from "crypto";

/** Write a complete file beside its destination, then replace it atomically. */
export async function atomicWriteFile(filePath: string, contents: string): Promise<void> {
  const suffix = `${process.pid}-${Date.now()}-${randomBytes(4).toString("hex")}`;
  const temporaryPath = path.join(path.dirname(filePath), `.${path.basename(filePath)}.${suffix}.tmp`);
  try {
    await fs.writeFile(temporaryPath, contents, "utf8");
    let lastError: unknown;
    for (let attempt = 0; attempt < 4; attempt += 1) {
      try {
        await fs.rename(temporaryPath, filePath);
        return;
      } catch (error) {
        lastError = error;
        const code = (error as NodeJS.ErrnoException)?.code;
        const transient = code === "EBUSY" || code === "EPERM" || code === "EACCES";
        if (!transient || attempt === 3) throw error;
        await new Promise((resolve) => setTimeout(resolve, 40 * (attempt + 1)));
      }
    }
    throw lastError;
  } catch (error) {
    await fs.unlink(temporaryPath).catch(() => undefined);
    throw error;
  }
}

export async function atomicWriteJson(filePath: string, value: unknown): Promise<void> {
  await atomicWriteFile(filePath, JSON.stringify(value, null, 2));
}
