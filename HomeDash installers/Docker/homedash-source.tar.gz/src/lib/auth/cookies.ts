import { cookies } from "next/headers";
import {
  SESSION_COOKIE,
  SESSION_TTL_SECONDS,
  createSessionPayload,
  getSessionSecret,
  openSession,
  sealSession,
  type SessionPayload,
} from "@/lib/auth";

export function sessionCookieOptions(secure: boolean) {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    path: "/",
    secure,
    maxAge: SESSION_TTL_SECONDS,
  };
}

export function isRequestSecure(request: Request): boolean {
  const proto = request.headers.get("x-forwarded-proto");
  if (proto) return proto.split(",")[0]?.trim() === "https";
  try {
    return new URL(request.url).protocol === "https:";
  } catch {
    return false;
  }
}

export async function readSessionFromCookies(): Promise<SessionPayload | null> {
  const secret = await getSessionSecret();
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  return openSession(secret, token);
}

export async function buildSessionToken(user: {
  id: string;
  username: string;
  role: SessionPayload["role"];
  permissions?: SessionPayload["permissions"];
  restrictedTabIds?: string[];
  restrictedWidgetIds?: string[];
  restrictedLayoutTabIds?: string[];
  mustChangePassword?: boolean;
}): Promise<string> {
  const secret = await getSessionSecret();
  const payload = createSessionPayload({
    sub: user.id,
    username: user.username,
    role: user.role,
    permissions: user.permissions,
    restrictedTabIds: user.restrictedTabIds,
    restrictedWidgetIds: user.restrictedWidgetIds,
    restrictedLayoutTabIds: user.restrictedLayoutTabIds,
    mustChangePassword: user.mustChangePassword,
  });
  return sealSession(secret, payload);
}
