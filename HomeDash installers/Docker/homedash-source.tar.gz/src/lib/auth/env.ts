/** Edge-safe: session secret must be provided via env (entrypoint seeds it). */
export function getSessionSecretSync(): string {
  return process.env.HOMEDASH_SESSION_SECRET?.trim() || "";
}
