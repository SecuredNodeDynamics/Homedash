export interface SessionLike {
  role: string;
  permissions?: string[];
}

export function hasPermission(session: SessionLike, permission: string) {
  return (
    session.role === "admin" ||
    session.permissions?.includes("*") ||
    session.permissions?.includes(permission)
  );
}
