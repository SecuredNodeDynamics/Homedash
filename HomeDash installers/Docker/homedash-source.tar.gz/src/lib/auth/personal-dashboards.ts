import type { AppSettings, DashboardTab, LayoutConfig } from "../types";
import type { AuthUser } from "./types";

export function personalTabs(user: AuthUser | undefined): DashboardTab[] {
  return Array.isArray(user?.personalTabs) ? user.personalTabs : [];
}

export function visiblePersonalTabs(
  user: AuthUser | undefined,
  allUsers?: AuthUser[],
): DashboardTab[] {
  if (user?.role === "admin" && allUsers) {
    return allUsers.flatMap((entry) => personalTabs(entry));
  }
  return personalTabs(user);
}

export function personalTabOwner(
  tabId: string,
  user: AuthUser | undefined,
  allUsers?: AuthUser[],
): AuthUser | undefined {
  if (user?.personalTabs?.some((tab) => tab.id === tabId)) return user;
  if (user?.role === "admin" && allUsers) {
    return allUsers.find((entry) => entry.personalTabs?.some((tab) => tab.id === tabId));
  }
  return undefined;
}

export function withPersonalTabs(
  settings: AppSettings,
  user: AuthUser | undefined,
  allUsers?: AuthUser[],
): AppSettings {
  const owned = visiblePersonalTabs(user, allUsers);
  if (!owned.length) return settings;
  const combined = [...settings.tabs, ...owned];
  const order = Array.isArray(user?.personalTabOrder) ? user.personalTabOrder : [];
  if (!order.length) return { ...settings, tabs: combined };
  const rank = new Map(order.map((id, index) => [id, index]));
  return {
    ...settings,
    tabs: combined
      .map((tab, originalIndex) => ({ tab, originalIndex }))
      .sort((a, b) => {
        const ar = rank.get(a.tab.id);
        const br = rank.get(b.tab.id);
        if (ar != null && br != null) return ar - br;
        if (ar != null) return -1;
        if (br != null) return 1;
        return a.originalIndex - b.originalIndex;
      })
      .map(({ tab }, index) => ({ ...tab, order: index })),
  };
}

export function emptyPersonalLayout(): LayoutConfig {
  return { lg: [], md: [], sm: [] };
}
