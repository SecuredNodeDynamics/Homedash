import { normalizeBookmarkGroups, normalizeBookmarks } from "@/lib/bookmarks";
import type { AppSettings, BookmarkGroup, BookmarkItem } from "@/lib/types";
import type { AuthUser } from "@/lib/auth/types";

export function profileBookmarks(
  user: AuthUser,
  fallback: Pick<AppSettings, "bookmarks" | "bookmarkGroups">,
): { bookmarks: BookmarkItem[]; bookmarkGroups: BookmarkGroup[] } {
  const hasStoredCollection =
    Array.isArray(user.personalBookmarks) || Array.isArray(user.personalBookmarkGroups);
  // Older builds could copy the global/admin collection into a standard user's
  // profile when they saved unrelated settings. Do not trust those unmarked
  // legacy values. A collection becomes visible only after that user explicitly
  // saves bookmarks under the isolated storage model.
  const hasPersonalCollection =
    user.role === "admin"
      ? hasStoredCollection
      : user.personalBookmarksIsolated === true && hasStoredCollection;
  // The global collection is retained only as a legacy source for the
  // administrator who originally owned it. Standard users must start with an
  // empty private collection; otherwise an account without saved bookmarks
  // would inherit and expose the administrator's links.
  const useLegacyAdminCollection = user.role === "admin" && !hasPersonalCollection;
  const bookmarkGroups = normalizeBookmarkGroups(
    hasPersonalCollection
      ? user.personalBookmarkGroups
      : useLegacyAdminCollection
        ? fallback.bookmarkGroups
        : [],
  );
  return {
    bookmarkGroups,
    bookmarks: normalizeBookmarks(
      hasPersonalCollection
        ? user.personalBookmarks
        : useLegacyAdminCollection
          ? fallback.bookmarks
          : [],
      bookmarkGroups,
    ),
  };
}
