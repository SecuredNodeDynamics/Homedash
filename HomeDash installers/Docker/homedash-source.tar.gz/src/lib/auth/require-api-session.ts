import { NextResponse } from "next/server";
import { readSessionFromCookies } from "@/lib/auth/cookies";
import { hasPermission } from "@/lib/auth/permissions";

export async function requireApiSession(permission: string) {
  const session = await readSessionFromCookies();

  if (!session) {
    return {
      session: null,
      error: NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 },
      ),
    };
  }

  if (session.mustChangePassword) {
    return {
      session: null,
      error: NextResponse.json(
        { error: "Password change required" },
        { status: 403 },
      ),
    };
  }

  if (!hasPermission(session, permission)) {
    return {
      session: null,
      error: NextResponse.json(
        { error: "Forbidden" },
        { status: 403 },
      ),
    };
  }

  return {
    session,
    error: null,
  };
}