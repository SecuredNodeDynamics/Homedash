import type { AppSettings } from "@/lib/types";
import { parseInstanceId } from "@/lib/instances";
import type { SessionPayload } from "./types";

export function filterSettingsForSession(settings: AppSettings, session: SessionPayload | null): AppSettings {
  if (!session || session.role === "admin") return settings;
  const restrictedTabs = new Set(session.restrictedTabIds || []);
  const restrictedWidgets = new Set(session.restrictedWidgetIds || []);
  if (!restrictedTabs.size && !restrictedWidgets.size) return settings;

  return {
    ...settings,
    tabs: settings.tabs
      .filter((tab) => !restrictedTabs.has(tab.id))
      .map((tab) => ({
        ...tab,
        widgetIds: tab.widgetIds.filter((cardId) => !restrictedWidgets.has(parseInstanceId(cardId).widgetId)),
      })),
    enabledWidgets: settings.enabledWidgets.filter((widgetId) => !restrictedWidgets.has(widgetId)),
    widgetInstances: settings.widgetInstances.filter((instance) => !restrictedWidgets.has(instance.widgetId)),
  };
}
