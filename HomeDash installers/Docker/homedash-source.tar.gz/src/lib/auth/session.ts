import type { SessionPayload } from "./types";
import { SESSION_TTL_SECONDS } from "./types";

function bytesToBase64Url(bytes: ArrayBuffer | Uint8Array): string {
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  let bin = "";
  for (let i = 0; i < u8.length; i++) bin += String.fromCharCode(u8[i]!);
  const b64 = typeof btoa === "function" ? btoa(bin) : Buffer.from(u8).toString("base64");
  return b64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function base64UrlToBytes(value: string): Uint8Array {
  const b64 = value.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((value.length + 3) % 4);
  if (typeof atob === "function") {
    const bin = atob(b64);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  return new Uint8Array(Buffer.from(b64, "base64"));
}

function textEncoder() {
  return new TextEncoder();
}

async function importHmacKey(secret: string): Promise<CryptoKey> {
  return crypto.subtle.importKey(
    "raw",
    textEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"],
  );
}

async function sign(secret: string, data: string): Promise<string> {
  const key = await importHmacKey(secret);
  const sig = await crypto.subtle.sign("HMAC", key, textEncoder().encode(data));
  return bytesToBase64Url(sig);
}

async function verifySig(secret: string, data: string, signature: string): Promise<boolean> {
  const key = await importHmacKey(secret);
  const sigBytes = base64UrlToBytes(signature);
  // subtle.verify expects ArrayBufferView matching algorithm; copy to ensure ArrayBuffer backing
  const copy = new Uint8Array(sigBytes);
  return crypto.subtle.verify("HMAC", key, copy, textEncoder().encode(data));
}

export function createSessionPayload(input: {
  sub: string;
  username: string;
  role: SessionPayload["role"];
  permissions?: SessionPayload["permissions"];
  restrictedTabIds?: string[];
  restrictedWidgetIds?: string[];
  restrictedLayoutTabIds?: string[];
  mustChangePassword?: boolean;
  ttlSeconds?: number;
}): SessionPayload {
  const ttl = input.ttlSeconds ?? SESSION_TTL_SECONDS;
  return {
    sub: input.sub,
    username: input.username,
    role: input.role,
    permissions: input.role === "admin" ? ["*"] : (input.permissions || []),
    restrictedTabIds: input.role === "admin" ? [] : (input.restrictedTabIds || []),
    restrictedWidgetIds: input.role === "admin" ? [] : (input.restrictedWidgetIds || []),
    restrictedLayoutTabIds: input.role === "admin" ? [] : (input.restrictedLayoutTabIds || []),
    mustChangePassword: Boolean(input.mustChangePassword),
    exp: Math.floor(Date.now() / 1000) + ttl,
  };
}

/** Create `payload.signature` token (Edge + Node safe). */
export async function sealSession(secret: string, payload: SessionPayload): Promise<string> {
  const body = bytesToBase64Url(textEncoder().encode(JSON.stringify(payload)));
  const signature = await sign(secret, body);
  return `${body}.${signature}`;
}

/** Verify token and return payload, or null. */
export async function openSession(secret: string, token: string | undefined | null): Promise<SessionPayload | null> {
  if (!token || !secret) return null;
  const dot = token.indexOf(".");
  if (dot <= 0 || dot === token.length - 1) return null;
  const body = token.slice(0, dot);
  const signature = token.slice(dot + 1);
  const ok = await verifySig(secret, body, signature);
  if (!ok) return null;
  try {
    const json = new TextDecoder().decode(base64UrlToBytes(body));
    const payload = JSON.parse(json) as SessionPayload;
    if (!payload?.sub || !payload?.username || !payload?.role || typeof payload.exp !== "number") {
      return null;
    }
    if (payload.exp * 1000 <= Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}
