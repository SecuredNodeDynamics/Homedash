import { promises as fs } from "fs";
import path from "path";
import { randomBytes, randomUUID } from "crypto";
import { getConfigDir } from "@/lib/config";
import { hashPassword } from "./password";
import type { AuthConfig, AuthPermission, AuthUser } from "./types";
import { atomicWriteJson } from "@/lib/atomic-file";

const EMPTY: AuthConfig = { version: 2, users: [], groups: [] };

function authPath() {
  return path.join(getConfigDir(), "auth.json");
}

function secretPath() {
  return path.join(getConfigDir(), "session-secret");
}

export async function readAuthConfig(): Promise<AuthConfig> {
  try {
    const raw = await fs.readFile(authPath(), "utf8");
    const data = JSON.parse(raw) as AuthConfig;
    if (!data || !Array.isArray(data.users)) return { ...EMPTY };
    return {
      version: 2,
      users: data.users.filter(
        (u): u is AuthUser =>
          Boolean(u?.id && u?.username && u?.passwordHash && (u?.role === "admin" || u?.role === "user")),
      ).map((u) => ({
        ...u,
        groupIds: Array.isArray(u.groupIds) ? u.groupIds : [],
        permissions: Array.isArray(u.permissions) ? u.permissions : [],
        restrictedTabIds: Array.isArray(u.restrictedTabIds) ? u.restrictedTabIds.map(String) : [],
        restrictedWidgetIds: Array.isArray(u.restrictedWidgetIds) ? u.restrictedWidgetIds.map(String) : [],
        restrictedLayoutTabIds: Array.isArray(u.restrictedLayoutTabIds) ? u.restrictedLayoutTabIds.map(String) : [],
      })),
      groups: Array.isArray(data.groups) ? data.groups.map((group) => ({
        ...group,
        restrictedTabIds: Array.isArray(group.restrictedTabIds) ? group.restrictedTabIds.map(String) : [],
        restrictedWidgetIds: Array.isArray(group.restrictedWidgetIds) ? group.restrictedWidgetIds.map(String) : [],
        restrictedLayoutTabIds: Array.isArray(group.restrictedLayoutTabIds) ? group.restrictedLayoutTabIds.map(String) : [],
      })) : [],
    };
  } catch {
    return { ...EMPTY };
  }
}

export async function writeAuthConfig(config: AuthConfig): Promise<void> {
  const dir = getConfigDir();
  await fs.mkdir(dir, { recursive: true });
  const normalized: AuthConfig = {
    version: 2,
    users: config.users,
    groups: config.groups,
  };
  await atomicWriteJson(authPath(), normalized);
  // Restrictive perms when possible (ignore on odd FS).
  try {
    await fs.chmod(authPath(), 0o600);
  } catch {
    // ignore
  }
}

export async function hasUsers(): Promise<boolean> {
  const config = await readAuthConfig();
  return config.users.length > 0;
}

/** Resolve session HMAC secret: env wins, else persist a generated file. */
export async function getSessionSecret(): Promise<string> {
  const fromEnv = process.env.HOMEDASH_SESSION_SECRET?.trim();
  if (fromEnv) return fromEnv;

  const dir = getConfigDir();
  await fs.mkdir(dir, { recursive: true });
  try {
    const existing = (await fs.readFile(secretPath(), "utf8")).trim();
    if (existing) {
      process.env.HOMEDASH_SESSION_SECRET = existing;
      return existing;
    }
  } catch {
    // create below
  }

  const secret = randomBytes(32).toString("base64url");
  await fs.writeFile(secretPath(), secret, "utf8");
  try {
    await fs.chmod(secretPath(), 0o600);
  } catch {
    // ignore
  }
  process.env.HOMEDASH_SESSION_SECRET = secret;
  return secret;
}

export async function findUserByUsername(username: string): Promise<AuthUser | null> {
  const config = await readAuthConfig();
  const needle = username.trim().toLowerCase();
  return config.users.find((u) => u.username.toLowerCase() === needle) || null;
}

export async function createAdminUser(username: string, password: string): Promise<AuthUser> {
  const config = await readAuthConfig();
  if (config.users.length > 0) {
    throw new Error("Admin user already exists");
  }
  const clean = username.trim();
  if (clean.length < 2 || clean.length > 64) {
    throw new Error("Username must be 2–64 characters");
  }
  if (!/^[a-zA-Z0-9._-]+$/.test(clean)) {
    throw new Error("Username may only contain letters, numbers, . _ -");
  }
  if (password.length < 8) {
    throw new Error("Password must be at least 8 characters");
  }

  const user: AuthUser = {
    id: randomUUID(),
    username: clean,
    passwordHash: await hashPassword(password),
    role: "admin",
    groupIds: [],
    permissions: [],
    createdAt: new Date().toISOString(),
  };
  await writeAuthConfig({ version: 2, users: [user], groups: [] });
  return user;
}

export async function updateUserPassword(userId: string, nextPassword: string): Promise<void> {
  if (nextPassword.length < 8) {
    throw new Error("Password must be at least 8 characters");
  }
  const config = await readAuthConfig();
  const idx = config.users.findIndex((u) => u.id === userId);
  if (idx < 0) throw new Error("User not found");
  const users = [...config.users];
  users[idx] = {
    ...users[idx]!,
    passwordHash: await hashPassword(nextPassword),
  };
  await writeAuthConfig({ ...config, users });
}

export function effectivePermissions(user: AuthUser, config: AuthConfig): Array<AuthPermission | "*"> {
  if (user.role === "admin") return ["*"];
  const values = new Set<AuthPermission>(user.permissions || []);
  for (const group of config.groups) {
    if (user.groupIds.includes(group.id)) group.permissions.forEach((permission) => values.add(permission));
  }
  return [...values];
}

export function effectiveRestrictions(user: AuthUser, config: AuthConfig) {
  if (user.role === "admin") return { restrictedTabIds: [], restrictedWidgetIds: [], restrictedLayoutTabIds: [] };
  const restrictedTabIds = new Set(user.restrictedTabIds || []);
  const restrictedWidgetIds = new Set(user.restrictedWidgetIds || []);
  const restrictedLayoutTabIds = new Set(user.restrictedLayoutTabIds || []);
  for (const group of config.groups) {
    if (!user.groupIds.includes(group.id)) continue;
    (group.restrictedTabIds || []).forEach((id) => restrictedTabIds.add(id));
    (group.restrictedWidgetIds || []).forEach((id) => restrictedWidgetIds.add(id));
    (group.restrictedLayoutTabIds || []).forEach((id) => restrictedLayoutTabIds.add(id));
  }
  return {
    restrictedTabIds: [...restrictedTabIds],
    restrictedWidgetIds: [...restrictedWidgetIds],
    restrictedLayoutTabIds: [...restrictedLayoutTabIds],
  };
}

/**
 * If auth.json is empty and HOMEDASH_ADMIN_USER + HOMEDASH_ADMIN_PASSWORD are set,
 * seed the first admin (headless bootstrap).
 */
export async function maybeBootstrapAdminFromEnv(): Promise<boolean> {
  if (await hasUsers()) return false;
  const user = process.env.HOMEDASH_ADMIN_USER?.trim();
  const pass = process.env.HOMEDASH_ADMIN_PASSWORD;
  if (!user || !pass) return false;
  await createAdminUser(user, pass);
  return true;
}
