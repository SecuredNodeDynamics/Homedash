export type AuthRole = "admin" | "user";
export type ProfileBackground = {
  enabled: boolean;
  background?: string;
  backgroundImageUrl?: string;
  backgroundImageOpacity?: number;
  backgroundImageBlur?: number;
};
export type AuthPermission =
  | "dashboard.view"
  | "settings.view"
  | "settings.manage"
  | "layout.manage"
  | "widgets.manage"
  | "terminals.use"
  | "proxmox.control"
  | "dashboards.personal"
  | "widgets.control"
  | "backups.manage"
  | "users.manage";

export type AuthGroup = {
  id: string;
  name: string;
  permissions: AuthPermission[];
  restrictedTabIds?: string[];
  restrictedWidgetIds?: string[];
  restrictedLayoutTabIds?: string[];
  createdAt: string;
};

export type AuthUser = {
  id: string;
  username: string;
  displayName?: string;
  profileImageUrl?: string;
  /** scrypt encoded: scrypt$N$r$p$saltB64$hashB64 */
  passwordHash: string;
  role: AuthRole;
  groupIds: string[];
  permissions: AuthPermission[];
  restrictedTabIds?: string[];
  restrictedWidgetIds?: string[];
  restrictedLayoutTabIds?: string[];
  disabled?: boolean;
  passwordResetRequestedAt?: string;
  mustChangePassword?: boolean;
  profileBackground?: ProfileBackground;
  profileTheme?: Partial<ThemeSettings>;
  personalBookmarks?: BookmarkItem[];
  personalBookmarkGroups?: BookmarkGroup[];
  /** Set after this account explicitly saves its isolated bookmark collection. */
  personalBookmarksIsolated?: boolean;
  personalTabs?: DashboardTab[];
  personalTabOrder?: string[];
  personalLayouts?: Record<string, LayoutConfig>;
  createdAt: string;
};

export type AuthConfig = {
  version: 2;
  users: AuthUser[];
  groups: AuthGroup[];
};

export type SessionPayload = {
  sub: string;
  username: string;
  role: AuthRole;
  permissions: Array<AuthPermission | "*">;
  restrictedTabIds?: string[];
  restrictedWidgetIds?: string[];
  restrictedLayoutTabIds?: string[];
  mustChangePassword?: boolean;
  exp: number;
};

export const SESSION_COOKIE = "hd_session";
export const SESSION_TTL_SECONDS = 60 * 60 * 24 * 14; // 14 days
import type {
  BookmarkGroup,
  BookmarkItem,
  DashboardTab,
  LayoutConfig,
  ThemeSettings,
} from "../types";
