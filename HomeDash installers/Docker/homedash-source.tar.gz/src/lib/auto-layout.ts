import type { GridItem, LayoutConfig, WidgetManifest } from "./types";
import { WIDGET_LAYOUT_SIZES } from "./tabs";
import { COLS } from "./breakpoints";

/** Height ceiling for auto-layout picks and expand-to-fill (manual edit uses a higher cap). */
export const AUTO_LAYOUT_MAX_H = 36;

export type AutoLayoutCard = {
  instanceId: string;
  widgetId: string;
  manifest: WidgetManifest;
  /** Auto Layout priority — lower first; omitted packs after numbered cards. */
  order?: number;
  /** Keep w/h from the existing layout; Auto Layout may only change x/y. */
  sizeLocked?: boolean;
  /** Preserve hide-on-this-device across Auto Layout. */
  hidden?: boolean;
  /** Preserved size when sizeLocked (from current layout). */
  lockedW?: number;
  lockedH?: number;
};

export type PackAutoLayoutOptions = {
  /** Different seed → different shuffle / size picks on each Auto Layout click. */
  seed?: number;
};

function cardOrderRank(card: AutoLayoutCard) {
  return card.order != null && Number.isFinite(card.order) ? card.order : Number.POSITIVE_INFINITY;
}

/** Stable sort: explicit order ascending, then instance id. */
function sortCardsByOrder(cards: AutoLayoutCard[]): AutoLayoutCard[] {
  return [...cards].sort((a, b) => {
    const ao = cardOrderRank(a);
    const bo = cardOrderRank(b);
    if (ao !== bo) return ao - bo;
    return a.instanceId.localeCompare(b.instanceId);
  });
}

function lockedSizeFor(card: AutoLayoutCard, cols: number) {
  const base = sizeFor(card, cols);
  const w = Math.min(cols, Math.max(1, card.lockedW ?? base.w));
  const h = Math.max(1, card.lockedH ?? base.h);
  return { w, h, minW: 1, minH: 1, maxW: cols, maxH: AUTO_LAYOUT_MAX_H };
}

function preserveMeta(card: AutoLayoutCard, item: GridItem): GridItem {
  const next = { ...item };
  if (card.sizeLocked) next.sizeLocked = true;
  if (card.hidden) next.hidden = true;
  if (card.order != null) next.order = card.order;
  return next;
}

function sizeFor(card: AutoLayoutCard, cols: number) {
  const preset = WIDGET_LAYOUT_SIZES[card.widgetId];
  const def = card.manifest.defaultSize;
  const rawW = preset?.w ?? def.w ?? 4;
  const rawH = preset?.h ?? def.h ?? 4;
  const w = Math.min(cols, rawW);
  return {
    w,
    h: rawH,
    minW: Math.min(def.minW ?? 2, cols),
    minH: def.minH ?? 2,
  };
}

function overlaps(a: GridItem, b: GridItem) {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}

function overlapsX(a: Pick<GridItem, "x" | "w">, b: Pick<GridItem, "x" | "w">) {
  return a.x < b.x + b.w && b.x < a.x + a.w;
}

/** Deterministic PRNG so each Auto Layout click can request a new arrangement. */
function mulberry32(seed: number) {
  let t = seed >>> 0;
  return () => {
    t += 0x6d2b79f5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

function shuffle<T>(items: T[], rng: () => number): T[] {
  const next = [...items];
  for (let i = next.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [next[i], next[j]] = [next[j], next[i]];
  }
  return next;
}

function pick<T>(items: T[], rng: () => number): T {
  return items[Math.floor(rng() * items.length) % items.length];
}

function uniqueSorted(values: number[]) {
  return Array.from(new Set(values.filter((n) => Number.isFinite(n) && n > 0))).sort((a, b) => a - b);
}

/** Choose a width/height that fits the grid; varies per click via rng. */
function pickFillSize(card: AutoLayoutCard, cols: number, rng: () => number) {
  const base = sizeFor(card, cols);
  const minW = Math.max(1, Math.min(cols, base.minW));
  const minH = Math.max(1, base.minH);
  const maxW = cols;
  const maxH = Math.max(minH, AUTO_LAYOUT_MAX_H);

  const widthPool = uniqueSorted([
    minW,
    Math.max(minW, Math.round(cols / 4)),
    Math.max(minW, Math.round(cols / 3)),
    Math.max(minW, Math.round(cols / 2)),
    Math.max(minW, Math.round((cols * 2) / 3)),
    Math.max(minW, base.w),
    Math.max(minW, Math.round(cols * 0.75)),
    maxW,
  ]).filter((w) => w >= minW && w <= maxW);

  const heightPool = uniqueSorted([
    minH,
    base.h,
    base.h + 1,
    base.h + 2,
    Math.max(minH, Math.round(base.h * 1.25)),
    Math.max(minH, Math.round(base.h * 1.5)),
    Math.min(maxH, base.h + 4),
  ]).filter((h) => h >= minH && h <= maxH);

  return {
    w: pick(widthPool, rng),
    h: pick(heightPool, rng),
    minW: 1,
    minH: 1,
    maxW,
    maxH,
  };
}

/** Related widget families that share a layout band when duplicated/mixed. */
const LAYOUT_FAMILIES: Record<string, readonly string[]> = {
  arr: ["radarr", "sonarr", "lidarr", "bazarr", "prowlarr", "dispatcharr", "tracearr"],
  dns: ["adguard-control", "pihole"],
  downloads: ["qbit", "downtify"],
  invest: ["invest-stocks", "invest-crypto", "crypto-tracker", "invest-news"],
};

const FAMILY_PRIORITY: Record<string, number> = {
  proxmox: 0,
  dns: 1,
  downloads: 2,
  arr: 3,
  invest: 4,
};

type LayoutFamilyKey = keyof typeof LAYOUT_FAMILIES | "proxmox" | `id:${string}`;

type PlacementMode = "peer-row" | "stack" | "hero";

type LayoutCluster = {
  key: string;
  family: LayoutFamilyKey;
  cards: AutoLayoutCard[];
  mode: PlacementMode;
};

/** True for big dashboard cards (Proxmox-scale) that read well as equal columns. */
function isColumnHero(card: AutoLayoutCard, cols: number) {
  if (card.widgetId === "proxmox-nodes") return true;
  const size = sizeFor(card, cols);
  return size.w >= Math.ceil(cols / 3) || size.h >= 10;
}

function familyForWidget(widgetId: string): LayoutFamilyKey | null {
  if (widgetId === "proxmox-nodes") return "proxmox";
  for (const [family, ids] of Object.entries(LAYOUT_FAMILIES)) {
    if (ids.includes(widgetId)) return family as LayoutFamilyKey;
  }
  return null;
}

function clusterKeyForCard(card: AutoLayoutCard, byWidgetCount: Map<string, number>): string {
  const count = byWidgetCount.get(card.widgetId) || 0;
  // Same widgetId duplicates always form their own cluster.
  if (count >= 2) return `id:${card.widgetId}`;
  const family = familyForWidget(card.widgetId);
  if (family) return `family:${family}`;
  return `solo:${card.instanceId}`;
}

function placementModeForCluster(cards: AutoLayoutCard[], cols: number): PlacementMode {
  if (cards.every((card) => isColumnHero(card, cols))) return "hero";
  if (cols <= 2) return "stack";
  const tall = cards.filter((card) => {
    const size = sizeFor(card, cols);
    return size.h >= size.w * 2;
  });
  // Stack only when most members are tall list/detail cards.
  if (tall.length >= Math.ceil(cards.length / 2) && cards.length >= 2) return "stack";
  return "peer-row";
}

/**
 * Build layout clusters: same widgetId first, then related families, then solos.
 * Multi-card clusters stay contiguous during packing.
 * Within a cluster, explicit `order` wins over shuffle.
 */
function buildLayoutClusters(cards: AutoLayoutCard[], cols: number, rng: () => number): LayoutCluster[] {
  const byWidgetCount = new Map<string, number>();
  for (const card of cards) {
    byWidgetCount.set(card.widgetId, (byWidgetCount.get(card.widgetId) || 0) + 1);
  }

  const buckets = new Map<string, AutoLayoutCard[]>();
  for (const card of cards) {
    const key = clusterKeyForCard(card, byWidgetCount);
    const list = buckets.get(key) || [];
    list.push(card);
    buckets.set(key, list);
  }

  const orderAwareShuffle = (group: AutoLayoutCard[]) => {
    const numbered = group.filter((card) => card.order != null);
    const rest = group.filter((card) => card.order == null);
    return [...sortCardsByOrder(numbered), ...shuffle(rest, rng)];
  };

  // Same-id groups consume members; family buckets should not re-include them.
  // clusterKeyForCard already routes duplicates to id:*, so family buckets only
  // get singles of that family — merge family singles into one family cluster.
  const familyMerged = new Map<string, AutoLayoutCard[]>();
  const other: LayoutCluster[] = [];

  for (const [key, group] of buckets) {
    if (key.startsWith("family:")) {
      const list = familyMerged.get(key) || [];
      list.push(...group);
      familyMerged.set(key, list);
      continue;
    }
    if (key.startsWith("id:")) {
      const widgetId = key.slice(3);
      other.push({
        key,
        family: familyForWidget(widgetId) || (`id:${widgetId}` as LayoutFamilyKey),
        cards: orderAwareShuffle(group),
        mode: placementModeForCluster(group, cols),
      });
      continue;
    }
    // solos
    for (const card of group) {
      other.push({
        key: `solo:${card.instanceId}`,
        family: `id:${card.widgetId}`,
        cards: [card],
        mode: "peer-row",
      });
    }
  }

  for (const [key, group] of familyMerged) {
    const family = key.slice("family:".length) as LayoutFamilyKey;
    other.push({
      key,
      family,
      cards: orderAwareShuffle(group),
      mode: placementModeForCluster(group, cols),
    });
  }

  return other.sort((a, b) => {
    const aOrder = Math.min(...a.cards.map(cardOrderRank));
    const bOrder = Math.min(...b.cards.map(cardOrderRank));
    if (aOrder !== bOrder) return aOrder - bOrder;
    const aMulti = a.cards.length >= 2 ? 0 : 1;
    const bMulti = b.cards.length >= 2 ? 0 : 1;
    if (aMulti !== bMulti) return aMulti - bMulti;
    if (b.cards.length !== a.cards.length) return b.cards.length - a.cards.length;
    const aPri = FAMILY_PRIORITY[String(a.family)] ?? (a.mode === "hero" ? 0 : 50);
    const bPri = FAMILY_PRIORITY[String(b.family)] ?? (b.mode === "hero" ? 0 : 50);
    if (aPri !== bPri) return aPri - bPri;
    return a.key.localeCompare(b.key);
  });
}

function skylineBottom(items: GridItem[]): number {
  return items.reduce((max, item) => Math.max(max, item.y + item.h), 0);
}

function maxPerRow(cols: number, cards: AutoLayoutCard[]): number {
  const minW = Math.max(1, ...cards.map((card) => sizeFor(card, cols).minW));
  return Math.max(1, Math.min(cards.length, Math.floor(cols / minW), cols));
}

function sharedPeerHeight(cards: AutoLayoutCard[], cols: number): number {
  const heights = cards.map((card) => {
    const size = sizeFor(card, cols);
    return Math.max(size.h, size.minH);
  });
  return Math.min(AUTO_LAYOUT_MAX_H, Math.max(2, ...heights));
}

/** Place a peer-row cluster as one or more equal-height full-width bands. */
function placePeerBand(
  cards: AutoLayoutCard[],
  cols: number,
  startY: number,
): { items: GridItem[]; lockedIds: string[] } {
  const ordered = cards;
  const perRow = maxPerRow(cols, ordered);
  const h = sharedPeerHeight(ordered, cols);
  const items: GridItem[] = [];
  const lockedIds: string[] = [];
  let y = startY;

  for (let i = 0; i < ordered.length; i += perRow) {
    const rowCards = ordered.slice(i, i + perRow);
    const widths = distributeWidths(cols, rowCards.length);
    let x = 0;
    for (let j = 0; j < rowCards.length; j++) {
      const card = rowCards[j];
      const w = widths[j];
      items.push({
        i: card.instanceId,
        x,
        y,
        w,
        h,
        minW: 1,
        minH: 1,
        maxW: cols,
        maxH: AUTO_LAYOUT_MAX_H,
      });
      lockedIds.push(card.instanceId);
      x += w;
    }
    y += h;
  }

  return { items, lockedIds };
}

/** Stack cluster members as full-width cards in a contiguous vertical block. */
function placeStackBand(cards: AutoLayoutCard[], cols: number, startY: number): GridItem[] {
  const items: GridItem[] = [];
  let y = startY;
  for (const card of cards) {
    const size = sizeFor(card, cols);
    const h = Math.max(size.h, size.minH);
    items.push({
      i: card.instanceId,
      x: 0,
      y,
      w: cols,
      h,
      minW: 1,
      minH: 1,
      maxW: cols,
      maxH: AUTO_LAYOUT_MAX_H,
    });
    y += h;
  }
  return items;
}

/** Place heroes in one equal-height row at startY (usually 0). */
function placeHeroBand(
  heroes: AutoLayoutCard[],
  cols: number,
  startY: number,
  rng: () => number,
): { items: GridItem[]; lockedIds: string[] } {
  const orderedHeroes = shuffle(heroes, rng);
  const widths = distributeWidths(cols, orderedHeroes.length);
  const heroHeight = Math.max(
    ...orderedHeroes.map((card) => Math.max(sizeFor(card, cols).h, sizeFor(card, cols).minH)),
    Math.round(cols * 0.7),
  );
  const h = Math.min(20, Math.max(8, heroHeight));
  const items: GridItem[] = [];
  const lockedIds: string[] = [];
  let x = 0;
  for (let i = 0; i < orderedHeroes.length; i++) {
    const card = orderedHeroes[i];
    const w = widths[i];
    items.push({
      i: card.instanceId,
      x,
      y: startY,
      w,
      h,
      minW: 1,
      minH: 1,
      maxW: cols,
      maxH: AUTO_LAYOUT_MAX_H,
    });
    lockedIds.push(card.instanceId);
    x += w;
  }
  return { items, lockedIds };
}

/** Split `cols` across `count` columns as evenly as possible (e.g. 16→5+5+6). */
function distributeWidths(cols: number, count: number): number[] {
  const n = Math.max(1, count);
  const widths: number[] = [];
  let remaining = cols;
  for (let i = 0; i < n; i++) {
    const w = Math.floor(remaining / (n - i));
    widths.push(Math.max(1, w));
    remaining -= w;
  }
  return widths;
}

/** Pull items upward to close vertical gaps without changing order preference. */
export function compactUp(items: GridItem[]): GridItem[] {
  const next = items.map((item) => ({ ...item })).sort((a, b) => a.y - b.y || a.x - b.x);
  for (let i = 0; i < next.length; i++) {
    const item = next[i];
    let y = 0;
    for (let j = 0; j < i; j++) {
      const other = next[j];
      if (!overlapsX(item, other)) continue;
      y = Math.max(y, other.y + other.h);
    }
    item.y = y;
  }
  return next;
}

/** Slide items left into open holes on their row without changing size or y. */
export function packLeft(items: GridItem[]): GridItem[] {
  const next = items.map((item) => ({ ...item })).sort((a, b) => a.y - b.y || a.x - b.x);
  for (let i = 0; i < next.length; i++) {
    const item = next[i];
    let bestX = item.x;
    for (let x = 0; x < item.x; x++) {
      const candidate = { ...item, x };
      const blocked = next.some((other, j) => j !== i && overlaps(candidate, other));
      if (!blocked) {
        bestX = x;
        break;
      }
    }
    item.x = bestX;
  }
  return next;
}

/** Alternate vertical + horizontal compaction so tall/short neighbors leave fewer holes. */
export function densify(items: GridItem[], passes = 4): GridItem[] {
  let next = items.map((item) => ({ ...item }));
  for (let i = 0; i < passes; i++) {
    next = compactUp(next);
    next = packLeft(next);
  }
  return next;
}

function canPlace(items: GridItem[], candidate: GridItem, ignoreId?: string) {
  return !items.some((other) => other.i !== ignoreId && overlaps(candidate, other));
}

/**
 * Grow each card right into empty grid cells so leftover columns on a row fill tightly.
 * Does not change heights — vertical stretch between neighbors was causing cards to
 * balloon and fill the page after Auto Layout / save.
 * Pass `lockedIds` to skip peer/hero band siblings so equal twins stay matched.
 */
export function expandToFill(
  items: GridItem[],
  cols: number,
  lockedIds: ReadonlySet<string> = new Set(),
): GridItem[] {
  const next = items.map((item) => ({ ...item }));
  if (!next.length) return next;

  // Width pass — prefer left-to-right so earlier cards claim leftover columns.
  for (const item of [...next].sort((a, b) => a.y - b.y || a.x - b.x)) {
    if (lockedIds.has(item.i)) continue;
    const maxW = Math.min(cols - item.x, item.maxW ?? cols);
    while (item.w < maxW) {
      const grown = { ...item, w: item.w + 1 };
      if (!canPlace(next, grown, item.i)) break;
      item.w += 1;
    }
  }

  return next;
}

/**
 * Cluster-aware packer: keep same/similar widgets in contiguous bands
 * (side-by-side peers, wrapped rows, or stacks), then skyline-pack leftovers.
 * Size-locked cards keep w/h and are only repositioned. Explicit `order` sorts first.
 */
export function packAutoLayout(
  cards: AutoLayoutCard[],
  cols: number,
  _existing: GridItem[] = [],
  options: PackAutoLayoutOptions = {},
): GridItem[] {
  const seed = options.seed ?? Date.now();
  const rng = mulberry32(seed);
  const ordered = sortCardsByOrder(cards);
  const byId = new Map(ordered.map((card) => [card.instanceId, card]));
  const numberedCards = ordered.filter((card) => Number.isFinite(card.order));
  const unnumberedCards = ordered.filter((card) => !Number.isFinite(card.order));

  // Priority is a strict vertical band: no unnumbered card may occupy a hole
  // beside or above a numbered card. Pack each band independently, then place
  // the unnumbered band beneath the complete priority band.
  if (numberedCards.length && unnumberedCards.length) {
    const numbered = packAutoLayout(numberedCards, cols, [], { seed });
    const unnumbered = packAutoLayout(unnumberedCards, cols, [], {
      seed: seed ^ 0x9e3779b9,
    });
    const offset = skylineBottom(numbered);
    return [
      ...numbered,
      ...unnumbered.map((item) => ({ ...item, y: item.y + offset })),
    ];
  }

  const sizeLockedCards = ordered.filter((card) => card.sizeLocked);
  const freeCards = ordered.filter((card) => !card.sizeLocked);
  const sizeLockedIds = new Set(sizeLockedCards.map((card) => card.instanceId));

  const items: GridItem[] = [];

  // Place size-locked cards first (position only — preserve w/h).
  for (const card of sizeLockedCards) {
    const size = lockedSizeFor(card, cols);
    const w = cols <= 1 ? 1 : size.w;
    const h = size.h;
    const slot = findOpenSlot(items, w, h, cols);
    items.push(
      preserveMeta(card, {
        i: card.instanceId,
        x: slot.x,
        y: slot.y,
        w,
        h,
        minW: 1,
        minH: 1,
        maxW: cols,
        maxH: AUTO_LAYOUT_MAX_H,
      }),
    );
  }

  // Mobile / single-column: stack free cards full-width under locked ones.
  if (cols <= 1) {
    let y = skylineBottom(items);
    for (const card of freeCards) {
      const size = sizeFor(card, cols);
      items.push(
        preserveMeta(card, {
          i: card.instanceId,
          x: 0,
          y,
          w: 1,
          h: size.h,
          minW: 1,
          minH: 1,
        }),
      );
      y += size.h;
    }
    return densify(items).map((item) => {
      const card = byId.get(item.i);
      return card ? preserveMeta(card, item) : item;
    });
  }

  const clusters = buildLayoutClusters(freeCards, cols, rng);
  const peerLockedIds = new Set<string>();

  const multi = clusters.filter((c) => c.cards.length >= 2);
  const singles = clusters.filter((c) => c.cards.length < 2).flatMap((c) => c.cards);

  const placeBandItems = (bandItems: GridItem[], bandCards: AutoLayoutCard[]) => {
    for (const item of bandItems) {
      const card = byId.get(item.i) || bandCards.find((c) => c.instanceId === item.i);
      items.push(card ? preserveMeta(card, item) : item);
    }
  };

  // Prefer a hero band first when present (below already-placed locked cards).
  const heroIdx = multi.findIndex((c) => c.mode === "hero");
  if (heroIdx >= 0) {
    const hero = multi.splice(heroIdx, 1)[0];
    const band = placeHeroBand(hero.cards, cols, skylineBottom(items), rng);
    placeBandItems(band.items, hero.cards);
    for (const id of band.lockedIds) peerLockedIds.add(id);
  }

  for (const cluster of multi) {
    const y = skylineBottom(items);
    if (cluster.mode === "stack") {
      const stacked = placeStackBand(cluster.cards, cols, y);
      placeBandItems(stacked, cluster.cards);
      continue;
    }
    if (cluster.mode === "hero") {
      const band = placeHeroBand(cluster.cards, cols, y, rng);
      placeBandItems(band.items, cluster.cards);
      for (const id of band.lockedIds) peerLockedIds.add(id);
      continue;
    }
    const band = placePeerBand(cluster.cards, cols, y);
    placeBandItems(band.items, cluster.cards);
    for (const id of band.lockedIds) peerLockedIds.add(id);
  }

  const numberedSingles = singles.filter((card) => card.order != null);
  const restSingles = singles.filter((card) => card.order == null);
  const singlesOrdered = [...sortCardsByOrder(numberedSingles), ...shuffle(restSingles, rng)];
  for (const card of singlesOrdered) {
    const size = card.order != null ? sizeFor(card, cols) : pickFillSize(card, cols, rng);
    const slot =
      card.order != null
        ? findOrderedSlot(items, size.w, size.h, cols, card.order)
        : findOpenSlot(items, size.w, size.h, cols);
    items.push(
      preserveMeta(card, {
        i: card.instanceId,
        x: slot.x,
        y: slot.y,
        w: size.w,
        h: size.h,
        minW: size.minW ?? 1,
        minH: size.minH ?? 1,
        maxW: cols,
        maxH: AUTO_LAYOUT_MAX_H,
      }),
    );
  }

  const expandSkip = new Set<string>([...sizeLockedIds, ...peerLockedIds]);
  const packed = expandToFill(densify(items), cols, expandSkip);

  // Re-assert size locks and meta after compaction / expand.
  return packed.map((item) => {
    const card = byId.get(item.i);
    if (!card) return item;
    let next = preserveMeta(card, item);
    if (card.sizeLocked) {
      const size = lockedSizeFor(card, cols);
      next = {
        ...next,
        w: cols <= 1 ? 1 : size.w,
        h: size.h,
      };
    }
    return next;
  });
}

/**
 * Preserve every card's saved size while arranging priority cards first and
 * placing all unnumbered cards in a separate band underneath them.
 */
export function alignItemsByPriority(items: GridItem[], cols: number): GridItem[] {
  const numbered = items
    .filter((item) => Number.isFinite(item.order))
    .sort((a, b) => Number(a.order) - Number(b.order) || a.y - b.y || a.x - b.x || a.i.localeCompare(b.i));
  if (!numbered.length) return items.map((item) => ({ ...item }));

  const unnumbered = items
    .filter((item) => !Number.isFinite(item.order))
    .sort((a, b) => a.y - b.y || a.x - b.x || a.i.localeCompare(b.i));

  const placeBand = (sources: GridItem[], offset: number) => {
    const local: GridItem[] = [];
    for (const source of sources) {
      const item = {
        ...source,
        w: Math.min(cols, Math.max(1, source.w)),
      };
      const slot = findOpenSlot(local, item.w, item.h, cols);
      item.x = slot.x;
      item.y = slot.y;
      local.push(item);
    }
    return local.map((item) => ({ ...item, y: item.y + offset }));
  };

  const priorityBand = placeBand(numbered, 0);
  const regularBand = placeBand(unnumbered, skylineBottom(priorityBand));
  const byId = new Map([...priorityBand, ...regularBand].map((item) => [item.i, item]));
  return items.map((item) => byId.get(item.i) || item);
}

/** Pack only the active breakpoint; leave other breakpoints untouched. */
export function buildAutoLayoutForBreakpoint(
  cards: AutoLayoutCard[],
  cols: number,
  existing: GridItem[] = [],
  options: PackAutoLayoutOptions = {},
): GridItem[] {
  return packAutoLayout(cards, cols, existing, options);
}

/** @deprecated Prefer buildAutoLayoutForBreakpoint so other breakpoints stay intact. */
export function buildAutoLayout(cards: AutoLayoutCard[]): LayoutConfig {
  return {
    lg: packAutoLayout(cards, COLS.lg),
    md: packAutoLayout(cards, COLS.md),
    sm: packAutoLayout(cards, COLS.sm).map((item) => ({ ...item, w: 1, x: 0 })),
    xl: packAutoLayout(cards, COLS.xl),
    xxl: packAutoLayout(cards, COLS.xxl),
  };
}

function applyClusterMins(items: GridItem[], threshold: number) {
  const sorted = [...items].sort((a, b) => a.y - b.y || a.x - b.x);
  const clusters: GridItem[][] = [];
  for (const item of sorted) {
    const cluster = clusters.find((group) => Math.abs(group[0].y - item.y) <= threshold);
    if (cluster) cluster.push(item);
    else clusters.push([item]);
  }
  for (const cluster of clusters) {
    const y = Math.min(...cluster.map((item) => item.y));
    for (const item of cluster) {
      const target = items.find((n) => n.i === item.i);
      if (target) target.y = y;
    }
  }
}

/**
 * Push later widgets down until no two items overlap.
 * Preserves relative top-to-bottom / left-to-right order.
 */
export function resolveVerticalOverlaps(items: GridItem[]): GridItem[] {
  const next = items
    .map((item) => ({ ...item }))
    .sort((a, b) => a.y - b.y || a.x - b.x || a.i.localeCompare(b.i));

  for (let i = 0; i < next.length; i++) {
    let guard = 0;
    let moved = true;
    while (moved && guard++ < 200) {
      moved = false;
      for (let j = 0; j < i; j++) {
        if (!overlaps(next[i], next[j])) continue;
        const pushTo = next[j].y + next[j].h;
        if (next[i].y < pushTo) {
          next[i].y = pushTo;
          moved = true;
        }
      }
    }
  }
  return next;
}

/**
 * Resolve a drop while keeping the actively dragged/resized item fixed.
 * Other cards may overlap temporarily during the gesture; on release, every
 * conflicting card is pushed downward in its current column until it fits.
 */
export function resolveOverlapsAroundPinnedItem(
  items: GridItem[],
  pinnedId: string,
): GridItem[] {
  const original = items.map((item) => ({ ...item }));
  const pinned = original.find((item) => item.i === pinnedId);
  if (!pinned) return resolveVerticalOverlaps(original);

  const placed: GridItem[] = [{ ...pinned }];
  const others = original
    .filter((item) => item.i !== pinnedId)
    .sort((a, b) => a.y - b.y || a.x - b.x || a.i.localeCompare(b.i));

  for (const source of others) {
    const item = { ...source };
    let guard = 0;
    while (guard++ < 500) {
      const collisions = placed.filter((other) => overlaps(item, other));
      if (!collisions.length) break;
      item.y = Math.max(...collisions.map((other) => other.y + other.h));
    }
    placed.push(item);
  }

  const byId = new Map(placed.map((item) => [item.i, item]));
  return original.map((item) => byId.get(item.i) || item);
}

/**
 * Slide each widget into the topmost-leftmost hole that fits its current size,
 * if that hole is higher (or same row further left) than its current position.
 * Closes side pockets beside tall neighbors without resizing.
 */
export function slideIntoBetterSlots(items: GridItem[], cols: number): GridItem[] {
  const next = items.map((item) => ({ ...item }));
  if (!next.length || cols < 1) return next;

  // Bottom-first so vacating lower cells can open upper holes for later items.
  const order = [...next].sort((a, b) => b.y - a.y || b.x - a.x || b.i.localeCompare(a.i));
  for (const item of order) {
    const occupied = next.filter((other) => other.i !== item.i);
    const best = findOpenSlot(occupied, item.w, item.h, cols);
    if (best.y < item.y || (best.y === item.y && best.x < item.x)) {
      item.x = best.x;
      item.y = best.y;
    }
  }
  return next;
}

/**
 * Tidy layout for the Align tops action:
 * 1) resolve overlaps by shifting widgets down
 * 2) compact vertical gaps + slide left into holes
 * 3) slide widgets into better top/left holes (closes side gaps)
 * 4) lightly snap near-miss tops onto shared rows
 */
export function alignLayoutTops(items: GridItem[], threshold = 1, cols = 12): GridItem[] {
  if (!items.length) return items;

  let next = resolveVerticalOverlaps(items);
  next = densify(next, 6);
  next = slideIntoBetterSlots(next, cols);
  next = densify(next, 4);
  applyClusterMins(next, threshold);
  next = resolveVerticalOverlaps(next);
  next = densify(next, 4);
  next = slideIntoBetterSlots(next, cols);
  next = densify(next, 3);
  return next;
}

/**
 * After drag/resize, lightly snap this item's top to a nearby row line.
 * Does not move any other widgets.
 */
export function snapItemToNearbyRow(items: GridItem[], itemId: string, threshold = 1): GridItem[] {
  const next = items.map((item) => ({ ...item }));
  const moved = next.find((item) => item.i === itemId);
  if (!moved) return next;

  const rowLines = Array.from(
    new Set(next.filter((item) => item.i !== itemId).map((item) => item.y)),
  ).sort((a, b) => a - b);
  if (!rowLines.length) return next;

  let best = moved.y;
  let bestDist = Infinity;
  for (const line of rowLines) {
    const dist = Math.abs(line - moved.y);
    if (dist < bestDist && dist <= threshold) {
      bestDist = dist;
      best = line;
    }
  }

  moved.y = best;
  return next;
}

export function itemsOverlap(a: GridItem, b: GridItem) {
  return overlaps(a, b);
}

/**
 * Prefer column `(order - 1) % cols` for numbered cards so priority maps
 * left→right across the active breakpoint column grid.
 */
function findOrderedSlot(
  occupied: Array<Pick<GridItem, "x" | "y" | "w" | "h">>,
  w: number,
  h: number,
  cols: number,
  order: number,
): { x: number; y: number } {
  const width = Math.min(cols, Math.max(1, w));
  const height = Math.max(1, h);
  const preferredX = Math.min(Math.max(0, (Math.round(order) - 1) % cols), Math.max(0, cols - width));
  const boardBottom = occupied.reduce((max, item) => Math.max(max, item.y + item.h), 0);

  const fits = (x: number, y: number) =>
    !occupied.some(
      (item) =>
        x < item.x + item.w &&
        x + width > item.x &&
        y < item.y + item.h &&
        y + height > item.y,
    );

  for (let y = 0; y <= boardBottom + height; y++) {
    if (fits(preferredX, y)) return { x: preferredX, y };
  }
  return findOpenSlot(occupied, width, height, cols);
}

/**
 * Find the top-most, then left-most open slot that fits `w`×`h` without overlapping
 * existing items. Prefers holes inside the current board bounds before extending below.
 */
export function findOpenSlot(
  occupied: Array<Pick<GridItem, "x" | "y" | "w" | "h">>,
  w: number,
  h: number,
  cols: number,
): { x: number; y: number } {
  const width = Math.min(cols, Math.max(1, w));
  const height = Math.max(1, h);
  const boardBottom = occupied.reduce((max, item) => Math.max(max, item.y + item.h), 0);

  const fits = (x: number, y: number) => {
    return !occupied.some(
      (item) =>
        x < item.x + item.w &&
        x + width > item.x &&
        y < item.y + item.h &&
        y + height > item.y,
    );
  };

  // 1) Fill gaps inside the existing bounding box (e.g. empty space beside a tall card).
  for (let y = 0; y <= boardBottom; y++) {
    for (let x = 0; x <= cols - width; x++) {
      if (fits(x, y)) return { x, y };
    }
  }

  // 2) Otherwise append below, still left-aligned into the first free column on that row.
  for (let x = 0; x <= cols - width; x++) {
    if (fits(x, boardBottom)) return { x, y: boardBottom };
  }

  return { x: 0, y: boardBottom };
}

/**
 * Push every hidden-on-this-device widget below all visible widgets, so hiding
 * a card doesn't leave a blank gap where it used to sit. Visible cards are left
 * exactly where they are; hidden cards are repacked — in their existing
 * relative top-to-bottom/left-to-right order — into the first open slots at or
 * below the bottom of the visible cards. Safe to call any time the hidden set
 * may have changed; a no-op when nothing is hidden.
 */
export function pushHiddenBelowVisible(items: GridItem[], cols: number): GridItem[] {
  const visible = items.filter((item) => !item.hidden);
  const hidden = items
    .filter((item) => item.hidden)
    .sort((a, b) => a.y - b.y || a.x - b.x || a.i.localeCompare(b.i));
  if (!hidden.length) return items.map((item) => ({ ...item }));

  const boardBottom = visible.reduce((max, item) => Math.max(max, item.y + item.h), 0);
  const occupied: GridItem[] = visible.map((item) => ({ ...item }));
  const placedHidden: GridItem[] = [];

  for (const source of hidden) {
    const item = { ...source };
    const width = Math.min(cols, Math.max(1, item.w));
    const height = Math.max(1, item.h);
    const fits = (x: number, y: number) =>
      !occupied.some(
        (other) =>
          x < other.x + other.w &&
          x + width > other.x &&
          y < other.y + other.h &&
          y + height > other.y,
      );

    let placed = false;
    const maxY = boardBottom + occupied.length + hidden.length + 1;
    for (let y = boardBottom; y <= maxY && !placed; y++) {
      for (let x = 0; x <= cols - width && !placed; x++) {
        if (fits(x, y)) {
          item.x = x;
          item.y = y;
          placed = true;
        }
      }
    }
    if (!placed) {
      item.x = 0;
      item.y = boardBottom;
    }
    occupied.push(item);
    placedHidden.push(item);
  }

  const byId = new Map<string, GridItem>([...visible, ...placedHidden].map((item) => [item.i, item]));
  return items.map((item) => byId.get(item.i) || { ...item });
}

/** Place any cards missing from the layout into open gaps; leave existing items untouched. */
export function placeMissingItems(
  cards: AutoLayoutCard[],
  existing: GridItem[],
  cols: number,
): GridItem[] {
  const byId = new Map(existing.map((item) => [item.i, item]));
  const next = existing.map((item) => ({ ...item }));
  const occupied: GridItem[] = [...next];

  for (const card of cards) {
    if (byId.has(card.instanceId)) continue;
    const size = sizeFor(card, cols);
    const slot = findOpenSlot(occupied, size.w, size.h, cols);
    const item: GridItem = {
      i: card.instanceId,
      x: slot.x,
      y: slot.y,
      w: size.w,
      h: size.h,
      minW: size.minW,
      minH: size.minH,
    };
    next.push(item);
    occupied.push(item);
    byId.set(card.instanceId, item);
  }

  return next;
}
