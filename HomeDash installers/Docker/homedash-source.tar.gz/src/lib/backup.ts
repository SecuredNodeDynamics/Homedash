import { promises as fs } from "fs";
import path from "path";
import type { AppSettings, BookmarkGroup, BookmarkItem, LayoutsByTab } from "./types";
import {
  getConfigDir,
  readLayouts,
  readSettings,
  readWidgetConfig,
  writeSettings,
  writeTabLayout,
  writeWidgetConfig,
} from "./config";
import { normalizeBookmarkGroups, normalizeBookmarks } from "./bookmarks";

export const BACKUP_VERSION = 1 as const;

export type BackupKind = "full" | "widgets";

export type HomedashBackup = {
  version: typeof BACKUP_VERSION;
  kind: BackupKind;
  exportedAt: string;
  label?: string;
  appName?: string;
  settings?: AppSettings;
  layouts?: LayoutsByTab;
  widgets: Record<string, Record<string, string>>;
  meta?: {
    widgetIds: string[];
    tabCount?: number;
    uploadFiles?: string[];
  };
};

export type BackupListItem = {
  id: string;
  filename: string;
  kind: BackupKind;
  label: string;
  exportedAt: string;
  size: number;
  widgetCount: number;
  hasSettings: boolean;
  hasLayouts: boolean;
};

export type RestoreParts = {
  settings?: boolean;
  layouts?: boolean;
  widgets?: boolean;
  /** When restoring widgets, limit to these instance ids. Empty/undefined = all in backup. */
  widgetIds?: string[];
};

export type RestoreResult = {
  settings: boolean;
  layouts: number;
  widgets: number;
};

const SAFE_ID = /^[a-zA-Z0-9][a-zA-Z0-9._-]{0,180}$/;
const SAFE_WIDGET_ID = /^[a-zA-Z0-9][a-zA-Z0-9._-]{0,120}$/;

function backupsDir() {
  return path.join(getConfigDir(), "backups");
}

async function ensureBackupsDir() {
  const dir = backupsDir();
  await fs.mkdir(dir, { recursive: true });
  return dir;
}

export function isSafeBackupId(id: string) {
  return SAFE_ID.test(id) && !id.includes("..");
}

export function isSafeWidgetId(id: string) {
  return SAFE_WIDGET_ID.test(id) && !id.includes("..") && !id.includes("/");
}

function stamp() {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

/** Sanitize an optional backup label for use in filenames / backup ids. */
export function slugBackupLabel(label?: string): string {
  const raw = String(label || "")
    .trim()
    .toLowerCase();
  if (!raw) return "";
  return raw
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
}

function isDefaultBackupLabelSlug(slug: string, kind: BackupKind) {
  if (!slug) return true;
  if (kind === "full" && (slug === "full-config" || slug === "full")) return true;
  if (kind === "widgets" && (slug === "widgets" || /^widgets-\d+$/.test(slug))) return true;
  return false;
}

export async function listWidgetConfigIds(): Promise<string[]> {
  const dir = path.join(getConfigDir(), "widgets");
  try {
    const entries = await fs.readdir(dir, { withFileTypes: true });
    return entries
      .filter((e) => e.isFile() && e.name.endsWith(".json"))
      .map((e) => e.name.replace(/\.json$/i, ""))
      .filter(isSafeWidgetId)
      .sort((a, b) => a.localeCompare(b));
  } catch {
    return [];
  }
}

export async function listUploadNames(): Promise<string[]> {
  const dir = path.join(getConfigDir(), "uploads");
  try {
    const entries = await fs.readdir(dir, { withFileTypes: true });
    return entries.filter((e) => e.isFile()).map((e) => e.name).sort();
  } catch {
    return [];
  }
}

async function collectWidgetConfigs(ids?: string[]): Promise<Record<string, Record<string, string>>> {
  const all = ids?.length ? ids.filter(isSafeWidgetId) : await listWidgetConfigIds();
  const widgets: Record<string, Record<string, string>> = {};
  for (const id of all) {
    const cfg = await readWidgetConfig(id);
    if (cfg && Object.keys(cfg).length > 0) {
      widgets[id] = cfg;
    } else if (ids?.includes(id)) {
      widgets[id] = cfg || {};
    }
  }
  return widgets;
}

export async function buildFullBackup(label?: string): Promise<HomedashBackup> {
  const settings = await readSettings();
  const layouts = await readLayouts();
  const widgets = await collectWidgetConfigs();
  const uploadFiles = await listUploadNames();
  return {
    version: BACKUP_VERSION,
    kind: "full",
    exportedAt: new Date().toISOString(),
    label: label?.trim() || "Full config",
    appName: settings.appName,
    settings,
    layouts,
    widgets,
    meta: {
      widgetIds: Object.keys(widgets),
      tabCount: settings.tabs?.length || 0,
      uploadFiles,
    },
  };
}

export async function buildWidgetsBackup(widgetIds: string[], label?: string): Promise<HomedashBackup> {
  const ids = [...new Set(widgetIds.filter(isSafeWidgetId))];
  if (!ids.length) {
    throw new Error("Select at least one widget config to back up");
  }
  const widgets = await collectWidgetConfigs(ids);
  const settings = await readSettings();
  return {
    version: BACKUP_VERSION,
    kind: "widgets",
    exportedAt: new Date().toISOString(),
    label: label?.trim() || `Widgets (${ids.length})`,
    appName: settings.appName,
    widgets,
    meta: {
      widgetIds: Object.keys(widgets),
    },
  };
}

export function backupFilename(backup: HomedashBackup) {
  const kind = backup.kind === "full" ? "full" : "widgets";
  const slug = slugBackupLabel(backup.label);
  if (isDefaultBackupLabelSlug(slug, kind)) {
    return `homedash-${kind}-${stamp()}.json`;
  }
  return `homedash-${kind}-${slug}-${stamp()}.json`;
}

export async function saveBackup(backup: HomedashBackup, idHint?: string): Promise<BackupListItem> {
  const dir = await ensureBackupsDir();
  const base = idHint && isSafeBackupId(idHint) ? idHint : backupFilename(backup).replace(/\.json$/i, "");
  const id = base.endsWith(".json") ? base.slice(0, -5) : base;
  if (!isSafeBackupId(id)) throw new Error("Invalid backup id");
  const filename = `${id}.json`;
  const filePath = path.join(dir, filename);
  const raw = JSON.stringify(backup, null, 2);
  await fs.writeFile(filePath, raw, "utf8");
  return toListItem(filename, backup, Buffer.byteLength(raw, "utf8"));
}

function toListItem(filename: string, backup: HomedashBackup, size: number): BackupListItem {
  return {
    id: filename.replace(/\.json$/i, ""),
    filename,
    kind: backup.kind,
    label: backup.label || (backup.kind === "full" ? "Full config" : "Widgets"),
    exportedAt: backup.exportedAt,
    size,
    widgetCount: Object.keys(backup.widgets || {}).length,
    hasSettings: Boolean(backup.settings),
    hasLayouts: Boolean(backup.layouts && Object.keys(backup.layouts).length),
  };
}

export async function listSavedBackups(): Promise<BackupListItem[]> {
  const dir = await ensureBackupsDir();
  let names: string[] = [];
  try {
    names = (await fs.readdir(dir)).filter((n) => n.endsWith(".json"));
  } catch {
    return [];
  }
  const items: BackupListItem[] = [];
  for (const filename of names) {
    const id = filename.replace(/\.json$/i, "");
    if (!isSafeBackupId(id)) continue;
    try {
      const filePath = path.join(dir, filename);
      const raw = await fs.readFile(filePath, "utf8");
      const backup = parseBackupJson(raw);
      items.push(toListItem(filename, backup, Buffer.byteLength(raw, "utf8")));
    } catch {
      // skip corrupt
    }
  }
  return items.sort((a, b) => b.exportedAt.localeCompare(a.exportedAt));
}

export async function readSavedBackup(id: string): Promise<HomedashBackup> {
  if (!isSafeBackupId(id)) throw new Error("Invalid backup id");
  const filePath = path.join(await ensureBackupsDir(), `${id}.json`);
  const raw = await fs.readFile(filePath, "utf8");
  return parseBackupJson(raw);
}

export async function deleteSavedBackup(id: string) {
  if (!isSafeBackupId(id)) throw new Error("Invalid backup id");
  await fs.unlink(path.join(await ensureBackupsDir(), `${id}.json`));
}

export function parseBackupJson(raw: string): HomedashBackup {
  let data: unknown;
  try {
    data = JSON.parse(raw);
  } catch {
    throw new Error("Backup file is not valid JSON");
  }
  if (!data || typeof data !== "object") throw new Error("Invalid backup payload");
  const obj = data as Record<string, unknown>;
  if (obj.version !== BACKUP_VERSION && obj.version !== 1) {
    throw new Error(`Unsupported backup version: ${String(obj.version)}`);
  }
  if (obj.kind !== "full" && obj.kind !== "widgets") {
    throw new Error("Backup kind must be full or widgets");
  }
  if (!obj.widgets || typeof obj.widgets !== "object") {
    throw new Error("Backup is missing widgets map");
  }
  const widgets: Record<string, Record<string, string>> = {};
  for (const [id, cfg] of Object.entries(obj.widgets as Record<string, unknown>)) {
    if (!isSafeWidgetId(id)) continue;
    if (!cfg || typeof cfg !== "object") continue;
    const clean: Record<string, string> = {};
    for (const [k, v] of Object.entries(cfg as Record<string, unknown>)) {
      if (typeof k !== "string" || !k) continue;
      if (v == null) continue;
      clean[k] = typeof v === "string" ? v : String(v);
    }
    widgets[id] = clean;
  }
  return {
    version: BACKUP_VERSION,
    kind: obj.kind,
    exportedAt: typeof obj.exportedAt === "string" ? obj.exportedAt : new Date().toISOString(),
    label: typeof obj.label === "string" ? obj.label : undefined,
    appName: typeof obj.appName === "string" ? obj.appName : undefined,
    settings: obj.settings && typeof obj.settings === "object" ? (obj.settings as AppSettings) : undefined,
    layouts: obj.layouts && typeof obj.layouts === "object" ? (obj.layouts as LayoutsByTab) : undefined,
    widgets,
    meta: obj.meta && typeof obj.meta === "object" ? (obj.meta as HomedashBackup["meta"]) : undefined,
  };
}

export async function restoreBackup(backup: HomedashBackup, parts: RestoreParts): Promise<RestoreResult> {
  const result: RestoreResult = { settings: false, layouts: 0, widgets: 0 };

  const wantSettings = Boolean(parts.settings);
  const wantLayouts = Boolean(parts.layouts);
  const wantWidgets = parts.widgets !== false; // default true when restoring

  if (wantSettings) {
    if (!backup.settings) throw new Error("This backup has no settings to restore");
    const body = backup.settings;
    if (!body.appName || !body.theme || !Array.isArray(body.enabledWidgets)) {
      throw new Error("Backup settings payload is incomplete");
    }
    await writeSettings(body);
    result.settings = true;
  }

  if (wantLayouts) {
    if (!backup.layouts) throw new Error("This backup has no layouts to restore");
    for (const [tabId, layout] of Object.entries(backup.layouts)) {
      if (!tabId || !layout) continue;
      await writeTabLayout(tabId, layout);
      result.layouts += 1;
    }
  }

  if (wantWidgets) {
    const allow = parts.widgetIds?.length
      ? new Set(parts.widgetIds.filter(isSafeWidgetId))
      : null;
    for (const [id, cfg] of Object.entries(backup.widgets || {})) {
      if (!isSafeWidgetId(id)) continue;
      if (allow && !allow.has(id)) continue;
      await writeWidgetConfig(id, cfg || {});
      result.widgets += 1;
    }
  }

  return result;
}

// ---------------------------------------------------------------------------
// Bookmarks-only backup & restore
// ---------------------------------------------------------------------------

export type HomedashBookmarksBackup = {
  version: typeof BACKUP_VERSION;
  kind: "bookmarks";
  exportedAt: string;
  label?: string;
  appName?: string;
  bookmarks: BookmarkItem[];
  bookmarkGroups: BookmarkGroup[];
};

export type BookmarksBackupListItem = {
  id: string;
  filename: string;
  label: string;
  exportedAt: string;
  size: number;
  bookmarkCount: number;
  groupCount: number;
};

export type BookmarksRestoreResult = {
  bookmarks: number;
  groups: number;
};

function bookmarksBackupsDir() {
  return path.join(getConfigDir(), "backups", "bookmarks");
}

async function ensureBookmarksBackupsDir() {
  const dir = bookmarksBackupsDir();
  await fs.mkdir(dir, { recursive: true });
  return dir;
}

export async function buildBookmarksBackup(label?: string): Promise<HomedashBookmarksBackup> {
  const settings = await readSettings();
  return {
    version: BACKUP_VERSION,
    kind: "bookmarks",
    exportedAt: new Date().toISOString(),
    label: label?.trim() || "Bookmarks",
    appName: settings.appName,
    bookmarks: settings.bookmarks,
    bookmarkGroups: settings.bookmarkGroups,
  };
}

export function bookmarksBackupFilename(backup: HomedashBookmarksBackup) {
  const slug = slugBackupLabel(backup.label);
  if (!slug || slug === "bookmarks") {
    return `homedash-bookmarks-${stamp()}.json`;
  }
  return `homedash-bookmarks-${slug}-${stamp()}.json`;
}

function toBookmarksListItem(
  filename: string,
  backup: HomedashBookmarksBackup,
  size: number,
): BookmarksBackupListItem {
  return {
    id: filename.replace(/\.json$/i, ""),
    filename,
    label: backup.label || "Bookmarks",
    exportedAt: backup.exportedAt,
    size,
    bookmarkCount: backup.bookmarks?.length || 0,
    groupCount: backup.bookmarkGroups?.length || 0,
  };
}

export async function saveBookmarksBackup(
  backup: HomedashBookmarksBackup,
  idHint?: string,
): Promise<BookmarksBackupListItem> {
  const dir = await ensureBookmarksBackupsDir();
  const base =
    idHint && isSafeBackupId(idHint) ? idHint : bookmarksBackupFilename(backup).replace(/\.json$/i, "");
  const id = base.endsWith(".json") ? base.slice(0, -5) : base;
  if (!isSafeBackupId(id)) throw new Error("Invalid backup id");
  const filename = `${id}.json`;
  const filePath = path.join(dir, filename);
  const raw = JSON.stringify(backup, null, 2);
  await fs.writeFile(filePath, raw, "utf8");
  return toBookmarksListItem(filename, backup, Buffer.byteLength(raw, "utf8"));
}

export async function listSavedBookmarksBackups(): Promise<BookmarksBackupListItem[]> {
  const dir = await ensureBookmarksBackupsDir();
  let names: string[] = [];
  try {
    names = (await fs.readdir(dir)).filter((n) => n.endsWith(".json"));
  } catch {
    return [];
  }
  const items: BookmarksBackupListItem[] = [];
  for (const filename of names) {
    const id = filename.replace(/\.json$/i, "");
    if (!isSafeBackupId(id)) continue;
    try {
      const filePath = path.join(dir, filename);
      const raw = await fs.readFile(filePath, "utf8");
      const backup = parseBookmarksBackupJson(raw);
      items.push(toBookmarksListItem(filename, backup, Buffer.byteLength(raw, "utf8")));
    } catch {
      // skip corrupt
    }
  }
  return items.sort((a, b) => b.exportedAt.localeCompare(a.exportedAt));
}

export async function readSavedBookmarksBackup(id: string): Promise<HomedashBookmarksBackup> {
  if (!isSafeBackupId(id)) throw new Error("Invalid backup id");
  const filePath = path.join(await ensureBookmarksBackupsDir(), `${id}.json`);
  const raw = await fs.readFile(filePath, "utf8");
  return parseBookmarksBackupJson(raw);
}

export async function deleteSavedBookmarksBackup(id: string) {
  if (!isSafeBackupId(id)) throw new Error("Invalid backup id");
  await fs.unlink(path.join(await ensureBookmarksBackupsDir(), `${id}.json`));
}

export function parseBookmarksBackupJson(raw: string): HomedashBookmarksBackup {
  let data: unknown;
  try {
    data = JSON.parse(raw);
  } catch {
    throw new Error("Backup file is not valid JSON");
  }
  if (!data || typeof data !== "object") throw new Error("Invalid backup payload");
  const obj = data as Record<string, unknown>;
  if (obj.version !== BACKUP_VERSION && obj.version !== 1) {
    throw new Error(`Unsupported backup version: ${String(obj.version)}`);
  }
  if (obj.kind !== "bookmarks") {
    throw new Error("Not a bookmarks backup file");
  }
  if (!Array.isArray(obj.bookmarks)) throw new Error("Backup is missing bookmarks list");
  return {
    version: BACKUP_VERSION,
    kind: "bookmarks",
    exportedAt: typeof obj.exportedAt === "string" ? obj.exportedAt : new Date().toISOString(),
    label: typeof obj.label === "string" ? obj.label : undefined,
    appName: typeof obj.appName === "string" ? obj.appName : undefined,
    bookmarks: obj.bookmarks as BookmarkItem[],
    bookmarkGroups: Array.isArray(obj.bookmarkGroups) ? (obj.bookmarkGroups as BookmarkGroup[]) : [],
  };
}

/**
 * Restore a bookmarks-only backup.
 * When `merge` is true, backup entries are combined with the current catalog
 * (backup wins on id conflicts, everything else is kept). Otherwise the
 * current bookmark catalog & groups are fully replaced.
 */
export async function restoreBookmarksBackup(
  backup: HomedashBookmarksBackup,
  opts?: { merge?: boolean },
): Promise<BookmarksRestoreResult> {
  const settings = await readSettings();
  const incomingGroups = normalizeBookmarkGroups(backup.bookmarkGroups);
  const incomingBookmarks = normalizeBookmarks(backup.bookmarks, incomingGroups);

  if (opts?.merge) {
    const groupIds = new Set(incomingGroups.map((g) => g.id));
    const mergedGroups = [
      ...incomingGroups,
      ...settings.bookmarkGroups.filter((g) => !groupIds.has(g.id)),
    ];
    const bookmarkIds = new Set(incomingBookmarks.map((b) => b.id));
    const mergedBookmarks = [
      ...incomingBookmarks,
      ...settings.bookmarks.filter((b) => !bookmarkIds.has(b.id)),
    ];
    const groups = normalizeBookmarkGroups(mergedGroups);
    const bookmarks = normalizeBookmarks(mergedBookmarks, groups);
    await writeSettings({ ...settings, bookmarks, bookmarkGroups: groups });
    return { bookmarks: bookmarks.length, groups: groups.length };
  }

  await writeSettings({ ...settings, bookmarks: incomingBookmarks, bookmarkGroups: incomingGroups });
  return { bookmarks: incomingBookmarks.length, groups: incomingGroups.length };
}

export async function backupOverview() {
  const settings = await readSettings();
  const layouts = await readLayouts();
  const widgetIds = await listWidgetConfigIds();
  const uploads = await listUploadNames();
  const backups = await listSavedBackups();
  return {
    appName: settings.appName,
    tabCount: settings.tabs?.length || 0,
    enabledWidgets: settings.enabledWidgets?.length || 0,
    layoutTabs: Object.keys(layouts).length,
    widgetConfigs: widgetIds.length,
    uploadFiles: uploads.length,
    savedBackups: backups.length,
    latestBackupAt: backups[0]?.exportedAt || null,
  };
}
