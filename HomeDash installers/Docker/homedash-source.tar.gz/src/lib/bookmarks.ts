import type { BookmarkGroup, BookmarkItem } from "./types";

export const DEFAULT_BOOKMARK_GROUP_ID = "general";

export function slugifyBookmarkGroupName(name: string) {
  return (
    name
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "") || "group"
  );
}

export function normalizeBookmarkGroups(groups: BookmarkGroup[] | undefined): BookmarkGroup[] {
  const raw = Array.isArray(groups) ? groups : [];
  const seen = new Set<string>();
  const normalized = raw
    .map((group, index) => {
      const name = String(group?.name || "").trim() || `Group ${index + 1}`;
      let id = String(group?.id || "").trim() || slugifyBookmarkGroupName(name);
      if (seen.has(id)) id = `${id}-${index + 1}`;
      seen.add(id);
      return {
        id,
        name,
        order: typeof group?.order === "number" ? group.order : index,
      };
    })
    .sort((a, b) => a.order - b.order)
    .map((group, index) => ({ ...group, order: index }));

  if (!normalized.length) {
    return [{ id: DEFAULT_BOOKMARK_GROUP_ID, name: "General", order: 0 }];
  }
  return normalized;
}

export function normalizeBookmarks(
  bookmarks: BookmarkItem[] | undefined,
  groups: BookmarkGroup[],
): BookmarkItem[] {
  const groupIds = new Set(groups.map((g) => g.id));
  const fallback = groups[0]?.id || DEFAULT_BOOKMARK_GROUP_ID;
  const list = Array.isArray(bookmarks) ? bookmarks : [];
  return list.map((item) => {
    const groupId = item.groupId && groupIds.has(item.groupId) ? item.groupId : fallback;
    return {
      ...item,
      id: item.id,
      name: item.name,
      publicUrl: item.publicUrl,
      groupId,
    };
  });
}

export function uniqueBookmarkGroupId(name: string, existing: BookmarkGroup[]) {
  const base = slugifyBookmarkGroupName(name);
  let id = base;
  let n = 2;
  const ids = new Set(existing.map((g) => g.id));
  while (ids.has(id)) id = `${base}-${n++}`;
  return id;
}

/** Chrome / instance title: "Bookmarks - {group}" */
export function formatBookmarksWidgetTitle(groupName?: string | null) {
  const name = String(groupName || "").trim() || "All bookmarks";
  return `Bookmarks - ${name}`;
}

export function resolveBookmarksWidgetTitle(
  groupId: string | null | undefined,
  groups: BookmarkGroup[] | undefined,
) {
  const id = String(groupId || "").trim();
  if (!id) return formatBookmarksWidgetTitle("All bookmarks");
  const name = groups?.find((group) => group.id === id)?.name || id;
  return formatBookmarksWidgetTitle(name);
}

/** Apply bookmark titles from in-memory widget configs (Settings form save path). */
export function withBookmarkTitlesFromConfigs<
  T extends {
    bookmarkGroups?: BookmarkGroup[];
    widgetInstances?: Array<{ id: string; widgetId: string; label: string; key: string }>;
  },
>(settings: T, configs: Record<string, Record<string, string>>): T {
  const instances = (settings.widgetInstances || []).map((inst) => {
    if (inst.widgetId !== "bookmarks") return inst;
    const groupId = configs[inst.id]?.groupId;
    const label = resolveBookmarksWidgetTitle(groupId, settings.bookmarkGroups);
    return inst.label === label ? inst : { ...inst, label };
  });
  return { ...settings, widgetInstances: instances };
}
