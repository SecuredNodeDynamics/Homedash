import type { GridItem, LayoutConfig } from "./types";

/** Built-in column counts when settings omit or reset gridCols. */
export const DEFAULT_COLS = { xxl: 8, xl: 6, lg: 6, md: 2, sm: 1 } as const;
export type Breakpoint = keyof typeof DEFAULT_COLS;
export type GridColsConfig = Record<Breakpoint, number>;

/** Stored layout keys — width breakpoints plus tablet/mobile landscape variants. */
export type LayoutSlot = Breakpoint | "mdLandscape" | "smLandscape";

export type Orientation = "portrait" | "landscape";

/** @deprecated Prefer DEFAULT_COLS / resolveGridCols — alias kept for existing imports. */
export const COLS = DEFAULT_COLS;

export const BREAKPOINT_ORDER: Breakpoint[] = ["xxl", "xl", "lg", "md", "sm"];

export const LAYOUT_SLOT_ORDER: LayoutSlot[] = [
  "xxl",
  "xl",
  "lg",
  "md",
  "mdLandscape",
  "sm",
  "smLandscape",
];

export const BREAKPOINT_LABELS: Record<Breakpoint, string> = {
  xxl: "Ultrawide",
  xl: "Wide",
  lg: "Desktop",
  md: "Tablet",
  sm: "Mobile",
};

export const BREAKPOINT_HINTS: Record<Breakpoint, string> = {
  xxl: "≥ 2560px",
  xl: "≥ 1600px",
  lg: "≥ 1024px (or mouse mid-width)",
  md: "720–1023px touch (short edge)",
  sm: "< 720px touch (short edge)",
};

export const ORIENTATION_LABELS: Record<Orientation, string> = {
  portrait: "Portrait",
  landscape: "Landscape",
};

/** Desktop floor — covers 11–14" laptop native widths and iPad landscape-ish CSS. */
export const DESKTOP_MIN_WIDTH = 1024;
/** Below this is Mobile; between this and DESKTOP_MIN_WIDTH is the tablet / mid band. */
export const TABLET_MIN_WIDTH = 720;

/** Allowed column range per device type. */
export const GRID_COLS_LIMITS: Record<Breakpoint, { min: number; max: number }> = {
  sm: { min: 1, max: 2 },
  md: { min: 1, max: 4 },
  lg: { min: 2, max: 12 },
  xl: { min: 2, max: 16 },
  xxl: { min: 2, max: 24 },
};

export function clampGridCols(bp: Breakpoint, value: number): number {
  const { min, max } = GRID_COLS_LIMITS[bp];
  if (!Number.isFinite(value)) return DEFAULT_COLS[bp];
  return Math.min(max, Math.max(min, Math.round(value)));
}

export function resolveGridCols(partial?: Partial<GridColsConfig> | null): GridColsConfig {
  const next: GridColsConfig = { ...DEFAULT_COLS };
  if (!partial || typeof partial !== "object") return next;
  for (const bp of BREAKPOINT_ORDER) {
    if (partial[bp] != null) next[bp] = clampGridCols(bp, Number(partial[bp]));
  }
  return next;
}

/** Prior grid widths — used to migrate saved layouts into the current COLS map. */
const LEGACY_COL_CANDIDATES = [24, 16, 12, 10, 8, 6, 5, 4] as const;

/**
 * True when the primary pointing device is mouse/trackpad-like.
 * Used to keep small / windowed laptops on Desktop instead of Tablet.
 * Touch-only tablets typically fail this (hover: none, pointer: coarse).
 */
export function isPointerDesktop(): boolean {
  if (typeof window === "undefined" || typeof window.matchMedia !== "function") {
    return false;
  }
  try {
    return window.matchMedia("(hover: hover) and (pointer: fine)").matches;
  } catch {
    return false;
  }
}

/**
 * Pick layout device class from viewport size (+ pointer capability in the mid band).
 * Mid-width (720–1023): Tablet for touch-first devices; Desktop when a fine pointer
 * with hover is available (small laptops, docked tablets with mouse).
 *
 * Touch-first devices are classified by the *shorter* edge so rotating the device
 * does not jump Mobile→Tablet or Tablet→Desktop (which would skip landscape slots).
 */
export function pickBreakpoint(width: number, preferDesktop = isPointerDesktop()): Breakpoint {
  let span = width;
  if (!preferDesktop && typeof window !== "undefined") {
    const height = window.innerHeight || width;
    span = Math.min(width, height);
  }
  if (span >= 2560) return "xxl";
  if (span >= 1600) return "xl";
  if (span >= DESKTOP_MIN_WIDTH) return "lg";
  if (span >= TABLET_MIN_WIDTH) return preferDesktop ? "lg" : "md";
  return "sm";
}

export function supportsOrientation(bp: Breakpoint): bp is "md" | "sm" {
  return bp === "md" || bp === "sm";
}

export function baseBreakpoint(slot: LayoutSlot): Breakpoint {
  if (slot === "mdLandscape") return "md";
  if (slot === "smLandscape") return "sm";
  return slot;
}

export function resolveLayoutSlot(bp: Breakpoint, orientation: Orientation): LayoutSlot {
  if (orientation === "landscape" && bp === "md") return "mdLandscape";
  if (orientation === "landscape" && bp === "sm") return "smLandscape";
  return bp;
}

export function orientationForSlot(slot: LayoutSlot): Orientation {
  return slot === "mdLandscape" || slot === "smLandscape" ? "landscape" : "portrait";
}

/**
 * Read viewport orientation. Prefer the CSS media query; fall back to geometry
 * when the query is still stale mid-`orientationchange` (common on iOS/Android).
 */
export function readOrientationMedia(): Orientation {
  if (typeof window === "undefined") return "portrait";
  try {
    if (window.matchMedia("(orientation: landscape)").matches) return "landscape";
    if (window.matchMedia("(orientation: portrait)").matches) return "portrait";
  } catch {
    /* ignore */
  }
  return window.innerWidth > window.innerHeight ? "landscape" : "portrait";
}

export function scaleLayout(items: GridItem[], fromCols: number, toCols: number): GridItem[] {
  if (fromCols === toCols || !items.length) {
    return items.map((item) => clampItemToCols(item, toCols));
  }
  const ratio = toCols / fromCols;
  return items.map((item) => {
    const minW = Math.min(item.minW ?? 1, toCols);
    const w = Math.min(toCols, Math.max(minW, Math.round(item.w * ratio)));
    const x = Math.min(Math.max(0, Math.round(item.x * ratio)), Math.max(0, toCols - w));
    return clampItemToCols(
      {
        ...item,
        x,
        w,
        minW,
        ...(item.maxW != null ? { maxW: Math.min(item.maxW, toCols) } : {}),
      },
      toCols,
    );
  });
}

function clampItemToCols(item: GridItem, cols: number): GridItem {
  const w = Math.min(Math.max(1, item.w), cols);
  const x = Math.min(Math.max(0, item.x), Math.max(0, cols - w));
  return {
    ...item,
    x,
    w,
    ...(item.minW != null ? { minW: Math.min(item.minW, cols) } : {}),
    ...(item.maxW != null ? { maxW: Math.min(item.maxW, cols) } : {}),
  };
}

/** Drop per-card size locks, hide flags, and order — used when copying/scaling across device breakpoints. */
export function stripCrossBreakpointMeta(items: GridItem[]): GridItem[] {
  return items.map((item) => {
    if (!item.sizeLocked && !item.hidden && item.order == null) return item;
    const next = { ...item };
    delete next.sizeLocked;
    delete next.hidden;
    delete next.order;
    return next;
  });
}

/** @deprecated Prefer stripCrossBreakpointMeta — kept for older call sites. */
export function stripSizeLocks(items: GridItem[]): GridItem[] {
  return stripCrossBreakpointMeta(items);
}

/** Infer the column count a saved breakpoint was authored against. */
export function inferSourceCols(items: GridItem[], targetCols: number): number {
  if (!items.length) return targetCols;
  const span = Math.max(...items.map((item) => item.x + item.w), 1);
  if (span > targetCols) {
    for (const legacy of LEGACY_COL_CANDIDATES) {
      if (span <= legacy) return legacy;
    }
    return Math.max(span, targetCols);
  }
  // Upsize full-width layouts from a prior grid (e.g. 5 → 6, or custom 8 → 10).
  for (let prior = targetCols - 1; prior >= 1; prior -= 1) {
    if (span === prior) return prior;
  }
  return targetCols;
}

function migrateSlotItems(
  items: GridItem[] | undefined,
  targetCols: number,
  savedFrom?: number,
): GridItem[] | undefined {
  if (!items?.length) return items;
  // Prefer the recorded save-time column count over guessing from item spans.
  // Guessing (inferSourceCols) misidentifies any intentionally-narrow card as
  // a legacy full-width card and stretches it — only fall back to it for
  // pre-existing data saved before savedCols existed.
  const from = savedFrom ?? inferSourceCols(items, targetCols);
  return from === targetCols
    ? items.map((item) => clampItemToCols(item, targetCols))
    : scaleLayout(items, from, targetCols);
}

/**
 * Scale each breakpoint's items from legacy col counts into the target cols map.
 * Runs on every load and save, so it must be a no-op unless the grid-cols
 * setting has genuinely changed since the layout was last saved — it uses
 * `layout.savedCols` (stamped below) for that comparison rather than
 * inferring it from item geometry.
 */
export function migrateLayoutToCurrentCols(
  layout: LayoutConfig,
  cols: GridColsConfig = DEFAULT_COLS,
): LayoutConfig {
  const savedCols = layout.savedCols;
  const next: LayoutConfig = {
    lg: layout.lg || [],
    md: layout.md || [],
    sm: layout.sm || [],
    xl: layout.xl || [],
    xxl: layout.xxl || [],
    ...(layout.mdLandscape?.length ? { mdLandscape: layout.mdLandscape } : {}),
    ...(layout.smLandscape?.length ? { smLandscape: layout.smLandscape } : {}),
    ...(layout.locked ? { locked: layout.locked } : {}),
  };
  for (const bp of BREAKPOINT_ORDER) {
    const items = next[bp];
    if (!items?.length) continue;
    next[bp] = migrateSlotItems(items, cols[bp], savedCols?.[bp]) || [];
  }
  if (next.mdLandscape?.length) {
    next.mdLandscape = migrateSlotItems(next.mdLandscape, cols.md, savedCols?.md);
  }
  if (next.smLandscape?.length) {
    next.smLandscape = migrateSlotItems(next.smLandscape, cols.sm, savedCols?.sm);
  }
  // Stamp the cols this layout is now authored against so future load/save
  // passes compare against a known value instead of re-guessing.
  next.savedCols = { ...cols };
  return next;
}

function slotItems(layout: LayoutConfig, slot: LayoutSlot): GridItem[] | undefined {
  return layout[slot];
}

/** True when this slot has an explicitly saved placement array. */
export function hasStoredBreakpoint(layout: LayoutConfig, slot: LayoutSlot): boolean {
  return Boolean(slotItems(layout, slot)?.length);
}

/**
 * Resolve items for a layout slot.
 * Empty xl/xxl fall back to a scaled desktop (lg) layout for viewing.
 * Empty landscape slots fall back to the same-device portrait layout.
 * Ephemeral fallbacks never inherit another device's card size-locks or # order.
 */
export function layoutForBreakpoint(
  layout: LayoutConfig,
  slot: LayoutSlot,
  cols: GridColsConfig = DEFAULT_COLS,
): GridItem[] {
  const stored = slotItems(layout, slot);
  if (stored?.length) return stored;

  const bp = baseBreakpoint(slot);
  if (slot === "mdLandscape" || slot === "smLandscape") {
    const portrait = layout[bp];
    if (portrait?.length) return portrait.map((item) => ({ ...item }));
    return [];
  }

  if (bp === "xl" || bp === "xxl") {
    const base = layout.lg?.length ? layout.lg : [];
    return stripCrossBreakpointMeta(scaleLayout(base, cols.lg, cols[bp]));
  }
  if (bp === "md") return layout.md || [];
  if (bp === "sm") return layout.sm || [];
  return layout.lg || [];
}

/**
 * Ensure `layout[slot]` is a concrete saved array (not an ephemeral scale/fallback).
 * Landscape seeds from same-device portrait when available, else desktop seed path.
 */
export function ensureBreakpointLayout(
  layout: LayoutConfig,
  slot: LayoutSlot,
  cols: GridColsConfig = DEFAULT_COLS,
): LayoutConfig {
  if (slotItems(layout, slot)?.length) return layout;

  const bp = baseBreakpoint(slot);
  if (slot === "mdLandscape" || slot === "smLandscape") {
    const portrait = layout[bp];
    if (portrait?.length) {
      return {
        ...layout,
        [slot]: portrait.map((item) => ({ ...item })),
      };
    }
  }

  const sourceBp: Breakpoint =
    (layout.lg?.length ? "lg" : null) ||
    BREAKPOINT_ORDER.find((key) => layout[key]?.length) ||
    "lg";
  const source = layout[sourceBp] || [];
  if (!source.length) return layout;

  return {
    ...layout,
    [slot]: stripCrossBreakpointMeta(scaleLayout(source, cols[sourceBp], cols[bp])),
  };
}

/** Replace target slot with a scaled copy of Desktop (lg). Locks and # order stay on Desktop only. */
export function copyDesktopToBreakpoint(
  layout: LayoutConfig,
  slot: LayoutSlot,
  cols: GridColsConfig = DEFAULT_COLS,
): LayoutConfig {
  const bp = baseBreakpoint(slot);
  if (slot === "lg") return { ...layout, lg: [...(layout.lg || [])] };
  const source = layout.lg || [];
  return {
    ...layout,
    [slot]: stripCrossBreakpointMeta(scaleLayout(source, cols.lg, cols[bp])),
  };
}

export function isBreakpointLocked(layout: LayoutConfig, slot: LayoutSlot): boolean {
  return Boolean(layout.locked?.[slot]);
}

export function setBreakpointLocked(
  layout: LayoutConfig,
  slot: LayoutSlot,
  locked: boolean,
): LayoutConfig {
  const nextLocked = { ...(layout.locked || {}) };
  if (locked) nextLocked[slot] = true;
  else delete nextLocked[slot];
  const hasAny = Object.values(nextLocked).some(Boolean);
  return {
    ...layout,
    locked: hasAny ? nextLocked : undefined,
  };
}
