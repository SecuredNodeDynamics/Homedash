import { promises as fs } from "fs";
import path from "path";
import { cache } from "react";
import type { AppSettings, GridItem, LayoutConfig, LayoutsByTab } from "./types";
import {
  buildDefaultTabs,
  buildLayoutForWidgets,
  defaultAppSettings,
  emptyLayout,
  normalizeTabs,
  WIDGET_LAYOUT_SIZES,
} from "./tabs";
import { defaultInstancesFromHomepage, normalizeWidgetInstances, parseInstanceId } from "./instances";
import {
  formatBookmarksWidgetTitle,
  normalizeBookmarkGroups,
  normalizeBookmarks,
  resolveBookmarksWidgetTitle,
} from "./bookmarks";
import { applyNodeTitleToInstance, isNodeTitleWidget } from "./widget-titles";
import { migrateLayoutToCurrentCols, resolveGridCols } from "./breakpoints";
import { atomicWriteJson } from "./atomic-file";
import { resolveVerticalOverlaps } from "./auto-layout";

export const DEFAULT_SETTINGS: AppSettings = defaultAppSettings();

export function getConfigDir() {
  return process.env.HOMEDASH_CONFIG_DIR || path.join(process.cwd(), "config");
}

async function ensureConfigDir() {
  const dir = getConfigDir();
  await fs.mkdir(path.join(dir, "widgets"), { recursive: true });
  await fs.mkdir(path.join(dir, "uploads"), { recursive: true });
  return dir;
}

async function readJsonFile<T>(filePath: string, fallback: T): Promise<T> {
  try {
    const raw = await fs.readFile(filePath, "utf8");
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function normalizeLocked(
  data: Partial<LayoutConfig> | undefined,
  fallback: LayoutConfig,
): LayoutConfig["locked"] {
  const raw = data?.locked ?? fallback.locked;
  if (!raw || typeof raw !== "object") return undefined;
  const locked: NonNullable<LayoutConfig["locked"]> = {};
  for (const bp of ["xxl", "xl", "lg", "md", "sm", "mdLandscape", "smLandscape"] as const) {
    if (raw[bp]) locked[bp] = true;
  }
  return Object.keys(locked).length ? locked : undefined;
}

function normalizeGridItems(items: unknown, fallback: GridItem[]): GridItem[] {
  if (!Array.isArray(items)) return fallback.map((item) => ({ ...item }));
  const next: GridItem[] = [];
  for (const raw of items) {
    if (!raw || typeof raw !== "object") continue;
    const item = raw as Partial<GridItem>;
    if (typeof item.i !== "string" || !item.i) continue;
    const x = Number(item.x);
    const y = Number(item.y);
    const w = Number(item.w);
    const h = Number(item.h);
    if (![x, y, w, h].every((n) => Number.isFinite(n))) continue;
    const normalized: GridItem = {
      i: item.i,
      x,
      y,
      w: Math.max(1, w),
      h: Math.max(1, h),
    };
    if (item.minW != null && Number.isFinite(Number(item.minW))) normalized.minW = Math.max(1, Number(item.minW));
    if (item.minH != null && Number.isFinite(Number(item.minH))) normalized.minH = Math.max(1, Number(item.minH));
    if (item.maxW != null && Number.isFinite(Number(item.maxW))) normalized.maxW = Math.max(1, Number(item.maxW));
    if (item.maxH != null && Number.isFinite(Number(item.maxH))) normalized.maxH = Math.max(1, Number(item.maxH));
    if (item.sizeLocked) normalized.sizeLocked = true;
    if (item.hidden) normalized.hidden = true;
    if (item.order != null && Number.isFinite(Number(item.order))) {
      const order = Math.max(1, Math.round(Number(item.order)));
      normalized.order = order;
    }
    next.push(normalized);
  }
  return next;
}

function normalizeLayout(
  data: Partial<LayoutConfig> | undefined,
  fallback: LayoutConfig,
  gridCols = resolveGridCols(),
): LayoutConfig {
  const locked = normalizeLocked(data, fallback);
  const raw: LayoutConfig = {
    xxl: normalizeGridItems(data?.xxl, fallback.xxl || []),
    xl: normalizeGridItems(data?.xl, fallback.xl || []),
    lg: normalizeGridItems(data?.lg, fallback.lg || []),
    md: normalizeGridItems(data?.md, fallback.md || []),
    sm: normalizeGridItems(data?.sm, fallback.sm || []),
    mdLandscape: normalizeGridItems(data?.mdLandscape, fallback.mdLandscape || []),
    smLandscape: normalizeGridItems(data?.smLandscape, fallback.smLandscape || []),
    ...(locked ? { locked } : {}),
    ...(data?.savedCols ? { savedCols: data.savedCols } : {}),
  };
  // Drop empty optional landscape arrays so disk stays lean.
  if (!raw.mdLandscape?.length) delete raw.mdLandscape;
  if (!raw.smLandscape?.length) delete raw.smLandscape;
  const migrated = migrateLayoutToCurrentCols(raw, gridCols);
  for (const key of ["xxl", "xl", "lg", "md", "sm", "mdLandscape", "smLandscape"] as const) {
    if (migrated[key]?.length) {
      migrated[key] = resolveVerticalOverlaps(migrated[key]!);
    }
  }
  return migrated;
}

export const readSettings = cache(async (): Promise<AppSettings> => {
  const dir = await ensureConfigDir();
  const data = await readJsonFile<Partial<AppSettings>>(path.join(dir, "settings.json"), {});
  const tabs = normalizeTabs(data.tabs);
  const enabledFromTabs = Array.from(new Set(tabs.flatMap((t) => t.widgetIds)));
  const enabledWidgets = data.enabledWidgets?.length ? data.enabledWidgets : enabledFromTabs;
  const bookmarkGroups = normalizeBookmarkGroups(data.bookmarkGroups);
  const bookmarks = normalizeBookmarks(
    Array.isArray(data.bookmarks) ? data.bookmarks : [],
    bookmarkGroups,
  );
  return {
    ...DEFAULT_SETTINGS,
    ...data,
    theme: { ...DEFAULT_SETTINGS.theme, ...(data.theme || {}) },
    gridCols: resolveGridCols(data.gridCols),
    tabs,
    enabledWidgets,
    widgetAccents: data.widgetAccents || {},
    widgetIcons: data.widgetIcons || {},
    widgetChrome: data.widgetChrome || {},
    widgetInstances: normalizeWidgetInstances(
      data.widgetInstances?.length ? data.widgetInstances : defaultInstancesFromHomepage(),
      enabledWidgets,
    ),
    bookmarkGroups,
    bookmarks,
  };
});

export async function writeSettings(settings: AppSettings) {
  const dir = await ensureConfigDir();
  const tabs = normalizeTabs(settings.tabs);
  const enabledWidgets = settings.enabledWidgets?.length
    ? settings.enabledWidgets
    : Array.from(new Set(tabs.flatMap((t) => t.widgetIds)));
  const bookmarkGroups = normalizeBookmarkGroups(settings.bookmarkGroups);
  const bookmarks = normalizeBookmarks(
    Array.isArray(settings.bookmarks) ? settings.bookmarks : [],
    bookmarkGroups,
  );
  const normalized: AppSettings = {
    ...settings,
    tabs,
    enabledWidgets,
    gridCols: resolveGridCols(settings.gridCols),
    widgetInstances: normalizeWidgetInstances(settings.widgetInstances, enabledWidgets),
    bookmarkGroups,
    bookmarks,
  };
  await atomicWriteJson(path.join(dir, "settings.json"), normalized);
}

export const readLayouts = cache(async (): Promise<LayoutsByTab> => {
  const dir = await ensureConfigDir();
  const settings = await readSettings();
  const gridCols = resolveGridCols(settings.gridCols);
  const stored = await readJsonFile<LayoutsByTab>(path.join(dir, "layouts.json"), {});
  const legacy = await readJsonFile<Partial<LayoutConfig> | null>(path.join(dir, "layout.json"), null);

  const result: LayoutsByTab = {};
  for (const tab of settings.tabs) {
    if (stored[tab.id]?.lg?.length) {
      result[tab.id] = normalizeLayout(stored[tab.id], emptyLayout(), gridCols);
      continue;
    }
    if (legacy && tab.order === 0 && (legacy.lg?.length || 0) > 0) {
      result[tab.id] = normalizeLayout(legacy, emptyLayout(), gridCols);
      continue;
    }
    result[tab.id] = buildLayoutForWidgets(tab.widgetIds, WIDGET_LAYOUT_SIZES);
  }
  return result;
});

export async function readTabLayout(tabId: string): Promise<LayoutConfig> {
  const layouts = await readLayouts();
  return layouts[tabId] || emptyLayout();
}

export async function writeTabLayout(tabId: string, layout: LayoutConfig) {
  const dir = await ensureConfigDir();
  const settings = await readSettings();
  const gridCols = resolveGridCols(settings.gridCols);
  const layouts = await readJsonFile<LayoutsByTab>(path.join(dir, "layouts.json"), {});
  layouts[tabId] = normalizeLayout(layout, emptyLayout(), gridCols);
  await atomicWriteJson(path.join(dir, "layouts.json"), layouts);
}

/** @deprecated use readTabLayout / writeTabLayout */
export async function readLayout(): Promise<LayoutConfig> {
  const settings = await readSettings();
  const first = settings.tabs[0];
  if (!first) return emptyLayout();
  return readTabLayout(first.id);
}

export async function writeLayout(layout: LayoutConfig) {
  const settings = await readSettings();
  const first = settings.tabs[0];
  if (!first) return;
  await writeTabLayout(first.id, layout);
}

export async function ensureTabLayoutsSeeded() {
  const dir = await ensureConfigDir();
  const settings = await readSettings();
  const layouts = await readJsonFile<LayoutsByTab>(path.join(dir, "layouts.json"), {});
  let changed = false;
  for (const tab of settings.tabs) {
    if (!layouts[tab.id]?.lg?.length) {
      layouts[tab.id] = buildLayoutForWidgets(tab.widgetIds, WIDGET_LAYOUT_SIZES);
      changed = true;
    }
  }
  if (changed || !Object.keys(layouts).length) {
    await atomicWriteJson(path.join(dir, "layouts.json"), layouts);
  }
  if (!settings.tabs?.length) {
    await writeSettings({ ...settings, tabs: buildDefaultTabs() });
  }
}

export async function readWidgetConfig(id: string): Promise<Record<string, string>> {
  const dir = await ensureConfigDir();
  return readJsonFile<Record<string, string>>(path.join(dir, "widgets", `${id}.json`), {});
}

export async function writeWidgetConfig(id: string, config: Record<string, string>) {
  const dir = await ensureConfigDir();
  await atomicWriteJson(path.join(dir, "widgets", `${id}.json`), config);
}

/**
 * Keep auto-titled multi-instance labels in sync:
 *  - bookmarks → "Bookmarks - {group}"
 *  - speedtest / net-glances → "{Name} - {PVE ID}"
 * Persists when any label changes. Safe to call on dashboard load.
 */
export async function syncBookmarkInstanceLabels(settings?: AppSettings): Promise<AppSettings> {
  const current = settings || (await readSettings());
  const instances = current.widgetInstances || [];
  let changed = false;
  const nextInstances = [];
  for (const inst of instances) {
    const widgetId = inst.widgetId || parseInstanceId(inst.id).widgetId;
    if (widgetId === "bookmarks") {
      const config = await readWidgetConfig(inst.id);
      const label = resolveBookmarksWidgetTitle(config.groupId, current.bookmarkGroups);
      if (inst.label !== label) {
        changed = true;
        nextInstances.push({ ...inst, label });
      } else {
        nextInstances.push(inst);
      }
      continue;
    }

    if (isNodeTitleWidget(widgetId)) {
      const config = await readWidgetConfig(inst.id);
      const next = applyNodeTitleToInstance({ ...inst, widgetId }, config);
      if (next.label !== inst.label) {
        changed = true;
        nextInstances.push(next);
      } else {
        nextInstances.push(inst);
      }
      continue;
    }

    nextInstances.push(inst);
  }
  if (!changed) return current;
  const next = { ...current, widgetInstances: nextInstances };
  await writeSettings(next);
  return next;
}

export { formatBookmarksWidgetTitle, resolveBookmarksWidgetTitle };
