import type { AppSettings, DashboardTab, GridItem, LayoutConfig, WidgetInstance } from "./types";
import {
  formatInstanceId,
  instancesForWidget,
  isMultiInstanceWidget,
  parseInstanceId,
  slugInstanceKey,
} from "./instances";

/** Drop a card from the current tab's widgetIds, expanding bare package ids when needed. */
export function removeCardFromTabWidgetIds(
  widgetIds: string[],
  instanceId: string,
  instances: WidgetInstance[],
): string[] {
  const { widgetId } = parseInstanceId(instanceId);
  const allInst = instancesForWidget(instances, widgetId);
  const next: string[] = [];

  for (const entry of widgetIds) {
    if (entry === instanceId) continue;
    if (entry === widgetId && isMultiInstanceWidget(widgetId) && allInst.length) {
      for (const inst of allInst) {
        if (inst.id !== instanceId) next.push(inst.id);
      }
      continue;
    }
    next.push(entry);
  }

  return next;
}

/** Remove layout items whose `i` is in `ids` across all breakpoints / orientation slots. */
export function pruneLayoutIds(layout: LayoutConfig, ids: Set<string>): LayoutConfig {
  const prune = (items?: GridItem[]) => (items ? items.filter((item) => !ids.has(item.i)) : items);
  const next: LayoutConfig = {
    lg: prune(layout.lg) || [],
    md: prune(layout.md) || [],
    sm: prune(layout.sm) || [],
  };
  if (layout.xl) next.xl = prune(layout.xl);
  if (layout.xxl) next.xxl = prune(layout.xxl);
  const mdLandscape = prune(layout.mdLandscape);
  const smLandscape = prune(layout.smLandscape);
  if (mdLandscape?.length) next.mdLandscape = mdLandscape;
  if (smLandscape?.length) next.smLandscape = smLandscape;
  if (layout.locked) next.locked = layout.locked;
  return next;
}

/** True when this package (or any of its instances) is already on the tab. */
export function tabHasWidgetPackage(tab: DashboardTab, widgetId: string): boolean {
  return tab.widgetIds.some((entry) => parseInstanceId(entry).widgetId === widgetId);
}

export function createServerInstance(
  settings: AppSettings,
  widgetId: string,
  widgetName: string,
): { settings: AppSettings; instance: WidgetInstance } {
  const current = instancesForWidget(settings.widgetInstances || [], widgetId);
  const keys = current.map((i) => i.key);
  const label = `${widgetName} ${current.length + 1}`;
  const key = slugInstanceKey(label, keys);
  const id = formatInstanceId(widgetId, key);
  const instance: WidgetInstance = { id, widgetId, key, label };
  const others = (settings.widgetInstances || []).filter((i) => i.widgetId !== widgetId);
  return {
    instance,
    settings: {
      ...settings,
      widgetInstances: [...others, ...current, instance],
      enabledWidgets: settings.enabledWidgets.includes(widgetId)
        ? settings.enabledWidgets
        : [...settings.enabledWidgets, widgetId],
    },
  };
}

/** Merge an updated tab into settings.tabs. */
export function withUpdatedTab(settings: AppSettings, tab: DashboardTab): AppSettings {
  return {
    ...settings,
    tabs: (settings.tabs || []).map((t) => (t.id === tab.id ? tab : t)),
  };
}
