import type { ReactNode } from "react";

export type HeaderQuickLinkId =
  | "google-calendar"
  | "google-drive"
  | "google-search"
  | "gmail"
  | "instagram"
  | "facebook"
  | "threads"
  | "linkedin";

export type HeaderQuickLinks = Partial<Record<HeaderQuickLinkId, boolean>>;

export type HeaderQuickLinksPlacement = "left" | "center" | "right";

export type HeaderQuickLinkItem = {
  id: string;
  label: string;
  href: string;
  enabled: boolean;
  /** Emoji/short glyph or an image URL. Empty keeps a built-in link's brand SVG. */
  icon?: string;
  color?: string;
};

export type HeaderQuickLinkDef = {
  id: HeaderQuickLinkId;
  label: string;
  href: string;
  /** Brand accent used for the icon glyph */
  color: string;
  icon: ReactNode;
};

/** Android packages for the built-in header destinations. */
const ANDROID_QUICK_LINK_PACKAGES: Partial<Record<HeaderQuickLinkId, string>> = {
  "google-search": "com.google.android.googlequicksearchbox",
  gmail: "com.google.android.gm",
  "google-calendar": "com.google.android.calendar",
  "google-drive": "com.google.android.apps.docs",
  instagram: "com.instagram.android",
  facebook: "com.facebook.katana",
  threads: "com.instagram.barcelona",
  linkedin: "com.linkedin.android",
};

/**
 * Returns an Android intent that opens the native app when installed and falls
 * back to the configured web URL otherwise. Non-Android and custom links keep
 * their normal web URL.
 */
export function quickLinkHrefForDevice(id: string, href: string) {
  if (typeof navigator === "undefined" || !/android/i.test(navigator.userAgent)) return href;
  const packageName = ANDROID_QUICK_LINK_PACKAGES[id as HeaderQuickLinkId];
  if (!packageName) return href;

  try {
    const url = new URL(href);
    if (url.protocol !== "http:" && url.protocol !== "https:") return href;
    const scheme = url.protocol.slice(0, -1);
    const destination = `${url.host}${url.pathname}${url.search}`;
    return `intent://${destination}#Intent;scheme=${scheme};package=${packageName};S.browser_fallback_url=${encodeURIComponent(href)};end`;
  } catch {
    return href;
  }
}

/**
 * Opens an Android Quick Link. The installed APK uses its native Capacitor
 * bridge; Android browsers use an intent URL. Returns false for normal web or
 * custom links so the anchor can perform its default navigation.
 */
export function openQuickLinkForDevice(id: string, href: string) {
  if (typeof navigator === "undefined" || !/android/i.test(navigator.userAgent)) return false;
  const packageName = ANDROID_QUICK_LINK_PACKAGES[id as HeaderQuickLinkId];
  if (!packageName) return false;

  const androidWindow = (
    window as typeof window & {
      HomedashAndroid?: {
        openQuickLink: (packageName: string, fallbackUrl: string) => void;
      };
      Capacitor?: {
        Plugins?: {
          HomedashAppLauncher?: {
            open: (options: { packageName: string; url: string }) => Promise<unknown>;
          };
        };
      };
    }
  );
  if (androidWindow.HomedashAndroid?.openQuickLink) {
    androidWindow.HomedashAndroid.openQuickLink(packageName, href);
    return true;
  }

  const capacitor = androidWindow.Capacitor;
  const nativeLauncher = capacitor?.Plugins?.HomedashAppLauncher;
  if (nativeLauncher?.open) {
    void nativeLauncher.open({ packageName, url: href }).catch(() => {
      window.open(href, "_blank", "noopener,noreferrer");
    });
    return true;
  }

  window.location.assign(quickLinkHrefForDevice(id, href));
  return true;
}

function Svg({ children, label }: { children: ReactNode; label: string }) {
  return (
    <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false">
      <title>{label}</title>
      {children}
    </svg>
  );
}

/** Canonical list — order is display order in the header. */
export const HEADER_QUICK_LINKS: HeaderQuickLinkDef[] = [
  {
    id: "google-search",
    label: "Google Search",
    href: "https://www.google.com/",
    color: "#4285F4",
    icon: (
      <Svg label="Google Search">
        <path
          fill="#4285F4"
          d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1Z"
        />
        <path
          fill="#34A853"
          d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23Z"
        />
        <path
          fill="#FBBC05"
          d="M5.84 14.09A7.23 7.23 0 0 1 5.5 12c0-.73.13-1.43.34-2.09V7.07H2.18A11.96 11.96 0 0 0 1 12c0 1.94.46 3.77 1.18 5.43l3.66-3.34Z"
        />
        <path
          fill="#EA4335"
          d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53Z"
        />
      </Svg>
    ),
  },
  {
    id: "gmail",
    label: "Gmail",
    href: "https://mail.google.com/",
    color: "#EA4335",
    icon: (
      <Svg label="Gmail">
        <path
          fill="#EA4335"
          d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2Zm0 4.2-8 5-8-5V6l8 5 8-5v2.2Z"
        />
      </Svg>
    ),
  },
  {
    id: "google-calendar",
    label: "Google Calendar",
    href: "https://calendar.google.com/",
    color: "#1A73E8",
    icon: (
      <Svg label="Google Calendar">
        <path
          fill="#1A73E8"
          d="M19 4h-1V2h-2v2H8V2H6v2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2Zm0 16H5V10h14v10Zm0-12H5V6h14v2Z"
        />
        <path fill="#EA4335" d="M8 13h2v2H8zm0 4h2v2H8zm4-4h2v2h-2zm0 4h2v2h-2zm4-4h2v2h-2z" />
      </Svg>
    ),
  },
  {
    id: "google-drive",
    label: "Google Drive",
    href: "https://drive.google.com/",
    color: "#1FA463",
    icon: (
      <Svg label="Google Drive">
        <path fill="#0066DA" d="M8.59 3.5h6.82L22 15.5h-6.82L8.59 3.5Z" />
        <path fill="#00AC47" d="M2 15.5 8.59 3.5h6.82L8.82 15.5H2Z" />
        <path fill="#FFBA00" d="m2 15.5 3.41 5.5h13.18L22 15.5H2Z" />
      </Svg>
    ),
  },
  {
    id: "instagram",
    label: "Instagram",
    href: "https://www.instagram.com/",
    color: "#E4405F",
    icon: (
      <Svg label="Instagram">
        <path
          fill="#E4405F"
          d="M7 2h10a5 5 0 0 1 5 5v10a5 5 0 0 1-5 5H7a5 5 0 0 1-5-5V7a5 5 0 0 1 5-5Zm0 2a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3H7Zm11.2 1.3a1.2 1.2 0 1 1 0 2.4 1.2 1.2 0 0 1 0-2.4ZM12 7.2A4.8 4.8 0 1 1 12 16.8 4.8 4.8 0 0 1 12 7.2Zm0 2a2.8 2.8 0 1 0 0 5.6 2.8 2.8 0 0 0 0-5.6Z"
        />
      </Svg>
    ),
  },
  {
    id: "facebook",
    label: "Facebook",
    href: "https://www.facebook.com/",
    color: "#1877F2",
    icon: (
      <Svg label="Facebook">
        <path
          fill="#1877F2"
          d="M22 12.06C22 6.5 17.52 2 12 2S2 6.5 2 12.06c0 5.02 3.66 9.18 8.44 9.94v-7.03H7.9v-2.91h2.54V9.84c0-2.51 1.49-3.9 3.77-3.9 1.09 0 2.24.2 2.24.2v2.47h-1.26c-1.24 0-1.63.78-1.63 1.57v1.88h2.78l-.44 2.91h-2.34V22C18.34 21.24 22 17.08 22 12.06Z"
        />
      </Svg>
    ),
  },
  {
    id: "threads",
    label: "Threads",
    href: "https://www.threads.net/",
    color: "#FFFFFF",
    icon: (
      <Svg label="Threads">
        <path
          fill="currentColor"
          d="M12.2 2C7.6 2 5 4.7 5 8.8c0 2.6 1.1 4.5 3.1 5.5-.2.5-.4 1.2-.4 1.9 0 .6.2 1.3.5 1.8l.1.2-.2.1A7.4 7.4 0 0 1 5.3 21l.9 1.3c.9-.6 1.7-1.2 2.4-1.9.9.3 1.9.5 3.1.5 5.1 0 8.3-3.1 8.3-7.7C20 5.1 17.1 2 12.2 2Zm.2 14.8c-.8 0-1.5-.1-2.1-.3.2-.4.3-.9.3-1.4 0-.5-.1-1-.3-1.4.5-.1 1.1-.2 1.8-.2 2.4 0 3.9 1.2 3.9 3.1 0 .8-.7 1.9-3.6 2.2Zm2.5-6.4c-.6-.5-1.5-.8-2.6-.9V7.9c1.4.1 2.3.7 2.4 1.8.1.4 0 .8-.2 1.1.1.1.3.3.4.6Zm-4.4-1.2v1.6c-1.5.2-2.4.8-2.4 1.9 0 1.1.9 1.8 2.4 1.9v1.6c-2.4-.2-4-1.5-4-3.5 0-2.1 1.7-3.3 4-3.5Z"
        />
      </Svg>
    ),
  },
  {
    id: "linkedin",
    label: "LinkedIn",
    href: "https://www.linkedin.com/",
    color: "#0A66C2",
    icon: (
      <Svg label="LinkedIn">
        <path
          fill="#0A66C2"
          d="M20.45 20.45h-3.56v-5.57c0-1.33-.02-3.04-1.85-3.04-1.85 0-2.14 1.45-2.14 2.94v5.67H9.35V9h3.41v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28ZM5.34 7.43a2.06 2.06 0 1 1 0-4.12 2.06 2.06 0 0 1 0 4.12ZM7.12 20.45H3.56V9h3.56v11.45ZM22 0H2C.9 0 0 .9 0 2v20c0 1.1.9 2 2 2h20c1.1 0 2-.9 2-2V2c0-1.1-.9-2-2-2Z"
        />
      </Svg>
    ),
  },
];

export function normalizeHeaderQuickLinks(value?: HeaderQuickLinks | null): HeaderQuickLinks {
  const next: HeaderQuickLinks = {};
  for (const link of HEADER_QUICK_LINKS) {
    next[link.id] = Boolean(value?.[link.id]);
  }
  return next;
}

export function normalizeHeaderQuickLinksPlacement(
  value?: HeaderQuickLinksPlacement | null,
): HeaderQuickLinksPlacement {
  if (value === "left" || value === "center" || value === "right") return value;
  return "right";
}

function safeHref(value: unknown) {
  const href = String(value || "").trim();
  if (/^https?:\/\//i.test(href) || href.startsWith("/")) return href.slice(0, 2048);
  return "";
}

function customIcon(value: string | undefined, label: string, color?: string) {
  const icon = String(value || "").trim();
  if (/^(https?:\/\/|\/)/i.test(icon)) {
    // User-managed quick-link icons may be local uploads or arbitrary remote assets.
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={icon} alt="" width="18" height="18" style={{ objectFit: "contain" }} />;
  }
  return (
    <span
      aria-hidden="true"
      style={{ color: color || "currentColor", fontSize: "16px", fontWeight: 800, lineHeight: 1 }}
      title={label}
    >
      {icon || "↗"}
    </span>
  );
}

export function normalizeHeaderQuickLinkItems(
  items?: HeaderQuickLinkItem[] | null,
  legacy?: HeaderQuickLinks | null,
): HeaderQuickLinkItem[] {
  if (!Array.isArray(items)) {
    const flags = normalizeHeaderQuickLinks(legacy);
    return HEADER_QUICK_LINKS.map((link) => ({
      id: link.id,
      label: link.label,
      href: link.href,
      enabled: Boolean(flags[link.id]),
      color: link.color,
    }));
  }
  const seen = new Set<string>();
  const normalized: HeaderQuickLinkItem[] = [];
  for (const raw of items.slice(0, 40)) {
    if (!raw || typeof raw !== "object") continue;
    const id = String(raw.id || "").trim().replace(/[^a-zA-Z0-9_-]+/g, "-").slice(0, 80);
    const href = safeHref(raw.href);
    const label = String(raw.label || "").trim().slice(0, 80);
    if (!id || !href || !label || seen.has(id)) continue;
    seen.add(id);
    normalized.push({
      id,
      label,
      href,
      enabled: Boolean(raw.enabled),
      icon: String(raw.icon || "").trim().slice(0, 2048) || undefined,
      color: String(raw.color || "").trim().slice(0, 40) || undefined,
    });
  }
  return normalized;
}

export function enabledHeaderQuickLinks(
  value?: HeaderQuickLinks | null,
  items?: HeaderQuickLinkItem[] | null,
) {
  if (Array.isArray(items)) {
    return normalizeHeaderQuickLinkItems(items, value)
      .filter((item) => item.enabled)
      .map((item) => {
        const builtIn = HEADER_QUICK_LINKS.find((link) => link.id === item.id);
        return {
          ...item,
          color: item.color || builtIn?.color || "currentColor",
          icon: item.icon ? customIcon(item.icon, item.label, item.color) : builtIn?.icon || customIcon("", item.label, item.color),
        };
      });
  }
  const flags = normalizeHeaderQuickLinks(value);
  return HEADER_QUICK_LINKS.filter((link) => flags[link.id]);
}
