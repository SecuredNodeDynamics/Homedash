import { promises as fs } from "fs";
import path from "path";

const IMAGE_EXT = new Set([".png", ".webp", ".svg", ".jpg", ".jpeg", ".gif", ".ico"]);

export function getIconsDir() {
  if (process.env.HOMEDASH_ICONS_DIR) return process.env.HOMEDASH_ICONS_DIR;
  return path.join(process.cwd(), "icons");
}

export async function ensureIconsDir() {
  const dir = getIconsDir();
  await fs.mkdir(dir, { recursive: true });
  return dir;
}

export function isSafeIconFilename(name: string) {
  const base = path.basename(name);
  if (!base || base !== name) return false;
  if (base.includes("..") || base.includes("/") || base.includes("\\")) return false;
  return /^[a-z0-9][a-z0-9._+-]*\.[a-z0-9]+$/i.test(base);
}

export function iconPublicUrl(filename: string) {
  return `/icons/${filename}`;
}

export function iconSlug(filename: string) {
  return path.basename(filename, path.extname(filename)).toLowerCase();
}

export type LocalIcon = {
  name: string;
  filename: string;
  url: string;
  slug: string;
};

let cache: { at: number; icons: LocalIcon[] } | null = null;
const CACHE_MS = 15_000;

export async function listLocalIcons(force = false): Promise<LocalIcon[]> {
  if (!force && cache && Date.now() - cache.at < CACHE_MS) return cache.icons;
  const dir = await ensureIconsDir();
  const entries = await fs.readdir(dir);
  const withStat = await Promise.all(
    entries.map(async (name) => {
      const ext = path.extname(name).toLowerCase();
      if (!IMAGE_EXT.has(ext) || !isSafeIconFilename(name)) return null;
      try {
        const st = await fs.stat(path.join(dir, name));
        return { name, mtime: st.mtimeMs };
      } catch {
        return { name, mtime: 0 };
      }
    }),
  );
  const icons = withStat
    .filter((row): row is { name: string; mtime: number } => Boolean(row))
    .map(({ name: filename, mtime }) => {
      const slug = iconSlug(filename);
      return {
        name: slug,
        filename,
        slug,
        url: iconPublicUrl(filename),
        mtime,
      };
    })
    // Newest uploads first, then A–Z — so custom icons aren't buried under 3k library files.
    .sort((a, b) => b.mtime - a.mtime || a.name.localeCompare(b.name))
    .map(({ mtime: _mtime, ...icon }) => icon);
  cache = { at: Date.now(), icons };
  return icons;
}

export function invalidateIconsCache() {
  cache = null;
}

function scoreIcon(icon: LocalIcon, q: string) {
  if (!q) return 1;
  const name = icon.name;
  const slug = icon.slug;
  const compact = slug.replace(/[-_.\s]+/g, "");
  const qCompact = q.replace(/[-_.\s]+/g, "");
  const tokens = slug.split(/[-_.\s]+/).filter(Boolean);

  if (name === q || slug === q) return 100;
  if (name.startsWith(q) || slug.startsWith(q)) return 90;
  if (compact === qCompact) return 85;
  if (compact.startsWith(qCompact)) return 75;
  if (tokens.some((t) => t === q || t.startsWith(q))) return 70;
  if (name.includes(q) || slug.includes(q)) return 55;
  if (compact.includes(qCompact)) return 45;
  if (tokens.some((t) => t.includes(q))) return 35;
  // light similar: shared prefix length
  let shared = 0;
  const a = compact;
  const b = qCompact;
  while (shared < a.length && shared < b.length && a[shared] === b[shared]) shared += 1;
  if (shared >= 3 && shared / Math.max(b.length, 1) >= 0.5) return 20 + shared;
  return 0;
}

export async function searchLocalIcons(qRaw: string, limit = 96) {
  const q = qRaw.trim().toLowerCase();
  const icons = await listLocalIcons();
  if (!q) {
    return { icons: icons.slice(0, limit), matched: icons.length, total: icons.length };
  }
  const scored = icons
    .map((icon) => ({ icon, score: scoreIcon(icon, q) }))
    .filter((row) => row.score > 0)
    .sort((a, b) => b.score - a.score || a.icon.name.localeCompare(b.icon.name));
  return {
    icons: scored.slice(0, limit).map((row) => row.icon),
    matched: scored.length,
    total: icons.length,
  };
}
