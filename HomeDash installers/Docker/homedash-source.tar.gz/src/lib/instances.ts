import type { DashboardTab, WidgetConfigField, WidgetInstance, WidgetManifest } from "./types";

/** Widget packages that can spawn one card per server/node. */
export const MULTI_INSTANCE_WIDGETS = new Set([
  "adguard-control",
  "ai-chat",
  "ai-trader",
  "amp",
  "bookmarks",
  "code-notes",
  "code-debugger",
  "crypto-tracker",
  "dispatcharr",
  "docker",
  "jellyfin-slider",
  "lidarr",
  "net-glances",
  "pihole",
  "plex-slider",
  "proxmox-nodes",
  "qbit",
  "radarr",
  "sonarr",
  "speedtest",
]);

export const MULTI_INSTANCE_FIELDS: Record<string, WidgetConfigField[]> = {
  "adguard-control": [
    { key: "baseUrl", label: "Private - IP", type: "url" },
    { key: "fallbackUrl", label: "Fallback Public URL", type: "url" },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url" },
    { key: "username", label: "Username", type: "text" },
    { key: "password", label: "Password", type: "password" },
  ],
  dispatcharr: [
    { key: "baseUrl", label: "Private - IP", type: "url" },
    { key: "fallbackUrl", label: "Fallback Public URL", type: "url" },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url" },
    { key: "username", label: "Username", type: "text", required: true },
    { key: "password", label: "Password", type: "password", required: true },
  ],
  docker: [
    {
      key: "provider",
      label: "Provider",
      type: "select",
      options: [
        { value: "engine", label: "Docker Engine" },
        { value: "portainer", label: "Portainer" },
      ],
    },
    { key: "baseUrl", label: "Private - IP", type: "url" },
    { key: "fallbackUrl", label: "Fallback Public URL", type: "url" },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url" },
    { key: "apiKey", label: "API Key", type: "password" },
    { key: "endpointId", label: "Portainer endpoint ID", type: "text", placeholder: "1" },
  ],
  "jellyfin-slider": [
    { key: "baseUrl", label: "Private - IP", type: "url" },
    { key: "fallbackUrl", label: "Fallback Public URL", type: "url" },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url" },
    { key: "apiKey", label: "API Key", type: "password", required: true },
    {
      key: "userId",
      label: "User ID or Username",
      type: "text",
      placeholder: "Jellyfin username or 32-character user ID",
      required: true,
    },
  ],
  lidarr: [
    { key: "baseUrl", label: "Private - IP", type: "url" },
    { key: "fallbackUrl", label: "Fallback Public URL", type: "url" },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url" },
    { key: "apiKey", label: "API Key", type: "password", required: true },
  ],
  "net-glances": [
    { key: "baseUrl", label: "Private - IP", type: "url" },
    { key: "fallbackUrl", label: "Fallback Public URL", type: "url" },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url" },
    { key: "netdataBaseUrl", label: "Netdata Private - IP", type: "url" },
    { key: "netdataFallbackUrl", label: "Netdata Fallback Public URL", type: "url" },
    { key: "interface", label: "Network interface", type: "text", placeholder: "vmbr0" },
    { key: "nodeName", label: "PVE ID", type: "text", placeholder: "PVE1", required: true },
    { key: "apiKey", label: "API Key / Token", type: "password" },
  ],
  pihole: [
    { key: "baseUrl", label: "Private - IP", type: "url" },
    { key: "fallbackUrl", label: "Fallback Public URL", type: "url" },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url" },
    { key: "apiKey", label: "API Key / Password", type: "password" },
  ],
  "plex-slider": [
    { key: "baseUrl", label: "Private - IP", type: "url" },
    { key: "fallbackUrl", label: "Fallback Public URL", type: "url" },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url" },
    { key: "apiKey", label: "Plex Token", type: "password", required: true },
  ],
  "proxmox-nodes": [
    { key: "pveUrl", label: "Private - IP", type: "url" },
    { key: "fallbackUrl", label: "Fallback Public URL", type: "url" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url" },
    { key: "tokenId", label: "Token ID", type: "text", required: true },
    { key: "tokenSecret", label: "Token Secret", type: "password", required: true },
    { key: "pveNode", label: "Node name", type: "text" },
    { key: "prxUrl", label: "ProxMenux Private - IP", type: "url" },
    { key: "prxFallbackUrl", label: "ProxMenux Fallback Public URL", type: "url" },
    { key: "prxToken", label: "ProxMenux API Key", type: "password" },
    { key: "glancesUrl", label: "Glances Private - IP", type: "url" },
    { key: "glancesFallbackUrl", label: "Glances Fallback Public URL", type: "url" },
    { key: "iface", label: "Primary interface", type: "text" },
    { key: "cpuSensor", label: "CPU sensor label", type: "text" },
    { key: "backupMount", label: "Backup mount path", type: "text" },
    { key: "color", label: "Accent color", type: "text" },
  ],
  qbit: [
    { key: "baseUrl", label: "Private - IP", type: "url" },
    { key: "fallbackUrl", label: "Fallback Public URL", type: "url" },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url" },
    { key: "username", label: "Username", type: "text", required: true },
    { key: "password", label: "Password", type: "password", required: true },
  ],
  radarr: [
    { key: "baseUrl", label: "Private - IP", type: "url" },
    { key: "fallbackUrl", label: "Fallback Public URL", type: "url" },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url" },
    { key: "apiKey", label: "API Key", type: "password", required: true },
  ],
  sonarr: [
    { key: "baseUrl", label: "Private - IP", type: "url" },
    { key: "fallbackUrl", label: "Fallback Public URL", type: "url" },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url" },
    { key: "apiKey", label: "API Key", type: "password", required: true },
  ],
  speedtest: [
    { key: "baseUrl", label: "Private - IP", type: "url" },
    { key: "fallbackUrl", label: "Fallback Public URL", type: "url" },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url" },
    { key: "apiKey", label: "API Key", type: "password", required: true },
    { key: "nodeName", label: "PVE ID", type: "text", placeholder: "LNV1", required: true },
    { key: "serverId", label: "Ookla server ID", type: "text", placeholder: "35180" },
    { key: "color", label: "Accent color", type: "text", placeholder: "#22c55e" },
  ],
  bookmarks: [
    {
      key: "groupId",
      label: "Bookmark group",
      type: "select",
      required: true,
      placeholder: "Select a group",
    },
  ],
};

export function fieldsForWidget(manifest: WidgetManifest): WidgetConfigField[] {
  if (manifest.configFields) return manifest.configFields;
  return MULTI_INSTANCE_FIELDS[manifest.id] || [];
}

export function isMultiInstanceWidget(widgetId: string) {
  return MULTI_INSTANCE_WIDGETS.has(widgetId);
}

export function formatInstanceId(widgetId: string, key: string) {
  if (!key || key === "default") return widgetId;
  return `${widgetId}--${key}`;
}

export function parseInstanceId(instanceId: string): { widgetId: string; key: string } {
  const idx = instanceId.indexOf("--");
  if (idx === -1) return { widgetId: instanceId, key: "default" };
  return {
    widgetId: instanceId.slice(0, idx),
    key: instanceId.slice(idx + 2) || "default",
  };
}

export function slugInstanceKey(label: string, existing: string[]) {
  const base =
    label
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "") || "server";
  let key = base;
  let n = 2;
  const used = new Set(existing);
  while (used.has(key) || used.has(formatInstanceId("", key))) {
    key = `${base}-${n++}`;
  }
  return key;
}

export function normalizeWidgetInstances(
  instances: WidgetInstance[] | undefined,
  enabledWidgets: string[],
): WidgetInstance[] {
  const list = Array.isArray(instances) ? [...instances] : [];
  const byWidget = new Map<string, WidgetInstance[]>();
  for (const inst of list) {
    if (!inst?.widgetId || !inst?.id) continue;
    const item: WidgetInstance = {
      id: inst.id,
      widgetId: inst.widgetId,
      key: inst.key || parseInstanceId(inst.id).key,
      label: inst.label?.trim() || inst.widgetId,
    };
    if (!byWidget.has(item.widgetId)) byWidget.set(item.widgetId, []);
    byWidget.get(item.widgetId)!.push(item);
  }

  // Ensure every enabled widget has at least one instance card id.
  for (const widgetId of enabledWidgets) {
    if (!byWidget.has(widgetId) || !byWidget.get(widgetId)!.length) {
      byWidget.set(widgetId, [
        {
          id: widgetId,
          widgetId,
          key: "default",
          label: widgetId,
        },
      ]);
    }
  }

  return Array.from(byWidget.values()).flat();
}

export function instancesForWidget(instances: WidgetInstance[], widgetId: string) {
  return instances.filter((i) => i.widgetId === widgetId);
}

export type DashboardCard = {
  instanceId: string;
  widgetId: string;
  label: string;
  manifest: WidgetManifest;
};

/** Expand tab widget entries (package or instance ids) into concrete cards. */
export function resolveTabCards(
  tab: DashboardTab,
  enabledWidgets: string[],
  instances: WidgetInstance[],
  getManifest: (widgetId: string) => WidgetManifest | undefined,
): DashboardCard[] {
  const enabled = new Set(enabledWidgets);
  const cards: DashboardCard[] = [];
  const seen = new Set<string>();

  for (const entry of tab.widgetIds) {
    const parsed = parseInstanceId(entry);
    const widgetId = parsed.widgetId;
    if (!enabled.has(widgetId)) continue;
    const manifest = getManifest(widgetId);
    if (!manifest) continue;

    const widgetInstances = instancesForWidget(instances, widgetId);

    // If the tab still references the bare package id, expand to all instances.
    if (entry === widgetId && isMultiInstanceWidget(widgetId) && widgetInstances.length) {
      for (const inst of widgetInstances) {
        if (seen.has(inst.id)) continue;
        seen.add(inst.id);
        cards.push({
          instanceId: inst.id,
          widgetId,
          label: inst.label || manifest.name,
          manifest,
        });
      }
      continue;
    }

    const inst =
      widgetInstances.find((i) => i.id === entry) ||
      widgetInstances.find((i) => i.key === parsed.key) ||
      ({
        id: entry,
        widgetId,
        key: parsed.key,
        label: manifest.name,
      } satisfies WidgetInstance);

    if (seen.has(inst.id)) continue;
    seen.add(inst.id);
    cards.push({
      instanceId: inst.id,
      widgetId,
      label: inst.label || manifest.name,
      manifest,
    });
  }

  return cards;
}

export function defaultInstancesFromHomepage(): WidgetInstance[] {
  return [
    { id: "adguard-control--agh1", widgetId: "adguard-control", key: "agh1", label: "AdGuard Home 1" },
    { id: "adguard-control--agh2", widgetId: "adguard-control", key: "agh2", label: "AdGuard Home 2" },
    { id: "dispatcharr--primary", widgetId: "dispatcharr", key: "primary", label: "Dispatcharr" },
    { id: "jellyfin-slider--jmg", widgetId: "jellyfin-slider", key: "jmg", label: "Jellyfin JMG" },
    { id: "jellyfin-slider--noe", widgetId: "jellyfin-slider", key: "noe", label: "Jellyfin Noe" },
    { id: "lidarr--primary", widgetId: "lidarr", key: "primary", label: "Lidarr" },
    { id: "pihole--primary", widgetId: "pihole", key: "primary", label: "Pi-hole" },
    { id: "plex-slider--primary", widgetId: "plex-slider", key: "primary", label: "Plex" },
    { id: "proxmox-nodes--lnv1", widgetId: "proxmox-nodes", key: "lnv1", label: "LNV1" },
    { id: "proxmox-nodes--lnv2", widgetId: "proxmox-nodes", key: "lnv2", label: "LNV2" },
    { id: "proxmox-nodes--hp", widgetId: "proxmox-nodes", key: "hp", label: "HP" },
    { id: "qbit--qbit1", widgetId: "qbit", key: "qbit1", label: "qBit 1" },
    { id: "qbit--qbit2", widgetId: "qbit", key: "qbit2", label: "qBit 2" },
    { id: "radarr--1", widgetId: "radarr", key: "1", label: "Radarr 1" },
    { id: "radarr--2", widgetId: "radarr", key: "2", label: "Radarr 2" },
    { id: "sonarr--1", widgetId: "sonarr", key: "1", label: "Sonarr 1" },
    { id: "sonarr--2", widgetId: "sonarr", key: "2", label: "Sonarr 2" },
  ];
}
