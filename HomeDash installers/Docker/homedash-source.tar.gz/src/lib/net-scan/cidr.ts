export type ParsedCidr = {
  /** Normalized "a.b.c.d/nn" form. */
  cidr: string;
  base: number; // network address as a uint32
  prefix: number;
  size: number; // total addresses in the block, including network/broadcast
};

const OCTET = "(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)";
const IPV4_RE = new RegExp(`^${OCTET}\\.${OCTET}\\.${OCTET}\\.${OCTET}$`);

// Scanning is a per-address TCP probe sweep (see scan.ts), so anything
// bigger than a /22 (1024 addresses) would make a single scan take far too
// long and hammer the network. /24 or smaller is the realistic case for a
// single LAN anyway.
export const MIN_PREFIX_LENGTH = 22;
export const MAX_PREFIX_LENGTH = 30;

export function ipToUint32(ip: string): number | undefined {
  const match = IPV4_RE.exec(ip.trim());
  if (!match) return undefined;
  const [a, b, c, d] = [match[1], match[2], match[3], match[4]].map(Number);
  return ((a << 24) | (b << 16) | (c << 8) | d) >>> 0;
}

export function uint32ToIp(value: number): string {
  return [24, 16, 8, 0].map((shift) => (value >>> shift) & 0xff).join(".");
}

/**
 * Parses "a.b.c.d/nn", validates the prefix length is in a sane scannable
 * range, and normalizes the address down to its network base (so
 * "10.128.1.55/24" is treated the same as "10.128.1.0/24").
 * Returns undefined for anything malformed rather than throwing, so callers
 * can produce their own error message with the right amount of context.
 */
export function parseCidr(input: string): ParsedCidr | undefined {
  const trimmed = input.trim();
  const slash = trimmed.indexOf("/");
  if (slash === -1) return undefined;

  const ipPart = trimmed.slice(0, slash);
  const prefixPart = trimmed.slice(slash + 1);
  if (!/^\d{1,2}$/.test(prefixPart)) return undefined;
  const prefix = Number(prefixPart);
  if (prefix < 0 || prefix > 32) return undefined;

  const ip = ipToUint32(ipPart);
  if (ip === undefined) return undefined;

  const size = prefix === 32 ? 1 : 2 ** (32 - prefix);
  const mask = prefix === 0 ? 0 : (0xffffffff << (32 - prefix)) >>> 0;
  const base = (ip & mask) >>> 0;

  return { cidr: `${uint32ToIp(base)}/${prefix}`, base, prefix, size };
}

/** Validates a user-supplied subnet string for saving, with a human-readable rejection reason. */
export function validateSubnetForSaving(input: string): { ok: true; cidr: string } | { ok: false; reason: string } {
  const parsed = parseCidr(input);
  if (!parsed) {
    return { ok: false, reason: "Subnet must be in CIDR form, e.g. 10.0.0.0/24." };
  }
  if (parsed.prefix < MIN_PREFIX_LENGTH) {
    return {
      ok: false,
      reason: `Subnet must be a /${MIN_PREFIX_LENGTH} or smaller (fewer addresses) so a scan can finish in reasonable time.`,
    };
  }
  if (parsed.prefix > MAX_PREFIX_LENGTH) {
    return { ok: false, reason: `Subnet must be at least a /${MAX_PREFIX_LENGTH}.` };
  }
  return { ok: true, cidr: parsed.cidr };
}

/** All usable host addresses in the block (network and broadcast addresses excluded for /30 and larger blocks). */
export function hostAddresses(parsed: ParsedCidr): string[] {
  if (parsed.prefix >= 31) {
    // /31 and /32 have no distinct network/broadcast address to exclude.
    return Array.from({ length: parsed.size }, (_, i) => uint32ToIp(parsed.base + i));
  }
  const addresses: string[] = [];
  for (let i = 1; i < parsed.size - 1; i += 1) {
    addresses.push(uint32ToIp(parsed.base + i));
  }
  return addresses;
}

// Docker assigns its default bridge networks out of 172.17.0.0/16 through
// 172.31.0.0/16 (RFC1918's 172.16.0.0/12 space) unless the host's daemon
// config overrides it. A home/office LAN is far more commonly
// 192.168.0.0/16 or elsewhere in 10.0.0.0/8, so landing here on
// auto-detection (never on a subnet the person typed in themselves) is a
// reasonable hint — not a certainty — that we're only seeing the
// container's own virtual network rather than the real LAN.
export function looksLikeDockerBridgeRange(ip: string): boolean {
  const value = ipToUint32(ip);
  if (value === undefined) return false;
  return value >= (ipToUint32("172.16.0.0") as number) && value <= (ipToUint32("172.31.255.255") as number);
}
