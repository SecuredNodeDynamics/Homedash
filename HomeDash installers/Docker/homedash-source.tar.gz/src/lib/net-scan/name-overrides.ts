import { assertValidInstanceId, readJsonFile, writeJsonFile } from "./store";

export const MAX_NAME_LENGTH = 60;

type NamesByInstance = Record<string, Record<string, string>>;

const FILE_NAME = "name-overrides.json";

async function readAll(): Promise<NamesByInstance> {
  return readJsonFile<NamesByInstance>(FILE_NAME, {});
}

/**
 * The identity a saved name is keyed against: MAC when known, otherwise IP.
 * Mirrors the client-side hostKeyOf() in Widget.tsx so a saved edit always
 * matches back up with the same device on the next scan.
 */
export function hostKey(host: { mac?: string; ip?: string }): string | null {
  return host.mac || host.ip || null;
}

export async function getNameOverrides(instanceId: string): Promise<Record<string, string>> {
  assertValidInstanceId(instanceId);
  const all = await readAll();
  return all[instanceId] || {};
}

export async function setNameOverride(
  instanceId: string,
  key: string,
  name: string,
): Promise<Record<string, string>> {
  assertValidInstanceId(instanceId);
  const all = await readAll();
  const forInstance = { ...(all[instanceId] || {}) };
  forInstance[key] = name.slice(0, MAX_NAME_LENGTH);
  all[instanceId] = forInstance;
  await writeJsonFile(FILE_NAME, all);
  return forInstance;
}

export async function clearNameOverride(instanceId: string, key: string): Promise<Record<string, string>> {
  assertValidInstanceId(instanceId);
  const all = await readAll();
  const forInstance = { ...(all[instanceId] || {}) };
  delete forInstance[key];
  all[instanceId] = forInstance;
  await writeJsonFile(FILE_NAME, all);
  return forInstance;
}

export async function exportNameOverrides(instanceId: string): Promise<Record<string, string>> {
  return getNameOverrides(instanceId);
}

export async function importNameOverrides(
  instanceId: string,
  overrides: Record<string, unknown>,
  mode: "merge" | "replace",
): Promise<{ imported: number; total: number }> {
  assertValidInstanceId(instanceId);
  const clean: Record<string, string> = {};
  for (const [key, value] of Object.entries(overrides)) {
    if (typeof key === "string" && key && typeof value === "string" && value.trim()) {
      clean[key] = value.trim().slice(0, MAX_NAME_LENGTH);
    }
  }

  const all = await readAll();
  const existing = mode === "replace" ? {} : all[instanceId] || {};
  const merged = { ...existing, ...clean };
  all[instanceId] = merged;
  await writeJsonFile(FILE_NAME, all);
  return { imported: Object.keys(clean).length, total: Object.keys(merged).length };
}
