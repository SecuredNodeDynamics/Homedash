import { readJsonFile, writeJsonFile } from "./store";

export type HostOverride = {
  ip?: string;
  name?: string;
  role?: string;
  mac?: string;
  icon?: string;
  localUrl?: string;
  tunnelUrl?: string;
};

const FILE_NAME = "overrides.json";

export async function readOverrides(): Promise<HostOverride[]> {
  return readJsonFile<HostOverride[]>(FILE_NAME, []);
}

function matches(entry: HostOverride, target: { ip?: string; name?: string }): boolean {
  if (target.ip && entry.ip && entry.ip === target.ip) return true;
  if (!target.ip && target.name && entry.name === target.name) return true;
  return false;
}

/** Adds a new override, or updates an existing one matched by ip (preferred) or else by name. */
export async function upsertOverride(entry: HostOverride): Promise<HostOverride[]> {
  const all = await readOverrides();
  const idx = all.findIndex((existing) => matches(existing, entry));
  if (idx === -1) {
    all.push(entry);
  } else {
    all[idx] = { ...all[idx], ...entry };
  }
  await writeJsonFile(FILE_NAME, all);
  return all;
}

export async function deleteOverride(target: { ip?: string; name?: string }): Promise<HostOverride[]> {
  const all = await readOverrides();
  const next = all.filter((entry) => !matches(entry, target));
  await writeJsonFile(FILE_NAME, next);
  return next;
}
