import { promises as fs } from "fs";
import net from "net";
import os from "os";
import dns from "dns";
import { hostAddresses, looksLikeDockerBridgeRange, parseCidr, uint32ToIp } from "./cidr";

export type SubnetSource = "override" | "saved-override" | "env" | "detected" | "detected-docker-range" | "fallback";

export type ScanHost = {
  ip: string;
  mac?: string;
  name: string;
};

export type ScanResult = {
  hosts: ScanHost[];
  subnet: string;
  subnetSource: SubnetSource;
  subnetWarning?: string;
  scannedAt: string;
};

// --- Why this scans the way it does -----------------------------------
//
// This container is intentionally locked down (see docker-compose.yml:
// `cap_drop: ALL`, `read_only: true`, no `network_mode: host`). That rules
// out the two "classic" LAN-discovery techniques:
//   - ARP requests need to be on the same L2 broadcast domain, which a
//     container on Docker's default bridge network structurally isn't.
//   - Raw ICMP echo (ping) needs CAP_NET_RAW, which is dropped.
// Neither of those can be fixed from application code, and this widget is
// built to work without asking anyone to edit docker-compose.yml or grant
// extra capabilities.
//
// So discovery here is a TCP-connect sweep: for every candidate address in
// the subnet, try opening a plain TCP connection to a handful of commonly
// open ports. A successful connect, or even an immediate "connection
// refused", both prove a live host answered at that IP — only a timeout
// means nobody's there (or it's silently firewalled). This uses ordinary
// unprivileged sockets, so it works the same whether the container is on a
// bridge network (reaching the LAN through the host's routing/NAT) or on
// host networking / a macvlan.
//
// Trade-offs worth knowing about:
//   - A host with every one of these ports closed AND ping/ICMP-only
//     reachability won't be seen. Most consumer/IoT devices have at least
//     one of these open (a web UI, SMB, RDP, SSH); a minimal firewalled
//     server might not.
//   - MAC addresses can only ever be resolved for devices on the same L2
//     segment as the container. On a bridge network that's structurally
//     nothing; on host networking/macvlan, this reads the kernel's own
//     neighbor table (a plain file read, no capability needed) and fills
//     in whatever's already there. There's no way to get a MAC address for
//     a device the container reaches purely through NAT — that's an
//     Ethernet-layer fact, not something any scan technique can work
//     around from inside a routed connection.

const PROBE_PORTS = [80, 443, 22, 8080, 445, 139, 3389, 8006, 32400, 5000, 62078, 9100];
const PROBE_TIMEOUT_MS = 450;
const MAX_CONCURRENT_PROBES = 64;
const REVERSE_DNS_TIMEOUT_MS = 800;
const CACHE_TTL_MS = 45_000;
const FALLBACK_SUBNET = "192.168.1.0/24";

const cache = new Map<string, { result: ScanResult; expiresAt: number }>();

function probePort(ip: string, port: number, timeoutMs: number): Promise<boolean> {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let settled = false;
    const finish = (alive: boolean) => {
      if (settled) return;
      settled = true;
      socket.destroy();
      resolve(alive);
    };
    socket.setTimeout(timeoutMs);
    socket.once("connect", () => finish(true));
    socket.once("timeout", () => finish(false));
    socket.once("error", (err: NodeJS.ErrnoException) => {
      // ECONNREFUSED means a host at this IP actively rejected the
      // connection — that's still proof it's alive, just not listening on
      // this particular port. Anything else (EHOSTUNREACH, ENETUNREACH,
      // ETIMEDOUT) means we got no answer at all.
      finish(err.code === "ECONNREFUSED");
    });
    socket.connect(port, ip);
  });
}

async function isHostAlive(ip: string): Promise<boolean> {
  // Ports are raced rather than tried in sequence, so one alive host is
  // detected as soon as any port answers instead of waiting through the
  // whole list.
  return new Promise((resolve) => {
    let remaining = PROBE_PORTS.length;
    let resolved = false;
    for (const port of PROBE_PORTS) {
      probePort(ip, port, PROBE_TIMEOUT_MS).then((alive) => {
        if (resolved) return;
        if (alive) {
          resolved = true;
          resolve(true);
          return;
        }
        remaining -= 1;
        if (remaining === 0) {
          resolved = true;
          resolve(false);
        }
      });
    }
  });
}

async function reverseDns(ip: string): Promise<string | undefined> {
  try {
    const names = await Promise.race<string[]>([
      dns.promises.reverse(ip),
      new Promise<string[]>((_, reject) =>
        setTimeout(() => reject(new Error("reverse DNS timeout")), REVERSE_DNS_TIMEOUT_MS),
      ),
    ]);
    return names[0];
  } catch {
    return undefined;
  }
}

// Best-effort MAC lookup from the kernel's own neighbor table. Reading
// /proc/net/arp is a plain file read (no capability needed) and only ever
// has entries for addresses the container's network stack has itself
// ARPed for — which only happens when it shares an L2 segment with that
// address (host networking / macvlan). On a bridge network this will
// simply have nothing for LAN addresses and every lookup below returns
// undefined, which is the correct, honest answer.
let arpTableCache: { table: Map<string, string>; expiresAt: number } | undefined;

async function readArpTable(): Promise<Map<string, string>> {
  if (arpTableCache && arpTableCache.expiresAt > Date.now()) return arpTableCache.table;
  const table = new Map<string, string>();
  try {
    const raw = await fs.readFile("/proc/net/arp", "utf8");
    const lines = raw.split("\n").slice(1);
    for (const line of lines) {
      const cols = line.trim().split(/\s+/);
      if (cols.length < 4) continue;
      const [ip, , , mac] = cols;
      if (mac && mac !== "00:00:00:00:00:00") table.set(ip, mac);
    }
  } catch {
    // Not on Linux, or /proc isn't mounted the way we expect — fine, MAC
    // addresses just won't be available from this path.
  }
  arpTableCache = { table, expiresAt: Date.now() + CACHE_TTL_MS };
  return table;
}

async function mapWithConcurrency<T, R>(items: T[], limit: number, fn: (item: T) => Promise<R>): Promise<R[]> {
  const results: R[] = new Array(items.length);
  let next = 0;
  async function worker() {
    while (next < items.length) {
      const current = next;
      next += 1;
      results[current] = await fn(items[current]);
    }
  }
  const workers = Array.from({ length: Math.min(limit, items.length) }, () => worker());
  await Promise.all(workers);
  return results;
}

function firstUsableIPv4Interface(): { address: string; netmaskBits: number } | undefined {
  const interfaces = os.networkInterfaces();
  for (const entries of Object.values(interfaces)) {
    for (const entry of entries || []) {
      if (entry.family === "IPv4" && !entry.internal) {
        const netmaskBits = entry.cidr ? Number(entry.cidr.split("/")[1]) : 24;
        return { address: entry.address, netmaskBits: Number.isFinite(netmaskBits) ? netmaskBits : 24 };
      }
    }
  }
  return undefined;
}

function resolveSubnet(requested?: string): { cidr: string; source: SubnetSource; warning?: string } {
  if (requested) {
    const parsed = parseCidr(requested);
    if (parsed) return { cidr: parsed.cidr, source: "override" };
  }

  const envSubnet = process.env.NET_TOPOLOGY_SUBNET;
  if (envSubnet) {
    const parsed = parseCidr(envSubnet);
    if (parsed) return { cidr: parsed.cidr, source: "env" };
  }

  const iface = firstUsableIPv4Interface();
  if (iface) {
    const prefix = Math.min(Math.max(iface.netmaskBits, 22), 24) || 24;
    const parsed = parseCidr(`${iface.address}/${prefix}`);
    if (parsed) {
      if (looksLikeDockerBridgeRange(iface.address)) {
        return {
          cidr: parsed.cidr,
          source: "detected-docker-range",
          warning:
            "This looks like Docker's internal bridge network, not your real LAN. Set your actual subnet using the gear icon.",
        };
      }
      return { cidr: parsed.cidr, source: "detected" };
    }
  }

  const fallback = parseCidr(FALLBACK_SUBNET);
  return {
    cidr: fallback ? fallback.cidr : FALLBACK_SUBNET,
    source: "fallback",
    warning: "Couldn't detect a network interface to scan, so this is just a guess. Set your subnet using the gear icon.",
  };
}

export async function getScan(opts: {
  subnet?: string;
  subnetSource?: "override" | "saved-override";
  force?: boolean;
}): Promise<ScanResult> {
  const resolved: { cidr: string; source: SubnetSource; warning?: string } = opts.subnet
    ? { cidr: parseCidr(opts.subnet)?.cidr ?? opts.subnet, source: opts.subnetSource ?? "override", warning: undefined }
    : resolveSubnet();

  const cacheKey = resolved.cidr;
  const cached = cache.get(cacheKey);
  if (!opts.force && cached && cached.expiresAt > Date.now()) {
    // The caller's subnetSource (e.g. "saved-override" vs a plain
    // "override" query param) reflects *why* we're scanning this subnet
    // right now, so it's applied fresh even when the scan itself is
    // served from cache.
    return { ...cached.result, subnetSource: resolved.source as SubnetSource, subnetWarning: resolved.warning };
  }

  const parsed = parseCidr(resolved.cidr);
  const addresses = parsed ? hostAddresses(parsed) : [];

  const aliveFlags = await mapWithConcurrency(addresses, MAX_CONCURRENT_PROBES, async (ip) => ({
    ip,
    alive: await isHostAlive(ip),
  }));
  const alive = aliveFlags.filter((entry) => entry.alive).map((entry) => entry.ip);

  const arpTable = await readArpTable();
  const hosts: ScanHost[] = await mapWithConcurrency(alive, MAX_CONCURRENT_PROBES, async (ip) => {
    const [resolvedName, mac] = await Promise.all([reverseDns(ip), Promise.resolve(arpTable.get(ip))]);
    // Reverse DNS is best-effort and fails constantly on a LAN (most
    // consumer/IoT devices never register a PTR record). Falling back to
    // the IP itself keeps `name` a plain string end-to-end instead of
    // pushing `undefined` up into ResponseHost.name (which is always a
    // string) and it's a more useful default than an empty name anyway.
    return { ip, mac, name: resolvedName ?? ip };
  });

  hosts.sort((a, b) => a.ip.localeCompare(b.ip, undefined, { numeric: true }));

  const result: ScanResult = {
    hosts,
    subnet: resolved.cidr,
    subnetSource: resolved.source as SubnetSource,
    subnetWarning: resolved.warning,
    scannedAt: new Date().toISOString(),
  };

  cache.set(cacheKey, { result, expiresAt: Date.now() + CACHE_TTL_MS });
  return result;
}

// Exported for the /subnet route's own troubleshooting needs, e.g. a
// future "detect now" button — not currently called by the shipped UI.
export function uint32ToIpAddress(value: number): string {
  return uint32ToIp(value);
}
