import { promises as fs } from "fs";
import os from "os";
import path from "path";

/**
 * Resolves (and lazily creates) the directory net-topology's small JSON
 * stores live in. Prefers HOMEDASH_DATA_DIR (a volume the host is expected
 * to persist across container recreation); if that directory can't be
 * created or written to — e.g. it isn't mounted in this environment — falls
 * back to a directory under the OS temp dir so the widget still works for
 * the running session instead of hard-failing every request. The temp-dir
 * fallback does NOT persist across container recreation; mount a writable
 * HOMEDASH_DATA_DIR to keep saved names/overrides permanently.
 */
let resolvedDir: string | null = null;

function primaryDataDir(): string {
  const base = process.env.HOMEDASH_DATA_DIR || path.join(process.cwd(), "data");
  return path.join(base, "widgets", "net-topology");
}

function fallbackDataDir(): string {
  return path.join(os.tmpdir(), "homedash-net-topology");
}

export async function dataDir(): Promise<string> {
  if (resolvedDir) return resolvedDir;

  const primary = primaryDataDir();
  try {
    await fs.mkdir(primary, { recursive: true });
    await fs.access(primary, fs.constants.W_OK);
    resolvedDir = primary;
    return resolvedDir;
  } catch {
    // Fall through to the temp-dir fallback below.
  }

  const fallback = fallbackDataDir();
  await fs.mkdir(fallback, { recursive: true });
  resolvedDir = fallback;
  return resolvedDir;
}

/** Only safe, simple instance ids are accepted — this is what stands between a caller-supplied id and a filesystem path. */
const INSTANCE_ID_RE = /^[a-zA-Z0-9_-]+$/;

export function assertValidInstanceId(instanceId: string): void {
  if (!instanceId || !INSTANCE_ID_RE.test(instanceId)) {
    throw new Error("Invalid instance id");
  }
}

/** Writes JSON atomically (write to a temp file, then rename) so a crash or concurrent read never observes a half-written store. */
export async function writeJsonAtomic(file: string, data: unknown): Promise<void> {
  const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(data, null, 2), "utf8");
  await fs.rename(tmp, file);
}

export async function readJsonOrDefault<T>(file: string, fallback: T): Promise<T> {
  try {
    const raw = await fs.readFile(file, "utf8");
    return JSON.parse(raw) as T;
  } catch (err) {
    if ((err as NodeJS.ErrnoException)?.code === "ENOENT") return fallback;
    throw err;
  }
}
