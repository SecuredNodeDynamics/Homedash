import { assertValidInstanceId, readJsonFile, writeJsonFile } from "./store";
import { validateSubnetForSaving } from "./cidr";

const FILE_NAME = "subnet-overrides.json";

type SubnetOverrides = Record<string, string>;

async function readAll(): Promise<SubnetOverrides> {
  return readJsonFile<SubnetOverrides>(FILE_NAME, {});
}

export async function getSubnetOverride(instanceId: string): Promise<string | undefined> {
  assertValidInstanceId(instanceId);
  const all = await readAll();
  return all[instanceId];
}

export async function setSubnetOverride(instanceId: string, subnet: string): Promise<string> {
  assertValidInstanceId(instanceId);
  const result = validateSubnetForSaving(subnet);
  if (!result.ok) {
    throw new Error(result.reason);
  }
  const all = await readAll();
  all[instanceId] = result.cidr;
  await writeJsonFile(FILE_NAME, all);
  return result.cidr;
}

export async function clearSubnetOverride(instanceId: string): Promise<void> {
  assertValidInstanceId(instanceId);
  const all = await readAll();
  if (instanceId in all) {
    delete all[instanceId];
    await writeJsonFile(FILE_NAME, all);
  }
}
