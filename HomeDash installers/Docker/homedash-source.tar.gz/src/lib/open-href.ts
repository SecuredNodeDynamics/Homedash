/**
 * Resolve widget "Open" links based on how the browser reached Homedash.
 * On LAN / private hosts → primary (usually LAN IP).
 * On public / Cloudflare hosts → open fallback (tunnel URL) when set.
 */

export function isLocalHomedashHost(hostname?: string | null): boolean {
  const host = String(hostname ?? "")
    .trim()
    .toLowerCase()
    .replace(/^\[|\]$/g, "");
  if (!host || host === "localhost" || host === "127.0.0.1" || host === "::1") return true;
  if (host.endsWith(".local") || host.endsWith(".lan") || host.endsWith(".home")) return true;

  const v4 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(host);
  if (v4) {
    const a = Number(v4[1]);
    const b = Number(v4[2]);
    if (a === 10 || a === 127) return true;
    if (a === 192 && b === 168) return true;
    if (a === 172 && b >= 16 && b <= 31) return true;
    return false;
  }

  if (host.startsWith("fd") || host.startsWith("fe80:")) return true;
  return false;
}

export function resolveOpenHref(
  primary?: string | null,
  fallback?: string | null,
  hostname?: string | null,
): string {
  const p = String(primary || "").trim();
  const f = String(fallback || "").trim();
  const host =
    hostname ??
    (typeof window !== "undefined" ? window.location.hostname : "");
  if (!isLocalHomedashHost(host) && f) return f;
  return p || f;
}

/** Primary Open URL + optional Cloudflare/open fallback from widget config. */
export function openUrlsFromConfig(cfg: {
  baseUrl?: string | null;
  publicUrl?: string | null;
  fallbackUrl?: string | null;
  openFallbackUrl?: string | null;
  /** Alternate primary keys used by some widgets (e.g. Proxmox). */
  primaryUrl?: string | null;
}): { href: string; openFallbackUrl: string } {
  const privateHref = trimUrl(cfg.publicUrl || cfg.primaryUrl || cfg.baseUrl);
  const publicHref = trimUrl(cfg.openFallbackUrl || cfg.fallbackUrl);
  // Remote-only services (blank Private - IP): the "public" URL becomes the
  // primary href, and there's no separate fallback left to offer.
  const href = privateHref || publicHref;
  const openFallbackUrl = privateHref ? publicHref : "";
  return { href, openFallbackUrl };
}

/** Trim a possibly-null URL string; never returns null/undefined. */
export function trimUrl(url?: string | null): string {
  return String(url ?? "").trim();
}

/** True when a service URL points directly at a local/private network host. */
export function isPrivateConnectionUrl(value?: string | null): boolean {
  const raw = trimUrl(value);
  if (!raw) return false;
  try {
    const host = new URL(raw).hostname.toLowerCase().replace(/^\[|\]$/g, "");
    if (host === "localhost" || host === "127.0.0.1" || host === "::1") return true;
    if (host.endsWith(".local") || host.endsWith(".lan") || host.endsWith(".home")) return true;
    const v4 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(host);
    if (v4) {
      const a = Number(v4[1]);
      const b = Number(v4[2]);
      return a === 10 || a === 127 || (a === 192 && b === 168) || (a === 172 && b >= 16 && b <= 31);
    }
    return host.startsWith("fd") || host.startsWith("fe80:");
  } catch {
    return false;
  }
}

/**
 * Ordered, de-duped list of usable connection URLs from a widget config.
 * Defaults to the common `baseUrl` (Private - IP) + `fallbackUrl` (Fallback
 * Public URL) keys, but accepts alternate key names (e.g. Proxmox `pveUrl`).
 * Private network URLs are promoted ahead of public URLs so legacy configs
 * with the two fields reversed still use the LAN connection first.
 */
export function connectionCandidates(
  cfg: Record<string, unknown> | null | undefined,
  primaryKey = "baseUrl",
  fallbackKey = "fallbackUrl",
): string[] {
  if (!cfg) return [];
  const primary = trimUrl(cfg[primaryKey] as string | undefined | null);
  const fallback = trimUrl(cfg[fallbackKey] as string | undefined | null);
  return Array.from(new Set([primary, fallback].filter(Boolean))).sort(
    (a, b) => Number(isPrivateConnectionUrl(b)) - Number(isPrivateConnectionUrl(a)),
  );
}

/** True when a config has a Private - IP and/or Fallback Public URL set. */
export function hasConnectionUrl(
  cfg: Record<string, unknown> | null | undefined,
  primaryKey = "baseUrl",
  fallbackKey = "fallbackUrl",
): boolean {
  return connectionCandidates(cfg, primaryKey, fallbackKey).length > 0;
}

/**
 * First usable connection URL (Private - IP if set, else Fallback Public
 * URL). Useful for keeping legacy code that assumes a single `baseUrl`
 * working when only the remote/public URL is configured.
 */
export function primaryConnectionUrl(
  cfg: Record<string, unknown> | null | undefined,
  primaryKey = "baseUrl",
  fallbackKey = "fallbackUrl",
): string {
  return connectionCandidates(cfg, primaryKey, fallbackKey)[0] || "";
}
