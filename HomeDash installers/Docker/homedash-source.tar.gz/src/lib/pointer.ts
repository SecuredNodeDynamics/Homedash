/**
 * Primary input capability: touch-first vs mouse/trackpad-first.
 * Matches devices where hover isn't available or the primary pointer is coarse
 * (phones, tablets, many touchscreen laptops).
 */
export const TOUCH_PRIMARY_MQ = "(hover: none), (pointer: coarse)";

export function isTouchPrimary(): boolean {
  if (typeof window === "undefined" || typeof window.matchMedia !== "function") {
    return false;
  }
  return window.matchMedia(TOUCH_PRIMARY_MQ).matches;
}

/** Subscribe to touch-primary changes (e.g. tablet dock/undock). */
export function subscribeTouchPrimary(onChange: (touchPrimary: boolean) => void): () => void {
  if (typeof window === "undefined" || typeof window.matchMedia !== "function") {
    onChange(false);
    return () => undefined;
  }
  const mq = window.matchMedia(TOUCH_PRIMARY_MQ);
  const sync = () => onChange(mq.matches);
  sync();
  mq.addEventListener("change", sync);
  return () => mq.removeEventListener("change", sync);
}
