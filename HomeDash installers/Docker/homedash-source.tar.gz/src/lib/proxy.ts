import { readWidgetConfig } from "./config";

export async function getWidgetConnection(id: string) {
  const cfg = await readWidgetConfig(id);
  return cfg;
}

export function joinUrl(base: string, path: string) {
  const b = base.replace(/\/$/, "");
  const p = path.startsWith("/") ? path : `/${path}`;
  return `${b}${p}`;
}
