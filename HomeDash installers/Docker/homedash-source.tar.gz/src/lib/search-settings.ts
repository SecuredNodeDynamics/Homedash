import type { SearchSettings } from "./types";

export const DEFAULT_SEARCH_SETTINGS: SearchSettings = {
  popupBackground: "#111821",
  popupOpacity: 0.98,
  popupBlur: 18,
  backdropBackground: "#010408",
  backdropOpacity: 0.76,
  backdropBlur: 14,
  borderColor: "#8a6717",
  borderWidth: 1,
  radius: 22,
  width: 700,
  shadow: "strong",
  resultDensity: "comfortable",
  maxResults: 8,
  showResultHeader: true,
  showResultCount: true,
  showIcons: true,
  showDescriptions: true,
  showResultTypes: true,
  showWebSearch: true,
  showKeyboardHints: true,
};

function clamp(value: unknown, min: number, max: number, fallback: number) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.min(max, Math.max(min, number)) : fallback;
}

export function normalizeSearchSettings(value: Partial<SearchSettings> | null | undefined): SearchSettings {
  const source = value || {};
  return {
    ...DEFAULT_SEARCH_SETTINGS,
    ...source,
    popupOpacity: clamp(source.popupOpacity, 0, 1, DEFAULT_SEARCH_SETTINGS.popupOpacity),
    popupBlur: clamp(source.popupBlur, 0, 40, DEFAULT_SEARCH_SETTINGS.popupBlur),
    backdropOpacity: clamp(source.backdropOpacity, 0, 1, DEFAULT_SEARCH_SETTINGS.backdropOpacity),
    backdropBlur: clamp(source.backdropBlur, 0, 40, DEFAULT_SEARCH_SETTINGS.backdropBlur),
    borderWidth: clamp(source.borderWidth, 0, 4, DEFAULT_SEARCH_SETTINGS.borderWidth),
    radius: clamp(source.radius, 0, 40, DEFAULT_SEARCH_SETTINGS.radius),
    width: clamp(source.width, 440, 920, DEFAULT_SEARCH_SETTINGS.width),
    maxResults: Math.round(clamp(source.maxResults, 3, 15, DEFAULT_SEARCH_SETTINGS.maxResults)),
    shadow: source.shadow === "none" || source.shadow === "soft" ? source.shadow : "strong",
    resultDensity:
      source.resultDensity === "compact" || source.resultDensity === "roomy"
        ? source.resultDensity
        : "comfortable",
  };
}

export function searchShadowValue(style: SearchSettings["shadow"]) {
  if (style === "none") return "none";
  if (style === "soft") return "0 20px 55px rgba(0, 0, 0, 0.38)";
  return "0 32px 100px rgba(0, 0, 0, 0.62), 0 10px 28px rgba(0, 0, 0, 0.32)";
}
