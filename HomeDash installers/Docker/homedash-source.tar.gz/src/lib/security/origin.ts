/**
 * Same-origin check for state-changing admin routes (widget install/uninstall,
 * system update upload). Guards against cross-site form/fetch submissions.
 *
 * request.url's host is NOT reliable on its own: in the standalone Next.js
 * server, it reflects whatever Host the Node process saw, which can differ
 * from what the browser actually connected to whenever Homedash sits behind
 * a reverse proxy or tunnel (nginx, Caddy, Traefik, Cloudflare Tunnel, etc.)
 * that doesn't forward the original Host unmodified. That mismatch caused
 * legitimate same-browser requests to be rejected as "cross-origin" on any
 * non-bare-localhost deployment. We instead trust X-Forwarded-Host (set by
 * essentially all reverse proxies) and the configured HOMEDASH_PUBLIC_URL
 * as additional valid hosts alongside the raw Host header.
 */
function candidateHosts(request: Request): string[] {
  const hosts = new Set<string>();

  const headerHost = request.headers.get("host");
  if (headerHost) hosts.add(headerHost);

  const forwardedHost = request.headers.get("x-forwarded-host")?.split(",")[0]?.trim();
  if (forwardedHost) hosts.add(forwardedHost);

  try {
    hosts.add(new URL(request.url).host);
  } catch {
    // ignore
  }

  const publicUrl = process.env.HOMEDASH_PUBLIC_URL?.trim();
  if (publicUrl) {
    try {
      hosts.add(new URL(publicUrl).host);
    } catch {
      // ignore invalid optional setting
    }
  }

  return [...hosts];
}

export function isTrustedOrigin(request: Request): boolean {
  const origin = request.headers.get("origin");
  if (!origin) return true; // no Origin header => not a browser cross-site request
  try {
    const originHost = new URL(origin).host;
    return candidateHosts(request).includes(originHost);
  } catch {
    return false;
  }
}
