/**
 * Per-panel layout for the Settings page's own cards (Application, Brand
 * assets, Account, Access control, etc). This is independent of dashboard
 * tab/widget layout — it only controls how the cards *within a Settings
 * panel* are arranged when the user drags/resizes them in "Edit layout"
 * mode on the Settings page.
 *
 * Stored per-browser (not per dashboard tab / server), since it's a
 * personal display preference rather than shared dashboard configuration.
 */

export interface SettingsCardGridItem {
  i: string;
  x: number;
  y: number;
  w: number;
  h: number;
}

export const SETTINGS_CARD_COLS = 12;
export const SETTINGS_CARD_ROW_HEIGHT = 28;
export const SETTINGS_CARD_MARGIN = 14;

const DEFAULT_CARD_W = 6;
const DEFAULT_CARD_H = 12;
const STORAGE_KEY = "hd:settings-card-layout:v1";

type StoredLayouts = Record<string, SettingsCardGridItem[]>;

function readAll(): StoredLayouts {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" ? (parsed as StoredLayouts) : {};
  } catch {
    return {};
  }
}

function writeAll(layouts: StoredLayouts) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(layouts));
  } catch {
    /* ignore quota/serialization errors */
  }
}

export function readSettingsCardLayout(panelId: string): SettingsCardGridItem[] | null {
  const all = readAll();
  const items = all[panelId];
  return Array.isArray(items) ? items : null;
}

export function writeSettingsCardLayout(panelId: string, items: SettingsCardGridItem[]) {
  const all = readAll();
  all[panelId] = items;
  writeAll(all);
}

export function resetSettingsCardLayout(panelId: string) {
  const all = readAll();
  delete all[panelId];
  writeAll(all);
}

/** Simple two-column default so a fresh panel doesn't start as one long stack. */
export function buildDefaultSettingsCardLayout(ids: string[]): SettingsCardGridItem[] {
  return ids.map((id, index) => ({
    i: id,
    x: (index % 2) * DEFAULT_CARD_W,
    y: Math.floor(index / 2) * DEFAULT_CARD_H,
    w: DEFAULT_CARD_W,
    h: DEFAULT_CARD_H,
  }));
}

/**
 * Reconciles a stored layout against the cards actually present right now:
 * keeps positions for cards that still exist, drops ids that vanished, and
 * appends any new ids below everything else at full width.
 */
export function reconcileSettingsCardLayout(
  stored: SettingsCardGridItem[] | null,
  ids: string[],
): SettingsCardGridItem[] {
  if (!stored || !stored.length) return buildDefaultSettingsCardLayout(ids);
  const idSet = new Set(ids);
  const kept = stored.filter((item) => idSet.has(item.i));
  const keptIds = new Set(kept.map((item) => item.i));
  const missing = ids.filter((id) => !keptIds.has(id));
  let nextY = kept.reduce((max, item) => Math.max(max, item.y + item.h), 0);
  const appended = missing.map((id) => {
    const item = { i: id, x: 0, y: nextY, w: SETTINGS_CARD_COLS, h: DEFAULT_CARD_H };
    nextY += DEFAULT_CARD_H;
    return item;
  });
  return [...kept, ...appended];
}
