type CacheEntry = {
  expiresAt: number;
  value: unknown;
};

const cache = new Map<string, CacheEntry>();
const inflight = new Map<string, Promise<unknown>>();

/**
 * TTL + single-flight cache for heavy widget status fan-outs.
 * Concurrent callers with the same key share one upstream promise.
 */
export async function cachedStatus<T>(
  key: string,
  ttlMs: number,
  loader: () => Promise<T>,
): Promise<T> {
  const now = Date.now();
  const hit = cache.get(key);
  if (hit && hit.expiresAt > now) {
    return hit.value as T;
  }

  const pending = inflight.get(key);
  if (pending) {
    return pending as Promise<T>;
  }

  const promise = (async () => {
    try {
      const value = await loader();
      cache.set(key, { value, expiresAt: Date.now() + Math.max(0, ttlMs) });
      return value;
    } catch (error) {
      // A previously successful widget response is more useful than an empty
      // card during a brief upstream or mobile-resume failure.
      if (hit) return hit.value as T;
      throw error;
    } finally {
      inflight.delete(key);
    }
  })();

  inflight.set(key, promise);
  return promise;
}

/** Drop a cached entry (e.g. after a mutating action). */
export function invalidateStatusCache(keyPrefix?: string) {
  if (!keyPrefix) {
    cache.clear();
    return;
  }
  for (const key of cache.keys()) {
    if (key === keyPrefix || key.startsWith(`${keyPrefix}:`) || key.startsWith(keyPrefix)) {
      cache.delete(key);
    }
  }
}
