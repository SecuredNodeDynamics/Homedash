"use client";

import { create } from "zustand";
import type { LayoutConfig, ThemeSettings } from "./types";
import type { Breakpoint, Orientation } from "./breakpoints";

const PRIVACY_KEY = "hd:privacy-blur";

function readPrivacyFlag() {
  if (typeof window === "undefined") return false;
  try {
    return window.sessionStorage.getItem(PRIVACY_KEY) === "1";
  } catch {
    return false;
  }
}

interface DashboardStore {
  editMode: boolean;
  dirty: boolean;
  activeTabId: string | null;
  layout: LayoutConfig | null;
  /** When set in edit mode, overrides the viewport-detected breakpoint. */
  editBreakpoint: Breakpoint | null;
  /** When set in edit mode, overrides viewport orientation for sm/md slots. */
  editOrientation: Orientation | null;
  autoLayoutToken: number;
  alignTopsToken: number;
  /** Blur IPs / URLs / credentials for safe screenshots */
  privacyBlur: boolean;
  /** Unsaved Appearance theme while Settings is open — drives live preview */
  previewTheme: ThemeSettings | null;
  /** Whether the header's "Edit layout" button is currently active on the Settings page. */
  settingsCardEditMode: boolean;
  /**
   * Whether the currently-selected Settings panel has a card grid that can
   * be laid out (set by SettingsForm as the user switches panels), so
   * AppChrome knows whether to show the "Edit layout" control at all.
   */
  settingsCardEditablePanel: boolean;
  /** Bumped to ask SettingsForm's card grid to persist its current arrangement. */
  settingsCardSaveToken: number;
  /** Bumped to ask SettingsForm's card grid to discard unsaved changes. */
  settingsCardCancelToken: number;
  setEditMode: (value: boolean) => void;
  setActiveTabId: (tabId: string | null) => void;
  setLayout: (layout: LayoutConfig) => void;
  setLayoutQuiet: (layout: LayoutConfig) => void;
  setEditBreakpoint: (bp: Breakpoint | null) => void;
  setEditOrientation: (orientation: Orientation | null) => void;
  markDirty: (value?: boolean) => void;
  triggerAutoLayout: () => void;
  triggerAlignTops: () => void;
  setPrivacyBlur: (value: boolean) => void;
  togglePrivacyBlur: () => void;
  setPreviewTheme: (theme: ThemeSettings | null) => void;
  setSettingsCardEditMode: (value: boolean) => void;
  setSettingsCardEditablePanel: (value: boolean) => void;
  triggerSettingsCardSave: () => void;
  triggerSettingsCardCancel: () => void;
}

export const useDashboardStore = create<DashboardStore>((set, get) => ({
  editMode: false,
  dirty: false,
  activeTabId: null,
  layout: null,
  editBreakpoint: null,
  editOrientation: null,
  autoLayoutToken: 0,
  alignTopsToken: 0,
  privacyBlur: false,
  previewTheme: null,
  settingsCardEditMode: false,
  settingsCardEditablePanel: false,
  settingsCardSaveToken: 0,
  settingsCardCancelToken: 0,
  setEditMode: (editMode) =>
    set((state) => ({
      editMode,
      editBreakpoint: editMode ? state.editBreakpoint : null,
      editOrientation: editMode ? state.editOrientation : null,
    })),
  setActiveTabId: (activeTabId) => set({ activeTabId }),
  setLayout: (layout) => set({ layout, dirty: true }),
  setLayoutQuiet: (layout) => set({ layout }),
  setEditBreakpoint: (editBreakpoint) => set({ editBreakpoint }),
  setEditOrientation: (editOrientation) => set({ editOrientation }),
  markDirty: (dirty = true) => set({ dirty }),
  triggerAutoLayout: () => set((s) => ({ autoLayoutToken: s.autoLayoutToken + 1 })),
  triggerAlignTops: () => set((s) => ({ alignTopsToken: s.alignTopsToken + 1 })),
  setPrivacyBlur: (privacyBlur) => {
    try {
      if (typeof window !== "undefined") {
        window.sessionStorage.setItem(PRIVACY_KEY, privacyBlur ? "1" : "0");
      }
    } catch {
      /* ignore */
    }
    set({ privacyBlur });
  },
  togglePrivacyBlur: () => get().setPrivacyBlur(!get().privacyBlur),
  setPreviewTheme: (previewTheme) => set({ previewTheme }),
  setSettingsCardEditMode: (settingsCardEditMode) => set({ settingsCardEditMode }),
  setSettingsCardEditablePanel: (settingsCardEditablePanel) => set({ settingsCardEditablePanel }),
  triggerSettingsCardSave: () => set((s) => ({ settingsCardSaveToken: s.settingsCardSaveToken + 1 })),
  triggerSettingsCardCancel: () => set((s) => ({ settingsCardCancelToken: s.settingsCardCancelToken + 1 })),
}));

/** Hydrate privacy flag after mount (avoids SSR mismatch). */
export function hydratePrivacyBlur() {
  useDashboardStore.getState().setPrivacyBlur(readPrivacyFlag());
}
