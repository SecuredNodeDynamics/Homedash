import type { AppSettings, DashboardTab, LayoutConfig, ThemeSettings } from "./types";
import type { Breakpoint } from "./breakpoints";
import { BREAKPOINT_ORDER, DEFAULT_COLS } from "./breakpoints";
import { DEFAULT_SEARCH_SETTINGS } from "./search-settings";

export function slugifyTabName(name: string) {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "") || "tab";
}

/** Homepage settings.yaml tab → Homedash widget ids */
export const HOMEPAGE_TAB_WIDGETS: Record<string, string[]> = {
  Network: [
    "adguard-control",
    "pihole",
    "net-glances",
    "uk-monitor",
    "tailscale",
    "cloudflare",
    "clock",
    "notes",
  ],
  Monitor: ["proxmox-nodes"],
  Traffic: ["wazuh", "speedtest", "checkmk", "invest-stocks", "invest-crypto", "crypto-tracker", "invest-news"],
  Media: ["jellyfin-slider", "jf-monitor", "seerr", "wizarr"],
  Arr: ["radarr", "sonarr", "tracearr", "prowlarr", "lidarr", "bazarr", "tdarr", "dispatcharr"],
  Schedule: ["qbit", "media-calendar"],
  Links: ["net-topology", "downtify", "immich", "navidrome", "bookmarks"],
  Demo: [
    "homeassistant",
    "nextcloud",
    "audiobookshelf",
    "bookorbit",
    "shelfmark",
    "plex",
    "plex-slider",
    "tautulli",
    "mealie",
    "truenas",
    "youtube",
  ],
};

const TAB_ORDER = ["Network", "Monitor", "Traffic", "Media", "Arr", "Schedule", "Links", "Demo"] as const;

export function buildDefaultTabs(): DashboardTab[] {
  return TAB_ORDER.map((name, index) => ({
    id: slugifyTabName(name),
    name,
    order: index,
    widgetIds: [...(HOMEPAGE_TAB_WIDGETS[name] || [])],
  }));
}

export function normalizeTabs(tabs: DashboardTab[] | undefined): DashboardTab[] {
  if (!tabs?.length) return buildDefaultTabs();
  return [...tabs]
    .map((tab, index) => {
      const rawVis = tab.deviceVisibility;
      let deviceVisibility: DashboardTab["deviceVisibility"];
      if (rawVis && typeof rawVis === "object") {
        const next: NonNullable<DashboardTab["deviceVisibility"]> = {};
        for (const bp of BREAKPOINT_ORDER) {
          if (rawVis[bp] === false) next[bp] = false;
          else if (rawVis[bp] === true) next[bp] = true;
        }
        if (Object.keys(next).length) deviceVisibility = next;
      }
      return {
        id: tab.id || slugifyTabName(tab.name || `tab-${index}`),
        name: tab.name?.trim() || `Tab ${index + 1}`,
        order: typeof tab.order === "number" ? tab.order : index,
        widgetIds: Array.isArray(tab.widgetIds) ? tab.widgetIds : [],
        ...(deviceVisibility ? { deviceVisibility } : {}),
      };
    })
    .sort((a, b) => a.order - b.order)
    .map((tab, index) => ({ ...tab, order: index }));
}

/** True when the tab should appear in the nav at this breakpoint. */
export function isTabVisibleOn(tab: DashboardTab, bp: Breakpoint): boolean {
  return tab.deviceVisibility?.[bp] !== false;
}

export function emptyLayout(): LayoutConfig {
  return { lg: [], md: [], sm: [], xl: [], xxl: [] };
}

export function buildLayoutForWidgets(
  widgetIds: string[],
  sizes: Record<string, { w: number; h: number }> = {},
): LayoutConfig {
  const defaultSize = { w: 1, h: 4 };
  const lgCols = DEFAULT_COLS.lg;
  const mdCols = DEFAULT_COLS.md;
  const lg: LayoutConfig["lg"] = [];
  let x = 0;
  let y = 0;
  let rowH = 0;
  for (const id of widgetIds) {
    const size = sizes[id] || defaultSize;
    const w = Math.min(size.w, lgCols);
    const h = size.h;
    if (x + w > lgCols) {
      x = 0;
      y += rowH;
      rowH = 0;
    }
    lg.push({ i: id, x, y, w, h, minW: 1, minH: 2 });
    x += w;
    rowH = Math.max(rowH, h);
  }

  const md = widgetIds.map((id, index) => {
    const size = sizes[id] || defaultSize;
    const w = Math.min(size.w, mdCols);
    const h = size.h;
    const col = index % Math.max(1, Math.floor(mdCols / Math.max(1, w)));
    return {
      i: id,
      x: Math.min(col * w, Math.max(0, mdCols - w)),
      y: Math.floor(index / Math.max(1, Math.floor(mdCols / Math.max(1, w)))) * h,
      w,
      h,
      minW: 1,
      minH: 2,
    };
  });

  let smY = 0;
  const sm = widgetIds.map((id) => {
    const h = (sizes[id] || defaultSize).h;
    const item = { i: id, x: 0, y: smY, w: 1, h, minW: 1, minH: 2 };
    smY += h;
    return item;
  });

  return { lg, md, sm, xl: [], xxl: [] };
}

/** Default sizes for the 6-col desktop / wide / ultrawide grids. */
export const WIDGET_LAYOUT_SIZES: Record<string, { w: number; h: number }> = {
  "jellyfin-slider": { w: 3, h: 5 },
  "plex-slider": { w: 3, h: 5 },
  seerr: { w: 2, h: 5 },
  "media-calendar": { w: 3, h: 5 },
  "proxmox-nodes": { w: 2, h: 18 },
  qbit: { w: 2, h: 5 },
  clock: { w: 1, h: 3 },
  notes: { w: 1, h: 3 },
  todo: { w: 2, h: 6 },
  "grocery-list": { w: 2, h: 7 },
  "net-topology": { w: 3, h: 5 },
  "net-glances": { w: 2, h: 4 },
};

export const DEFAULT_THEME: ThemeSettings = {
  mode: "dark",
  accent: "#e5a00d",
  background: "#0b0f14",
  backgroundImageUrl: "",
  backgroundImageOpacity: 0.35,
  backgroundImageBlur: 0,
  backgroundImageMode: "static",
  backgroundImageUrls: [],
  backgroundImageRotateSeconds: 120,
  backgroundImageTransition: "fade",
  backgroundImageTransitionMs: 1400,
  backgroundPatternEnabled: false,
  backgroundPatternStyle: "dots",
  backgroundPatternColor: "#60a5fa",
  backgroundPatternOpacity: 0.18,
  backgroundPatternSize: 28,
  backgroundPatternWeight: 1,
  backgroundPatternAnimationEnabled: false,
  backgroundPatternAnimation: "drift",
  backgroundPatternAnimationSeconds: 18,
  backgroundPatternAnimationDirection: "normal",
  backgroundPatternAnimationStrength: 24,
  backgroundPatternAnimationColor: "#22d3ee",
  backgroundPatternAnimationColorSecondary: "#8b5cf6",
  backgroundPatternAnimationTravelDirection: "right",
  surface: "rgba(18, 24, 32, 0.86)",
  border: "rgba(255, 255, 255, 0.10)",
  radius: 18,
  font: "Manrope",
  buttonAccentColor: "",
  cardAccent: "rainbow",
  cardAccentColor: "#e5a00d",
  cardBackground: "rgb(12, 16, 22)",
  cardOpacity: 0.85,
  cardBlur: 18,
  cardSaturate: 120,
  cardBorderStyle: "glass",
  cardBorderColor: "",
  cardShadow: "none",
  headerLayout: "flush",
  headerBackground: "rgb(8, 12, 18)",
  headerOpacity: 0.72,
  headerBlur: 16,
  headerBorderStyle: "soft",
  headerBorderColor: "",
  headerRadius: 18,
  headerShadow: "none",
  headerTabStyle: "pill",
  headerTabActiveStyle: "accent",
  headerTabRadius: 999,
  headerQuickLinks: {
    "google-search": false,
    gmail: false,
    "google-calendar": false,
    "google-drive": false,
    instagram: false,
    facebook: false,
    threads: false,
    linkedin: false,
  },
  headerQuickLinksPlacement: "right",
  search: { ...DEFAULT_SEARCH_SETTINGS },
};

export function defaultAppSettings(): AppSettings {
  const tabs = buildDefaultTabs();
  return {
    appName: "Homedash",
    logoUrl: "",
    faviconUrl: "",
    redirectLocalToPublic: true,
    theme: { ...DEFAULT_THEME },
    gridCols: { ...DEFAULT_COLS },
    tabs,
    enabledWidgets: tabs.flatMap((t) => t.widgetIds),
    widgetAccents: {},
    widgetIcons: {},
    widgetChrome: {},
    widgetInstances: [],
    bookmarks: [],
    bookmarkGroups: [{ id: "general", name: "General", order: 0 }],
  };
}
