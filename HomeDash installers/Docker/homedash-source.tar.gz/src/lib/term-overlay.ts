"use client";

import { useEffect } from "react";

/**
 * Phones + touch tablets (incl. landscape widths past 900px).
 * Prefer this over max-width:900 alone — Homedash tablet layout uses short-edge
 * breakpoints, so CSS width is often >900 while the UI is still "tablet".
 */
export const TERM_OVERLAY_MQ =
  "(max-width: 900px), ((max-width: 1180px) and (hover: none) and (pointer: coarse))";

export function matchesTermOverlayViewport(): boolean {
  return typeof window !== "undefined" && window.matchMedia(TERM_OVERLAY_MQ).matches;
}

/**
 * Soft background lock for terminal/console overlays.
 * Never uses position:fixed on body (that races the open tap on touch WebViews).
 * Never sets touch-action:none on body (that blocks the terminal itself).
 */
export function useTermOverlayLock() {
  useEffect(() => {
    if (!matchesTermOverlayViewport()) return;

    const html = document.documentElement;
    const prev = {
      htmlOverflow: html.style.overflow,
      bodyOverflow: document.body.style.overflow,
    };

    let cancelled = false;
    // Wait until the portal has painted before locking scroll.
    const timer = window.setTimeout(() => {
      if (cancelled) return;
      html.style.overflow = "hidden";
      document.body.style.overflow = "hidden";
      document.body.classList.add("hd-term-open");
    }, 100);

    return () => {
      cancelled = true;
      window.clearTimeout(timer);
      html.style.overflow = prev.htmlOverflow;
      document.body.style.overflow = prev.bodyOverflow;
      document.body.classList.remove("hd-term-open");
    };
  }, []);
}
