import type { CSSProperties } from "react";
import type {
  BackgroundImageTransition,
  BackgroundPatternStyle,
  BackgroundPatternAnimation,
  BackgroundPatternTravelDirection,
  CardAccentMode,
  CardBorderStyle,
  CardShadowStyle,
  HeaderLayoutMode,
  HeaderTabActiveStyle,
  HeaderTabStyle,
  ThemeSettings,
  WidgetAccentSettings,
  WidgetChromeSettings,
} from "./types";
import { BREAKPOINT_ORDER, type Breakpoint } from "./breakpoints";

export type ChromeExpand = NonNullable<WidgetChromeSettings["expand"]>;

const BG_TRANSITIONS: BackgroundImageTransition[] = ["fade", "slide", "zoom", "blur"];
const BG_PATTERNS: BackgroundPatternStyle[] = [
  "dots",
  "grid",
  "diagonal",
  "crosshatch",
  "blueprint",
  "diamonds",
  "waves",
  "radial",
];
const BG_PATTERN_ANIMATIONS: BackgroundPatternAnimation[] = [
  "drift",
  "diagonal-drift",
  "pulse",
  "breathe",
  "scan",
  "rotate",
  "wave-3d",
  "ripple-3d",
  "wave-4d",
];
const BG_PATTERN_TRAVEL_DIRECTIONS: BackgroundPatternTravelDirection[] = [
  "right", "left", "up", "down", "up-right", "up-left", "down-right", "down-left",
];

/** Normalize stored Expand: true = all devices, array = specific, undefined = off. */
export function normalizeChromeExpand(value: unknown): ChromeExpand | undefined {
  if (value === true) return true;
  if (!Array.isArray(value)) return undefined;
  const allowed = new Set<string>(BREAKPOINT_ORDER);
  const picked = BREAKPOINT_ORDER.filter((bp) =>
    value.some((entry) => entry === bp && allowed.has(bp)),
  );
  if (!picked.length) return undefined;
  if (picked.length === BREAKPOINT_ORDER.length) return true;
  return picked;
}

export function isChromeExpandOn(expand: WidgetChromeSettings["expand"] | undefined): boolean {
  return normalizeChromeExpand(expand) != null;
}

/** Whether Expand should run for the live / edit breakpoint. */
export function isChromeExpandActive(
  expand: WidgetChromeSettings["expand"] | undefined,
  bp: Breakpoint | null | undefined,
): boolean {
  const normalized = normalizeChromeExpand(expand);
  if (!normalized || !bp) return false;
  if (normalized === true) return true;
  return normalized.includes(bp);
}

/** Toggle a device chip while Expand is on. */
export function toggleChromeExpandDevice(
  expand: WidgetChromeSettings["expand"] | undefined,
  bp: Breakpoint,
): ChromeExpand | undefined {
  const normalized = normalizeChromeExpand(expand);
  if (!normalized) return [bp];
  if (normalized === true) {
    const next = BREAKPOINT_ORDER.filter((entry) => entry !== bp);
    return normalizeChromeExpand(next);
  }
  const has = normalized.includes(bp);
  const next = has ? normalized.filter((entry) => entry !== bp) : [...normalized, bp];
  return normalizeChromeExpand(next);
}

export function normalizeThemeBackground(theme: ThemeSettings): ThemeSettings {
  const mode = theme.backgroundImageMode === "rotate" ? "rotate" : "static";
  const urls = Array.isArray(theme.backgroundImageUrls)
    ? theme.backgroundImageUrls.map((url) => String(url || "").trim()).filter(Boolean)
    : [];
  const rotateSeconds = Math.max(
    15,
    Math.min(3600, Number(theme.backgroundImageRotateSeconds) || 120),
  );
  const transition = BG_TRANSITIONS.includes(theme.backgroundImageTransition as BackgroundImageTransition)
    ? (theme.backgroundImageTransition as BackgroundImageTransition)
    : "fade";
  const transitionMs = Math.max(
    200,
    Math.min(8000, Math.round(Number(theme.backgroundImageTransitionMs) || 1400)),
  );
  const patternStyle = BG_PATTERNS.includes(theme.backgroundPatternStyle as BackgroundPatternStyle)
    ? theme.backgroundPatternStyle as BackgroundPatternStyle
    : "dots";
  const patternAnimation = BG_PATTERN_ANIMATIONS.includes(
    theme.backgroundPatternAnimation as BackgroundPatternAnimation,
  )
    ? theme.backgroundPatternAnimation as BackgroundPatternAnimation
    : "drift";
  const animationDirection = ["normal", "reverse", "alternate"].includes(
    String(theme.backgroundPatternAnimationDirection),
  )
    ? theme.backgroundPatternAnimationDirection
    : "normal";
  const travelDirection = BG_PATTERN_TRAVEL_DIRECTIONS.includes(
    theme.backgroundPatternAnimationTravelDirection as BackgroundPatternTravelDirection,
  )
    ? theme.backgroundPatternAnimationTravelDirection as BackgroundPatternTravelDirection
    : "right";
  return {
    ...theme,
    backgroundImageMode: mode,
    backgroundImageUrls: urls,
    backgroundImageRotateSeconds: rotateSeconds,
    backgroundImageTransition: transition,
    backgroundImageTransitionMs: transitionMs,
    backgroundPatternEnabled: Boolean(theme.backgroundPatternEnabled),
    backgroundPatternStyle: patternStyle,
    backgroundPatternColor: String(theme.backgroundPatternColor || "#60a5fa"),
    backgroundPatternOpacity: clamp(Number(theme.backgroundPatternOpacity ?? 0.18), 0, 0.8),
    backgroundPatternSize: clamp(Number(theme.backgroundPatternSize ?? 28), 8, 120),
    backgroundPatternWeight: clamp(Number(theme.backgroundPatternWeight ?? 1), 0.5, 4),
    backgroundPatternAnimationEnabled: Boolean(theme.backgroundPatternAnimationEnabled),
    backgroundPatternAnimation: patternAnimation,
    backgroundPatternAnimationSeconds: clamp(
      Number(theme.backgroundPatternAnimationSeconds ?? 18),
      3,
      120,
    ),
    backgroundPatternAnimationDirection: animationDirection,
    backgroundPatternAnimationStrength: clamp(
      Number(theme.backgroundPatternAnimationStrength ?? 24),
      4,
      100,
    ),
    backgroundPatternAnimationColor: String(
      theme.backgroundPatternAnimationColor || "#22d3ee",
    ),
    backgroundPatternAnimationColorSecondary: String(
      theme.backgroundPatternAnimationColorSecondary || "#8b5cf6",
    ),
    backgroundPatternAnimationTravelDirection: travelDirection,
  };
}

/** Active wallpaper URL list for the current mode. */
export function themeBackgroundUrls(theme: ThemeSettings): string[] {
  const normalized = normalizeThemeBackground(theme);
  if (normalized.backgroundImageMode === "rotate") {
    const gallery = normalized.backgroundImageUrls || [];
    if (gallery.length) return gallery;
    const single = normalized.backgroundImageUrl?.trim();
    return single ? [single] : [];
  }
  const single = normalized.backgroundImageUrl?.trim();
  return single ? [single] : [];
}

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

function borderTokens(
  kind: CardBorderStyle | undefined,
  customColor: string | undefined,
  fallback: string,
  defaultKind: CardBorderStyle = "glass",
): { width: string; style: string; color: string } {
  const resolved = (kind || defaultKind) as CardBorderStyle;
  const custom = customColor?.trim();
  switch (resolved) {
    case "none":
      return { width: "0px", style: "solid", color: "transparent" };
    case "soft":
      return { width: "1px", style: "solid", color: custom || "rgba(255, 255, 255, 0.06)" };
    case "solid":
      return { width: "1px", style: "solid", color: custom || fallback };
    case "strong":
      return { width: "2px", style: "solid", color: custom || "rgba(255, 255, 255, 0.22)" };
    case "dashed":
      return { width: "1px", style: "dashed", color: custom || fallback };
    case "glass":
    default:
      return { width: "1px", style: "solid", color: custom || "rgba(255, 255, 255, 0.10)" };
  }
}

function shadowToken(style: CardShadowStyle | undefined): string {
  switch (style) {
    case "soft":
      return "0 6px 16px rgba(0, 0, 0, 0.22)";
    case "lift":
      return "0 14px 34px rgba(0, 0, 0, 0.34)";
    case "none":
    default:
      return "none";
  }
}

export function themeHeaderLayout(theme: ThemeSettings): HeaderLayoutMode {
  return theme.headerLayout === "floating" ? "floating" : "flush";
}

export function themeHeaderTabStyle(theme: ThemeSettings): HeaderTabStyle {
  const style = theme.headerTabStyle;
  if (style === "underline" || style === "chip" || style === "segment" || style === "pill") {
    return style;
  }
  return "pill";
}

export function themeHeaderTabActiveStyle(theme: ThemeSettings): HeaderTabActiveStyle {
  const style = theme.headerTabActiveStyle;
  if (style === "soft" || style === "outline" || style === "plain" || style === "accent") {
    return style;
  }
  return "accent";
}

export function themeToCssVars(theme: ThemeSettings): CSSProperties {
  const normalized = normalizeThemeBackground(theme);
  const urls = themeBackgroundUrls(normalized);
  const imageUrl = urls[0] || "";
  const hasImage = urls.length > 0;
  const cardAccent = normalized.cardAccent || "rainbow";
  const solid = normalized.cardAccentColor || normalized.accent;
  const buttonAccent = normalized.buttonAccentColor?.trim() || normalized.accent;
  // Prefer unquoted url() paths — React HTML-escapes quotes inside style attributes.
  const safeUrl = imageUrl.replace(/[)\\s]/g, (ch) => encodeURIComponent(ch));
  // Rotating wallpapers are painted by <BackgroundRotator>; keep ::before empty then.
  const useCssLayer = hasImage && normalized.backgroundImageMode !== "rotate";
  const cardBg = normalized.cardBackground?.trim() || normalized.surface || "rgb(12, 16, 22)";
  const cardOpacity = clamp(Number(normalized.cardOpacity ?? 0.85), 0, 1);
  const cardBlur = clamp(Number(normalized.cardBlur ?? 18), 0, 40);
  const cardSaturate = clamp(Number(normalized.cardSaturate ?? 120), 100, 200);
  const border = borderTokens(
    normalized.cardBorderStyle,
    normalized.cardBorderColor,
    normalized.border || "rgba(255, 255, 255, 0.10)",
  );
  const shadowStyle = (normalized.cardShadow || "none") as CardShadowStyle;
  const shadow = shadowToken(shadowStyle);
  const shadowHover =
    shadowStyle === "lift"
      ? "0 18px 40px rgba(0, 0, 0, 0.4)"
      : shadowStyle === "soft"
        ? "0 10px 22px rgba(0, 0, 0, 0.28)"
        : "0 6px 14px rgba(0, 0, 0, 0.18)";

  const headerBg =
    normalized.headerBackground?.trim() || "rgb(8, 12, 18)";
  const headerOpacity = clamp(Number(normalized.headerOpacity ?? 0.72), 0, 1);
  const headerBlur = clamp(Number(normalized.headerBlur ?? 16), 0, 40);
  const headerBorder = borderTokens(
    normalized.headerBorderStyle || "soft",
    normalized.headerBorderColor,
    normalized.border || "rgba(255, 255, 255, 0.10)",
    "soft",
  );
  const headerRadius = clamp(Number(normalized.headerRadius ?? normalized.radius ?? 18), 0, 40);
  const headerShadow = shadowToken(normalized.headerShadow || "none");
  const tabRadiusRaw = Number(normalized.headerTabRadius ?? 999);
  const tabRadius = tabRadiusRaw >= 40 ? "999px" : `${clamp(tabRadiusRaw, 0, 40)}px`;

  return {
    ["--hd-accent" as string]: normalized.accent,
    ["--hd-btn-accent" as string]: buttonAccent,
    ["--hd-bg" as string]: normalized.background,
    ["--hd-surface" as string]: normalized.surface,
    ["--hd-border" as string]: normalized.border,
    ["--hd-radius" as string]: `${normalized.radius}px`,
    ["--hd-font" as string]: `"${normalized.font}", ui-sans-serif, system-ui, sans-serif`,
    ["--hd-bg-image" as string]: useCssLayer ? `url(${safeUrl})` : "none",
    ["--hd-bg-image-opacity" as string]: String(normalized.backgroundImageOpacity ?? 0.35),
    ["--hd-bg-image-blur" as string]: `${normalized.backgroundImageBlur ?? 0}px`,
    ["--hd-bg-pattern-color" as string]: normalized.backgroundPatternColor || "#60a5fa",
    ["--hd-bg-pattern-opacity" as string]: String(normalized.backgroundPatternOpacity ?? 0.18),
    ["--hd-bg-pattern-size" as string]: `${normalized.backgroundPatternSize ?? 28}px`,
    ["--hd-bg-pattern-weight" as string]: `${normalized.backgroundPatternWeight ?? 1}px`,
    ["--hd-bg-pattern-animation-duration" as string]: `${normalized.backgroundPatternAnimationSeconds ?? 18}s`,
    ["--hd-bg-pattern-animation-direction" as string]: normalized.backgroundPatternAnimationDirection || "normal",
    ["--hd-bg-pattern-animation-strength" as string]: `${normalized.backgroundPatternAnimationStrength ?? 24}px`,
    ["--hd-bg-pattern-animation-color" as string]: normalized.backgroundPatternAnimationColor || "#22d3ee",
    ["--hd-bg-pattern-animation-color-secondary" as string]: normalized.backgroundPatternAnimationColorSecondary || "#8b5cf6",
    ["--hd-bg-pattern-animation-x" as string]: `${(
      normalized.backgroundPatternAnimationTravelDirection || "right"
    ).includes("left") ? -1 : (
      normalized.backgroundPatternAnimationTravelDirection || "right"
    ).includes("right") ? 1 : 0}`,
    ["--hd-bg-pattern-animation-y" as string]: `${(
      normalized.backgroundPatternAnimationTravelDirection || "right"
    ).includes("up") ? -1 : (
      normalized.backgroundPatternAnimationTravelDirection || "right"
    ).includes("down") ? 1 : 0}`,
    ["--hd-card-accent-solid" as string]: solid,
    ["--hd-card-accent-mode" as string]: cardAccent,
    ["--hd-card-bg" as string]: cardBg,
    ["--hd-card-opacity" as string]: String(cardOpacity),
    ["--hd-card-blur" as string]: `${cardBlur}px`,
    ["--hd-card-saturate" as string]: `${cardSaturate}%`,
    ["--hd-card-border-width" as string]: border.width,
    ["--hd-card-border-style" as string]: border.style,
    ["--hd-card-border-color" as string]: border.color,
    ["--hd-card-shadow" as string]: shadow,
    ["--hd-card-shadow-hover" as string]: shadowHover,
    ["--hd-header-bg" as string]: headerBg,
    ["--hd-header-opacity" as string]: String(headerOpacity),
    ["--hd-header-blur" as string]: `${headerBlur}px`,
    ["--hd-header-border-width" as string]: headerBorder.width,
    ["--hd-header-border-style" as string]: headerBorder.style,
    ["--hd-header-border-color" as string]: headerBorder.color,
    ["--hd-header-radius" as string]: `${headerRadius}px`,
    ["--hd-header-shadow" as string]: headerShadow,
    ["--hd-header-tab-radius" as string]: tabRadius,
    colorScheme: normalized.mode,
  };
}

export function themeHasBackgroundImage(theme: ThemeSettings) {
  return themeBackgroundUrls(theme).length > 0;
}

/** Apply theme tokens to document.body for live Appearance previews. */
export function applyThemeToDocument(theme: ThemeSettings) {
  if (typeof document === "undefined") return;
  const vars = themeToCssVars(theme);
  const body = document.body;
  for (const [key, value] of Object.entries(vars)) {
    if (value == null || value === false) continue;
    if (key.startsWith("--")) {
      body.style.setProperty(key, String(value));
      continue;
    }
    if (key === "colorScheme") {
      body.style.colorScheme = String(value);
    }
  }
  body.dataset.hdBgImage = themeHasBackgroundImage(theme) ? "1" : "0";
  body.dataset.hdBgPattern = theme.backgroundPatternEnabled
    ? (theme.backgroundPatternStyle || "dots")
    : "none";
  body.dataset.hdBgPatternAnimation =
    theme.backgroundPatternEnabled && theme.backgroundPatternAnimationEnabled
      ? (theme.backgroundPatternAnimation || "drift")
      : "none";
  body.dataset.theme = theme.mode;
  body.dataset.hdHeader = themeHeaderLayout(theme);
  body.dataset.hdTabs = themeHeaderTabStyle(theme);
  body.dataset.hdTabActive = themeHeaderTabActiveStyle(theme);
  body.classList.toggle("light", theme.mode === "light");
  body.classList.toggle("dark", theme.mode === "dark");
}

export function resolveWidgetAccent(
  globalMode: CardAccentMode | undefined,
  globalSolid: string | undefined,
  themeAccent: string,
  widget?: WidgetAccentSettings,
): { mode: "rainbow" | "solid" | "off"; color: string } {
  const inherited = globalMode || "rainbow";
  const mode = !widget || widget.mode === "inherit" ? inherited : widget.mode;
  const color = widget?.color || globalSolid || themeAccent || "#e5a00d";
  return { mode, color };
}

export function resolveWidgetChrome(
  chromeById: Record<string, WidgetChromeSettings> | undefined,
  instanceId: string,
  widgetId: string,
): { showIcon: boolean; showTitle: boolean; expand: ChromeExpand | undefined } {
  const chrome = chromeById?.[instanceId] || chromeById?.[widgetId] || {};
  return {
    showIcon: chrome.showIcon !== false,
    showTitle: chrome.showTitle !== false,
    expand: normalizeChromeExpand(chrome.expand),
  };
}

/**
 * Merge a chrome patch into an existing entry.
 * Returns `undefined` when the result matches defaults (caller should delete the key).
 */
export function mergeWidgetChromeEntry(
  existing: WidgetChromeSettings | undefined,
  patch: Partial<WidgetChromeSettings>,
  fallback?: WidgetChromeSettings,
): WidgetChromeSettings | undefined {
  const current: WidgetChromeSettings = {
    showIcon: true,
    showTitle: true,
    ...(fallback || {}),
    ...(existing || {}),
  };
  const nextExpand =
    patch.expand !== undefined
      ? normalizeChromeExpand(patch.expand === false ? undefined : patch.expand)
      : normalizeChromeExpand(current.expand);
  const next: WidgetChromeSettings = {
    showIcon: patch.showIcon ?? current.showIcon,
    showTitle: patch.showTitle ?? current.showTitle,
    ...(nextExpand != null ? { expand: nextExpand } : {}),
  };
  const atDefaults =
    next.showIcon !== false && next.showTitle !== false && next.expand == null;
  if (atDefaults) return undefined;
  return {
    ...(next.showIcon === false ? { showIcon: false } : {}),
    ...(next.showTitle === false ? { showTitle: false } : {}),
    ...(next.expand != null ? { expand: next.expand } : {}),
  };
}
