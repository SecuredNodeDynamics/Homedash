import type { ComponentType } from "react";
import type { HeaderQuickLinkItem, HeaderQuickLinks, HeaderQuickLinksPlacement } from "./header-quick-links";

export type ThemeMode = "dark" | "light";
export type CardAccentMode = "rainbow" | "solid" | "off";
export type WidgetAccentMode = "inherit" | "rainbow" | "solid" | "off";
export type BackgroundImageMode = "static" | "rotate";
export type BackgroundPatternStyle =
  | "dots"
  | "grid"
  | "diagonal"
  | "crosshatch"
  | "blueprint"
  | "diamonds"
  | "waves"
  | "radial";
export type BackgroundPatternAnimation =
  | "drift"
  | "diagonal-drift"
  | "pulse"
  | "breathe"
  | "scan"
  | "rotate"
  | "wave-3d"
  | "ripple-3d"
  | "wave-4d";
export type BackgroundPatternTravelDirection =
  | "right"
  | "left"
  | "up"
  | "down"
  | "up-right"
  | "up-left"
  | "down-right"
  | "down-left";
/** How rotating gallery images cross between slides */
export type BackgroundImageTransition = "fade" | "slide" | "zoom" | "blur";
export type CardBorderStyle = "none" | "soft" | "glass" | "solid" | "strong" | "dashed";
export type CardShadowStyle = "none" | "soft" | "lift";
/** Flush = edge-to-edge sticky bar; floating = inset card-like bar */
export type HeaderLayoutMode = "flush" | "floating";
/** How tab buttons are arranged in the header */
export type HeaderTabStyle = "pill" | "underline" | "chip" | "segment";
/** Active tab treatment */
export type HeaderTabActiveStyle = "accent" | "soft" | "outline" | "plain";
export type SearchShadowStyle = "none" | "soft" | "strong";
export type SearchResultDensity = "compact" | "comfortable" | "roomy";
export type { HeaderQuickLinksPlacement };

export interface ThemeSettings {
  mode: ThemeMode;
  accent: string;
  background: string;
  backgroundImageUrl: string;
  backgroundImageOpacity: number;
  backgroundImageBlur: number;
  /**
   * static = single wallpaper (backgroundImageUrl)
   * rotate = soft-fade through backgroundImageUrls on an interval
   */
  backgroundImageMode?: BackgroundImageMode;
  /** Gallery used when backgroundImageMode is "rotate" */
  backgroundImageUrls?: string[];
  /** Seconds between rotates. Default 120. */
  backgroundImageRotateSeconds?: number;
  /** Crossfade style when rotating gallery images. Default fade. */
  backgroundImageTransition?: BackgroundImageTransition;
  /** Transition duration in milliseconds. Default 1400. */
  backgroundImageTransitionMs?: number;
  /** Decorative layer above the wallpaper and behind dashboard content. */
  backgroundPatternEnabled?: boolean;
  backgroundPatternStyle?: BackgroundPatternStyle;
  backgroundPatternColor?: string;
  backgroundPatternOpacity?: number;
  backgroundPatternSize?: number;
  backgroundPatternWeight?: number;
  backgroundPatternAnimationEnabled?: boolean;
  backgroundPatternAnimation?: BackgroundPatternAnimation;
  backgroundPatternAnimationSeconds?: number;
  backgroundPatternAnimationDirection?: "normal" | "reverse" | "alternate";
  backgroundPatternAnimationStrength?: number;
  backgroundPatternAnimationColor?: string;
  backgroundPatternAnimationColorSecondary?: string;
  backgroundPatternAnimationTravelDirection?: BackgroundPatternTravelDirection;
  surface: string;
  border: string;
  radius: number;
  font: string;
  /**
   * Override for the primary system button color (background/border/text).
   * Empty/omitted = inherits `accent`.
   */
  buttonAccentColor?: string;
  /** Global left edge accent on widget cards */
  cardAccent: CardAccentMode;
  /** Used when cardAccent is "solid" */
  cardAccentColor: string;
  /** Widget card fill color (alpha controlled separately by cardOpacity) */
  cardBackground?: string;
  /** Widget card fill opacity 0–1. Default 0.85 */
  cardOpacity?: number;
  /** Widget card backdrop blur in px. Default 18 */
  cardBlur?: number;
  /** Extra saturate % for glass cards. Default 120 */
  cardSaturate?: number;
  /** Border treatment for widget cards */
  cardBorderStyle?: CardBorderStyle;
  /** Optional border color override */
  cardBorderColor?: string;
  /** Drop shadow under widget cards */
  cardShadow?: CardShadowStyle;
  /** Top header: flush to edges or floating like cards */
  headerLayout?: HeaderLayoutMode;
  headerBackground?: string;
  headerOpacity?: number;
  headerBlur?: number;
  headerBorderStyle?: CardBorderStyle;
  headerBorderColor?: string;
  /** Corner radius when floating (and for floating bar overall) */
  headerRadius?: number;
  headerShadow?: CardShadowStyle;
  headerTabStyle?: HeaderTabStyle;
  headerTabActiveStyle?: HeaderTabActiveStyle;
  /** Tab / pill corner radius in px */
  headerTabRadius?: number;
  /**
   * Icon-only quick links in the header.
   * Each key defaults to off when omitted.
   */
  headerQuickLinks?: HeaderQuickLinks;
  /** Editable built-in and custom header links. Falls back to legacy flags when omitted. */
  headerQuickLinkItems?: HeaderQuickLinkItem[];
  /**
   * Desktop placement for enabled quick links.
   * left = after logo/title, center = under tabs, right = before layout/logout.
   * Default right.
   */
  headerQuickLinksPlacement?: HeaderQuickLinksPlacement;
  /** Command-palette search appearance and visible content. */
  search?: SearchSettings;
}

export interface SearchSettings {
  popupBackground: string;
  popupOpacity: number;
  popupBlur: number;
  backdropBackground: string;
  backdropOpacity: number;
  backdropBlur: number;
  borderColor: string;
  borderWidth: number;
  radius: number;
  width: number;
  shadow: SearchShadowStyle;
  resultDensity: SearchResultDensity;
  maxResults: number;
  showResultHeader: boolean;
  showResultCount: boolean;
  showIcons: boolean;
  showDescriptions: boolean;
  showResultTypes: boolean;
  showWebSearch: boolean;
  showKeyboardHints: boolean;
}

export interface WidgetAccentSettings {
  mode: WidgetAccentMode;
  /** Used when mode is "solid" */
  color?: string;
}

/** Per-widget / per-instance card chrome (frame header) */
export interface WidgetChromeSettings {
  /** Show logo/icon in the card header. Default true. */
  showIcon?: boolean;
  /** Show title in the card header. Default true. */
  showTitle?: boolean;
  /**
   * Content-fit Expand. Default off.
   * - `true` — all device breakpoints
   * - breakpoint list — only those devices (e.g. `["sm"]` for Mobile)
   */
  expand?: boolean | Array<"xxl" | "xl" | "lg" | "md" | "sm">;
}

export interface DashboardTab {
  id: string;
  name: string;
  order: number;
  /** Package ids and/or instance ids (`widgetId--key`) shown on this tab */
  widgetIds: string[];
  /**
   * Per-device visibility (sm→xxl). Omitted or true = shown; false = hidden.
   * Hidden tabs (and their widgets) are omitted from the nav at that breakpoint.
   */
  deviceVisibility?: Partial<Record<"xxl" | "xl" | "lg" | "md" | "sm", boolean>>;
}

export interface WidgetInstance {
  /** Layout / config id, e.g. `adguard-control--agh1` */
  id: string;
  widgetId: string;
  key: string;
  label: string;
}

/** Catalog entry edited under Settings → BookMarks */
export interface BookmarkItem {
  id: string;
  name: string;
  /** Logo URL (upload, CDN, or dashboardicons) */
  icon?: string;
  /** LAN / host IP shown on the card (e.g. 10.128.1.29) */
  ip?: string;
  /** Full LAN URL opened via “Local IP” (may include port/path) */
  localUrl?: string;
  /** Public / tunnel URL opened via “Cloudflare” */
  publicUrl: string;
  /** Optional category tag under the card */
  category?: string;
  /** Bookmark group id from Settings → BookMarks */
  groupId?: string;
}

/** Named group of bookmarks; widgets pick one group to display */
export interface BookmarkGroup {
  id: string;
  name: string;
  order: number;
}

export interface AppSettings {
  appName: string;
  logoUrl: string;
  faviconUrl: string;
  /** Redirect direct HTTP/local-IP dashboard visits to HOMEDASH_PUBLIC_URL. */
  redirectLocalToPublic: boolean;
  theme: ThemeSettings;
  /**
   * Dashboard grid column counts per device breakpoint.
   * Omitted keys fall back to built-in defaults (xxl 8 / xl 6 / lg 6 / md 2 / sm 1).
   */
  gridCols?: Partial<Record<"xxl" | "xl" | "lg" | "md" | "sm", number>>;
  tabs: DashboardTab[];
  enabledWidgets: string[];
  widgetAccents: Record<string, WidgetAccentSettings>;
  /** Custom logo/icon URL per widget or instance id */
  widgetIcons: Record<string, string>;
  /** Show/hide frame logo & title per widget or instance id */
  widgetChrome: Record<string, WidgetChromeSettings>;
  /** Extra cards for multi-server widgets (AdGuard, Pi-hole, Proxmox, qBit, …) */
  widgetInstances: WidgetInstance[];
  /** Global bookmark catalog for the Bookmarks widget */
  bookmarks: BookmarkItem[];
  /** Named groups used to filter bookmarks per widget instance */
  bookmarkGroups: BookmarkGroup[];
}

export interface GridItem {
  i: string;
  x: number;
  y: number;
  w: number;
  h: number;
  minW?: number;
  minH?: number;
  maxW?: number;
  maxH?: number;
  /** When true for this breakpoint only, Auto Layout must not change w/h — only position. */
  sizeLocked?: boolean;
  /**
   * When true for this breakpoint/slot only, the widget is omitted from the live dashboard
   * for that device. Still visible (dimmed) in Edit Layout so it can be shown again.
   */
  hidden?: boolean;
  /**
   * Auto Layout priority for this breakpoint only — lower first.
   * Omitted cards pack after numbered ones. Not shared across device types.
   */
  order?: number;
}

export interface LayoutConfig {
  xxl?: GridItem[];
  xl?: GridItem[];
  lg: GridItem[];
  /** Tablet portrait (and legacy tablet layout). */
  md: GridItem[];
  /** Mobile portrait (and legacy mobile layout). */
  sm: GridItem[];
  /** Tablet landscape — falls back to `md` when empty. */
  mdLandscape?: GridItem[];
  /** Mobile landscape — falls back to `sm` when empty. */
  smLandscape?: GridItem[];
  /**
   * Per-device locks. When true for a breakpoint/slot, that saved placement is frozen:
   * drag/resize/auto-layout stay off until unlocked. View-mode Expand still applies
   * ephemeral height overrides (not written back to the saved layout).
   */
  locked?: Partial<
    Record<"xxl" | "xl" | "lg" | "md" | "sm" | "mdLandscape" | "smLandscape", boolean>
  >;
  /**
   * Column count each breakpoint was actually saved against, stamped on every
   * normalize pass. Lets the width-migration logic detect a *real* grid-cols
   * change instead of guessing from item spans (which misfires on any
   * intentionally-narrow card — see inferSourceCols in breakpoints.ts).
   */
  savedCols?: Partial<Record<"xxl" | "xl" | "lg" | "md" | "sm", number>>;
}

export type LayoutsByTab = Record<string, LayoutConfig>;

export type WidgetConfigFieldType =
  | "text"
  | "url"
  | "password"
  | "number"
  | "select"
  | "color"
  | "checkbox";

export interface WidgetConfigField {
  key: string;
  label: string;
  type?: WidgetConfigFieldType;
  placeholder?: string;
  required?: boolean;
  /** Static options for type "select". Dynamic options (e.g. bookmark groups) are filled by the UI. */
  options?: Array<{ value: string; label: string }>;
}

export interface WidgetManifest {
  id: string;
  name: string;
  description: string;
  version: string;
  defaultSize: { w: number; h: number; minW?: number; minH?: number };
  category?: string;
  hostClass?: string;
  configFields?: WidgetConfigField[];
}

export interface WidgetModule {
  manifest: WidgetManifest;
  /** Lazy-load the widget body; manifests stay sync for settings/add-widget. */
  load: () => Promise<{ default: ComponentType }>;
}
