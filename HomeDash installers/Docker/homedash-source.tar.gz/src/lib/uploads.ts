import { promises as fs } from "fs";
import path from "path";
import { getConfigDir } from "./config";
import { getIconsDir, iconPublicUrl, invalidateIconsCache } from "./icons-library";

export const MAX_UPLOAD_BYTES = 25 * 1024 * 1024;

export type UploadKind = "logo" | "favicon" | "background" | "widget-icon" | "profile-image";

const ALLOWED_MIME: Record<string, string[]> = {
  "image/png": [".png"],
  "image/jpeg": [".jpg", ".jpeg"],
  "image/webp": [".webp"],
  "image/gif": [".gif"],
  "image/svg+xml": [".svg"],
  "image/x-icon": [".ico"],
  "image/vnd.microsoft.icon": [".ico"],
  "image/ico": [".ico"],
};

const KIND_EXT_FALLBACK: Record<UploadKind, string> = {
  logo: ".png",
  favicon: ".ico",
  background: ".jpg",
  "widget-icon": ".png",
  "profile-image": ".png",
};

export async function getUploadsDir() {
  const dir = path.join(getConfigDir(), "uploads");
  await fs.mkdir(dir, { recursive: true });
  return dir;
}

export function isAllowedImage(mime: string, filename: string) {
  const lower = filename.toLowerCase();
  const exts = ALLOWED_MIME[mime];
  if (exts?.some((ext) => lower.endsWith(ext))) return true;
  if (!mime || mime === "application/octet-stream") {
    return Object.values(ALLOWED_MIME).flat().some((ext) => lower.endsWith(ext));
  }
  return false;
}

export function extensionForUpload(mime: string, filename: string, kind: UploadKind) {
  const lower = filename.toLowerCase();
  const fromName = Object.values(ALLOWED_MIME)
    .flat()
    .find((ext) => lower.endsWith(ext));
  if (fromName) return fromName;
  const fromMime = ALLOWED_MIME[mime]?.[0];
  return fromMime || KIND_EXT_FALLBACK[kind];
}

export function sanitizeUploadKey(key: string) {
  return key
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

export async function clearKindUploads(kind: UploadKind) {
  const dir = await getUploadsDir();
  const entries = await fs.readdir(dir);
  await Promise.all(
    entries
      .filter((name) => name === kind || name.startsWith(`${kind}.`))
      .map((name) => fs.unlink(path.join(dir, name)).catch(() => undefined)),
  );
}

/** Only clear the single static wallpaper file (background.ext), not gallery images. */
export async function clearPrimaryBackgroundUpload() {
  const dir = await getUploadsDir();
  const entries = await fs.readdir(dir);
  await Promise.all(
    entries
      .filter((name) => /^background\.[a-z0-9]+$/i.test(name))
      .map((name) => fs.unlink(path.join(dir, name)).catch(() => undefined)),
  );
}

async function uniqueBackgroundGalleryFilename(dir: string, ext: string) {
  const stamp = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
  let candidate = `background--${stamp}${ext}`;
  try {
    await fs.access(path.join(dir, candidate));
  } catch {
    return candidate;
  }
  return `background--${stamp}-${Math.random().toString(36).slice(2, 5)}${ext}`;
}

async function uniqueIconFilename(dir: string, base: string, ext: string) {
  let candidate = `widget-icon--${base}${ext}`;
  try {
    await fs.access(path.join(dir, candidate));
  } catch {
    return candidate;
  }
  return `${base}-${Date.now().toString(36)}${ext}`;
}

export async function saveUpload(
  kind: UploadKind,
  file: File,
  opts?: { key?: string; gallery?: boolean },
) {
  if (file.size > MAX_UPLOAD_BYTES) {
    throw new Error(`File exceeds the 25 MB limit (${(file.size / (1024 * 1024)).toFixed(1)} MB)`);
  }
  if (!isAllowedImage(file.type, file.name)) {
    throw new Error("Only image files are allowed (png, jpg, webp, gif, svg, ico)");
  }

  const ext = extensionForUpload(file.type, file.name, kind);
  const buffer = Buffer.from(await file.arrayBuffer());

  if (kind === "widget-icon") {
    const iconsDir = getIconsDir();
    await fs.mkdir(iconsDir, { recursive: true });

    const fromName = sanitizeUploadKey(path.parse(file.name).name);
    const fromKey = sanitizeUploadKey(opts?.key || "");
    const base = fromName || fromKey || `upload-${Date.now()}`;
    const filename = await uniqueIconFilename(iconsDir, base, ext);

    await fs.writeFile(path.join(iconsDir, filename), buffer, { mode: 0o644 });
    invalidateIconsCache();

    return {
      filename,
      url: iconPublicUrl(filename),
      size: file.size,
      mime: file.type || "application/octet-stream",
    };
  }

  const dir = await getUploadsDir();

  if (kind === "profile-image") {
    const key = sanitizeUploadKey(opts?.key || "");
    if (!key) throw new Error("Missing profile image owner");
    const entries = await fs.readdir(dir);
    await Promise.all(
      entries
        .filter((name) => name.startsWith(`profile-image--${key}.`))
        .map((name) => fs.unlink(path.join(dir, name)).catch(() => undefined)),
    );
    const filename = `profile-image--${key}${ext}`;
    await fs.writeFile(path.join(dir, filename), buffer);
    return {
      filename,
      url: `/api/uploads/${filename}`,
      size: file.size,
      mime: file.type || "application/octet-stream",
    };
  }

  if (kind === "background" && opts?.gallery) {
    const filename = await uniqueBackgroundGalleryFilename(dir, ext);
    await fs.writeFile(path.join(dir, filename), buffer);
    return {
      filename,
      url: `/api/uploads/${filename}`,
      size: file.size,
      mime: file.type || "application/octet-stream",
    };
  }

  const filename = `${kind}${ext}`;
  if (kind === "background") await clearPrimaryBackgroundUpload();
  else await clearKindUploads(kind);
  await fs.writeFile(path.join(dir, filename), buffer);

  return {
    filename,
    url: `/api/uploads/${filename}`,
    size: file.size,
    mime: file.type || "application/octet-stream",
  };
}

export async function deleteUploadByUrl(url: string) {
  const match = url.match(/\/api\/uploads\/([^/?#]+)/i);
  if (!match) return false;
  const name = safeUploadName(decodeURIComponent(match[1]));
  if (!name) return false;
  const dir = await getUploadsDir();
  await fs.unlink(path.join(dir, name)).catch(() => undefined);
  return true;
}

export function safeUploadName(name: string) {
  const base = path.basename(name);
  if (/^(logo|favicon|background)\.[a-z0-9]+$/i.test(base)) return base;
  if (/^background--[a-z0-9._-]+\.[a-z0-9]+$/i.test(base)) return base;
  if (/^widget-icon--[a-z0-9._-]+\.[a-z0-9]+$/i.test(base)) return base;
  if (/^profile-image--[a-z0-9._-]+\.[a-z0-9]+$/i.test(base)) return base;
  return null;
}

export function contentTypeForFilename(filename: string) {
  const lower = filename.toLowerCase();
  if (lower.endsWith(".png")) return "image/png";
  if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
  if (lower.endsWith(".webp")) return "image/webp";
  if (lower.endsWith(".gif")) return "image/gif";
  if (lower.endsWith(".svg")) return "image/svg+xml";
  if (lower.endsWith(".ico")) return "image/x-icon";
  return "application/octet-stream";
}
