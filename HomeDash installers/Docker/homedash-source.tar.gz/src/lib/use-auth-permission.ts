"use client";

import { useEffect, useState } from "react";

export function useAuthPermission(permission: string) {
  const [allowed, setAllowed] = useState(false);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/auth/me")
      .then((response) => response.json())
      .then((data) => {
        if (cancelled) return;
        const role = String(data.user?.role || "user");
        const permissions = Array.isArray(data.user?.permissions) ? data.user.permissions : [];
        setAllowed(role === "admin" || permissions.includes("*") || permissions.includes(permission));
      })
      .catch(() => {
        if (!cancelled) setAllowed(false);
      });
    return () => {
      cancelled = true;
    };
  }, [permission]);

  return allowed;
}
