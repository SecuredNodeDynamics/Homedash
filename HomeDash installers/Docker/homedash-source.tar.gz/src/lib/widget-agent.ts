import { promises as fs } from "fs";
import http from "http";
import path from "path";
import { getConfigDir } from "./config";

export type WidgetPackageRecord = {
  id: string;
  name: string;
  version: string;
  category: string;
  file: string;
  sha256: string;
  bytes: number;
  sourceFiles: number;
};

export type WidgetPackageIndex = {
  formatVersion: number;
  homedashVersion: string;
  packages: WidgetPackageRecord[];
};

export type WidgetAgentJob = {
  id: string;
  widgetId: string;
  widgetIds?: string[];
  operation?: "install" | "uninstall" | "system-update" | "cleanup";
  status: "queued" | "running" | "restarting" | "complete" | "failed";
  step: string;
  message: string;
  createdAt: string;
  updatedAt: string;
  log: string[];
  rolledBack?: boolean;
  scheduleId?: string;
};

export type CleanupScheduleOptions = {
  dockerImages: boolean;
  containersNetworks: boolean;
  dockerVolumes: boolean;
  packageCache: boolean;
  systemLogs: boolean;
};

export type CleanupSchedule = {
  id: string;
  enabled: boolean;
  frequency: "daily" | "weekly";
  /** 24-hour "HH:MM", evaluated in the host's local time. */
  time: string;
  /** 0 = Sunday .. 6 = Saturday. Only meaningful when frequency is "weekly". */
  dayOfWeek: number;
  options: CleanupScheduleOptions;
  logRetentionDays: number;
  createdAt: string;
  updatedAt: string;
  lastRunAt: string | null;
  lastJobId: string | null;
  nextRunAt: string;
};

/**
 * Compares two dotted version strings numerically (e.g. "0.1.10" > "0.1.2").
 * Falls back to 0 (equal) for any segment that isn't a plain integer, so
 * odd/custom version strings degrade to a straight string-equality check
 * instead of throwing.
 */
export function compareVersions(a: string, b: string): number {
  const partsA = a.split(".");
  const partsB = b.split(".");
  const length = Math.max(partsA.length, partsB.length);
  for (let i = 0; i < length; i += 1) {
    const numA = Number.parseInt(partsA[i] ?? "0", 10);
    const numB = Number.parseInt(partsB[i] ?? "0", 10);
    if (Number.isNaN(numA) || Number.isNaN(numB)) {
      return a === b ? 0 : a > b ? 1 : -1;
    }
    if (numA !== numB) return numA > numB ? 1 : -1;
  }
  return 0;
}

/** True only when `catalogVersion` is strictly newer than `installedVersion`. */
export function isNewerVersion(catalogVersion: string, installedVersion: string): boolean {
  return compareVersions(catalogVersion, installedVersion) > 0;
}

function agentSocket() {
  return process.env.HOMEDASH_WIDGET_AGENT_SOCKET || path.join(getConfigDir(), "agent", "widget-agent.sock");
}

async function agentToken() {
  return (await fs.readFile(path.join(getConfigDir(), "agent-token"), "utf8")).trim();
}

export async function readWidgetPackageIndex(): Promise<WidgetPackageIndex> {
  const candidates = [
    path.join(process.cwd(), "public", "widget-packages", "index.json"),
    path.join(process.cwd(), "widget-packages", "index.json"),
  ];
  for (const file of candidates) {
    try {
      return JSON.parse(await fs.readFile(file, "utf8")) as WidgetPackageIndex;
    } catch {
      // try next runtime layout
    }
  }
  return { formatVersion: 1, homedashVersion: "unknown", packages: [] };
}

export async function callWidgetAgent<T>(
  method: "GET" | "POST" | "PATCH" | "DELETE",
  requestPath: string,
  body?: unknown,
): Promise<T> {
  const token = await agentToken();
  const payload = body == null ? "" : JSON.stringify(body);
  return new Promise<T>((resolve, reject) => {
    const request = http.request(
      {
        socketPath: agentSocket(),
        path: requestPath,
        method,
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: "application/json",
          ...(payload
            ? {
                "Content-Type": "application/json",
                "Content-Length": Buffer.byteLength(payload),
              }
            : {}),
        },
        timeout: 8_000,
      },
      (response) => {
        const chunks: Buffer[] = [];
        response.on("data", (chunk) => chunks.push(Buffer.from(chunk)));
        response.on("end", () => {
          const raw = Buffer.concat(chunks).toString("utf8");
          let data: unknown = {};
          try {
            data = raw ? JSON.parse(raw) : {};
          } catch {
            reject(new Error("Widget agent returned invalid JSON"));
            return;
          }
          if ((response.statusCode || 500) >= 400) {
            const message =
              data && typeof data === "object" && "error" in data
                ? String((data as { error: unknown }).error)
                : `Widget agent HTTP ${response.statusCode}`;
            reject(new Error(message));
            return;
          }
          resolve(data as T);
        });
      },
    );
    request.on("timeout", () => request.destroy(new Error("Widget agent timed out")));
    request.on("error", reject);
    if (payload) request.write(payload);
    request.end();
  });
}

export type WidgetAgentDiskUsage = {
  path: string;
  total: number;
  used: number;
  free: number;
};

export async function widgetAgentHealth() {
  try {
    return await callWidgetAgent<{ ok: boolean; version: number }>("GET", "/health");
  } catch (error) {
    return {
      ok: false,
      version: 0,
      error: error instanceof Error ? error.message : "Widget agent unavailable",
    };
  }
}

export async function widgetAgentDiskUsage(): Promise<WidgetAgentDiskUsage | null> {
  try {
    return await callWidgetAgent<WidgetAgentDiskUsage>("GET", "/disk-usage");
  } catch {
    return null;
  }
}
