const CDN = "https://cdn.jsdelivr.net/gh/homarr-labs/dashboard-icons/webp";

/** Best-effort brand icons for settings / picker UI. */
const WIDGET_ICONS: Record<string, string> = {
  "adguard-control": `${CDN}/adguard-home.webp`,
  "ai-chat": `${CDN}/openai.webp`,
  audiobookshelf: `${CDN}/audiobookshelf.webp`,
  bazarr: `${CDN}/bazarr.webp`,
  bookorbit: `${CDN}/bookorbit.webp`,
  bookmarks: "/icons/pvy-bookmarks.png",
  checkmk: `${CDN}/checkmk.webp`,
  clock: "/icons/pvy-timer.png",
  cloudflare: `${CDN}/cloudflare.webp`,
  dispatcharr: `${CDN}/jellyfin.webp`,
  docker: "/icons/docker.png",
  downtify: "/icons/downtify.png",
  homeassistant: `${CDN}/homeassistant.webp`,
  "grocery-list": "/icons/our-shopping-list.png",
  immich: `${CDN}/immich.webp`,
  "invest-crypto": `${CDN}/bitcoin.webp`,
  "invest-news": `${CDN}/rss.webp`,
  "crypto-tracker": `${CDN}/bitcoin.webp`,
  "invest-stocks": `${CDN}/yahoo-finance.webp`,
  "jellyfin-slider": `${CDN}/jellyfin.webp`,
  "jf-monitor": `${CDN}/jellyfin.webp`,
  lidarr: `${CDN}/lidarr.webp`,
  mealie: `${CDN}/mealie.webp`,
  "media-calendar": "/icons/media-calendar.png",
  navidrome: `${CDN}/navidrome.webp`,
  "net-glances": `${CDN}/glances.webp`,
  "net-topology": `${CDN}/unifi.webp`,
  nextcloud: `${CDN}/nextcloud.webp`,
  notes: "/icons/pvy-notes.png",
  pihole: `${CDN}/pi-hole.webp`,
  plex: `${CDN}/plex.webp`,
  "plex-slider": `${CDN}/plex.webp`,
  prowlarr: `${CDN}/prowlarr.webp`,
  "proxmox-nodes": `${CDN}/proxmox.webp`,
  qbit: `${CDN}/qbittorrent.webp`,
  radarr: `${CDN}/radarr.webp`,
  seerr: `${CDN}/jellyseerr.webp`,
  shelfmark: `${CDN}/shelfmark.webp`,
  sonarr: `${CDN}/sonarr.webp`,
  speedtest: `${CDN}/speedtest-tracker.webp`,
  tailscale: `${CDN}/tailscale.webp`,
  tautulli: `${CDN}/tautulli.webp`,
  tdarr: `${CDN}/tdarr.webp`,
  todo: "/icons/todoist.png",
  tracearr: `${CDN}/tracearr.webp`,
  truenas: `${CDN}/truenas.webp`,
  "uk-monitor": `${CDN}/uptime-kuma.webp`,
  wazuh: `${CDN}/wazuh.webp`,
  wizarr: `${CDN}/wizarr.webp`,
  youtube: `${CDN}/youtube.webp`,
};

export function iconForWidget(widgetId: string): string | null {
  return WIDGET_ICONS[widgetId] || null;
}

export function resolveWidgetIcon(
  widgetId: string,
  customIcon?: string | null,
  packageCustomIcon?: string | null,
): string | null {
  const custom = customIcon?.trim() || packageCustomIcon?.trim();
  if (custom) return custom;
  return iconForWidget(widgetId);
}

export function dashboardIconUrl(slug: string) {
  const name = slug
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\/dashboardicons\.com\/icons\//, "")
    .replace(/\.(svg|png|webp)$/i, "")
    .replace(/[^a-z0-9-]+/g, "-")
    .replace(/^-+|-+$/g, "");
  if (!name) return "";
  return `https://cdn.jsdelivr.net/gh/homarr-labs/dashboard-icons/webp/${name}.webp`;
}

export function initialsForWidget(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "?";
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return `${parts[0][0] || ""}${parts[1][0] || ""}`.toUpperCase();
}
