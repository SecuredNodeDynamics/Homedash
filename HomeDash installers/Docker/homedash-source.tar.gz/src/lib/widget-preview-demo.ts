type DemoPayload = Record<string, unknown>;

const DEMO_URL = "https://demo.invalid";
const now = Math.floor(Date.now() / 1000);

const payloads: Record<string, DemoPayload> = {
  checkmk: {
    href: DEMO_URL,
    openFallbackUrl: DEMO_URL,
    hosts: { up: 4, down: 0, unreach: 0, unknown: 0, total: 4 },
    hostList: [
      { name: "Demo Gateway", state: 0, acknowledged: false, address: "[PRIVATE HOST]" },
      { name: "Demo Storage", state: 0, acknowledged: false, address: "[PRIVATE HOST]" },
      { name: "Demo Media", state: 0, acknowledged: false, address: "[PRIVATE HOST]" },
      { name: "Demo Automation", state: 0, acknowledged: false, address: "[PRIVATE HOST]" },
    ],
    problems: [
      {
        host: "Demo Storage",
        description: "Backup freshness",
        output: "Last demo snapshot exceeded the warning threshold",
        state: 1,
        acknowledged: false,
        changed: now - 1800,
      },
    ],
    summary: { warn: 1, crit: 0, unknown: 0 },
  },
  bazarr: {
    href: DEMO_URL,
    stats: [["Series", 18], ["Movies", 42], ["Missing", 3], ["Queued", 2]],
    items: [
      { title: "Aurora Station — S01E04", status: "English subtitles queued" },
      { title: "Signal Horizon", status: "Spanish subtitles downloaded" },
      { title: "The Last Archive", status: "Forced subtitles available" },
    ],
  },
  dispatcharr: {
    href: DEMO_URL,
    recordings: 14,
    channels: 86,
    active: 3,
    items: [
      { title: "Morning Technology Brief", meta: "Recording · 24 min remaining" },
      { title: "World News Live", meta: "Recording · Channel 12" },
      { title: "Science Tonight", meta: "Scheduled · 8:00 PM" },
    ],
  },
  lidarr: {
    href: DEMO_URL,
    artists: 126,
    albums: 842,
    tracks: 10648,
    queued: 4,
    upcoming: [
      { artist: "The Neon Atlas", title: "Signals at Dawn" },
      { artist: "Arctic Relay", title: "Parallel Skies" },
      { artist: "Solar Avenue", title: "Night Transit" },
    ],
  },
  "net-topology": {
    subnet: "Demo Service Network",
    hosts: [
      { name: "Media Core", role: "Streaming", ip: "[PRIVATE HOST]", localUrl: "#" },
      { name: "Storage Array", role: "NAS", ip: "[PRIVATE HOST]", localUrl: "#" },
      { name: "Automation", role: "Services", ip: "[PRIVATE HOST]", localUrl: "#", tunnelUrl: "#" },
      { name: "Home Control", role: "IoT", ip: "[PRIVATE HOST]", localUrl: "#" },
      { name: "Monitoring", role: "Observability", ip: "[PRIVATE HOST]", localUrl: "#", tunnelUrl: "#" },
      { name: "Security Hub", role: "Security", ip: "[PRIVATE HOST]", localUrl: "#" },
    ],
  },
  plex: {
    href: DEMO_URL,
    serverName: "Demo Media Server",
    streams: 2,
    totalItems: 4872,
    sessions: [
      { id: "demo-1", title: "Beyond the Signal", subtitle: "Episode 4", user: "Demo User", player: "Living Room", state: "playing", viewOffset: 1860000, duration: 3120000, progress: 60, transcode: false, type: "episode", artUrl: "" },
      { id: "demo-2", title: "Ocean of Stars", subtitle: "2026", user: "Guest Profile", player: "Web Player", state: "paused", viewOffset: 2940000, duration: 6480000, progress: 45, transcode: true, type: "movie", artUrl: "" },
    ],
    libraries: [
      { key: "1", title: "Movies", type: "movie", count: 1240 },
      { key: "2", title: "Television", type: "show", count: 3180 },
      { key: "3", title: "Music", type: "artist", count: 452 },
    ],
  },
  tautulli: {
    href: DEMO_URL,
    serverName: "Demo Media Analytics",
    streams: 2,
    transcodes: 1,
    direct_play: 1,
    users: 8,
    sessions: [
      { title: "Beyond the Signal", user: "Demo User", progress: 62, player: "Living Room", quality: "4K", bandwidth: 18200, transcode: "Direct Play", mediaType: "episode", state: "playing" },
      { title: "Ocean of Stars", user: "Guest Profile", progress: 41, player: "Web Player", quality: "1080p", bandwidth: 8200, transcode: "Transcode", mediaType: "movie", state: "paused" },
    ],
    libraries: [
      { name: "Movies", count: 1240, type: "movie" },
      { name: "Television", count: 3180, type: "show" },
      { name: "Music", count: 452, type: "artist" },
    ],
    history: [
      { title: "The Last Archive", user: "Demo User", date: now - 3600, mediaType: "movie" },
      { title: "Aurora Station", user: "Guest Profile", date: now - 7200, mediaType: "episode" },
    ],
  },
  tdarr: {
    href: DEMO_URL,
    files: 18420,
    queue: 7,
    errors: 1,
    transcoded: 16382,
    nodes: [
      { name: "Transcode Node Alpha", status: "Working · 68 FPS", paused: false },
      { name: "Transcode Node Beta", status: "Idle", paused: false },
      { name: "GPU Worker", status: "Working · 112 FPS", paused: false },
    ],
  },
  truenas: {
    href: DEMO_URL,
    system: { hostname: "DEMO-NAS", version: "25.10", uptime: 1587600, loadavg: [0.42, 0.38, 0.31] },
    pools: [
      { name: "media-pool", healthy: true, status: "ONLINE", used: 8600000000000, available: 5400000000000 },
      { name: "backup-pool", healthy: true, status: "ONLINE", used: 3200000000000, available: 8800000000000 },
    ],
    alerts: [{ level: "INFO", message: "Scheduled scrub completed successfully" }],
  },
};

const plexSections = {
  sections: [
    { key: "1", title: "Movies", type: "movie" },
    { key: "2", title: "Television", type: "show" },
    { key: "3", title: "Music", type: "artist" },
  ],
  baseUrl: DEMO_URL,
  publicUrl: DEMO_URL,
};

const plexItems = {
  items: [
    { key: "a", ratingKey: "a", type: "movie", title: "Beyond the Signal", subtitle: "Science Fiction", year: "2026", summary: "A demo media entry.", thumb: "", art: "", duration: 6840000, sectionTitle: "Movies", sectionType: "movie", addedAt: now },
    { key: "b", ratingKey: "b", type: "movie", title: "Ocean of Stars", subtitle: "Adventure", year: "2025", summary: "A demo media entry.", thumb: "", art: "", duration: 6420000, sectionTitle: "Movies", sectionType: "movie", addedAt: now - 100 },
    { key: "c", ratingKey: "c", type: "show", title: "Aurora Station", subtitle: "Season 1", year: "2026", summary: "A demo television entry.", thumb: "", art: "", duration: 3120000, sectionTitle: "Television", sectionType: "show", addedAt: now - 200 },
    { key: "d", ratingKey: "d", type: "show", title: "The Last Archive", subtitle: "Season 3", year: "2024", summary: "A demo television entry.", thumb: "", art: "", duration: 2880000, sectionTitle: "Television", sectionType: "show", addedAt: now - 300 },
    { key: "e", ratingKey: "e", type: "movie", title: "Parallel Skies", subtitle: "Drama", year: "2025", summary: "A demo media entry.", thumb: "", art: "", duration: 5940000, sectionTitle: "Movies", sectionType: "movie", addedAt: now - 400 },
  ],
  baseUrl: DEMO_URL,
  publicUrl: DEMO_URL,
};

function json(payload: unknown) {
  return new Response(JSON.stringify(payload), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });
}

export function installWidgetPreviewDemo(widgetId: string) {
  if (typeof window === "undefined") return;
  const state = window as Window & {
    __homedashPreviewFetch?: typeof fetch;
    __homedashPreviewWidget?: string;
  };
  if (!state.__homedashPreviewFetch) state.__homedashPreviewFetch = window.fetch.bind(window);
  if (state.__homedashPreviewWidget === widgetId) return;
  state.__homedashPreviewWidget = widgetId;
  const original = state.__homedashPreviewFetch;
  window.fetch = async (input, init) => {
    const url = new URL(typeof input === "string" ? input : input instanceof URL ? input.href : input.url, location.origin);
    if (widgetId === "plex-slider") {
      if (url.pathname.endsWith("/sections")) return json(plexSections);
      if (url.pathname.endsWith("/items") || url.pathname.endsWith("/search")) return json(plexItems);
    }
    const payload = payloads[widgetId];
    if (payload && url.pathname.includes(`/api/widgets/${widgetId}/status`)) return json(payload);
    return original(input, init);
  };
}
