import type { WidgetInstance } from "./types";

/** Multi-instance widgets whose chrome title is "{Name} - {PVE ID}". */
export const NODE_TITLE_WIDGETS: Record<string, { name: string; field: string }> = {
  speedtest: { name: "Speedtest", field: "nodeName" },
  "net-glances": { name: "Glances", field: "nodeName" },
};

export function isNodeTitleWidget(widgetId: string) {
  return Boolean(NODE_TITLE_WIDGETS[widgetId]);
}

/** Chrome / instance title: "Speedtest - PVE1" */
export function formatNodeWidgetTitle(widgetName: string, nodeName?: string | null) {
  const id = String(nodeName || "").trim();
  if (!id) return widgetName;
  return `${widgetName} - ${id}`;
}

export function resolveNodeWidgetTitle(widgetId: string, nodeName?: string | null) {
  const meta = NODE_TITLE_WIDGETS[widgetId];
  if (!meta) return String(nodeName || "").trim() || widgetId;
  return formatNodeWidgetTitle(meta.name, nodeName);
}

/** Apply Speedtest/Glances titles from in-memory widget configs (Settings form save path). */
export function withNodeTitlesFromConfigs<
  T extends {
    widgetInstances?: Array<{ id: string; widgetId: string; label: string; key: string }>;
  },
>(settings: T, configs: Record<string, Record<string, string>>): T {
  const instances = (settings.widgetInstances || []).map((inst) => {
    const meta = NODE_TITLE_WIDGETS[inst.widgetId];
    if (!meta) return inst;
    const nodeName = configs[inst.id]?.[meta.field];
    const label = formatNodeWidgetTitle(meta.name, nodeName);
    return inst.label === label ? inst : { ...inst, label };
  });
  return { ...settings, widgetInstances: instances as T["widgetInstances"] };
}

export function applyNodeTitleToInstance(
  inst: WidgetInstance,
  config: Record<string, string> | undefined,
): WidgetInstance {
  const meta = NODE_TITLE_WIDGETS[inst.widgetId];
  if (!meta) return inst;
  const label = formatNodeWidgetTitle(meta.name, config?.[meta.field]);
  return inst.label === label ? inst : { ...inst, label };
}
