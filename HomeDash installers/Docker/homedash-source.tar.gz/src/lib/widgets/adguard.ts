import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, hasConnectionUrl, openUrlsFromConfig, primaryConnectionUrl } from "@/lib/open-href";

export type AdguardConfig = {
  baseUrl: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  username?: string;
  password?: string;
};

type RequestResult = {
  data: Record<string, unknown>;
  base: string;
};

const activeBases = new Map<string, string>();

function apiRoot(url: string) {
  return String(url || "").replace(/\/$/, "");
}

function targets(instanceId: string, cfg: AdguardConfig) {
  const configured = connectionCandidates(cfg).map((url) => apiRoot(url));
  const active = activeBases.get(instanceId);
  return [...new Set(active ? [active, ...configured] : configured)];
}

function authHeaders(cfg: AdguardConfig, hasBody = false) {
  const headers: Record<string, string> = { Accept: "application/json" };
  if (cfg.username || cfg.password) {
    headers.Authorization = `Basic ${Buffer.from(
      `${cfg.username || ""}:${cfg.password || ""}`,
    ).toString("base64")}`;
  }
  if (hasBody) headers["Content-Type"] = "application/json";
  return headers;
}

export async function loadAdguardConfig(instanceId: string): Promise<AdguardConfig> {
  const cfg = await readWidgetConfig(instanceId);
  if (!hasConnectionUrl(cfg)) {
    throw new Error("Configure a Private - IP or Fallback Public URL in Settings");
  }
  return { ...cfg, baseUrl: primaryConnectionUrl(cfg) } as AdguardConfig;
}

async function requestAdguard(
  instanceId: string,
  cfg: AdguardConfig,
  path: string,
  options: RequestInit = {},
): Promise<RequestResult> {
  let lastError: Error | null = null;
  const hasBody = options.body !== undefined;

  for (const base of targets(instanceId, cfg)) {
    try {
      const response = await fetch(joinUrl(base, path), {
        ...options,
        headers: { ...authHeaders(cfg, hasBody), ...(options.headers || {}) },
        cache: "no-store",
        signal: AbortSignal.timeout(8000),
      });
      if (!response.ok) {
        const text = await response.text().catch(() => "");
        throw new Error(text || `AdGuard HTTP ${response.status}`);
      }

      const text = await response.text();
      let data: Record<string, unknown> = {};
      if (text.trim()) {
        try {
          data = JSON.parse(text) as Record<string, unknown>;
        } catch {
          // Some successful control endpoints intentionally return an empty body.
        }
      }
      activeBases.set(instanceId, base);
      return { data, base };
    } catch (error) {
      if (activeBases.get(instanceId) === base) activeBases.delete(instanceId);
      lastError = error instanceof Error ? error : new Error("AdGuard request failed");
    }
  }

  throw lastError || new Error("AdGuard is unreachable");
}

export type AdguardConnectionSource = "private" | "public" | "unknown";

export type AdguardStatus = {
  href: string;
  openFallbackUrl: string;
  protectionEnabled: boolean;
  safeBrowsingEnabled: boolean;
  parentalEnabled: boolean;
  queries: number;
  blocked: number;
  blockRate: number;
  averageRate: number;
  connectionSource: AdguardConnectionSource;
  topBlocked: TopEntry[];
  topClients: TopEntry[];
};

function classifyConnectionSource(cfg: AdguardConfig, base: string): AdguardConnectionSource {
  const normalized = apiRoot(base);
  if (cfg.baseUrl && apiRoot(cfg.baseUrl) === normalized) return "private";
  if (cfg.fallbackUrl && apiRoot(cfg.fallbackUrl) === normalized) return "public";
  return "unknown";
}

function numberValue(value: unknown) {
  const result = Number(value ?? 0);
  return Number.isFinite(result) ? result : 0;
}

export type TopEntry = { name: string; count: number };

function parseTopEntries(value: unknown, limit = 5): TopEntry[] {
  if (!Array.isArray(value)) return [];
  const entries: TopEntry[] = [];
  for (const row of value) {
    if (!row || typeof row !== "object") continue;
    for (const [name, count] of Object.entries(row as Record<string, unknown>)) {
      entries.push({ name, count: numberValue(count) });
    }
  }
  return entries.sort((a, b) => b.count - a.count).slice(0, limit);
}

export async function fetchAdguardStatus(instanceId: string): Promise<AdguardStatus> {
  const cfg = await loadAdguardConfig(instanceId);
  const status = await requestAdguard(instanceId, cfg, "/control/status");
  const emptyResult = (): RequestResult => ({ data: {}, base: status.base });
  const [stats, safeBrowsing, parental] = await Promise.all([
    requestAdguard(instanceId, cfg, "/control/stats").catch(emptyResult),
    requestAdguard(instanceId, cfg, "/control/safebrowsing/status").catch(emptyResult),
    requestAdguard(instanceId, cfg, "/control/parental/status").catch(emptyResult),
  ]);
  const queries = numberValue(stats.data.num_dns_queries);
  const blocked = numberValue(stats.data.num_blocked_filtering);

  const { href, openFallbackUrl } = openUrlsFromConfig(cfg);

  return {
    href: href || status.base,
    openFallbackUrl,
    protectionEnabled: Boolean(status.data.protection_enabled),
    safeBrowsingEnabled: Boolean(safeBrowsing.data.enabled),
    parentalEnabled: Boolean(parental.data.enabled),
    queries,
    blocked,
    blockRate: queries ? (blocked / queries) * 100 : 0,
    averageRate: queries / 86_400,
    connectionSource: classifyConnectionSource(cfg, status.base),
    topBlocked: parseTopEntries(stats.data.top_blocked_domains),
    topClients: parseTopEntries(stats.data.top_clients),
  };
}

export type AdguardToggle = "filtering" | "safebrowsing" | "parental";

export async function setAdguardToggle(
  instanceId: string,
  toggle: AdguardToggle,
  enabled: boolean,
  duration = 0,
) {
  const cfg = await loadAdguardConfig(instanceId);
  if (toggle === "filtering") {
    return requestAdguard(instanceId, cfg, "/control/protection", {
      method: "POST",
      body: JSON.stringify({ enabled, ...(!enabled && duration > 0 ? { duration } : {}) }),
    });
  }

  const path =
    toggle === "safebrowsing"
      ? enabled
        ? "/control/safebrowsing/enable"
        : "/control/safebrowsing/disable"
      : enabled
        ? "/control/parental/enable"
        : "/control/parental/disable";
  return requestAdguard(instanceId, cfg, path, { method: "POST" });
}
