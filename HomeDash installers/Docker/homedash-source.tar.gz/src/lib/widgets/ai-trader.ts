export type TraderStrategy = "sma" | "rsi" | "momentum";
export type TraderSide = "buy" | "sell";

export type BacktestInput = {
  prices: number[];
  strategy: TraderStrategy;
  capital: number;
  feePct: number;
  stopLossPct: number;
  takeProfitPct: number;
  fast: number;
  slow: number;
  period: number;
  buyThreshold: number;
  sellThreshold: number;
};

export type PaperTrade = {
  index: number;
  side: TraderSide;
  price: number;
  quantity: number;
  value: number;
  reason: string;
  pnl?: number;
};

export type BacktestResult = {
  strategy: TraderStrategy;
  params: Pick<BacktestInput, "fast" | "slow" | "period" | "buyThreshold" | "sellThreshold">;
  initialCapital: number;
  finalEquity: number;
  returnPct: number;
  benchmarkPct: number;
  maxDrawdownPct: number;
  sharpe: number;
  winRatePct: number;
  profitFactor: number;
  trades: PaperTrade[];
  equity: number[];
  prices: number[];
  score: number;
};

function average(values: number[]) {
  return values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0;
}

function sma(prices: number[], index: number, period: number) {
  if (index + 1 < period) return null;
  return average(prices.slice(index + 1 - period, index + 1));
}

function rsi(prices: number[], index: number, period: number) {
  if (index < period) return null;
  let gains = 0;
  let losses = 0;
  for (let cursor = index + 1 - period; cursor <= index; cursor += 1) {
    const change = prices[cursor] - prices[cursor - 1];
    if (change >= 0) gains += change;
    else losses -= change;
  }
  if (losses === 0) return 100;
  const ratio = (gains / period) / (losses / period);
  return 100 - (100 / (1 + ratio));
}

function signal(input: BacktestInput, index: number): "buy" | "sell" | "hold" {
  const { prices } = input;
  if (input.strategy === "sma") {
    const fastNow = sma(prices, index, input.fast);
    const slowNow = sma(prices, index, input.slow);
    const fastBefore = sma(prices, index - 1, input.fast);
    const slowBefore = sma(prices, index - 1, input.slow);
    if ([fastNow, slowNow, fastBefore, slowBefore].some((value) => value == null)) return "hold";
    if (fastBefore! <= slowBefore! && fastNow! > slowNow!) return "buy";
    if (fastBefore! >= slowBefore! && fastNow! < slowNow!) return "sell";
    return "hold";
  }
  if (input.strategy === "rsi") {
    const value = rsi(prices, index, input.period);
    if (value == null) return "hold";
    if (value <= input.buyThreshold) return "buy";
    if (value >= input.sellThreshold) return "sell";
    return "hold";
  }
  if (index < input.period) return "hold";
  const momentum = ((prices[index] / prices[index - input.period]) - 1) * 100;
  if (momentum >= input.buyThreshold) return "buy";
  if (momentum <= input.sellThreshold) return "sell";
  return "hold";
}

export function runBacktest(raw: BacktestInput): BacktestResult {
  const prices = raw.prices.filter((price) => Number.isFinite(price) && price > 0).slice(-4000);
  if (prices.length < 12) throw new Error("Not enough historical data for this strategy");
  const input: BacktestInput = {
    ...raw,
    prices,
    capital: Math.max(100, raw.capital || 10_000),
    feePct: Math.max(0, Math.min(5, raw.feePct || 0)),
    stopLossPct: Math.max(0, Math.min(90, raw.stopLossPct || 0)),
    takeProfitPct: Math.max(0, Math.min(500, raw.takeProfitPct || 0)),
    fast: Math.max(2, Math.round(raw.fast || 5)),
    slow: Math.max(3, Math.round(raw.slow || 20)),
    period: Math.max(2, Math.round(raw.period || 14)),
  };
  if (input.fast >= input.slow) input.fast = Math.max(2, input.slow - 1);

  let cash = input.capital;
  let quantity = 0;
  let entryPrice = 0;
  let entryCost = 0;
  let peak = input.capital;
  let maxDrawdown = 0;
  const trades: PaperTrade[] = [];
  const equity: number[] = [];
  const completedPnls: number[] = [];

  const buy = (index: number, price: number, reason: string) => {
    if (quantity > 0 || cash <= 0) return;
    const feeRate = input.feePct / 100;
    quantity = cash / (price * (1 + feeRate));
    const value = quantity * price;
    const fee = value * feeRate;
    entryPrice = price;
    entryCost = value + fee;
    cash = Math.max(0, cash - entryCost);
    trades.push({ index, side: "buy", price, quantity, value, reason });
  };
  const sell = (index: number, price: number, reason: string) => {
    if (quantity <= 0) return;
    const value = quantity * price;
    const proceeds = value * (1 - input.feePct / 100);
    const pnl = proceeds - entryCost;
    cash += proceeds;
    trades.push({ index, side: "sell", price, quantity, value, reason, pnl });
    completedPnls.push(pnl);
    quantity = 0;
    entryPrice = 0;
    entryCost = 0;
  };

  prices.forEach((price, index) => {
    if (quantity > 0 && input.stopLossPct > 0 && price <= entryPrice * (1 - input.stopLossPct / 100)) {
      sell(index, price, "Stop loss");
    } else if (quantity > 0 && input.takeProfitPct > 0 && price >= entryPrice * (1 + input.takeProfitPct / 100)) {
      sell(index, price, "Take profit");
    } else {
      const next = signal(input, index);
      if (next === "buy") buy(index, price, `${input.strategy.toUpperCase()} entry`);
      if (next === "sell") sell(index, price, `${input.strategy.toUpperCase()} exit`);
    }
    const value = cash + quantity * price;
    equity.push(value);
    peak = Math.max(peak, value);
    maxDrawdown = Math.max(maxDrawdown, peak > 0 ? ((peak - value) / peak) * 100 : 0);
  });
  if (quantity > 0) sell(prices.length - 1, prices.at(-1)!, "End of test");
  equity[equity.length - 1] = cash;

  const returns = equity.slice(1).map((value, index) =>
    equity[index] ? (value / equity[index]) - 1 : 0);
  const mean = average(returns);
  const variance = average(returns.map((value) => (value - mean) ** 2));
  const deviation = Math.sqrt(variance);
  const sharpe = deviation > 0 ? (mean / deviation) * Math.sqrt(Math.min(365, prices.length)) : 0;
  const wins = completedPnls.filter((pnl) => pnl > 0);
  const losses = completedPnls.filter((pnl) => pnl < 0);
  const grossWin = wins.reduce((sum, pnl) => sum + pnl, 0);
  const grossLoss = Math.abs(losses.reduce((sum, pnl) => sum + pnl, 0));
  const returnPct = ((cash / input.capital) - 1) * 100;
  const benchmarkPct = ((prices.at(-1)! / prices[0]) - 1) * 100;
  const profitFactor = grossLoss > 0 ? grossWin / grossLoss : grossWin > 0 ? 99 : 0;
  const score = returnPct - maxDrawdown * 0.55 + Math.max(-3, Math.min(3, sharpe)) * 3;

  return {
    strategy: input.strategy,
    params: {
      fast: input.fast,
      slow: input.slow,
      period: input.period,
      buyThreshold: input.buyThreshold,
      sellThreshold: input.sellThreshold,
    },
    initialCapital: input.capital,
    finalEquity: cash,
    returnPct,
    benchmarkPct,
    maxDrawdownPct: maxDrawdown,
    sharpe,
    winRatePct: completedPnls.length ? (wins.length / completedPnls.length) * 100 : 0,
    profitFactor,
    trades,
    equity,
    prices,
    score,
  };
}

export function optimizeBacktest(input: BacktestInput) {
  const candidates: BacktestInput[] = [];
  if (input.strategy === "sma") {
    for (const fast of [3, 5, 8, 10, 12]) {
      for (const slow of [15, 20, 30, 40, 50]) {
        if (fast < slow) candidates.push({ ...input, fast, slow });
      }
    }
  } else if (input.strategy === "rsi") {
    for (const period of [7, 10, 14, 18, 21]) {
      for (const buyThreshold of [20, 25, 30, 35]) {
        candidates.push({ ...input, period, buyThreshold, sellThreshold: 100 - buyThreshold });
      }
    }
  } else {
    for (const period of [3, 5, 7, 10, 14, 21]) {
      for (const buyThreshold of [0.5, 1, 2, 3, 5]) {
        candidates.push({ ...input, period, buyThreshold, sellThreshold: -buyThreshold });
      }
    }
  }
  return candidates
    .map(runBacktest)
    .sort((a, b) => b.score - a.score)
    .slice(0, 5);
}
