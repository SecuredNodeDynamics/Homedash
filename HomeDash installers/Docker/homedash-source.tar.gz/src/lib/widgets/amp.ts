import { readWidgetConfig } from "@/lib/config";
import { connectionCandidates, openUrlsFromConfig } from "@/lib/open-href";

type Config = {
  baseUrl?: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  username?: string;
  password?: string;
  twoFactorToken?: string;
};

type RawMetric = { RawValue?: number; MaxValue?: number; Percent?: number; Units?: string };
type RawInstance = {
  InstanceID?: string;
  InstanceName?: string;
  FriendlyName?: string;
  Description?: string;
  Module?: string;
  ModuleDisplayName?: string;
  Running?: boolean;
  AppState?: number;
  IP?: string;
  Port?: number;
  IsHTTPS?: boolean;
  DiskUsageMB?: number;
  Metrics?: Record<string, RawMetric>;
  DisplayImageSource?: string;
  Tags?: string[];
};
type RawTarget = { AvailableInstances?: RawInstance[] };
type RawInstanceStatus = { InstanceID?: string; Running?: boolean };

export type AmpServer = {
  id: string;
  instanceName: string;
  name: string;
  description: string;
  game: string;
  running: boolean;
  state: number;
  stateLabel: string;
  address: string;
  port: number;
  https: boolean;
  diskMB: number;
  metrics: Array<{ name: string; value: number; max: number; percent: number; units: string }>;
  image: string;
  directUrl: string;
};

const STATES: Record<number, string> = {
  [-1]: "Undefined", 0: "Stopped", 5: "Pre-start", 7: "Configuring", 10: "Starting",
  20: "Ready", 30: "Restarting", 40: "Stopping", 45: "Preparing for sleep",
  50: "Sleeping", 60: "Waiting", 70: "Installing", 75: "Updating",
  80: "Awaiting input", 100: "Failed", 200: "Suspended", 250: "Maintenance",
  999: "Unknown",
};

function cleanBase(value: string) {
  return value.trim().replace(/\/+$/, "");
}

function resolveDisplayImageSource(source: unknown, base: string) {
  const value = String(source || "").trim();
  if (!value || value.toLowerCase() === "none:") return "";
  const steam = /^steam:(\d+)$/i.exec(value);
  if (steam) {
    return `https://cdn.akamai.steamstatic.com/steam/apps/${steam[1]}/header.jpg`;
  }
  const explicitUrl = /^url:(.+)$/i.exec(value);
  const candidate = explicitUrl ? explicitUrl[1].trim() : value;
  if (candidate.startsWith("data:")) return candidate;
  try {
    return new URL(candidate, `${cleanBase(base)}/`).toString();
  } catch {
    return "";
  }
}

async function ampPost<T>(base: string, endpoint: string, body: Record<string, unknown>) {
  const response = await fetch(`${cleanBase(base)}/API/${endpoint}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify(body),
    cache: "no-store",
    signal: AbortSignal.timeout(12_000),
  });
  const text = await response.text();
  let data: unknown;
  try { data = text ? JSON.parse(text) : {}; } catch { throw new Error(`AMP returned invalid JSON (${response.status})`); }
  if (!response.ok) throw new Error(`AMP HTTP ${response.status}`);
  if (data && typeof data === "object" && "Title" in data && "Message" in data) {
    throw new Error(String((data as { Message?: unknown }).Message || "AMP API error"));
  }
  return data as T;
}

async function ampAction(base: string, endpoint: string, body: Record<string, unknown>) {
  const result = await ampPost<Record<string, unknown>>(base, endpoint, body);
  if (result?.Status === false) {
    throw new Error(String(result.Reason || `AMP rejected ${endpoint.split("/").pop() || "the action"}`));
  }
  return result;
}

const ampSessions = new Map<string, { sessionId: string; expiresAt: number }>();

async function login(base: string, config: Config) {
  const cacheKey = `${cleanBase(base)}|${config.username || ""}`;
  const cached = ampSessions.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) return cached.sessionId;
  const result = await ampPost<{
    success?: boolean;
    sessionID?: string;
    resultReason?: string;
  }>(base, "Core/Login", {
    username: config.username || "",
    password: config.password || "",
    token: config.twoFactorToken || "",
    rememberMe: true,
  });
  if (!result.success || !result.sessionID) {
    throw new Error(result.resultReason || "AMP login failed");
  }
  ampSessions.set(cacheKey, {
    sessionId: result.sessionID,
    expiresAt: Date.now() + 4 * 60_000,
  });
  return result.sessionID;
}

async function connect(instanceId: string) {
  const config = (await readWidgetConfig(instanceId)) as Config;
  if (!config.username?.trim() || !config.password) throw new Error("Configure AMP username and password");
  const candidates = connectionCandidates(config);
  if (!candidates.length) throw new Error("Configure an AMP controller URL");
  let last: unknown;
  for (const base of candidates) {
    try {
      return { config, base, sessionId: await login(base, config) };
    } catch (error) { last = error; }
  }
  throw last instanceof Error ? last : new Error("AMP unavailable");
}

function mapServer(raw: RawInstance, base: string): AmpServer {
  const metrics = Object.entries(raw.Metrics || {}).map(([name, metric]) => ({
    name,
    value: Number(metric.RawValue) || 0,
    max: Number(metric.MaxValue) || 0,
    percent: Math.max(0, Math.min(100, Number(metric.Percent) || 0)),
    units: String(metric.Units || ""),
  }));
  const state = Number(raw.AppState);
  const image = resolveDisplayImageSource(raw.DisplayImageSource, base);
  const controller = new URL(base);
  const directHost = raw.IP && !["0.0.0.0", "::", "127.0.0.1", "localhost"].includes(raw.IP)
    ? raw.IP
    : controller.hostname;
  const directUrl = raw.Port
    ? `${raw.IsHTTPS ? "https" : "http"}://${directHost}:${raw.Port}/`
    : "";
  return {
    id: String(raw.InstanceID || raw.InstanceName || ""),
    instanceName: String(raw.InstanceName || ""),
    name: String(raw.FriendlyName || raw.InstanceName || "Game server"),
    description: String(raw.Description || ""),
    game: String(raw.ModuleDisplayName || raw.Module || "Game server"),
    running: Boolean(raw.Running),
    state: Number.isFinite(state) ? state : 999,
    stateLabel: STATES[state] || "Unknown",
    address: String(raw.IP || ""),
    port: Number(raw.Port) || 0,
    https: Boolean(raw.IsHTTPS),
    diskMB: Number(raw.DiskUsageMB) || 0,
    metrics,
    image,
    directUrl,
  };
}

function isGameInstance(raw: RawInstance) {
  const module = String(raw.Module || "").trim().toLowerCase();
  const moduleName = String(raw.ModuleDisplayName || "").trim().toLowerCase();
  return module !== "ads"
    && module !== "amp"
    && !moduleName.includes("application deployment service")
    && !moduleName.includes("instance manager")
    && !moduleName.includes("amp controller");
}

export async function fetchAmpStatus(instanceId = "amp") {
  const { config, base, sessionId } = await connect(instanceId);
  const [targets, liveStatuses] = await Promise.all([
    ampPost<RawTarget[]>(base, "ADSModule/GetInstances", {
      SESSIONID: sessionId,
      ForceIncludeSelf: false,
    }),
    ampPost<RawInstanceStatus[]>(base, "ADSModule/GetInstanceStatuses", {
      SESSIONID: sessionId,
    }).catch(() => []),
  ]);
  const liveById = new Map(
    (Array.isArray(liveStatuses) ? liveStatuses : [])
      .filter((status) => status.InstanceID)
      .map((status) => [String(status.InstanceID).toLowerCase(), Boolean(status.Running)]),
  );
  const servers = (Array.isArray(targets) ? targets : [])
    .flatMap((target) => target.AvailableInstances || [])
    .filter((entry) => entry.InstanceName && isGameInstance(entry))
    .map((entry) => {
      const liveRunning = liveById.get(String(entry.InstanceID || "").toLowerCase());
      if (liveRunning === undefined) return entry;
      return {
        ...entry,
        Running: liveRunning,
        AppState: liveRunning
          ? (Number(entry.AppState) === 0 ? 20 : entry.AppState)
          : 0,
      };
    })
    .map((server) => mapServer(server, base))
    .map((server) => ({
      ...server,
      image: server.image
        ? `/api/widgets/amp/image?instance=${encodeURIComponent(instanceId)}&server=${encodeURIComponent(server.instanceName)}`
        : "",
    }))
    .sort((a, b) => Number(b.running) - Number(a.running) || a.name.localeCompare(b.name));
  const urls = openUrlsFromConfig(config);
  return {
    href: urls.href || base,
    openFallbackUrl: urls.openFallbackUrl,
    servers,
    summary: {
      total: servers.length,
      running: servers.filter((server) => server.running).length,
      stopped: servers.filter((server) => !server.running).length,
    },
  };
}

export async function fetchAmpImage(instanceId: string, instanceName: string) {
  const { base, sessionId } = await connect(instanceId);
  const targets = await ampPost<RawTarget[]>(base, "ADSModule/GetInstances", {
    SESSIONID: sessionId,
    ForceIncludeSelf: false,
  });
  const raw = targets
    .flatMap((target) => target.AvailableInstances || [])
    .find((entry) => entry.InstanceName === instanceName);
  const source = resolveDisplayImageSource(raw?.DisplayImageSource, base);
  if (!source) throw new Error("AMP instance has no cover image");

  if (source.startsWith("data:")) {
    const match = /^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/.exec(source);
    if (!match) throw new Error("AMP returned an invalid cover image");
    return { bytes: Buffer.from(match[2], "base64"), contentType: match[1] };
  }

  const imageUrl = new URL(source, `${cleanBase(base)}/`);
  const candidates = [imageUrl];
  if (!imageUrl.searchParams.has("SESSIONID")) {
    const authenticated = new URL(imageUrl);
    authenticated.searchParams.set("SESSIONID", sessionId);
    candidates.push(authenticated);
  }

  let lastStatus = 0;
  for (const url of candidates) {
    const response = await fetch(url, {
      headers: {
        Accept: "image/*",
        Cookie: `sessionID=${sessionId}; SESSIONID=${sessionId}`,
      },
      cache: "no-store",
      signal: AbortSignal.timeout(12_000),
    });
    lastStatus = response.status;
    const contentType = response.headers.get("content-type")?.split(";")[0].trim() || "";
    if (response.ok && contentType.startsWith("image/")) {
      return {
        bytes: Buffer.from(await response.arrayBuffer()),
        contentType,
      };
    }
  }
  throw new Error(`AMP cover image unavailable${lastStatus ? ` (${lastStatus})` : ""}`);
}

export async function controlAmpInstance(
  instanceId: string,
  instanceName: string,
  action: "start" | "stop" | "restart" | "kill" | "update" | "manage",
  serverId = "",
) {
  const { config, base, sessionId } = await connect(instanceId);
  if (action === "update") {
    return ampAction(base, "ADSModule/UpgradeInstance", {
      SESSIONID: sessionId,
      InstanceName: instanceName,
    });
  }
  if (action === "manage") {
    if (!serverId) throw new Error("AMP did not provide an instance ID");
    return ampAction(base, "ADSModule/ManageInstance", {
      SESSIONID: sessionId,
      InstanceId: serverId,
    });
  }
  if (action !== "kill") {
    const method = action === "start" ? "StartInstance" : action === "stop" ? "StopInstance" : "RestartInstance";
    return ampAction(base, `ADSModule/${method}`, { SESSIONID: sessionId, InstanceName: instanceName });
  }

  const targets = await ampPost<RawTarget[]>(base, "ADSModule/GetInstances", {
    SESSIONID: sessionId,
    ForceIncludeSelf: false,
  });
  const raw = targets.flatMap((target) => target.AvailableInstances || [])
    .find((entry) => entry.InstanceName === instanceName);
  if (!raw?.Port) throw new Error("AMP did not provide an endpoint for this instance");
  const controller = new URL(base);
  const directBase = `${raw.IsHTTPS ? "https" : "http"}://${controller.hostname}:${raw.Port}`;
  const directSession = await login(directBase, config);
  return ampAction(directBase, "Core/Kill", { SESSIONID: directSession });
}
