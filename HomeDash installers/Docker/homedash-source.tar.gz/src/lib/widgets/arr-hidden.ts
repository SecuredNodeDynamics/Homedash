import { promises as fs } from "fs";
import path from "path";

/**
 * Persistent "hidden from Missing" list for the Radarr/Sonarr widgets.
 * Stored as JSON on the Homedash server so it survives reloads, restarts,
 * rebuilds (when the data dir is a volume) and is shared across devices.
 */
export type HiddenEntry = { id: string; title: string; at: number };

type Store = Record<string, HiddenEntry[]>;

function storePath(kind: string) {
  const dir = process.env.HOMEDASH_DATA_DIR || path.join(process.cwd(), "data");
  return path.join(dir, "widgets", `${kind.replace(/[^a-z0-9_-]/gi, "")}-hidden-missing.json`);
}

async function readStore(kind: string): Promise<Store> {
  try {
    const raw = await fs.readFile(storePath(kind), "utf8");
    const parsed = JSON.parse(raw) as unknown;
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? (parsed as Store) : {};
  } catch {
    return {};
  }
}

async function writeStore(kind: string, store: Store) {
  const file = storePath(kind);
  await fs.mkdir(path.dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(store, null, 2), "utf8");
  await fs.rename(tmp, file);
}

export async function listHidden(kind: string, instance: string): Promise<HiddenEntry[]> {
  const store = await readStore(kind);
  return Array.isArray(store[instance]) ? store[instance] : [];
}

export async function setHidden(
  kind: string,
  instance: string,
  id: string,
  title: string,
  hidden: boolean,
): Promise<HiddenEntry[]> {
  const store = await readStore(kind);
  const current = (Array.isArray(store[instance]) ? store[instance] : []).filter((e) => e.id !== id);
  if (hidden) current.push({ id, title, at: Date.now() });
  store[instance] = current;
  await writeStore(kind, store);
  return current;
}
