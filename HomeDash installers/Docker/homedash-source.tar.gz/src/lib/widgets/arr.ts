import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, hasConnectionUrl, openUrlsFromConfig, primaryConnectionUrl } from "@/lib/open-href";
import { cachedStatus, invalidateStatusCache } from "@/lib/status-cache";

type Config = {
  baseUrl: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  apiKey: string;
  /** Raw, unmodified config values — kept alongside `baseUrl` (which gets
   *  overwritten with primaryConnectionUrl()'s pick below) so connection
   *  source classification always compares against what was actually
   *  configured, not whichever URL happened to be chosen as primary. */
  rawBaseUrl?: string;
  rawFallbackUrl?: string;
};

type ArrImage = { coverType?: string; url?: string; remoteUrl?: string };

type ArrQueueRecord = {
  id?: number;
  movieId?: number;
  seriesId?: number;
  title?: string;
  status?: string;
  trackedDownloadState?: string;
  trackedDownloadStatus?: string;
  size?: number;
  sizeleft?: number;
  timeleft?: string;
  errorMessage?: string;
  movie?: {
    id?: number;
    title?: string;
    titleSlug?: string;
    year?: number;
    images?: ArrImage[];
  };
  series?: {
    id?: number;
    title?: string;
    titleSlug?: string;
    year?: number;
    images?: ArrImage[];
  };
  episode?: {
    seasonNumber?: number;
    episodeNumber?: number;
    title?: string;
  };
};

export type ArrQueueItem = {
  id: string;
  title: string;
  meta: string;
  state: string;
  progress: number | null;
  poster: string;
  href: string;
  mediaId?: number;
  queueId?: number;
  monitored?: boolean;
};

async function config(id: string) {
  const value = (await readWidgetConfig(id)) as Partial<Config>;
  if (!hasConnectionUrl(value) || !value.apiKey) {
    throw new Error("Configure a Private - IP or Fallback Public URL, and API key in Settings");
  }
  return {
    ...value,
    baseUrl: primaryConnectionUrl(value),
    rawBaseUrl: value.baseUrl,
    rawFallbackUrl: value.fallbackUrl,
  } as Config;
}

async function request<T>(
  cfg: Config,
  path: string,
  init: RequestInit = {},
  meta?: { usedBase?: string },
): Promise<T> {
  let last: unknown;
  for (const base of connectionCandidates(cfg)) {
    try {
      const headers: Record<string, string> = {
        "X-Api-Key": cfg.apiKey,
        ...(init.body ? { "Content-Type": "application/json" } : {}),
        ...((init.headers as Record<string, string>) || {}),
      };
      const res = await fetch(joinUrl(base, path), {
        ...init,
        headers,
        cache: "no-store",
        signal: AbortSignal.timeout(15_000),
      });
      const text = await res.text();
      if (!res.ok) {
        let detail = "";
        try {
          const body = text ? JSON.parse(text) as unknown : null;
          if (Array.isArray(body)) {
            detail = body
              .map((item) => {
                if (!item || typeof item !== "object") return "";
                const record = item as Record<string, unknown>;
                return String(record.errorMessage || record.message || "");
              })
              .filter(Boolean)
              .join(" ");
          } else if (body && typeof body === "object") {
            const record = body as Record<string, unknown>;
            detail = String(record.errorMessage || record.message || record.error || "");
          }
        } catch {
          detail = text.trim();
        }
        throw new Error(detail || `HTTP ${res.status}`);
      }
      if (meta) meta.usedBase = base;
      if (!text) return null as T;
      try {
        return JSON.parse(text) as T;
      } catch {
        return text as T;
      }
    } catch (error) {
      last = error;
    }
  }
  throw last instanceof Error ? last : new Error("Service unavailable");
}

function classifyConnectionSource(usedBase: string | undefined, cfg: Config): "private" | "public" | "unknown" {
  const normalize = (url?: string | null) => (url ? url.replace(/\/+$/, "") : "");
  const target = normalize(usedBase);
  if (!target) return "unknown";
  // Compare against the raw config values, not `cfg.baseUrl` — by this point
  // `cfg.baseUrl` has already been overwritten with primaryConnectionUrl()'s
  // pick, which can silently substitute the wrong URL and mislabel a
  // successful private connection as "public" (or vice versa).
  if (target === normalize(cfg.rawBaseUrl)) return "private";
  if (target === normalize(cfg.rawFallbackUrl)) return "public";
  return "unknown";
}

function hrefFor(cfg: Config) {
  return (cfg.publicUrl || cfg.baseUrl).replace(/\/$/, "");
}

function pickPoster(images?: ArrImage[]) {
  if (!images?.length) return null;
  return images.find((image) => image.coverType === "poster") || images[0] || null;
}

function posterUrl(
  cfg: Config,
  instanceId: string,
  kind: "radarr" | "sonarr",
  images?: ArrImage[],
) {
  const poster = pickPoster(images);
  if (!poster) return "";
  if (poster.remoteUrl) return poster.remoteUrl;
  if (poster.url?.startsWith("http")) return poster.url;
  if (!poster.url) return "";
  const path = poster.url.split("?")[0];
  return `/api/widgets/${kind}/cover?instance=${encodeURIComponent(instanceId)}&path=${encodeURIComponent(path)}`;
}

function formatState(record: ArrQueueRecord) {
  const raw = (record.trackedDownloadState || record.status || "queued").replace(/_/g, " ");
  return raw.charAt(0).toUpperCase() + raw.slice(1);
}

function progressFor(record: ArrQueueRecord) {
  const size = Number(record.size || 0);
  const left = Number(record.sizeleft ?? NaN);
  if (!(size > 0) || !Number.isFinite(left)) return null;
  return Math.max(0, Math.min(100, Math.round(((size - left) / size) * 100)));
}

function mapQueueItems(
  cfg: Config,
  instanceId: string,
  kind: "radarr" | "sonarr",
  records: ArrQueueRecord[],
  slugById?: Map<number, string>,
) {
  const items: ArrQueueItem[] = [];
  const seen = new Set<string>();

  for (const record of records) {
    const movie = record.movie;
    const series = record.series;
    const dedupeKey =
      kind === "radarr"
        ? `movie:${movie?.id || record.movieId || record.id || record.title}`
        : `series:${series?.id || record.seriesId || record.id || record.title}`;
    if (seen.has(dedupeKey)) continue;
    seen.add(dedupeKey);

    const title =
      (kind === "radarr" ? movie?.title : series?.title) ||
      record.title ||
      (kind === "radarr" ? "Movie" : "Series");
    const year = kind === "radarr" ? movie?.year : series?.year;
    const ep = record.episode;
    const epBit =
      ep && ep.seasonNumber != null && ep.episodeNumber != null
        ? `S${String(ep.seasonNumber).padStart(2, "0")}E${String(ep.episodeNumber).padStart(2, "0")}`
        : "";
    const progress = progressFor(record);
    const state = formatState(record);
    const metaBits = [
      year ? String(year) : "",
      epBit,
      progress != null
        ? `${progress}%`
        : record.timeleft && record.timeleft !== "00:00:00"
          ? record.timeleft
          : "",
      state,
    ].filter(Boolean);

    const mediaId = kind === "radarr" ? movie?.id || record.movieId : series?.id || record.seriesId;
    const href =
      kind === "radarr"
        ? mediaHref(cfg, kind, movie, record.movieId || mediaId, slugById)
        : mediaHref(cfg, kind, series, record.seriesId || mediaId, slugById);

    items.push({
      id: dedupeKey,
      title,
      meta: metaBits.join(" · "),
      state,
      progress,
      poster: posterUrl(cfg, instanceId, kind, kind === "radarr" ? movie?.images : series?.images),
      href,
      mediaId: Number(mediaId || 0) || undefined,
      queueId: Number(record.id || 0) || undefined,
    });

    if (items.length >= 12) break;
  }

  return items;
}

type ArrMissingRecord = {
  id?: number;
  title?: string;
  titleSlug?: string;
  year?: number;
  images?: ArrImage[];
  seriesId?: number;
  seasonNumber?: number;
  episodeNumber?: number;
  airDateUtc?: string;
  series?: {
    id?: number;
    title?: string;
    titleSlug?: string;
    year?: number;
    images?: ArrImage[];
  };
};

type ArrLibraryRecord = {
  id?: number;
  title?: string;
  titleSlug?: string;
  year?: number;
  monitored?: boolean;
  images?: ArrImage[];
  statistics?: {
    episodeFileCount?: number;
    episodeCount?: number;
    totalEpisodeCount?: number;
    percentOfEpisodes?: number;
  };
};

/** Radarr/Sonarr UI routes use titleSlug (`/movie/foo-123`), not numeric ids. */
function mediaHref(
  cfg: Config,
  kind: "radarr" | "sonarr",
  media?: { titleSlug?: string; id?: number } | null,
  fallbackId?: number,
  slugById?: Map<number, string>,
) {
  const base = hrefFor(cfg);
  const segment = kind === "radarr" ? "movie" : "series";
  const id = media?.id || fallbackId;
  const slug =
    media?.titleSlug?.trim() ||
    (id && slugById?.get(id)) ||
    "";
  if (slug) return `${base}/${segment}/${slug}`;
  if (id) return `${base}/${segment}/${id}`;
  return base;
}

function mapMissingItems(
  cfg: Config,
  instanceId: string,
  kind: "radarr" | "sonarr",
  records: ArrMissingRecord[],
  slugById?: Map<number, string>,
) {
  const items: ArrQueueItem[] = [];
  const seen = new Set<string>();

  for (const record of records) {
    if (kind === "radarr") {
      const dedupeKey = `missing-movie:${record.id || record.title}`;
      if (seen.has(dedupeKey)) continue;
      seen.add(dedupeKey);
      const title = record.title || "Movie";
      const year = record.year ? String(record.year) : "";
      items.push({
        id: dedupeKey,
        title,
        meta: [year, "Missing"].filter(Boolean).join(" · "),
        state: "Missing",
        progress: null,
        poster: posterUrl(cfg, instanceId, kind, record.images),
        href: mediaHref(cfg, kind, record, record.id, slugById),
      });
    } else {
      const series = record.series;
      const seriesId = series?.id || record.seriesId;
      const dedupeKey = `missing-series:${seriesId || series?.title || record.id}`;
      const existing = items.find((item) => item.id === dedupeKey);
      if (existing) {
        const count = Number(existing.meta.match(/(\d+)\s+missing/i)?.[1] || 1) + 1;
        existing.meta = [series?.year ? String(series.year) : "", `${count} missing`]
          .filter(Boolean)
          .join(" · ");
        continue;
      }
      seen.add(dedupeKey);
      const title = series?.title || record.title || "Series";
      items.push({
        id: dedupeKey,
        title,
        meta: [series?.year ? String(series.year) : "", "1 missing"].filter(Boolean).join(" · "),
        state: "Missing",
        progress: null,
        poster: posterUrl(cfg, instanceId, kind, series?.images),
        href: mediaHref(cfg, kind, series, seriesId, slugById),
      });
    }

    if (items.length >= 24) break;
  }

  return items;
}

function mapLibraryItems(
  cfg: Config,
  instanceId: string,
  kind: "radarr" | "sonarr",
  records: ArrLibraryRecord[],
  mode: "all" | "monitored" | "episodes",
) {
  const selected = mode === "monitored" ? records.filter((record) => record.monitored) : records;
  const sorted = [...selected].sort((a, b) => {
    if (mode === "episodes") {
      const countA = Number(a.statistics?.episodeFileCount || 0);
      const countB = Number(b.statistics?.episodeFileCount || 0);
      if (countA !== countB) return countB - countA;
    }
    return String(a.title || "").localeCompare(String(b.title || ""), undefined, { sensitivity: "base" });
  });

  return sorted.slice(0, 160).map((record) => {
    const episodeCount = Number(record.statistics?.episodeFileCount || 0);
    const availableCount = Number(
      record.statistics?.episodeCount ?? record.statistics?.totalEpisodeCount ?? 0,
    );
    const episodeMeta =
      kind === "sonarr"
        ? availableCount > 0
          ? `${episodeCount.toLocaleString()} of ${availableCount.toLocaleString()} episodes`
          : `${episodeCount.toLocaleString()} episode${episodeCount === 1 ? "" : "s"}`
        : "";
    return {
      id: `library-${kind}:${record.id || record.title}`,
      title: record.title || (kind === "radarr" ? "Movie" : "Series"),
      meta: [
        record.year ? String(record.year) : "",
        episodeMeta,
        record.monitored ? "Monitored" : "Unmonitored",
      ]
        .filter(Boolean)
        .join(" · "),
      state:
        mode === "episodes"
          ? `${episodeCount.toLocaleString()} EP`
          : record.monitored
            ? "Monitored"
            : "Unmonitored",
      progress:
        kind === "sonarr" && availableCount > 0
          ? Math.max(0, Math.min(100, Math.round((episodeCount / availableCount) * 100)))
          : null,
      poster: posterUrl(cfg, instanceId, kind, record.images),
      href: mediaHref(cfg, kind, record, record.id),
      mediaId: Number(record.id || 0) || undefined,
      monitored: Boolean(record.monitored),
    } satisfies ArrQueueItem;
  });
}

export async function arrCover(id: string, path: string) {
  const cfg = await config(id);
  const clean = path.startsWith("/") ? path : `/${path}`;
  if (!clean.startsWith("/MediaCover/")) throw new Error("Invalid cover path");
  let last: unknown;
  for (const base of connectionCandidates(cfg)) {
    try {
      const response = await fetch(joinUrl(base, clean), {
        headers: { "X-Api-Key": cfg.apiKey },
        cache: "force-cache",
        signal: AbortSignal.timeout(10_000),
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return response;
    } catch (error) {
      last = error;
    }
  }
  throw last instanceof Error ? last : new Error("Cover unavailable");
}

export async function arrStatus(id: string, kind: "radarr" | "sonarr") {
  const cfg = await config(id);
  const queuePath =
    kind === "radarr"
      ? "/api/v3/queue?pageSize=40&includeMovie=true"
      : "/api/v3/queue?pageSize=40&includeSeries=true&includeEpisode=true";
  const missingPath =
    kind === "radarr"
      ? "/api/v3/wanted/missing?pageSize=48&sortKey=title&sortDirection=ascending"
      : "/api/v3/wanted/missing?pageSize=80&includeSeries=true&sortKey=airDateUtc&sortDirection=descending";
  const connMeta: { usedBase?: string } = {};
  const [library, queue, wanted] = await Promise.all([
    request<ArrLibraryRecord[]>(
      cfg,
      `/api/v3/${kind === "radarr" ? "movie" : "series"}`,
      {},
      connMeta,
    ),
    request<{ totalRecords?: number; records?: ArrQueueRecord[] }>(cfg, queuePath),
    request<{ totalRecords?: number; records?: ArrMissingRecord[] }>(cfg, missingPath),
  ]);
  const queueRecords = queue.records || [];
  const missingRecords = wanted.records || [];
  const slugById = new Map<number, string>();
  for (const item of library) {
    if (item.id && item.titleSlug) slugById.set(item.id, item.titleSlug);
  }
  return {
    ...openUrlsFromConfig(cfg),
    href: hrefFor(cfg),
    connectionSource: classifyConnectionSource(connMeta.usedBase, cfg),
    total: library.length,
    monitored: library.filter((x) => x.monitored).length,
    episodes:
      kind === "sonarr"
        ? library.reduce((n, x) => n + (x.statistics?.episodeFileCount || 0), 0)
        : undefined,
    queued: queue.totalRecords ?? queueRecords.length,
    wanted: wanted.totalRecords ?? missingRecords.length,
    queueItems: mapQueueItems(cfg, id, kind, queueRecords, slugById),
    missingItems: mapMissingItems(cfg, id, kind, missingRecords, slugById),
    libraryItems: mapLibraryItems(cfg, id, kind, library, "all"),
    monitoredItems: mapLibraryItems(cfg, id, kind, library, "monitored"),
    episodeItems: kind === "sonarr" ? mapLibraryItems(cfg, id, kind, library, "episodes") : [],
  };
}

export type ArrManagerMissingItem = {
  id: number;
  mediaId: number;
  title: string;
  subtitle: string;
  poster: string;
};

export type ArrInteractiveRelease = {
  guid: string;
  indexerId: number;
  title: string;
  indexer: string;
  quality: string;
  size: number;
  seeders: number | null;
  leechers: number | null;
  ageHours: number | null;
  rejected: boolean;
  rejections: string[];
};

export async function arrManagerMissing(
  id: string,
  kind: "radarr" | "sonarr",
): Promise<ArrManagerMissingItem[]> {
  const cfg = await config(id);
  const path =
    kind === "radarr"
      ? "/api/v3/wanted/missing?page=1&pageSize=200&sortKey=title&sortDirection=ascending"
      : "/api/v3/wanted/missing?page=1&pageSize=200&includeSeries=true&sortKey=airDateUtc&sortDirection=descending";
  const wanted = await request<{ records?: ArrMissingRecord[] }>(cfg, path);
  return (wanted.records || []).map((record) => {
    if (kind === "radarr") {
      return {
        id: Number(record.id || 0),
        mediaId: Number(record.id || 0),
        title: record.title || "Movie",
        subtitle: [record.year ? String(record.year) : "", "Missing movie"].filter(Boolean).join(" · "),
        poster: posterUrl(cfg, id, kind, record.images),
      };
    }
    const series = record.series;
    const season = record.seasonNumber == null ? "" : `S${String(record.seasonNumber).padStart(2, "0")}`;
    const episode = record.episodeNumber == null ? "" : `E${String(record.episodeNumber).padStart(2, "0")}`;
    return {
      id: Number(record.id || 0),
      mediaId: Number(series?.id || record.seriesId || 0),
      title: series?.title || "Series",
      subtitle: [
        `${season}${episode}`,
        record.title || "",
        record.airDateUtc ? new Date(record.airDateUtc).toLocaleDateString() : "",
      ].filter(Boolean).join(" · "),
      poster: posterUrl(cfg, id, kind, series?.images),
    };
  }).filter((item) => item.id > 0);
}

type RawRelease = {
  guid?: string;
  indexerId?: number;
  title?: string;
  indexer?: string;
  size?: number;
  seeders?: number;
  leechers?: number;
  ageHours?: number;
  rejected?: boolean;
  rejections?: string[];
  quality?: { quality?: { name?: string }; revision?: { version?: number; real?: number } };
};

export async function arrInteractiveSearch(
  id: string,
  kind: "radarr" | "sonarr",
  targetId: number,
): Promise<ArrInteractiveRelease[]> {
  if (!Number.isInteger(targetId) || targetId <= 0) throw new Error("Invalid media id");
  const cfg = await config(id);
  const key = kind === "radarr" ? "movieId" : "episodeId";
  const releases = await request<RawRelease[]>(
    cfg,
    `/api/v3/release?${key}=${encodeURIComponent(targetId)}`,
  );
  return releases.map((release) => ({
    guid: String(release.guid || ""),
    indexerId: Number(release.indexerId || 0),
    title: release.title || "Untitled release",
    indexer: release.indexer || "Indexer",
    quality: release.quality?.quality?.name || "Unknown",
    size: Number(release.size || 0),
    seeders: Number.isFinite(Number(release.seeders)) ? Number(release.seeders) : null,
    leechers: Number.isFinite(Number(release.leechers)) ? Number(release.leechers) : null,
    ageHours: Number.isFinite(Number(release.ageHours)) ? Number(release.ageHours) : null,
    rejected: Boolean(release.rejected),
    rejections: Array.isArray(release.rejections) ? release.rejections.map(String) : [],
  })).filter((release) => release.guid && release.indexerId > 0);
}

export async function arrGrabRelease(
  id: string,
  kind: "radarr" | "sonarr",
  guid: string,
  indexerId: number,
) {
  if (!guid.trim() || !Number.isInteger(indexerId) || indexerId <= 0) {
    throw new Error("Invalid release");
  }
  const cfg = await config(id);
  await request(cfg, "/api/v3/release", {
    method: "POST",
    body: JSON.stringify({ guid, indexerId }),
  });
  invalidateStatusCache(`${kind}:${id}`);
  return { ok: true };
}

export type ArrMediaAction =
  | "monitor"
  | "unmonitor"
  | "search"
  | "refresh"
  | "queue-remove"
  | "queue-blocklist";

export async function arrMediaAction(
  id: string,
  kind: "radarr" | "sonarr",
  action: ArrMediaAction,
  targetId: number,
) {
  if (!Number.isInteger(targetId) || targetId <= 0) throw new Error("Invalid target id");
  const cfg = await config(id);
  const resource = kind === "radarr" ? "movie" : "series";

  if (action === "monitor" || action === "unmonitor") {
    const media = await request<Record<string, unknown>>(cfg, `/api/v3/${resource}/${targetId}`);
    await request(cfg, `/api/v3/${resource}/${targetId}`, {
      method: "PUT",
      body: JSON.stringify({ ...media, monitored: action === "monitor" }),
    });
  } else if (action === "search") {
    await request(cfg, "/api/v3/command", {
      method: "POST",
      body: JSON.stringify(
        kind === "radarr"
          ? { name: "MoviesSearch", movieIds: [targetId] }
          : { name: "SeriesSearch", seriesId: targetId },
      ),
    });
  } else if (action === "refresh") {
    await request(cfg, "/api/v3/command", {
      method: "POST",
      body: JSON.stringify(
        kind === "radarr"
          ? { name: "RefreshMovie", movieId: targetId }
          : { name: "RefreshSeries", seriesId: targetId },
      ),
    });
  } else {
    const blocklist = action === "queue-blocklist";
    await request(
      cfg,
      `/api/v3/queue/${targetId}?removeFromClient=true&blocklist=${blocklist ? "true" : "false"}&skipRedownload=false&changeCategory=false`,
      { method: "DELETE" },
    );
  }
  invalidateStatusCache(`${kind}:${id}`);
  return { ok: true };
}

export async function lidarrStatus(id: string) {
  const cfg = await config(id);
  const [artists, queue, calendar] = await Promise.all([
    request<Array<{ statistics?: { albumCount?: number; trackFileCount?: number; totalTrackCount?: number } }>>(
      cfg,
      "/api/v1/artist",
    ),
    request<{ totalRecords?: number; records?: unknown[] } | unknown[]>(cfg, "/api/v1/queue?pageSize=5"),
    request<Array<{ title?: string; artist?: { artistName?: string }; releaseDate?: string }>>(
      cfg,
      "/api/v1/calendar?unmonitored=true",
    ).catch(() => []),
  ]);
  const queueCount = Array.isArray(queue)
    ? queue.length
    : queue.totalRecords ?? queue.records?.length ?? 0;
  return {
    ...openUrlsFromConfig(cfg),
    href: hrefFor(cfg),
    artists: artists.length,
    albums: artists.reduce((n, a) => n + (a.statistics?.albumCount || 0), 0),
    tracks: artists.reduce(
      (n, a) => n + (a.statistics?.trackFileCount || a.statistics?.totalTrackCount || 0),
      0,
    ),
    queued: queueCount,
    upcoming: calendar.slice(0, 6).map((item) => ({
      title: item.title || "Release",
      artist: item.artist?.artistName || "",
      date: item.releaseDate || "",
    })),
  };
}

async function softTimeout<T>(promise: Promise<T>, ms: number): Promise<T | undefined> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      promise.then((value) => value),
      new Promise<undefined>((resolve) => {
        timer = setTimeout(() => resolve(undefined), ms);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export async function prowlarrStatus(id: string) {
  const cfg = await config(id);

  // indexerstats is the slow path (~1–2s). Cache it separately and soft-timeout
  // so the widget can paint indexers/history first.
  const statsPromise = cachedStatus(`prowlarr-stats:${id}`, 5 * 60_000, () =>
    request<{
      indexers?: Array<{
        indexerId?: number;
        indexerName?: string;
        averageResponseTime?: number;
        averageGrabResponseTime?: number;
        numberOfQueries?: number;
        numberOfGrabs?: number;
        numberOfRssQueries?: number;
        numberOfAuthQueries?: number;
        numberOfFailedQueries?: number;
        numberOfFailedGrabs?: number;
        numberOfFailedRssQueries?: number;
        numberOfFailedAuthQueries?: number;
      }>;
    }>(cfg, "/api/v1/indexerstats"),
  );

  const connMeta: { usedBase?: string } = {};
  const [fastSettled, statsSoft] = await Promise.all([
    Promise.allSettled([
      request<
        Array<{
          id?: number;
          name?: string;
          enable?: boolean;
          protocol?: string;
          privacy?: string;
          definitionName?: string;
          status?: { disabledTill?: string };
        }>
      >(cfg, "/api/v1/indexer", {}, connMeta),
      request<{
        totalRecords?: number;
        records?: Array<{
          id?: number;
          indexerId?: number;
          date?: string;
          eventType?: string;
          successful?: boolean;
          downloadId?: string;
          data?: {
            query?: string;
            queryType?: string;
            source?: string;
            queryResults?: number | string;
          };
        }>;
      }>(cfg, "/api/v1/history?pageSize=100&sortKey=date&sortDirection=descending"),
      request<Array<{ id?: number; indexerId?: number; disabledTill?: string }>>(
        cfg,
        "/api/v1/indexerstatus",
      ),
    ]),
    softTimeout(statsPromise, 500),
  ]);

  const [indexersRes, historyRes, statusesRes] = fastSettled;
  const indexers = indexersRes.status === "fulfilled" ? indexersRes.value || [] : [];
  const historyPayload = historyRes.status === "fulfilled" ? historyRes.value : null;
  const history = Array.isArray(historyPayload)
    ? historyPayload
    : Array.isArray(historyPayload?.records)
      ? historyPayload.records
      : [];
  const statuses = statusesRes.status === "fulfilled" ? statusesRes.value || [] : [];
  const stats = statsSoft ?? null;
  const statsPending = statsSoft == null;

  const now = Date.now();
  const isDisabledTillActive = (disabledTill?: string) => {
    if (!disabledTill) return false;
    const until = new Date(disabledTill).getTime();
    return Number.isFinite(until) && until > now;
  };

  const failingIds = new Set<number>();
  for (const status of statuses) {
    if (isDisabledTillActive(status.disabledTill)) {
      const idValue = status.indexerId ?? status.id;
      if (idValue != null) failingIds.add(idValue);
    }
  }
  for (const indexer of indexers) {
    if (indexer.id != null && isDisabledTillActive(indexer.status?.disabledTill)) {
      failingIds.add(indexer.id);
    }
  }

  const indexerStats = Array.isArray(stats?.indexers) ? stats.indexers : [];
  const totalGrabs = indexerStats.reduce((sum, item) => sum + (item.numberOfGrabs || 0), 0);
  const totalQueries = indexerStats.reduce((sum, item) => sum + (item.numberOfQueries || 0), 0);
  const totalFailedGrabs = indexerStats.reduce(
    (sum, item) => sum + (item.numberOfFailedGrabs || 0),
    0,
  );
  const totalFailedQueries = indexerStats.reduce(
    (sum, item) => sum + (item.numberOfFailedQueries || 0),
    0,
  );
  const totalRssQueries = indexerStats.reduce(
    (sum, item) => sum + (item.numberOfRssQueries || 0),
    0,
  );
  const totalAuthQueries = indexerStats.reduce(
    (sum, item) => sum + (item.numberOfAuthQueries || 0),
    0,
  );
  const responseSamples = indexerStats.filter((item) => (item.numberOfQueries || 0) > 0);
  const averageResponseTime = responseSamples.length
    ? Math.round(
        responseSamples.reduce(
          (sum, item) => sum + (item.averageResponseTime || 0) * (item.numberOfQueries || 0),
          0,
        ) / responseSamples.reduce((sum, item) => sum + (item.numberOfQueries || 0), 0),
      )
    : 0;

  return {
    ...openUrlsFromConfig(cfg),
    href: hrefFor(cfg),
    connectionSource: classifyConnectionSource(connMeta.usedBase, cfg),
    statsPending,
    indexers: indexers.map((indexer) => {
      const statusHit = statuses.find((status) => (status.indexerId ?? status.id) === indexer.id);
      const disabledTill = indexer.status?.disabledTill || statusHit?.disabledTill || "";
      const failing = indexer.id != null && failingIds.has(indexer.id);
      return {
        id: indexer.id ?? 0,
        name: indexer.name || "Unknown",
        enable: indexer.enable !== false,
        protocol: (indexer.protocol || "").toLowerCase(),
        privacy: (indexer.privacy || "").toLowerCase(),
        definitionName: indexer.definitionName || "",
        disabledTill,
        failing,
      };
    }),
    history: history.map((item) => ({
      id: item.id ?? 0,
      indexerId: item.indexerId ?? 0,
      date: item.date || "",
      eventType: item.eventType || "",
      successful: item.successful !== false,
      downloadId: item.downloadId || "",
      query: item.data?.query || "",
      queryType: item.data?.queryType || item.eventType || "",
      source: item.data?.source || "",
      queryResults: item.data?.queryResults ?? null,
    })),
    indexerStats: indexerStats.map((item) => ({
      indexerId: item.indexerId ?? 0,
      indexerName: item.indexerName || "Unknown",
      averageResponseTime: item.averageResponseTime || 0,
      averageGrabResponseTime: item.averageGrabResponseTime || 0,
      numberOfQueries: item.numberOfQueries || 0,
      numberOfGrabs: item.numberOfGrabs || 0,
      numberOfRssQueries: item.numberOfRssQueries || 0,
      numberOfAuthQueries: item.numberOfAuthQueries || 0,
      numberOfFailedQueries: item.numberOfFailedQueries || 0,
      numberOfFailedGrabs: item.numberOfFailedGrabs || 0,
      numberOfFailedRssQueries: item.numberOfFailedRssQueries || 0,
      numberOfFailedAuthQueries: item.numberOfFailedAuthQueries || 0,
    })),
    totals: {
      indexers: indexers.length,
      enabled: indexers.filter((indexer) => indexer.enable !== false).length,
      disabled: indexers.filter((indexer) => indexer.enable === false).length,
      torrent: indexers.filter((indexer) => (indexer.protocol || "").toLowerCase() === "torrent")
        .length,
      failing: failingIds.size,
      grabs: totalGrabs,
      queries: totalQueries,
      failedGrabs: totalFailedGrabs,
      failedQueries: totalFailedQueries,
      rssQueries: totalRssQueries,
      authQueries: totalAuthQueries,
      averageResponseTime,
    },
  };
}

export async function prowlarrSync(id: string) {
  const cfg = await config(id);
  await request(cfg, "/api/v1/command", {
    method: "POST",
    body: JSON.stringify({ name: "ApplicationIndexerSync" }),
  });
  invalidateStatusCache(`prowlarr:${id}`);
  invalidateStatusCache(`prowlarr-stats:${id}`);
  return { ok: true };
}

export type ProwlarrIndexerAction = "test" | "update" | "delete";

export async function prowlarrIndexerDetails(id: string, indexerId: number) {
  if (!Number.isInteger(indexerId) || indexerId <= 0) {
    throw new Error("A valid indexer id is required");
  }
  const cfg = await config(id);
  const indexer = await request<
    Record<string, unknown> & {
      fields?: Array<Record<string, unknown> & { selectOptionsProviderAction?: string }>;
    }
  >(cfg, `/api/v1/indexer/${indexerId}`);
  const fields = indexer.fields || [];
  const optionActions = [
    ...new Set(fields.map((field) => field.selectOptionsProviderAction).filter(Boolean)),
  ] as string[];
  const resolved = new Map<string, unknown[]>();

  await Promise.all(
    optionActions.map(async (action) => {
      try {
        const result = await request<{ options?: unknown[] }>(
          cfg,
          `/api/v1/indexer/action/${encodeURIComponent(action)}`,
          { method: "POST", body: JSON.stringify(indexer) },
        );
        resolved.set(action, result.options || []);
      } catch {
        resolved.set(action, []);
      }
    }),
  );

  return {
    ...indexer,
    fields: fields.map((field) => {
      const action = field.selectOptionsProviderAction;
      return action ? { ...field, homedashSelectOptions: resolved.get(action) || [] } : field;
    }),
  };
}

export async function prowlarrIndexerAction(
  id: string,
  indexerId: number,
  action: ProwlarrIndexerAction,
  indexer?: Record<string, unknown>,
) {
  if (!Number.isInteger(indexerId) || indexerId <= 0) {
    throw new Error("A valid indexer id is required");
  }
  const cfg = await config(id);

  if (action === "delete") {
    await request(cfg, `/api/v1/indexer/${indexerId}`, { method: "DELETE" });
  } else {
    if (!indexer || typeof indexer !== "object") {
      throw new Error("Indexer configuration is required");
    }
    const payload = { ...indexer, id: indexerId };
    await request(cfg, action === "test" ? "/api/v1/indexer/test" : `/api/v1/indexer/${indexerId}`, {
      method: action === "test" ? "POST" : "PUT",
      body: JSON.stringify(payload),
    });
  }

  invalidateStatusCache(`prowlarr:${id}`);
  invalidateStatusCache(`prowlarr-stats:${id}`);
  return { ok: true };
}

export type ProwlarrIndexerDefinition = {
  definitionName: string;
  name: string;
  implementationName: string;
  protocol: string;
  privacy: string;
  language: string;
  description: string;
  categories: string[];
  supportsSearch: boolean;
  supportsRss: boolean;
};

type ProwlarrSchemaEntry = Record<string, unknown> & {
  fields?: Array<Record<string, unknown> & { selectOptionsProviderAction?: string }>;
  definitionName?: string;
  name?: string;
  implementationName?: string;
  protocol?: string;
  privacy?: string;
  language?: string;
  description?: string;
  supportsSearch?: boolean;
  supportsRss?: boolean;
  capabilities?: {
    categories?: Array<{ id?: number; name?: string }>;
  };
};

async function fetchIndexerSchemas(cfg: Config) {
  return request<ProwlarrSchemaEntry[]>(cfg, "/api/v1/indexer/schema");
}

// Prowlarr reports categories as parent groups (Movies, TV, Audio…) each with
// numbered subCategories. We only surface the parent names for filtering.
function topLevelCategories(entry: ProwlarrSchemaEntry): string[] {
  const categories = entry.capabilities?.categories || [];
  return [
    ...new Set(
      categories
        .map((category) => (category?.name || "").trim())
        .filter(Boolean),
    ),
  ].sort((a, b) => a.localeCompare(b));
}

// Catalog of indexer definitions available to add — cached, since this list is
// effectively static per Prowlarr install and only changes with app updates.
export async function prowlarrIndexerSchemas(id: string): Promise<ProwlarrIndexerDefinition[]> {
  return cachedStatus(`prowlarr-schema:${id}`, 10 * 60_000, async () => {
    const cfg = await config(id);
    const schemas = await fetchIndexerSchemas(cfg);
    return (schemas || [])
      .map((entry) => ({
        definitionName: String(entry.definitionName || entry.name || ""),
        name: String(entry.name || entry.definitionName || "Unknown"),
        implementationName: String(entry.implementationName || ""),
        protocol: String(entry.protocol || "").toLowerCase(),
        privacy: String(entry.privacy || "").toLowerCase(),
        language: String(entry.language || ""),
        description: String(entry.description || ""),
        categories: topLevelCategories(entry),
        supportsSearch: entry.supportsSearch !== false,
        supportsRss: entry.supportsRss !== false,
      }))
      .filter((entry) => entry.definitionName)
      .sort((a, b) => a.name.localeCompare(b.name));
  });
}

// Full field template for one definition, with select-option providers resolved —
// this is the pre-filled form a user configures before adding the indexer.
export async function prowlarrIndexerSchemaDetails(id: string, definitionName: string) {
  if (!definitionName) {
    throw new Error("A definition name is required");
  }
  const cfg = await config(id);
  const schemas = await fetchIndexerSchemas(cfg);
  const entry = (schemas || []).find(
    (item) => (item.definitionName || item.name) === definitionName,
  );
  if (!entry) {
    throw new Error("Indexer definition not found");
  }
  const fields = entry.fields || [];
  const optionActions = [
    ...new Set(fields.map((field) => field.selectOptionsProviderAction).filter(Boolean)),
  ] as string[];
  const resolved = new Map<string, unknown[]>();

  await Promise.all(
    optionActions.map(async (action) => {
      try {
        const result = await request<{ options?: unknown[] }>(
          cfg,
          `/api/v1/indexer/action/${encodeURIComponent(action)}`,
          { method: "POST", body: JSON.stringify(entry) },
        );
        resolved.set(action, result.options || []);
      } catch {
        resolved.set(action, []);
      }
    }),
  );

  return {
    ...entry,
    fields: fields.map((field) => {
      const action = field.selectOptionsProviderAction;
      return action ? { ...field, homedashSelectOptions: resolved.get(action) || [] } : field;
    }),
  };
}

export type ProwlarrSchemaAction = "test" | "create";

export async function prowlarrIndexerSchemaAction(
  id: string,
  action: ProwlarrSchemaAction,
  indexer: Record<string, unknown>,
) {
  if (!indexer || typeof indexer !== "object") {
    throw new Error("Indexer configuration is required");
  }
  const cfg = await config(id);
  const result = await request<Record<string, unknown>>(
    cfg,
    action === "test" ? "/api/v1/indexer/test" : "/api/v1/indexer",
    { method: "POST", body: JSON.stringify(indexer) },
  );

  if (action === "create") {
    invalidateStatusCache(`prowlarr:${id}`);
    invalidateStatusCache(`prowlarr-stats:${id}`);
    return result;
  }
  return { ok: true };
}
