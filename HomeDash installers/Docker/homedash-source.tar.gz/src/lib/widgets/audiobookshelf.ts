import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, hasConnectionUrl, primaryConnectionUrl } from "@/lib/open-href";

export type AbsTab = "library" | "continue" | "recent" | "playing";

type AbsConfig = {
  baseUrl: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  pathPrefix?: string;
  apiKey?: string;
  token?: string;
  username?: string;
  password?: string;
};

type AbsLibrary = {
  id: string;
  name: string;
  mediaType?: string;
  totalItems?: number;
};

export type AbsBook = {
  id: string;
  title: string;
  author: string;
  series?: string;
  duration: number;
  href: string;
  openFallbackUrl?: string;
  progress?: number | null;
  synopsis?: string;
  narrator?: string;
  publishedYear?: string;
  genres?: string[];
};

export type AbsSession = {
  id: string;
  title: string;
  author: string;
  user: string;
  pct: number;
  href: string;
  openFallbackUrl?: string;
};

export type AbsConnectionSource = "private" | "public" | "unknown";

type Session = {
  cfg: AbsConfig;
  base: string;
  token: string;
  source: AbsConnectionSource;
};

function asRecord(value: unknown) {
  return value && typeof value === "object" ? (value as Record<string, unknown>) : {};
}

function apiRoot(url: string) {
  return String(url || "").replace(/\/$/, "");
}

function classifyConnectionSource(cfg: AbsConfig, base: string): AbsConnectionSource {
  const normalized = apiRoot(base);
  if (cfg.baseUrl && apiRoot(cfg.baseUrl) === normalized) return "private";
  if (cfg.fallbackUrl && apiRoot(cfg.fallbackUrl) === normalized) return "public";
  return "unknown";
}

function webBase(cfg: AbsConfig, base: string) {
  const root = base.replace(/\/$/, "");
  const prefix = String(cfg.pathPrefix || "").replace(/\/$/, "");
  if (!prefix) return root;
  return `${root}${prefix.startsWith("/") ? prefix : `/${prefix}`}`;
}

async function resolveSession(instanceId: string): Promise<Session> {
  const rawConfig = (await readWidgetConfig(instanceId)) as AbsConfig;
  if (!hasConnectionUrl(rawConfig)) {
    throw new Error("Configure a Private - IP or Fallback Public URL in Settings");
  }
  const raw = { ...rawConfig, baseUrl: primaryConnectionUrl(rawConfig) };
  const token = String(raw.apiKey || raw.token || "").trim();
  const candidates = connectionCandidates(raw).map((u) => u.replace(/\/$/, ""));

  if (token) {
    for (const base of candidates) {
      try {
        const r = await fetch(joinUrl(base, "/api/libraries"), {
          headers: { Authorization: `Bearer ${token}`, Accept: "application/json" },
          cache: "no-store",
          signal: AbortSignal.timeout(10_000),
        });
        if (r.ok) return { cfg: raw, base, token, source: classifyConnectionSource(rawConfig, base) };
      } catch {
        /* try next */
      }
    }
    return { cfg: raw, base: candidates[0], token, source: classifyConnectionSource(rawConfig, candidates[0]) };
  }

  if (!raw.username || !raw.password) {
    throw new Error("Configure an API token (or username/password) in Settings");
  }

  let lastErr: unknown;
  for (const base of candidates) {
    try {
      const r = await fetch(joinUrl(base, "/login"), {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ username: raw.username, password: raw.password }),
        cache: "no-store",
        signal: AbortSignal.timeout(10_000),
      });
      if (!r.ok) throw new Error(`Login failed (${r.status})`);
      const data = (await r.json()) as { user?: { token?: string } };
      const next = String(data.user?.token || "");
      if (!next) throw new Error("Login response missing token");
      return { cfg: raw, base, token: next, source: classifyConnectionSource(rawConfig, base) };
    } catch (err) {
      lastErr = err;
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error("Audiobookshelf login failed");
}

async function apiGet<T>(session: Session, path: string): Promise<T> {
  const r = await fetch(joinUrl(session.base, path), {
    headers: { Authorization: `Bearer ${session.token}`, Accept: "application/json" },
    cache: "no-store",
    signal: AbortSignal.timeout(12_000),
  });
  if (!r.ok) throw new Error(`Audiobookshelf ${r.status}`);
  if (r.status === 204) return null as T;
  return (await r.json()) as T;
}

function itemId(item: Record<string, unknown>) {
  return String(item.id || item.libraryItemId || "");
}

function itemTitle(item: Record<string, unknown>) {
  const media = asRecord(item.media);
  const meta = asRecord(media.metadata || item.mediaMetadata);
  return String(meta.title || item.displayTitle || item.title || "Unknown");
}

function itemAuthor(item: Record<string, unknown>) {
  const media = asRecord(item.media);
  const meta = asRecord(media.metadata || item.mediaMetadata);
  return String(meta.authorName || meta.author || item.displayAuthor || "");
}

function itemDuration(item: Record<string, unknown>) {
  const media = asRecord(item.media);
  const meta = asRecord(item.mediaMetadata);
  return Number(media.duration || item.duration || meta.duration || 0) || 0;
}

function itemSeries(item: Record<string, unknown>) {
  const media = asRecord(item.media);
  const meta = asRecord(media.metadata || item.mediaMetadata);
  return String(meta.seriesName || "");
}

function cleanText(value: unknown) {
  return String(value || "")
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/\s+/g, " ")
    .trim();
}

function itemHref(session: Session, item: Record<string, unknown>) {
  const base = webBase(session.cfg, session.base);
  const id = itemId(item);
  if (!id) return base;
  const type = String(item.mediaType || asRecord(item.media).mediaType || "book");
  if (type === "podcast") return `${base}/podcast/${id}`;
  return `${base}/item/${id}`;
}

function openFallbackBase(cfg: AbsConfig) {
  const raw = (cfg.openFallbackUrl || cfg.fallbackUrl || "").trim();
  return raw ? webBase(cfg, raw) : "";
}

function itemOpenFallbackHref(session: Session, item: Record<string, unknown>) {
  const base = openFallbackBase(session.cfg);
  if (!base) return "";
  const id = itemId(item);
  if (!id) return base;
  const type = String(item.mediaType || asRecord(item.media).mediaType || "book");
  if (type === "podcast") return `${base}/podcast/${id}`;
  return `${base}/item/${id}`;
}

function progressOf(item: Record<string, unknown>) {
  const mp = asRecord(item.mediaProgress || item.progress);
  if (mp.progress != null) return Math.round(Number(mp.progress) * (Number(mp.progress) <= 1 ? 100 : 1));
  if (item.progress != null && typeof item.progress === "number") {
    const p = item.progress;
    return Math.round(p <= 1 ? p * 100 : p);
  }
  const current = Number(item.currentTime || mp.currentTime || 0);
  const dur = Number(item.duration || mp.duration || itemDuration(item) || 0);
  if (dur > 0 && current > 0) return Math.min(100, Math.round((current / dur) * 100));
  return null;
}

function normalizeBook(session: Session, raw: unknown): AbsBook | null {
  let item = asRecord(raw);
  if (item.libraryItem && typeof item.libraryItem === "object") {
    const nested = asRecord(item.libraryItem);
    item = { ...nested, mediaProgress: item.mediaProgress || item.progress || nested.mediaProgress };
  }
  const id = itemId(item);
  if (!id) return null;
  const media = asRecord(item.media);
  const meta = asRecord(media.metadata || item.mediaMetadata);
  const rawGenres = Array.isArray(meta.genres) ? meta.genres : [];
  return {
    id,
    title: itemTitle(item),
    author: itemAuthor(item),
    series: itemSeries(item) || undefined,
    duration: itemDuration(item),
    href: itemHref(session, item),
    openFallbackUrl: itemOpenFallbackHref(session, item),
    progress: progressOf(item),
    synopsis: cleanText(meta.description || meta.subtitle || item.description) || undefined,
    narrator: cleanText(meta.narratorName || meta.narrator) || undefined,
    publishedYear: cleanText(meta.publishedYear || meta.publishYear) || undefined,
    genres: rawGenres.map((genre) => cleanText(genre)).filter(Boolean),
  };
}

function normalizeSession(session: Session, raw: unknown): AbsSession | null {
  const item = asRecord(raw);
  const id = String(item.libraryItemId || item.id || "");
  if (!id) return null;
  const current = Number(item.currentTime || 0);
  const duration = Number(item.duration || 0);
  const pct = duration > 0 ? Math.min(100, Math.round((current / duration) * 100)) : 0;
  const user = asRecord(item.user);
  return {
    id,
    title: String(item.displayTitle || itemTitle(item)),
    author: String(item.displayAuthor || itemAuthor(item)),
    user: String(user.username || item.username || ""),
    pct,
    href: itemHref(session, { ...item, id, libraryItemId: id }),
    openFallbackUrl: itemOpenFallbackHref(session, { ...item, id, libraryItemId: id }),
  };
}

async function loadLibraries(session: Session): Promise<AbsLibrary[]> {
  const data = await apiGet<{ libraries?: Array<Record<string, unknown>> }>(session, "/api/libraries");
  return (data?.libraries || []).map((lib) => ({
    id: String(lib.id || ""),
    name: String(lib.name || "Library"),
    mediaType: lib.mediaType ? String(lib.mediaType) : undefined,
  })).filter((l) => l.id);
}

async function libraryStats(session: Session, libraryId: string) {
  try {
    return await apiGet<Record<string, unknown>>(session, `/api/libraries/${encodeURIComponent(libraryId)}/stats`);
  } catch {
    return {};
  }
}

async function personalized(session: Session, libraryId: string, sectionId: string) {
  try {
    const sections = await apiGet<Array<Record<string, unknown>>>(
      session,
      `/api/libraries/${encodeURIComponent(libraryId)}/personalized`,
    );
    if (!Array.isArray(sections)) return [];
    const section = sections.find((s) => s.id === sectionId);
    const entities = Array.isArray(section?.entities) ? section.entities : [];
    return entities.map((e) => normalizeBook(session, e)).filter(Boolean) as AbsBook[];
  } catch {
    return [];
  }
}

function libsForView(libraries: AbsLibrary[], libraryId: string | null) {
  if (!libraryId) return libraries;
  return libraries.filter((l) => l.id === libraryId);
}

export async function audiobookshelfStatus(
  instanceId: string,
  options: { tab?: string; libraryId?: string } = {},
) {
  const tab = (String(options.tab || "library").toLowerCase() || "library") as AbsTab;
  const session = await resolveSession(instanceId);
  const href = webBase(session.cfg, session.base);
  const openFallbackUrl = openFallbackBase(session.cfg);
  const libraries = await loadLibraries(session);
  const preferred =
    options.libraryId ||
    libraries.find((l) => /ebook/i.test(l.name))?.id ||
    libraries.find((l) => !/audio/i.test(l.name))?.id ||
    libraries[0]?.id ||
    "";
  const libraryId = preferred || null;
  const viewLibs = libsForView(libraries, libraryId);

  const libCards: AbsLibrary[] = await Promise.all(
    libraries.map(async (lib) => {
      const stats = await libraryStats(session, lib.id);
      return { ...lib, totalItems: Number(stats.totalItems || 0) || 0 };
    }),
  );

  if (tab === "playing") {
    const online = await apiGet<{ openSessions?: unknown[] }>(session, "/api/users/online").catch(() => ({
      openSessions: [],
    }));
    const sessions = (online.openSessions || [])
      .map((s) => normalizeSession(session, s))
      .filter(Boolean) as AbsSession[];
    return { href, openFallbackUrl, tab, libraryId, libraries: libCards, sessions, connectionSource: session.source };
  }

  if (tab === "continue" || tab === "recent") {
    const sectionId = tab === "continue" ? "continue-listening" : "recently-added";
    let items: AbsBook[] = [];
    for (const lib of viewLibs) {
      items = items.concat(await personalized(session, lib.id, sectionId));
    }
    items = items.slice(0, 16);
    return { href, openFallbackUrl, tab, libraryId, libraries: libCards, items, connectionSource: session.source };
  }

  // library overview
  let totalItems = 0;
  let totalAuthors = 0;
  let totalDuration = 0;
  let totalSize = 0;
  for (const lib of viewLibs) {
    const stats = await libraryStats(session, lib.id);
    totalItems += Number(stats.totalItems || 0) || 0;
    totalAuthors += Number(stats.totalAuthors || 0) || 0;
    totalDuration += Number(stats.totalDuration || 0) || 0;
    totalSize += Number(stats.totalSize || 0) || 0;
  }

  let recent: AbsBook[] = [];
  for (const lib of viewLibs) {
    recent = recent.concat(await personalized(session, lib.id, "recently-added"));
  }
  recent = recent.slice(0, 8);

  return {
    href,
    openFallbackUrl,
    tab: "library" as const,
    libraryId,
    libraries: libCards,
    totals: {
      items: totalItems,
      authors: totalAuthors,
      duration: totalDuration,
      size: totalSize,
    },
    recent,
    connectionSource: session.source,
  };
}

export async function audiobookshelfCover(instanceId: string, itemId: string, width = 400) {
  if (!itemId) throw new Error("Missing item id");
  const session = await resolveSession(instanceId);
  const w = Math.max(40, Math.min(800, width));
  const path = `/api/items/${encodeURIComponent(itemId)}/cover?width=${w}`;
  const headers = { Authorization: `Bearer ${session.token}` };

  let response = await fetch(joinUrl(session.base, path), {
    headers,
    cache: "no-store",
    signal: AbortSignal.timeout(10_000),
  });

  // Some ABS setups prefer token query auth for cover binaries.
  if (!response.ok) {
    const withToken = `${joinUrl(session.base, path)}&token=${encodeURIComponent(session.token)}`;
    response = await fetch(withToken, {
      cache: "no-store",
      signal: AbortSignal.timeout(10_000),
    });
  }

  if (!response.ok) throw new Error(`Cover ${response.status}`);
  return response;
}
