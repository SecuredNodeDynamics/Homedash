import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, hasConnectionUrl } from "@/lib/open-href";

type Config = {
  baseUrl: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  username?: string;
  password?: string;
  apiKey?: string;
};

function openFallbackFor(cfg: Config) {
  return (cfg.openFallbackUrl || cfg.fallbackUrl || "").trim();
}

export type BoConnectionSource = "private" | "public" | "unknown";

function apiRoot(url: string) {
  return String(url || "").replace(/\/+$/, "");
}

function classifyConnectionSource(cfg: Config, base: string): BoConnectionSource {
  const normalized = apiRoot(base);
  if (cfg.baseUrl && apiRoot(cfg.baseUrl) === normalized) return "private";
  if (cfg.fallbackUrl && apiRoot(cfg.fallbackUrl) === normalized) return "public";
  return "unknown";
}

type TokenCache = { token: string; expires: number; base: string };
const tokenCache = new Map<string, TokenCache>();
const TOKEN_TTL_MS = 10 * 60_000;

function bases(cfg: Config) {
  return connectionCandidates(cfg).map((u) => u.replace(/\/$/, ""));
}

async function loadConfig(instanceId: string): Promise<Config> {
  const value = (await readWidgetConfig(instanceId)) as Partial<Config>;
  if (!hasConnectionUrl(value)) {
    throw new Error("Configure a Private - IP or Fallback Public URL in Settings");
  }
  if (!value.apiKey && !(value.username && value.password)) {
    throw new Error("Configure BookOrbit apiKey or username/password in Settings");
  }
  return { ...value, baseUrl: value.baseUrl || "" } as Config;
}

function unwrapPayload(data: unknown): unknown {
  if (!data || typeof data !== "object" || Array.isArray(data)) return data;
  const obj = data as Record<string, unknown>;
  if (obj.data && typeof obj.data === "object") return obj.data;
  if (obj.result && typeof obj.result === "object") return obj.result;
  if (obj.widget && typeof obj.widget === "object") return obj.widget;
  return data;
}

function asList(value: unknown): unknown[] {
  if (Array.isArray(value)) return value;
  if (value && typeof value === "object") {
    const obj = value as Record<string, unknown>;
    for (const key of ["books", "items", "results", "data"]) {
      if (Array.isArray(obj[key])) return obj[key] as unknown[];
    }
  }
  return [];
}

async function login(cfg: Config, base: string) {
  if (!cfg.username || !cfg.password) throw new Error("BookOrbit login requires username and password");
  const res = await fetch(joinUrl(base, "/api/v1/auth/login"), {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({ username: cfg.username, password: cfg.password }),
    cache: "no-store",
    signal: AbortSignal.timeout(10_000),
  });
  const data = (await res.json().catch(() => ({}))) as {
    accessToken?: string;
    token?: string;
    access_token?: string;
    message?: string;
  };
  if (!res.ok) throw new Error(data.message || `BookOrbit login ${res.status}`);
  const token = data.accessToken || data.token || data.access_token;
  if (!token) throw new Error("BookOrbit login succeeded but no access token returned");
  return token;
}

async function resolveAuth(instanceId: string, cfg: Config, base: string): Promise<string> {
  if (cfg.apiKey) return cfg.apiKey;
  const cacheKey = `${instanceId}:${base}`;
  const cached = tokenCache.get(cacheKey);
  if (cached && Date.now() < cached.expires) return cached.token;
  const token = await login(cfg, base);
  tokenCache.set(cacheKey, { token, expires: Date.now() + TOKEN_TTL_MS, base });
  return token;
}

async function apiFetch<T>(
  instanceId: string,
  cfg: Config,
  path: string,
  init: RequestInit = {},
  retried = false,
): Promise<{ data: T; href: string }> {
  let last: unknown;
  for (const base of bases(cfg)) {
    try {
      const token = await resolveAuth(instanceId, cfg, base);
      const res = await fetch(joinUrl(base, path), {
        ...init,
        headers: {
          Accept: "application/json",
          Authorization: `Bearer ${token}`,
          ...(init.headers as Record<string, string> | undefined),
        },
        cache: "no-store",
        signal: AbortSignal.timeout(12_000),
      });
      if ((res.status === 401 || res.status === 403) && !retried && !cfg.apiKey && cfg.username && cfg.password) {
        tokenCache.delete(`${instanceId}:${base}`);
        return apiFetch(instanceId, cfg, path, init, true);
      }
      if (!res.ok) throw new Error(`BookOrbit HTTP ${res.status}`);
      if (res.status === 204) return { data: null as T, href: base };
      const json = unwrapPayload(await res.json()) as T;
      return { data: json, href: base };
    } catch (error) {
      last = error;
    }
  }
  throw last instanceof Error ? last : new Error("BookOrbit unavailable");
}

function mapBook(raw: unknown) {
  const book = (raw || {}) as Record<string, unknown>;
  const meta = (book.metadata || {}) as Record<string, unknown>;
  const authorRaw = book.author || book.authorName || book.authors || meta.author;
  const author = Array.isArray(authorRaw)
    ? authorRaw.map((a) => (typeof a === "object" && a ? String((a as { name?: string }).name || a) : String(a))).join(", ")
    : String(authorRaw || "");
  const progress = book.progressPercent ?? book.progress ?? book.percentComplete;
  return {
    id: String(book.id || book.bookId || ""),
    title: String(book.title || book.name || book.bookTitle || meta.title || "Untitled"),
    author,
    progress: Number.isFinite(Number(progress)) ? Math.max(0, Math.min(100, Math.round(Number(progress)))) : null,
    coverUrl: String(book.coverUrl || book.cover || book.thumbnailUrl || book.thumbnail || ""),
  };
}

export async function bookorbitStatus(instanceId: string, tab = "overview") {
  const cfg = await loadConfig(instanceId);
  const key = (tab || "overview").toLowerCase();

  if (key === "reading") {
    const { data, href } = await apiFetch<unknown>(instanceId, cfg, "/api/v1/dashboard/scrollers/continue-reading?limit=12");
    return { href, openFallbackUrl: openFallbackFor(cfg), connectionSource: classifyConnectionSource(cfg, href), tab: "reading", books: asList(data).map(mapBook) };
  }

  if (key === "recent") {
    const { data, href } = await apiFetch<unknown>(instanceId, cfg, "/api/v1/dashboard/scrollers/recently-added?limit=12");
    return { href, openFallbackUrl: openFallbackFor(cfg), connectionSource: classifyConnectionSource(cfg, href), tab: "recent", books: asList(data).map(mapBook) };
  }

  if (key === "stats") {
    const { data, href } = await apiFetch<Record<string, unknown>>(instanceId, cfg, "/api/v1/user-statistics/summary");
    const stats = data || {};
    return {
      href,
      openFallbackUrl: openFallbackFor(cfg),
      connectionSource: classifyConnectionSource(cfg, href),
      tab: "stats",
      completed: Number(stats.booksCompleted ?? stats.completedBooks ?? stats.booksRead ?? 0),
      pages: Number(stats.pagesRead ?? stats.totalPagesRead ?? 0),
      readingSeconds: Number(stats.readingSeconds ?? stats.totalReadingSeconds ?? stats.readingTimeSeconds ?? 0),
      sessions: Number(stats.sessions ?? stats.sessionCount ?? 0),
      stats,
    };
  }

  const [overviewR, goalR, streakR] = await Promise.allSettled([
    apiFetch<Record<string, unknown>>(instanceId, cfg, "/api/v1/dashboard/widgets/library-overview"),
    apiFetch<Record<string, unknown>>(instanceId, cfg, "/api/v1/dashboard/widgets/reading-goal"),
    apiFetch<Record<string, unknown>>(instanceId, cfg, "/api/v1/dashboard/widgets/reading-streak"),
  ]);

  if (overviewR.status === "rejected" && goalR.status === "rejected" && streakR.status === "rejected") {
    throw overviewR.reason instanceof Error ? overviewR.reason : new Error("BookOrbit overview failed");
  }

  const overview = overviewR.status === "fulfilled" ? overviewR.value.data || {} : {};
  const goal = goalR.status === "fulfilled" ? goalR.value.data || {} : {};
  const streak = streakR.status === "fulfilled" ? streakR.value.data || {} : {};
  const href =
    (overviewR.status === "fulfilled" && overviewR.value.href) ||
    (goalR.status === "fulfilled" && goalR.value.href) ||
    (streakR.status === "fulfilled" && streakR.value.href) ||
    cfg.baseUrl;

  const authors = overview.totalAuthors
    ?? (Array.isArray(overview.authors) ? overview.authors.length : overview.authors)
    ?? overview.authorCount
    ?? 0;

  let reading: ReturnType<typeof mapBook>[] = [];
  try {
    const { data: readingData } = await apiFetch<unknown>(
      instanceId,
      cfg,
      "/api/v1/dashboard/scrollers/continue-reading?limit=8",
    );
    reading = asList(readingData).map(mapBook);
  } catch {
    reading = [];
  }

  let completed = Number(goal.completedBooks ?? goal.completed ?? 0);
  let pages = 0;
  let readingSeconds = 0;
  try {
    const { data: summary } = await apiFetch<Record<string, unknown>>(
      instanceId,
      cfg,
      "/api/v1/user-statistics/summary",
    );
    const stats = summary || {};
    completed = Number(stats.booksCompleted ?? stats.completedBooks ?? stats.booksRead ?? completed);
    pages = Number(stats.pagesRead ?? stats.totalPagesRead ?? 0);
    readingSeconds = Number(stats.readingSeconds ?? stats.totalReadingSeconds ?? stats.readingTimeSeconds ?? 0);
  } catch {
    /* overview still works without summary */
  }

  return {
    href,
    openFallbackUrl: openFallbackFor(cfg),
    connectionSource: classifyConnectionSource(cfg, href),
    tab: "overview",
    books: Number(overview.totalBooks ?? overview.books ?? overview.bookCount ?? 0),
    authors: Number(authors || 0),
    goalCompleted: Number(goal.completedBooks ?? goal.completed ?? 0),
    goalBooks: Number(goal.goalBooks ?? goal.goal ?? 0),
    dayStreak: Number(streak.currentStreak ?? streak.streak ?? streak.days ?? 0),
    completed,
    pages,
    readingSeconds,
    readingCount: reading.length,
    reading,
    overview,
    goal,
    streak,
  };
}

export async function bookorbitCover(instanceId: string, bookId: string) {
  if (!bookId) throw new Error("Missing book id");
  const cfg = await loadConfig(instanceId);
  let last: unknown;
  for (const base of bases(cfg)) {
    try {
      const token = await resolveAuth(instanceId, cfg, base);
      for (const path of [
        `/api/v1/books/${encodeURIComponent(bookId)}/thumbnail`,
        `/api/v1/books/${encodeURIComponent(bookId)}/cover`,
      ]) {
        const res = await fetch(joinUrl(base, path), {
          headers: { Authorization: `Bearer ${token}`, Accept: "image/*" },
          cache: "no-store",
          signal: AbortSignal.timeout(12_000),
        });
        if (res.ok) return res;
        last = new Error(`BookOrbit cover HTTP ${res.status}`);
      }
    } catch (error) {
      last = error;
    }
  }
  throw last instanceof Error ? last : new Error("BookOrbit cover unavailable");
}
