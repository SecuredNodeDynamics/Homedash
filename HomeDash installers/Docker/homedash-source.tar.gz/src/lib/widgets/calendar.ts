import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";

export type CalendarSourceType = "radarr" | "sonarr" | "lidarr" | "seerr";

export type CalendarSource = {
  type: CalendarSourceType;
  label: string;
  color: string;
  url: string;
  fallbackUrl?: string;
  key: string;
};

type Config = {
  sources?: CalendarSource[];
  sourcesJson?: string;
  radarrUrl?: string;
  radarrKey?: string;
  radarrFallbackUrl?: string;
  radarr2Url?: string;
  radarr2Key?: string;
  radarr2FallbackUrl?: string;
  sonarrUrl?: string;
  sonarrKey?: string;
  sonarrFallbackUrl?: string;
  sonarr2Url?: string;
  sonarr2Key?: string;
  sonarr2FallbackUrl?: string;
  lidarrUrl?: string;
  lidarrKey?: string;
  lidarrFallbackUrl?: string;
  seerrUrl?: string;
  seerrKey?: string;
  seerrFallbackUrl?: string;
};

export type CalendarEvent = {
  id: string;
  title: string;
  subtitle?: string;
  date: string;
  type: "movie" | "episode" | "album" | "request";
  source: string;
  color: string;
  poster: string;
  href: string;
  status: number;
};

type ArrImage = { coverType?: string; url?: string; remoteUrl?: string };

function isoDay(d: Date) {
  return d.toISOString().slice(0, 10);
}

function range() {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), 1);
  const end = new Date(now.getFullYear(), now.getMonth() + 2, 0);
  return { start: isoDay(start), end: isoDay(end) };
}

function pickPoster(images?: ArrImage[], coverType = "poster") {
  if (!images?.length) return "";
  const hit = images.find((image) => image.coverType === coverType) || images[0];
  return hit?.remoteUrl || (hit?.url?.startsWith("http") ? hit.url : "") || "";
}

function resolveSources(config: Config): CalendarSource[] {
  const fromJson = (() => {
    if (!config.sourcesJson?.trim()) return [] as CalendarSource[];
    try {
      const parsed = JSON.parse(config.sourcesJson) as CalendarSource[];
      if (!Array.isArray(parsed)) return [];
      return parsed.filter((source) => source?.url && source?.key && source?.type);
    } catch {
      return [];
    }
  })();
  if (fromJson.length) return fromJson;

  if (Array.isArray(config.sources) && config.sources.length) {
    return config.sources.filter((source) => source?.url && source?.key && source?.type);
  }

  const fromFlat: CalendarSource[] = [];
  if (config.sonarrUrl && config.sonarrKey) {
    fromFlat.push({
      type: "sonarr",
      label: "Sonarr 1",
      color: "#2dd4bf",
      url: config.sonarrUrl,
      fallbackUrl: config.sonarrFallbackUrl,
      key: config.sonarrKey,
    });
  }
  if (config.sonarr2Url && config.sonarr2Key) {
    fromFlat.push({
      type: "sonarr",
      label: "Sonarr 2",
      color: "#67e8f9",
      url: config.sonarr2Url,
      fallbackUrl: config.sonarr2FallbackUrl,
      key: config.sonarr2Key,
    });
  }
  if (config.radarrUrl && config.radarrKey) {
    fromFlat.push({
      type: "radarr",
      label: "Radarr 1",
      color: "#fb923c",
      url: config.radarrUrl,
      fallbackUrl: config.radarrFallbackUrl,
      key: config.radarrKey,
    });
  }
  if (config.radarr2Url && config.radarr2Key) {
    fromFlat.push({
      type: "radarr",
      label: "Radarr 2",
      color: "#fbbf24",
      url: config.radarr2Url,
      fallbackUrl: config.radarr2FallbackUrl,
      key: config.radarr2Key,
    });
  }
  if (config.lidarrUrl && config.lidarrKey) {
    fromFlat.push({
      type: "lidarr",
      label: "Lidarr",
      color: "#c084fc",
      url: config.lidarrUrl,
      fallbackUrl: config.lidarrFallbackUrl,
      key: config.lidarrKey,
    });
  }
  if (config.seerrUrl && config.seerrKey) {
    fromFlat.push({
      type: "seerr",
      label: "Seerr",
      color: "#a78bfa",
      url: config.seerrUrl,
      fallbackUrl: config.seerrFallbackUrl,
      key: config.seerrKey,
    });
  }
  return fromFlat;
}

async function calFetch<T>(
  source: CalendarSource,
  path: string,
  headers: Record<string, string> = {},
): Promise<T> {
  const candidates = [source.url, source.fallbackUrl].filter(
    (value, index, list): value is string => Boolean(value) && list.indexOf(value) === index,
  );

  let lastError: unknown;
  for (const base of candidates) {
    try {
      const response = await fetch(joinUrl(base, path), {
        headers,
        cache: "no-store",
        signal: AbortSignal.timeout(10_000),
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return (await response.json()) as T;
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError instanceof Error ? lastError : new Error(`All URLs failed for ${source.label}`);
}

async function radarrEvents(source: CalendarSource) {
  const { start, end } = range();
  const data = await calFetch<
    Array<{
      id?: number;
      title?: string;
      titleSlug?: string;
      physicalRelease?: string;
      digitalRelease?: string;
      inCinemas?: string;
      releaseDate?: string;
      hasFile?: boolean;
      images?: ArrImage[];
    }>
  >(
    source,
    `/api/v3/calendar?start=${start}&end=${end}&unmonitored=true`,
    { "X-Api-Key": source.key },
  );

  const base = source.url.replace(/\/$/, "");
  return (Array.isArray(data) ? data : [])
    .map((movie) => {
      const date =
        movie.physicalRelease || movie.digitalRelease || movie.inCinemas || movie.releaseDate || "";
      if (!date) return null;
      return {
        id: `radarr-${source.label}-${movie.id || movie.titleSlug || movie.title}-${date}`,
        title: movie.title || "Untitled",
        date,
        type: "movie" as const,
        source: source.label,
        color: source.color,
        poster: pickPoster(movie.images),
        href: movie.titleSlug ? `${base}/movie/${movie.titleSlug}` : base,
        status: movie.hasFile ? 5 : 1,
      };
    })
    .filter(Boolean) as CalendarEvent[];
}

async function sonarrEvents(source: CalendarSource) {
  const { start, end } = range();
  const data = await calFetch<
    Array<{
      id?: number;
      title?: string;
      airDateUtc?: string;
      airDate?: string;
      seasonNumber?: number;
      episodeNumber?: number;
      hasFile?: boolean;
      series?: {
        id?: number;
        title?: string;
        titleSlug?: string;
        images?: ArrImage[];
      };
    }>
  >(
    source,
    `/api/v3/calendar?start=${start}&end=${end}&unmonitored=true&includeSeries=true`,
    { "X-Api-Key": source.key },
  );

  const base = source.url.replace(/\/$/, "");
  return (Array.isArray(data) ? data : [])
    .filter((ep) => ep.seasonNumber !== 0)
    .map((ep) => {
      const date = ep.airDateUtc || ep.airDate || "";
      if (!date) return null;
      const series = ep.series;
      const epCode =
        ep.seasonNumber != null && ep.episodeNumber != null
          ? `S${String(ep.seasonNumber).padStart(2, "0")}E${String(ep.episodeNumber).padStart(2, "0")}`
          : "";
      return {
        id: `sonarr-${source.label}-${ep.id || `${series?.id}-${epCode}`}-${date}`,
        title: series?.title || "Unknown",
        subtitle: [epCode, ep.title].filter(Boolean).join(" · "),
        date,
        type: "episode" as const,
        source: source.label,
        color: source.color,
        poster: pickPoster(series?.images),
        href: series?.titleSlug ? `${base}/series/${series.titleSlug}` : base,
        status: ep.hasFile ? 5 : 1,
      };
    })
    .filter(Boolean) as CalendarEvent[];
}

async function lidarrEvents(source: CalendarSource) {
  const { start, end } = range();
  const data = await calFetch<
    Array<{
      id?: number;
      title?: string;
      releaseDate?: string;
      artistName?: string;
      images?: ArrImage[];
      artist?: {
        artistName?: string;
        foreignArtistId?: string;
        id?: number;
      };
    }>
  >(source, `/api/v1/calendar?start=${start}&end=${end}&unmonitored=true`, {
    "X-Api-Key": source.key,
  });

  const base = source.url.replace(/\/$/, "");
  return (Array.isArray(data) ? data : [])
    .map((album) => {
      const date = album.releaseDate || "";
      if (!date) return null;
      const artistId = album.artist?.foreignArtistId || album.artist?.id;
      return {
        id: `lidarr-${source.label}-${album.id || album.title}-${date}`,
        title: album.artist?.artistName || album.artistName || "Unknown",
        subtitle: album.title,
        date,
        type: "album" as const,
        source: source.label,
        color: source.color,
        poster: pickPoster(album.images, "cover"),
        href: artistId ? `${base}/artist/${artistId}` : base,
        status: 5,
      };
    })
    .filter(Boolean) as CalendarEvent[];
}

async function seerrEvents(source: CalendarSource) {
  const now = new Date();
  const oneMonthAgo = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const twoMonthsAhead = new Date(now.getFullYear(), now.getMonth() + 3, 0);
  const events: CalendarEvent[] = [];
  const seen = new Set<string>();
  const base = source.url.replace(/\/$/, "");

  async function fetchDiscoverPages(endpoint: string, kind: "movie" | "tv") {
    let page = 1;
    let totalPages = 1;
    while (page <= totalPages && page <= 5) {
      const data = await calFetch<{
        totalPages?: number;
        results?: Array<{
          id?: number;
          title?: string;
          name?: string;
          releaseDate?: string;
          firstAirDate?: string;
          posterPath?: string;
          mediaInfo?: { status?: number };
        }>;
      }>(source, `/api/v1${endpoint}?page=${page}`, { "X-Api-Key": source.key });

      totalPages = data.totalPages || 1;
      for (const item of data.results || []) {
        const releaseStr = kind === "movie" ? item.releaseDate : item.firstAirDate;
        if (!releaseStr) continue;
        const date = new Date(releaseStr);
        if (Number.isNaN(date.getTime()) || date < oneMonthAgo || date > twoMonthsAhead) continue;
        const id = `seerr-${kind}-${item.id || item.title || item.name}-${releaseStr}`;
        if (seen.has(id)) continue;
        seen.add(id);
        events.push({
          id,
          title: item.title || item.name || "Unknown",
          subtitle: kind === "movie" ? "Upcoming Movie" : "Upcoming Series",
          date: releaseStr,
          type: kind === "movie" ? "movie" : "episode",
          source: kind === "movie" ? "Seerr · Movie" : "Seerr · Series",
          color: kind === "movie" ? source.color : "#a78bfa",
          poster: item.posterPath ? `https://image.tmdb.org/t/p/w200${item.posterPath}` : "",
          href: `${base}/${kind === "movie" ? "movie" : "tv"}/${item.id}`,
          status: item.mediaInfo?.status ?? 0,
        });
      }
      page += 1;
    }
  }

  await Promise.allSettled([
    fetchDiscoverPages("/discover/movies/upcoming", "movie"),
    fetchDiscoverPages("/discover/tv/upcoming", "tv"),
  ]);

  return events;
}

async function fetchSourceEvents(source: CalendarSource) {
  if (source.type === "radarr") return radarrEvents(source);
  if (source.type === "sonarr") return sonarrEvents(source);
  if (source.type === "lidarr") return lidarrEvents(source);
  if (source.type === "seerr") return seerrEvents(source);
  return [] as CalendarEvent[];
}

export async function calendarStatus(id: string) {
  const config = (await readWidgetConfig(id)) as Config;
  const sources = resolveSources(config);

  if (!sources.length) {
    throw new Error("Configure calendar sources in Settings");
  }

  const results = await Promise.allSettled(sources.map((source) => fetchSourceEvents(source)));
  const seenIds = new Set<string>();
  const events = results
    .flatMap((result) => (result.status === "fulfilled" ? result.value : []))
    .filter((event) => {
      if (seenIds.has(event.id)) return false;
      seenIds.add(event.id);
      return true;
    })
    .sort((a, b) => a.date.localeCompare(b.date));

  const failed = results.filter((result) => result.status === "rejected").length;

  const primarySource = sources.find((source) => source.type === "seerr") || sources[0];
  return {
    events,
    href: primarySource?.url || "",
    openFallbackUrl: primarySource?.fallbackUrl || "",
    sources: sources.map((source) => ({ label: source.label, color: source.color })),
    degraded: failed > 0 && failed < sources.length,
    failed,
  };
}
