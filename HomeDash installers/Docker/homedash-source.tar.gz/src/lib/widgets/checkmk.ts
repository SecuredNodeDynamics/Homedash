import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, hasConnectionUrl, primaryConnectionUrl } from "@/lib/open-href";

type CheckmkConfig = {
  baseUrl?: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  username?: string;
  password?: string;
  apiKey?: string;
  siteName?: string;
  topProblems?: string;
};

export type CheckmkProblem = {
  host: string;
  description: string;
  output: string;
  state: number;
  acknowledged: boolean;
  changed: number;
};

export type CheckmkHost = {
  name: string;
  state: number;
  acknowledged: boolean;
  address: string;
};

export type CheckmkStatus = {
  href: string;
  openFallbackUrl: string;
  hosts: { up: number; down: number; unreach: number; unknown: number; total: number };
  hostList: CheckmkHost[];
  problems: CheckmkProblem[];
  summary: { warn: number; crit: number; unknown: number };
};

const num = (value: unknown) => Number(value) || 0;

function authHeader(cfg: CheckmkConfig) {
  const username = cfg.username?.trim();
  const password = cfg.password?.trim() || cfg.apiKey?.trim();
  if (username && password) return `Bearer ${username} ${password}`;
  if (password) return `Bearer ${password}`;
  return "";
}

export async function fetchCheckmkStatus(instanceId: string): Promise<CheckmkStatus> {
  const cfg = (await readWidgetConfig(instanceId)) as CheckmkConfig;
  const auth = authHeader(cfg);
  if (!hasConnectionUrl(cfg) || !auth) {
    throw new Error(
      "Configure a Private - IP or Fallback Public URL, username, and password in Settings",
    );
  }
  const baseUrl = primaryConnectionUrl(cfg);

  const site = (cfg.siteName || "monitoring").trim() || "monitoring";
  const topProblems = Math.max(1, Number(cfg.topProblems || 10) || 10);
  const bases = connectionCandidates(cfg);
  let lastError: unknown;

  for (const base of bases) {
    try {
      const api = joinUrl(base, `/${site}/check_mk/api/1.0`);
      const request = async (path: string) => {
        const response = await fetch(`${api}${path}`, {
          headers: {
            Authorization: auth,
            Accept: "application/json",
          },
          cache: "no-store",
          signal: AbortSignal.timeout(8_000),
        });
        if (!response.ok) {
          const body = await response.text().catch(() => "");
          throw new Error(`Checkmk HTTP ${response.status}${body ? ` — ${body.slice(0, 120)}` : ""}`);
        }
        return response.json();
      };

      const query = encodeURIComponent(JSON.stringify({ op: "!=", left: "state", right: "0" }));
      const [hosts, services] = await Promise.all([
        request(
          "/domain-types/host/collections/all?columns=name&columns=state&columns=acknowledged&columns=address",
        ),
        request(
          `/domain-types/service/collections/all?columns=host_name&columns=description&columns=state&columns=plugin_output&columns=acknowledged&columns=last_state_change&query=${query}`,
        ),
      ]);

      const rawHosts = Array.isArray(hosts?.value) ? hosts.value : [];
      const hostList: CheckmkHost[] = rawHosts
        .map((item: { extensions?: Record<string, unknown>; id?: string; title?: string }) => {
          const e = item.extensions || {};
          return {
            name: String(e.name || item.id || item.title || "?"),
            state: num(e.state ?? e.host_state),
            acknowledged: Boolean(e.acknowledged),
            address: String(e.address || ""),
          };
        })
        .sort((a: CheckmkHost, b: CheckmkHost) => a.state - b.state || a.name.localeCompare(b.name));

      const counts = { up: 0, down: 0, unreach: 0, unknown: 0, total: hostList.length };
      for (const item of hostList) {
        if (item.state === 0) counts.up++;
        else if (item.state === 1) counts.down++;
        else if (item.state === 2) counts.unreach++;
        else counts.unknown++;
      }

      const problems: CheckmkProblem[] = (Array.isArray(services?.value) ? services.value : [])
        .map((item: { extensions?: Record<string, unknown> }) => {
          const e = item.extensions || {};
          return {
            host: String(e.host_name || "?"),
            description: String(e.description || "?"),
            output: String(e.plugin_output || ""),
            state: num(e.state),
            acknowledged: Boolean(e.acknowledged),
            changed: num(e.last_state_change),
          };
        })
        .filter((item: CheckmkProblem) => item.state !== 0)
        .sort((a: CheckmkProblem, b: CheckmkProblem) => b.state - a.state || b.changed - a.changed)
        .slice(0, topProblems);

      const summary = problems.reduce(
        (total, item) => {
          if (item.state === 1) total.warn++;
          else if (item.state === 2) total.crit++;
          else total.unknown++;
          return total;
        },
        { warn: 0, crit: 0, unknown: 0 },
      );

      const openFallbackBase = cfg.openFallbackUrl?.trim() || cfg.fallbackUrl?.trim() || "";
      return {
        href: cfg.publicUrl?.trim() || joinUrl(baseUrl, `/${site}/check_mk/`),
        openFallbackUrl: openFallbackBase ? joinUrl(openFallbackBase, `/${site}/check_mk/`) : "",
        hosts: counts,
        hostList,
        problems,
        summary,
      };
    } catch (error) {
      lastError = error;
    }
  }

  throw lastError instanceof Error ? lastError : new Error("Checkmk unavailable");
}
