import { readWidgetConfig } from "@/lib/config";

type WidgetConfig = Record<string, string>;

async function within<T>(promise: Promise<T>, ms: number, fallback: T): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      promise,
      new Promise<T>((resolve) => {
        timer = setTimeout(() => resolve(fallback), ms);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

type Analytics = {
  requests: number;
  bytes: number;
  cachedRequests: number;
  uniques: number;
  threats: number;
  threatTypes: Array<{ name: string; count: number }>;
  threatCountries: Array<{ name: string; count: number }>;
  hostBreakdown: Array<{ host: string; requests: number }>;
};

export type CloudflareStatus = {
  dashboardUrl: string;
  tunnel: { name: string; status: string; createdAt: string | null };
  connections: Array<{ id: string; name: string; active: boolean }>;
  zones: Array<{ id: string; name: string; active: boolean; analytics: Analytics | null }>;
};

const DEFAULT_ORIGIN_MAP: Record<string, string> = {
  "5adb7502-76a1-4273-9837-0e1078a924d8": "proxmox1",
  "bf7b5db4-f01f-45db-9254-6d98d3d0ad8d": "proxmox2",
  "c0175ee5-59a5-4db9-8fc5-0f90767b4a18": "proxmox3",
};

const THREAT_SOURCE_LABELS: Record<string, string> = {
  bic: "Bot Fight Mode",
  botnet: "Botnet Protection",
  firewallrules: "Custom Firewall Rules",
  l7ddos: "L7 DDoS",
  ratelimit: "Rate Limiting",
  securitylevel: "Security Level",
  managedrules: "WAF Managed Rules",
  uniques: "Unique Rules",
  uaBlock: "UA Block",
  country: "Country Blocking",
  ip: "IP Access Rules",
  waf: "WAF",
  asp: "ASP",
  hot: "Hotlink Protection",
  sanitize: "Sanitization",
};

const THREAT_ACTION_LABELS: Record<string, string> = {
  block: "Blocked",
  challenge: "Challenged",
  jschallenge: "JS Challenge",
  managed_challenge: "Managed Challenge",
  log: "Logged",
  allow: "Allowed",
  bypass: "Bypassed",
  connectionClose: "Connection Closed",
  forceConnectionClose: "Force Close",
};

function proxyUrl(baseUrl: string, path: string) {
  const url = new URL(baseUrl);
  url.searchParams.set("path", path);
  return url.toString();
}

async function cloudflareRequest<T>(
  baseUrl: string,
  path: string,
  token: string | undefined,
  body?: unknown,
): Promise<T> {
  const response = await fetch(proxyUrl(baseUrl, path), {
    method: body ? "POST" : "GET",
    headers: {
      Accept: "application/json",
      ...(body ? { "Content-Type": "application/json" } : {}),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
    cache: "no-store",
    signal: AbortSignal.timeout(10_000),
  });
  if (!response.ok) throw new Error(`Cloudflare proxy HTTP ${response.status}`);
  const data = (await response.json()) as {
    success?: boolean;
    errors?: Array<{ message?: string }> | null;
  } & T;
  if (data.success === false) {
    throw new Error(
      (Array.isArray(data.errors) && data.errors[0]?.message) || "Cloudflare API error",
    );
  }
  return data;
}

async function cfGraphql<T>(
  baseUrl: string,
  token: string | undefined,
  query: string,
): Promise<T> {
  const data = await cloudflareRequest<{
    data?: T;
    errors?: Array<{ message?: string }> | null;
  }>(baseUrl, "/client/v4/graphql", token, { query });
  return (data.data || {}) as T;
}

function titleCase(value: string) {
  return value
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .replace(/[_-]+/g, " ")
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function humanizeThreatLabel(source: string, action: string) {
  const src =
    THREAT_SOURCE_LABELS[source] || (source ? titleCase(source) : "");
  const act =
    THREAT_ACTION_LABELS[action] || (action ? titleCase(action) : "");
  return [src, act].filter(Boolean).join(" · ") || "Blocked / mitigated";
}

function parseOriginMap(raw: string | undefined) {
  if (!raw?.trim()) return { ...DEFAULT_ORIGIN_MAP };
  try {
    const parsed = JSON.parse(raw) as Record<string, string>;
    return { ...DEFAULT_ORIGIN_MAP, ...parsed };
  } catch {
    return { ...DEFAULT_ORIGIN_MAP };
  }
}

async function fetchThreatDetails(
  baseUrl: string,
  token: string | undefined,
  zoneId: string,
): Promise<{ bySource: Record<string, number>; byCountry: Record<string, number> }> {
  const until = new Date().toISOString();
  const since = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
  const details = { bySource: {} as Record<string, number>, byCountry: {} as Record<string, number> };

  try {
    const data = await cfGraphql<{
      viewer?: {
        zones?: Array<{
          firewallEventsAdaptiveGroups?: Array<{
            count?: number;
            dimensions?: { source?: string; action?: string; clientCountryName?: string };
          }>;
        }>;
      };
    }>(
      baseUrl,
      token,
      `{
  viewer {
    zones(filter: { zoneTag: "${zoneId}" }) {
      firewallEventsAdaptiveGroups(
        limit: 20,
        orderBy: [count_DESC],
        filter: { datetime_geq: "${since}", datetime_leq: "${until}" }
      ) {
        count
        dimensions { source action clientCountryName }
      }
    }
  }
}`,
    );
    for (const group of data.viewer?.zones?.[0]?.firewallEventsAdaptiveGroups || []) {
      const count = Number(group.count) || 0;
      if (count <= 0) continue;
      const label = humanizeThreatLabel(
        String(group.dimensions?.source || "").trim(),
        String(group.dimensions?.action || "").trim(),
      );
      details.bySource[label] = (details.bySource[label] || 0) + count;
      const country = String(group.dimensions?.clientCountryName || "").trim();
      if (country) details.byCountry[country] = (details.byCountry[country] || 0) + count;
    }
  } catch {
    // Token may lack firewall analytics scope — keep totals from httpRequests.
  }

  if (!Object.keys(details.bySource).length) {
    try {
      const data = await cfGraphql<{
        viewer?: {
          zones?: Array<{
            httpRequestsAdaptiveGroups?: Array<{
              count?: number;
              dimensions?: { securityAction?: string; clientCountryName?: string };
            }>;
          }>;
        };
      }>(
        baseUrl,
        token,
        `{
  viewer {
    zones(filter: { zoneTag: "${zoneId}" }) {
      httpRequestsAdaptiveGroups(
        limit: 15,
        orderBy: [count_DESC],
        filter: {
          datetime_geq: "${since}",
          datetime_leq: "${until}",
          AND: [
            { securityAction_neq: "unknown" },
            { securityAction_neq: "allow" }
          ]
        }
      ) {
        count
        dimensions { securityAction clientCountryName }
      }
    }
  }
}`,
      );
      for (const group of data.viewer?.zones?.[0]?.httpRequestsAdaptiveGroups || []) {
        const count = Number(group.count) || 0;
        if (count <= 0) continue;
        const action = String(group.dimensions?.securityAction || "").trim();
        if (!action || action === "allow" || action === "unknown") continue;
        const label = humanizeThreatLabel("", action);
        details.bySource[label] = (details.bySource[label] || 0) + count;
        const country = String(group.dimensions?.clientCountryName || "").trim();
        if (country) details.byCountry[country] = (details.byCountry[country] || 0) + count;
      }
    } catch {
      // optional breakdown
    }
  }

  return details;
}

async function fetchHostBreakdown(
  baseUrl: string,
  token: string | undefined,
  zoneId: string,
): Promise<Array<{ host: string; requests: number }>> {
  const until = new Date().toISOString();
  const since = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();

  try {
    const data = await cfGraphql<{
      viewer?: {
        zones?: Array<{
          httpRequestsAdaptiveGroups?: Array<{
            count?: number;
            dimensions?: { clientRequestHTTPHost?: string };
          }>;
        }>;
      };
    }>(
      baseUrl,
      token,
      `{
  viewer {
    zones(filter: { zoneTag: "${zoneId}" }) {
      httpRequestsAdaptiveGroups(
        limit: 25,
        orderBy: [count_DESC],
        filter: { datetime_geq: "${since}", datetime_leq: "${until}" }
      ) {
        count
        dimensions { clientRequestHTTPHost }
      }
    }
  }
}`,
    );
    const byHost: Record<string, number> = {};
    for (const group of data.viewer?.zones?.[0]?.httpRequestsAdaptiveGroups || []) {
      const host = String(group.dimensions?.clientRequestHTTPHost || "").trim();
      const count = Number(group.count) || 0;
      if (!host || count <= 0) continue;
      byHost[host] = (byHost[host] || 0) + count;
    }
    return Object.entries(byHost)
      .sort(([, a], [, b]) => b - a)
      .map(([host, requests]) => ({ host, requests }));
  } catch {
    // Token may lack the analytics scope needed for this dimension — the
    // widget just won't have a host-level breakdown for this zone.
    return [];
  }
}

async function zoneAnalytics(
  baseUrl: string,
  token: string | undefined,
  zoneId: string,
): Promise<Analytics | null> {
  const today = new Date().toISOString().slice(0, 10);
  const dayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().slice(0, 10);

  try {
    const data = await cfGraphql<{
      viewer?: {
        zones?: Array<{
          httpRequests1dGroups?: Array<{
            sum?: {
              requests?: number;
              bytes?: number;
              cachedRequests?: number;
              threats?: number;
            };
            uniq?: { uniques?: number };
          }>;
        }>;
      };
    }>(
      baseUrl,
      token,
      `{
  viewer {
    zones(filter: { zoneTag: "${zoneId}" }) {
      httpRequests1dGroups(
        limit: 1,
        orderBy: [sum_requests_DESC],
        filter: { date_geq: "${dayAgo}", date_leq: "${today}" }
      ) {
        sum { requests bytes cachedRequests threats }
        uniq { uniques }
      }
    }
  }
}`,
    );

    const groups = data.viewer?.zones?.[0]?.httpRequests1dGroups || [];
    if (!groups.length) return null;

    const totals = groups.reduce(
      (acc, group) => ({
        requests: acc.requests + (Number(group.sum?.requests) || 0),
        bytes: acc.bytes + (Number(group.sum?.bytes) || 0),
        cachedRequests: acc.cachedRequests + (Number(group.sum?.cachedRequests) || 0),
        threats: acc.threats + (Number(group.sum?.threats) || 0),
        uniques: acc.uniques + (Number(group.uniq?.uniques) || 0),
      }),
      { requests: 0, bytes: 0, cachedRequests: 0, threats: 0, uniques: 0 },
    );

    const threatDetails =
      totals.threats > 0
        ? await fetchThreatDetails(baseUrl, token, zoneId)
        : { bySource: {}, byCountry: {} };
    const hostBreakdown =
      totals.requests > 0 ? await fetchHostBreakdown(baseUrl, token, zoneId) : [];

    const threatTypes = Object.entries(threatDetails.bySource)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 6)
      .map(([name, count]) => ({ name, count }));
    const threatCountries = Object.entries(threatDetails.byCountry)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 5)
      .map(([name, count]) => ({ name, count }));

    return {
      requests: totals.requests,
      bytes: totals.bytes,
      cachedRequests: totals.cachedRequests,
      uniques: totals.uniques,
      threats: totals.threats,
      threatTypes,
      threatCountries,
      hostBreakdown,
    };
  } catch {
    return null;
  }
}

async function fetchZones(baseUrl: string, accountId: string, token: string | undefined) {
  const attempts = [
    `/client/v4/zones?account.id=${encodeURIComponent(accountId)}&per_page=50`,
    `/client/v4/zones?per_page=50`,
    `/client/v4/zones?account_id=${encodeURIComponent(accountId)}&per_page=50`,
  ];
  for (const path of attempts) {
    try {
      const data = await cloudflareRequest<{ result?: unknown[] }>(baseUrl, path, token);
      if (Array.isArray(data.result) && data.result.length) return data.result;
    } catch {
      // try next
    }
  }
  return [];
}

export async function fetchCloudflareStatus(instanceId: string): Promise<CloudflareStatus> {
  const config = (await readWidgetConfig(instanceId)) as WidgetConfig;
  const baseUrl = (config.proxyUrl || config.proxyBase || config.baseUrl || "").trim();
  const accountId = config.accountId?.trim();
  const tunnelId = config.tunnelId?.trim();
  const token = config.apiToken?.trim() || config.token?.trim();
  const originMap = parseOriginMap(config.originMap);
  if (!baseUrl || !accountId || !tunnelId) {
    throw new Error("Configure the Cloudflare proxy URL, account ID, and tunnel ID in Settings");
  }

  const [tunnelResponse, connectionResponse, rawZones] = await Promise.all([
    cloudflareRequest<{ result?: Record<string, unknown> }>(
      baseUrl,
      `/client/v4/accounts/${encodeURIComponent(accountId)}/cfd_tunnel/${encodeURIComponent(tunnelId)}`,
      token,
    ),
    cloudflareRequest<{ result?: Array<Record<string, unknown>> }>(
      baseUrl,
      `/client/v4/accounts/${encodeURIComponent(accountId)}/cfd_tunnel/${encodeURIComponent(tunnelId)}/connections`,
      token,
    ).catch(() => ({ result: [] })),
    within(fetchZones(baseUrl, accountId, token), 11_000, []),
  ]);

  const tunnel = tunnelResponse.result || {};
  const rawConnections = (connectionResponse.result || []).flatMap((connector) =>
    ((connector.conns as Array<Record<string, unknown>> | undefined) || []).map(
      (connection): Record<string, unknown> & { connectorId: string } => ({
        ...connection,
        connectorId: String(connector.id || ""),
      }),
    ),
  );

  const connections = rawConnections
    .filter(
      (connection, index, list) =>
        list.findIndex((candidate) => candidate.connectorId === connection.connectorId) === index,
    )
    .sort((a, b) => {
      const nameA = originMap[a.connectorId] || "";
      const nameB = originMap[b.connectorId] || "";
      return nameA.localeCompare(nameB);
    })
    .map((connection) => ({
      id: connection.connectorId || String(connection.id || ""),
      name:
        originMap[connection.connectorId] ||
        String(connection.colo_name || connection.origin_ip || connection.connectorId || "edge"),
      active: connection.is_pending_reconnect !== true,
    }));

  const zones = await within(Promise.all(
    rawZones.map(async (zone) => {
      const record = zone as Record<string, unknown>;
      const id = String(record.id || "");
      return {
        id,
        name: String(record.name || ""),
        active: record.status === "active",
        analytics: id ? await zoneAnalytics(baseUrl, token, id) : null,
      };
    }),
  ), 12_000, rawZones.map((zone) => {
    const record = zone as Record<string, unknown>;
    return {
      id: String(record.id || ""),
      name: String(record.name || ""),
      active: record.status === "active",
      analytics: null,
    };
  }));

  return {
    dashboardUrl:
      config.publicUrl?.trim() ||
      config.dashboardUrl?.trim() ||
      `https://dash.cloudflare.com/${encodeURIComponent(accountId)}/home/overview`,
    tunnel: {
      name: String(tunnel.name || "Tunnel"),
      status: String(tunnel.status || "unknown"),
      createdAt: typeof tunnel.created_at === "string" ? tunnel.created_at : null,
    },
    connections,
    zones,
  };
}
