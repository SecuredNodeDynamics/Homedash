export type DebugSeverity = "critical" | "high" | "medium" | "low" | "info";
export type DebugFinding = {
  id: string;
  file: string;
  line: number;
  severity: DebugSeverity;
  category: "security" | "bug" | "quality" | "performance";
  title: string;
  detail: string;
  remediation: string;
  excerpt: string;
};

export type DebugFile = { name: string; content: string };

type Rule = {
  id: string;
  pattern: RegExp;
  severity: DebugSeverity;
  category: DebugFinding["category"];
  title: string;
  detail: string;
  remediation: string;
};

const RULES: Rule[] = [
  { id: "private-key", pattern: /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/g, severity: "critical", category: "security", title: "Private key embedded in source", detail: "A private signing or SSH key appears to be committed with the code.", remediation: "Revoke and rotate the key immediately, remove it from history, and load secrets from a protected secret store." },
  { id: "hardcoded-secret", pattern: /\b(?:api[_-]?key|secret|password|passwd|token)\b\s*[:=]\s*["'`][^"'`\n]{8,}["'`]/gi, severity: "critical", category: "security", title: "Potential hardcoded credential", detail: "Credentials in source can leak through repositories, logs, builds, and client bundles.", remediation: "Rotate the value and replace it with an environment variable or managed secret." },
  { id: "eval", pattern: /\beval\s*\(/g, severity: "high", category: "security", title: "Dynamic code execution", detail: "eval() can turn untrusted input into executable code and complicates auditing.", remediation: "Replace dynamic evaluation with explicit parsing, lookup tables, or validated structured data." },
  { id: "function-constructor", pattern: /\bnew\s+Function\s*\(/g, severity: "high", category: "security", title: "Function constructor execution", detail: "The Function constructor has injection risks similar to eval().", remediation: "Use explicit functions and a strict allowlist of supported operations." },
  { id: "html-injection", pattern: /\.(?:innerHTML|outerHTML)\s*=|dangerouslySetInnerHTML/g, severity: "high", category: "security", title: "HTML injection sink", detail: "Untrusted content reaching this sink may execute script or malicious markup.", remediation: "Render text safely or sanitize HTML with a proven allowlist sanitizer before insertion." },
  { id: "command-shell", pattern: /\b(?:exec|execSync|system|Runtime\.getRuntime\(\)\.exec)\s*\(/g, severity: "high", category: "security", title: "Operating-system command execution", detail: "Shell commands can become command-injection vulnerabilities when arguments contain user input.", remediation: "Avoid a shell, pass validated arguments as an array, and enforce strict allowlists." },
  { id: "sql-concat", pattern: /\b(?:SELECT|INSERT|UPDATE|DELETE)\b[^;\n]*(?:\+|\$\{)/gi, severity: "high", category: "security", title: "Possible SQL injection", detail: "The query appears to be assembled through string interpolation or concatenation.", remediation: "Use parameterized statements or a query builder that binds values separately." },
  { id: "weak-hash", pattern: /\b(?:md5|sha1)\b/gi, severity: "medium", category: "security", title: "Weak cryptographic hash", detail: "MD5 and SHA-1 are unsuitable for passwords, signatures, and collision-resistant security decisions.", remediation: "Use Argon2id/bcrypt/scrypt for passwords and SHA-256 or stronger where a general cryptographic hash is required." },
  { id: "insecure-http", pattern: /["'`]http:\/\/(?!localhost|127\.0\.0\.1|\[::1\])/gi, severity: "medium", category: "security", title: "Unencrypted HTTP endpoint", detail: "Traffic and credentials can be observed or altered in transit.", remediation: "Use HTTPS and validate certificates." },
  { id: "open-cors", pattern: /access-control-allow-origin["']?\s*[:,]\s*["']\*|cors\s*\(\s*\)/gi, severity: "medium", category: "security", title: "Overly broad cross-origin access", detail: "A wildcard origin can expose responses to any website.", remediation: "Allow only trusted origins and review whether credentials are permitted." },
  { id: "tls-disabled", pattern: /rejectUnauthorized\s*:\s*false|NODE_TLS_REJECT_UNAUTHORIZED\s*=\s*["']?0/gi, severity: "high", category: "security", title: "TLS verification disabled", detail: "Disabling certificate verification permits man-in-the-middle attacks.", remediation: "Install the appropriate CA certificate and keep verification enabled." },
  { id: "empty-catch", pattern: /catch\s*(?:\([^)]*\))?\s*\{\s*\}/g, severity: "medium", category: "bug", title: "Silently swallowed exception", detail: "An empty catch block hides failures and leaves the application in an unknown state.", remediation: "Handle the expected error explicitly or log and rethrow unexpected failures." },
  { id: "loose-equality", pattern: /(^|[^=!])==([^=]|$)|(^|[^!])!=([^=]|$)/gm, severity: "low", category: "bug", title: "Loose equality comparison", detail: "Implicit type coercion can produce surprising comparisons.", remediation: "Prefer strict equality (=== and !==) unless coercion is deliberate and documented." },
  { id: "console", pattern: /\bconsole\.(?:log|debug)\s*\(/g, severity: "info", category: "quality", title: "Debug logging remains", detail: "Debug output may expose internal data and create noisy production logs.", remediation: "Remove it or route structured messages through the application logger with appropriate levels." },
  { id: "todo", pattern: /\b(?:TODO|FIXME|HACK)\b/g, severity: "info", category: "quality", title: "Unresolved engineering note", detail: "The code contains a marker for unfinished or risky work.", remediation: "Convert the note into a tracked issue with an owner and remove stale markers." },
];

function lineFor(content: string, index: number) {
  return content.slice(0, index).split("\n").length;
}

export function analyzeCode(files: DebugFile[]) {
  const findings: DebugFinding[] = [];
  for (const file of files) {
    for (const rule of RULES) {
      const pattern = new RegExp(rule.pattern.source, rule.pattern.flags);
      for (const match of file.content.matchAll(pattern)) {
        const index = match.index || 0;
        const line = lineFor(file.content, index);
        const sourceLine = file.content.split("\n")[line - 1]?.trim() || "";
        findings.push({
          id: `${file.name}:${rule.id}:${line}:${index}`,
          file: file.name,
          line,
          severity: rule.severity,
          category: rule.category,
          title: rule.title,
          detail: rule.detail,
          remediation: rule.remediation,
          excerpt: sourceLine.slice(0, 240),
        });
      }
    }
  }
  const rank: Record<DebugSeverity, number> = { critical: 0, high: 1, medium: 2, low: 3, info: 4 };
  findings.sort((a, b) => rank[a.severity] - rank[b.severity] || a.file.localeCompare(b.file) || a.line - b.line);
  const counts = Object.fromEntries(
    (["critical", "high", "medium", "low", "info"] as DebugSeverity[])
      .map((severity) => [severity, findings.filter((finding) => finding.severity === severity).length]),
  ) as Record<DebugSeverity, number>;
  const score = Math.max(0, 100 - counts.critical * 30 - counts.high * 18 - counts.medium * 8 - counts.low * 3);
  return { findings: findings.slice(0, 300), counts, score, lines: files.reduce((sum, file) => sum + file.content.split("\n").length, 0) };
}

export function redactCode(content: string) {
  return content
    .replace(/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----[\s\S]*?-----END (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/g, "[REDACTED PRIVATE KEY]")
    .replace(/(\b(?:api[_-]?key|secret|password|passwd|token)\b\s*[:=]\s*["'`])[^"'`\n]+(["'`])/gi, "$1[REDACTED]$2");
}
