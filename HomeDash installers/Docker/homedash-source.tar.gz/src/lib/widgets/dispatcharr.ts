import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, hasConnectionUrl, openUrlsFromConfig, primaryConnectionUrl } from "@/lib/open-href";

type Config = {
  baseUrl: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  username?: string;
  password?: string;
  apiKey?: string;
};

type TokenCache = { token: string; expires: number };
const tokenCache = new Map<string, TokenCache>();

async function loadConfig(id: string) {
  const value = (await readWidgetConfig(id)) as Partial<Config>;
  if (!hasConnectionUrl(value)) {
    throw new Error("Configure a Private - IP or Fallback Public URL in Settings");
  }
  return { ...value, baseUrl: primaryConnectionUrl(value) } as Config;
}

async function login(cfg: Config, base: string) {
  if (!cfg.username || !cfg.password) {
    throw new Error("Configure Dispatcharr username and password in Settings");
  }
  const res = await fetch(joinUrl(base, "/api/accounts/token/"), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username: cfg.username, password: cfg.password }),
    cache: "no-store",
    signal: AbortSignal.timeout(10_000),
  });
  if (!res.ok) throw new Error(`Login failed (${res.status})`);
  const json = (await res.json()) as { access?: string };
  if (!json.access) throw new Error("Dispatcharr login returned no token");
  return json.access;
}

async function authHeaders(instanceId: string, cfg: Config, base: string) {
  if (cfg.apiKey) return { Authorization: `Bearer ${cfg.apiKey}` } as HeadersInit;
  const cacheKey = `${instanceId}:${base}`;
  const cached = tokenCache.get(cacheKey);
  if (cached && Date.now() < cached.expires) {
    return { Authorization: `Bearer ${cached.token}` } as HeadersInit;
  }
  const token = await login(cfg, base);
  tokenCache.set(cacheKey, { token, expires: Date.now() + 4.5 * 60_000 });
  return { Authorization: `Bearer ${token}` } as HeadersInit;
}

async function request<T>(instanceId: string, cfg: Config, path: string): Promise<T> {
  let last: unknown;
  for (const base of connectionCandidates(cfg)) {
    try {
      const headers = await authHeaders(instanceId, cfg, base);
      const res = await fetch(joinUrl(base, path), {
        headers,
        cache: "no-store",
        signal: AbortSignal.timeout(12_000),
      });
      if (res.status === 401) {
        tokenCache.delete(`${instanceId}:${base}`);
        const retryHeaders = await authHeaders(instanceId, cfg, base);
        const retry = await fetch(joinUrl(base, path), {
          headers: retryHeaders,
          cache: "no-store",
          signal: AbortSignal.timeout(12_000),
        });
        if (!retry.ok) throw new Error(`HTTP ${retry.status}`);
        return retry.json() as Promise<T>;
      }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return res.json() as Promise<T>;
    } catch (error) {
      last = error;
    }
  }
  throw last instanceof Error ? last : new Error("Dispatcharr unavailable");
}

function asList(value: unknown): unknown[] {
  if (Array.isArray(value)) return value;
  if (value && typeof value === "object") {
    const obj = value as { results?: unknown[]; data?: unknown[]; recordings?: unknown[] };
    if (Array.isArray(obj.results)) return obj.results;
    if (Array.isArray(obj.data)) return obj.data;
    if (Array.isArray(obj.recordings)) return obj.recordings;
  }
  return [];
}

export async function dispatcharrStatus(instanceId: string) {
  const cfg = await loadConfig(instanceId);
  const [recordings, channels] = await Promise.all([
    request<unknown>(instanceId, cfg, "/api/channels/recordings/").catch(() => []),
    request<unknown>(instanceId, cfg, "/api/channels/channels/").catch(() => []),
  ]);
  const recordingList = asList(recordings);
  const channelList = asList(channels);
  const active = recordingList.filter((item) => {
    const status = String((item as { status?: string }).status || "").toLowerCase();
    return status.includes("record") || status.includes("progress") || status === "active";
  }).length;

  return {
    ...openUrlsFromConfig(cfg),
    recordings: recordingList.length,
    channels: channelList.length,
    active,
    items: recordingList.slice(0, 8).map((item) => {
      const row = item as { name?: string; title?: string; channel?: string; status?: string };
      return {
        title: row.title || row.name || "Recording",
        meta: [row.channel, row.status].filter(Boolean).join(" · "),
      };
    }),
  };
}
