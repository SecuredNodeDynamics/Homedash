export type DockerExecTicket = {
  ticket: string;
  instanceId: string;
  containerId: string;
  execId: string;
  provider: "engine" | "portainer";
  baseUrl: string;
  endpointId: string;
  apiKey: string;
  expiresAt: number;
};

type TicketStore = Map<string, DockerExecTicket>;

function store(): TicketStore {
  const g = globalThis as typeof globalThis & { __hdDockerExecTickets?: TicketStore };
  if (!g.__hdDockerExecTickets) g.__hdDockerExecTickets = new Map();
  return g.__hdDockerExecTickets;
}

export function putDockerExecTicket(ticket: DockerExecTicket) {
  store().set(ticket.ticket, ticket);
}

export function takeDockerExecTicket(ticketId: string): DockerExecTicket | null {
  const id = String(ticketId || "").trim();
  if (!id) return null;
  const map = store();
  const ticket = map.get(id) || null;
  if (!ticket) return null;
  map.delete(id);
  if (ticket.expiresAt <= Date.now()) return null;
  return ticket;
}

export function peekDockerExecTicket(ticketId: string): DockerExecTicket | null {
  const ticket = store().get(String(ticketId || "").trim());
  if (!ticket) return null;
  if (ticket.expiresAt <= Date.now()) {
    store().delete(ticket.ticket);
    return null;
  }
  return ticket;
}
