import { randomBytes } from "node:crypto";
import { request as httpsRequest } from "node:https";
import { request as httpRequestRaw } from "node:http";
import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { putDockerExecTicket } from "@/lib/widgets/docker-exec-tickets";
import { connectionCandidates, hasConnectionUrl, openUrlsFromConfig, primaryConnectionUrl } from "@/lib/open-href";

export type DockerProvider = "engine" | "portainer";
export type DockerContainerAction =
  | "start"
  | "stop"
  | "restart"
  | "pause"
  | "unpause"
  | "remove";

export type DockerContainer = {
  id: string;
  name: string;
  image: string;
  state: string;
  status: string;
  ports: string;
};

export type DockerStatus = {
  href: string;
  openFallbackUrl: string;
  connectionSource: DockerConnectionSource;
  provider: DockerProvider;
  host: string;
  running: number;
  stopped: number;
  paused: number;
  total: number;
  containers: DockerContainer[];
};

export type DockerVolume = {
  name: string;
  driver: string;
  mountpoint: string;
  created?: string;
  inUse: boolean;
  labels?: Record<string, string>;
};

export type DockerPruneResult = {
  imagesDeleted: number;
  spaceReclaimed: number;
};

type Config = {
  provider?: string;
  baseUrl?: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  apiKey?: string;
  endpointId?: string;
};

export type ResolvedDockerConnection = {
  provider: DockerProvider;
  baseUrl: string;
  privateUrl: string;
  fallbackUrl: string;
  bases: string[];
  endpointId: string;
  href: string;
  openFallbackUrl: string;
  apiKey: string;
  headers: Record<string, string>;
};

const ACTIONS = new Set<DockerContainerAction>([
  "start",
  "stop",
  "restart",
  "pause",
  "unpause",
  "remove",
]);

function normalizeProvider(raw?: string): DockerProvider {
  return String(raw || "engine").toLowerCase() === "portainer" ? "portainer" : "engine";
}

function shortImage(image: string) {
  const raw = String(image || "").trim();
  if (!raw) return "—";
  const withoutDigest = raw.split("@")[0] || raw;
  const parts = withoutDigest.split("/");
  return parts[parts.length - 1] || withoutDigest;
}

function containerName(names: unknown, fallbackId: string) {
  if (Array.isArray(names) && names.length) {
    const first = String(names[0] || "").replace(/^\//, "").trim();
    if (first) return first;
  }
  if (typeof names === "string" && names.trim()) {
    return names.replace(/^\//, "").trim();
  }
  return fallbackId.slice(0, 12);
}

function formatPorts(ports: unknown) {
  if (!Array.isArray(ports) || !ports.length) return "";
  const seen = new Set<string>();
  const out: string[] = [];
  for (const port of ports) {
    const privatePort = Number(port?.PrivatePort || 0);
    const publicPort = Number(port?.PublicPort || 0);
    const type = String(port?.Type || "tcp");
    if (!privatePort) continue;
    const label = publicPort
      ? `${publicPort}→${privatePort}/${type}`
      : `${privatePort}/${type}`;
    if (seen.has(label)) continue;
    seen.add(label);
    out.push(label);
    if (out.length >= 3) break;
  }
  return out.join(", ");
}

function normalizeState(raw: unknown) {
  return String(raw || "unknown").toLowerCase();
}

function normalizeContainers(raw: unknown[]): DockerContainer[] {
  const list = (Array.isArray(raw) ? raw : []).map((item: any) => {
    const id = String(item?.Id || item?.ID || "").slice(0, 64);
    const state = normalizeState(item?.State);
    return {
      id,
      name: containerName(item?.Names ?? item?.Name, id),
      image: shortImage(item?.Image || item?.ImageID || ""),
      state,
      status: String(item?.Status || state || "—"),
      ports: formatPorts(item?.Ports),
    };
  });

  list.sort((a, b) => {
    const aRun = a.state === "running" ? 0 : 1;
    const bRun = b.state === "running" ? 0 : 1;
    if (aRun !== bRun) return aRun - bRun;
    return a.name.localeCompare(b.name);
  });

  return list;
}

function countByState(containers: DockerContainer[]) {
  let running = 0;
  let paused = 0;
  let stopped = 0;
  for (const c of containers) {
    if (c.state === "running") running += 1;
    else if (c.state === "paused") paused += 1;
    else stopped += 1;
  }
  return { running, paused, stopped, total: containers.length };
}

function buildHeaders(cfg: Config, provider: DockerProvider): Record<string, string> {
  const headers: Record<string, string> = { Accept: "application/json" };
  const key = String(cfg.apiKey || "").trim();
  if (!key) return headers;
  if (provider === "portainer") {
    headers["X-API-Key"] = key;
  } else {
    headers.Authorization = `Bearer ${key}`;
  }
  return headers;
}

export function dockerPath(provider: DockerProvider, endpointId: string, path: string) {
  if (provider === "portainer") {
    return `/api/endpoints/${encodeURIComponent(endpointId)}/docker${path}`;
  }
  return path;
}

async function withBases<T>(bases: string[], run: (base: string) => Promise<T>): Promise<T> {
  let lastError: unknown;
  for (const base of bases) {
    try {
      return await run(base);
    } catch (error) {
      // Surface *why* this base failed instead of silently moving on — without this,
      // a failing private URL is indistinguishable from one that was never tried.
      // Node's fetch() throws a generic "fetch failed" at the top level; the actual
      // reason (TLS cert error, ECONNREFUSED, DNS failure, etc.) lives in .cause.
      const cause = error instanceof Error && "cause" in error ? (error as { cause?: unknown }).cause : undefined;
      console.warn(
        `[docker] base ${base} failed, trying next candidate:`,
        error instanceof Error ? error.message : error,
        cause ? `| cause: ${cause instanceof Error ? cause.message : String(cause)}` : "",
      );
      lastError = error;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("Docker unavailable");
}

export type DockerConnectionSource = "private" | "public" | "unknown";

function apiRoot(url: string) {
  return String(url || "").replace(/\/+$/, "");
}

// Homelab HTTPS endpoints (Portainer, the Docker Engine API behind a reverse proxy, etc.)
// are almost always self-signed or backed by an internal/private CA. Node's built-in
// fetch() rejects those certs by default, which is exactly why a private `https://`
// base fails with "self-signed certificate" while curl or a browser already configured
// to trust that cert works fine.
//
// `undici` isn't a dependency of this app, so rather than pull in a package just to get
// at its Agent/dispatcher, this talks straight to node:https/node:http with
// `rejectUnauthorized: false`. It's only ever used for the exact "Private - IP" URL the
// user configured in Settings — never for the public Fallback URL, which keeps full
// certificate validation.
type FetchLikeResponse = {
  ok: boolean;
  status: number;
  text(): Promise<string>;
  json(): Promise<any>;
  arrayBuffer(): Promise<ArrayBuffer>;
};

function headersToPlain(init?: RequestInit["headers"]): Record<string, string> {
  const out: Record<string, string> = {};
  if (!init) return out;
  if (typeof Headers !== "undefined" && init instanceof Headers) {
    init.forEach((v, k) => (out[k] = v));
    return out;
  }
  if (Array.isArray(init)) {
    for (const [k, v] of init) out[k] = String(v);
    return out;
  }
  Object.assign(out, init as Record<string, string>);
  return out;
}

function insecureFetch(url: string, init: RequestInit = {}): Promise<FetchLikeResponse> {
  return new Promise((resolve, reject) => {
    let parsed: URL;
    try {
      parsed = new URL(url);
    } catch (err) {
      reject(err as Error);
      return;
    }
    const isHttps = parsed.protocol === "https:";
    const doRequest = isHttps ? httpsRequest : httpRequestRaw;
    const method = String(init.method || "GET").toUpperCase();
    const headers = headersToPlain(init.headers);

    let bodyBuf: Buffer | undefined;
    const rawBody = init.body as unknown;
    if (typeof rawBody === "string") bodyBuf = Buffer.from(rawBody);
    else if (rawBody instanceof Uint8Array) bodyBuf = Buffer.from(rawBody);
    if (bodyBuf && headers["Content-Length"] === undefined && headers["content-length"] === undefined) {
      headers["Content-Length"] = String(bodyBuf.length);
    }

    const req = doRequest(
      {
        hostname: parsed.hostname,
        port: parsed.port || (isHttps ? 443 : 80),
        path: `${parsed.pathname}${parsed.search}`,
        method,
        headers,
        // The whole point of this function: this is a private LAN endpoint with a
        // self-signed/internal-CA cert we've intentionally chosen to trust.
        rejectUnauthorized: false,
      } as any,
      (res) => {
        const chunks: Buffer[] = [];
        res.on("data", (chunk) => chunks.push(chunk as Buffer));
        res.on("end", () => {
          const buf = Buffer.concat(chunks);
          const status = res.statusCode || 0;
          resolve({
            ok: status >= 200 && status < 300,
            status,
            text: async () => buf.toString("utf8"),
            json: async () => (buf.length ? JSON.parse(buf.toString("utf8")) : null),
            arrayBuffer: async () =>
              buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) as ArrayBuffer,
          });
        });
      },
    );

    req.on("error", reject);

    const signal = init.signal;
    if (signal) {
      if (signal.aborted) {
        req.destroy();
        reject(new Error("The operation was aborted"));
        return;
      }
      signal.addEventListener(
        "abort",
        () => {
          req.destroy();
          reject(new Error("The operation was aborted"));
        },
        { once: true },
      );
    }

    if (bodyBuf) req.write(bodyBuf);
    req.end();
  });
}

/**
 * Drop-in fetch() replacement: uses the normal, fully-verified global fetch() for every
 * base except the one exact "Private - IP" URL configured for this widget, where it
 * falls back to the dependency-free insecure client above.
 */
function tlsFetch(privateUrl: string, base: string, url: string, init: RequestInit): Promise<FetchLikeResponse> {
  const isPrivateHttps = base.startsWith("https://") && !!privateUrl && apiRoot(base) === apiRoot(privateUrl);
  if (isPrivateHttps) return insecureFetch(url, init);
  return fetch(url, init) as unknown as Promise<FetchLikeResponse>;
}

function classifyConnectionSource(
  conn: { privateUrl: string; fallbackUrl: string },
  base: string,
): DockerConnectionSource {
  const normalized = apiRoot(base);
  if (conn.privateUrl && apiRoot(conn.privateUrl) === normalized) return "private";
  if (conn.fallbackUrl && apiRoot(conn.fallbackUrl) === normalized) return "public";
  return "unknown";
}

/**
 * Ordered list of API bases to try, private first, then public fallback.
 * Built directly from this widget's own config fields rather than trusting
 * the shared connectionCandidates() ordering, which was putting the public
 * (fallback) URL ahead of the private one.
 */
function orderedBases(cfg: Config): string[] {
  const seen = new Set<string>();
  const bases: string[] = [];
  const push = (url?: string) => {
    const v = String(url || "").trim();
    if (!v || seen.has(v)) return;
    seen.add(v);
    bases.push(v);
  };
  push(cfg.baseUrl); // Private - IP, always tried first
  push(cfg.fallbackUrl); // Fallback Public URL, only used if private fails/unreachable

  if (bases.length) return bases;
  // Neither field set on this widget's own config (shouldn't happen since
  // hasConnectionUrl() already guards against it) — fall back to whatever
  // the shared resolver can find.
  return connectionCandidates(cfg);
}

function readConfig(cfg: Config): ResolvedDockerConnection {
  const provider = normalizeProvider(cfg.provider);
  if (!hasConnectionUrl(cfg)) {
    throw new Error("Configure a Private - IP or Fallback Public URL in Settings");
  }
  const baseUrl = primaryConnectionUrl(cfg);
  if (provider === "portainer") {
    if (!String(cfg.apiKey || "").trim()) {
      throw new Error("Configure Portainer API key in Settings");
    }
    if (!String(cfg.endpointId || "").trim()) {
      throw new Error("Configure Portainer endpoint ID in Settings");
    }
  }
  const bases = orderedBases(cfg);
  const { href, openFallbackUrl } = openUrlsFromConfig(cfg);
  return {
    provider,
    baseUrl,
    // Raw "Private - IP" field, used verbatim so connection-source labeling
    // reflects what was actually configured/fetched rather than whatever
    // primaryConnectionUrl() decided was "primary".
    privateUrl: String(cfg.baseUrl || "").trim(),
    fallbackUrl: String(cfg.fallbackUrl || "").trim(),
    bases,
    endpointId: String(cfg.endpointId || "").trim(),
    href: href || baseUrl,
    openFallbackUrl,
    apiKey: String(cfg.apiKey || "").trim(),
    headers: buildHeaders(cfg, provider),
  };
}

export async function resolveDockerConnection(instanceId: string) {
  const cfg = (await readWidgetConfig(instanceId)) as Config;
  return readConfig(cfg);
}

export async function fetchDockerStatus(instanceId: string): Promise<DockerStatus> {
  const conn = await resolveDockerConnection(instanceId);
  const { provider, bases, endpointId, href, openFallbackUrl, headers, privateUrl } = conn;

  return withBases(bases, async (base) => {
    const api = async (path: string) => {
      const response = await tlsFetch(privateUrl, base, joinUrl(base, dockerPath(provider, endpointId, path)), {
          headers,
          cache: "no-store",
          signal: AbortSignal.timeout(12_000),
        });
      if (!response.ok) throw new Error(`Docker HTTP ${response.status}`);
      return response.json();
    };

    const [info, containersRaw] = await Promise.all([
      api("/info").catch(() => null),
      api("/containers/json?all=true"),
    ]);

    const containers = normalizeContainers(containersRaw);
    const counts = countByState(containers);
    const host =
      String(info?.Name || info?.name || "").trim() ||
      (provider === "portainer" ? `endpoint ${endpointId}` : "Docker");

    return {
      href,
      openFallbackUrl,
      connectionSource: classifyConnectionSource(conn, base),
      provider,
      host,
      ...counts,
      containers,
    };
  });
}

export async function dockerContainerAction(
  instanceId: string,
  containerId: string,
  action: DockerContainerAction,
) {
  if (!ACTIONS.has(action)) throw new Error("Invalid Docker action");
  const id = String(containerId || "").trim();
  if (!id) throw new Error("Missing container id");

  const { provider, bases, endpointId, headers, privateUrl } = await resolveDockerConnection(instanceId);

  await withBases(bases, async (base) => {
    if (action === "remove") {
      const response = await tlsFetch(privateUrl, base, joinUrl(base, dockerPath(provider, endpointId, `/containers/${encodeURIComponent(id)}?force=true`)), {
          method: "DELETE",
          headers,
          cache: "no-store",
          signal: AbortSignal.timeout(30_000),
        });
      if (!response.ok && response.status !== 204 && response.status !== 404) {
        const text = await response.text().catch(() => "");
        throw new Error(text || `Docker HTTP ${response.status}`);
      }
      return;
    }

    const response = await tlsFetch(privateUrl, base, joinUrl(base, dockerPath(provider, endpointId, `/containers/${encodeURIComponent(id)}/${action}`)), {
        method: "POST",
        headers,
        cache: "no-store",
        signal: AbortSignal.timeout(20_000),
      });
    if (!response.ok && response.status !== 304) {
      const text = await response.text().catch(() => "");
      throw new Error(text || `Docker HTTP ${response.status}`);
    }
  });
}

/** Decode Docker multiplexed log frames into plain text. */
export function demuxDockerLogs(buffer: ArrayBuffer | Buffer): string {
  const buf = Buffer.isBuffer(buffer) ? buffer : Buffer.from(buffer);
  if (buf.length < 8) return buf.toString("utf8");
  // Heuristic: multiplexed frames start with stream type 0-2 and size in bytes 4-7
  const firstType = buf[0];
  if (firstType > 2) return buf.toString("utf8");

  let out = "";
  let offset = 0;
  while (offset + 8 <= buf.length) {
    const size = buf.readUInt32BE(offset + 4);
    offset += 8;
    if (size < 0 || offset + size > buf.length) {
      out += buf.subarray(offset - 8).toString("utf8");
      break;
    }
    out += buf.subarray(offset, offset + size).toString("utf8");
    offset += size;
  }
  return out;
}

export async function fetchDockerLogs(
  instanceId: string,
  containerId: string,
  tail = 200,
): Promise<string> {
  const id = String(containerId || "").trim();
  if (!id) throw new Error("Missing container id");
  const { provider, bases, endpointId, headers, privateUrl } = await resolveDockerConnection(instanceId);
  const safeTail = Math.max(1, Math.min(2000, Number(tail) || 200));

  return withBases(bases, async (base) => {
    const path = `/containers/${encodeURIComponent(id)}/logs?stdout=true&stderr=true&timestamps=true&tail=${safeTail}`;
    const response = await tlsFetch(privateUrl, base, joinUrl(base, dockerPath(provider, endpointId, path)), {
        headers: { ...headers, Accept: "*/*" },
        cache: "no-store",
        signal: AbortSignal.timeout(20_000),
      });
    if (!response.ok) {
      const text = await response.text().catch(() => "");
      throw new Error(text || `Docker HTTP ${response.status}`);
    }
    const buf = Buffer.from(await response.arrayBuffer());
    return demuxDockerLogs(buf);
  });
}

export async function fetchDockerVolumes(instanceId: string): Promise<DockerVolume[]> {
  const { provider, bases, endpointId, headers, privateUrl } = await resolveDockerConnection(instanceId);

  return withBases(bases, async (base) => {
    const [volumesRaw, containersRaw] = await Promise.all([
      tlsFetch(privateUrl, base, joinUrl(base, dockerPath(provider, endpointId, "/volumes")), {
        headers,
        cache: "no-store",
        signal: AbortSignal.timeout(12_000),
      }).then(async (res) => {
        if (!res.ok) throw new Error(`Docker HTTP ${res.status}`);
        return res.json();
      }),
      tlsFetch(privateUrl, base, joinUrl(base, dockerPath(provider, endpointId, "/containers/json?all=true")), {
        headers,
        cache: "no-store",
        signal: AbortSignal.timeout(12_000),
      })
        .then(async (res) => (res.ok ? res.json() : []))
        .catch(() => []),
    ]);

    const inUse = new Set<string>();
    for (const container of Array.isArray(containersRaw) ? containersRaw : []) {
      const mounts = Array.isArray(container?.Mounts) ? container.Mounts : [];
      for (const mount of mounts) {
        const name = String(mount?.Name || "").trim();
        if (name) inUse.add(name);
      }
    }

    const volumes = Array.isArray(volumesRaw?.Volumes) ? volumesRaw.Volumes : [];
    return volumes
      .map((vol: any) => {
        const name = String(vol?.Name || "").trim();
        return {
          name,
          driver: String(vol?.Driver || "local"),
          mountpoint: String(vol?.Mountpoint || ""),
          created: vol?.CreatedAt ? String(vol.CreatedAt) : undefined,
          inUse: inUse.has(name),
          labels: (vol?.Labels && typeof vol.Labels === "object" ? vol.Labels : undefined) as
            | Record<string, string>
            | undefined,
        };
      })
      .filter((v: DockerVolume) => v.name)
      .sort((a: DockerVolume, b: DockerVolume) => a.name.localeCompare(b.name));
  });
}

export async function deleteDockerVolume(instanceId: string, name: string, force = false) {
  const volume = String(name || "").trim();
  if (!volume) throw new Error("Missing volume name");
  const { provider, bases, endpointId, headers, privateUrl } = await resolveDockerConnection(instanceId);

  await withBases(bases, async (base) => {
    const qs = force ? "?force=true" : "";
    const response = await tlsFetch(
      privateUrl,
      base,
      joinUrl(base, dockerPath(provider, endpointId, `/volumes/${encodeURIComponent(volume)}${qs}`)),
      {
        method: "DELETE",
        headers,
        cache: "no-store",
        signal: AbortSignal.timeout(20_000),
      },
    );
    if (!response.ok && response.status !== 204 && response.status !== 404) {
      const text = await response.text().catch(() => "");
      throw new Error(text || `Docker HTTP ${response.status}`);
    }
  });
}

export async function pruneDockerImages(instanceId: string): Promise<DockerPruneResult> {
  const { provider, bases, endpointId, headers, privateUrl } = await resolveDockerConnection(instanceId);

  return withBases(bases, async (base) => {
    const response = await tlsFetch(privateUrl, base, joinUrl(base, dockerPath(provider, endpointId, "/images/prune")), {
        method: "POST",
        headers: { ...headers, "Content-Type": "application/json" },
        body: "{}",
        cache: "no-store",
        signal: AbortSignal.timeout(120_000),
      });
    if (!response.ok) {
      const text = await response.text().catch(() => "");
      throw new Error(text || `Docker HTTP ${response.status}`);
    }
    const json = await response.json().catch(() => ({}));
    const deleted = Array.isArray(json?.ImagesDeleted) ? json.ImagesDeleted : [];
    return {
      imagesDeleted: deleted.filter((row: any) => row?.Deleted || row?.Untagged).length,
      spaceReclaimed: Number(json?.SpaceReclaimed || 0) || 0,
    };
  });
}

const SHELL_CANDIDATES: string[][] = [
  ["/bin/bash"],
  ["/usr/bin/bash"],
  ["/bin/sh"],
  ["/usr/bin/sh"],
  ["/bin/ash"],
  ["/usr/bin/ash"],
  ["/busybox", "sh"],
  ["/bin/busybox", "sh"],
];

async function probeContainerShell(
  base: string,
  provider: DockerProvider,
  endpointId: string,
  headers: Record<string, string>,
  containerId: string,
  privateUrl: string,
): Promise<string[]> {
  for (const shell of SHELL_CANDIDATES) {
    try {
      const createRes = await tlsFetch(privateUrl, base, joinUrl(base, dockerPath(provider, endpointId, `/containers/${encodeURIComponent(containerId)}/exec`)), {
          method: "POST",
          headers: { ...headers, "Content-Type": "application/json" },
          body: JSON.stringify({
            AttachStdin: false,
            AttachStdout: true,
            AttachStderr: true,
            Tty: false,
            Cmd: [...shell, "-c", "exit 0"],
          }),
          cache: "no-store",
          signal: AbortSignal.timeout(10_000),
        });
      if (!createRes.ok) continue;
      const created = await createRes.json();
      const execId = String(created?.Id || "").trim();
      if (!execId) continue;

      const startRes = await tlsFetch(privateUrl, base, joinUrl(base, dockerPath(provider, endpointId, `/exec/${encodeURIComponent(execId)}/start`)), {
          method: "POST",
          headers: { ...headers, "Content-Type": "application/json" },
          body: JSON.stringify({ Detach: false, Tty: false }),
          cache: "no-store",
          signal: AbortSignal.timeout(10_000),
        });
      const startText = await startRes.text().catch(() => "");
      if (!startRes.ok) continue;
      if (/no such file or directory|executable file not found|OCI runtime/i.test(startText)) {
        continue;
      }

      const inspectRes = await tlsFetch(privateUrl, base, joinUrl(base, dockerPath(provider, endpointId, `/exec/${encodeURIComponent(execId)}/json`)), {
          headers,
          cache: "no-store",
          signal: AbortSignal.timeout(8_000),
        });
      if (!inspectRes.ok) {
        return shell;
      }
      const inspect = await inspectRes.json();
      const exitCode = Number(inspect?.ExitCode ?? 1);
      if (!inspect?.Running && exitCode === 0) return shell;
    } catch {
      /* try next shell */
    }
  }

  throw new Error(
    "This container has no shell. Distroless and scratch images (like Portainer) cannot open an interactive console.",
  );
}

export async function createDockerExecSession(
  instanceId: string,
  containerId: string,
  cmd?: string[],
): Promise<{ ticket: string; wsPath: string }> {
  const id = String(containerId || "").trim();
  if (!id) throw new Error("Missing container id");

  const conn = await resolveDockerConnection(instanceId);

  return withBases(conn.bases, async (base) => {
    const command =
      Array.isArray(cmd) && cmd.length
        ? cmd.map(String)
        : await probeContainerShell(base, conn.provider, conn.endpointId, conn.headers, id, conn.privateUrl);

    const response = await tlsFetch(conn.privateUrl, base, joinUrl(base, dockerPath(conn.provider, conn.endpointId, `/containers/${encodeURIComponent(id)}/exec`)), {
        method: "POST",
        headers: { ...conn.headers, "Content-Type": "application/json" },
        body: JSON.stringify({
          AttachStdin: true,
          AttachStdout: true,
          AttachStderr: true,
          Tty: true,
          Cmd: command,
        }),
        cache: "no-store",
        signal: AbortSignal.timeout(15_000),
      });
    if (!response.ok) {
      const text = await response.text().catch(() => "");
      throw new Error(text || `Docker HTTP ${response.status}`);
    }
    const json = await response.json();
    const execId = String(json?.Id || "").trim();
    if (!execId) throw new Error("Docker did not return an exec id");

    const ticket = randomBytes(24).toString("hex");
    putDockerExecTicket({
      ticket,
      instanceId,
      containerId: id,
      execId,
      provider: conn.provider,
      baseUrl: base,
      endpointId: conn.endpointId,
      apiKey: conn.apiKey,
      expiresAt: Date.now() + 60_000,
    });

    return { ticket, wsPath: `/api/widgets/docker/exec/ws?ticket=${encodeURIComponent(ticket)}` };
  });
}

export function isDockerAction(value: string): value is DockerContainerAction {
  return ACTIONS.has(value as DockerContainerAction);
}
