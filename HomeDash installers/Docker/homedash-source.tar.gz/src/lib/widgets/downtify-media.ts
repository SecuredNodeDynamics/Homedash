export type DowntifySong = Record<string, unknown> & {
  title?: string;
  name?: string;
  status?: string;
  progress?: number;
  artists?: string | string[];
  artist?: string;
  album?: string;
  album_name?: string;
  url?: string;
  source_url?: string;
  filename?: string;
  file?: string;
  cover_url?: string;
  thumbnail?: string;
  media_type?: string;
  type?: string;
  browse_id?: string;
  browseId?: string;
  videoId?: string;
  video_id?: string;
  completed_at?: string;
  updated_at?: string;
  created_at?: string;
  year?: string | number;
  release_date?: string;
  track_count?: number;
  song?: DowntifySong;
};

export function normText(value: unknown) {
  return String(value || "")
    .replace(/\s+/g, " ")
    .trim();
}

export function songTitle(item: DowntifySong) {
  return item?.title || item?.name || item?.song?.title || item?.song?.name || "Unknown track";
}

export function songArtists(item: DowntifySong) {
  const fromSong = item?.song?.artists || item?.song?.artist;
  const artists = item?.artists || item?.artist || fromSong;
  if (Array.isArray(artists)) return artists.filter(Boolean).join(", ");
  return String(artists || "");
}

export function songAlbum(item: DowntifySong) {
  return item?.album || item?.album_name || item?.song?.album || item?.song?.album_name || "";
}

export function songStatus(item: DowntifySong) {
  return String(item?.status || "unknown");
}

export function songUrl(item: DowntifySong) {
  const song = item?.song || item || {};
  if (song.url || song.source_url || item?.url || item?.source_url) {
    return String(song.url || song.source_url || item?.url || item?.source_url || "");
  }
  const videoId = song.videoId || song.video_id || item?.videoId || item?.video_id;
  if (videoId) return `https://music.youtube.com/watch?v=${encodeURIComponent(String(videoId))}`;
  const browseId = song.browse_id || song.browseId || item?.browse_id || item?.browseId;
  if (browseId) return `https://music.youtube.com/browse/${encodeURIComponent(String(browseId))}`;
  return "";
}

function pickString(...values: unknown[]) {
  for (const value of values) {
    const text = String(value || "").trim();
    if (text) return text;
  }
  return "";
}

export function songFile(item: DowntifySong) {
  const song = item?.song || item || {};
  const rec = item as Record<string, unknown>;
  const nested = song as Record<string, unknown>;
  return pickString(
    rec.filename,
    rec.file,
    rec.path,
    rec.filepath,
    rec.file_path,
    rec.relpath,
    rec.relative_path,
    rec.fullpath,
    rec.full_path,
    rec.location,
    nested.filename,
    nested.file,
    nested.path,
    nested.filepath,
    nested.file_path,
    nested.relpath,
    nested.relative_path,
    nested.fullpath,
    nested.full_path,
    nested.location,
  );
}

export function songType(item: DowntifySong) {
  const song = item?.song || item || {};
  const type = String(
    song.media_type ||
      song.type ||
      song.resultType ||
      item?.media_type ||
      item?.type ||
      item?.resultType ||
      "",
  ).toLowerCase();
  if (type.includes("album")) return "album";
  if (type.includes("artist")) return "artist";
  if (type.includes("playlist")) return "playlist";
  const browseId = item?.browse_id || item?.browseId || song.browse_id || song.browseId;
  const videoId = song.videoId || song.video_id || item?.videoId || item?.video_id;
  if (browseId && !videoId && !type) return "album";
  return "track";
}

function firstImageValue(...values: unknown[]): string {
  for (const value of values) {
    if (!value) continue;
    if (typeof value === "string") return value;
    if (Array.isArray(value)) {
      const nested = firstImageValue(...value);
      if (nested) return nested;
    }
    if (typeof value === "object") {
      const obj = value as Record<string, unknown>;
      const nested = firstImageValue(
        obj.url,
        obj.src,
        obj.href,
        obj.cover_url,
        obj.coverUrl,
        obj.image_url,
        obj.imageUrl,
      );
      if (nested) return nested;
    }
  }
  return "";
}

export function isHomedashCoverProxy(value: string) {
  return /(?:^|\/)api\/widgets\/downtify\/cover(?:\?|$)/i.test(value);
}

function coverRefFromUrl(raw: string): { file?: string; url?: string } {
  const value = String(raw || "").trim();
  if (!value || isHomedashCoverProxy(value)) return {};
  try {
    const parsed = value.startsWith("/") ? new URL(value, "http://downtify.local") : new URL(value);
    const path = parsed.pathname || "";
    if (/\/api\/library\/cover$/i.test(path) || path === "/cover") {
      const file = String(parsed.searchParams.get("file") || "").trim();
      if (file) return { file };
    }
    if (path.startsWith("/cover/") && path.length > 7) {
      return { file: decodeURIComponent(path.slice("/cover/".length)) };
    }
  } catch {
    /* keep the original URL */
  }
  if (/^https?:\/\//i.test(value) || (value.startsWith("/") && !value.startsWith("//"))) {
    return { url: value };
  }
  return {};
}

export function songCover(item: DowntifySong, instanceId: string, size = 240) {
  const song = item?.song || item || {};
  const raw = firstImageValue(
    song.cover_url,
    song.coverUrl,
    song.album_cover_url,
    song.albumCoverUrl,
    song.artwork_url,
    song.artworkUrl,
    song.thumbnail,
    song.thumbnail_url,
    song.thumbnailUrl,
    song.image,
    song.images,
    item.cover_url,
    item.thumbnail,
    (item as { cover?: string }).cover,
    (item as { artwork?: string }).artwork,
    (item as { picture?: string }).picture,
  );
  const fromUrl = coverRefFromUrl(raw);
  const file = fromUrl.file || songFile(item);
  const url = fromUrl.url || "";
  const artist = songArtists(item).split(",")[0]?.trim() || "";
  if (!instanceId) return "";
  const params = new URLSearchParams({ instance: instanceId, size: String(size) });
  if (file) params.set("file", file);
  if (url) params.set("url", url);
  if (artist) params.set("artist", artist);
  if (!params.has("file") && !params.has("url") && !params.has("artist")) return "";
  return `/api/widgets/downtify/cover?${params.toString()}`;
}

export function statusClass(status: string) {
  const s = status.toLowerCase();
  if (s === "done" || s === "completed" || s === "ok") return "downtify-pill--ok";
  if (s === "downloading" || s === "queued" || s === "active") return "downtify-pill--active";
  if (s === "error" || s === "failed") return "downtify-pill--warn";
  return "downtify-pill--muted";
}

export function fmtBytes(bytes: number) {
  if (!bytes || bytes < 0) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let value = bytes;
  let i = 0;
  while (value >= 1024 && i < units.length - 1) {
    value /= 1024;
    i += 1;
  }
  return `${value.toFixed(value >= 10 || i === 0 ? 0 : 1)} ${units[i]}`;
}

export function firstNumber(...values: unknown[]) {
  for (const value of values) {
    const n = typeof value === "number" ? value : Number(value);
    if (Number.isFinite(n)) return n;
  }
  return 0;
}

export function fmtDate(value?: string) {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return date.toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

export function libraryKey(title: string, artists: string, album = "") {
  return [normText(title), normText(artists), normText(album)].join("|").toLowerCase();
}
