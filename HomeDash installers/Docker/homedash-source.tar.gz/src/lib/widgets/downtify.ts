import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { openUrlsFromConfig } from "@/lib/open-href";
import {
  isHomedashCoverProxy,
  songAlbum,
  songArtists,
  songTitle,
  songType,
  songUrl,
  type DowntifySong,
} from "@/lib/widgets/downtify-media";

export type { DowntifySong } from "@/lib/widgets/downtify-media";
export {
  firstNumber,
  fmtBytes,
  fmtDate,
  libraryKey,
  normText,
  songAlbum,
  songArtists,
  songCover,
  songFile,
  songStatus,
  songTitle,
  songType,
  songUrl,
  statusClass,
} from "@/lib/widgets/downtify-media";

type Config = Record<string, string>;

class DowntifyHttpError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

type AuthSession = { token: string; cookie: string; expires: number };
const tokenCache = new Map<string, AuthSession>();
const TOKEN_TTL_MS = 25 * 60_000;

function candidates(config: Config) {
  const out: string[] = [];
  for (const key of ["baseUrl", "fallbackUrl"] as const) {
    const value = (config[key] || "").trim().replace(/\/$/, "");
    if (value && !out.includes(value)) out.push(value);
  }
  return out;
}

async function fetchJson<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, {
    ...init,
    cache: "no-store",
    signal: init?.signal || AbortSignal.timeout(15_000),
    headers: {
      Accept: "application/json",
      ...(init?.headers || {}),
    },
  });
  if (!response.ok) {
    let detail = "";
    try {
      const data = (await response.json()) as { detail?: string; message?: string };
      detail = data.detail || data.message || "";
    } catch {
      /* ignore */
    }
    throw new DowntifyHttpError(response.status, detail || `Downtify ${response.status}`);
  }
  if (response.status === 204) return null as T;
  const type = response.headers.get("content-type") || "";
  if (!type.includes("application/json")) {
    throw new DowntifyHttpError(response.status, "Downtify returned a non-JSON response");
  }
  const data = (await response.json()) as T;
  if (isAuthRejectedPayload(data)) {
    throw new DowntifyHttpError(401, "Downtify login required");
  }
  return data;
}

function isAuthRejectedPayload(data: unknown) {
  if (!data || typeof data !== "object" || Array.isArray(data)) return false;
  const obj = data as Record<string, unknown>;
  const detail = String(obj.detail || obj.message || obj.error || "").toLowerCase();
  return /not authenticated|unauthori[sz]ed|invalid token|login required|not logged in/.test(detail);
}

function cookieHeaderFrom(response: Response) {
  const getSetCookie = (response.headers as Headers & { getSetCookie?: () => string[] }).getSetCookie;
  const parts = typeof getSetCookie === "function" ? getSetCookie.call(response.headers) : [];
  const raw = parts.length ? parts : [response.headers.get("set-cookie") || ""];
  return raw
    .flatMap((entry) => entry.split(/,(?=[^;]+?=)/))
    .map((chunk) => chunk.split(";")[0]?.trim())
    .filter(Boolean)
    .join("; ");
}

function tokenFrom(data: Record<string, unknown>, cookie = "") {
  const nested = data.user && typeof data.user === "object" ? (data.user as Record<string, unknown>) : {};
  const fromJson = String(
    data.token || data.access_token || data.accessToken || nested.token || nested.access_token || "",
  ).trim();
  if (fromJson) return fromJson;
  const cookieToken = cookie.match(/(?:^|;\s*)(?:access_token|auth_token|token)=([^;]+)/i);
  return cookieToken?.[1]?.trim() || "";
}

function authHeadersFrom(session: Pick<AuthSession, "token" | "cookie">): HeadersInit {
  const headers: Record<string, string> = {};
  if (session.token) headers.Authorization = `Bearer ${session.token}`;
  if (session.cookie) headers.Cookie = session.cookie;
  return headers;
}

function authCacheKey(base: string, config: Config) {
  return `${base}|${(config.username || "").trim()}`;
}

async function login(base: string, config: Config): Promise<AuthSession> {
  const username = (config.username || "").trim();
  const password = config.password || "";
  if (!username || !password) {
    throw new Error("Configure Downtify username and password in Settings");
  }
  const response = await fetch(joinUrl(base, "/api/auth/login"), {
    method: "POST",
    cache: "no-store",
    redirect: "manual",
    signal: AbortSignal.timeout(15_000),
    headers: { Accept: "application/json", "Content-Type": "application/json" },
    body: JSON.stringify({ username, password, pin: "" }),
  });
  const cookie = cookieHeaderFrom(response);
  const data = (await response.json().catch(() => ({}))) as Record<string, unknown>;
  if (!response.ok && response.status !== 302) {
    const detail = String(data.detail || data.message || `Downtify login ${response.status}`);
    throw new DowntifyHttpError(response.status, detail);
  }
  const token = tokenFrom(data, cookie);
  if (!token && !cookie) throw new Error("Downtify login succeeded but no session was returned");
  const session = { token, cookie, expires: Date.now() + TOKEN_TTL_MS };
  tokenCache.set(authCacheKey(base, config), session);
  return session;
}

async function resolveAuthHeaders(base: string, config: Config, force = false): Promise<HeadersInit> {
  const username = (config.username || "").trim();
  const password = config.password || "";
  if (!username || !password) {
    throw new Error("Configure Downtify username and password in Settings");
  }
  const key = authCacheKey(base, config);
  const cached = tokenCache.get(key);
  if (!force && cached && Date.now() < cached.expires) {
    return authHeadersFrom(cached);
  }
  return authHeadersFrom(await login(base, config));
}

function isAuthFailure(err: unknown) {
  if (err instanceof DowntifyHttpError) return err.status === 401 || err.status === 403;
  return /401|403|not authenticated|unauthorized/i.test(String(err instanceof Error ? err.message : err));
}

async function withFailover<T>(
  config: Config,
  path: string,
  init?: RequestInit,
): Promise<{ data: T; href: string }> {
  const urls = candidates(config);
  if (!urls.length) throw new Error("Configure a Private - IP or Fallback Public URL in Settings");
  let lastError: Error | null = null;
  for (const base of urls) {
    for (const force of [false, true]) {
      try {
        const auth = await resolveAuthHeaders(base, config, force);
        const data = await fetchJson<T>(joinUrl(base, path), {
          ...init,
          headers: {
            ...auth,
            ...(init?.headers || {}),
          },
        });
        return { data, href: base };
      } catch (err) {
        lastError = err instanceof Error ? err : new Error(String(err));
        if (!force && isAuthFailure(err)) {
          tokenCache.delete(authCacheKey(base, config));
          continue;
        }
        break;
      }
    }
  }
  throw lastError || new Error("All Downtify URLs failed");
}

async function withFailoverResponse(
  config: Config,
  path: string,
  init?: RequestInit,
): Promise<{ response: Response; href: string }> {
  const urls = candidates(config);
  if (!urls.length) throw new Error("Configure a Private - IP or Fallback Public URL in Settings");
  let lastError: Error | null = null;
  for (const base of urls) {
    for (const force of [false, true]) {
      try {
        const auth = await resolveAuthHeaders(base, config, force);
        const response = await fetch(joinUrl(base, path), {
          ...init,
          cache: "no-store",
          signal: init?.signal || AbortSignal.timeout(20_000),
          headers: {
            Accept: "image/*,*/*;q=0.8",
            ...auth,
            ...(init?.headers || {}),
          },
        });
        if (!response.ok) {
          throw new DowntifyHttpError(response.status, `Downtify cover ${response.status}`);
        }
        const type = (response.headers.get("content-type") || "").toLowerCase();
        if (type.includes("application/json") || type.includes("text/html")) {
          throw new DowntifyHttpError(response.status, "Downtify cover was not an image");
        }
        return { response, href: base };
      } catch (err) {
        lastError = err instanceof Error ? err : new Error(String(err));
        if (!force && isAuthFailure(err)) {
          tokenCache.delete(authCacheKey(base, config));
          continue;
        }
        break;
      }
    }
  }
  throw lastError || new Error("All Downtify URLs failed");
}

function asArray<T>(value: unknown): T[] {
  if (Array.isArray(value)) return value as T[];
  if (value && typeof value === "object") {
    const obj = value as Record<string, unknown>;
    for (const key of ["results", "data", "items", "tracks", "files", "library", "history", "songs", "queue", "downloads", "entries"] as const) {
      if (Array.isArray(obj[key])) return obj[key] as T[];
    }
  }
  return [];
}

function asSongs(value: unknown): DowntifySong[] {
  return asArray<unknown>(value)
    .map((entry) => {
      if (typeof entry === "string") return libraryFromPaths([entry])[0] || null;
      if (entry && typeof entry === "object") return entry as DowntifySong;
      return null;
    })
    .filter((entry): entry is DowntifySong => Boolean(entry));
}

function classifyConnectionSource(config: Config, base: string): "private" | "public" | "unknown" {
  const normalized = String(base || "").replace(/\/$/, "");
  if (!normalized) return "unknown";
  if (String(config.baseUrl || "").replace(/\/$/, "") === normalized) return "private";
  if (String(config.fallbackUrl || "").replace(/\/$/, "") === normalized) return "public";
  return "unknown";
}

function emptyStatus(config: Config, error = "") {
  const { href, openFallbackUrl } = openUrlsFromConfig(config);
  return {
    href,
    openFallbackUrl,
    summary: null,
    queue: [] as DowntifySong[],
    history: [] as DowntifySong[],
    capabilities: null,
    health: null,
    monitor: [] as Array<Record<string, unknown>>,
    coreOnline: false,
    coreErrors: 3,
    historyOk: false,
    connectionSource: "unknown" as const,
    error,
  };
}

export async function downtifyStatus(instanceId: string) {
  const config = (await readWidgetConfig(instanceId)) as Config;
  if (!candidates(config).length) {
    return emptyStatus(config, "Configure a Private - IP or Fallback Public URL in Settings");
  }
  if (!(config.username || "").trim() || !config.password) {
    return emptyStatus(config, "Configure Downtify username and password in Settings");
  }

  const settled = await Promise.allSettled([
    withFailover<Record<string, unknown>>(config, "/api/summary"),
    withFailover<unknown>(config, "/api/queue"),
    withFailover<unknown>(config, "/api/history?limit=25&include_active=true&reconcile=false"),
    withFailover<unknown>(config, "/api/monitor/playlists"),
  ]);

  const pick = <T,>(index: number, fallback: T): { value: T; href?: string; ok: boolean } => {
    const result = settled[index];
    if (result.status === "fulfilled") {
      return { value: result.value.data as T, href: result.value.href, ok: true };
    }
    return { value: fallback, ok: false };
  };

  const summary = pick<Record<string, unknown> | null>(0, null);
  const queue = pick<unknown>(1, []);
  const history = pick<unknown>(2, []);
  const monitor = pick<unknown>(3, []);

  const activeHref = summary.href || queue.href || history.href || candidates(config)[0] || "";
  const { href, openFallbackUrl } = openUrlsFromConfig(config);
  const coreOnline = [summary, queue, history].some((part) => part.ok);
  const coreErrors = [summary, queue, history].filter((part) => !part.ok).length;
  const failed = settled.find((part) => part.status === "rejected") as PromiseRejectedResult | undefined;
  const error = coreOnline
    ? ""
    : failed?.reason instanceof Error
      ? failed.reason.message
      : "Downtify is not connected";

  return {
    href: href || activeHref,
    openFallbackUrl,
    summary: summary.value,
    queue: asSongs(queue.value),
    history: asSongs(history.value),
    capabilities: null,
    health: null,
    monitor: asArray<Record<string, unknown>>(monitor.value),
    coreOnline,
    coreErrors,
    historyOk: history.ok,
    connectionSource: classifyConnectionSource(config, activeHref),
    error,
  };
}

function libraryFromPaths(paths: string[]): DowntifySong[] {
  return paths
    .map((raw) => String(raw || "").trim())
    .filter(Boolean)
    .map((filename) => {
      const parts = filename.split("/").filter(Boolean);
      const file = parts[parts.length - 1] || filename;
      const title = file.replace(/\.[^.]+$/, "");
      return {
        filename,
        file: filename,
        title,
        artists: parts.length > 1 ? parts[0] : "",
        album: parts.length > 2 ? parts[1] : "",
        status: "done",
      } as DowntifySong;
    });
}

export async function downtifyLibrary(instanceId: string) {
  const config = (await readWidgetConfig(instanceId)) as Config;
  if (!(config.username || "").trim() || !config.password) {
    throw new Error("Configure Downtify username and password in Settings");
  }
  const { data, href } = await withFailover<unknown>(config, "/api/library/files", {
    signal: AbortSignal.timeout(60_000),
  });
  const library = asSongs(data);
  if (library.length) return { href, library };
  try {
    const listed = await withFailover<unknown>(config, "/list", {
      signal: AbortSignal.timeout(60_000),
    });
    const paths = Array.isArray(listed.data) ? listed.data.map((item) => String(item)) : [];
    return { href: listed.href, library: libraryFromPaths(paths) };
  } catch {
    return { href, library };
  }
}

export async function downtifySearch(instanceId: string, query: string) {
  const config = (await readWidgetConfig(instanceId)) as Config;
  const q = query.trim();
  if (q.length < 2) throw new Error("Type at least 2 characters");
  const { data, href } = await withFailover<unknown>(
    config,
    `/api/songs/search?query=${encodeURIComponent(q)}`,
  );
  return { href, results: asSongs(data) };
}

export async function downtifyDownload(
  instanceId: string,
  body: { item: DowntifySong; clientId?: string },
) {
  const config = (await readWidgetConfig(instanceId)) as Config;
  const item = body.item || {};
  const type = songType(item);

  if (type === "album") {
    const browseId =
      item.browse_id ||
      item.browseId ||
      item.song?.browse_id ||
      item.song?.browseId;
    if (!browseId) throw new Error("Album browse ID missing");
    const album = await withFailover<unknown>(
      config,
      `/api/album/youtube?browse_id=${encodeURIComponent(String(browseId))}`,
      { signal: AbortSignal.timeout(20_000) },
    );
    const tracks = asSongs(album.data);
    if (!tracks.length) throw new Error("No album tracks found");
    await withFailover(config, "/api/download/batch", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        songs: tracks.map((track) => ({
          ...track,
          source: "homedash",
          media_type: "track",
          album_name: track.album_name || item.album_name || item.name || "",
        })),
        playlist_url: "",
        generate_m3u: false,
      }),
    });
    return { ok: true, message: `Queued ${songTitle(item)}` };
  }

  const url = songUrl(item);
  if (!url) throw new Error("Track URL missing");
  const clientId = body.clientId || "homedash-widget";
  const params = new URLSearchParams({ url, client_id: clientId });
  await withFailover(config, `/api/download/url?${params.toString()}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      ...item,
      url,
      source: "homedash",
      media_type: type,
      title: songTitle(item),
      artists: songArtists(item),
      album: songAlbum(item),
    }),
  });
  return { ok: true, message: `Queued ${songTitle(item)}` };
}

export async function downtifyCover(
  instanceId: string,
  query: { file?: string; url?: string; artist?: string; size?: number },
) {
  const config = (await readWidgetConfig(instanceId)) as Config;
  const file = String(query.file || "").trim();
  const url = String(query.url || "").trim();
  const artist = String(query.artist || "").trim();
  const size = Math.max(0, Math.min(800, Number(query.size) || 240));
  const attempts: string[] = [];
  if (file) {
    attempts.push(`/api/library/cover?file=${encodeURIComponent(file)}&size=${size}`);
    attempts.push(`/cover?file=${encodeURIComponent(file)}&size=${size}`);
    attempts.push(`/cover/${file.split("/").filter(Boolean).map(encodeURIComponent).join("/")}?size=${size}`);
  }
  if (url.startsWith("/") && !url.startsWith("//") && !isHomedashCoverProxy(url)) {
    attempts.push(url);
  } else if (/^https?:\/\//i.test(url)) {
    attempts.push(`/api/image-proxy?url=${encodeURIComponent(url)}`);
  }
  if (artist) {
    attempts.push(`/api/metadata/artist-images/preview?artist=${encodeURIComponent(artist)}`);
    attempts.push(`/api/metadata/artist-images/folder-preview?folder=${encodeURIComponent(artist)}&size=${size}`);
  }
  if (!attempts.length) throw new Error("Missing cover");
  let lastError: Error | null = null;
  for (const path of attempts) {
    try {
      const { response } = await withFailoverResponse(config, path);
      return response;
    } catch (err) {
      lastError = err instanceof Error ? err : new Error(String(err));
    }
  }
  throw lastError || new Error("Cover not found");
}
