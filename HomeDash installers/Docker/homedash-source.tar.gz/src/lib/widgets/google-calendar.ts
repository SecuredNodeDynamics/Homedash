import { createSign } from "crypto";
import { readWidgetConfig } from "@/lib/config";

// ── Types ───────────────────────────────────────────────────────────────
//
// Auth: Google service account, 2-legged JWT-bearer flow (no OAuth consent
// screen / redirect). The calendar(s) must be shared with the service
// account's email address from within Google Calendar's own sharing UI.
// Docs: https://developers.google.com/identity/protocols/oauth2/service-account

export type GCalEvent = {
  id: string;
  calendarId: string;
  calendarLabel: string;
  title: string;
  description: string | null;
  location: string | null;
  start: string; // ISO datetime, or YYYY-MM-DD for all-day events
  end: string;
  allDay: boolean;
  htmlLink: string | null;
};

export type GCalCalendarRef = { id: string; label: string };

export type GCalCalendarError = { calendarId: string; label: string; message: string };

export type GCalStatus = {
  events: GCalEvent[];
  calendars: GCalCalendarRef[];
  errors: GCalCalendarError[];
};

type GCalConfig = {
  serviceAccountEmail: string;
  privateKey: string;
  calendars: GCalCalendarRef[];
};

// ── Config ──────────────────────────────────────────────────────────────

async function loadGCalConfig(instanceId: string): Promise<GCalConfig> {
  const config = (await readWidgetConfig(instanceId)) as Partial<{
    serviceAccountEmail: string;
    privateKey: string;
    calendars: string;
  }>;

  if (!config.serviceAccountEmail || !config.privateKey) {
    throw new Error("Add the service account email and private key in Settings");
  }
  if (!config.calendars || !config.calendars.trim()) {
    throw new Error("Add at least one calendar (Label:CalendarID) in Settings");
  }

  const calendars: GCalCalendarRef[] = config.calendars
    .split(",")
    .map((entry) => entry.trim())
    .filter(Boolean)
    .map((entry) => {
      const splitAt = entry.indexOf(":");
      if (splitAt === -1) return { id: entry, label: entry };
      const label = entry.slice(0, splitAt).trim();
      const id = entry.slice(splitAt + 1).trim();
      return { id: id || entry, label: label || entry };
    });

  if (!calendars.length) {
    throw new Error("Couldn't parse any calendars from Settings — use Label:CalendarID, comma-separated");
  }

  // Support pasting the private_key field either as literal "\n" escapes
  // (as it appears inside the downloaded JSON key file) or as real newlines.
  const privateKey = config.privateKey.includes("\\n")
    ? config.privateKey.replace(/\\n/g, "\n")
    : config.privateKey;

  return {
    serviceAccountEmail: config.serviceAccountEmail.trim(),
    privateKey,
    calendars,
  };
}

// ── Service-account auth (JWT-bearer, no OAuth redirect) ─────────────────

function base64url(input: Buffer): string {
  return input.toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

type TokenCacheEntry = { token: string; expiresAt: number };
const tokenCache = new Map<string, TokenCacheEntry>();

async function getAccessToken(instanceId: string, email: string, privateKey: string): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const cached = tokenCache.get(instanceId);
  if (cached && cached.expiresAt - 60 > now) return cached.token;

  const header = base64url(Buffer.from(JSON.stringify({ alg: "RS256", typ: "JWT" })));
  const claims = base64url(
    Buffer.from(
      JSON.stringify({
        iss: email,
        scope: "https://www.googleapis.com/auth/calendar",
        aud: "https://oauth2.googleapis.com/token",
        iat: now,
        exp: now + 3600,
      }),
    ),
  );
  const signingInput = `${header}.${claims}`;

  let signature: Buffer;
  try {
    const signer = createSign("RSA-SHA256");
    signer.update(signingInput);
    signer.end();
    signature = signer.sign(privateKey);
  } catch {
    throw new Error("Invalid service account private key — check it was pasted in full");
  }

  const jwt = `${signingInput}.${base64url(signature)}`;

  let response: Response;
  try {
    response = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
        assertion: jwt,
      }),
      cache: "no-store",
      signal: AbortSignal.timeout(10_000),
    });
  } catch {
    throw new Error("Couldn't reach Google's token endpoint");
  }

  if (!response.ok) {
    throw new Error(`Google rejected the service account credentials (${response.status})`);
  }

  const json = (await response.json()) as { access_token?: string; expires_in?: number };
  if (!json.access_token) throw new Error("Google did not return an access token");

  tokenCache.set(instanceId, { token: json.access_token, expiresAt: now + (json.expires_in ?? 3600) });
  return json.access_token;
}

// ── Fetch helper ────────────────────────────────────────────────────────

async function gcalFetch(token: string, path: string, init: RequestInit = {}): Promise<Response> {
  const url = `https://www.googleapis.com/calendar/v3${path}`;
  try {
    return await fetch(url, {
      ...init,
      headers: {
        ...(init.headers || {}),
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      cache: "no-store",
      signal: AbortSignal.timeout(10_000),
    });
  } catch {
    throw new Error("Couldn't reach the Google Calendar API");
  }
}

async function gcalErrorMessage(response: Response, fallback: string): Promise<string> {
  try {
    const json = await response.json();
    if (json?.error?.message) return String(json.error.message);
  } catch {
    // ignore non-JSON error bodies
  }
  if (response.status === 401 || response.status === 403) {
    return "Google rejected the request — check the calendar is shared with the service account and has the right permission";
  }
  return `${fallback} (${response.status})`;
}

// ── Normalizer ──────────────────────────────────────────────────────────

function toEvent(raw: Record<string, unknown>, calendarId: string, calendarLabel: string): GCalEvent | null {
  const id = typeof raw.id === "string" ? raw.id : null;
  if (!id) return null;
  const start = (raw.start as Record<string, unknown> | undefined) ?? {};
  const end = (raw.end as Record<string, unknown> | undefined) ?? {};
  const allDay = typeof start.date === "string" && typeof start.dateTime !== "string";
  return {
    id,
    calendarId,
    calendarLabel,
    title: String(raw.summary ?? "(No title)"),
    description: typeof raw.description === "string" ? raw.description : null,
    location: typeof raw.location === "string" ? raw.location : null,
    start: String(start.dateTime ?? start.date ?? ""),
    end: String(end.dateTime ?? end.date ?? ""),
    allDay,
    htmlLink: typeof raw.htmlLink === "string" ? raw.htmlLink : null,
  };
}

// ── Status ──────────────────────────────────────────────────────────────

export async function fetchGCalStatus(instanceId: string): Promise<GCalStatus> {
  const config = await loadGCalConfig(instanceId);
  const token = await getAccessToken(instanceId, config.serviceAccountEmail, config.privateKey);

  const timeMin = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
  const timeMax = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();

  // Each calendar is fetched independently so one bad calendar ID or a
  // missing share doesn't take out the others — same pattern as the
  // YouTube Music widget's state/playlists split.
  const results = await Promise.all(
    config.calendars.map(async (cal) => {
      try {
        const params = new URLSearchParams({
          timeMin,
          timeMax,
          singleEvents: "true",
          orderBy: "startTime",
          maxResults: "50",
        });
        const response = await gcalFetch(token, `/calendars/${encodeURIComponent(cal.id)}/events?${params}`);
        if (!response.ok) {
          throw new Error(await gcalErrorMessage(response, `Calendar "${cal.label}" failed to load`));
        }
        const json = (await response.json()) as { items?: Record<string, unknown>[] };
        const events = (json.items ?? [])
          .map((item) => toEvent(item, cal.id, cal.label))
          .filter((event): event is GCalEvent => event !== null);
        return { ok: true as const, calendar: cal, events };
      } catch (error) {
        return {
          ok: false as const,
          calendar: cal,
          message: error instanceof Error ? error.message : "Failed to load events",
        };
      }
    }),
  );

  const events = results
    .filter((r): r is { ok: true; calendar: GCalCalendarRef; events: GCalEvent[] } => r.ok)
    .flatMap((r) => r.events)
    .sort((a, b) => a.start.localeCompare(b.start));

  const errors: GCalCalendarError[] = results
    .filter((r): r is { ok: false; calendar: GCalCalendarRef; message: string } => !r.ok)
    .map((r) => ({ calendarId: r.calendar.id, label: r.calendar.label, message: r.message }));

  return { events, calendars: config.calendars, errors };
}

// ── Actions ─────────────────────────────────────────────────────────────

export type GCalActionKind = "create-event" | "update-event" | "delete-event";

function buildEventBody(payload: Record<string, unknown>): Record<string, unknown> {
  const title = String(payload.title || "").trim();
  if (!title) throw new Error("Title is required");

  const startVal = String(payload.start || "");
  const endVal = String(payload.end || "");
  if (!startVal || !endVal) throw new Error("Start and end are required");

  const allDay = Boolean(payload.allDay);
  const body: Record<string, unknown> = {
    summary: title,
    start: allDay ? { date: startVal } : { dateTime: startVal },
    end: allDay ? { date: endVal } : { dateTime: endVal },
  };
  if (payload.description) body.description = String(payload.description);
  if (payload.location) body.location = String(payload.location);
  return body;
}

export async function performGCalAction(
  instanceId: string,
  kind: GCalActionKind,
  payload: Record<string, unknown>,
) {
  const config = await loadGCalConfig(instanceId);
  const token = await getAccessToken(instanceId, config.serviceAccountEmail, config.privateKey);

  const calendarId = String(payload.calendarId || "");
  if (!calendarId) throw new Error("Missing calendar id");

  switch (kind) {
    case "create-event": {
      const body = buildEventBody(payload);
      const response = await gcalFetch(token, `/calendars/${encodeURIComponent(calendarId)}/events`, {
        method: "POST",
        body: JSON.stringify(body),
      });
      if (!response.ok) throw new Error(await gcalErrorMessage(response, "Failed to create event"));
      return response.json();
    }
    case "update-event": {
      const eventId = String(payload.eventId || "");
      if (!eventId) throw new Error("Missing event id");
      const body = buildEventBody(payload);
      const response = await gcalFetch(
        token,
        `/calendars/${encodeURIComponent(calendarId)}/events/${encodeURIComponent(eventId)}`,
        { method: "PATCH", body: JSON.stringify(body) },
      );
      if (!response.ok) throw new Error(await gcalErrorMessage(response, "Failed to update event"));
      return response.json();
    }
    case "delete-event": {
      const eventId = String(payload.eventId || "");
      if (!eventId) throw new Error("Missing event id");
      const response = await gcalFetch(
        token,
        `/calendars/${encodeURIComponent(calendarId)}/events/${encodeURIComponent(eventId)}`,
        { method: "DELETE" },
      );
      // Google returns 410 Gone if the event was already deleted — treat as success.
      if (!response.ok && response.status !== 410) {
        throw new Error(await gcalErrorMessage(response, "Failed to delete event"));
      }
      return null;
    }
    default:
      throw new Error("Unknown action");
  }
}
