import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { hasConnectionUrl, openUrlsFromConfig, primaryConnectionUrl } from "@/lib/open-href";

type Config = {
  baseUrl: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  token?: string;
  apiKey?: string;
  devices?: string | DeviceConfig[];
};

export type HaEntity = {
  entity_id: string;
  state: string;
  attributes: Record<string, unknown>;
  last_changed?: string;
};

export type DeviceConfig = {
  id: string;
  label: string;
  kind: string;
  entityId?: string;
  match?: string;
  domains?: string[];
};

export type HaDevice = {
  id: string;
  label: string;
  kind: string;
  entityId: string;
  entity: HaEntity;
  area?: string;
  related: HaEntity[];
};

type RegistryEntry = {
  entity_id: string;
  area_id?: string | null;
  device_id?: string | null;
  entity_category?: string | null;
};

type AreaEntry = { area_id: string; name: string };

const CARD_DOMAINS = [
  "camera",
  "light",
  "lock",
  "cover",
  "media_player",
  "switch",
  "vacuum",
  "climate",
] as const;

const CONTROLLABLE = [
  "light",
  "switch",
  "fan",
  "cover",
  "lock",
  "media_player",
  "button",
  "siren",
  "input_boolean",
  "vacuum",
];

export type HaConnectionSource = "private" | "public" | "unknown";

const SENSOR_DOMAINS = ["sensor", "binary_sensor", "event"];
const HIDE_CATEGORIES = new Set(["config", "diagnostic"]);
const MAX_AUTO_DEVICES = 24;

function apiRoot(url: string) {
  return String(url || "").replace(/\/$/, "");
}

function classifyConnectionSource(cfg: Config, base: string): HaConnectionSource {
  const normalized = apiRoot(base);
  if (cfg.baseUrl && apiRoot(cfg.baseUrl) === normalized) return "private";
  if (cfg.fallbackUrl && apiRoot(cfg.fallbackUrl) === normalized) return "public";
  return "unknown";
}

/**
 * Ordered list of API bases to try, private first, then public fallback.
 * Built directly from the widget's own config fields rather than trusting
 * connectionCandidates()'s ordering, which was found to put the public
 * (fallback) URL ahead of the private one for the Docker widget — same
 * shared helper is used here, so apply the same guard.
 */
function orderedBases(cfg: { privateUrl?: string; fallbackUrl?: string }): string[] {
  const seen = new Set<string>();
  const bases: string[] = [];
  const push = (url?: string) => {
    const v = String(url || "").trim();
    if (!v || seen.has(v)) return;
    seen.add(v);
    bases.push(v);
  };
  push(cfg.privateUrl); // Private - IP, always tried first
  push(cfg.fallbackUrl); // Fallback Public URL, only used if private fails/unreachable
  return bases;
}

async function config(id: string) {
  const value = (await readWidgetConfig(id)) as Config;
  const token = value.token || value.apiKey;
  if (!hasConnectionUrl(value) || !token) {
    throw new Error("Configure a Private - IP or Fallback Public URL, and token");
  }
  return {
    ...value,
    // Raw "Private - IP" field, kept verbatim (before primaryConnectionUrl()
    // below may rewrite baseUrl) so connection ordering/labeling reflects
    // what was actually configured.
    privateUrl: String(value.baseUrl || "").trim(),
    baseUrl: primaryConnectionUrl(value),
    token,
  };
}

async function request(id: string, path: string, init?: RequestInit) {
  const cfg = await config(id);
  let lastError: unknown;
  for (const base of orderedBases(cfg)) {
    try {
      const response = await fetch(joinUrl(base, path), {
        ...init,
        headers: {
          Authorization: `Bearer ${cfg.token}`,
          Accept: "application/json",
          ...(init?.body ? { "Content-Type": "application/json" } : {}),
          ...(init?.headers || {}),
        },
        cache: "no-store",
        signal: AbortSignal.timeout(10_000),
      });
      if (!response.ok) throw new Error(`Home Assistant HTTP ${response.status}`);
      return { data: response.status === 204 ? null : await response.json(), href: base };
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("Home Assistant unavailable");
}

async function requestBinary(id: string, path: string, init?: RequestInit) {
  const cfg = await config(id);
  let lastError: unknown;
  for (const base of orderedBases(cfg)) {
    try {
      const response = await fetch(joinUrl(base, path), {
        ...init,
        headers: {
          Authorization: `Bearer ${cfg.token}`,
          ...(init?.headers || {}),
        },
        cache: "no-store",
        signal: AbortSignal.timeout(20_000),
      });
      if (!response.ok) throw new Error(`Home Assistant HTTP ${response.status}`);
      return response;
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("Home Assistant unavailable");
}

const domain = (e: HaEntity | string) =>
  (typeof e === "string" ? e : e.entity_id).split(".")[0] || "unknown";

const unavailable = (e: HaEntity) => ["unknown", "unavailable"].includes(e.state);

const friendly = (e: HaEntity) =>
  String(e.attributes.friendly_name || e.entity_id.split(".")[1]?.replaceAll("_", " ") || e.entity_id);

function entityStem(entityId: string) {
  const slug = entityId.split(".").pop() || "";
  return slug.replace(/_live_view$|_live$|_stream$/i, "");
}

function parseDevicesConfig(raw: Config["devices"]): DeviceConfig[] {
  if (!raw) return [];
  if (Array.isArray(raw)) return raw;
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as DeviceConfig[]) : [];
  } catch {
    return [];
  }
}

function entityMatches(entity: HaEntity, cfg: DeviceConfig) {
  if (!cfg.match) return false;
  try {
    const re = new RegExp(cfg.match, "i");
    const slug = entity.entity_id.split(".").pop() || "";
    return re.test(entity.entity_id) || re.test(slug) || re.test(friendly(entity));
  } catch {
    return false;
  }
}

function resolveDeviceEntity(cfg: DeviceConfig, states: HaEntity[]) {
  if (cfg.entityId) {
    const hit = states.find((s) => s.entity_id === cfg.entityId);
    if (hit) return hit;
  }
  const domains =
    cfg.domains ||
    (cfg.kind === "camera"
      ? ["camera"]
      : cfg.kind === "media"
        ? ["media_player"]
        : null);
  const candidates = states.filter((s) => {
    if (domains && !domains.includes(domain(s))) return false;
    if (unavailable(s)) return false;
    return entityMatches(s, cfg);
  });
  if (!candidates.length) return null;
  if (cfg.kind === "camera") return candidates.find((c) => domain(c) === "camera") || candidates[0];
  if (cfg.kind === "media") return candidates.find((c) => domain(c) === "media_player") || candidates[0];
  return (
    candidates.find((c) => domain(c) === "sensor" && /cycle|state|status|job|mode|run/i.test(c.entity_id)) ||
    candidates.find((c) => domain(c) === "binary_sensor") ||
    candidates.find((c) => domain(c) === "sensor") ||
    candidates.find((c) => domain(c) === "switch") ||
    candidates[0]
  );
}

function isUsefulSensor(e: HaEntity) {
  if (!SENSOR_DOMAINS.includes(domain(e)) || unavailable(e)) return false;
  const dc = String(e.attributes.device_class || "");
  if (domain(e) === "event") return /motion|ding|doorbell/i.test(e.entity_id);
  return (
    ["temperature", "humidity", "illuminance", "power", "energy", "battery", "occupancy", "motion", "door", "window", "moisture"].includes(dc) ||
    /temp|humid|battery|motion|door|occupancy/i.test(e.entity_id)
  );
}

function isControllable(e: HaEntity) {
  return CONTROLLABLE.includes(domain(e)) && !unavailable(e);
}

function kindForDomain(d: string) {
  if (d === "media_player") return "media";
  if (d === "camera") return "camera";
  return d;
}

function applianceId(entity: HaEntity) {
  const text = `${entity.entity_id} ${friendly(entity)}`.toLowerCase();
  if (/washer|washing_machine|laundry/.test(text)) return "washer";
  if (/printer|brother|toner|drum|dcp[_ -]/.test(text)) return "printer";
  return entity.entity_id.replace(/\./g, "_");
}

function applianceLabel(entity: HaEntity) {
  return friendly(entity)
    .replace(/\s+(?:state|status|cycle|job|mode)$/i, "")
    .trim();
}

function isAppliancePrimary(entity: HaEntity) {
  if (domain(entity) !== "sensor" || unavailable(entity)) return false;
  const text = `${entity.entity_id} ${friendly(entity)}`;
  if (/backup|battery|signal|temperature|humidity|energy|power/i.test(text)) return false;
  return /(?:^|[_\s-])(?:state|status|cycle|job|mode)(?:$|[_\s-])/i.test(text);
}

async function loadAreasAndRegistry(id: string): Promise<{ areas: AreaEntry[]; registry: RegistryEntry[] }> {
  const tryFetch = async (method: "POST" | "GET") => {
    const init: RequestInit =
      method === "POST" ? { method: "POST", body: "{}" } : { method: "GET" };
    const [areasRes, registryRes] = await Promise.all([
      request(id, "/api/config/area_registry/list", init),
      request(id, "/api/config/entity_registry/list", init),
    ]);
    const areas = Array.isArray(areasRes.data) ? (areasRes.data as AreaEntry[]) : [];
    const registry = Array.isArray(registryRes.data) ? (registryRes.data as RegistryEntry[]) : [];
    if (!areas.length && !registry.length) throw new Error("empty registry");
    return { areas, registry };
  };

  try {
    return await tryFetch("POST");
  } catch {
    try {
      return await tryFetch("GET");
    } catch {
      return { areas: [], registry: [] };
    }
  }
}

function buildRelated(
  primary: HaEntity,
  states: HaEntity[],
  registry: RegistryEntry[],
  deviceEntities: Record<string, HaEntity[]>,
) {
  const reg = registry.find((r) => r.entity_id === primary.entity_id);
  const deviceId = reg?.device_id || undefined;
  const stem = entityStem(primary.entity_id);
  const related: HaEntity[] = [];
  const seen = new Set([primary.entity_id]);

  const consider = (state?: HaEntity) => {
    if (!state || seen.has(state.entity_id) || unavailable(state)) return;
    seen.add(state.entity_id);
    related.push(state);
  };

  if (deviceId && deviceEntities[deviceId]) {
    deviceEntities[deviceId].forEach(consider);
  }

  for (const state of states) {
    if (state.entity_id === primary.entity_id) continue;
    const slug = state.entity_id.split(".").pop() || "";
    if (slug.includes(stem) || (stem && slug.includes(stem.split("_")[0]))) consider(state);
  }

  return related.slice(0, 12);
}

function buildDeviceEntitiesMap(registry: RegistryEntry[], stateMap: Record<string, HaEntity>) {
  const deviceEntities: Record<string, HaEntity[]> = {};
  for (const r of registry) {
    if (r.entity_category && HIDE_CATEGORIES.has(r.entity_category)) continue;
    const state = stateMap[r.entity_id];
    if (!state || !r.device_id) continue;
    if (!deviceEntities[r.device_id]) deviceEntities[r.device_id] = [];
    deviceEntities[r.device_id].push(state);
  }
  return deviceEntities;
}

function areaNameFor(
  entityId: string,
  registry: RegistryEntry[],
  areas: AreaEntry[],
) {
  const reg = registry.find((r) => r.entity_id === entityId);
  if (!reg?.area_id) return undefined;
  return areas.find((a) => a.area_id === reg.area_id)?.name;
}

function buildConfiguredDevices(
  cfgs: DeviceConfig[],
  states: HaEntity[],
  registry: RegistryEntry[],
  areas: AreaEntry[],
  deviceEntities: Record<string, HaEntity[]>,
): HaDevice[] {
  const out: HaDevice[] = [];
  for (const cfg of cfgs) {
    const entity = resolveDeviceEntity(cfg, states);
    if (!entity) continue;
    out.push({
      id: cfg.id,
      label: cfg.label,
      kind: cfg.kind,
      entityId: entity.entity_id,
      entity,
      area: areaNameFor(entity.entity_id, registry, areas),
      related: buildRelated(entity, states, registry, deviceEntities),
    });
  }
  return out;
}

function buildAutoDevices(
  states: HaEntity[],
  registry: RegistryEntry[],
  areas: AreaEntry[],
  deviceEntities: Record<string, HaEntity[]>,
): HaDevice[] {
  const used = new Set<string>();
  const devices: HaDevice[] = [];

  // Prefer one card per HA device_id when the device has a primary card-domain entity
  for (const [deviceId, ents] of Object.entries(deviceEntities)) {
    const primary =
      CARD_DOMAINS.map((d) => ents.find((e) => domain(e) === d)).find(Boolean) ||
      null;
    if (!primary) continue;
    used.add(primary.entity_id);
    for (const e of ents) used.add(e.entity_id);
    devices.push({
      id: `dev_${deviceId.slice(0, 12)}`,
      label: friendly(primary),
      kind: kindForDomain(domain(primary)),
      entityId: primary.entity_id,
      entity: primary,
      area: areaNameFor(primary.entity_id, registry, areas),
      related: buildRelated(primary, states, registry, deviceEntities),
    });
    if (devices.length >= MAX_AUTO_DEVICES) return devices;
  }

  // Home Assistant exposes area/entity registries over WebSocket on many
  // versions, so their REST-shaped endpoints can return 404. In that case,
  // recover sensor-led appliances (washers, printers, etc.) by grouping their
  // related state/status entities instead of silently omitting them.
  const appliancePrimaries = states
    .filter((entity) => isAppliancePrimary(entity) && !used.has(entity.entity_id))
    .sort((a, b) => friendly(a).localeCompare(friendly(b)));

  for (const entity of appliancePrimaries) {
    const related = buildRelated(entity, states, registry, deviceEntities);
    used.add(entity.entity_id);
    related.forEach((item) => used.add(item.entity_id));
    devices.push({
      id: applianceId(entity),
      label: applianceLabel(entity),
      kind: "appliance",
      entityId: entity.entity_id,
      entity,
      area: areaNameFor(entity.entity_id, registry, areas),
      related,
    });
    if (devices.length >= MAX_AUTO_DEVICES) return devices;
  }

  // Remaining standalone card-domain entities
  const leftovers = states
    .filter((e) => CARD_DOMAINS.includes(domain(e) as (typeof CARD_DOMAINS)[number]) && !used.has(e.entity_id))
    .sort((a, b) => friendly(a).localeCompare(friendly(b)));

  for (const entity of leftovers) {
    if (used.has(entity.entity_id)) continue;
    const related = buildRelated(entity, states, registry, deviceEntities);
    used.add(entity.entity_id);
    related.forEach((item) => used.add(item.entity_id));
    devices.push({
      id: applianceId(entity),
      label: friendly(entity),
      kind: kindForDomain(domain(entity)),
      entityId: entity.entity_id,
      entity,
      area: areaNameFor(entity.entity_id, registry, areas),
      related,
    });
    if (devices.length >= MAX_AUTO_DEVICES) break;
  }

  return devices;
}

function findWeather(states: HaEntity[]) {
  const w = states.find((e) => domain(e) === "weather");
  if (w) return w;
  const t = states.find(
    (e) =>
      domain(e) === "sensor" &&
      (e.attributes.device_class === "temperature" || /outdoor.*temp|weather.*temp/i.test(e.entity_id)),
  );
  if (t) {
    return {
      entity_id: "weather.inferred",
      state: "Temp",
      attributes: { temperature: Number.parseFloat(t.state) || t.state, friendly_name: "Weather" },
    } satisfies HaEntity;
  }
  return undefined;
}

function stateIsProblem(e: HaEntity) {
  if (unavailable(e)) return false;
  const devClass = String(e.attributes.device_class || "");
  if (domain(e) === "lock") return ["unlocked", "open"].includes(e.state);
  if (domain(e) === "cover") return e.state === "open";
  if (domain(e) === "alarm_control_panel") return !["disarmed", "armed_home", "armed_away"].includes(e.state);
  if (domain(e) === "binary_sensor") {
    return e.state === "on" && ["problem", "safety", "smoke", "gas", "moisture", "tamper"].includes(devClass);
  }
  return false;
}

export async function fetchHomeAssistantStatus(id: string) {
  const cfg = await config(id);
  const rawCfg = (await readWidgetConfig(id)) as Config;
  const [{ data: info, href: configHref }, { data: rawStates }, areaData] = await Promise.all([
    request(id, "/api/config"),
    request(id, "/api/states"),
    loadAreasAndRegistry(id),
  ]);

  const states = (Array.isArray(rawStates) ? rawStates : []) as HaEntity[];
  const stateMap = Object.fromEntries(states.map((s) => [s.entity_id, s]));
  const deviceEntities = buildDeviceEntitiesMap(areaData.registry, stateMap);

  const visible = states.filter(
    (e) =>
      !unavailable(e) &&
      ["light", "switch", "fan", "cover", "lock", "media_player", "camera", "climate", "binary_sensor", "sensor", "vacuum"].includes(
        domain(e),
      ),
  );
  const controls = visible.filter((e) => isControllable(e)).slice(0, 12);
  const sensors = visible.filter((e) => isUsefulSensor(e) || domain(e) === "climate").slice(0, 8);
  const alerts = states.filter(stateIsProblem).slice(0, 6);
  const weather = findWeather(states);

  const configured = parseDevicesConfig(cfg.devices);
  const devices = configured.length
    ? buildConfiguredDevices(configured, states, areaData.registry, areaData.areas, deviceEntities)
    : buildAutoDevices(states, areaData.registry, areaData.areas, deviceEntities);

  return {
    ...openUrlsFromConfig(cfg),
    location: (info as { location_name?: string } | null)?.location_name || "Smart Home",
    weather,
    alerts,
    controls,
    sensors,
    devices,
    areas: areaData.areas.map((a) => ({ id: a.area_id, name: a.name })),
    connectionSource: classifyConnectionSource(rawCfg, configHref),
  };
}

function defaultServiceFor(entityId: string, state?: string) {
  const d = domain(entityId);
  if (d === "lock") return state === "locked" ? "unlock" : "lock";
  if (d === "cover") return state === "open" || state === "opening" ? "close_cover" : "open_cover";
  if (d === "media_player") return "media_play_pause";
  if (d === "camera") return "turn_on";
  if (d === "button") return "press";
  if (d === "vacuum") return state === "cleaning" ? "return_to_base" : "start";
  if (["light", "switch", "fan", "input_boolean", "siren"].includes(d)) {
    if (state === "on") return "turn_off";
    if (state === "off") return "turn_on";
    return "toggle";
  }
  return "toggle";
}

export async function callHomeAssistantService(id: string, entityId: string, service?: string) {
  const d = domain(entityId);
  let action = service;
  if (!action) {
    try {
      const { data } = await request(id, `/api/states/${encodeURIComponent(entityId)}`);
      const state = (data as HaEntity | null)?.state;
      action = defaultServiceFor(entityId, state);
    } catch {
      action = defaultServiceFor(entityId);
    }
  }
  await request(id, `/api/services/${d}/${action}`, {
    method: "POST",
    body: JSON.stringify({ entity_id: entityId }),
  });
}

/** Browser credentials for HA camera WebRTC (Ring live view requires this). */
export async function cameraStreamAuth(instanceId: string) {
  const cfg = await config(instanceId);
  const href = cfg.baseUrl.replace(/\/$/, "");
  const bases = orderedBases(cfg).map((u) => u.replace(/\/$/, ""));
  const uniqueBases = [...new Set(bases)];
  const toWs = (url: string) =>
    url.replace(/^http/i, (m) => (m.toLowerCase() === "https" ? "wss" : "ws")) + "/api/websocket";
  // Always try the configured private/LAN URL before the public fallback.
  const wsUrls = uniqueBases.map(toWs);
  return {
    href,
    bases: uniqueBases,
    wsUrl: wsUrls[0],
    wsUrls,
    token: cfg.token,
  };
}

/** Fetch `/api/camera_proxy/{entity_id}` (or stream) as a binary Response. */
export async function cameraSnapshot(instanceId: string, entityId: string, stream = false) {
  if (!entityId) throw new Error("Missing camera entity");
  const basePath = stream
    ? `/api/camera_proxy_stream/${encodeURIComponent(entityId)}`
    : `/api/camera_proxy/${encodeURIComponent(entityId)}`;

  // Prefer the entity's short-lived media token when available.
  try {
    const { data } = await request(instanceId, `/api/states/${encodeURIComponent(entityId)}`);
    const accessToken = String((data as HaEntity | null)?.attributes?.access_token || "");
    if (accessToken) {
      try {
        return await requestBinary(instanceId, `${basePath}?token=${encodeURIComponent(accessToken)}`);
      } catch {
        /* fall through */
      }
    }
  } catch {
    /* fall through */
  }

  const cfg = await config(instanceId);
  try {
    return await requestBinary(
      instanceId,
      `${basePath}?access_token=${encodeURIComponent(cfg.token)}`,
    );
  } catch {
    return requestBinary(instanceId, basePath);
  }
}
