import { readWidgetConfig } from "@/lib/config";

export type CryptoCoinDef = {
  id: string;
  symbol: string;
  name: string;
  emoji: string;
};

export type CryptoMarketItem = {
  id: string;
  symbol: string;
  name: string;
  emoji: string;
  image: string;
  current_price: number | null;
  price_change_percentage_1h_in_currency: number | null;
  price_change_percentage_24h_in_currency: number | null;
  price_change_percentage_7d_in_currency: number | null;
  market_cap: number | null;
  high_24h: number | null;
  low_24h: number | null;
  total_volume: number | null;
  market_cap_rank: number | null;
  circulating_supply: number | null;
  /** ~7d hourly sparkline from markets (avoids extra chart API calls) */
  sparkline: number[];
};

export const DEFAULT_COINS: CryptoCoinDef[] = [
  { id: "bitcoin", symbol: "BTC", name: "Bitcoin", emoji: "₿" },
  { id: "ethereum", symbol: "ETH", name: "Ethereum", emoji: "Ξ" },
  { id: "solana", symbol: "SOL", name: "Solana", emoji: "◎" },
  { id: "binancecoin", symbol: "BNB", name: "BNB", emoji: "🔶" },
  { id: "ripple", symbol: "XRP", name: "XRP", emoji: "✕" },
  { id: "dogecoin", symbol: "DOGE", name: "Dogecoin", emoji: "Ð" },
  { id: "cardano", symbol: "ADA", name: "Cardano", emoji: "₳" },
  { id: "avalanche-2", symbol: "AVAX", name: "Avalanche", emoji: "🔺" },
];

const DEFAULT_COINS_CSV = DEFAULT_COINS.map((c) => c.id).join(",");

type CgMarket = {
  id?: string;
  symbol?: string;
  name?: string;
  image?: string;
  current_price?: number | null;
  price_change_percentage_1h_in_currency?: number | null;
  price_change_percentage_24h_in_currency?: number | null;
  price_change_percentage_7d_in_currency?: number | null;
  market_cap?: number | null;
  high_24h?: number | null;
  low_24h?: number | null;
  total_volume?: number | null;
  market_cap_rank?: number | null;
  circulating_supply?: number | null;
  sparkline_in_7d?: { price?: number[] };
};

type CacheEntry<T> = { at: number; value: T };

const marketsCache = new Map<string, CacheEntry<CryptoMarketItem[]>>();
const chartCache = new Map<string, CacheEntry<number[]>>();
const MARKETS_TTL_MS = 60_000;
const CHART_TTL_MS = 5 * 60_000;

function byIdMap(coins: CryptoCoinDef[]) {
  return Object.fromEntries(coins.map((c) => [c.id, c]));
}

function resolveCoins(coinsCsv?: string): CryptoCoinDef[] {
  const ids = (coinsCsv || DEFAULT_COINS_CSV)
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  if (!ids.length) return DEFAULT_COINS;
  const catalog = byIdMap(DEFAULT_COINS);
  return ids.map((id) => catalog[id] || { id, symbol: id.slice(0, 4).toUpperCase(), name: id, emoji: "●" });
}

async function fetchJson<T>(url: string): Promise<T> {
  const response = await fetch(url, {
    headers: { Accept: "application/json" },
    cache: "no-store",
    signal: AbortSignal.timeout(12_000),
  });
  if (response.status === 429) {
    throw new Error("CoinGecko rate limit — wait a minute and try again");
  }
  if (!response.ok) throw new Error(`CoinGecko HTTP ${response.status}`);
  return response.json() as Promise<T>;
}

export async function cryptoStatus(instanceId: string) {
  const config = (await readWidgetConfig(instanceId)) as { coins?: string; defaultInterval?: string };
  const coins = resolveCoins(config.coins);
  const ids = coins.map((c) => c.id).join(",");
  const cacheKey = ids;
  const defaultInterval =
    config.defaultInterval === "24h" || config.defaultInterval === "7d"
      ? config.defaultInterval
      : "1h";

  const cached = marketsCache.get(cacheKey);
  if (cached && Date.now() - cached.at < MARKETS_TTL_MS) {
    return {
      items: cached.value,
      defaultInterval,
      updatedAt: new Date(cached.at).toISOString(),
      cached: true,
    };
  }

  const url =
    `https://api.coingecko.com/api/v3/coins/markets` +
    `?vs_currency=usd` +
    `&ids=${encodeURIComponent(ids)}` +
    `&order=market_cap_desc` +
    `&per_page=50` +
    `&page=1` +
    `&sparkline=true` +
    `&price_change_percentage=1h%2C24h%2C7d`;

  let markets: CgMarket[];
  try {
    markets = await fetchJson<CgMarket[]>(url);
  } catch (error) {
    if (cached) {
      return {
        items: cached.value,
        defaultInterval,
        updatedAt: new Date(cached.at).toISOString(),
        cached: true,
        stale: true,
      };
    }
    throw error;
  }

  const byId: Record<string, CgMarket> = {};
  for (const row of markets) {
    if (row.id) byId[row.id] = row;
  }

  const items: CryptoMarketItem[] = coins.map((coin) => {
    const d = byId[coin.id];
    const symbol = (d?.symbol || coin.symbol).toUpperCase();
    const sparkline = (d?.sparkline_in_7d?.price || []).filter(
      (v) => typeof v === "number" && Number.isFinite(v),
    );
    return {
      id: coin.id,
      symbol,
      name: d?.name || coin.name,
      emoji: coin.emoji,
      image:
        d?.image ||
        `https://assets.coincap.io/assets/icons/${symbol.toLowerCase()}@2x.png`,
      current_price: d?.current_price ?? null,
      price_change_percentage_1h_in_currency: d?.price_change_percentage_1h_in_currency ?? null,
      price_change_percentage_24h_in_currency: d?.price_change_percentage_24h_in_currency ?? null,
      price_change_percentage_7d_in_currency: d?.price_change_percentage_7d_in_currency ?? null,
      market_cap: d?.market_cap ?? null,
      high_24h: d?.high_24h ?? null,
      low_24h: d?.low_24h ?? null,
      total_volume: d?.total_volume ?? null,
      market_cap_rank: d?.market_cap_rank ?? null,
      circulating_supply: d?.circulating_supply ?? null,
      sparkline,
    };
  });

  marketsCache.set(cacheKey, { at: Date.now(), value: items });

  return {
    items,
    defaultInterval,
    updatedAt: new Date().toISOString(),
  };
}

export async function cryptoChart(coinId: string, days: number) {
  const id = coinId.trim();
  if (!id) throw new Error("Missing coin id");
  const safeDays = Math.max(1, Math.round(days) || 1);
  const cacheKey = `${id}:${safeDays}`;
  const cached = chartCache.get(cacheKey);
  if (cached && Date.now() - cached.at < CHART_TTL_MS) {
    return { prices: cached.value, cached: true };
  }

  // Free API: omit interval (often rejected / rate-limited); days alone is enough
  const url =
    `https://api.coingecko.com/api/v3/coins/${encodeURIComponent(id)}/market_chart` +
    `?vs_currency=usd&days=${safeDays}`;

  try {
    const data = await fetchJson<{ prices?: Array<[number, number]> }>(url);
    const prices = (data.prices || [])
      .map((p) => p[1])
      .filter((v) => typeof v === "number" && Number.isFinite(v));
    chartCache.set(cacheKey, { at: Date.now(), value: prices });
    return { prices };
  } catch (error) {
    if (cached) return { prices: cached.value, cached: true, stale: true };
    throw error;
  }
}
