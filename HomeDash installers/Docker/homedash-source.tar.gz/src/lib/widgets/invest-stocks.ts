import { readWidgetConfig } from "@/lib/config";

export type StockTickerDef = {
  symbol: string;
  name: string;
};

export type StockQuoteItem = {
  symbol: string;
  name: string;
  image: string;
  price: number | null;
  change: number | null;
  open: number | null;
  high: number | null;
  low: number | null;
  prevClose: number | null;
};

export type ChartTab = "1h" | "24h" | "7d" | "30d" | "90d" | "180d" | "365d" | "live";

export const DEFAULT_TICKERS: StockTickerDef[] = [
  { symbol: "AMZN", name: "Amazon" },
  { symbol: "AMD", name: "AMD" },
  { symbol: "NVDA", name: "NVIDIA" },
  { symbol: "MSFT", name: "Microsoft" },
  { symbol: "AAPL", name: "Apple" },
  { symbol: "GOOG", name: "Alphabet" },
  { symbol: "META", name: "Meta" },
  { symbol: "TSLA", name: "Tesla" },
  { symbol: "SPY", name: "S&P 500 ETF" },
  { symbol: "QQQ", name: "Nasdaq ETF" },
];

const DEFAULT_PROXY = "https://stock-proxy.janzenmediagroup.com";
const QUOTE_GAP_MS = 700;
const QUOTES_TTL_MS = 60_000;
const CHART_TTL_MS = 5 * 60_000;

type CacheEntry<T> = { at: number; value: T };
type FinnhubQuote = {
  c?: number;
  d?: number;
  dp?: number;
  h?: number;
  l?: number;
  o?: number;
  pc?: number;
};

const quotesCache = new Map<string, CacheEntry<StockQuoteItem[]>>();
const chartCache = new Map<string, CacheEntry<number[]>>();

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function bySymbol(tickers: StockTickerDef[]) {
  return Object.fromEntries(tickers.map((t) => [t.symbol.toUpperCase(), t]));
}

function resolveTickers(symbolsCsv?: string): StockTickerDef[] {
  const catalog = bySymbol(DEFAULT_TICKERS);
  const symbols = (symbolsCsv || DEFAULT_TICKERS.map((t) => t.symbol).join(","))
    .split(",")
    .map((s) => s.trim().toUpperCase())
    .filter(Boolean);
  if (!symbols.length) return DEFAULT_TICKERS;
  return symbols.map((symbol) => catalog[symbol] || { symbol, name: symbol });
}

export function isMarketOpen(now = new Date()) {
  // Approximate US equity hours in Eastern Time (no holiday calendar).
  const weekday = new Intl.DateTimeFormat("en-US", {
    timeZone: "America/New_York",
    weekday: "short",
  }).format(now);
  if (weekday === "Sat" || weekday === "Sun") return false;
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "America/New_York",
    hour: "numeric",
    minute: "numeric",
    hour12: false,
  }).formatToParts(now);
  const hour = Number(parts.find((p) => p.type === "hour")?.value || 0);
  const minute = Number(parts.find((p) => p.type === "minute")?.value || 0);
  const h = hour + minute / 60;
  return h >= 9.5 && h < 16;
}

function stockIconUrl(symbol: string) {
  return `https://assets.parqet.com/logos/symbol/${encodeURIComponent(symbol)}?format=svg`;
}

async function fetchJson<T>(url: string): Promise<T> {
  const response = await fetch(url, {
    headers: { Accept: "application/json" },
    cache: "no-store",
    signal: AbortSignal.timeout(12_000),
  });
  if (response.status === 429) {
    throw new Error("Rate limit — wait a minute and try again");
  }
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response.json() as Promise<T>;
}

async function fetchQuote(symbol: string, apiKey: string): Promise<FinnhubQuote> {
  const url =
    `https://finnhub.io/api/v1/quote` +
    `?symbol=${encodeURIComponent(symbol)}&token=${encodeURIComponent(apiKey)}`;
  return fetchJson<FinnhubQuote>(url);
}

function mapQuote(ticker: StockTickerDef, q: FinnhubQuote): StockQuoteItem {
  const price = typeof q.c === "number" && Number.isFinite(q.c) ? q.c : null;
  const prev = typeof q.pc === "number" && Number.isFinite(q.pc) ? q.pc : null;
  const pct =
    typeof q.dp === "number" && Number.isFinite(q.dp)
      ? q.dp
      : price != null && prev != null && prev !== 0
        ? ((price - prev) / prev) * 100
        : null;
  return {
    symbol: ticker.symbol,
    name: ticker.name,
    image: stockIconUrl(ticker.symbol),
    price,
    change: pct,
    open: typeof q.o === "number" && Number.isFinite(q.o) ? q.o : null,
    high: typeof q.h === "number" && Number.isFinite(q.h) ? q.h : null,
    low: typeof q.l === "number" && Number.isFinite(q.l) ? q.l : null,
    prevClose: prev,
  };
}

export async function stocksStatus(instanceId: string) {
  const config = (await readWidgetConfig(instanceId)) as {
    apiKey?: string;
    symbols?: string;
    stockProxyUrl?: string;
  };
  if (!config.apiKey?.trim()) {
    throw new Error("Configure a Finnhub API key in Settings");
  }
  const apiKey = config.apiKey.trim();
  const tickers = resolveTickers(config.symbols);
  const cacheKey = `${apiKey.slice(0, 8)}:${tickers.map((t) => t.symbol).join(",")}`;
  const cached = quotesCache.get(cacheKey);
  if (cached && Date.now() - cached.at < QUOTES_TTL_MS) {
    return {
      items: cached.value,
      marketOpen: isMarketOpen(),
      updatedAt: new Date(cached.at).toISOString(),
      cached: true,
    };
  }

  const items: StockQuoteItem[] = [];
  let lastError: Error | null = null;
  for (let i = 0; i < tickers.length; i++) {
    const ticker = tickers[i];
    try {
      const quote = await fetchQuote(ticker.symbol, apiKey);
      items.push(mapQuote(ticker, quote));
    } catch (error) {
      lastError = error instanceof Error ? error : new Error("Quote failed");
      items.push({
        symbol: ticker.symbol,
        name: ticker.name,
        image: stockIconUrl(ticker.symbol),
        price: null,
        change: null,
        open: null,
        high: null,
        low: null,
        prevClose: null,
      });
    }
    if (i < tickers.length - 1) await sleep(QUOTE_GAP_MS);
  }

  if (!items.some((item) => item.price != null)) {
    if (cached) {
      return {
        items: cached.value,
        marketOpen: isMarketOpen(),
        updatedAt: new Date(cached.at).toISOString(),
        cached: true,
        stale: true,
      };
    }
    throw lastError || new Error("Failed to load stock quotes");
  }

  quotesCache.set(cacheKey, { at: Date.now(), value: items });
  return {
    items,
    marketOpen: isMarketOpen(),
    updatedAt: new Date().toISOString(),
  };
}

function chartParams(tab: ChartTab): { interval: string; range: string } {
  if (tab === "live" || tab === "1h") return { interval: "5m", range: "1d" };
  if (tab === "24h") return { interval: "60m", range: "5d" };
  if (tab === "30d") return { interval: "1d", range: "1mo" };
  if (tab === "90d") return { interval: "1d", range: "3mo" };
  if (tab === "180d") return { interval: "1d", range: "6mo" };
  if (tab === "365d") return { interval: "1d", range: "1y" };
  return { interval: "1d", range: "1mo" };
}

function chartFallback(tab: ChartTab): { interval: string; range: string } | null {
  if (tab === "live" || tab === "1h") return { interval: "60m", range: "5d" };
  if (tab === "24h") return { interval: "1d", range: "5d" };
  if (tab === "30d") return { interval: "1d", range: "3mo" };
  if (tab === "90d" || tab === "180d" || tab === "365d") return null;
  return { interval: "1d", range: "3mo" };
}

async function fetchCloses(proxyBase: string, symbol: string, interval: string, range: string) {
  const base = proxyBase.replace(/\/$/, "");
  const url =
    `${base}?symbol=${encodeURIComponent(symbol)}` +
    `&interval=${encodeURIComponent(interval)}&range=${encodeURIComponent(range)}`;
  const data = await fetchJson<{
    chart?: { result?: Array<{ indicators?: { quote?: Array<{ close?: Array<number | null> }> } }> };
  }>(url);
  const closes = data.chart?.result?.[0]?.indicators?.quote?.[0]?.close || [];
  return closes.filter((v): v is number => typeof v === "number" && Number.isFinite(v));
}

export async function stocksChart(symbolRaw: string, tabRaw: string, instanceId?: string) {
  const symbol = symbolRaw.trim().toUpperCase();
  if (!symbol) throw new Error("Missing symbol");
  const tab = (["1h", "24h", "7d", "30d", "90d", "180d", "365d", "live"].includes(tabRaw) ? tabRaw : "live") as ChartTab;

  let proxyBase = DEFAULT_PROXY;
  if (instanceId) {
    const config = (await readWidgetConfig(instanceId)) as { stockProxyUrl?: string };
    if (config.stockProxyUrl?.trim()) proxyBase = config.stockProxyUrl.trim();
  }

  const cacheKey = `${proxyBase}|${symbol}|${tab}`;
  const cached = chartCache.get(cacheKey);
  if (cached && Date.now() - cached.at < CHART_TTL_MS) {
    return { prices: cached.value, cached: true };
  }

  const primary = chartParams(tab);
  let prices: number[] = [];
  try {
    prices = await fetchCloses(proxyBase, symbol, primary.interval, primary.range);
    if (prices.length < 2) {
      const fallback = chartFallback(tab);
      if (fallback) {
        prices = await fetchCloses(proxyBase, symbol, fallback.interval, fallback.range);
      }
    }
  } catch (error) {
    if (cached) return { prices: cached.value, cached: true, stale: true };
    throw error;
  }

  if (prices.length) chartCache.set(cacheKey, { at: Date.now(), value: prices });
  return { prices };
}
