import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { isPrivateConnectionUrl, primaryConnectionUrl } from "@/lib/open-href";
import { cachedStatus } from "@/lib/status-cache";

/**
 * Jellyfin Collection Manager (JCM) panel — read-only status for the dashboard card.
 * JCM serves a small JSON API on its panel port (default 8090). When a PIN is set it
 * answers 401 until POST /api/login {pin} hands back a `jcmp` cookie. With no PIN the
 * API is open. POSTs would need `Content-Type: application/json` + `X-JCM: 1`; this
 * widget only reads, except for the login call.
 */
type Config = {
  baseUrl: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  pin?: string;
};

export type JcmConnectionSource = "private" | "public" | "unknown";

class JcmHttpError extends Error {
  status?: number;
  drift?: boolean;
  constructor(message: string, status?: number, drift?: boolean) {
    super(message);
    this.name = "JcmHttpError";
    this.status = status;
    this.drift = drift;
  }
}

const cookieCache = new Map<string, string>();

function apiRoot(url: string) {
  return String(url || "").replace(/\/$/, "");
}

async function loadConfig(instanceId: string): Promise<Config> {
  const value = (await readWidgetConfig(instanceId)) as Partial<Config>;
  const hasAnyUrl = [value.baseUrl, value.fallbackUrl, value.publicUrl, value.openFallbackUrl].some(Boolean);
  if (!hasAnyUrl) {
    throw new Error("Configure a Private - IP or Fallback Public URL in Settings");
  }
  return { ...value, baseUrl: primaryConnectionUrl(value) } as Config;
}

async function classifyConnectionSource(instanceId: string, base: string): Promise<JcmConnectionSource> {
  const raw = (await readWidgetConfig(instanceId)) as Partial<Config>;
  const normalized = apiRoot(base);
  if (raw.baseUrl && apiRoot(raw.baseUrl) === normalized) return "private";
  if (raw.publicUrl && apiRoot(raw.publicUrl) === normalized) return "private";
  if (raw.fallbackUrl && apiRoot(raw.fallbackUrl) === normalized) return "public";
  if (raw.openFallbackUrl && apiRoot(raw.openFallbackUrl) === normalized) return "public";
  return "unknown";
}

function readSetCookie(response: Response): string {
  const anyHeaders = response.headers as unknown as { getSetCookie?: () => string[] };
  const list = typeof anyHeaders.getSetCookie === "function" ? anyHeaders.getSetCookie() : [];
  const raw = list.length ? list : [response.headers.get("set-cookie") || ""];
  for (const line of raw) {
    const match = /(?:^|[,;\s])jcmp=([^;,\s]+)/.exec(line);
    if (match) return `jcmp=${match[1]}`;
  }
  return "";
}

async function login(config: Config, base: string): Promise<string> {
  const pin = String(config.pin || "").trim();
  if (!pin) {
    throw new JcmHttpError("This panel needs a PIN. Enter it in the widget settings (Panel PIN).", 401);
  }
  const response = await fetch(joinUrl(base, "/api/login"), {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-JCM": "1" },
    body: JSON.stringify({ pin }),
    cache: "no-store",
    signal: AbortSignal.timeout(10_000),
  });
  if (response.status === 403 || response.status === 429) {
    const body = (await response.json().catch(() => ({}))) as { error?: string };
    throw new JcmHttpError(body.error || "Wrong PIN", response.status);
  }
  if (!response.ok) throw new JcmHttpError(`Login failed (HTTP ${response.status})`, response.status);
  const cookie = readSetCookie(response);
  if (cookie) cookieCache.set(`${base}`, cookie);
  return cookie;
}

async function jcmFetch<T>(
  config: Config,
  path: string,
  post?: Record<string, unknown>,
): Promise<{ data: T; baseUrl: string }> {
  let last: unknown;
  const bases = Array.from(
    new Set(
      [config.baseUrl, config.fallbackUrl, config.publicUrl, config.openFallbackUrl].filter(Boolean) as string[],
    ),
  ).sort((a, b) => Number(isPrivateConnectionUrl(b)) - Number(isPrivateConnectionUrl(a)));

  for (const base of bases) {
    try {
      for (let attempt = 0; attempt < 2; attempt += 1) {
        const headers: Record<string, string> = { Accept: "application/json" };
        if (post) {
          headers["Content-Type"] = "application/json";
          headers["X-JCM"] = "1";
        }
        const cookie = cookieCache.get(base);
        if (cookie) headers.Cookie = cookie;
        const response = await fetch(joinUrl(base, path), {
          method: post ? "POST" : "GET",
          headers,
          body: post ? JSON.stringify(post) : undefined,
          cache: "no-store",
          signal: AbortSignal.timeout(post ? 120_000 : 20_000),
        });
        if (response.status === 401 && attempt === 0) {
          cookieCache.delete(base);
          await login(config, base);
          continue;
        }
        const text = await response.text();
        let data: unknown = null;
        try {
          data = text ? JSON.parse(text) : null;
        } catch {
          throw new JcmHttpError(`Unexpected reply from the panel (${path}, HTTP ${response.status})`, response.status);
        }
        if (!response.ok) {
          const message = (data as { error?: string } | null)?.error;
          const hasDrift = Boolean((data as { drift?: unknown } | null)?.drift);
          if (post) {
            throw new JcmHttpError(message || `Panel error (${path}, HTTP ${response.status})`, response.status, hasDrift);
          }
          throw new JcmHttpError(
            message === "auth" ? "This panel needs a PIN. Enter it in the widget settings (Panel PIN)." : message || `Panel error (${path}, HTTP ${response.status})`,
            response.status,
          );
        }
        return { data: data as T, baseUrl: base };
      }
    } catch (error) {
      if (post && error instanceof JcmHttpError && error.status) throw error;
      last = error;
    }
  }
  throw last instanceof Error ? last : new Error("Collection Manager unavailable");
}

type RawStatus = {
  version?: string;
  jellyfin?: { configured?: boolean; ok?: boolean; error?: string; name?: string; version?: string };
  seer?: { configured?: boolean };
  pin_set?: boolean;
  backup?: { ok?: boolean; error?: string };
  last_restore_point?: { name?: string; created?: string; file?: string } | null;
  undo_available?: { label?: string; created?: string } | null;
};

type RawCollection = { name?: string; title?: string; count?: number; movies?: number; series?: number; has_poster?: boolean };

async function jcmStatusUncached(instanceId: string) {
  const config = await loadConfig(instanceId);

  // The status call also proves the panel is up (and logs in if a PIN is set).
  const { data: status, baseUrl: activeBase } = await jcmFetch<RawStatus>(config, "/api/status");

  const [collectionsRes, suggestionsRes, scanRes, historyRes, missingRes] = await Promise.allSettled([
    jcmFetch<{ collections?: RawCollection[] }>(config, "/api/collections"),
    jcmFetch<Record<string, unknown>>(config, "/api/suggestions"),
    jcmFetch<Record<string, unknown>>(config, "/api/scan"),
    jcmFetch<{ runs?: Array<{ label?: string; created?: string; status?: string; undone?: boolean }> }>(
      config,
      "/api/history",
    ),
    jcmFetch<unknown>(config, "/api/missing"),
  ]);

  let missing: number | null = null;
  if (missingRes.status === "fulfilled") {
    const m = normalizeMissing(missingRes.value.data);
    missing = m.checked ? m.missing : null;
  }

  let collections: {
    total: number;
    movies: number;
    series: number;
    noPoster: number;
    empty: number;
    top: Array<{ name: string; count: number }>;
  } | null = null;
  if (collectionsRes.status === "fulfilled") {
    const list = collectionsRes.value.data?.collections || [];
    collections = {
      total: list.length,
      movies: list.reduce((n, c) => n + Number(c.movies || 0), 0),
      series: list.reduce((n, c) => n + Number(c.series || 0), 0),
      noPoster: list.filter((c) => c.has_poster === false).length,
      empty: list.filter((c) => Number(c.count || 0) === 0).length,
      top: list
        .map((c) => ({ name: String(c.name || c.title || ""), count: Number(c.count || 0) }))
        .filter((c) => c.name)
        .sort((a, b) => b.count - a.count)
        .slice(0, 5),
    };
  }

  // Suggestions / needs-attention: counted from whichever arrays the panel returns.
  let suggestions: number | null = null;
  let attention: number | null = null;
  if (suggestionsRes.status === "fulfilled") {
    const view = suggestionsRes.value.data || {};
    if (Array.isArray(view.suggestions)) suggestions = view.suggestions.length;
    if (Array.isArray(view.needs_attention)) attention = view.needs_attention.length;
  }

  let scan: { running: boolean; last: string } | null = null;
  if (scanRes.status === "fulfilled") {
    const s = (scanRes.value.data || {}) as Record<string, unknown>;
    let last = "";
    for (const [key, value] of Object.entries(s)) {
      if (!/(finish|last|end|done|complete|updated|time|_at)/i.test(key) || /start/i.test(key)) continue;
      if (typeof value === "string" && Number.isFinite(Date.parse(value))) {
        last = value;
        break;
      }
      if (typeof value === "number" && value > 1e9) {
        last = new Date((value < 1e12 ? value * 1000 : value)).toISOString();
        break;
      }
    }
    scan = { running: s.running === true, last };
  }

  let lastChange: { label: string; created: string; status: string } | null = null;
  let recent: Array<{ label: string; created: string; status: string; undone: boolean }> = [];
  if (historyRes.status === "fulfilled") {
    const runs = historyRes.value.data?.runs || [];
    recent = runs.slice(0, 5).map((r) => ({
      label: r.label || "Change",
      created: r.created || "",
      status: r.status || "",
      undone: Boolean(r.undone),
    }));
    const run = runs[0];
    if (run) lastChange = { label: run.label || "", created: run.created || "", status: run.status || "" };
  }

  return {
    version: status?.version || "",
    pinSet: Boolean(status?.pin_set),
    jellyfin: {
      configured: Boolean(status?.jellyfin?.configured),
      ok: Boolean(status?.jellyfin?.ok),
      name: status?.jellyfin?.name || "",
      version: status?.jellyfin?.version || "",
      error: status?.jellyfin?.error || "",
    },
    collections,
    suggestions,
    attention,
    missing,
    scan,
    lastRestorePoint: status?.last_restore_point
      ? { name: status.last_restore_point.name || "", created: status.last_restore_point.created || "" }
      : null,
    lastChange,
    recent,
    undoAvailable: status?.undo_available
      ? { label: status.undo_available.label || "", created: status.undo_available.created || "" }
      : null,
    publicUrl: config.publicUrl?.trim() || config.baseUrl,
    openFallbackUrl: config.openFallbackUrl?.trim() || config.fallbackUrl?.trim() || "",
    connectionSource: await classifyConnectionSource(instanceId, activeBase),
  };
}

export type JcmStatus = Awaited<ReturnType<typeof jcmStatusUncached>>;

export async function jcmStatus(instanceId: string) {
  return cachedStatus(`jellyfin-collections-mgr:${instanceId}`, 30_000, () => jcmStatusUncached(instanceId));
}

export async function jcmStatusFresh(instanceId: string) {
  return jcmStatusUncached(instanceId);
}

export type JcmActionResult = { ok: boolean; message: string; drift?: boolean };

/** Safe, user-triggered actions. Each maps to one JCM panel endpoint. */
export async function jcmAction(instanceId: string, action: string, force = false): Promise<JcmActionResult> {
  const config = await loadConfig(instanceId);
  try {
    if (action === "scan") {
      const { data } = await jcmFetch<{ started?: boolean; message?: string; error?: string }>(
        config,
        "/api/scan",
        { reason: "manual" },
      );
      return { ok: true, message: data?.message || "Scan started" };
    }
    if (action === "refresh") {
      await jcmFetch(config, "/api/refresh", {});
      return { ok: true, message: "Library cache refreshed" };
    }
    if (action === "undo") {
      await jcmFetch(config, "/api/undo", { force });
      return { ok: true, message: "Last change undone" };
    }
  } catch (error) {
    if (error instanceof JcmHttpError) return { ok: false, message: error.message, drift: error.drift };
    throw error;
  }
  throw new Error("Unknown action");
}

// ---------- passthrough for the manager screens (whitelisted panel endpoints only) ----------
const GET_ALLOW = [
  /^\/api\/collections$/,
  /^\/api\/collections\/[0-9A-Fa-f-]{32,36}$/,
  /^\/api\/organize-data$/,
  /^\/api\/library\/search$/,
  /^\/api\/in-several$/,
  /^\/api\/suggestions$/,
  /^\/api\/missing$/,
];
const POST_ALLOW = [
  /^\/api\/titles\/add$/,
  /^\/api\/titles\/remove$/,
  /^\/api\/collections\/merge$/,
  /^\/api\/collections\/combine$/,
  /^\/api\/collections\/delete_empty$/,
  /^\/api\/suggestions\/(approve|skip|unskip|ignore|unignore|attn_ignore|attn_unignore)$/,
  /^\/api\/missing\/(check|request)$/,
];

export class JcmProxyError extends Error {
  status: number;
  drift?: boolean;
  constructor(message: string, status: number, drift?: boolean) {
    super(message);
    this.status = status;
    this.drift = drift;
  }
}

export async function jcmProxy(
  instanceId: string,
  method: "GET" | "POST",
  pathWithQuery: string,
  body?: Record<string, unknown>,
): Promise<unknown> {
  const pathname = pathWithQuery.split("?")[0];
  const allowed = (method === "GET" ? GET_ALLOW : POST_ALLOW).some((re) => re.test(pathname));
  if (!allowed) throw new JcmProxyError("That panel action is not available from the widget", 403);
  const config = await loadConfig(instanceId);
  try {
    const { data } = await jcmFetch<unknown>(config, pathWithQuery, method === "POST" ? body || {} : undefined);
    return data;
  } catch (error) {
    if (error instanceof JcmHttpError) throw new JcmProxyError(error.message, error.status || 502, error.drift);
    throw error;
  }
}

export async function jcmImage(instanceId: string, id: string): Promise<{ body: ArrayBuffer; type: string }> {
  if (!/^[0-9A-Fa-f-]{32,36}$/.test(id)) throw new JcmProxyError("Bad image id", 400);
  const config = await loadConfig(instanceId);
  const bases = Array.from(
    new Set([config.baseUrl, config.fallbackUrl, config.publicUrl, config.openFallbackUrl].filter(Boolean) as string[]),
  ).sort((a, b) => Number(isPrivateConnectionUrl(b)) - Number(isPrivateConnectionUrl(a)));
  let last: unknown;
  for (const base of bases) {
    try {
      for (let attempt = 0; attempt < 2; attempt += 1) {
        const headers: Record<string, string> = {};
        const cookie = cookieCache.get(base);
        if (cookie) headers.Cookie = cookie;
        const response = await fetch(joinUrl(base, `/img/${id}`), {
          headers,
          cache: "no-store",
          signal: AbortSignal.timeout(20_000),
        });
        if (response.status === 401 && attempt === 0) {
          cookieCache.delete(base);
          await login(config, base);
          continue;
        }
        if (!response.ok) throw new JcmProxyError(`Image not available (HTTP ${response.status})`, response.status);
        return { body: await response.arrayBuffer(), type: response.headers.get("content-type") || "image/jpeg" };
      }
    } catch (error) {
      last = error;
    }
  }
  throw last instanceof Error ? last : new Error("Image unavailable");
}

// ---------- Missing tab (franchise films that are not in the Jellyfin library) ----------
export type JcmMissingFilm = {
  id: string;
  title: string;
  year: string;
  released: boolean;
  poster: string;
  seer: string;
  app: { result: string; detail: string } | null;
};
export type JcmMissingFranchise = {
  id: string;
  name: string;
  inCollections: string[];
  libs: string[];
  have: Array<{ id: string; title: string; year: string }>;
  missing: JcmMissingFilm[];
};
export type JcmMissing = {
  running: boolean;
  progress: { phase: string; done: number; total: number };
  error: string;
  checked: boolean;
  finished: string;
  seerConfigured: boolean;
  seerError: string;
  hasTmdb: boolean;
  libraries: Array<{ id: string; name: string }>;
  franchises: JcmMissingFranchise[];
  missing: number;
  unreleased: number;
};

const asArr = (v: unknown): Array<Record<string, unknown>> =>
  Array.isArray(v) ? (v.filter((x) => x && typeof x === "object") as Array<Record<string, unknown>>) : [];
const str = (v: unknown) => (v === null || v === undefined ? "" : String(v));

function posterUrl(v: unknown): string {
  const raw = str(v);
  if (!raw) return "";
  if (/^https?:\/\//i.test(raw)) return raw;
  if (raw.startsWith("/")) return `https://image.tmdb.org/t/p/w342${raw}`;
  return "";
}

/** Shape of the panel's GET /api/missing (missing.py: Missing.view). */
export function normalizeMissing(raw: unknown): JcmMissing {
  const v = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const franchises: JcmMissingFranchise[] = asArr(v.groups).map((g) => ({
    id: str(g.id),
    name: str(g.name),
    inCollections: Array.isArray(g.in_collections) ? g.in_collections.map(str) : [],
    libs: Array.isArray(g.libs) ? g.libs.map(str) : [],
    have: asArr(g.have).map((h) => ({ id: str(h.id), title: str(h.title), year: str(h.year) })),
    missing: asArr(g.missing).map((m) => {
      const app = m.app && typeof m.app === "object" ? (m.app as Record<string, unknown>) : null;
      return {
        id: str(m.tmdb),
        title: str(m.title),
        year: str(m.year),
        released: m.released !== false,
        poster: posterUrl(m.poster),
        seer: str(m.seer),
        app: app ? { result: str(app.result), detail: str(app.detail) } : null,
      };
    }),
  }));
  const all = franchises.flatMap((f) => f.missing);
  const progress = (v.progress && typeof v.progress === "object" ? v.progress : {}) as Record<string, unknown>;
  const finished = Number(v.finished) || 0;
  return {
    running: v.running === true,
    progress: { phase: str(progress.phase), done: Number(progress.done) || 0, total: Number(progress.total) || 0 },
    error: str(v.error),
    checked: finished > 0,
    finished: finished ? new Date(finished * 1000).toISOString() : "",
    seerConfigured: v.seer_configured === true,
    seerError: str(v.seer_error),
    hasTmdb: v.has_tmdb === true,
    libraries: asArr(v.libraries).map((l) => ({ id: str(l.id), name: str(l.name) })),
    franchises,
    missing: all.filter((m) => m.released).length,
    unreleased: all.filter((m) => !m.released).length,
  };
}

export async function jcmMissing(instanceId: string, fresh: boolean): Promise<JcmMissing> {
  const raw = await jcmProxy(instanceId, "GET", `/api/missing${fresh ? "?fresh=1" : ""}`);
  return normalizeMissing(raw);
}
