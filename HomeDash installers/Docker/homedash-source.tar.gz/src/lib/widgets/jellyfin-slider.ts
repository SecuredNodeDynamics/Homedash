import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, hasConnectionUrl, isPrivateConnectionUrl, primaryConnectionUrl } from "@/lib/open-href";

export type JellyfinSection = {
  key: string;
  title: string;
  itemTypes?: string;
  parentId?: string;
  limit?: number;
  fields?: string;
};

export type JellyfinServer = {
  label: string;
  baseUrl: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  apiKey: string;
  userId: string;
  sections?: JellyfinSection[];
};

export type JellyfinItem = {
  Id: string;
  Name?: string;
  Type?: string;
  ProductionYear?: number;
  OfficialRating?: string;
  RunTimeTicks?: number;
  Overview?: string;
  Genres?: string[];
  AlbumArtist?: string;
  Artists?: string[];
  ChildCount?: number;
  ParentId?: string;
  ImageTags?: { Primary?: string };
  BackdropImageTags?: string[];
  AlbumPrimaryImageTag?: string;
  IndexNumber?: number;
  ParentIndexNumber?: number;
  RemoteTrailers?: Array<{ Name?: string; Url?: string }>;
};

export type JellyfinTrailer = {
  kind: "local" | "remote";
  itemId?: string;
  name: string;
  url?: string;
};

type JellyfinUser = {
  Id?: string;
  Name?: string;
};

type Config = {
  baseUrl?: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  apiKey?: string;
  userId?: string;
  sectionsJson?: string;
  serversJson?: string;
  caseView?: string;
  musicShelf?: string;
};

const DEFAULT_FIELDS =
  "ProductionYear,ImageTags,BackdropImageTags,Overview,Genres,RunTimeTicks,OfficialRating,Type,ChildCount,AlbumArtist,Artists,AlbumPrimaryImageTag,ParentId";

export function parseSections(sectionsJson: string): JellyfinSection[] {
  if (!sectionsJson) {
    return [
      { key: "movies", title: "Movies", itemTypes: "Movie" },
      { key: "tv", title: "TV", itemTypes: "Series" },
      { key: "music", title: "Music", itemTypes: "MusicAlbum" },
    ];
  }
  try {
    const parsed = JSON.parse(sectionsJson);
    if (Array.isArray(parsed) && parsed.length) return parsed as JellyfinSection[];
  } catch {
    /* keep defaults */
  }
  return [
    { key: "movies", title: "Movies", itemTypes: "Movie" },
    { key: "tv", title: "TV", itemTypes: "Series" },
  ];
}

export async function loadJellyfinServers(instanceId = "jellyfin-slider") {
  const cfg = (await readWidgetConfig(instanceId)) as Config;
  const apiKey = cfg.apiKey?.trim();
  const userId = cfg.userId?.trim();

  // Prefer flat per-card credentials (multi-instance). Only fall back to legacy
  // serversJson when the card has no direct URL/key/user configured.
  // Remote-only servers (blank Private - IP, Fallback Public URL set) are allowed:
  // the public URL becomes the primary `baseUrl` and `fallbackUrl` is left blank
  // since there's nothing left to fall back to.
  if (hasConnectionUrl(cfg) && apiKey && userId) {
    const [baseUrl, fallbackUrl = ""] = connectionCandidates(cfg);
    return [
      {
        label: "Jellyfin",
        baseUrl,
        fallbackUrl,
        publicUrl: cfg.publicUrl?.trim() || baseUrl,
        openFallbackUrl: cfg.openFallbackUrl?.trim() || fallbackUrl,
        apiKey,
        userId,
        sections: parseSections(cfg.sectionsJson || ""),
      },
    ];
  }

  if (cfg.serversJson) {
    try {
      const parsed = JSON.parse(cfg.serversJson) as JellyfinServer[];
      if (Array.isArray(parsed) && parsed.length) {
        return parsed
          .filter((server) => hasConnectionUrl(server) && server.apiKey && server.userId)
          .map((server) => ({ ...server, baseUrl: primaryConnectionUrl(server) }));
      }
    } catch {
      /* fall through */
    }
  }

  throw new Error(
    "Configure a Private - IP or Fallback Public URL, API key, and User ID in Settings",
  );
}

export async function resolveJellyfinServer(instanceId: string, serverIndex = 0) {
  const servers = await loadJellyfinServers(instanceId);
  const server = servers[serverIndex] || servers[0];
  if (!server) throw new Error("Configure Jellyfin servers in Settings");
  const userId = await resolveJellyfinUserId(server);
  return {
    servers: servers.map((entry) => ({
      label: entry.label,
      publicUrl: entry.publicUrl || entry.baseUrl,
      openFallbackUrl: entry.openFallbackUrl || entry.fallbackUrl || "",
    })),
    server: { ...server, userId },
    serverIndex: servers[serverIndex] ? serverIndex : 0,
    sections: server.sections?.length ? server.sections : parseSections(""),
  };
}

async function jfFetch<T>(baseUrl: string, apiKey: string, path: string): Promise<T> {
  const response = await fetch(joinUrl(baseUrl, path), {
    headers: {
      Authorization: `MediaBrowser Token="${apiKey}"`,
      "X-Emby-Token": apiKey,
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    cache: "no-store",
    // A dead LAN address should fail over quickly; public tunnels get a wider
    // allowance for normal WAN/Cloudflare latency.
    signal: AbortSignal.timeout(isPrivateConnectionUrl(baseUrl) ? 4_000 : 12_000),
  });
  if (!response.ok) throw new Error(`Jellyfin HTTP ${response.status}`);
  return response.json() as Promise<T>;
}

async function jfPost(baseUrl: string, apiKey: string, path: string): Promise<void> {
  const response = await fetch(joinUrl(baseUrl, path), {
    method: "POST",
    headers: {
      Authorization: `MediaBrowser Token="${apiKey}"`,
      "X-Emby-Token": apiKey,
      Accept: "application/json",
    },
    cache: "no-store",
    signal: AbortSignal.timeout(isPrivateConnectionUrl(baseUrl) ? 4_000 : 12_000),
  });
  // Jellyfin returns 204 No Content for /Items/{id}/Refresh; there is no body to parse.
  if (!response.ok) throw new Error(`Jellyfin HTTP ${response.status}`);
}

const preferredBase = new Map<string, { baseUrl: string; expiresAt: number }>();

async function withFallback<T>(
  bases: string[],
  apiKey: string,
  path: string,
): Promise<{ data: T; baseUrl: string }> {
  const key = bases.join("|");
  const cached = preferredBase.get(key);
  const ordered = cached && cached.expiresAt > Date.now() && bases.includes(cached.baseUrl)
    ? [cached.baseUrl, ...bases.filter((base) => base !== cached.baseUrl)]
    : bases;
  let lastError: unknown;
  for (const base of ordered) {
    try {
      const data = await jfFetch<T>(base, apiKey, path);
      preferredBase.set(key, { baseUrl: base, expiresAt: Date.now() + 60_000 });
      return { data, baseUrl: base };
    } catch (error) {
      if (cached?.baseUrl === base) preferredBase.delete(key);
      lastError = error;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("Jellyfin unavailable");
}

async function withFallbackAction(bases: string[], apiKey: string, path: string): Promise<void> {
  const key = bases.join("|");
  const cached = preferredBase.get(key);
  const ordered = cached && cached.expiresAt > Date.now() && bases.includes(cached.baseUrl)
    ? [cached.baseUrl, ...bases.filter((base) => base !== cached.baseUrl)]
    : bases;
  let lastError: unknown;
  for (const base of ordered) {
    try {
      await jfPost(base, apiKey, path);
      preferredBase.set(key, { baseUrl: base, expiresAt: Date.now() + 60_000 });
      return;
    } catch (error) {
      if (cached?.baseUrl === base) preferredBase.delete(key);
      lastError = error;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("Jellyfin unavailable");
}

function basesFor(server: JellyfinServer) {
  // openFallbackUrl is normally for the browser's Open button, but it is still
  // a valid Jellyfin public endpoint and provides a safe compatibility fallback
  // for older cards where Fallback Public URL was left blank.
  return connectionCandidates({
    ...server,
    fallbackUrl: server.fallbackUrl || server.openFallbackUrl || "",
  });
}

const resolvedUsers = new Map<string, { userId: string; expiresAt: number }>();

async function resolveJellyfinUserId(server: JellyfinServer) {
  const configured = server.userId.trim();
  if (/^[a-f0-9]{32}$/i.test(configured) || /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(configured)) {
    return configured;
  }
  const bases = basesFor(server);
  const cacheKey = `${bases.join("|")}|${configured.toLowerCase()}`;
  const cached = resolvedUsers.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) return cached.userId;

  const { data } = await withFallback<JellyfinUser[]>(bases, server.apiKey, "/Users");
  const match = data.find(
    (user) =>
      user.Id?.toLowerCase() === configured.toLowerCase() ||
      user.Name?.trim().toLowerCase() === configured.toLowerCase(),
  );
  if (!match?.Id) {
    throw new Error(
      `Jellyfin user "${configured}" was not found. Enter the exact username or internal Jellyfin user ID.`,
    );
  }
  resolvedUsers.set(cacheKey, { userId: match.Id, expiresAt: Date.now() + 10 * 60_000 });
  return match.Id;
}

export async function fetchJellyfinSections(instanceId = "jellyfin-slider", serverIndex = 0) {
  const config = await readWidgetConfig(instanceId);
  const { servers, server, sections, serverIndex: idx } = await resolveJellyfinServer(
    instanceId,
    serverIndex,
  );
  const { baseUrl } = await withFallback(
    basesFor(server),
    server.apiKey,
    `/Users/${encodeURIComponent(server.userId)}`,
  );
  return {
    sections,
    servers,
    serverIndex: idx,
    baseUrl,
    publicUrl: server.publicUrl || baseUrl,
    openFallbackUrl: server.openFallbackUrl || server.fallbackUrl || "",
    caseView: String(config.caseView || "false") === "true",
    musicShelf: String(config.musicShelf || "false") === "true",
  };
}

type JellyfinVirtualFolder = {
  ItemId?: string;
  Name?: string;
  CollectionType?: string;
};

// Maps an item type used by a section's `itemTypes` filter to the
// Jellyfin `CollectionType` reported for a library in /Library/VirtualFolders.
// Used as a fallback when a section has no explicit `parentId` configured.
const COLLECTION_TYPE_BY_ITEM_TYPE: Record<string, string[]> = {
  Movie: ["movies"],
  Series: ["tvshows"],
  MusicAlbum: ["music"],
  Audio: ["music"],
  BoxSet: ["boxsets"],
};

async function resolveLibraryItemId(
  bases: string[],
  apiKey: string,
  section: JellyfinSection,
): Promise<string | undefined> {
  // A section explicitly scoped to a library folder already carries the
  // library's own item id — that's the id /Items/{id}/Refresh expects.
  if (section.parentId) return section.parentId;

  const { data } = await withFallback<JellyfinVirtualFolder[]>(
    bases,
    apiKey,
    "/Library/VirtualFolders",
  );
  const itemTypes = (section.itemTypes || "")
    .split(",")
    .map((type) => type.trim())
    .filter(Boolean);
  const wantedCollectionTypes = new Set(
    itemTypes.flatMap((type) => COLLECTION_TYPE_BY_ITEM_TYPE[type] || []),
  );
  if (!wantedCollectionTypes.size) return undefined;

  const matches = data.filter(
    (folder) => folder.CollectionType && wantedCollectionTypes.has(folder.CollectionType) && folder.ItemId,
  );
  // Only auto-resolve when there's exactly one library of that type — with
  // several (e.g. two separate movie libraries) guessing could scan the
  // wrong one, so that case requires an explicit Library on the section.
  return matches.length === 1 ? matches[0].ItemId : undefined;
}

export async function triggerJellyfinLibraryScan(
  instanceId: string,
  sectionKey: string,
  serverIndex = 0,
) {
  const { server, sections } = await resolveJellyfinServer(instanceId, serverIndex);
  const section = sections.find((entry) => entry.key === sectionKey) || sections[0];
  if (!section) throw new Error("No library to sync");

  const bases = basesFor(server);
  const libraryId = await resolveLibraryItemId(bases, server.apiKey, section);
  if (!libraryId) {
    throw new Error(
      `Could not identify a single Jellyfin library for "${section.title}" — set a Library on this section.`,
    );
  }

  await withFallbackAction(
    bases,
    server.apiKey,
    `/Items/${encodeURIComponent(libraryId)}/Refresh?Recursive=true&ImageRefreshMode=Default&MetadataRefreshMode=Default&ReplaceAllImages=false&ReplaceAllMetadata=false`,
  );

  return { library: section.title, libraryId };
}

type JellyfinTaskInfo = {
  Id?: string;
  Name?: string;
  Key?: string;
  State?: string;
  CurrentProgressPercentage?: number;
};

// Jellyfin's /Items/{id}/Refresh only *queues* a scan — it returns 204
// immediately while the actual "Scan Media Library" scheduled task keeps
// running in the background. Polling this lets the widget know when the
// scan (and therefore the newly-synced items) is actually ready, instead of
// reloading the shelf a moment after kicking the scan off and finding
// nothing new.
export async function getJellyfinScanStatus(instanceId: string, serverIndex = 0) {
  const { server } = await resolveJellyfinServer(instanceId, serverIndex);
  const bases = basesFor(server);
  const { data } = await withFallback<JellyfinTaskInfo[]>(bases, server.apiKey, "/ScheduledTasks");
  const task = data.find((entry) => {
    const key = (entry.Key || "").toLowerCase();
    const name = (entry.Name || "").toLowerCase();
    return (
      key.includes("refreshlibrary") ||
      key.includes("refreshmedialibrary") ||
      name.includes("scan media library")
    );
  });
  if (!task) return { running: false, progress: 100 };
  const running = task.State === "Running" || task.State === "Cancelling";
  const rawProgress = Number(task.CurrentProgressPercentage);
  const progress = Number.isFinite(rawProgress)
    ? Math.max(0, Math.min(100, rawProgress))
    : running
      ? 0
      : 100;
  return { running, progress };
}

export async function fetchJellyfinItems(
  instanceId: string,
  sectionKey: string,
  serverIndex = 0,
) {
  const { server, sections } = await resolveJellyfinServer(instanceId, serverIndex);
  const section = sections.find((entry) => entry.key === sectionKey) || sections[0];
  const sectionIdentity = `${section?.key || ""} ${section?.title || ""}`.toLowerCase();
  const isCollectionSection =
    sectionIdentity.includes("collection") || sectionIdentity.includes("box set");
  // Jellyfin's Collections library is a virtual folder whose recursive
  // descendants can include episodes from TV/anime libraries. Always constrain
  // it to BoxSet records, even when an older saved section omitted itemTypes.
  const itemTypes = isCollectionSection
    ? "BoxSet"
    : section?.itemTypes || (!section?.parentId ? "Movie" : "");
  const requestedLimit = Math.max(1, Math.min(200, Number(section?.limit) || 24));
  const params = new URLSearchParams({
    Recursive: "true",
    SortBy: "DateCreated,SortName",
    SortOrder: "Descending",
    // Over-fetch a bit so we can drop duplicates / wrong types and still fill the slider.
    Limit: String(Math.min(500, Math.max(requestedLimit, requestedLimit * 3))),
    Fields: section?.fields || DEFAULT_FIELDS,
  });
  // ParentId scopes to a library; IncludeItemTypes must still be set or Jellyfin
  // returns every child (episodes/seasons) which looks like duplicate thumbs.
  if (section?.parentId) params.set("ParentId", section.parentId);
  if (itemTypes) params.set("IncludeItemTypes", itemTypes);

  const { data, baseUrl } = await withFallback<{ Items?: JellyfinItem[] }>(
    basesFor(server),
    server.apiKey,
    `/Users/${encodeURIComponent(server.userId)}/Items?${params}`,
  );

  const wanted = new Set(
    itemTypes
      .split(",")
      .map((value) => value.trim())
      .filter(Boolean),
  );
  const seen = new Set<string>();
  const items: JellyfinItem[] = [];
  for (const item of data.Items || []) {
    if (!item?.Id || seen.has(item.Id)) continue;
    if (wanted.size && item.Type && !wanted.has(item.Type)) continue;
    seen.add(item.Id);
    items.push(item);
    if (items.length >= requestedLimit) break;
  }

  return {
    items,
    baseUrl,
    publicUrl: server.publicUrl || baseUrl,
    openFallbackUrl: server.openFallbackUrl || server.fallbackUrl || "",
    section,
  };
}

export async function searchJellyfin(instanceId: string, query: string, serverIndex = 0) {
  const { server, sections } = await resolveJellyfinServer(instanceId, serverIndex);
  const types = Array.from(
    new Set(sections.map((section) => section.itemTypes).filter(Boolean) as string[]),
  ).join(",");
  const params = new URLSearchParams({
    searchTerm: query,
    Recursive: "true",
    IncludeItemTypes: types || "Movie,Series,MusicAlbum,BoxSet",
    Limit: "40",
    Fields: DEFAULT_FIELDS,
  });
  const { data, baseUrl } = await withFallback<{ Items?: JellyfinItem[] }>(
    basesFor(server),
    server.apiKey,
    `/Users/${encodeURIComponent(server.userId)}/Items?${params}`,
  );
  return {
    items: data.Items || [],
    baseUrl,
    publicUrl: server.publicUrl || baseUrl,
    openFallbackUrl: server.openFallbackUrl || server.fallbackUrl || "",
  };
}

export async function fetchJellyfinTracks(
  instanceId: string,
  albumId: string,
  serverIndex = 0,
) {
  const { server } = await resolveJellyfinServer(instanceId, serverIndex);
  const fetchAll = async (scope: "AlbumIds" | "ParentId") => {
    const items: JellyfinItem[] = [];
    const seen = new Set<string>();
    let baseUrl = "";
    let startIndex = 0;
    const pageSize = 200;

    while (true) {
      const params = new URLSearchParams({
        [scope]: albumId,
        IncludeItemTypes: "Audio",
        Recursive: "true",
        SortBy: "ParentIndexNumber,IndexNumber,SortName",
        SortOrder: "Ascending",
        Fields: "IndexNumber,ParentIndexNumber,Name,RunTimeTicks,Artists,AlbumArtist",
        StartIndex: String(startIndex),
        Limit: String(pageSize),
      });
      const result = await withFallback<{
        Items?: JellyfinItem[];
        TotalRecordCount?: number;
      }>(
        basesFor(server),
        server.apiKey,
        `/Users/${encodeURIComponent(server.userId)}/Items?${params}`,
      );
      baseUrl = result.baseUrl;
      const page = result.data.Items || [];
      for (const track of page) {
        if (!track?.Id || seen.has(track.Id)) continue;
        seen.add(track.Id);
        items.push(track);
      }
      startIndex += page.length;
      const total = Number(result.data.TotalRecordCount);
      if (!page.length || page.length < pageSize || (Number.isFinite(total) && startIndex >= total)) {
        break;
      }
    }
    return { items, baseUrl };
  };

  // AlbumIds is reliable for compilation albums whose audio files may live
  // under different physical parents. Retain ParentId for older servers.
  const byAlbum = await fetchAll("AlbumIds");
  return byAlbum.items.length ? byAlbum : fetchAll("ParentId");
}

export async function fetchJellyfinCollection(
  instanceId: string,
  collectionId: string,
  serverIndex = 0,
) {
  const { server } = await resolveJellyfinServer(instanceId, serverIndex);
  const params = new URLSearchParams({
    ParentId: collectionId,
    Recursive: "true",
    SortBy: "SortName",
    SortOrder: "Ascending",
    Fields: DEFAULT_FIELDS,
    Limit: "100",
  });
  const { data, baseUrl } = await withFallback<{ Items?: JellyfinItem[] }>(
    basesFor(server),
    server.apiKey,
    `/Users/${encodeURIComponent(server.userId)}/Items?${params}`,
  );
  return { items: data.Items || [], baseUrl };
}

export async function fetchJellyfinSeasons(
  instanceId: string,
  seriesId: string,
  serverIndex = 0,
) {
  const { server } = await resolveJellyfinServer(instanceId, serverIndex);
  const params = new URLSearchParams({
    userId: server.userId,
    Fields: "Overview,ImageTags,ChildCount",
  });
  const { data, baseUrl } = await withFallback<{ Items?: JellyfinItem[] }>(
    basesFor(server),
    server.apiKey,
    `/Shows/${encodeURIComponent(seriesId)}/Seasons?${params}`,
  );
  return { items: (data.Items || []).filter((item) => (item.IndexNumber || 0) > 0), baseUrl };
}

export async function fetchJellyfinEpisodes(
  instanceId: string,
  seriesId: string,
  seasonId: string,
  serverIndex = 0,
) {
  const { server } = await resolveJellyfinServer(instanceId, serverIndex);
  const params = new URLSearchParams({
    userId: server.userId,
    seasonId,
    Fields: "IndexNumber,Name,RunTimeTicks,Overview,ImageTags",
  });
  const { data, baseUrl } = await withFallback<{ Items?: JellyfinItem[] }>(
    basesFor(server),
    server.apiKey,
    `/Shows/${encodeURIComponent(seriesId)}/Episodes?${params}`,
  );
  return { items: data.Items || [], baseUrl };
}

export async function jellyfinDownloadResponse(
  instanceId: string,
  itemId: string,
  serverIndex = 0,
) {
  const { server } = await resolveJellyfinServer(instanceId, serverIndex);
  let lastError: unknown;
  for (const base of basesFor(server)) {
    try {
      const response = await fetch(
        joinUrl(base, `/Items/${encodeURIComponent(itemId)}/Download`),
        {
          headers: {
            Authorization: `MediaBrowser Token="${server.apiKey}"`,
            "X-Emby-Token": server.apiKey,
            // Ask for the raw byte stream. If a reverse proxy (or Jellyfin
            // itself) gzip/br-compresses the response, fetch() silently
            // decompresses the body but the upstream Content-Length header
            // still reflects the *compressed* size. Chromium/WebKit download
            // managers enforce that length strictly and truncate the saved
            // file once it's reached, corrupting .mkv/.mp4 downloads (Firefox
            // tolerates the mismatch, which masked this everywhere else).
            // Requesting identity encoding avoids the mismatch at the source.
            "Accept-Encoding": "identity",
          },
          cache: "no-store",
          signal: AbortSignal.timeout(120_000),
        },
      );
      if (!response.ok) throw new Error(`Download HTTP ${response.status}`);
      return response;
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("Download failed");
}

export async function fetchJellyfinTrailer(
  instanceId: string,
  itemId: string,
  serverIndex = 0,
): Promise<JellyfinTrailer | null> {
  const { server } = await resolveJellyfinServer(instanceId, serverIndex);
  try {
    const { data } = await withFallback<JellyfinItem[]>(
      basesFor(server),
      server.apiKey,
      `/Users/${encodeURIComponent(server.userId)}/Items/${encodeURIComponent(itemId)}/LocalTrailers`,
    );
    const local = Array.isArray(data) ? data.find((entry) => entry?.Id) : undefined;
    if (local?.Id) {
      return { kind: "local", itemId: local.Id, name: local.Name || "Trailer" };
    }
  } catch {
    // A library without local trailers may return 404; try remote metadata.
  }

  const { data: detail } = await withFallback<JellyfinItem>(
    basesFor(server),
    server.apiKey,
    `/Users/${encodeURIComponent(server.userId)}/Items/${encodeURIComponent(itemId)}`,
  );
  const remote = detail.RemoteTrailers?.find((entry) => entry?.Url?.trim());
  return remote?.Url
    ? { kind: "remote", name: remote.Name || "Trailer", url: remote.Url.trim() }
    : null;
}

export async function jellyfinTrailerStreamResponse(
  instanceId: string,
  itemId: string,
  serverIndex = 0,
  range?: string | null,
) {
  const { server } = await resolveJellyfinServer(instanceId, serverIndex);
  let lastError: unknown;
  for (const base of basesFor(server)) {
    try {
      const headers: Record<string, string> = {
        Authorization: `MediaBrowser Token="${server.apiKey}"`,
        "X-Emby-Token": server.apiKey,
      };
      if (range) headers.Range = range;
      const response = await fetch(
        joinUrl(base, `/Videos/${encodeURIComponent(itemId)}/stream?Static=true`),
        {
          headers,
          cache: "no-store",
          signal: AbortSignal.timeout(120_000),
        },
      );
      if (!response.ok && response.status !== 206) {
        throw new Error(`Trailer stream HTTP ${response.status}`);
      }
      return response;
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("Trailer stream failed");
}

export async function jellyfinAudioStreamResponse(
  instanceId: string,
  itemId: string,
  serverIndex = 0,
  range?: string | null,
) {
  const { server } = await resolveJellyfinServer(instanceId, serverIndex);
  let lastError: unknown;
  for (const base of basesFor(server)) {
    try {
      const headers: Record<string, string> = {
        Authorization: `MediaBrowser Token="${server.apiKey}"`,
        "X-Emby-Token": server.apiKey,
      };
      if (range) headers.Range = range;
      const response = await fetch(
        joinUrl(base, `/Audio/${encodeURIComponent(itemId)}/stream?Static=true`),
        {
          headers,
          cache: "no-store",
          signal: AbortSignal.timeout(120_000),
        },
      );
      if (!response.ok && response.status !== 206) {
        throw new Error(`Audio stream HTTP ${response.status}`);
      }
      return response;
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("Audio demo failed");
}

export function primaryImageUrl(baseUrl: string, item: JellyfinItem, maxWidth = 280) {
  const tag = item.ImageTags?.Primary || item.AlbumPrimaryImageTag;
  if (!tag || !item.Id) return "";
  return `${baseUrl.replace(/\/$/, "")}/Items/${item.Id}/Images/Primary?tag=${encodeURIComponent(tag)}&maxWidth=${maxWidth}&quality=85`;
}

export function backdropImageUrl(baseUrl: string, item: JellyfinItem) {
  const tag = item.BackdropImageTags?.[0];
  if (!tag || !item.Id) return "";
  return `${baseUrl.replace(/\/$/, "")}/Items/${item.Id}/Images/Backdrop/0?tag=${encodeURIComponent(tag)}&maxHeight=720&quality=80`;
}

export function detailsUrl(publicUrl: string, itemId: string) {
  return `${publicUrl.replace(/\/$/, "")}/web/index.html#!/details?id=${encodeURIComponent(itemId)}`;
}
