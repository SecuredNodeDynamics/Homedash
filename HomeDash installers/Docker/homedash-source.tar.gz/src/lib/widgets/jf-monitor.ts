import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, hasConnectionUrl, openUrlsFromConfig, primaryConnectionUrl } from "@/lib/open-href";

type Config = {
  baseUrl: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  apiKey: string;
  messageSender?: string;
};

type NowPlayingItem = {
  Id?: string;
  Name?: string;
  Type?: string;
  SeriesName?: string;
  SeriesId?: string;
  SeriesPrimaryImageTag?: string;
  ParentIndexNumber?: number;
  IndexNumber?: number;
  RunTimeTicks?: number;
  ImageTags?: { Primary?: string };
};

type JellyfinSession = {
  Id?: string;
  UserName?: string;
  Client?: string;
  DeviceName?: string;
  SupportsRemoteControl?: boolean;
  SupportsMediaControl?: boolean;
  SupportedCommands?: string[];
  NowPlayingItem?: NowPlayingItem;
  PlayState?: {
    IsPaused?: boolean;
    PlayState?: string;
    PositionTicks?: number;
  };
};

type JellyfinUser = {
  Id?: string;
  Name?: string;
  Policy?: { IsAdministrator?: boolean };
};

type LibraryFolder = {
  ItemId?: string;
  Name?: string;
  CollectionType?: string;
};

type ScheduledTask = {
  Key?: string;
  Name?: string;
  State?: string;
  CurrentProgressPercentage?: number | null;
};

export type JfSyncStatus = {
  running: boolean;
  progress: number | null;
};

export type JfSession = {
  id: string;
  title: string;
  user: string;
  client: string;
  device: string;
  paused: boolean;
  positionTicks: number;
  runTimeTicks: number;
  artUrl: string;
  type: string;
  /** Client reports DisplayMessage in SupportedCommands (false for Roku, etc.). */
  canMessage: boolean;
  canControl: boolean;
};

const MESSAGE_TIMEOUT_MS = 12_000;

export type JfConnectionSource = "private" | "public" | "unknown";

function apiRoot(url: string) {
  return String(url || "").replace(/\/$/, "");
}

// Classifies which URL a request actually connected through. This must compare
// against the raw config values (read fresh from config), not `cfg.baseUrl` —
// by the time a caller holds `cfg`, `cfg.baseUrl` has already been passed through
// `primaryConnectionUrl()`, which can substitute the fallback URL as "primary"
// and would otherwise cause a successful private connection to be mislabeled
// as public (or vice versa).
async function classifyConnectionSource(
  instanceId: string,
  base: string,
): Promise<JfConnectionSource> {
  const raw = (await readWidgetConfig(instanceId)) as Partial<Config>;
  const normalized = apiRoot(base);
  if (raw.baseUrl && apiRoot(raw.baseUrl) === normalized) return "private";
  if (raw.fallbackUrl && apiRoot(raw.fallbackUrl) === normalized) return "public";
  return "unknown";
}

function sessionCanMessage(session: JellyfinSession): boolean {
  const commands = session.SupportedCommands || [];
  return commands.includes("DisplayMessage");
}

function sessionCanControl(session: JellyfinSession): boolean {
  return !!session.SupportsMediaControl;
}

function messagePayload(text: string, header: string) {
  return {
    Header: header,
    Text: text,
    TimeoutMs: MESSAGE_TIMEOUT_MS,
  };
}

/**
 * Resolves the display name shown as the message sender on-screen.
 * Prefers a manually configured name; otherwise looks up the Jellyfin
 * admin account and uses its username. Falls back to "Homedash" only
 * if no manual name is set and no admin account can be found.
 */
async function resolveMessageHeader(config: Config): Promise<string> {
  const manual = (config.messageSender || "").trim();
  if (manual) return manual;
  try {
    const { data } = await jfFetch<JellyfinUser[]>(config, "/Users", {
      headers: authHeaders(config.apiKey),
    });
    const admin = (data || []).find((user) => user.Policy?.IsAdministrator && user.Name);
    if (admin?.Name) return admin.Name;
  } catch {
    // Fall through to default below — a lookup failure shouldn't block sending.
  }
  return "Homedash";
}

async function loadConfig(instanceId: string): Promise<Config> {
  const value = (await readWidgetConfig(instanceId)) as Partial<Config>;
  if (!hasConnectionUrl(value) || !value.apiKey) {
    throw new Error("Configure a Private - IP or Fallback Public URL, and API key in Settings");
  }
  return { ...value, baseUrl: primaryConnectionUrl(value) } as Config;
}

function authHeaders(apiKey: string, extra: Record<string, string> = {}) {
  return {
    "X-Emby-Token": apiKey,
    Authorization: `MediaBrowser Token="${apiKey}"`,
    Accept: "application/json",
    ...extra,
  };
}

async function jfFetch<T>(
  config: Config,
  path: string,
  init: RequestInit = {},
): Promise<{ data: T; baseUrl: string }> {
  let last: unknown;
  const bases = connectionCandidates(config);
  for (const base of bases) {
    try {
      const response = await fetch(joinUrl(base, path), {
        ...init,
        cache: "no-store",
        signal: AbortSignal.timeout(10_000),
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      if (response.status === 204) return { data: null as T, baseUrl: base };
      const ct = response.headers.get("content-type") || "";
      if (!ct.includes("json")) return { data: null as T, baseUrl: base };
      return { data: (await response.json()) as T, baseUrl: base };
    } catch (error) {
      last = error;
    }
  }
  throw last instanceof Error ? last : new Error("Jellyfin unavailable");
}

function formatSessionTitle(item: NowPlayingItem): string {
  if (item.Type === "Episode") {
    const show = item.SeriesName ? `${item.SeriesName} — ` : "";
    const epNum =
      item.ParentIndexNumber != null && item.IndexNumber != null
        ? `S${String(item.ParentIndexNumber).padStart(2, "0")}E${String(item.IndexNumber).padStart(2, "0")} `
        : "";
    return `${show}${epNum}${item.Name || "Episode"}`;
  }
  return item.Name || "Unknown";
}

function artUrlFor(baseUrl: string, item?: NowPlayingItem): string {
  if (!item) return "";
  const isEpisode = item.Type === "Episode";
  const imageItemId = isEpisode ? item.SeriesId : item.Id;
  const imageTag = isEpisode ? item.SeriesPrimaryImageTag : item.ImageTags?.Primary;
  if (!imageItemId || !imageTag) return "";
  return `${baseUrl.replace(/\/$/, "")}/Items/${imageItemId}/Images/Primary?maxHeight=120&maxWidth=80&tag=${encodeURIComponent(imageTag)}&quality=90`;
}

function mapSession(session: JellyfinSession, baseUrl: string): JfSession | null {
  const item = session.NowPlayingItem;
  if (!item || !session.Id) return null;
  const paused =
    !!session.PlayState?.IsPaused ||
    String(session.PlayState?.PlayState || "")
      .toLowerCase()
      .includes("pause");
  return {
    id: session.Id,
    title: formatSessionTitle(item),
    user: session.UserName || "Unknown",
    client: session.Client || "",
    device: session.DeviceName || "",
    paused,
    positionTicks: session.PlayState?.PositionTicks || 0,
    runTimeTicks: item.RunTimeTicks || 0,
    artUrl: artUrlFor(baseUrl, item),
    type: item.Type || "Media",
    canMessage: sessionCanMessage(session),
    canControl: sessionCanControl(session),
  };
}

export async function jfMonitorStatus(instanceId: string) {
  const config = await loadConfig(instanceId);
  const headers = authHeaders(config.apiKey);
  const [sessionsRes, countsRes, librariesRes] = await Promise.all([
    jfFetch<JellyfinSession[]>(config, "/Sessions", { headers }),
    jfFetch<{
      MovieCount?: number;
      SeriesCount?: number;
      EpisodeCount?: number;
      SongCount?: number;
      AlbumCount?: number;
    }>(config, "/Items/Counts", { headers }),
    jfFetch<LibraryFolder[]>(config, "/Library/VirtualFolders", { headers }),
  ]);

  const baseUrl = sessionsRes.baseUrl || config.baseUrl;
  const sessions = (sessionsRes.data || [])
    .map((session) => mapSession(session, baseUrl))
    .filter(Boolean) as JfSession[];

  const counts = countsRes.data || {};
  return {
    ...openUrlsFromConfig(config),
    baseUrl,
    sessions,
    movies: counts.MovieCount || 0,
    series: counts.SeriesCount || 0,
    episodes: counts.EpisodeCount || 0,
    songs: counts.SongCount || 0,
    albums: counts.AlbumCount || 0,
    libraries: (librariesRes.data || []).map((folder) => ({
      id: folder.ItemId || "",
      name: folder.Name || "Library",
      collectionType: folder.CollectionType || "mixed",
    })),
    connectionSource: await classifyConnectionSource(instanceId, baseUrl),
  };
}

export async function jfMonitorLibraries(instanceId: string) {
  const config = await loadConfig(instanceId);
  const { data, baseUrl } = await jfFetch<LibraryFolder[]>(config, "/Library/VirtualFolders", {
    headers: authHeaders(config.apiKey),
  });
  return {
    baseUrl,
    libraries: (data || []).map((folder) => ({
      id: folder.ItemId || "",
      name: folder.Name || "Library",
      collectionType: folder.CollectionType || "mixed",
    })),
  };
}

export async function jfMonitorSyncAll(instanceId: string) {
  const config = await loadConfig(instanceId);
  await jfFetch(config, "/Library/Refresh", {
    method: "POST",
    headers: authHeaders(config.apiKey),
  });
  return { ok: true };
}

export async function jfMonitorSyncLibrary(instanceId: string, libraryId: string) {
  const config = await loadConfig(instanceId);
  const path = `/Items/${encodeURIComponent(libraryId)}/Refresh?Recursive=true&ImageRefreshMode=Default&MetadataRefreshMode=Default`;
  await jfFetch(config, path, {
    method: "POST",
    headers: authHeaders(config.apiKey),
  });
  return { ok: true };
}

/**
 * Reads the real progress of Jellyfin's library scan task ("RefreshLibrary")
 * from /ScheduledTasks. Both "Sync All" (/Library/Refresh) and a single
 * library sync (/Items/{id}/Refresh) run through this same task, so it's a
 * reliable way to report genuine percentage-complete instead of just
 * optimistically flipping a button to a checkmark the instant the POST
 * that *triggers* the scan returns (the scan itself keeps running after
 * that response comes back).
 */
export async function jfMonitorSyncStatus(instanceId: string): Promise<JfSyncStatus> {
  const config = await loadConfig(instanceId);
  const { data } = await jfFetch<ScheduledTask[]>(config, "/ScheduledTasks", {
    headers: authHeaders(config.apiKey),
  });
  const task = (data || []).find(
    (candidate) =>
      candidate.Key === "RefreshLibrary" || /scan media library/i.test(candidate.Name || ""),
  );
  if (!task) return { running: false, progress: null };
  const running = task.State === "Running" || task.State === "Cancelling";
  const progress =
    typeof task.CurrentProgressPercentage === "number"
      ? Math.max(0, Math.min(100, Math.round(task.CurrentProgressPercentage)))
      : null;
  return { running, progress: running ? progress : null };
}

export async function jfMonitorSessionCommand(
  instanceId: string,
  sessionId: string,
  command: string,
) {
  const normalized = String(command || "").toLowerCase();
  const allowed = new Set(["pause", "unpause", "stop"]);
  if (!allowed.has(normalized)) throw new Error("Unsupported session command");
  const config = await loadConfig(instanceId);
  // Jellyfin accepts the Homepage-style lowercase Playing/* commands.
  await jfFetch(config, `/Sessions/${encodeURIComponent(sessionId)}/Playing/${normalized}`, {
    method: "POST",
    headers: authHeaders(config.apiKey),
  });
  return { ok: true };
}

export async function jfMonitorSessionMessage(
  instanceId: string,
  sessionId: string,
  text: string,
) {
  const message = text.trim();
  if (!message) throw new Error("Message required");
  const config = await loadConfig(instanceId);
  const { data: sessions } = await jfFetch<JellyfinSession[]>(config, "/Sessions", {
    headers: authHeaders(config.apiKey),
  });
  const target = (sessions || []).find((session) => session.Id === sessionId);
  if (!target) throw new Error("Session not found");
  if (!sessionCanMessage(target)) {
    const client = target.Client || target.DeviceName || "This client";
    throw new Error(
      `${client} does not support on-screen messages (Roku and some TV apps cannot show them)`,
    );
  }
  const header = await resolveMessageHeader(config);
  await jfFetch(config, `/Sessions/${encodeURIComponent(sessionId)}/Message`, {
    method: "POST",
    headers: authHeaders(config.apiKey, { "Content-Type": "application/json" }),
    body: JSON.stringify(messagePayload(message, header)),
  });
  return { ok: true, canMessage: true };
}

export async function jfMonitorGroupMessage(instanceId: string, text: string) {
  const message = text.trim();
  if (!message) throw new Error("Message required");
  const config = await loadConfig(instanceId);
  const { data } = await jfFetch<JellyfinSession[]>(config, "/Sessions", {
    headers: authHeaders(config.apiKey),
  });
  const active = (data || []).filter((session) => session.NowPlayingItem && session.Id);
  if (!active.length) throw new Error("No active sessions");

  const supported = active.filter(sessionCanMessage);
  const skipped = active
    .filter((session) => !sessionCanMessage(session))
    .map((session) => ({
      client: session.Client || "Unknown",
      device: session.DeviceName || "",
      user: session.UserName || "Unknown",
      reason: "Client does not support DisplayMessage",
    }));

  if (!supported.length) {
    throw new Error(
      `None of the ${active.length} active session(s) support on-screen messages (common on Roku / some TV apps)`,
    );
  }

  const header = await resolveMessageHeader(config);
  const results = await Promise.allSettled(
    supported.map((session) =>
      jfFetch(config, `/Sessions/${encodeURIComponent(session.Id!)}/Message`, {
        method: "POST",
        headers: authHeaders(config.apiKey, { "Content-Type": "application/json" }),
        body: JSON.stringify(messagePayload(message, header)),
      }),
    ),
  );
  const okCount = results.filter((result) => result.status === "fulfilled").length;
  return {
    ok: okCount === results.length,
    sent: okCount,
    total: supported.length,
    active: active.length,
    skipped,
  };
}
