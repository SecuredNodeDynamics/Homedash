import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, hasConnectionUrl, primaryConnectionUrl } from "@/lib/open-href";

export type KumaHeartbeat = {
  status: number;
  time?: string;
  msg?: string;
  ping?: number | null;
};

export type KumaMonitor = {
  id: string | number;
  name: string;
  type: string;
  url: string;
  status: number;
  up24: number | null;
  up7d: number | null;
  up30d: number | null;
  avgPing: number | null;
  lastCheck: string | null;
  lastMsg: string;
  recentBeats: KumaHeartbeat[];
  group: string;
};

export type KumaConnectionSource = "private" | "public" | "unknown";

export type KumaPage = {
  slug: string;
  label: string;
  icon: string;
  href: string;
  openFallbackUrl: string;
  monitors: KumaMonitor[] | null;
  connectionSource: KumaConnectionSource;
  error?: string;
};

type KumaConfig = {
  baseUrl: string;
  fallbackUrl?: string;
  openFallbackUrl?: string;
  statusPages?: string;
};

const DEFAULT_PAGES = [
  { slug: "jnz-service", label: "Cloudflare", icon: "☁️" },
  { slug: "jnz-service-ip", label: "LAN / IP", icon: "🖧" },
];

function parsePages(value?: string) {
  if (!value?.trim()) return DEFAULT_PAGES;

  return value
    .split(/[\n,]+/)
    .map((entry) => {
      const [slug, label, icon] = entry.trim().split("|").map((part) => part.trim());
      return slug ? { slug, label: label || slug, icon: icon || "◉" } : null;
    })
    .filter((page): page is NonNullable<typeof page> => page !== null);
}

function targets(config: KumaConfig) {
  return connectionCandidates(config).map((url) => url.replace(/\/$/, ""));
}

function apiRoot(url: string) {
  return String(url || "").replace(/\/$/, "");
}

function classifyConnectionSource(config: KumaConfig, base: string): KumaConnectionSource {
  const normalized = apiRoot(base);
  if (config.baseUrl && apiRoot(config.baseUrl) === normalized) return "private";
  if (config.fallbackUrl && apiRoot(config.fallbackUrl) === normalized) return "public";
  return "unknown";
}

export async function loadKumaConfig(instanceId: string): Promise<KumaConfig> {
  const config = (await readWidgetConfig(instanceId)) as KumaConfig;
  if (!hasConnectionUrl(config)) {
    throw new Error("Configure a Private - IP or Fallback Public URL in Settings");
  }
  return { ...config, baseUrl: primaryConnectionUrl(config) };
}

function toNumberOrNull(value: unknown) {
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function toMonitor(monitor: Record<string, unknown>, heartbeat: Record<string, unknown>, uptime: Record<string, unknown>, group: string): KumaMonitor {
  const id = String(monitor.id ?? "");
  const beats = Array.isArray(heartbeat[id]) ? heartbeat[id] : [];
  const recentBeats = beats.slice(-20).map((beat: Record<string, unknown>) => ({
    status: Number(beat.status ?? -1),
    time: typeof beat.time === "string" ? beat.time : undefined,
    msg: typeof beat.msg === "string" ? beat.msg : undefined,
    ping: toNumberOrNull(beat.ping),
  }));
  const latest = recentBeats.at(-1);
  const pings = recentBeats
    .map((beat) => beat.ping)
    .filter((ping): ping is number => ping !== null && ping > 0);

  return {
    id,
    name: String(monitor.name ?? "Unnamed monitor"),
    type: String(monitor.type ?? ""),
    url: String(monitor.url ?? ""),
    status: latest?.status ?? -1,
    up24: toNumberOrNull(uptime[`${id}_24`]),
    up7d: toNumberOrNull(uptime[`${id}_720`]),
    up30d: toNumberOrNull(uptime[`${id}_1440`]),
    avgPing: pings.length ? Math.round(pings.reduce((sum, ping) => sum + ping, 0) / pings.length) : null,
    lastCheck: latest?.time ?? null,
    lastMsg: latest?.msg ?? "",
    recentBeats,
    group,
  };
}

async function fetchPage(base: string, page: { slug: string; label: string; icon: string }): Promise<Omit<KumaPage, "connectionSource">> {
  const [infoResponse, heartbeatResponse] = await Promise.all([
    fetch(joinUrl(base, `/api/status-page/${encodeURIComponent(page.slug)}`), {
      cache: "no-store",
      signal: AbortSignal.timeout(6000),
    }),
    fetch(joinUrl(base, `/api/status-page/heartbeat/${encodeURIComponent(page.slug)}`), {
      cache: "no-store",
      signal: AbortSignal.timeout(6000),
    }),
  ]);

  if (!infoResponse.ok || !heartbeatResponse.ok) {
    throw new Error(`Uptime Kuma returned ${infoResponse.status}/${heartbeatResponse.status}`);
  }

  const info = await infoResponse.json();
  const heartbeats = await heartbeatResponse.json();
  const heartbeatList = (heartbeats?.heartbeatList || {}) as Record<string, unknown>;
  const uptimeList = (heartbeats?.uptimeList || {}) as Record<string, unknown>;
  const monitors = (info?.publicGroupList || []).flatMap((group: Record<string, unknown>) =>
    (Array.isArray(group.monitorList) ? group.monitorList : []).map((monitor) =>
      toMonitor(monitor as Record<string, unknown>, heartbeatList, uptimeList, String(group.name ?? "")),
    ),
  );

  return { ...page, href: joinUrl(base, `/status/${encodeURIComponent(page.slug)}`), openFallbackUrl: "", monitors };
}

export async function fetchKumaStatus(instanceId: string) {
  const rawConfig = (await readWidgetConfig(instanceId)) as KumaConfig;
  const config = await loadKumaConfig(instanceId);
  const pages = parsePages(config.statusPages);
  const bases = targets(config);
  const openFallbackBase = config.openFallbackUrl || config.fallbackUrl || "";

  const results = await Promise.all(
    pages.map(async (page) => {
      let lastError: Error | null = null;
      let fetched: Awaited<ReturnType<typeof fetchPage>> | null = null;
      let connectionSource: KumaConnectionSource = "unknown";
      for (const base of bases) {
        try {
          fetched = await fetchPage(base, page);
          connectionSource = classifyConnectionSource(rawConfig, base);
          break;
        } catch (error) {
          lastError = error instanceof Error ? error : new Error("Failed to reach Uptime Kuma");
        }
      }
      const openFallbackUrl = openFallbackBase
        ? joinUrl(openFallbackBase, `/status/${encodeURIComponent(page.slug)}`)
        : "";
      if (fetched) {
        return {
          ...fetched,
          href: joinUrl(config.baseUrl, `/status/${encodeURIComponent(page.slug)}`),
          openFallbackUrl,
          connectionSource,
        };
      }
      return {
        ...page,
        href: joinUrl(config.baseUrl, `/status/${encodeURIComponent(page.slug)}`),
        openFallbackUrl,
        monitors: null,
        connectionSource,
        error: lastError?.message || "Failed to reach Uptime Kuma",
      };
    }),
  );

  if (results.every((page) => page.monitors === null)) {
    throw new Error(results[0]?.error || "Failed to reach Uptime Kuma");
  }

  return { pages: results };
}
