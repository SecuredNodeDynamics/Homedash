import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, hasConnectionUrl, openUrlsFromConfig } from "@/lib/open-href";

type Config = {
  baseUrl: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  apiKey: string;
};

type RecipeRaw = Record<string, unknown> & {
  id?: string;
  slug?: string;
  name?: string;
  title?: string;
  description?: string;
  recipe?: RecipeRaw;
  image?: string;
  imagePath?: string;
  image_path?: string;
};

type MealPlanRaw = Record<string, unknown> & {
  date?: string;
  createdAt?: string;
  entryType?: string;
  entry_type?: string;
  mealType?: string;
  meal_type?: string;
  type?: string;
  note?: string;
  title?: string;
  recipe?: RecipeRaw;
  recipeName?: string;
  recipe_name?: string;
};

type ShoppingRaw = Record<string, unknown> & {
  name?: string;
  title?: string;
  listItems?: unknown[];
  items?: unknown[];
  itemCount?: number;
  item_count?: number;
};

async function cfg(id: string) {
  const value = (await readWidgetConfig(id)) as Partial<Config>;
  if (!hasConnectionUrl(value) || !value.apiKey) {
    throw new Error("Configure a Private - IP or Fallback Public URL, and API token in Settings");
  }
  return { ...value, baseUrl: value.baseUrl || "" } as Config;
}

// Tracks, per widget instance, which base URL last responded successfully so
// we can report whether we're pulling from the Private or Public URL.
const activeBases = new Map<string, string>();

export type MealieConnectionSource = "private" | "public" | "unknown";

function apiRoot(url: string) {
  return String(url || "").replace(/\/+$/, "");
}

function classifyConnectionSource(config: Config, instanceId: string): MealieConnectionSource {
  const base = activeBases.get(instanceId);
  if (!base) return "unknown";
  const normalized = apiRoot(base);
  if (config.baseUrl && apiRoot(config.baseUrl) === normalized) return "private";
  if (config.fallbackUrl && apiRoot(config.fallbackUrl) === normalized) return "public";
  return "unknown";
}

function orderedCandidates(config: Config, instanceId?: string) {
  const urls = connectionCandidates(config);
  const active = instanceId ? activeBases.get(instanceId) : undefined;
  return active ? [...new Set([active, ...urls])] : urls;
}

function authHeaders(config: Config): HeadersInit {
  return {
    Accept: "application/json",
    Authorization: `Bearer ${config.apiKey}`,
  };
}

async function mlFetch<T>(
  config: Config,
  path: string,
  init: RequestInit = {},
  instanceId?: string,
): Promise<T> {
  const apiPath = path.startsWith("/api/") ? path : `/api${path.startsWith("/") ? "" : "/"}${path}`;
  let last: unknown;
  for (const base of orderedCandidates(config, instanceId)) {
    try {
      const response = await fetch(joinUrl(base, apiPath), {
        ...init,
        headers: { ...authHeaders(config), ...(init.headers || {}) },
        cache: "no-store",
        signal: AbortSignal.timeout(12_000),
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = (await response.json()) as T;
      if (instanceId) activeBases.set(instanceId, base);
      return data;
    } catch (error) {
      if (instanceId && activeBases.get(instanceId) === base) activeBases.delete(instanceId);
      last = error;
    }
  }
  throw last instanceof Error ? last : new Error(`Mealie request failed for ${path}`);
}

async function mlFetchOptional<T>(
  config: Config,
  paths: string[],
  fallback: T,
  instanceId?: string,
): Promise<T> {
  for (const path of paths) {
    try {
      return await mlFetch<T>(config, path, {}, instanceId);
    } catch {
      /* try next */
    }
  }
  return fallback;
}

function normalizeList(payload: unknown): Record<string, unknown>[] {
  if (Array.isArray(payload)) return payload as Record<string, unknown>[];
  if (Array.isArray((payload as { items?: unknown[] })?.items)) {
    return (payload as { items: Record<string, unknown>[] }).items;
  }
  if (Array.isArray((payload as { data?: unknown[] })?.data)) {
    return (payload as { data: Record<string, unknown>[] }).data;
  }
  if (Array.isArray((payload as { results?: unknown[] })?.results)) {
    return (payload as { results: Record<string, unknown>[] }).results;
  }
  return [];
}

function isoDate(offsetDays = 0) {
  const d = new Date();
  d.setHours(12, 0, 0, 0);
  d.setDate(d.getDate() + offsetDays);
  return d.toISOString().slice(0, 10);
}

function recipeKey(row: RecipeRaw | MealPlanRaw) {
  const recipe = (row.recipe || row) as RecipeRaw;
  return String(
    recipe.id ||
      recipe.slug ||
      (row as { recipeId?: string }).recipeId ||
      (row as { recipe_id?: string }).recipe_id ||
      row.slug ||
      (row as { id?: string }).id ||
      "",
  );
}

function recipeName(row: RecipeRaw) {
  return String(row.name || row.recipe?.name || row.title || "Recipe");
}

function mealTitle(row: MealPlanRaw) {
  return String(row.recipe?.name || row.recipeName || row.recipe_name || row.title || row.note || "Planned meal");
}

function mealType(row: MealPlanRaw) {
  return String(row.entryType || row.entry_type || row.mealType || row.meal_type || row.type || "Meal");
}

function planDate(row: MealPlanRaw) {
  return String(row.date || row.createdAt || "").slice(0, 10);
}

function mediaProxyUrl(instanceId: string, recipeId: string) {
  if (!recipeId) return "";
  return `/api/widgets/mealie/media?instance=${encodeURIComponent(instanceId)}&id=${encodeURIComponent(recipeId)}`;
}

export async function mealieMedia(instanceId: string, recipeId: string, variant = "min-original.webp") {
  if (!recipeId) throw new Error("Missing recipe id");
  const config = await cfg(instanceId);
  const safeVariant = variant.includes("..") ? "min-original.webp" : variant;
  const candidates = [
    `/api/media/recipes/${encodeURIComponent(recipeId)}/images/${safeVariant}`,
    `/api/media/recipes/${encodeURIComponent(recipeId)}/images/min-original.webp`,
    `/api/media/recipes/${encodeURIComponent(recipeId)}/images/original.webp`,
  ];
  let last: unknown;
  for (const base of connectionCandidates(config)) {
    for (const path of candidates) {
      try {
        const response = await fetch(joinUrl(base, path), {
          headers: authHeaders(config),
          cache: "no-store",
          signal: AbortSignal.timeout(10_000),
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        return response;
      } catch (error) {
        last = error;
      }
    }
  }
  throw last instanceof Error ? last : new Error("Recipe image unavailable");
}

export async function mealieStatus(instanceId: string) {
  const config = await cfg(instanceId);
  const start = isoDate(0);
  const end = isoDate(7);

  const [about, recipesPayload, mealPlansPayload, shoppingPayload] = await Promise.all([
    mlFetchOptional<Record<string, unknown>>(config, ["/app/about"], {}, instanceId),
    mlFetchOptional<Record<string, unknown>>(
      config,
      [
        "/recipes?orderBy=created_at&orderDirection=desc&page=1&perPage=6",
        "/recipes?orderBy=createdAt&orderDirection=desc&page=1&perPage=6",
        "/recipes?page=1&perPage=6",
      ],
      {},
      instanceId,
    ),
    mlFetchOptional<unknown>(
      config,
      [
        `/households/mealplans?start_date=${start}&end_date=${end}`,
        `/households/mealplans?startDate=${start}&endDate=${end}`,
        `/meal-plans?start_date=${start}&end_date=${end}`,
      ],
      [],
      instanceId,
    ),
    mlFetchOptional<unknown>(
      config,
      ["/households/shopping/lists", "/shopping/lists", "/groups/shopping/lists"],
      [],
      instanceId,
    ),
  ]);

  const recipeRows = normalizeList(recipesPayload).slice(0, 6) as RecipeRaw[];
  const mealPlans = normalizeList(mealPlansPayload).slice(0, 8) as MealPlanRaw[];
  const shoppingLists = normalizeList(shoppingPayload).slice(0, 4) as ShoppingRaw[];
  const today = isoDate(0);

  const { href: primaryBase, openFallbackUrl: fallbackBase } = openUrlsFromConfig(config);
  const recipes = recipeRows.map((row) => {
    const id = recipeKey(row);
    const slug = String(row.slug || id);
    return {
      id,
      name: recipeName(row),
      description: String(row.description || ""),
      slug,
      imageUrl: mediaProxyUrl(instanceId, id),
      href: `${primaryBase.replace(/\/$/, "")}/g/home/r/${encodeURIComponent(slug)}`,
      openFallbackUrl: fallbackBase
        ? `${fallbackBase.replace(/\/$/, "")}/g/home/r/${encodeURIComponent(slug)}`
        : "",
    };
  });

  const plans = mealPlans.map((row) => {
    const id = recipeKey(row);
    return {
      id,
      name: mealTitle(row),
      type: mealType(row),
      date: planDate(row),
      imageUrl: mediaProxyUrl(instanceId, id),
    };
  });

  const todayAll = plans.filter((row) => row.date === today);
  const todayPlans = todayAll.slice(0, 3);
  const upcomingPlans = plans.slice(0, 6);

  return {
    href: primaryBase,
    openFallbackUrl: fallbackBase,
    connectionSource: classifyConnectionSource(config, instanceId),
    about: {
      version: String(about.version || about.versionLatest || ""),
    },
    recipeTotal: Number(
      (recipesPayload as { total?: number }).total ||
        (recipesPayload as { count?: number }).count ||
        recipes.length,
    ),
    todayCount: todayAll.length,
    plannedCount: plans.length,
    recipes,
    todayPlans,
    upcomingPlans,
    shoppingLists: shoppingLists.map((row) => ({
      name: String(row.name || row.title || "Shopping List"),
      itemCount: Number(
        row.listItems?.length || row.items?.length || row.itemCount || row.item_count || 0,
      ),
    })),
  };
}
