import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, hasConnectionUrl, openUrlsFromConfig, primaryConnectionUrl } from "@/lib/open-href";
type Config = {
  baseUrl: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  apiKey: string;
  /** Raw, unmodified config values — kept alongside `baseUrl` (which gets
   *  overwritten with primaryConnectionUrl()'s pick below) so connection
   *  source classification always compares against what was actually
   *  configured, not whichever URL happened to be chosen as primary. */
  rawBaseUrl?: string;
  rawFallbackUrl?: string;
};
async function cfg(id: string) {
  const value = await readWidgetConfig(id) as Partial<Config>;
  if (!hasConnectionUrl(value) || !value.apiKey) throw new Error("Configure a Private - IP or Fallback Public URL, and API key in Settings");
  return { ...value, baseUrl: primaryConnectionUrl(value), rawBaseUrl: value.baseUrl, rawFallbackUrl: value.fallbackUrl } as Config;
}

// Tracks, per widget instance, which base URL last responded successfully so
// we can report whether we're pulling from the Private or Public URL.
const activeBases = new Map<string, string>();

function apiRoot(url: string) {
  return String(url || "").replace(/\/+$/, "");
}

export type MediaConnectionSource = "private" | "public" | "unknown";

function classifyConnectionSource(config: Config, instanceId: string): MediaConnectionSource {
  const base = activeBases.get(instanceId);
  if (!base) return "unknown";
  const normalized = apiRoot(base);
  // Compare against the raw config values, not `config.baseUrl` — by this
  // point `config.baseUrl` has already been overwritten with
  // primaryConnectionUrl()'s pick, which can silently substitute the wrong
  // URL and mislabel a successful private connection as "public" (or vice
  // versa).
  if (config.rawBaseUrl && apiRoot(config.rawBaseUrl) === normalized) return "private";
  if (config.rawFallbackUrl && apiRoot(config.rawFallbackUrl) === normalized) return "public";
  return "unknown";
}

function orderedCandidates(config: Config, instanceId?: string) {
  const urls = connectionCandidates(config);
  const active = instanceId ? activeBases.get(instanceId) : undefined;
  return active ? [...new Set([active, ...urls])] : urls;
}

async function json<T>(config: Config, path: string, init: RequestInit = {}, instanceId?: string) { let last: unknown; for (const base of orderedCandidates(config, instanceId)) try { const r = await fetch(joinUrl(base, path), { ...init, cache: "no-store", signal: AbortSignal.timeout(8000) }); if (!r.ok) throw new Error(`HTTP ${r.status}`); const data = await r.json() as T; if (instanceId) activeBases.set(instanceId, base); return data; } catch (e) { if (instanceId && activeBases.get(instanceId) === base) activeBases.delete(instanceId); last = e; } throw last instanceof Error ? last : new Error("Service unavailable"); }
export async function jellyfinStatus(id: string) { const c = await cfg(id); const headers = { "X-Emby-Token": c.apiKey }; const [sessions, counts, libraries] = await Promise.all([json<Array<{ NowPlayingItem?: { Name?: string; Type?: string }; UserName?: string; PlayState?: { IsPaused?: boolean } }>>(c, "/Sessions", { headers }), json<{ MovieCount?: number; SeriesCount?: number; EpisodeCount?: number }>(c, "/Items/Counts", { headers }), json<Array<{ Name?: string }>>(c, "/Library/VirtualFolders", { headers })]); return { ...openUrlsFromConfig(c), sessions: sessions.filter(x => x.NowPlayingItem).map(x => ({ title: x.NowPlayingItem?.Name || "Unknown", type: x.NowPlayingItem?.Type || "Media", user: x.UserName || "Unknown", paused: !!x.PlayState?.IsPaused })), movies: counts.MovieCount || 0, series: counts.SeriesCount || 0, episodes: counts.EpisodeCount || 0, libraries: libraries.map(x => x.Name || "Library") }; }
export { plexStatus } from "@/lib/widgets/plex";

type TauSession = {
  title?: string;
  full_title?: string;
  grandparent_title?: string;
  user?: string;
  username?: string;
  friendly_name?: string;
  progress_percent?: number;
  media_type?: string;
  player?: string;
  product?: string;
  state?: string;
  player_state?: string;
  transcode_decision?: string;
  stream_video_decision?: string;
  stream_decision?: string;
  quality_profile?: string;
  video_full_resolution?: string;
  video_resolution?: string;
  bandwidth?: number | string;
  stream_bandwidth?: number | string;
};

function tauCmd(c: Config, cmd: string, extra: Record<string, string> = {}) {
  const params = new URLSearchParams({ apikey: c.apiKey, cmd, ...extra });
  return json<{ response?: { data?: unknown; result?: string } }>(c, `/api/v2?${params.toString()}`);
}

function tauData<T>(raw: { response?: { data?: unknown } } | unknown): T {
  const wrapped = raw as { response?: { data?: unknown } };
  if (wrapped?.response && "data" in wrapped.response) return wrapped.response.data as T;
  return raw as T;
}

function tauSessionTitle(row: TauSession) {
  if (row.media_type === "episode") {
    return `${row.grandparent_title || row.full_title || "Unknown"} · ${row.title || ""}`.replace(/\s+·\s*$/, "");
  }
  return row.full_title || row.title || "Unknown";
}

export async function tautulliStatus(id: string) {
  const c = await cfg(id);
  const [activityRaw, librariesRaw, historyRaw, serverRaw] = await Promise.all([
    tauCmd(c, "get_activity").catch(() => ({})),
    tauCmd(c, "get_libraries").catch(() => ({})),
    tauCmd(c, "get_history", { length: "8", order_column: "date", order_dir: "desc" }).catch(() => ({})),
    tauCmd(c, "get_server_info").catch(() => ({})),
  ]);

  const activity = tauData<{ stream_count?: number; sessions?: TauSession[]; data?: TauSession[] }>(activityRaw) || {};
  const sessionsList = (Array.isArray(activity.sessions) ? activity.sessions : Array.isArray(activity.data) ? activity.data : []) as TauSession[];
  const libsRaw = tauData<unknown>(librariesRaw);
  const librariesList = (Array.isArray(libsRaw)
    ? libsRaw
    : Array.isArray((libsRaw as { data?: unknown[] })?.data)
      ? (libsRaw as { data: unknown[] }).data
      : Array.isArray((libsRaw as { libraries?: unknown[] })?.libraries)
        ? (libsRaw as { libraries: unknown[] }).libraries
        : []) as Array<Record<string, unknown>>;
  const histRaw = tauData<unknown>(historyRaw);
  const historyList = (Array.isArray(histRaw)
    ? histRaw
    : Array.isArray((histRaw as { data?: unknown[] })?.data)
      ? (histRaw as { data: unknown[] }).data
      : Array.isArray((histRaw as { history?: unknown[] })?.history)
        ? (histRaw as { history: unknown[] }).history
        : []) as TauSession[];
  const serverInfo = (tauData<Record<string, unknown>>(serverRaw) || {}) as Record<string, unknown>;

  const streams = activity.stream_count ?? sessionsList.length;
  const transcodes = sessionsList.filter((s) =>
    String(s.transcode_decision || s.stream_video_decision || "").toLowerCase().includes("transcode"),
  ).length;
  const direct = sessionsList.filter((s) => {
    const d = String(s.transcode_decision || s.stream_video_decision || "").toLowerCase();
    return d.includes("direct") || d.includes("copy");
  }).length;
  const users = new Set(sessionsList.map((s) => s.user || s.username).filter(Boolean)).size;

  const sessions = sessionsList.map((x) => ({
    title: tauSessionTitle(x),
    user: x.user || x.username || x.friendly_name || "Unknown",
    progress: Math.round(Number(x.progress_percent) || 0),
    mediaType: x.media_type || "",
    player: x.player || x.product || "",
    state: x.state || x.player_state || "",
    decision: x.transcode_decision || x.stream_video_decision || x.stream_decision || "",
    quality: x.quality_profile || x.video_full_resolution || x.video_resolution || "",
    bandwidth: x.bandwidth || x.stream_bandwidth || "",
  }));

  const libraries = librariesList.map((lib) => ({
    name: String(lib.section_name || lib.library_name || lib.name || "Library"),
    type: String(lib.section_type || lib.media_type || "library"),
    count: Number(lib.count || lib.parent_count || lib.child_count || 0),
    duration: Number(lib.duration || lib.total_duration || lib.child_duration || 0),
  }));

  const history = historyList.slice(0, 8).map((row) => ({
    title: tauSessionTitle(row),
    user: row.user || row.username || "",
    mediaType: row.media_type || "",
    date: (row as { date?: number }).date || 0,
  }));

  const sessionsOut = sessions.map((x) => ({
    ...x,
    transcode: x.decision || "",
  }));

  return {
    ...openUrlsFromConfig(c),
    streams,
    transcodes,
    direct,
    direct_play: direct,
    users,
    sessions: sessionsOut,
    libraries,
    history,
    serverName: String(serverInfo.pms_name || serverInfo.server_name || serverInfo.friendly_name || "Tautulli"),
  };
}
export async function tdarrStatus(id: string) { const c = await cfg(id); const init = { method: "POST", headers: { "Content-Type": "application/json", "x-api-key": c.apiKey }, body: JSON.stringify({ data: { collection: "StatisticsJSONDB", mode: "getById", docID: "statistics", obj: {} } }) }; const [stats, rawNodes] = await Promise.all([json<Record<string, number>>(c, "/api/v2/cruddb", init), json<Record<string, { nodeName?: string; status?: string; nodePaused?: boolean }>>(c, "/api/v2/get-nodes", { headers: { "x-api-key": c.apiKey } })]); return { ...openUrlsFromConfig(c), files: stats.totalFileCount || 0, queue: (stats.table3Count || 0) + (stats.table4Count || 0), errors: stats.table6Count || 0, transcoded: stats.totalTranscodeCount || 0, nodes: Object.values(rawNodes).map(x => ({ name: x.nodeName || "Node", status: x.status || "unknown", paused: !!x.nodePaused })) }; }
type ImmichAlbumRaw = {
  id: string;
  albumName?: string;
  assetCount?: number;
  albumThumbnailAssetId?: string;
  updatedAt?: string;
  lastModifiedAssetTimestamp?: string;
  shared?: boolean;
  owner?: { name?: string };
};

export async function immichStatus(id: string) {
  const c = await cfg(id);
  const albums = await json<ImmichAlbumRaw[]>(c, "/api/albums", {
    headers: { "x-api-key": c.apiKey, Accept: "application/json" },
  }, id);
  const base = c.baseUrl.replace(/\/$/, "");
  const { href, openFallbackUrl } = openUrlsFromConfig(c);
  return {
    href,
    openFallbackUrl,
    connectionSource: classifyConnectionSource(c, id),
    albums: albums.map((x) => ({
      id: x.id,
      name: x.albumName || "Untitled",
      count: x.assetCount ?? 0,
      thumbnail: x.albumThumbnailAssetId
        ? `/api/widgets/immich/thumbnail?instance=${encodeURIComponent(id)}&asset=${encodeURIComponent(x.albumThumbnailAssetId)}`
        : "",
      updatedAt: x.updatedAt || "",
      lastModified: x.lastModifiedAssetTimestamp || "",
      shared: !!x.shared,
      owner: x.owner?.name || "",
      href: `${base}/albums/${encodeURIComponent(x.id)}`,
    })),
  };
}

export async function immichThumbnail(id: string, asset: string) {
  if (!asset) throw new Error("Missing asset id");
  const c = await cfg(id);
  const path = `/api/assets/${encodeURIComponent(asset)}/thumbnail?size=preview`;
  const headers = { "x-api-key": c.apiKey };
  let last: unknown;
  for (const base of connectionCandidates(c)) {
    try {
      const r = await fetch(joinUrl(base, path), {
        headers,
        cache: "no-store",
        signal: AbortSignal.timeout(8000),
      });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      return r;
    } catch (e) {
      last = e;
    }
  }
  throw last instanceof Error ? last : new Error("Thumbnail unavailable");
}

type ImmichAssetRaw = {
  id?: string;
  type?: string;
  originalFileName?: string;
  localDateTime?: string;
  fileCreatedAt?: string;
  thumbhash?: string;
};

function mapImmichAssets(id: string, assets: ImmichAssetRaw[], limit = 48) {
  return assets
    .filter((asset) => asset?.id)
    .slice(0, limit)
    .map((asset) => ({
      id: String(asset.id),
      type: String(asset.type || "IMAGE").toUpperCase(),
      name: String(asset.originalFileName || "Photo"),
      takenAt: String(asset.localDateTime || asset.fileCreatedAt || ""),
      thumbnail: `/api/widgets/immich/thumbnail?instance=${encodeURIComponent(id)}&asset=${encodeURIComponent(String(asset.id))}`,
    }));
}

export async function immichAlbum(id: string, albumId: string) {
  if (!albumId) throw new Error("Missing album id");
  const c = await cfg(id);
  const headers = {
    "x-api-key": c.apiKey,
    Accept: "application/json",
    "Content-Type": "application/json",
  };
  const base = c.baseUrl.replace(/\/$/, "");

  let albumName = "Album";
  let assetCount = 0;
  let shared = false;
  let assets: ImmichAssetRaw[] = [];

  try {
    const album = await json<{
      id?: string;
      albumName?: string;
      assetCount?: number;
      shared?: boolean;
      assets?: ImmichAssetRaw[];
    }>(c, `/api/albums/${encodeURIComponent(albumId)}`, { headers });
    albumName = album.albumName || albumName;
    assetCount = album.assetCount ?? album.assets?.length ?? 0;
    shared = !!album.shared;
    if (Array.isArray(album.assets) && album.assets.length) {
      assets = album.assets;
    }
  } catch {
    /* fall through to search endpoints */
  }

  if (!assets.length) {
    try {
      const search = await json<{
        assets?: { items?: ImmichAssetRaw[]; total?: number };
        nextPage?: string | null;
      }>(c, "/api/search/metadata", {
        method: "POST",
        headers,
        body: JSON.stringify({ albumIds: [albumId], size: 48 }),
      });
      assets = search.assets?.items || [];
      if (!assetCount) assetCount = search.assets?.total ?? assets.length;
    } catch {
      try {
        const search = await json<{
          assets?: ImmichAssetRaw[];
          items?: ImmichAssetRaw[];
        }>(c, `/api/search/assets?albumIds=${encodeURIComponent(albumId)}`, {
          method: "POST",
          headers,
          body: JSON.stringify({ albumIds: [albumId], size: 48 }),
        });
        assets = search.assets || search.items || [];
      } catch {
        /* keep empty assets */
      }
    }
  }

  return {
    id: albumId,
    name: albumName,
    count: assetCount || assets.length,
    shared,
    href: `${base}/albums/${encodeURIComponent(albumId)}`,
    assets: mapImmichAssets(id, assets),
  };
}
