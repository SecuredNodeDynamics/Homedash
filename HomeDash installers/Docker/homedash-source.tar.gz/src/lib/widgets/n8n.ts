import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, hasConnectionUrl, primaryConnectionUrl } from "@/lib/open-href";

export type N8nExecutionStatus = "success" | "error" | "running" | "waiting" | "canceled" | "unknown";

export type N8nWorkflow = {
  id: string;
  name: string;
  active: boolean;
  isArchived: boolean;
  nodeCount: number;
  tags: string[];
  createdAt: string | null;
  updatedAt: string | null;
};

export type N8nExecution = {
  id: string;
  workflowId: string;
  workflowName: string;
  status: N8nExecutionStatus;
  mode: string;
  startedAt: string | null;
  stoppedAt: string | null;
  durationMs: number | null;
};

export type N8nConnectionSource = "private" | "public" | "unknown";

export type N8nStatus = {
  workflows: N8nWorkflow[];
  executions: N8nExecution[];
  workflowsHref: string;
  executionsHref: string;
  openFallbackUrl: string;
  connectionSource: N8nConnectionSource;
};

type N8nConfig = {
  baseUrl: string;
  fallbackUrl?: string;
  openFallbackUrl?: string;
  apiKey?: string;
};

function apiRoot(url: string) {
  return String(url || "").replace(/\/$/, "");
}

function classifyConnectionSource(config: N8nConfig, base: string): N8nConnectionSource {
  const normalized = apiRoot(base);
  if (config.baseUrl && apiRoot(config.baseUrl) === normalized) return "private";
  if (config.fallbackUrl && apiRoot(config.fallbackUrl) === normalized) return "public";
  return "unknown";
}

export async function loadN8nConfig(instanceId: string): Promise<N8nConfig> {
  const config = (await readWidgetConfig(instanceId)) as N8nConfig;
  if (!hasConnectionUrl(config)) {
    throw new Error("Configure a Private - IP or Fallback Public URL in Settings");
  }
  if (!config.apiKey) {
    throw new Error("Add an n8n API key in Settings");
  }
  return { ...config, baseUrl: primaryConnectionUrl(config) };
}

function normalizeStatus(raw: Record<string, unknown>): N8nExecutionStatus {
  const status = typeof raw.status === "string" ? raw.status.toLowerCase() : "";
  if (
    status === "success" ||
    status === "error" ||
    status === "running" ||
    status === "waiting" ||
    status === "canceled"
  ) {
    return status;
  }
  if (raw.finished === true) return "success";
  if (raw.startedAt && !raw.stoppedAt) return "running";
  return "unknown";
}

function toTags(raw: unknown): string[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .map((tag) => {
      if (typeof tag === "string") return tag;
      if (tag && typeof tag === "object") return String((tag as Record<string, unknown>).name ?? "");
      return "";
    })
    .filter(Boolean);
}

function toWorkflow(raw: Record<string, unknown>): N8nWorkflow {
  return {
    id: String(raw.id ?? ""),
    name: String(raw.name ?? "Untitled workflow"),
    active: Boolean(raw.active),
    isArchived: Boolean(raw.isArchived),
    nodeCount: Array.isArray(raw.nodes) ? raw.nodes.length : 0,
    tags: toTags(raw.tags),
    createdAt: typeof raw.createdAt === "string" ? raw.createdAt : null,
    updatedAt: typeof raw.updatedAt === "string" ? raw.updatedAt : null,
  };
}

function toExecution(raw: Record<string, unknown>, workflowNames: Map<string, string>): N8nExecution {
  const workflowId = String(raw.workflowId ?? "");
  const startedAt = typeof raw.startedAt === "string" ? raw.startedAt : null;
  const stoppedAt = typeof raw.stoppedAt === "string" ? raw.stoppedAt : null;
  const durationMs =
    startedAt && stoppedAt ? new Date(stoppedAt).getTime() - new Date(startedAt).getTime() : null;

  return {
    id: String(raw.id ?? ""),
    workflowId,
    workflowName: workflowNames.get(workflowId) || `Workflow ${workflowId}`,
    status: normalizeStatus(raw),
    mode: String(raw.mode ?? ""),
    startedAt,
    stoppedAt,
    durationMs: durationMs !== null && Number.isFinite(durationMs) && durationMs >= 0 ? durationMs : null,
  };
}

async function fetchJson(base: string, path: string, apiKey: string) {
  const response = await fetch(joinUrl(base, path), {
    headers: { "X-N8N-API-KEY": apiKey, Accept: "application/json" },
    cache: "no-store",
    signal: AbortSignal.timeout(8000),
  });
  if (!response.ok) {
    if (response.status === 401 || response.status === 403) {
      throw new Error("n8n rejected the API key");
    }
    throw new Error(`n8n returned ${response.status}`);
  }
  return response.json();
}

// ── Action endpoints (workflow activate/deactivate/archive, execution retry/stop) ──
// These map to n8n's real Public API (X-N8N-API-KEY auth, /api/v1/...).
// The API key used for monitoring needs write scopes (workflow:update,
// workflow:delete, execution:update) for these to succeed; n8n returns
// 401/403 otherwise. Archiving is n8n's soft-delete step: an archived
// workflow can be unarchived, or permanently removed with delete-workflow.
export type N8nActionKind =
  | "activate-workflow"
  | "deactivate-workflow"
  | "archive-workflow"
  | "unarchive-workflow"
  | "delete-workflow"
  | "retry-execution"
  | "stop-execution"
  | "delete-execution";

const ACTION_ROUTES: Record<N8nActionKind, { path: (id: string) => string; method: string }> = {
  "activate-workflow": { path: (id) => `/api/v1/workflows/${encodeURIComponent(id)}/activate`, method: "POST" },
  "deactivate-workflow": { path: (id) => `/api/v1/workflows/${encodeURIComponent(id)}/deactivate`, method: "POST" },
  "archive-workflow": { path: (id) => `/api/v1/workflows/${encodeURIComponent(id)}/archive`, method: "POST" },
  "unarchive-workflow": { path: (id) => `/api/v1/workflows/${encodeURIComponent(id)}/unarchive`, method: "POST" },
  "delete-workflow": { path: (id) => `/api/v1/workflows/${encodeURIComponent(id)}`, method: "DELETE" },
  "retry-execution": { path: (id) => `/api/v1/executions/${encodeURIComponent(id)}/retry`, method: "POST" },
  "stop-execution": { path: (id) => `/api/v1/executions/${encodeURIComponent(id)}/stop`, method: "POST" },
  "delete-execution": { path: (id) => `/api/v1/executions/${encodeURIComponent(id)}`, method: "DELETE" },
};

async function sendAction(base: string, path: string, method: string, apiKey: string) {
  const response = await fetch(joinUrl(base, path), {
    method,
    headers: { "X-N8N-API-KEY": apiKey, Accept: "application/json" },
    cache: "no-store",
    signal: AbortSignal.timeout(15000),
  });
  if (!response.ok) {
    if (response.status === 401 || response.status === 403) {
      throw new Error("n8n rejected the API key (needs write access for this action)");
    }
    if (response.status === 404) {
      throw new Error("n8n couldn't find that item (it may have been removed)");
    }
    let message = `n8n returned ${response.status}`;
    try {
      const body = await response.json();
      if (body && typeof body.message === "string") message = body.message;
    } catch {
      // ignore non-JSON error bodies
    }
    throw new Error(message);
  }
  if (response.status === 204) return null;
  const text = await response.text();
  return text ? JSON.parse(text) : null;
}

export async function performN8nAction(instanceId: string, kind: N8nActionKind, id: string) {
  if (!id) throw new Error("Missing id");
  const config = await loadN8nConfig(instanceId);
  const bases = connectionCandidates(config).map((url) => url.replace(/\/$/, ""));
  const route = ACTION_ROUTES[kind];

  let lastError: Error | null = null;
  for (const base of bases) {
    try {
      return await sendAction(base, route.path(id), route.method, config.apiKey || "");
    } catch (error) {
      lastError = error instanceof Error ? error : new Error("Failed to reach n8n");
    }
  }
  throw lastError || new Error("Failed to reach n8n");
}

async function fetchFromBase(base: string, apiKey: string) {
  const [workflowsJson, executionsJson] = await Promise.all([
    fetchJson(base, "/api/v1/workflows?limit=250", apiKey),
    fetchJson(base, "/api/v1/executions?limit=20", apiKey),
  ]);

  const workflowRows = Array.isArray(workflowsJson?.data) ? workflowsJson.data : [];
  const workflows: N8nWorkflow[] = workflowRows.map((row: Record<string, unknown>) => toWorkflow(row));
  const workflowNames = new Map<string, string>(
    workflows.map((workflow: N8nWorkflow): [string, string] => [workflow.id, workflow.name]),
  );

  const executionRows = Array.isArray(executionsJson?.data) ? executionsJson.data : [];
  const executions: N8nExecution[] = executionRows.map((row: Record<string, unknown>) =>
    toExecution(row, workflowNames),
  );

  return { workflows, executions };
}

export async function fetchN8nStatus(instanceId: string): Promise<N8nStatus> {
  const rawConfig = (await readWidgetConfig(instanceId)) as N8nConfig;
  const config = await loadN8nConfig(instanceId);
  const bases = connectionCandidates(config).map((url) => url.replace(/\/$/, ""));
  const openFallbackBase = config.openFallbackUrl || config.fallbackUrl || "";

  let lastError: Error | null = null;
  for (const base of bases) {
    try {
      const { workflows, executions } = await fetchFromBase(base, config.apiKey || "");
      return {
        workflows,
        executions,
        workflowsHref: joinUrl(base, "/home/workflows"),
        executionsHref: joinUrl(base, "/home/executions"),
        openFallbackUrl: openFallbackBase,
        connectionSource: classifyConnectionSource(rawConfig, base),
      };
    } catch (error) {
      lastError = error instanceof Error ? error : new Error("Failed to reach n8n");
    }
  }

  throw lastError || new Error("Failed to reach n8n");
}
