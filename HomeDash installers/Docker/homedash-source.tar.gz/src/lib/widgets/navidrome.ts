import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";

type Config = Record<string, string>;

export type NdTab =
  | "stats"
  | "newest"
  | "nowplaying"
  | "recent"
  | "frequent"
  | "starred"
  | "playlists";

export const ND_TABS: NdTab[] = [
  "stats",
  "newest",
  "nowplaying",
  "recent",
  "frequent",
  "starred",
  "playlists",
];

export type NdAlbum = {
  id: string;
  name?: string;
  album?: string;
  title?: string;
  artist?: string;
  albumArtist?: string;
  year?: number;
  playCount?: number;
  coverArt?: string;
  songCount?: number;
};

export type NdSong = {
  id: string;
  title?: string;
  artist?: string;
  album?: string;
  albumId?: string;
  coverArt?: string;
  duration?: number;
  playCount?: number;
  username?: string;
};

export type NdPlaylist = {
  id: string;
  name?: string;
  songCount?: number;
  duration?: number;
  coverArt?: string;
};

type SubsonicResponse = Record<string, unknown> & {
  status?: string;
  error?: { message?: string };
  artists?: { index?: Array<{ artist?: unknown[] }> };
  albumList2?: { album?: NdAlbum[] };
  nowPlaying?: { entry?: NdSong[] };
  starred2?: { album?: NdAlbum[]; song?: NdSong[] };
  playlists?: { playlist?: NdPlaylist[] };
  scanStatus?: { scanning?: boolean; lastScan?: string };
};

const LIST_SIZE = 20;
const API_VERSION = "1.16.1";
const CLIENT = "homedash";

function candidates(config: Config) {
  const out: string[] = [];
  for (const key of ["baseUrl", "fallbackUrl"] as const) {
    const value = (config[key] || "").trim().replace(/\/$/, "");
    if (value && !out.includes(value)) out.push(value);
  }
  return out;
}

function authQuery(config: Config, extra: Record<string, string | number> = {}) {
  const user = (config.user || config.username || "").trim();
  const token = (config.token || "").trim();
  const salt = (config.salt || "").trim();
  if (!user || !token || !salt) {
    throw new Error("Configure Navidrome username, token, and salt");
  }
  const params = new URLSearchParams({
    u: user,
    t: token,
    s: salt,
    v: API_VERSION,
    c: CLIENT,
    f: "json",
  });
  for (const [key, value] of Object.entries(extra)) {
    params.set(key, String(value));
  }
  return params.toString();
}

async function apiFetch(
  config: Config,
  endpoint: string,
  extra: Record<string, string | number> = {},
): Promise<{ data: SubsonicResponse; href: string }> {
  const urls = candidates(config);
  if (!urls.length) throw new Error("Configure a Private - IP or Fallback Public URL in Settings");

  const query = authQuery(config, extra);
  let lastError: Error | null = null;

  for (const base of urls) {
    try {
      const url = joinUrl(base, `/rest/${endpoint}.view?${query}`);
      const response = await fetch(url, {
        cache: "no-store",
        signal: AbortSignal.timeout(8_000),
        headers: { Accept: "application/json" },
      });
      if (!response.ok) throw new Error(`Navidrome ${response.status}`);
      const json = (await response.json()) as { "subsonic-response"?: SubsonicResponse };
      const data = json["subsonic-response"];
      if (!data || data.status !== "ok") {
        throw new Error(data?.error?.message || "API error");
      }
      return { data, href: base };
    } catch (err) {
      lastError = err instanceof Error ? err : new Error(String(err));
    }
  }

  throw lastError || new Error("All URLs failed for Navidrome");
}

function asAlbums(value: unknown): NdAlbum[] {
  return Array.isArray(value) ? (value as NdAlbum[]) : [];
}

function asSongs(value: unknown): NdSong[] {
  return Array.isArray(value) ? (value as NdSong[]) : [];
}

function asPlaylists(value: unknown): NdPlaylist[] {
  return Array.isArray(value) ? (value as NdPlaylist[]) : [];
}

function isNdTab(value: string | null): value is NdTab {
  return !!value && (ND_TABS as string[]).includes(value);
}

function openFallbackFor(config: Config) {
  return (config.openFallbackUrl || config.fallbackUrl || "").trim().replace(/\/$/, "");
}

export function navidromeCoverUrl(instanceId: string, id?: string | null, size = 200) {
  if (!id) return "";
  const params = new URLSearchParams({
    instance: instanceId,
    id,
    size: String(size),
  });
  return `/api/widgets/navidrome/cover?${params}`;
}

async function loadStats(config: Config) {
  const [artistsR, scanR, albumsR, recentR] = await Promise.allSettled([
    apiFetch(config, "getArtists"),
    apiFetch(config, "getScanStatus"),
    apiFetch(config, "getAlbumList2", { type: "alphabeticalByName", size: 500 }),
    apiFetch(config, "getAlbumList2", { type: "newest", size: 5 }),
  ]);

  const href =
    (artistsR.status === "fulfilled" && artistsR.value.href) ||
    (scanR.status === "fulfilled" && scanR.value.href) ||
    (albumsR.status === "fulfilled" && albumsR.value.href) ||
    (recentR.status === "fulfilled" && recentR.value.href) ||
    candidates(config)[0] ||
    "";

  const artists =
    artistsR.status === "fulfilled"
      ? (artistsR.value.data.artists?.index || []).reduce(
          (n, idx) => n + (idx.artist?.length || 0),
          0,
        )
      : null;

  const scanning =
    scanR.status === "fulfilled" ? Boolean(scanR.value.data.scanStatus?.scanning) : false;
  const lastScan =
    scanR.status === "fulfilled" ? scanR.value.data.scanStatus?.lastScan || null : null;

  const albumList =
    albumsR.status === "fulfilled" ? asAlbums(albumsR.value.data.albumList2?.album) : [];
  const albumCount = albumList.length || null;
  const trackCount = albumList.length
    ? albumList.reduce((sum, album) => sum + (album.songCount || 0), 0)
    : null;

  const recentAlbums =
    recentR.status === "fulfilled" ? asAlbums(recentR.value.data.albumList2?.album) : [];

  return {
    href,
    openFallbackUrl: openFallbackFor(config),
    tab: "stats" as const,
    artists,
    albums: albumCount,
    tracks: trackCount,
    scanning,
    lastScan,
    recentAlbums,
  };
}

async function loadAlbumList(config: Config, tab: "newest" | "recent" | "frequent") {
  const type = tab === "newest" ? "newest" : tab === "recent" ? "recent" : "frequent";
  const { data, href } = await apiFetch(config, "getAlbumList2", { type, size: LIST_SIZE });
  return {
    href,
    openFallbackUrl: openFallbackFor(config),
    tab,
    albumList: asAlbums(data.albumList2?.album),
  };
}

async function loadNowPlaying(config: Config) {
  const { data, href } = await apiFetch(config, "getNowPlaying");
  return {
    href,
    openFallbackUrl: openFallbackFor(config),
    tab: "nowplaying" as const,
    entries: asSongs(data.nowPlaying?.entry),
  };
}

async function loadStarred(config: Config) {
  const { data, href } = await apiFetch(config, "getStarred2");
  return {
    href,
    openFallbackUrl: openFallbackFor(config),
    tab: "starred" as const,
    starredAlbums: asAlbums(data.starred2?.album),
    starredSongs: asSongs(data.starred2?.song),
  };
}

async function loadPlaylists(config: Config) {
  const { data, href } = await apiFetch(config, "getPlaylists");
  return {
    href,
    openFallbackUrl: openFallbackFor(config),
    tab: "playlists" as const,
    playlists: asPlaylists(data.playlists?.playlist),
  };
}

export async function navidromeStatus(instanceId: string, tabRaw?: string | null) {
  const config = (await readWidgetConfig(instanceId)) as Config;
  const tab: NdTab = isNdTab(tabRaw || null) ? (tabRaw as NdTab) : "stats";

  switch (tab) {
    case "newest":
    case "recent":
    case "frequent":
      return loadAlbumList(config, tab);
    case "nowplaying":
      return loadNowPlaying(config);
    case "starred":
      return loadStarred(config);
    case "playlists":
      return loadPlaylists(config);
    case "stats":
    default:
      return loadStats(config);
  }
}

export async function navidromeCover(instanceId: string, id: string, size = 200) {
  const config = (await readWidgetConfig(instanceId)) as Config;
  if (!id) throw new Error("Missing cover id");

  const urls = candidates(config);
  if (!urls.length) throw new Error("Configure a Private - IP or Fallback Public URL in Settings");

  const query = authQuery(config, { id, size });
  let lastError: Error | null = null;

  for (const base of urls) {
    try {
      const url = joinUrl(base, `/rest/getCoverArt.view?${query}`);
      const response = await fetch(url, {
        cache: "no-store",
        signal: AbortSignal.timeout(10_000),
      });
      if (!response.ok) throw new Error(`Cover ${response.status}`);
      return response;
    } catch (err) {
      lastError = err instanceof Error ? err : new Error(String(err));
    }
  }

  throw lastError || new Error("Cover art failed");
}
