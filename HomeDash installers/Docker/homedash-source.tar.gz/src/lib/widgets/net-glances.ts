import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";

type WidgetConfig = Record<string, string>;

type Alarm = {
  name: string;
  chart: string;
  value: string;
  info: string;
};

export type NetGlancesDisk = {
  mount: string;
  percent: number;
  used: number;
  size: number;
};

export type NetGlancesStatus = {
  href: string;
  openFallbackUrl: string;
  name: string;
  iface: string;
  online: boolean;
  hostname: string;
  platform: string;
  uptime: string;
  cpu: { percent: number; cores: number } | null;
  mem: { percent: number; used: number; total: number; available: number } | null;
  swap: { percent: number; used: number; total: number } | null;
  load: { min1: number; min5: number; min15: number; cores: number } | null;
  disks: NetGlancesDisk[];
  network: {
    rx: number;
    tx: number;
    history: { rx: number[]; tx: number[] } | null;
  };
  alarms: { critical: Alarm[]; warning: Alarm[] } | null;
  interval: number;
  connectionSource: NetGlancesConnectionSource;
};

function candidates(...urls: Array<string | undefined>) {
  return [...new Set(urls.filter(Boolean).map((url) => String(url).replace(/\/+$/, "")))];
}

export type NetGlancesConnectionSource = "private" | "public" | "unknown";

// Tracks, per widget instance, which Glances base URL last responded successfully
// so we can report whether we're pulling from the Private or Public URL and so
// we can try that URL first on the next request.
const activeGlancesBases = new Map<string, string>();

function apiRoot(url: string) {
  return String(url || "").replace(/\/+$/, "");
}

function orderedUrls(instanceId: string, urls: string[]) {
  const active = activeGlancesBases.get(instanceId);
  return active ? [...new Set([active, ...urls])] : urls;
}

async function requestJson<T>(
  urls: string[],
  path: string,
  headers: HeadersInit = {},
  instanceId?: string,
): Promise<T> {
  let error: Error | null = null;
  const orderedForInstance = instanceId ? orderedUrls(instanceId, urls) : urls;
  for (const baseUrl of orderedForInstance) {
    try {
      const response = await fetch(joinUrl(baseUrl, path), {
        headers: { Accept: "application/json", ...headers },
        cache: "no-store",
        signal: AbortSignal.timeout(10_000),
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const json = (await response.json()) as T;
      if (instanceId) activeGlancesBases.set(instanceId, baseUrl);
      return json;
    } catch (err) {
      if (instanceId && activeGlancesBases.get(instanceId) === baseUrl) {
        activeGlancesBases.delete(instanceId);
      }
      error = err instanceof Error ? err : new Error("Request failed");
    }
  }
  throw error || new Error("No service URL configured");
}

async function softJson<T>(
  urls: string[],
  path: string,
  headers: HeadersInit,
  instanceId?: string,
): Promise<T | null> {
  try {
    return await requestJson<T>(urls, path, headers, instanceId);
  } catch {
    return null;
  }
}

function classifyConnectionSource(
  config: WidgetConfig,
  instanceId: string,
): NetGlancesConnectionSource {
  const base = activeGlancesBases.get(instanceId);
  if (!base) return "unknown";
  const normalized = apiRoot(base);
  if (config.baseUrl && apiRoot(config.baseUrl) === normalized) return "private";
  if (config.fallbackUrl && apiRoot(config.fallbackUrl) === normalized) return "public";
  return "unknown";
}

function interfaceData(data: unknown, preferred: string) {
  const interfaces = Array.isArray(data) ? data : [];
  return (
    interfaces.find((item) => {
      const record = item as Record<string, unknown>;
      return record.interface_name === preferred || record.name === preferred;
    }) ||
    interfaces.find((item) => {
      const name = String(
        (item as Record<string, unknown>).interface_name ||
          (item as Record<string, unknown>).name ||
          "",
      );
      return name !== "lo" && !name.startsWith("docker") && !name.startsWith("veth");
    })
  );
}

function metricIndices(labels: unknown[]) {
  const normalized = labels.map(String);
  return {
    rx: normalized.findIndex((value) => /receiv|inoctets|rx|download/i.test(value)),
    tx: normalized.findIndex((value) => /sent|outoctets|tx|upload/i.test(value)),
  };
}

async function fetchNetdata(
  urls: string[],
  iface: string,
  interval: number,
  headers: HeadersInit,
) {
  const chart = `net.${iface}`;
  const points = Math.min(200, Math.max(60, Math.round(interval / 30)));
  const data = await requestJson<{ labels?: unknown[]; data?: unknown[][] }>(
    urls,
    `/api/v1/data?chart=${encodeURIComponent(chart)}&after=-${interval}&points=${points}&format=json&options=seconds%7Cabs`,
    headers,
  );
  const rows = data.data || [];
  const { rx, tx } = metricIndices(data.labels || []);
  if (rx < 0 || tx < 0 || !rows.length) throw new Error("Network chart unavailable");
  const values = rows.map((row) => ({
    rx: (Math.abs(Number(row[rx]) || 0) * 1000) / 8,
    tx: (Math.abs(Number(row[tx]) || 0) * 1000) / 8,
  }));
  return {
    live: values.at(-1) || { rx: 0, tx: 0 },
    history: { rx: values.map((value) => value.rx), tx: values.map((value) => value.tx) },
  };
}

async function fetchAlarms(urls: string[], headers: HeadersInit) {
  try {
    const data = await requestJson<{ alarms?: Record<string, Record<string, unknown>> }>(
      urls,
      "/api/v1/alarms?active",
      headers,
    );
    const alarms = Object.values(data.alarms || {});
    const map = (status: string): Alarm[] =>
      alarms
        .filter((alarm) => alarm.status === status)
        .map((alarm) => ({
          name: String(alarm.name || "Unknown"),
          chart: String(alarm.chart || ""),
          value: String(alarm.value_string || alarm.value || ""),
          info: String(alarm.info || ""),
        }));
    return { critical: map("CRITICAL"), warning: map("WARNING") };
  } catch {
    return null;
  }
}

function pickDisks(raw: unknown): NetGlancesDisk[] {
  if (!Array.isArray(raw)) return [];
  const skipped = /\/(boot|efi|snap|docker|kubelet|var\/lib\/docker)/i;
  const disks = raw
    .map((item) => {
      const row = item as Record<string, unknown>;
      const mount = String(row.mnt_point || row.mountpoint || "");
      const size = Number(row.size) || 0;
      const used = Number(row.used) || 0;
      const percent = Number(row.percent) || (size > 0 ? (used / size) * 100 : 0);
      return { mount, percent, used, size };
    })
    .filter((disk) => disk.mount && disk.size > 0 && !skipped.test(disk.mount));

  const root = disks.find((disk) => disk.mount === "/");
  const others = disks
    .filter((disk) => disk.mount !== "/")
    .sort((a, b) => b.used - a.used || b.percent - a.percent)
    .slice(0, 3);

  const picked = root ? [root, ...others.filter((d) => d.mount !== "/")] : others;
  return picked.slice(0, 4);
}

export async function fetchNetGlancesStatus(
  instanceId: string,
  interval = 3600,
): Promise<NetGlancesStatus> {
  const config = (await readWidgetConfig(instanceId)) as WidgetConfig;
  const glancesUrls = candidates(config.baseUrl, config.fallbackUrl);
  if (!glancesUrls.length) {
    throw new Error("Configure a Private - IP or Fallback Public URL in Settings");
  }

  const netdataUrls = candidates(config.netdataBaseUrl, config.netdataFallbackUrl);
  const iface = config.interface || "vmbr0";
  const headers: HeadersInit = config.apiKey?.trim()
    ? { Authorization: `Bearer ${config.apiKey.trim()}` }
    : {};

  const [cpu, mem, swap, load, fs, uptime, system, networkRaw] = await Promise.all([
    softJson<Record<string, unknown>>(glancesUrls, "/api/4/cpu", headers, instanceId),
    softJson<Record<string, unknown>>(glancesUrls, "/api/4/mem", headers, instanceId),
    softJson<Record<string, unknown>>(glancesUrls, "/api/4/memswap", headers, instanceId),
    softJson<Record<string, unknown>>(glancesUrls, "/api/4/load", headers, instanceId),
    softJson<unknown>(glancesUrls, "/api/4/fs", headers, instanceId),
    softJson<string | Record<string, unknown>>(glancesUrls, "/api/4/uptime", headers, instanceId),
    softJson<Record<string, unknown>>(glancesUrls, "/api/4/system", headers, instanceId),
    softJson<unknown[]>(glancesUrls, "/api/4/network", headers, instanceId),
  ]);

  const glancesOnline = Boolean(cpu || mem || load || networkRaw);
  let rx = 0;
  let tx = 0;
  let history: { rx: number[]; tx: number[] } | null = null;
  let online = glancesOnline;

  if (netdataUrls.length) {
    try {
      const netdata = await fetchNetdata(netdataUrls, iface, interval, headers);
      rx = netdata.live.rx;
      tx = netdata.live.tx;
      history = netdata.history;
      online = true;
    } catch {
      // Fall through to Glances live rates.
    }
  }

  if (!history || (!rx && !tx)) {
    const selected = interfaceData(networkRaw, iface) as Record<string, unknown> | undefined;
    if (selected) {
      rx = Number(selected.bytes_recv_rate_per_sec) || rx;
      tx = Number(selected.bytes_sent_rate_per_sec) || tx;
      online = true;
    }
  }

  const alarms = netdataUrls.length ? await fetchAlarms(netdataUrls, headers) : null;
  const uptimeText =
    typeof uptime === "string"
      ? uptime
      : uptime && typeof uptime === "object"
        ? String((uptime as Record<string, unknown>).uptime || "")
        : "";

  return {
    href: config.publicUrl?.trim() || glancesUrls[0] || "",
    openFallbackUrl: config.openFallbackUrl?.trim() || config.fallbackUrl?.trim() || "",
    name: config.nodeName?.trim() || "Glances",
    iface,
    online,
    hostname: String(system?.hostname || ""),
    platform: String(system?.linux_distro || system?.os_name || ""),
    uptime: uptimeText,
    cpu: cpu
      ? {
          percent: Number(cpu.total) || 0,
          cores: Number(cpu.cpucore) || 0,
        }
      : null,
    mem: mem
      ? {
          percent: Number(mem.percent) || 0,
          used: Number(mem.used) || 0,
          total: Number(mem.total) || 0,
          available: Number(mem.available) || 0,
        }
      : null,
    swap: swap
      ? {
          percent: Number(swap.percent) || 0,
          used: Number(swap.used) || 0,
          total: Number(swap.total) || 0,
        }
      : null,
    load: load
      ? {
          min1: Number(load.min1) || 0,
          min5: Number(load.min5) || 0,
          min15: Number(load.min15) || 0,
          cores: Number(load.cpucore) || Number(cpu?.cpucore) || 0,
        }
      : null,
    disks: pickDisks(fs),
    network: { rx, tx, history },
    alarms,
    interval,
    connectionSource: classifyConnectionSource(config, instanceId),
  };
}
