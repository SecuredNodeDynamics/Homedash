import { request as httpsRequest } from "node:https";
import { request as httpRequestRaw } from "node:http";
import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, hasConnectionUrl } from "@/lib/open-href";

export type NcTab =
  | "overview"
  | "files"
  | "talk"
  | "calendar"
  | "contacts"
  | "shares"
  | "activity"
  | "alerts";

export type NcFilesMode = "browse" | "favorites" | "recent" | "trash";

type Config = {
  baseUrl: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  username: string;
  password: string;
  shareLimit?: number;
  activityLimit?: number;
  notifyLimit?: number;
  talkLimit?: number;
  talkChatLimit?: number;
  calendarLimit?: number;
  taskLimit?: number;
  contactsLimit?: number;
  recentLimit?: number;
  favoriteLimit?: number;
  trashLimit?: number;
  storageTotalGb?: number | null;
  storageTotalBytes?: number | null;
};

type DavFile = {
  name: string;
  path: string;
  href?: string;
  isDir: boolean;
  size: number | null;
  modified: string | null;
  fileId: string | null;
  favorite?: boolean;
  trashName?: string;
  originalLocation?: string;
  deletedAt?: string | null;
};

type CalendarEvent = {
  summary: string;
  start: string | null;
  end: string | null;
  location: string;
  uid: string;
  allDay: boolean;
  calendarName?: string;
};

type TaskItem = {
  uid: string;
  summary: string;
  completed: boolean;
  due: string | null;
  priority: number;
  listName: string;
  calendarPath?: string;
  status: string;
};

type ContactItem = {
  id: string;
  name: string;
  email: string;
  phone: string;
  source: string;
  link: string | null;
};

type ResolvedBase = { cfg: Config; base: string; auth: string; userId: string };

export type NcConnectionSource = "private" | "public" | "unknown";

function apiRoot(url: string) {
  return String(url || "").replace(/\/+$/, "");
}

function classifyConnectionSource(cfg: Config, base: string): NcConnectionSource {
  const normalized = apiRoot(base);
  if (cfg.baseUrl && apiRoot(cfg.baseUrl) === normalized) return "private";
  if (cfg.fallbackUrl && apiRoot(cfg.fallbackUrl) === normalized) return "public";
  return "unknown";
}

// Homelab HTTPS endpoints are almost always self-signed or backed by an internal/private
// CA. Node's built-in fetch() rejects those certs by default, which is exactly why a
// private `https://` base fails with "self-signed certificate" while curl or a browser
// already configured to trust that cert works fine.
//
// `undici` isn't a dependency of this app, so rather than pull in a package just to get
// at its Agent/dispatcher, this talks straight to node:https/node:http with
// `rejectUnauthorized: false`. It's only ever used for the exact "Private - IP" URL the
// user configured in Settings — never for the public Fallback URL, which keeps full
// certificate validation.
type FetchLikeResponse = {
  ok: boolean;
  status: number;
  text(): Promise<string>;
  json(): Promise<any>;
  arrayBuffer(): Promise<ArrayBuffer>;
};

function headersToPlain(init?: RequestInit["headers"]): Record<string, string> {
  const out: Record<string, string> = {};
  if (!init) return out;
  if (typeof Headers !== "undefined" && init instanceof Headers) {
    init.forEach((v, k) => (out[k] = v));
    return out;
  }
  if (Array.isArray(init)) {
    for (const [k, v] of init) out[k] = String(v);
    return out;
  }
  Object.assign(out, init as Record<string, string>);
  return out;
}

function insecureFetch(url: string, init: RequestInit = {}): Promise<FetchLikeResponse> {
  return new Promise((resolve, reject) => {
    let parsed: URL;
    try {
      parsed = new URL(url);
    } catch (err) {
      reject(err as Error);
      return;
    }
    const isHttps = parsed.protocol === "https:";
    const doRequest = isHttps ? httpsRequest : httpRequestRaw;
    const method = String(init.method || "GET").toUpperCase();
    const headers = headersToPlain(init.headers);

    let bodyBuf: Buffer | undefined;
    const rawBody = init.body as unknown;
    if (typeof rawBody === "string") bodyBuf = Buffer.from(rawBody);
    else if (rawBody instanceof Uint8Array) bodyBuf = Buffer.from(rawBody);
    if (bodyBuf && headers["Content-Length"] === undefined && headers["content-length"] === undefined) {
      headers["Content-Length"] = String(bodyBuf.length);
    }

    const req = doRequest(
      {
        hostname: parsed.hostname,
        port: parsed.port || (isHttps ? 443 : 80),
        path: `${parsed.pathname}${parsed.search}`,
        method,
        headers,
        // The whole point of this function: this is a private LAN endpoint with a
        // self-signed/internal-CA cert we've intentionally chosen to trust.
        rejectUnauthorized: false,
      } as any,
      (res) => {
        const chunks: Buffer[] = [];
        res.on("data", (chunk) => chunks.push(chunk as Buffer));
        res.on("end", () => {
          const buf = Buffer.concat(chunks);
          const status = res.statusCode || 0;
          resolve({
            ok: status >= 200 && status < 300,
            status,
            text: async () => buf.toString("utf8"),
            json: async () => (buf.length ? JSON.parse(buf.toString("utf8")) : null),
            arrayBuffer: async () =>
              buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) as ArrayBuffer,
          });
        });
      },
    );

    req.on("error", reject);

    const signal = init.signal;
    if (signal) {
      if (signal.aborted) {
        req.destroy();
        reject(new Error("The operation was aborted"));
        return;
      }
      signal.addEventListener(
        "abort",
        () => {
          req.destroy();
          reject(new Error("The operation was aborted"));
        },
        { once: true },
      );
    }

    if (bodyBuf) req.write(bodyBuf);
    req.end();
  });
}

/**
 * Drop-in fetch() replacement: uses the normal, fully-verified global fetch() for every
 * base except the one exact "Private - IP" URL configured for this widget, where it
 * falls back to the dependency-free insecure client above.
 */
function tlsFetch(cfg: Config, base: string, url: string, init: RequestInit): Promise<FetchLikeResponse> {
  const privateUrl = String(cfg.baseUrl || "").trim();
  const isPrivateHttps = base.startsWith("https://") && !!privateUrl && apiRoot(base) === apiRoot(privateUrl);
  if (isPrivateHttps) return insecureFetch(url, init);
  return fetch(url, init) as unknown as Promise<FetchLikeResponse>;
}

const DEFAULTS = {
  shareLimit: 12,
  activityLimit: 16,
  notifyLimit: 12,
  talkLimit: 24,
  talkChatLimit: 50,
  calendarLimit: 40,
  taskLimit: 40,
  contactsLimit: 20,
  recentLimit: 24,
  favoriteLimit: 24,
  trashLimit: 24,
};

function lim(cfg: Config, key: keyof typeof DEFAULTS) {
  const n = Number(cfg[key]);
  return Number.isFinite(n) && n > 0 ? n : DEFAULTS[key];
}

function bases(cfg: Config) {
  // Always try the Private - IP URL before the Fallback Public URL. Do not rely on
  // connectionCandidates()'s own ordering for this — it is a shared helper used across
  // widgets and isn't guaranteed to put the private/LAN URL first, which previously let
  // requests land on (and get "stuck" reporting) the public URL even when the private
  // one was reachable.
  const ordered = [cfg.baseUrl, cfg.fallbackUrl]
    .map((u) => String(u || "").trim())
    .filter(Boolean)
    .map((u) => u.replace(/\/$/, ""));
  if (ordered.length) return ordered;
  // Neither the private nor public API URL is configured directly (e.g. only the
  // "OPEN" link fields are set) — fall back to the shared resolver so the widget still
  // has something to try.
  return connectionCandidates(cfg).map((u) => u.replace(/\/$/, ""));
}

function authHeader(cfg: Config) {
  return `Basic ${Buffer.from(`${cfg.username}:${cfg.password}`).toString("base64")}`;
}

async function loadConfig(instanceId: string): Promise<Config> {
  const value = (await readWidgetConfig(instanceId)) as Partial<Config>;
  if (!hasConnectionUrl(value) || !value.username || !value.password) {
    throw new Error("Configure a Private - IP or Fallback Public URL, username, and app password");
  }
  return { ...value, baseUrl: value.baseUrl || "" } as Config;
}

function unwrapOcs(payload: unknown) {
  const root = payload as { ocs?: { meta?: Record<string, unknown>; data?: unknown }; data?: unknown };
  const ocs = root?.ocs || root;
  const meta = (ocs as { meta?: Record<string, unknown> })?.meta || {};
  const code = Number(meta.statuscode ?? meta.statusCode ?? 0);
  if (code && code !== 100 && code !== 200) {
    throw new Error(String(meta.message || `Nextcloud OCS ${code}`));
  }
  return (ocs as { data?: unknown })?.data ?? root?.data ?? payload;
}

function normalizeList(raw: unknown): Array<Record<string, unknown>> {
  if (Array.isArray(raw)) return raw as Array<Record<string, unknown>>;
  if (!raw || typeof raw !== "object") return [];
  const obj = raw as Record<string, unknown>;
  for (const key of ["element", "data", "users", "rooms", "notifications", "shares"]) {
    if (Array.isArray(obj[key])) return obj[key] as Array<Record<string, unknown>>;
  }
  return [];
}

function decodeXmlEntities(value: string) {
  return value
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCharCode(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)))
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, "&");
}

function cleanText(value: string) {
  return decodeXmlEntities(String(value || ""))
    .replace(/\r\n/g, " ")
    .replace(/[\r\n]+/g, " ")
    .replace(/\u0000/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function localNameBlocks(xml: string, localName: string): string[] {
  const re = new RegExp(`<(?:[\\w.-]+:)?${localName}\\b[^>]*>([\\s\\S]*?)<\\/(?:[\\w.-]+:)?${localName}>`, "gi");
  const out: string[] = [];
  let m: RegExpExecArray | null;
  while ((m = re.exec(xml))) out.push(m[1]);
  return out;
}

function textOf(block: string, localName: string) {
  const re = new RegExp(`<(?:[\\w.-]+:)?${localName}\\b[^>]*>([\\s\\S]*?)<\\/(?:[\\w.-]+:)?${localName}>`, "i");
  const m = block.match(re);
  return m ? decodeXmlEntities(m[1].replace(/<[^>]+>/g, "").trim()) : "";
}

function hasLocal(block: string, localName: string) {
  return new RegExp(`<(?:[\\w.-]+:)?${localName}\\b`, "i").test(block);
}

function attrOf(block: string, localName: string, attr: string) {
  const re = new RegExp(`<(?:[\\w.-]+:)?${localName}\\b([^>]*)>`, "gi");
  const vals: string[] = [];
  let m: RegExpExecArray | null;
  while ((m = re.exec(block))) {
    const am = m[1].match(new RegExp(`${attr}\\s*=\\s*["']([^"']+)["']`, "i"));
    if (am) vals.push(am[1]);
  }
  return vals;
}

async function withFailover<T>(cfg: Config, run: (base: string) => Promise<T>): Promise<{ result: T; base: string }> {
  let last: unknown;
  for (const base of bases(cfg)) {
    try {
      const result = await run(base);
      return { result, base };
    } catch (error) {
      // Surface *why* this base failed instead of silently moving on — without this,
      // a failing private URL is indistinguishable from one that was never tried.
      // Node's fetch() throws a generic "fetch failed" at the top level; the actual
      // reason (TLS cert error, ECONNREFUSED, DNS failure, etc.) lives in .cause.
      const cause = error instanceof Error && "cause" in error ? (error as { cause?: unknown }).cause : undefined;
      console.warn(
        `[nextcloud] base ${base} failed, trying next candidate:`,
        error instanceof Error ? error.message : error,
        cause ? `| cause: ${cause instanceof Error ? cause.message : String(cause)}` : "",
      );
      last = error;
    }
  }
  throw last instanceof Error ? last : new Error("Nextcloud unavailable");
}

export async function ocsFetch(
  cfg: Config,
  path: string,
  opts: { method?: string; body?: BodyInit | null; form?: Record<string, string | number | boolean | null | undefined>; base?: string } = {},
): Promise<{ data: unknown; base: string }> {
  const auth = authHeader(cfg);
  const headers: Record<string, string> = {
    Authorization: auth,
    "OCS-APIRequest": "true",
    Accept: "application/json",
  };
  let body: BodyInit | null | undefined = opts.body;
  if (opts.form) {
    const params = new URLSearchParams();
    for (const [k, v] of Object.entries(opts.form)) {
      if (v == null) continue;
      params.set(k, String(v));
    }
    body = params.toString();
    headers["Content-Type"] = "application/x-www-form-urlencoded";
  }

  const attempt = async (base: string) => {
    const res = await tlsFetch(cfg, base, joinUrl(base, path), {
      method: opts.method || (body ? "POST" : "GET"),
      headers,
      body,
      cache: "no-store",
      signal: AbortSignal.timeout(15_000),
    });
    if (res.status === 204) return null;
    if (!res.ok) {
      let detail = "";
      try {
        const j = (await res.json()) as { ocs?: { meta?: { message?: string } } };
        detail = j?.ocs?.meta?.message || "";
      } catch {
        /* ignore */
      }
      throw new Error(detail || `Nextcloud HTTP ${res.status}`);
    }
    const json = await res.json();
    return unwrapOcs(json);
  };

  if (opts.base) {
    return { data: await attempt(opts.base), base: opts.base };
  }
  const { result, base } = await withFailover(cfg, attempt);
  return { data: result, base };
}

export async function davRequest(
  cfg: Config,
  davPath: string,
  opts: {
    method?: string;
    headers?: Record<string, string>;
    body?: string | null;
    okStatuses?: number[];
    base?: string;
  } = {},
): Promise<{ res: FetchLikeResponse; base: string; text: string }> {
  const auth = authHeader(cfg);
  const ok = opts.okStatuses || [200, 207];
  const method = opts.method || "PROPFIND";
  const attempt = async (base: string) => {
    const res = await tlsFetch(cfg, base, joinUrl(base, davPath), {
      method,
      headers: {
        Authorization: auth,
        Accept: "application/xml, text/xml, */*",
        ...(opts.headers || {}),
      },
      body: opts.body == null ? undefined : opts.body,
      cache: "no-store",
      signal: AbortSignal.timeout(20_000),
    });
    if (!ok.includes(res.status) && !res.ok) {
      throw new Error(`WebDAV HTTP ${res.status}`);
    }
    const text = await res.text();
    return { res, text };
  };
  if (opts.base) {
    const hit = await attempt(opts.base);
    return { ...hit, base: opts.base };
  }
  const { result, base } = await withFailover(cfg, attempt);
  return { ...result, base };
}

function normalizeFilesPath(path: string) {
  const clean = `/${String(path || "").replace(/^\/+|\/+$/g, "")}`;
  return clean === "/" ? "/" : clean;
}

function davHrefForPath(userId: string, relPath: string) {
  const parts = String(relPath || "/")
    .split("/")
    .filter(Boolean)
    .map(encodeURIComponent);
  const base = `/remote.php/dav/files/${encodeURIComponent(userId)}/`;
  if (!parts.length) return base;
  return `${base}${parts.join("/")}/`;
}

function pathFromDavHref(href: string) {
  const raw = decodeURIComponent(String(href || ""));
  const marker = `/dav/files/`;
  const idx = raw.indexOf(marker);
  if (idx < 0) return "/";
  let rest = raw.slice(idx + marker.length);
  const slash = rest.indexOf("/");
  rest = slash >= 0 ? rest.slice(slash) : "/";
  if (!rest.startsWith("/")) rest = `/${rest}`;
  return normalizeFilesPath(rest.replace(/\/+$/, "") || "/");
}

function pathFromTrashHref(href: string) {
  const raw = decodeURIComponent(String(href || ""));
  const marker = "/dav/trashbin/";
  const idx = raw.indexOf(marker);
  if (idx < 0) return raw;
  let rest = raw.slice(idx + marker.length);
  const slash = rest.indexOf("/");
  rest = slash >= 0 ? rest.slice(slash) : "/";
  if (!rest.startsWith("/")) rest = `/${rest}`;
  return rest.replace(/\/+$/, "") || "/";
}

function parseDavItems(
  xmlText: string,
  opts: {
    skipSelf?: string | null;
    pathResolver?: (href: string) => string;
    trash?: boolean;
  } = {},
): DavFile[] {
  const responses = localNameBlocks(xmlText, "response");
  const items: DavFile[] = [];
  const selfPath = opts.skipSelf != null ? normalizeFilesPath(opts.skipSelf) : null;
  const resolve = opts.pathResolver || pathFromDavHref;

  for (const resp of responses) {
    const href = textOf(resp, "href");
    if (!href) continue;
    const path = resolve(href);
    if (selfPath != null && path === selfPath) continue;
    const isDir = hasLocal(resp, "collection");
    const display =
      textOf(resp, "displayname") ||
      textOf(resp, "trashbin-filename") ||
      path.split("/").filter(Boolean).pop() ||
      (isDir ? "Folder" : "File");
    const sizeRaw = textOf(resp, "size") || textOf(resp, "getcontentlength");
    const modified = textOf(resp, "getlastmodified") || null;
    const fileId = textOf(resp, "fileid") || null;
    const fav = textOf(resp, "favorite");
    const item: DavFile = {
      name: display,
      path,
      href,
      isDir,
      size: sizeRaw !== "" && Number.isFinite(Number(sizeRaw)) ? Number(sizeRaw) : null,
      modified,
      fileId,
      favorite: fav === "1",
    };
    if (opts.trash) {
      item.trashName = textOf(resp, "trashbin-filename") || display;
      item.originalLocation = textOf(resp, "trashbin-original-location") || "";
      item.deletedAt = textOf(resp, "trashbin-deletion-time") || modified;
      item.name = item.trashName;
    }
    items.push(item);
  }

  items.sort((a, b) => {
    if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
    return String(a.name).localeCompare(String(b.name), undefined, { sensitivity: "base" });
  });
  return items;
}

async function resolveSession(instanceId: string): Promise<ResolvedBase> {
  const cfg = await loadConfig(instanceId);
  const { data, base } = await ocsFetch(cfg, "/ocs/v2.php/cloud/user?format=json");
  const user = (data || {}) as Record<string, unknown>;
  const userId = String(user.id || cfg.username);
  return { cfg, base, auth: authHeader(cfg), userId };
}

async function ocsOptional(cfg: Config, base: string, path: string, fallback: unknown = null) {
  try {
    const { data } = await ocsFetch(cfg, path, { base });
    return data;
  } catch {
    return fallback;
  }
}

async function fetchPublic(cfg: Config, base: string, path: string) {
  const res = await tlsFetch(cfg, base, joinUrl(base, path), {
    headers: { Accept: "application/json" },
    cache: "no-store",
    signal: AbortSignal.timeout(8_000),
  });
  if (!res.ok) throw new Error(`Nextcloud HTTP ${res.status}`);
  return res.json();
}

function serverBits(server: Record<string, unknown> | null) {
  const nc = (server?.nextcloud || server || {}) as Record<string, unknown>;
  const system = (nc.system || {}) as Record<string, unknown>;
  const storage = (nc.storage || {}) as Record<string, unknown>;
  const shares = (nc.shares || {}) as Record<string, unknown>;
  const active = (server?.activeUsers || nc.activeUsers || {}) as Record<string, unknown>;
  const freespace = Number(system.freespace);
  return {
    version: (system.version || system.versionstring || null) as string | null,
    users: (storage.num_users ?? null) as number | null,
    files: (storage.num_files ?? null) as number | null,
    shareCount: (shares.num_shares ?? null) as number | null,
    active24h: (active.last24hours ?? null) as number | null,
    webserver: ((server?.server as Record<string, unknown> | undefined)?.webserver as string | null) || null,
    freespace: Number.isFinite(freespace) && freespace >= 0 ? freespace : null,
    hasServerinfo: !!(storage.num_users != null || storage.num_files != null || (Number.isFinite(freespace) && freespace >= 0)),
  };
}

function resolveStorage(
  user: Record<string, unknown>,
  server: Record<string, unknown> | null,
  cfg: Config,
) {
  const q = (user.quota && typeof user.quota === "object" ? user.quota : {}) as Record<string, unknown>;
  const used = Number(q.used);
  const usedBytes = Number.isFinite(used) && used >= 0 ? used : 0;
  const free = Number(q.free);
  const total = Number(q.total);
  const quotaVal = Number(q.quota);
  const relative = Number(q.relative);
  const quotaUnlimited =
    quotaVal < 0 || free < 0 || !Number.isFinite(total) || total <= 0 || total >= 9e18;

  if (!quotaUnlimited && Number.isFinite(total) && total > 0) {
    const pct = Number.isFinite(relative) ? relative : (usedBytes / total) * 100;
    const freeBytes = Number.isFinite(free) && free >= 0 ? free : Math.max(0, total - usedBytes);
    return { used: usedBytes, free: freeBytes, total, pct: Math.min(100, Math.max(0, pct)), source: "quota" as const };
  }

  const info = serverBits(server);
  if (info.freespace != null) {
    const diskTotal = usedBytes + info.freespace;
    return {
      used: usedBytes,
      free: info.freespace,
      total: diskTotal,
      pct: diskTotal > 0 ? Math.min(100, (usedBytes / diskTotal) * 100) : 0,
      source: "disk" as const,
    };
  }

  const gb = Number(cfg.storageTotalGb);
  const configured =
    Number.isFinite(gb) && gb > 0
      ? gb * 1e9
      : Number.isFinite(Number(cfg.storageTotalBytes)) && Number(cfg.storageTotalBytes) > 0
        ? Number(cfg.storageTotalBytes)
        : null;
  if (configured != null) {
    return {
      used: usedBytes,
      free: Math.max(0, configured - usedBytes),
      total: configured,
      pct: configured > 0 ? Math.min(100, (usedBytes / configured) * 100) : 0,
      source: "config" as const,
    };
  }

  return { used: usedBytes, free: null as number | null, total: null as number | null, pct: null as number | null, source: "unknown" as const };
}

function healthBits(server: Record<string, unknown> | null, status: Record<string, unknown> | null) {
  const nc = (server?.nextcloud || server || {}) as Record<string, unknown>;
  const system = (nc.system || {}) as Record<string, unknown>;
  const update = (system.update || system.updates || {}) as Record<string, unknown>;
  const apps = (nc.apps || system.apps || {}) as Record<string, unknown>;
  const php = (server?.php || nc.php || {}) as Record<string, unknown>;
  const database = (server?.database || nc.database || {}) as Record<string, unknown>;
  const warnings: string[] = [];
  if (status?.maintenance) warnings.push("Maintenance mode");
  if (status?.needsDbUpgrade) warnings.push("DB upgrade needed");
  if (system.debug === "yes" || system.debug === true) warnings.push("Debug mode on");
  const appUpdates = Number(apps.updates_available ?? apps.app_updates ?? update.available ?? 0);
  const info = serverBits(server);
  return {
    version: info.version,
    php: (php.version || php.phpversion || null) as string | null,
    db: (database.type || database.version || null) as string | null,
    appUpdates: Number.isFinite(appUpdates) ? appUpdates : 0,
    updateAvailable: !!(update.available || system.updateAvailable),
    warnings,
    hasServerinfo: info.hasServerinfo,
  };
}

function capsRoot(capabilities: Record<string, unknown> | null) {
  return ((capabilities?.capabilities || capabilities || {}) as Record<string, unknown>) || {};
}

function hasTalkApp(capabilities: Record<string, unknown> | null) {
  return !!capsRoot(capabilities).spreed;
}

function sortRooms(rooms: Array<Record<string, unknown>>) {
  return rooms
    .slice()
    .sort((a, b) => {
      const mentionA = a.unreadMentionDirect || a.unreadMention ? 1 : 0;
      const mentionB = b.unreadMentionDirect || b.unreadMention ? 1 : 0;
      if (mentionA !== mentionB) return mentionB - mentionA;
      const unreadDiff = Number(b.unreadMessages || 0) - Number(a.unreadMessages || 0);
      if (unreadDiff) return unreadDiff;
      return Number(b.lastActivity || 0) - Number(a.lastActivity || 0);
    });
}

async function listFilesBrowse(session: ResolvedBase, path: string) {
  const rel = normalizeFilesPath(path);
  const body = `<?xml version="1.0" encoding="UTF-8"?>
<d:propfind xmlns:d="DAV:" xmlns:oc="http://owncloud.org/ns" xmlns:nc="http://nextcloud.org/ns">
  <d:prop>
    <d:displayname/>
    <d:getlastmodified/>
    <d:getcontentlength/>
    <d:resourcetype/>
    <oc:size/>
    <oc:fileid/>
  </d:prop>
</d:propfind>`;
  const { text } = await davRequest(session.cfg, davHrefForPath(session.userId, rel), {
    method: "PROPFIND",
    headers: { "Content-Type": "text/xml; charset=utf-8", Depth: "1" },
    body,
    base: session.base,
  });
  return parseDavItems(text, { skipSelf: rel });
}

async function listFavorites(session: ResolvedBase) {
  const body = `<?xml version="1.0"?>
<oc:filter-files xmlns:d="DAV:" xmlns:oc="http://owncloud.org/ns" xmlns:nc="http://nextcloud.org/ns">
  <d:prop>
    <d:displayname/>
    <d:getlastmodified/>
    <d:getcontentlength/>
    <d:resourcetype/>
    <oc:size/>
    <oc:fileid/>
    <oc:favorite/>
  </d:prop>
  <oc:filter-rules>
    <oc:favorite>1</oc:favorite>
  </oc:filter-rules>
</oc:filter-files>`;
  const { text } = await davRequest(session.cfg, `/remote.php/dav/files/${encodeURIComponent(session.userId)}/`, {
    method: "REPORT",
    headers: { "Content-Type": "text/xml; charset=utf-8", Depth: "0" },
    body,
    base: session.base,
  });
  return parseDavItems(text).slice(0, lim(session.cfg, "favoriteLimit"));
}

async function listRecent(session: ResolvedBase) {
  const res = await tlsFetch(session.cfg, session.base, joinUrl(session.base, "/index.php/apps/files/api/v1/recent/"), {
    headers: {
      Accept: "application/json",
      Authorization: session.auth,
    },
    cache: "no-store",
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) throw new Error(`Recent files HTTP ${res.status}`);
  const json = await res.json();
  const rows = Array.isArray(json) ? json : normalizeList(json);
  return rows.slice(0, lim(session.cfg, "recentLimit")).map((row) => {
    const path = normalizeFilesPath(String(row.path || row.filePath || row.name || "/"));
    const name = String(row.name || path.split("/").filter(Boolean).pop() || "File");
    return {
      name,
      path,
      isDir: row.type === "dir" || row.isDir === true,
      size: row.size != null ? Number(row.size) : null,
      modified: (row.mtime || row.modified || row.lastModified || null) as string | null,
      fileId: (row.fileid || row.fileId || row.id || null) as string | null,
    } satisfies DavFile;
  });
}

async function listTrash(session: ResolvedBase) {
  const body = `<?xml version="1.0" encoding="UTF-8"?>
<d:propfind xmlns:d="DAV:" xmlns:oc="http://owncloud.org/ns" xmlns:nc="http://nextcloud.org/ns">
  <d:prop>
    <d:displayname/>
    <d:getlastmodified/>
    <d:getcontentlength/>
    <d:resourcetype/>
    <oc:size/>
    <oc:fileid/>
    <nc:trashbin-filename/>
    <nc:trashbin-original-location/>
    <nc:trashbin-deletion-time/>
  </d:prop>
</d:propfind>`;
  const { text } = await davRequest(session.cfg, `/remote.php/dav/trashbin/${encodeURIComponent(session.userId)}/trash`, {
    method: "PROPFIND",
    headers: { "Content-Type": "text/xml; charset=utf-8", Depth: "1" },
    body,
    base: session.base,
  });
  return parseDavItems(text, {
    skipSelf: "/trash",
    pathResolver: pathFromTrashHref,
    trash: true,
  }).slice(0, lim(session.cfg, "trashLimit"));
}

function calDavTime(d: Date) {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
}

function parseIcsDate(raw: string) {
  const s = String(raw || "").trim();
  if (!s) return null;
  if (/^\d{8}$/.test(s)) {
    return new Date(`${s.slice(0, 4)}-${s.slice(4, 6)}-${s.slice(6, 8)}T00:00:00Z`);
  }
  const m = s.match(/^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})(Z)?$/);
  if (!m) {
    const d = new Date(s);
    return Number.isNaN(d.getTime()) ? null : d;
  }
  const iso = `${m[1]}-${m[2]}-${m[3]}T${m[4]}:${m[5]}:${m[6]}${m[7] || "Z"}`;
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? null : d;
}

function parseIcsEvents(icsText: string): Omit<CalendarEvent, "calendarName">[] {
  const text = String(icsText || "").replace(/\r\n[ \t]/g, "");
  const blocks = text.split(/BEGIN:VEVENT/i).slice(1);
  const out: Omit<CalendarEvent, "calendarName">[] = [];
  for (const block of blocks) {
    const body = block.split(/END:VEVENT/i)[0] || "";
    const get = (key: string) => {
      const re = new RegExp(`^${key}(?:;[^:]*)?:(.+)$`, "im");
      const m = body.match(re);
      return m ? m[1].trim() : "";
    };
    const summary = get("SUMMARY") || "Event";
    const dtstart = get("DTSTART");
    const dtend = get("DTEND");
    const location = get("LOCATION");
    const uid = get("UID");
    const start = parseIcsDate(dtstart);
    if (!start) continue;
    out.push({
      summary: summary.replace(/\\\\/g, "\\").replace(/\\,/g, ",").replace(/\\n/g, " "),
      start: start.toISOString(),
      end: (() => {
        const e = parseIcsDate(dtend);
        return e ? e.toISOString() : null;
      })(),
      location: location.replace(/\\\\/g, "\\").replace(/\\,/g, ","),
      uid,
      allDay: /^\d{8}$/.test(dtstart),
    });
  }
  return out;
}

function parseIcsTodos(icsText: string, listName = ""): TaskItem[] {
  const text = String(icsText || "").replace(/\r\n[ \t]/g, "");
  const blocks = text.split(/BEGIN:VTODO/i).slice(1);
  const out: TaskItem[] = [];
  for (const block of blocks) {
    const body = block.split(/END:VTODO/i)[0] || "";
    const get = (key: string) => {
      const re = new RegExp(`^${key}(?:;[^:]*)?:(.+)$`, "im");
      const m = body.match(re);
      return m ? m[1].trim() : "";
    };
    const status = (get("STATUS") || "").toUpperCase();
    const completed = status === "COMPLETED" || !!get("COMPLETED");
    const summary = (get("SUMMARY") || "Task").replace(/\\\\/g, "\\").replace(/\\,/g, ",").replace(/\\n/g, " ");
    const due = parseIcsDate(get("DUE")) || parseIcsDate(get("DTSTART"));
    out.push({
      uid: get("UID"),
      summary,
      completed,
      due: due ? due.toISOString() : null,
      priority: Number(get("PRIORITY") || 0) || 0,
      listName,
      status: status || (completed ? "COMPLETED" : "NEEDS-ACTION"),
    });
  }
  return out;
}

async function listCalendars(session: ResolvedBase) {
  const body = `<?xml version="1.0" encoding="UTF-8"?>
<d:propfind xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav" xmlns:cs="http://calendarserver.org/ns/">
  <d:prop>
    <d:displayname/>
    <d:resourcetype/>
    <c:supported-calendar-component-set/>
  </d:prop>
</d:propfind>`;
  const { text } = await davRequest(session.cfg, `/remote.php/dav/calendars/${encodeURIComponent(session.userId)}/`, {
    method: "PROPFIND",
    headers: { "Content-Type": "text/xml; charset=utf-8", Depth: "1" },
    body,
    base: session.base,
  });
  const out: Array<{ path: string; name: string; hasEvents: boolean; hasTasks: boolean }> = [];
  for (const resp of localNameBlocks(text, "response")) {
    const href = textOf(resp, "href");
    if (!href) continue;
    if (!hasLocal(resp, "calendar")) continue;
    const path = href.replace(/^https?:\/\/[^/]+/i, "");
    if (/\/(inbox|outbox|trashbin|notifications)\/?$/i.test(path)) continue;
    const clean = path.startsWith("/") ? path : `/${path}`;
    const name = textOf(resp, "displayname") || clean.split("/").filter(Boolean).pop() || "Calendar";
    const comps = attrOf(resp, "comp", "name").map((v) => v.toUpperCase()).filter(Boolean);
    out.push({
      path: clean,
      name,
      hasEvents: !comps.length || comps.includes("VEVENT"),
      hasTasks: !comps.length || comps.includes("VTODO"),
    });
  }
  return out;
}

async function reportCalendarData(session: ResolvedBase, calPath: string, filterXml: string) {
  const body = `<?xml version="1.0" encoding="UTF-8"?>
<c:calendar-query xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav">
  <d:prop>
    <d:getetag/>
    <c:calendar-data/>
  </d:prop>
  <c:filter>
    <c:comp-filter name="VCALENDAR">
      ${filterXml}
    </c:comp-filter>
  </c:filter>
</c:calendar-query>`;
  const { text } = await davRequest(session.cfg, calPath, {
    method: "REPORT",
    headers: { "Content-Type": "text/xml; charset=utf-8", Depth: "1" },
    body,
    base: session.base,
  });
  return localNameBlocks(text, "calendar-data").map((n) => decodeXmlEntities(n));
}

async function fetchCalendarEvents(session: ResolvedBase, rangeStart: Date, rangeEnd: Date) {
  const calendars = (await listCalendars(session)).filter((c) => c.hasEvents);
  if (!calendars.length) return [] as CalendarEvent[];
  const filterXml = `<c:comp-filter name="VEVENT">
        <c:time-range start="${calDavTime(rangeStart)}" end="${calDavTime(rangeEnd)}"/>
      </c:comp-filter>`;
  const all: CalendarEvent[] = [];
  for (const cal of calendars.slice(0, 10)) {
    try {
      const chunks = await reportCalendarData(session, cal.path, filterXml);
      for (const ics of chunks) {
        for (const ev of parseIcsEvents(ics)) {
          all.push({ ...ev, calendarName: cal.name });
        }
      }
    } catch {
      /* skip calendar */
    }
  }
  return all
    .filter((e) => e.start)
    .sort((a, b) => Date.parse(a.start || "") - Date.parse(b.start || ""))
    .slice(0, lim(session.cfg, "calendarLimit"));
}

async function fetchTasks(session: ResolvedBase) {
  const calendars = (await listCalendars(session)).filter((c) => c.hasTasks);
  if (!calendars.length) return { tasks: [] as TaskItem[], lists: calendars };
  const filterXml = `<c:comp-filter name="VTODO"/>`;
  const all: TaskItem[] = [];
  for (const cal of calendars.slice(0, 10)) {
    try {
      const chunks = await reportCalendarData(session, cal.path, filterXml);
      for (const ics of chunks) {
        for (const t of parseIcsTodos(ics, cal.name)) {
          all.push({ ...t, calendarPath: cal.path, listName: cal.name });
        }
      }
    } catch {
      /* skip */
    }
  }
  const tasks = all
    .sort((a, b) => {
      if (a.completed !== b.completed) return a.completed ? 1 : -1;
      if (a.due && b.due) return Date.parse(a.due) - Date.parse(b.due);
      if (a.due) return -1;
      if (b.due) return 1;
      if (a.priority !== b.priority) return (a.priority || 9) - (b.priority || 9);
      return String(a.summary).localeCompare(String(b.summary));
    })
    .slice(0, lim(session.cfg, "taskLimit"));
  return { tasks, lists: calendars };
}

function isUserAddressbook(path: string) {
  const clean = String(path || "");
  if (/\/z-/i.test(clean)) return false;
  if (/\/(inbox|outbox)\/?$/i.test(clean)) return false;
  return true;
}

function parseVcardContact(vcf: string, bookName: string, href: string): ContactItem {
  const fn = cleanText((vcf.match(/^FN:(.+)$/im) || [])[1] || "Contact");
  const email = cleanText((vcf.match(/^EMAIL(?:;[^:]*)?:(.+)$/im) || [])[1] || "");
  const tel = cleanText((vcf.match(/^TEL(?:;[^:]*)?:(.+)$/im) || [])[1] || "");
  const uid = cleanText((vcf.match(/^UID:(.+)$/im) || [])[1] || "");
  return {
    id: uid || `${fn}${email}`,
    name: fn || "Contact",
    email,
    phone: tel,
    source: bookName,
    link: href,
  };
}

async function listAddressbooks(session: ResolvedBase) {
  const body = `<?xml version="1.0" encoding="UTF-8"?>
<d:propfind xmlns:d="DAV:" xmlns:card="urn:ietf:params:xml:ns:carddav">
  <d:prop>
    <d:displayname/>
    <d:resourcetype/>
  </d:prop>
</d:propfind>`;
  const { text } = await davRequest(session.cfg, `/remote.php/dav/addressbooks/users/${encodeURIComponent(session.userId)}/`, {
    method: "PROPFIND",
    headers: { "Content-Type": "text/xml; charset=utf-8", Depth: "1" },
    body,
    base: session.base,
  });
  const out: Array<{ path: string; name: string }> = [];
  for (const resp of localNameBlocks(text, "response")) {
    const href = textOf(resp, "href");
    if (!href) continue;
    if (!hasLocal(resp, "addressbook")) continue;
    const path = href.replace(/^https?:\/\/[^/]+/i, "");
    const clean = path.startsWith("/") ? path : `/${path}`;
    if (!isUserAddressbook(clean)) continue;
    const name = textOf(resp, "displayname") || clean.split("/").filter(Boolean).pop() || "Contacts";
    out.push({ path: clean, name });
  }
  return out;
}

async function listAddressbookContacts(session: ResolvedBase) {
  const books = (await listAddressbooks(session)).filter((book) => isUserAddressbook(book.path));
  const out: ContactItem[] = [];
  const seen = new Set<string>();
  const body = `<?xml version="1.0" encoding="UTF-8"?>
<card:addressbook-query xmlns:d="DAV:" xmlns:card="urn:ietf:params:xml:ns:carddav">
  <d:prop>
    <d:getetag/>
    <card:address-data>
      <card:prop name="FN"/>
      <card:prop name="EMAIL"/>
      <card:prop name="TEL"/>
      <card:prop name="UID"/>
    </card:address-data>
  </d:prop>
</card:addressbook-query>`;
  const contactsHref = `${session.base.replace(/\/$/, "")}/index.php/apps/contacts/`;
  for (const book of books.slice(0, 6)) {
    try {
      const { text } = await davRequest(session.cfg, book.path, {
        method: "REPORT",
        headers: { "Content-Type": "text/xml; charset=utf-8", Depth: "1" },
        body,
        base: session.base,
      });
      for (const node of localNameBlocks(text, "address-data")) {
        const contact = parseVcardContact(node, book.name, contactsHref);
        const key = contact.id || `${contact.name}|${contact.email}`;
        if (seen.has(key)) continue;
        seen.add(key);
        out.push(contact);
      }
    } catch {
      /* skip book */
    }
  }
  out.sort((a, b) => String(a.name).localeCompare(String(b.name), undefined, { sensitivity: "base" }));
  return out;
}

async function searchContacts(session: ResolvedBase, query: string) {
  const q = String(query || "").trim().toLowerCase();
  let rows = await listAddressbookContacts(session);
  if (q) {
    rows = rows.filter((c) => `${c.name} ${c.email} ${c.phone}`.toLowerCase().includes(q));
  }
  if (q && rows.length < lim(session.cfg, "contactsLimit")) {
    const data = await ocsOptional(
      session.cfg,
      session.base,
      `/ocs/v2.php/core/autocomplete/get?format=json&search=${encodeURIComponent(q)}&limit=${lim(session.cfg, "contactsLimit")}`,
      [],
    );
    const seen = new Set(rows.map((r) => `${r.name}|${r.email}`.toLowerCase()));
    for (const row of normalizeList(data)) {
      const name = String(row.label || row.name || row.id || "User");
      const email = String(row.email || row.shareWithDisplayNameUnique || "");
      const key = `${name}|${email}`.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      rows.push({
        id: String(row.id || row.value || key),
        name,
        email,
        phone: "",
        source: String(row.source || row.status || "user"),
        link: null,
      });
      if (rows.length >= lim(session.cfg, "contactsLimit")) break;
    }
  }
  return rows.slice(0, lim(session.cfg, "contactsLimit"));
}

function escapeIcsText(s: string) {
  return String(s || "")
    .replace(/\\/g, "\\\\")
    .replace(/;/g, "\\;")
    .replace(/,/g, "\\,")
    .replace(/\n/g, "\\n");
}

function escapeXml(s: string) {
  return String(s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function calDavStamp(d = new Date()) {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
}

function newUid() {
  return `hd-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

function slugifyCalId(name: string) {
  const base =
    String(name || "tasks")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 40) || "tasks";
  return `${base}-${Date.now().toString(36).slice(-4)}`;
}

async function createTaskList(session: ResolvedBase, displayName: string) {
  const name = String(displayName || "").trim();
  if (!name) throw new Error("List name required");
  const calId = slugifyCalId(name);
  const calPath = `/remote.php/dav/calendars/${encodeURIComponent(session.userId)}/${calId}/`;
  const body = `<?xml version="1.0" encoding="UTF-8"?>
<C:mkcalendar xmlns:D="DAV:" xmlns:C="urn:ietf:params:xml:ns:caldav">
  <D:set>
    <D:prop>
      <D:displayname>${escapeXml(name)}</D:displayname>
      <C:supported-calendar-component-set>
        <C:comp name="VTODO"/>
      </C:supported-calendar-component-set>
    </D:prop>
  </D:set>
</C:mkcalendar>`;
  try {
    await davRequest(session.cfg, calPath, {
      method: "MKCALENDAR",
      headers: { "Content-Type": "application/xml; charset=utf-8" },
      body,
      okStatuses: [201, 200, 204],
      base: session.base,
    });
  } catch {
    const mkcol = `<?xml version="1.0" encoding="UTF-8"?>
<D:mkcol xmlns:D="DAV:" xmlns:C="urn:ietf:params:xml:ns:caldav">
  <D:set>
    <D:prop>
      <D:resourcetype>
        <D:collection/>
        <C:calendar/>
      </D:resourcetype>
      <D:displayname>${escapeXml(name)}</D:displayname>
      <C:supported-calendar-component-set>
        <C:comp name="VTODO"/>
      </C:supported-calendar-component-set>
    </D:prop>
  </D:set>
</D:mkcol>`;
    await davRequest(session.cfg, calPath, {
      method: "MKCOL",
      headers: { "Content-Type": "application/xml; charset=utf-8" },
      body: mkcol,
      okStatuses: [201, 200, 204],
      base: session.base,
    });
  }
  return calPath;
}

async function createTask(session: ResolvedBase, summary: string, listPath?: string, dueKey = "") {
  const title = String(summary || "").trim();
  if (!title) throw new Error("Task title required");
  let path = listPath || "";
  if (!path) path = await createTaskList(session, "Tasks");
  const uid = newUid();
  const stamp = calDavStamp();
  let dueLine = "";
  if (dueKey && /^\d{4}-\d{2}-\d{2}$/.test(dueKey)) {
    dueLine = `DUE;VALUE=DATE:${dueKey.replace(/-/g, "")}\r\n`;
  }
  const ics = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Homedash Nextcloud Widget//EN",
    "CALSCALE:GREGORIAN",
    "BEGIN:VTODO",
    `UID:${uid}`,
    `DTSTAMP:${stamp}`,
    `CREATED:${stamp}`,
    `LAST-MODIFIED:${stamp}`,
    `SUMMARY:${escapeIcsText(title)}`,
    "STATUS:NEEDS-ACTION",
    "PERCENT-COMPLETE:0",
    dueLine.trim(),
    "END:VTODO",
    "END:VCALENDAR",
    "",
  ]
    .filter((line) => line !== "")
    .join("\r\n");

  const filePath = `${path.replace(/\/+$/, "")}/${uid}.ics`;
  await davRequest(session.cfg, filePath, {
    method: "PUT",
    headers: { "Content-Type": "text/calendar; charset=utf-8" },
    body: ics,
    okStatuses: [201, 200, 204],
    base: session.base,
  });
  return { uid, listPath: path };
}

async function createContact(
  session: ResolvedBase,
  input: { name: string; email?: string; phone?: string; bookPath?: string },
) {
  const fn = String(input.name || "").trim();
  if (!fn) throw new Error("Name is required");
  let book = String(input.bookPath || "").trim();
  if (!book) {
    const books = await listAddressbooks(session);
    book = books[0]?.path || "";
  }
  if (!book) throw new Error("No address book available");
  const uid = newUid();
  const parts = fn.split(/\s+/);
  const last = parts.length > 1 ? parts[parts.length - 1] : "";
  const first = parts.length > 1 ? parts.slice(0, -1).join(" ") : parts[0] || "";
  const lines = [
    "BEGIN:VCARD",
    "VERSION:3.0",
    `UID:${uid}`,
    `FN:${escapeIcsText(fn)}`,
    `N:${escapeIcsText(last)};${escapeIcsText(first)};;;`,
  ];
  const em = String(input.email || "").trim();
  const tel = String(input.phone || "").trim();
  if (em) lines.push(`EMAIL;TYPE=INTERNET:${escapeIcsText(em)}`);
  if (tel) lines.push(`TEL;TYPE=CELL:${escapeIcsText(tel)}`);
  lines.push("END:VCARD", "");
  const filePath = `${book.replace(/\/+$/, "")}/${uid}.vcf`;
  await davRequest(session.cfg, filePath, {
    method: "PUT",
    headers: { "Content-Type": "text/vcard; charset=utf-8" },
    body: lines.join("\r\n"),
    okStatuses: [201, 200, 204],
    base: session.base,
  });
  return uid;
}

async function restoreTrashItem(session: ResolvedBase, item: { href?: string; path?: string; trashName?: string; name?: string }) {
  const userId = encodeURIComponent(session.userId);
  const srcPath = item.href?.includes("/dav/")
    ? item.href.replace(/^https?:\/\/[^/]+/i, "")
    : `/remote.php/dav/trashbin/${userId}${item.path}`;
  const destName = encodeURIComponent(item.trashName || item.name || "restored");
  const destination = `${session.base.replace(/\/$/, "")}/remote.php/dav/trashbin/${userId}/restore/${destName}`;
  await davRequest(session.cfg, srcPath.startsWith("/") ? srcPath : `/${srcPath}`, {
    method: "MOVE",
    headers: { Destination: destination, Overwrite: "T" },
    body: null,
    okStatuses: [201, 204, 200],
    base: session.base,
  });
}

async function loadTalkRooms(session: ResolvedBase, capabilities: Record<string, unknown> | null) {
  if (!hasTalkApp(capabilities)) {
    return { rooms: [] as Array<Record<string, unknown>>, talkMissing: true, talkError: null as string | null };
  }
  try {
    const raw = await ocsOptional(
      session.cfg,
      session.base,
      "/ocs/v2.php/apps/spreed/api/v4/room?format=json&noStatusUpdate=1",
      [],
    );
    return {
      rooms: sortRooms(normalizeList(raw)).slice(0, lim(session.cfg, "talkLimit")),
      talkMissing: false,
      talkError: null,
    };
  } catch (error) {
    return {
      rooms: [] as Array<Record<string, unknown>>,
      talkMissing: false,
      talkError: error instanceof Error ? error.message : "Talk unavailable",
    };
  }
}

async function loadTalkChat(session: ResolvedBase, token: string) {
  const { data } = await ocsFetch(
    session.cfg,
    `/ocs/v2.php/apps/spreed/api/v1/chat/${encodeURIComponent(token)}?format=json&lookIntoFuture=0&limit=${lim(session.cfg, "talkChatLimit")}&setReadMarker=1`,
    { base: session.base },
  );
  return normalizeList(data)
    .filter((m) => m && m.messageType !== "comment_deleted")
    .slice()
    .sort((a, b) => Number(a.id) - Number(b.id));
}

export type NextcloudStatusOptions = {
  tab?: NcTab | string;
  filesMode?: NcFilesMode | string;
  filesPath?: string;
  talkRoom?: string;
  contactsQuery?: string;
};

export async function nextcloudStatus(instanceId: string, options: NextcloudStatusOptions = {}) {
  const tab = (String(options.tab || "overview").toLowerCase() || "overview") as NcTab;
  const session = await resolveSession(instanceId);
  const { cfg, base, userId } = session;
  const openFallbackUrl = (cfg.openFallbackUrl || cfg.fallbackUrl || "").trim();
  const connectionSource = classifyConnectionSource(cfg, base);

  const userRes = await ocsFetch(cfg, "/ocs/v2.php/cloud/user?format=json", { base });
  const user = (userRes.data || {}) as Record<string, unknown>;

  if (tab === "files") {
    const mode = (["browse", "favorites", "recent", "trash"].includes(String(options.filesMode))
      ? options.filesMode
      : "browse") as NcFilesMode;
    const path = normalizeFilesPath(options.filesPath || "/");
    let files: DavFile[] = [];
    let error: string | null = null;
    try {
      if (mode === "favorites") files = await listFavorites(session);
      else if (mode === "recent") files = await listRecent(session);
      else if (mode === "trash") files = await listTrash(session);
      else files = await listFilesBrowse(session, path);
    } catch (err) {
      error = err instanceof Error ? err.message : "Failed to list files";
    }
    return {
      href: base,
      openFallbackUrl,
      connectionSource,
      tab,
      userId,
      filesMode: mode,
      filesPath: path,
      files,
      error,
    };
  }

  if (tab === "talk") {
    const capabilities = (await ocsOptional(cfg, base, "/ocs/v2.php/cloud/capabilities?format=json", null)) as Record<
      string,
      unknown
    > | null;
    const talk = await loadTalkRooms(session, capabilities);
    let messages: Array<Record<string, unknown>> = [];
    let chatError: string | null = null;
    const talkRoom = options.talkRoom || "";
    if (talkRoom && !talk.talkMissing) {
      try {
        messages = await loadTalkChat(session, talkRoom);
      } catch (err) {
        chatError = err instanceof Error ? err.message : "Failed to load chat";
      }
    }
    return {
      href: base,
      openFallbackUrl,
      connectionSource,
      tab,
      userId,
      rooms: talk.rooms,
      talkMissing: talk.talkMissing,
      talkError: talk.talkError,
      talkRoom: talkRoom || null,
      messages,
      chatError,
    };
  }

  if (tab === "calendar") {
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth(), 1);
    start.setDate(start.getDate() - start.getDay());
    const end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    end.setDate(end.getDate() + (6 - end.getDay()));
    end.setHours(23, 59, 59, 999);
    const stripEnd = new Date(Date.now() + 21 * 86400000);
    const rangeEnd = end > stripEnd ? end : stripEnd;
    let calendar: CalendarEvent[] = [];
    let calendarError: string | null = null;
    let tasks: TaskItem[] = [];
    let taskLists: Array<{ path: string; name: string }> = [];
    let tasksError: string | null = null;
    try {
      calendar = await fetchCalendarEvents(session, start, rangeEnd);
    } catch (err) {
      calendarError = err instanceof Error ? err.message : "Calendar unavailable";
    }
    try {
      const taskData = await fetchTasks(session);
      tasks = taskData.tasks;
      taskLists = taskData.lists.map((l) => ({ path: l.path, name: l.name }));
    } catch (err) {
      tasksError = err instanceof Error ? err.message : "Tasks unavailable";
    }
    return {
      href: base,
      openFallbackUrl,
      connectionSource,
      tab,
      userId,
      calendar,
      calendarError,
      tasks,
      taskLists,
      tasksError,
    };
  }

  if (tab === "contacts") {
    const query = String(options.contactsQuery || "");
    let contacts: ContactItem[] = [];
    let error: string | null = null;
    let addressbooks: Array<{ path: string; name: string }> = [];
    try {
      addressbooks = await listAddressbooks(session);
      contacts = await searchContacts(session, query);
    } catch (err) {
      error = err instanceof Error ? err.message : "Contacts unavailable";
    }
    return {
      href: base,
      openFallbackUrl,
      connectionSource,
      tab,
      userId,
      contacts,
      addressbooks,
      contactsQuery: query,
      error,
    };
  }

  if (tab === "shares") {
    const sharesRaw = await ocsOptional(cfg, base, "/ocs/v2.php/apps/files_sharing/api/v1/shares?format=json", []);
    const shares = normalizeList(sharesRaw)
      .slice()
      .sort((a, b) => Number(b?.stime || 0) - Number(a?.stime || 0))
      .slice(0, lim(cfg, "shareLimit"));
    return { href: base, openFallbackUrl, connectionSource, tab, userId, shares };
  }

  if (tab === "activity") {
    const activityRaw = await ocsOptional(
      cfg,
      base,
      `/ocs/v2.php/apps/activity/api/v2/activity?format=json&limit=${lim(cfg, "activityLimit")}`,
      [],
    );
    return {
      href: base,
      openFallbackUrl,
      connectionSource,
      tab,
      userId,
      activity: normalizeList(activityRaw).slice(0, lim(cfg, "activityLimit")),
    };
  }

  if (tab === "alerts") {
    const notificationsRaw = await ocsOptional(
      cfg,
      base,
      "/ocs/v2.php/apps/notifications/api/v2/notifications?format=json",
      [],
    );
    return {
      href: base,
      openFallbackUrl,
      connectionSource,
      tab,
      userId,
      notifications: normalizeList(notificationsRaw).slice(0, lim(cfg, "notifyLimit")),
    };
  }

  // overview (default)
  const [server, status, capabilities, usersRaw, sharesRaw, activityRaw, notificationsRaw, roomsRaw, mountsRaw] =
    await Promise.all([
      ocsOptional(cfg, base, "/ocs/v2.php/apps/serverinfo/api/v1/info?format=json", null),
      fetchPublic(cfg, base, "/status.php").catch(() => null),
      ocsOptional(cfg, base, "/ocs/v2.php/cloud/capabilities?format=json", null),
      ocsOptional(cfg, base, "/ocs/v1.php/cloud/users?format=json", null),
      ocsOptional(cfg, base, "/ocs/v2.php/apps/files_sharing/api/v1/shares?format=json", []),
      ocsOptional(cfg, base, `/ocs/v2.php/apps/activity/api/v2/activity?format=json&limit=${lim(cfg, "activityLimit")}`, []),
      ocsOptional(cfg, base, "/ocs/v2.php/apps/notifications/api/v2/notifications?format=json", []),
      ocsOptional(cfg, base, "/ocs/v2.php/apps/spreed/api/v4/room?format=json&noStatusUpdate=1", []),
      ocsOptional(cfg, base, "/ocs/v2.php/apps/files_external/api/v1/mounts?format=json", []),
    ]);

  const usersPayload = (usersRaw as { users?: unknown } | null)?.users ?? usersRaw;
  const users = Array.isArray(usersPayload) ? usersPayload : normalizeList(usersPayload);
  const shares = normalizeList(sharesRaw)
    .slice()
    .sort((a, b) => Number(b?.stime || 0) - Number(a?.stime || 0))
    .slice(0, lim(cfg, "shareLimit"));
  const activity = normalizeList(activityRaw).slice(0, lim(cfg, "activityLimit"));
  const notifications = normalizeList(notificationsRaw).slice(0, lim(cfg, "notifyLimit"));
  const rooms = sortRooms(normalizeList(roomsRaw)).slice(0, lim(cfg, "talkLimit"));
  const mounts = normalizeList(mountsRaw);
  const caps = capabilities as Record<string, unknown> | null;
  const serverObj = server as Record<string, unknown> | null;
  const statusObj = status as Record<string, unknown> | null;
  const info = serverBits(serverObj);
  const storage = resolveStorage(user, serverObj, cfg);
  const health = healthBits(serverObj, statusObj);

  let calendar: CalendarEvent[] = [];
  let calendarError: string | null = null;
  try {
    const start = new Date();
    const end = new Date(Date.now() + 21 * 86400000);
    calendar = await fetchCalendarEvents(session, start, end);
  } catch (err) {
    calendarError = err instanceof Error ? err.message : "Calendar unavailable";
  }

  const version =
    info.version ||
    ((caps?.version as Record<string, unknown> | undefined)?.string as string | undefined) ||
    ((caps?.version as Record<string, unknown> | undefined)?.version as string | undefined) ||
    (statusObj?.versionstring as string | undefined) ||
    (statusObj?.version as string | undefined) ||
    null;

  return {
    href: base,
    openFallbackUrl,
    connectionSource,
    tab: "overview" as const,
    userId,
    user,
    server: serverObj,
    status: statusObj,
    capabilities: caps,
    storage,
    health,
    version,
    info,
    users,
    shares,
    activity,
    notifications,
    rooms,
    mounts,
    calendar: calendar.slice(0, 5),
    calendarError,
    talkMissing: !hasTalkApp(caps),
  };
}

export async function nextcloudAction(
  instanceId: string,
  op: string,
  payload: Record<string, unknown> = {},
) {
  const session = await resolveSession(instanceId);

  if (op === "talk-send") {
    const token = String(payload.token || "");
    const message = String(payload.message || "").trim();
    if (!token || !message) throw new Error("token and message required");
    await ocsFetch(session.cfg, `/ocs/v2.php/apps/spreed/api/v1/chat/${encodeURIComponent(token)}`, {
      base: session.base,
      form: { message },
    });
    const messages = await loadTalkChat(session, token);
    return { ok: true, messages };
  }

  if (op === "restore-trash") {
    await restoreTrashItem(session, {
      href: payload.href ? String(payload.href) : undefined,
      path: payload.path ? String(payload.path) : undefined,
      trashName: payload.trashName ? String(payload.trashName) : undefined,
      name: payload.name ? String(payload.name) : undefined,
    });
    return { ok: true };
  }

  if (op === "create-task") {
    const result = await createTask(
      session,
      String(payload.summary || ""),
      payload.listPath ? String(payload.listPath) : undefined,
      payload.dueKey ? String(payload.dueKey) : "",
    );
    return { ok: true, ...result };
  }

  if (op === "create-task-list") {
    const path = await createTaskList(session, String(payload.name || ""));
    return { ok: true, listPath: path };
  }

  if (op === "create-contact") {
    const uid = await createContact(session, {
      name: String(payload.name || ""),
      email: payload.email ? String(payload.email) : "",
      phone: payload.phone ? String(payload.phone) : "",
      bookPath: payload.bookPath ? String(payload.bookPath) : undefined,
    });
    return { ok: true, uid };
  }

  throw new Error(`Unknown Nextcloud action: ${op}`);
}
