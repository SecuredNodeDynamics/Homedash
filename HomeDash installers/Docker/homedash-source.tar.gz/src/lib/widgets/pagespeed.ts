import { readWidgetConfig } from "@/lib/config";

type Config = {
  defaultUrl?: string;
};

export type PsMetric = {
  key: string;
  label: string;
  displayValue: string;
  score: number | null; // 0-1, null when Lighthouse has no score for the audit
};

export type PsResult = {
  requestedUrl: string;
  finalUrl: string;
  strategy: "mobile" | "desktop";
  fetchedAt: string;
  scores: {
    performance: number | null;
    accessibility: number | null;
    bestPractices: number | null;
    seo: number | null;
  };
  metrics: PsMetric[];
  reportUrl: string;
};

const PSI_ENDPOINT = "https://www.googleapis.com/pagespeedonline/v5/runPagespeed";
const TEST_TIMEOUT_MS = 55_000;

const METRIC_DEFS: { key: string; label: string }[] = [
  { key: "first-contentful-paint", label: "First Contentful Paint" },
  { key: "largest-contentful-paint", label: "Largest Contentful Paint" },
  { key: "total-blocking-time", label: "Total Blocking Time" },
  { key: "cumulative-layout-shift", label: "Cumulative Layout Shift" },
  { key: "speed-index", label: "Speed Index" },
];

async function loadConfig(instanceId: string): Promise<Config> {
  const value = (await readWidgetConfig(instanceId)) as Partial<Config>;
  return { defaultUrl: value?.defaultUrl || "" };
}

export function normalizeUrl(input: string): string {
  const trimmed = (input || "").trim();
  if (!trimmed) throw new Error("Enter a website address to test");
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  return `https://${trimmed}`;
}

function scoreOf(categories: Record<string, { score?: number | null }> | undefined, id: string): number | null {
  const score = categories?.[id]?.score;
  return typeof score === "number" ? Math.round(score * 100) : null;
}

function reportUrlFor(url: string, strategy: "mobile" | "desktop"): string {
  return `https://pagespeed.web.dev/analysis?url=${encodeURIComponent(url)}&form_factor=${strategy}`;
}

export async function pagespeedDefaults(instanceId: string) {
  const config = await loadConfig(instanceId);
  return { defaultUrl: config.defaultUrl || "" };
}

export async function pagespeedRunTest(
  instanceId: string,
  rawUrl: string,
  strategy: "mobile" | "desktop",
): Promise<PsResult> {
  void instanceId; // no per-instance config needed — PSI is called without an API key
  const url = normalizeUrl(rawUrl);
  const mode = strategy === "desktop" ? "desktop" : "mobile";

  const params = new URLSearchParams({ url, strategy: mode });
  params.append("category", "performance");
  params.append("category", "accessibility");
  params.append("category", "best-practices");
  params.append("category", "seo");

  let response: Response;
  try {
    response = await fetch(`${PSI_ENDPOINT}?${params.toString()}`, {
      cache: "no-store",
      signal: AbortSignal.timeout(TEST_TIMEOUT_MS),
    });
  } catch (error) {
    if (error instanceof Error && error.name === "TimeoutError") {
      throw new Error("PageSpeed test timed out — the site may be slow to respond");
    }
    throw new Error("Could not reach the PageSpeed Insights API");
  }

  const json = await response.json().catch(() => null);
  if (!response.ok) {
    const message = json?.error?.message || `HTTP ${response.status}`;
    throw new Error(message);
  }

  const lighthouse = json?.lighthouseResult;
  if (!lighthouse) throw new Error("PageSpeed Insights returned no report for this URL");

  const categories = lighthouse.categories || {};
  const audits = lighthouse.audits || {};

  const metrics: PsMetric[] = METRIC_DEFS.map((def) => {
    const audit = audits[def.key];
    return {
      key: def.key,
      label: def.label,
      displayValue: audit?.displayValue || "—",
      score: typeof audit?.score === "number" ? audit.score : null,
    };
  });

  return {
    requestedUrl: url,
    finalUrl: lighthouse.finalUrl || url,
    strategy: mode,
    fetchedAt: lighthouse.fetchTime || new Date().toISOString(),
    scores: {
      performance: scoreOf(categories, "performance"),
      accessibility: scoreOf(categories, "accessibility"),
      bestPractices: scoreOf(categories, "best-practices"),
      seo: scoreOf(categories, "seo"),
    },
    metrics,
    reportUrl: reportUrlFor(url, mode),
  };
}
