import https from "node:https";
import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, hasConnectionUrl, openUrlsFromConfig, primaryConnectionUrl } from "@/lib/open-href";

export type PiholeConfig = {
  baseUrl: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  apiKey?: string;
  password?: string;
};

type Session = {
  sid: string;
  csrf: string;
  base: string;
  expiresAt: number;
};

type AuthSessionPayload = {
  valid?: boolean;
  totp?: boolean;
  sid?: string | null;
  csrf?: string;
  validity?: number;
  message?: string;
};

const sessions = new Map<string, Session>();

function apiRoot(url: string) {
  return String(url || "")
    .replace(/\/admin\/?$/i, "")
    .replace(/\/$/, "");
}

export type PiholeConnectionSource = "private" | "public" | "unknown";

function classifyConnectionSource(cfg: PiholeConfig, base: string): PiholeConnectionSource {
  const normalized = apiRoot(base);
  if (!normalized) return "unknown";
  if (cfg.baseUrl && apiRoot(cfg.baseUrl) === normalized) return "private";
  if (cfg.fallbackUrl && apiRoot(cfg.fallbackUrl) === normalized) return "public";
  return "unknown";
}

function passwordFrom(cfg: PiholeConfig) {
  // Pi-hole app passwords are sometimes copied with spaces for readability.
  return String(cfg.apiKey || cfg.password || "").replace(/\s+/g, "").trim();
}

function targets(cfg: PiholeConfig) {
  return connectionCandidates(cfg).map((url) => apiRoot(url));
}

function openSession(base: string): Session {
  return {
    sid: "",
    csrf: "",
    base,
    expiresAt: Date.now() + 5 * 60_000,
  };
}

/** Fetch JSON; allow self-signed TLS on LAN HTTPS Pi-hole installs. */
async function piholeFetch(
  url: string,
  init: RequestInit = {},
): Promise<{ ok: boolean; status: number; json: () => Promise<any>; text: () => Promise<string> }> {
  if (!url.startsWith("https:")) {
    const res = await fetch(url, { ...init, cache: "no-store", signal: AbortSignal.timeout(8000) });
    return {
      ok: res.ok,
      status: res.status,
      json: () => res.json(),
      text: () => res.text(),
    };
  }

  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const method = String(init.method || "GET").toUpperCase();
    const headers = { ...(init.headers as Record<string, string> | undefined) };
    const body = typeof init.body === "string" ? init.body : undefined;
    const req = https.request(
      {
        protocol: parsed.protocol,
        hostname: parsed.hostname,
        port: parsed.port || 443,
        path: `${parsed.pathname}${parsed.search}`,
        method,
        headers,
        rejectUnauthorized: false,
        timeout: 8000,
      },
      (res) => {
        const chunks: Buffer[] = [];
        res.on("data", (chunk) => chunks.push(Buffer.from(chunk)));
        res.on("end", () => {
          const text = Buffer.concat(chunks).toString("utf8");
          const status = res.statusCode || 0;
          resolve({
            ok: status >= 200 && status < 300,
            status,
            json: async () => (text ? JSON.parse(text) : {}),
            text: async () => text,
          });
        });
      },
    );
    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("Pi-hole request timeout"));
    });
    if (body) req.write(body);
    req.end();
  });
}

async function probeAuth(base: string): Promise<AuthSessionPayload> {
  try {
    const res = await piholeFetch(joinUrl(base, "/api/auth"), {
      method: "GET",
      headers: { Accept: "application/json" },
    });
    if (!res.ok) return {};
    const data = await res.json();
    return (data?.session || {}) as AuthSessionPayload;
  } catch {
    return {};
  }
}

async function unauthApiWorks(base: string): Promise<boolean> {
  try {
    const res = await piholeFetch(joinUrl(base, "/api/stats/summary"), {
      method: "GET",
      headers: { Accept: "application/json" },
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function auth(instanceId: string, cfg: PiholeConfig): Promise<Session> {
  const cached = sessions.get(instanceId);
  if (cached && cached.expiresAt > Date.now() + 30_000) return cached;

  const password = passwordFrom(cfg);
  let lastErr: Error | null = null;

  for (const base of targets(cfg)) {
    try {
      const probe = await probeAuth(base);
      const noPasswordRequired =
        String(probe.message || "").toLowerCase().includes("no password") ||
        (!password && probe.valid === true && !probe.sid);

      // Pi-hole with no web password: API is open. Ignore any leftover apiKey.
      if (noPasswordRequired) {
        const open = openSession(base);
        sessions.set(instanceId, open);
        return open;
      }

      if (!password) {
        if (await unauthApiWorks(base)) {
          const open = openSession(base);
          sessions.set(instanceId, open);
          return open;
        }
        throw new Error("Pi-hole requires an API password — add it in widget settings");
      }

      const res = await piholeFetch(joinUrl(base, "/api/auth"), {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ password }),
      });
      if (res.status === 429) throw new Error("Pi-hole auth rate limited");
      const data = await res.json().catch(() => ({}));
      const session = (data?.session || {}) as AuthSessionPayload;

      if (session.valid && session.sid) {
        const next: Session = {
          sid: String(session.sid),
          csrf: session.csrf || "",
          base,
          expiresAt: Date.now() + Math.max(60, Number(session.validity || 300) - 20) * 1000,
        };
        sessions.set(instanceId, next);
        return next;
      }

      // Wrong/stale password in settings, but this Pi-hole may still allow open API.
      if (await unauthApiWorks(base)) {
        const open = openSession(base);
        sessions.set(instanceId, open);
        return open;
      }

      const detail = session.message || data?.error?.message || `HTTP ${res.status}`;
      throw new Error(`Pi-hole auth failed (${detail})`);
    } catch (err) {
      lastErr = err instanceof Error ? err : new Error("Auth failed");
    }
  }

  throw lastErr || new Error("Pi-hole auth failed");
}

export async function loadPiholeConfig(instanceId: string): Promise<PiholeConfig> {
  const cfg = await readWidgetConfig(instanceId);
  if (!hasConnectionUrl(cfg)) {
    throw new Error("Configure a Private - IP or Fallback Public URL in Settings");
  }
  return { ...cfg, baseUrl: primaryConnectionUrl(cfg) } as PiholeConfig;
}

export async function piholeRequest(
  instanceId: string,
  path: string,
  options: RequestInit = {},
  retry = true,
) {
  const cfg = await loadPiholeConfig(instanceId);
  const session = await auth(instanceId, cfg);
  const method = (options.method || "GET").toUpperCase();
  const headers: Record<string, string> = {
    Accept: "application/json",
    ...(method !== "GET" ? { "Content-Type": "application/json" } : {}),
    ...(session.sid ? { "X-FTL-SID": session.sid } : {}),
    ...(session.csrf ? { "X-FTL-CSRF": session.csrf } : {}),
    ...((options.headers as Record<string, string>) || {}),
  };

  const res = await piholeFetch(joinUrl(session.base, path.startsWith("/api") ? path : `/api${path}`), {
    ...options,
    headers,
  });

  if ((res.status === 401 || res.status === 403) && retry) {
    sessions.delete(instanceId);
    return piholeRequest(instanceId, path, options, false);
  }

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(text || `HTTP ${res.status}`);
  }
  if (res.status === 204) return {};
  return res.json();
}

function num(v: unknown) {
  const n = Number(String(v ?? 0).replace(/,/g, ""));
  return Number.isFinite(n) ? n : 0;
}

function topList(obj: any, key: string, nameKeys: string[]) {
  const source =
    obj?.[key] || obj?.domains || obj?.clients || obj?.top_domains || obj?.top_clients || {};
  if (Array.isArray(source)) {
    return source.slice(0, 5).map((item: any) => ({
      name:
        nameKeys.map((k) => item?.[k]).find(Boolean) ||
        item?.name ||
        item?.domain ||
        item?.client ||
        "Unknown",
      count: num(item?.count ?? item?.queries ?? item?.blocked ?? 0),
    }));
  }
  return Object.entries(source)
    .slice(0, 5)
    .map(([name, count]) => ({ name, count: num(count) }));
}

export async function fetchPiholeStatus(instanceId: string) {
  const cfg = await loadPiholeConfig(instanceId);
  const [summary, blocking, topItems, topClients] = await Promise.all([
    piholeRequest(instanceId, "/api/stats/summary"),
    piholeRequest(instanceId, "/api/dns/blocking").catch(() => ({})),
    piholeRequest(instanceId, "/api/stats/top_domains?blocked=true&count=5").catch(() => ({})),
    piholeRequest(instanceId, "/api/stats/top_clients?count=5").catch(() => ({})),
  ]);

  const enabled =
    String((blocking as any).blocking || (summary as any).status || "")
      .toLowerCase() !== "disabled";

  const { href, openFallbackUrl } = openUrlsFromConfig(cfg);
  const session = sessions.get(instanceId);

  return {
    enabled,
    href,
    openFallbackUrl,
    queries: num(
      (summary as any).queries?.total ??
        (summary as any).dns_queries_today ??
        (summary as any).dns_queries_all_types,
    ),
    blocked: num((summary as any).queries?.blocked ?? (summary as any).ads_blocked_today),
    pctBlocked: num(
      (summary as any).queries?.percent_blocked ?? (summary as any).ads_percentage_today,
    ),
    domains: num(
      (summary as any).gravity?.domains_being_blocked ?? (summary as any).domains_being_blocked,
    ),
    clients: num(
      (summary as any).clients?.active ??
        (summary as any).clients?.total ??
        (summary as any).unique_clients ??
        (summary as any).clients_ever_seen,
    ),
    topBlocked: topList(topItems, "domains", ["domain", "name"]),
    topClients: topList(topClients, "clients", ["client", "name", "ip"]),
    connectionSource: classifyConnectionSource(cfg, session?.base || ""),
  };
}

export async function setPiholeBlocking(instanceId: string, enabled: boolean, seconds = 0) {
  const body = enabled
    ? { blocking: true }
    : { blocking: false, timer: seconds > 0 ? seconds : null };
  return piholeRequest(instanceId, "/api/dns/blocking", {
    method: "POST",
    body: JSON.stringify(body),
  });
}
