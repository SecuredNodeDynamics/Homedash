import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, hasConnectionUrl, primaryConnectionUrl } from "@/lib/open-href";

export type PlexSliderConfig = {
  baseUrl: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  apiKey: string;
};

export type PlexSliderSection = {
  key: string;
  title: string;
  type: string;
};

export type PlexSliderItem = {
  key: string;
  ratingKey: string;
  type: string;
  title: string;
  subtitle: string;
  year: string | number;
  summary: string;
  thumb: string;
  art: string;
  duration: number;
  sectionTitle: string;
  sectionType: string;
  addedAt: number;
};

type PlexMeta = {
  ratingKey?: string;
  key?: string;
  type?: string;
  title?: string;
  grandparentTitle?: string;
  parentTitle?: string;
  year?: number | string;
  summary?: string;
  thumb?: string;
  grandparentThumb?: string;
  parentThumb?: string;
  art?: string;
  grandparentArt?: string;
  duration?: number;
  addedAt?: number;
};

type PlexDirectory = {
  key?: string;
  title?: string;
  type?: string;
};

const DEFAULT_LIMIT = 18;

async function loadConfig(instanceId: string): Promise<PlexSliderConfig> {
  const value = (await readWidgetConfig(instanceId)) as Partial<PlexSliderConfig>;
  if (!hasConnectionUrl(value) || !value.apiKey?.trim()) {
    throw new Error("Configure a Private - IP or Fallback Public URL, and token in Settings");
  }
  return {
    baseUrl: primaryConnectionUrl(value).replace(/\/$/, ""),
    fallbackUrl: value.fallbackUrl?.trim().replace(/\/$/, "") || undefined,
    publicUrl: value.publicUrl?.trim() || undefined,
    apiKey: value.apiKey.trim(),
  };
}

function bases(cfg: PlexSliderConfig) {
  return connectionCandidates(cfg);
}

function tokenPath(path: string, apiKey: string) {
  const joiner = path.includes("?") ? "&" : "?";
  return `${path}${joiner}X-Plex-Token=${encodeURIComponent(apiKey)}`;
}

function asArray<T>(value: T | T[] | undefined | null): T[] {
  if (!value) return [];
  return Array.isArray(value) ? value : [value];
}

function publicHref(cfg: PlexSliderConfig, baseUrl: string) {
  const raw = (cfg.publicUrl || baseUrl).replace(/\/$/, "");
  return raw.endsWith("/web") ? raw : `${raw}/web`;
}

function openFallbackHref(cfg: PlexSliderConfig, baseUrl: string) {
  const raw = (cfg.openFallbackUrl || cfg.fallbackUrl || "").trim().replace(/\/$/, "");
  if (!raw) return "";
  return raw.endsWith("/web") ? raw : `${raw}/web`;
}

async function plexFetch<T>(
  cfg: PlexSliderConfig,
  path: string,
  init: RequestInit = {},
): Promise<{ data: T; baseUrl: string }> {
  let last: unknown;
  for (const base of bases(cfg)) {
    try {
      const response = await fetch(joinUrl(base, tokenPath(path, cfg.apiKey)), {
        ...init,
        headers: {
          Accept: "application/json",
          ...(init.headers as Record<string, string> | undefined),
        },
        cache: "no-store",
        signal: AbortSignal.timeout(12_000),
      });
      if (!response.ok) throw new Error(`Plex HTTP ${response.status}`);
      const ct = response.headers.get("content-type") || "";
      if (!ct.includes("json")) return { data: null as T, baseUrl: base };
      return { data: (await response.json()) as T, baseUrl: base };
    } catch (error) {
      last = error;
    }
  }
  throw last instanceof Error ? last : new Error("Plex unavailable");
}

function normalizeItem(item: PlexMeta = {}, section: PlexSliderSection | null = null): PlexSliderItem {
  const type = item.type || section?.type || "media";
  const title =
    type === "episode"
      ? `${item.grandparentTitle || "Unknown"} · ${item.title || ""}`.replace(/\s+·\s*$/, "")
      : item.title || "Untitled";
  const subtitle =
    type === "episode"
      ? [item.parentTitle, item.year].filter(Boolean).join(" · ")
      : [section?.title || type, item.year].filter(Boolean).join(" · ");
  const thumb =
    type === "episode"
      ? item.grandparentThumb || item.parentThumb || item.thumb || ""
      : type === "season"
        ? item.parentThumb || item.grandparentThumb || item.thumb || ""
        : item.thumb || item.grandparentThumb || item.parentThumb || "";

  return {
    key: String(item.ratingKey || item.key || title),
    ratingKey: String(item.ratingKey || ""),
    type,
    title,
    subtitle,
    year: item.year || "",
    summary: item.summary || "",
    thumb,
    art: item.art || item.grandparentArt || "",
    duration: Number(item.duration || 0),
    sectionTitle: section?.title || "",
    sectionType: section?.type || "",
    addedAt: Number(item.addedAt || 0),
  };
}

async function fetchSectionItems(
  cfg: PlexSliderConfig,
  section: PlexSliderSection,
  limit: number,
): Promise<{ items: PlexSliderItem[]; baseUrl: string }> {
  const path =
    section.type === "show"
      ? `/library/sections/${encodeURIComponent(section.key)}/all?type=2&sort=addedAt:desc&X-Plex-Container-Start=0&X-Plex-Container-Size=${limit}`
      : `/library/sections/${encodeURIComponent(section.key)}/recentlyAdded?X-Plex-Container-Start=0&X-Plex-Container-Size=${limit}`;

  const { data, baseUrl } = await plexFetch<{
    MediaContainer?: { Metadata?: PlexMeta[] | PlexMeta };
  }>(cfg, path);

  const meta = asArray(data?.MediaContainer?.Metadata).filter(Boolean);
  return {
    items: meta.map((item) => normalizeItem(item, section)),
    baseUrl,
  };
}

export async function plexSliderSections(instanceId: string) {
  const cfg = await loadConfig(instanceId);
  const { data, baseUrl } = await plexFetch<{
    MediaContainer?: { Directory?: PlexDirectory[] | PlexDirectory };
  }>(cfg, "/library/sections");

  const dirs = asArray(data?.MediaContainer?.Directory).filter(Boolean);
  const sections: PlexSliderSection[] = dirs
    .map((section) => ({
      key: String(section.key || ""),
      title: section.title || "Library",
      type: section.type || "",
    }))
    .filter((section) => section.key);

  return {
    sections,
    baseUrl,
    publicUrl: publicHref(cfg, baseUrl),
    href: publicHref(cfg, baseUrl),
    openFallbackUrl: openFallbackHref(cfg, baseUrl),
  };
}

export async function plexSliderItems(
  instanceId: string,
  opts: { sectionKey?: string; limit?: number } = {},
) {
  const cfg = await loadConfig(instanceId);
  const limit = Math.min(60, Math.max(1, Number(opts.limit) || DEFAULT_LIMIT));
  const sectionKey = (opts.sectionKey || "").trim();

  const { data, baseUrl: sectionsBase } = await plexFetch<{
    MediaContainer?: { Directory?: PlexDirectory[] | PlexDirectory };
  }>(cfg, "/library/sections");

  const dirs = asArray(data?.MediaContainer?.Directory).filter(Boolean);
  const sections: PlexSliderSection[] = dirs
    .map((section) => ({
      key: String(section.key || ""),
      title: section.title || "Library",
      type: section.type || "",
    }))
    .filter((section) => section.key);

  if (!sectionKey || sectionKey === "__all__") {
    const pairs = await Promise.all(
      sections.map(async (section) => {
        try {
          return await fetchSectionItems(cfg, section, limit);
        } catch {
          return { items: [] as PlexSliderItem[], baseUrl: sectionsBase };
        }
      }),
    );
    const seen = new Set<string>();
    const items = pairs
      .flatMap((pair) => pair.items)
      .sort((a, b) => Number(b.addedAt || 0) - Number(a.addedAt || 0))
      .filter((item) => {
        const key = item.ratingKey || item.key;
        if (!key || seen.has(key)) return false;
        seen.add(key);
        return true;
      })
      .slice(0, limit);

    const baseUrl = pairs.find((pair) => pair.baseUrl)?.baseUrl || sectionsBase;
    return {
      items,
      baseUrl,
      publicUrl: publicHref(cfg, baseUrl),
      openFallbackUrl: openFallbackHref(cfg, baseUrl),
      section: { key: "__all__", title: "Recent", type: "mixed" } satisfies PlexSliderSection,
    };
  }

  const section = sections.find((entry) => entry.key === sectionKey);
  if (!section) throw new Error("Unknown Plex library section");

  const { items, baseUrl } = await fetchSectionItems(cfg, section, limit);
  return {
    items,
    baseUrl,
    publicUrl: publicHref(cfg, baseUrl),
    openFallbackUrl: openFallbackHref(cfg, baseUrl),
    section,
  };
}

export async function plexSliderSearch(instanceId: string, query: string) {
  const cfg = await loadConfig(instanceId);
  const q = query.trim();
  if (!q) {
    return {
      items: [] as PlexSliderItem[],
      baseUrl: cfg.baseUrl,
      publicUrl: publicHref(cfg, cfg.baseUrl),
      openFallbackUrl: openFallbackHref(cfg, cfg.baseUrl),
    };
  }

  const { data, baseUrl } = await plexFetch<{
    MediaContainer?: {
      Hub?: Array<{ title?: string; Metadata?: PlexMeta[] | PlexMeta }> | { title?: string; Metadata?: PlexMeta[] | PlexMeta };
    };
  }>(cfg, `/hubs/search?query=${encodeURIComponent(q)}&limit=40`);

  const hubs = asArray(data?.MediaContainer?.Hub).filter(Boolean);
  const items: PlexSliderItem[] = [];
  for (const hub of hubs) {
    const meta = asArray(hub.Metadata).filter(Boolean);
    for (const item of meta) {
      items.push(
        normalizeItem(item, {
          key: "",
          title: hub.title || "",
          type: item.type || "",
        }),
      );
    }
  }

  const seen = new Set<string>();
  const deduped = items.filter((item) => {
    const key = item.ratingKey || item.key;
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  return {
    items: deduped,
    baseUrl,
    publicUrl: publicHref(cfg, baseUrl),
    openFallbackUrl: openFallbackHref(cfg, baseUrl),
  };
}

export async function plexSliderImage(
  instanceId: string,
  urlPath: string,
  w = 320,
  h = 480,
  direct = false,
) {
  if (!urlPath) throw new Error("Missing image path");
  const cfg = await loadConfig(instanceId);
  const path = urlPath.startsWith("/") ? urlPath : `/${urlPath}`;
  let last: unknown;

  for (const base of bases(cfg)) {
    try {
      if (!direct) {
        const tokenized = tokenPath(path, cfg.apiKey);
        const transcode = `/photo/:/transcode?width=${Math.max(1, w)}&height=${Math.max(1, h)}&minSize=1&upscale=1&url=${encodeURIComponent(tokenized)}&X-Plex-Token=${encodeURIComponent(cfg.apiKey)}`;
        const res = await fetch(joinUrl(base, transcode), {
          headers: { Accept: "image/*" },
          cache: "no-store",
          signal: AbortSignal.timeout(12_000),
        });
        if (res.ok) return res;
      }

      const fallback = await fetch(joinUrl(base, tokenPath(path, cfg.apiKey)), {
        headers: { Accept: "image/*" },
        cache: "no-store",
        signal: AbortSignal.timeout(12_000),
      });
      if (fallback.ok) return fallback;
      throw new Error(`Plex image HTTP ${fallback.status}`);
    } catch (error) {
      last = error;
    }
  }

  throw last instanceof Error ? last : new Error("Plex image unavailable");
}

export function plexDetailsHref(publicUrl: string, baseUrl: string, ratingKey: string) {
  if (!ratingKey) return publicUrl || baseUrl || "#";
  const href = (publicUrl || baseUrl).replace(/\/$/, "");
  const web = href.endsWith("/web") ? href : `${href}/web`;
  return `${web}#!/server/${encodeURIComponent(baseUrl)}/details?key=${encodeURIComponent(`/library/metadata/${ratingKey}`)}`;
}
