import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, hasConnectionUrl, openUrlsFromConfig, primaryConnectionUrl } from "@/lib/open-href";

type Config = {
  baseUrl: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  apiKey: string;
};

type PlexMeta = {
  title?: string;
  grandparentTitle?: string;
  parentTitle?: string;
  year?: number | string;
  type?: string;
  ratingKey?: string;
  viewOffset?: number;
  duration?: number;
  thumb?: string;
  grandparentThumb?: string;
  parentThumb?: string;
  art?: string;
  User?: { title?: string; username?: string };
  Player?: { title?: string; product?: string; platform?: string; state?: string };
  Session?: { id?: string };
  TranscodeSession?: unknown;
};

type PlexDirectory = {
  key?: string;
  title?: string;
  type?: string;
  count?: number | string;
};

async function loadConfig(instanceId: string): Promise<Config> {
  const value = (await readWidgetConfig(instanceId)) as Partial<Config>;
  if (!hasConnectionUrl(value) || !value.apiKey) {
    throw new Error("Configure a Private - IP or Fallback Public URL, and token in Settings");
  }
  return { ...value, baseUrl: primaryConnectionUrl(value) } as Config;
}

function bases(cfg: Config) {
  return connectionCandidates(cfg).map((u) => u.replace(/\/$/, ""));
}

function tokenPath(path: string, apiKey: string) {
  const joiner = path.includes("?") ? "&" : "?";
  return `${path}${joiner}X-Plex-Token=${encodeURIComponent(apiKey)}`;
}

async function plexFetch<T>(
  cfg: Config,
  path: string,
  init: RequestInit = {},
): Promise<{ data: T; baseUrl: string }> {
  let last: unknown;
  for (const base of bases(cfg)) {
    try {
      const response = await fetch(joinUrl(base, tokenPath(path, cfg.apiKey)), {
        ...init,
        headers: {
          Accept: "application/json",
          ...(init.headers as Record<string, string> | undefined),
        },
        cache: "no-store",
        signal: AbortSignal.timeout(12_000),
      });
      if (!response.ok) throw new Error(`Plex HTTP ${response.status}`);
      if (response.status === 204 || response.headers.get("content-length") === "0") {
        return { data: null as T, baseUrl: base };
      }
      const ct = response.headers.get("content-type") || "";
      if (!ct.includes("json")) return { data: null as T, baseUrl: base };
      return { data: (await response.json()) as T, baseUrl: base };
    } catch (error) {
      last = error;
    }
  }
  throw last instanceof Error ? last : new Error("Plex unavailable");
}

function artPath(item: PlexMeta) {
  return item.thumb || item.grandparentThumb || item.parentThumb || item.art || "";
}

function normalizeSession(item: PlexMeta, instanceId: string) {
  const session = item.Session || {};
  const user = item.User || {};
  const player = item.Player || {};
  const title =
    item.type === "episode"
      ? `${item.grandparentTitle || "Unknown"} · ${item.title || ""}`.replace(/\s+·\s*$/, "")
      : item.title || "Unknown";
  const subtitle =
    item.type === "episode"
      ? [item.parentTitle, item.year].filter(Boolean).join(" · ")
      : [item.type, item.year].filter(Boolean).join(" · ");
  const path = artPath(item);
  const viewOffset = Number(item.viewOffset || 0);
  const duration = Number(item.duration || 0);

  return {
    id: String(session.id || item.ratingKey || title),
    sessionId: String(session.id || ""),
    title,
    subtitle,
    parent: item.grandparentTitle || "",
    type: item.type || "media",
    user: user.title || user.username || "Unknown user",
    player: player.title || player.product || player.platform || "Unknown player",
    state: String(player.state || "").toLowerCase(),
    viewOffset,
    duration,
    progress: duration > 0 ? Math.min(100, Math.max(0, Math.round((viewOffset / duration) * 100))) : 0,
    transcode: !!item.TranscodeSession,
    artPath: path,
    artUrl: path
      ? `/api/widgets/plex/art?instance=${encodeURIComponent(instanceId)}&path=${encodeURIComponent(path)}`
      : "",
  };
}

export async function plexStatus(instanceId: string) {
  const cfg = await loadConfig(instanceId);

  const [identityRes, sessionsRes, sectionsRes] = await Promise.all([
    plexFetch<{ MediaContainer?: { friendlyName?: string; machineIdentifier?: string } }>(cfg, "/").catch(
      () => ({ data: null as { MediaContainer?: { friendlyName?: string; machineIdentifier?: string } } | null, baseUrl: cfg.baseUrl }),
    ),
    plexFetch<{ MediaContainer?: { Metadata?: PlexMeta[] | PlexMeta } }>(cfg, "/status/sessions"),
    plexFetch<{ MediaContainer?: { Directory?: PlexDirectory[] | PlexDirectory } }>(cfg, "/library/sections"),
  ]);

  const baseUrl = sessionsRes.baseUrl || sectionsRes.baseUrl || cfg.baseUrl;
  const mc = identityRes.data?.MediaContainer || {};
  const serverName = mc.friendlyName || mc.machineIdentifier || "Plex";

  const rawSessions = sessionsRes.data?.MediaContainer?.Metadata;
  const sessionList = (Array.isArray(rawSessions) ? rawSessions : rawSessions ? [rawSessions] : []).filter(Boolean);
  const sessions = sessionList.map((item) => normalizeSession(item, instanceId));

  const rawDirs = sectionsRes.data?.MediaContainer?.Directory;
  const dirs = (Array.isArray(rawDirs) ? rawDirs : rawDirs ? [rawDirs] : []).filter(Boolean);

  const libraries = await Promise.all(
    dirs.map(async (section) => {
      const key = String(section.key || "");
      let count = Number(section.count || 0);
      if (key) {
        try {
          const detail = await plexFetch<{
            MediaContainer?: { totalSize?: number; size?: number };
          }>(cfg, `/library/sections/${encodeURIComponent(key)}/all?X-Plex-Container-Start=0&X-Plex-Container-Size=0`);
          count = Number(
            detail.data?.MediaContainer?.totalSize ?? detail.data?.MediaContainer?.size ?? count,
          );
        } catch {
          /* keep section.count */
        }
      }
      return {
        key,
        title: section.title || "Library",
        type: section.type || "",
        count,
      };
    }),
  );

  const totalItems = libraries.reduce((sum, lib) => sum + Number(lib.count || 0), 0);
  const webify = (url: string) => {
    const trimmed = url.replace(/\/$/, "");
    return trimmed.endsWith("/web") ? trimmed : `${trimmed}/web`;
  };
  const { href: primaryHref, openFallbackUrl: fallbackHref } = openUrlsFromConfig(cfg);
  const href = webify(primaryHref || baseUrl);
  const openFallbackUrl = fallbackHref ? webify(fallbackHref) : "";

  return {
    href,
    openFallbackUrl,
    baseUrl,
    serverName,
    streams: sessions.length,
    totalItems,
    sessions,
    libraries,
  };
}

export async function plexRefresh(instanceId: string, sectionKey?: string) {
  const cfg = await loadConfig(instanceId);

  if (sectionKey) {
    await plexFetch(cfg, `/library/sections/${encodeURIComponent(sectionKey)}/refresh`, { method: "GET" });
    return { ok: true, sectionKey };
  }

  const sections = await plexFetch<{ MediaContainer?: { Directory?: PlexDirectory[] | PlexDirectory } }>(
    cfg,
    "/library/sections",
  );
  const rawDirs = sections.data?.MediaContainer?.Directory;
  const dirs = (Array.isArray(rawDirs) ? rawDirs : rawDirs ? [rawDirs] : []).filter(Boolean);
  const keys = dirs.map((d) => String(d.key || "")).filter(Boolean);

  const results = await Promise.allSettled(
    keys.map((key) =>
      plexFetch(cfg, `/library/sections/${encodeURIComponent(key)}/refresh`, { method: "GET" }),
    ),
  );
  const ok = results.filter((r) => r.status === "fulfilled").length;
  return { ok: ok === results.length, refreshed: ok, total: results.length };
}

export async function plexArt(instanceId: string, path: string) {
  if (!path) throw new Error("Missing art path");
  if (/^https?:\/\//i.test(path)) {
    const res = await fetch(path, {
      headers: { Accept: "image/*" },
      cache: "no-store",
      signal: AbortSignal.timeout(12_000),
    });
    if (!res.ok) throw new Error(`Plex art HTTP ${res.status}`);
    return res;
  }

  const cfg = await loadConfig(instanceId);
  const normalized = path.startsWith("/") ? path : `/${path}`;
  let last: unknown;
  for (const base of bases(cfg)) {
    try {
      const res = await fetch(joinUrl(base, tokenPath(normalized, cfg.apiKey)), {
        headers: { Accept: "image/*" },
        cache: "no-store",
        signal: AbortSignal.timeout(12_000),
      });
      if (!res.ok) throw new Error(`Plex art HTTP ${res.status}`);
      return res;
    } catch (error) {
      last = error;
    }
  }
  throw last instanceof Error ? last : new Error("Plex art unavailable");
}
