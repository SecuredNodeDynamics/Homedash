import { readSettings, readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { hasConnectionUrl, openUrlsFromConfig, primaryConnectionUrl } from "@/lib/open-href";
import { cryptoStatus } from "@/lib/widgets/invest-crypto";
import { stocksStatus } from "@/lib/widgets/invest-stocks";
import type { AppSettings } from "@/lib/types";

type Config = Record<string, string>;
const timeout = (url: string, init: RequestInit = {}) => fetch(url, { ...init, cache: "no-store", signal: AbortSignal.timeout(10_000) });
const json = async <T>(url: string, init?: RequestInit) => {
  const response = await timeout(url, init);
  if (!response.ok) throw new Error(`Request failed (${response.status})`);
  return response.json() as Promise<T>;
};
const parse = <T>(value: string | undefined, fallback: T): T => {
  try { return value ? JSON.parse(value) as T : fallback; } catch { return fallback; }
};

export async function portedWidgetStatus(
  id: string,
  instanceId: string,
  settingsOverride?: AppSettings,
) {
  const config = await readWidgetConfig(instanceId) as Config;
  if (["bazarr", "lidarr", "tracearr", "dispatcharr"].includes(id)) {
    if (!hasConnectionUrl(config)) {
      throw new Error("Configure a Private - IP or Fallback Public URL in Settings");
    }
    const baseUrl = primaryConnectionUrl(config);
    const openUrls = openUrlsFromConfig(config);
    const headers: HeadersInit = config.apiKey ? { Authorization: `Bearer ${config.apiKey}`, "X-Api-Key": config.apiKey } : {};
    const request = <T>(path: string, init: RequestInit = {}) => json<T>(joinUrl(baseUrl, path), { ...init, headers: { ...headers, ...init.headers } });
    const list = (value: unknown) => Array.isArray(value) ? value : Array.isArray((value as { data?: unknown[] })?.data) ? (value as { data: unknown[] }).data : Array.isArray((value as { results?: unknown[] })?.results) ? (value as { results: unknown[] }).results : [];
    if (id === "bazarr") {
      const [movies, series, wantedMovies, wantedEpisodes] = await Promise.all([
        request<{ total?: number }>("/api/movies?start=0&length=1"), request<{ total?: number }>("/api/series?start=0&length=1"),
        request<unknown>("/api/movies/wanted?start=0&length=5").catch(() => []), request<unknown>("/api/episodes/wanted?start=0&length=5").catch(() => []),
      ]);
      return { ...openUrls, stats: [["Movies", movies.total || 0], ["Series", series.total || 0], ["Movies Wanted", list(wantedMovies).length], ["Episodes Wanted", list(wantedEpisodes).length]], items: [...list(wantedMovies), ...list(wantedEpisodes)].slice(0, 6) };
    }
    if (id === "lidarr") {
      const [artists, queue, calendar] = await Promise.all([request<unknown>("/api/v1/artist"), request<unknown>("/api/v1/queue?pageSize=5"), request<unknown>("/api/v1/calendar?unmonitored=true").catch(() => [])]);
      const artistList = list(artists) as Array<{ statistics?: { albumCount?: number; totalTrackCount?: number } }>;
      return { ...openUrls, stats: [["Artists", artistList.length], ["Albums", artistList.reduce((n, artist) => n + (artist.statistics?.albumCount || 0), 0)], ["Tracks", artistList.reduce((n, artist) => n + (artist.statistics?.totalTrackCount || 0), 0)], ["Queue", list(queue).length]], items: list(calendar).slice(0, 6) };
    }
    if (id === "tracearr") {
      const trHeaders: HeadersInit = config.apiKey ? { Authorization: `Bearer ${config.apiKey}` } : {};
      const [stats, today, streams] = await Promise.all(["/api/v1/public/stats", "/api/v1/public/stats/today", "/api/v1/public/streams"].map((path) => json<Record<string, unknown>>(joinUrl(baseUrl, path), { headers: trHeaders }).catch((): Record<string, unknown> => ({}))));
      return { ...openUrls, stats: [["Plays Today", Number(today["plays"] || today["todayPlays"] || 0)], ["Active Streams", Number(today["activeStreams"] || stats["activeStreams"] || 0)], ["Users", Number(stats["users"] || stats["totalUsers"] || 0)], ["Streams", list(streams).length]], items: list(streams).slice(0, 6) };
    }
    if (id === "dispatcharr") {
      const data = await request<Record<string, unknown>>("/api/channels/recordings/");
      const entries = list(data).length
        ? list(data)
        : Object.values(data).filter((value) => typeof value === "object").flatMap(list);
      return {
        ...openUrls,
        stats: Object.entries(data)
          .filter(([, value]) => typeof value === "number")
          .slice(0, 4)
          .map(([key, value]) => [key, value]),
        items: entries.slice(0, 8),
      };
    }
  }
  if (id === "youtube") {
    const channels = (config.channels || "").split(",").map((id) => id.trim()).filter(Boolean);
    if (!channels.length) throw new Error("Configure comma-separated YouTube channel IDs in Settings");
    const results = await Promise.all(channels.map(async (channelId) => {
      const feed = await json<{ items?: Array<{ title?: string; link?: string; thumbnail?: string; pubDate?: string }> }>(`https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(`https://www.youtube.com/feeds/videos.xml?channel_id=${channelId}`)}`);
      return (feed.items || []).slice(0, 4);
    }));
    return { videos: results.flat().sort((a, b) => Date.parse(b.pubDate || "") - Date.parse(a.pubDate || "")) };
  }
  if (id === "downtify") {
    const { downtifyStatus } = await import("@/lib/widgets/downtify");
    return downtifyStatus(instanceId);
  }
  if (id === "navidrome") {
    const { navidromeStatus } = await import("@/lib/widgets/navidrome");
    return navidromeStatus(instanceId);
  }
  if (id === "bookmarks") {
    const settings = settingsOverride || await readSettings();
    const catalog = Array.isArray(settings.bookmarks) ? settings.bookmarks : [];
    const groupId = String(config.groupId || "").trim();
    if (catalog.length) {
      const matchedGroup = groupId
        ? settings.bookmarkGroups?.find((group) => group.id === groupId)
        : undefined;
      const bookmarks = matchedGroup
        ? catalog.filter((item) => (item.groupId || "") === groupId)
        : catalog;
      const groupName =
        matchedGroup?.name || "All bookmarks";
      return { bookmarks, groupId: matchedGroup?.id || null, groupName };
    }
    if (settingsOverride) {
      return { bookmarks: [], groupId: null, groupName: "All bookmarks" };
    }
    // Legacy fallback: Groups JSON in widget config
    const legacy = parse<Array<{ label: string; links: Array<{ name: string; href: string; icon?: string }> }>>(
      config.groups,
      [],
    );
    const flattened = legacy.flatMap((group) =>
      (group.links || []).map((link, index) => ({
        id: `legacy-${group.label}-${index}`,
        name: link.name,
        icon: link.icon,
        publicUrl: link.href,
        category: group.label,
        groupId: undefined as string | undefined,
      })),
    );
    return {
      bookmarks: groupId
        ? flattened.filter((item) => (item.category || "") === groupId)
        : flattened,
      groupId: groupId || null,
      groupName: groupId || "All bookmarks",
    };
  }
  if (id === "net-topology") {
    return { subnet: config.subnet || "", hosts: parse(config.hosts, []) };
  }
  if (id === "invest-crypto") {
    return cryptoStatus(instanceId);
  }
  if (id === "invest-stocks") {
    return stocksStatus(instanceId);
  }
  if (id === "invest-news") {
    const feeds = parse<Array<{ label: string; url: string; category?: string }>>(config.feeds, [
      { label: "Yahoo Finance", url: "https://finance.yahoo.com/news/rssindex", category: "markets" },
      { label: "CoinDesk", url: "https://www.coindesk.com/arc/outboundfeeds/rss/", category: "crypto" },
    ]);
    const results = await Promise.allSettled(feeds.map(async (feed) => {
      const data = await json<{
        items?: Array<{
          title?: string;
          link?: string;
          pubDate?: string;
          thumbnail?: string;
          description?: string;
          content?: string;
          author?: string;
          categories?: string[];
          enclosure?: { link?: string };
        }>;
      }>(
        `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(feed.url)}`,
      );
      return (data.items || []).slice(0, 12).map((item) => ({
        ...item,
        thumbnail: item.thumbnail || item.enclosure?.link || "",
        description: (item.description || "")
          .replace(/<[^>]*>/g, " ")
          .replace(/&amp;/g, "&")
          .replace(/&quot;/g, "\"")
          .replace(/&#39;/g, "'")
          .replace(/\s+/g, " ")
          .trim(),
        content: (item.content || item.description || "")
          .replace(/<[^>]*>/g, " ")
          .replace(/&amp;/g, "&")
          .replace(/&quot;/g, "\"")
          .replace(/&#39;/g, "'")
          .replace(/\s+/g, " ")
          .trim()
          .slice(0, 6000),
        source: feed.label,
        category: feed.category || "markets",
      }));
    }));
    return { items: results.flatMap((result) => result.status === "fulfilled" ? result.value : []).sort((a, b) => Date.parse(b.pubDate || "") - Date.parse(a.pubDate || "")) };
  }
  if (id === "nextcloud") {
    const { nextcloudStatus } = await import("@/lib/widgets/nextcloud");
    return nextcloudStatus(instanceId);
  }
  throw new Error("Unsupported widget");
}
