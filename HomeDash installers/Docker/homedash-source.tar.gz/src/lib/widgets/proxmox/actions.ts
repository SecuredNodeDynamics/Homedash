import { loadProxmoxConfig } from "./config";
import { prxFetch } from "./proxmenux";
import { clearLynisReportStore } from "./lynis-store";

export async function proxmenuxProxy(
  instanceId: string,
  path: string,
  init?: { method?: string; body?: unknown },
) {
  const cfg = await loadProxmoxConfig(instanceId);
  return prxFetch(cfg, path, {
    method: init?.method || "GET",
    body: init?.body != null ? JSON.stringify(init.body) : undefined,
  });
}

export async function runLynisScan(instanceId: string) {
  return proxmenuxProxy(instanceId, "/api/security/lynis/run", { method: "POST", body: {} });
}

export async function deleteLynisReport(instanceId: string) {
  const result = await proxmenuxProxy(instanceId, "/api/security/lynis/report", { method: "DELETE" });
  // An intentional delete must also drop the saved copy, or it would reappear.
  await clearLynisReportStore(instanceId);
  return result;
}

export async function fetchDiskSmart(instanceId: string, disk: string) {
  return proxmenuxProxy(instanceId, `/api/storage/smart/${encodeURIComponent(disk)}`);
}

export async function runDiskSmartTest(instanceId: string, disk: string, testType: "short" | "long") {
  return proxmenuxProxy(instanceId, `/api/storage/smart/${encodeURIComponent(disk)}/test`, {
    method: "POST",
    body: { test_type: testType },
  });
}

export async function fetchDiskTempHistory(instanceId: string, disk: string, timeframe = "hour") {
  return proxmenuxProxy(
    instanceId,
    `/api/disk/${encodeURIComponent(disk)}/temperature/history?timeframe=${encodeURIComponent(timeframe)}`,
  );
}
