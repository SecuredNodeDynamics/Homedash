import { request as httpsRequest } from "node:https";
import { request as httpRequest } from "node:http";
import { joinUrl } from "@/lib/proxy";
import { loadProxmoxConfig, pveTargets, type ProxmoxConfig } from "./config";

type PveEnvelope<T> = { data: T };

type MinimalResponse = { ok: boolean; status: number; json: () => Promise<unknown> };

// Proxmox's default web UI certificate is self-signed, which Node's global
// fetch rejects by default — every private-URL attempt would otherwise fail
// with a TLS error and silently fall through to the public fallback.
// Rather than pull in an external TLS-agent package, do a minimal raw
// request via Node's built-in http/https modules for just the private/LAN
// target, with certificate verification disabled only for that connection.
// The public fallback always goes through normal fetch with full cert
// validation — nothing about its security is changed.
function insecurePveFetch(
  url: string,
  init: { method?: string; headers?: Record<string, string>; body?: BodyInit | null; signal?: AbortSignal },
): Promise<MinimalResponse> {
  return new Promise((resolve, reject) => {
    const target = new URL(url);
    const doRequest = target.protocol === "https:" ? httpsRequest : httpRequest;
    const options: Record<string, unknown> = {
      hostname: target.hostname,
      port: target.port || (target.protocol === "https:" ? 443 : 80),
      path: `${target.pathname}${target.search}`,
      method: init.method || "GET",
      headers: init.headers,
    };
    // Only meaningful for the https branch; irrelevant (and not a valid
    // option) for plain http, so only set it there.
    if (target.protocol === "https:") options.rejectUnauthorized = false;
    const req = doRequest(options as never, (res) => {
      const chunks: Buffer[] = [];
      res.on("data", (chunk) => chunks.push(chunk as Buffer));
      res.on("end", () => {
        const status = res.statusCode ?? 0;
        const bodyText = Buffer.concat(chunks).toString("utf8");
        resolve({
          ok: status >= 200 && status < 300,
          status,
          json: async () => (bodyText ? JSON.parse(bodyText) : null),
        });
      });
    });
    req.on("error", reject);
    if (init.signal) {
      if (init.signal.aborted) req.destroy(new Error("Aborted"));
      else init.signal.addEventListener("abort", () => req.destroy(new Error("Aborted")), { once: true });
    }
    if (init.body != null) req.write(init.body as string);
    req.end();
  });
}

export async function pveRequest<T>(
  cfg: ProxmoxConfig,
  path: string,
  init: RequestInit = {},
): Promise<{ data: T; base: string }> {
  let lastError: Error | undefined;
  const targets = pveTargets(cfg);
  // Raw value only — cfg.pveUrl has already been through primaryConnectionUrl()
  // and can equal the public fallback URL when no private URL is configured,
  // which would wrongly route the public connection through the
  // cert-validation-disabled insecure path meant only for the LAN target.
  const privateBase = cfg.pvePrivateUrl;
  for (const [index, base] of targets.entries()) {
    try {
      const url = joinUrl(base, `/api2/json${path}`);
      const headers = {
        Accept: "application/json",
        Authorization: `PVEAPIToken=${cfg.tokenId}=${cfg.tokenSecret}`,
        ...(init.headers as Record<string, string> | undefined),
      };
      // Private PVE endpoints should answer almost immediately. Fail over
      // quickly when a LAN host is unavailable, while giving a remote
      // fallback a little more room for tunnel latency.
      const signal =
        init.signal || AbortSignal.timeout(index === 0 && targets.length > 1 ? 4_000 : 7_000);

      const response =
        base === privateBase
          ? await insecurePveFetch(url, {
              method: init.method,
              headers,
              body: init.body,
              signal,
            })
          : await fetch(url, { ...init, headers, cache: "no-store", signal });
      if (!response.ok) throw new Error(`Proxmox HTTP ${response.status}`);
      if (response.status === 204) return { data: null as T, base };
      const body = (await response.json()) as PveEnvelope<T>;
      return { data: body.data, base };
    } catch (cause) {
      lastError = cause instanceof Error ? cause : new Error("Proxmox request failed");
    }
  }
  throw lastError || new Error("Could not reach Proxmox");
}

export async function pvePost<T>(cfg: ProxmoxConfig, path: string, body?: BodyInit | null) {
  return pveRequest<T>(cfg, path, {
    method: "POST",
    body: body ?? null,
    headers: body ? { "Content-Type": "application/x-www-form-urlencoded" } : undefined,
    signal: AbortSignal.timeout(20_000),
  });
}

export async function resolveNodeName(cfg: ProxmoxConfig): Promise<{ node: string; base: string; online: boolean }> {
  if (cfg.pveNode) {
    try {
      const { base } = await pveRequest(cfg, `/nodes/${encodeURIComponent(cfg.pveNode)}/status`);
      return { node: cfg.pveNode, base, online: true };
    } catch {
      // fall through to node list
    }
  }
  const { data: nodes, base } = await pveRequest<Array<{ node: string; status: string }>>(cfg, "/nodes");
  const match =
    (cfg.pveNode ? nodes.find((n) => n.node === cfg.pveNode) : undefined) ||
    nodes.find((n) => n.status === "online") ||
    nodes[0];
  if (!match?.node) throw new Error("No Proxmox node found");
  return { node: match.node, base, online: match.status === "online" };
}

export async function withProxmoxConfig<T>(instanceId: string, fn: (cfg: ProxmoxConfig) => Promise<T>) {
  return fn(await loadProxmoxConfig(instanceId));
}
