import { readWidgetConfig } from "@/lib/config";
import { hasConnectionUrl, primaryConnectionUrl } from "@/lib/open-href";
import { candidates } from "./format";

export type ProxmoxConfig = {
  pveUrl: string;
  /**
   * Raw "Private - IP" URL exactly as entered in Settings, kept separate
   * from `pveUrl` (which primaryConnectionUrl() may resolve to the public
   * fallback for display/"open" purposes). Data-fetch ordering must always
   * use this raw value so LAN is tried first regardless of that resolution.
   */
  pvePrivateUrl?: string;
  fallbackUrl?: string;
  openFallbackUrl?: string;
  tokenId: string;
  tokenSecret: string;
  pveNode?: string;
  glancesUrl?: string;
  glancesFallbackUrl?: string;
  prxUrl?: string;
  prxFallbackUrl?: string;
  prxOpenFallbackUrl?: string;
  prxToken?: string;
  iface?: string;
  cpuSensor?: string;
  backupMount?: string;
  color?: string;
};

export async function loadProxmoxConfig(instanceId: string): Promise<ProxmoxConfig> {
  const cfg = (await readWidgetConfig(instanceId)) as Partial<ProxmoxConfig>;
  if (!hasConnectionUrl(cfg, "pveUrl", "fallbackUrl") || !cfg.tokenId || !cfg.tokenSecret) {
    throw new Error(
      "Configure a Private - IP or Fallback Public URL, and API token in Settings",
    );
  }
  return {
    pveUrl: primaryConnectionUrl(cfg, "pveUrl", "fallbackUrl"),
    pvePrivateUrl: cfg.pveUrl,
    fallbackUrl: cfg.fallbackUrl,
    openFallbackUrl: cfg.openFallbackUrl,
    tokenId: cfg.tokenId,
    tokenSecret: cfg.tokenSecret,
    pveNode: cfg.pveNode,
    glancesUrl: cfg.glancesUrl,
    glancesFallbackUrl: cfg.glancesFallbackUrl,
    prxUrl: cfg.prxUrl,
    prxFallbackUrl: cfg.prxFallbackUrl,
    prxOpenFallbackUrl: cfg.prxOpenFallbackUrl,
    prxToken: cfg.prxToken,
    iface: cfg.iface || "vmbr0",
    cpuSensor: cfg.cpuSensor || "Package id 0",
    backupMount: cfg.backupMount,
    color: cfg.color || "#6ee7b7",
  };
}

export function pveTargets(cfg: ProxmoxConfig) {
  // Always try the LAN/private URL first for actual API calls. cfg.pveUrl
  // may have been resolved to the public fallback for "open in browser"
  // purposes elsewhere, so we deliberately use the raw private field here.
  return candidates(cfg.pvePrivateUrl || cfg.pveUrl, cfg.fallbackUrl);
}

export function glancesTargets(cfg: ProxmoxConfig) {
  return candidates(cfg.glancesUrl, cfg.glancesFallbackUrl);
}

export function prxTargets(cfg: ProxmoxConfig) {
  return candidates(cfg.prxUrl, cfg.prxFallbackUrl);
}
