export function fmtBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB", "PB"];
  const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  const value = bytes / 1024 ** index;
  return `${value.toFixed(index > 1 ? 1 : 0)} ${units[index]}`;
}

export function fmtBps(bytesPerSec: number): string {
  if (!Number.isFinite(bytesPerSec) || bytesPerSec <= 0) return "0 B/s";
  return `${fmtBytes(bytesPerSec)}/s`;
}

export function fmtUptime(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds <= 0) return "—";
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  if (d > 0) return `${d}d ${h}h`;
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m`;
}

export function fmtUptimeFull(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds <= 0) return "—";
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (d > 0) return `${d}d ${h}h ${m}m`;
  if (h > 0) return `${h}h ${m}m ${s}s`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

export function pctColor(pct: number): string {
  if (pct >= 90) return "#f87171";
  if (pct >= 75) return "#fbbf24";
  if (pct >= 50) return "#60a5fa";
  return "#6ee7b7";
}

export function tempColor(deg: number): string {
  if (deg >= 85) return "#f87171";
  if (deg >= 70) return "#fbbf24";
  return "#6ee7b7";
}

export function loadColor(load1: number, cpuCount: number): string {
  const ratio = cpuCount > 0 ? load1 / cpuCount : load1;
  if (ratio >= 1.5) return "#f87171";
  if (ratio >= 1) return "#fbbf24";
  return "#6ee7b7";
}

export function iowaitColor(pct: number): string {
  if (pct >= 20) return "#f87171";
  if (pct >= 10) return "#fbbf24";
  return "#6ee7b7";
}

export function percent(used: number, total: number): number {
  return total > 0 ? Math.round((used / total) * 100) : 0;
}

export function candidates(...urls: Array<string | undefined | null>): string[] {
  return [...new Set(urls.filter(Boolean).map((url) => String(url).replace(/\/+$/, "")))];
}
