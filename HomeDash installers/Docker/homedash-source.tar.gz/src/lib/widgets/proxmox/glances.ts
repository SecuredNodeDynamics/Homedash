import { joinUrl } from "@/lib/proxy";
import { glancesTargets, type ProxmoxConfig } from "./config";

export type GlancesBundle = {
  cpu: Record<string, number> | null;
  mem: Record<string, number> | null;
  network: Array<Record<string, unknown>> | null;
  processlist: Array<Record<string, unknown>> | null;
  sensors: Array<Record<string, unknown>> | null;
  fs: Array<Record<string, unknown>> | null;
  load: Record<string, number> | null;
  swap: Record<string, number> | null;
  quicklook: Record<string, number> | null;
};

async function glancesGet<T>(urls: string[], path: string): Promise<T | null> {
  for (const [index, base] of urls.entries()) {
    try {
      const response = await fetch(joinUrl(base, path), {
        headers: { Accept: "application/json" },
        cache: "no-store",
        signal: AbortSignal.timeout(index === 0 && urls.length > 1 ? 2_000 : 4_000),
      });
      if (!response.ok) continue;
      return (await response.json()) as T;
    } catch {
      // try next
    }
  }
  return null;
}

export async function fetchGlancesBundle(cfg: ProxmoxConfig): Promise<GlancesBundle | null> {
  const urls = glancesTargets(cfg);
  if (!urls.length) return null;

  const [cpu, mem, network, processlist, sensors, fs, load, swap, quicklook] = await Promise.all([
    glancesGet<Record<string, number>>(urls, "/api/4/cpu"),
    glancesGet<Record<string, number>>(urls, "/api/4/mem"),
    glancesGet<Array<Record<string, unknown>>>(urls, "/api/4/network"),
    glancesGet<Array<Record<string, unknown>>>(urls, "/api/4/processlist"),
    glancesGet<Array<Record<string, unknown>>>(urls, "/api/4/sensors"),
    glancesGet<Array<Record<string, unknown>>>(urls, "/api/4/fs"),
    glancesGet<Record<string, number>>(urls, "/api/4/load"),
    glancesGet<Record<string, number>>(urls, "/api/4/mem/swap"),
    glancesGet<Record<string, number>>(urls, "/api/4/quicklook"),
  ]);

  if (!cpu && !mem && !network) return null;
  return { cpu, mem, network, processlist, sensors, fs, load, swap, quicklook };
}
