import { pvePost, pveRequest, resolveNodeName } from "./client";
import { loadProxmoxConfig } from "./config";
import { prxFetch } from "./proxmenux";

export type GuestAction =
  | "start"
  | "shutdown"
  | "reboot"
  | "stop"
  | "backup"
  | "delete-backup"
  | "create-backup-job"
  | "update-backup-job"
  | "delete-backup-job";

function guestKind(type: string) {
  return type === "lxc" || type === "ct" ? "lxc" : "qemu";
}

export async function fetchGuestDetails(instanceId: string, type: string, vmid: number) {
  const cfg = await loadProxmoxConfig(instanceId);
  const { node } = await resolveNodeName(cfg);
  const kind = guestKind(type);
  const base = `/nodes/${encodeURIComponent(node)}/${kind}/${vmid}`;

  const [status, config, firewallOptions, firewallRules, storage] = await Promise.all([
    pveRequest<Record<string, unknown>>(cfg, `${base}/status/current`),
    pveRequest<Record<string, unknown>>(cfg, `${base}/config`),
    pveRequest<Record<string, unknown>>(cfg, `${base}/firewall/options`).catch(() => ({ data: {}, base: "" })),
    pveRequest<Array<Record<string, unknown>>>(cfg, `${base}/firewall/rules`).catch(() => ({ data: [], base: "" })),
    pveRequest<Array<Record<string, unknown>>>(cfg, `/nodes/${encodeURIComponent(node)}/storage`).catch(() => ({
      data: [],
      base: "",
    })),
  ]);

  const backups: Array<Record<string, unknown>> = [];
  for (const store of storage.data || []) {
    if (!store?.storage) continue;
    const content = String(store.content || "");
    if (content && !content.includes("backup")) continue;
    try {
      const result = await pveRequest<Array<Record<string, unknown>>>(
        cfg,
        `/nodes/${encodeURIComponent(node)}/storage/${encodeURIComponent(String(store.storage))}/content?content=backup&vmid=${vmid}`,
      );
      for (const item of result.data || []) {
        backups.push({ ...item, storage: store.storage });
      }
    } catch {
      // skip stores that reject backup listing
    }
  }

  let updateCheck: unknown = null;
  try {
    const vms = await prxFetch(cfg, "/api/vms");
    const list = Array.isArray(vms)
      ? vms
      : ((vms as { vms?: unknown[] })?.vms || []) as Array<Record<string, unknown>>;
    const match = list.find((item) => Number(item.vmid) === vmid);
    updateCheck = match?.update_check || null;
  } catch {
    updateCheck = null;
  }

  return {
    node,
    type: kind,
    vmid,
    status: status.data,
    config: config.data,
    firewall: { options: firewallOptions.data, rules: firewallRules.data || [] },
    backups: backups.sort((a, b) => Number(b.ctime || 0) - Number(a.ctime || 0)),
    updateCheck,
  };
}

export async function runGuestAction(
  instanceId: string,
  type: string,
  vmid: number,
  action: GuestAction,
  params?: Record<string, unknown>,
) {
  const cfg = await loadProxmoxConfig(instanceId);
  const { node } = await resolveNodeName(cfg);
  const kind = guestKind(type);

  if (action === "backup") {
    const storage = String(params?.storage || "local");
    await pvePost(
      cfg,
      `/nodes/${encodeURIComponent(node)}/vzdump`,
      `vmid=${vmid}&storage=${encodeURIComponent(storage)}&mode=snapshot&remove=0`,
    );
    return { ok: true, action, vmid, type: kind, node };
  }

  if (action === "delete-backup") {
    const volid = String(params?.volid || "");
    if (!volid) throw new Error("volid required for delete-backup");
    const storage = volid.split(":")[0];
    await pveRequest(
      cfg,
      `/nodes/${encodeURIComponent(node)}/storage/${encodeURIComponent(storage)}/content/${encodeURIComponent(volid)}`,
      { method: "DELETE" },
    );
    return { ok: true, action, volid, node };
  }

  if (action === "create-backup-job" || action === "update-backup-job") {
    const id = params?.id ? String(params.id) : undefined;
    const path = action === "create-backup-job" ? "/cluster/backup" : `/cluster/backup/${id}`;
    const method = action === "create-backup-job" ? "POST" : "PUT";

    // Proxmox expects form-urlencoded for these
    const searchParams = new URLSearchParams();
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (key === "instance" || key === "action" || (key === "id" && action === "update-backup-job")) return;
        searchParams.append(key, String(value));
      });
    }

    await pveRequest(cfg, path, {
      method,
      body: searchParams.toString(),
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
    });
    return { ok: true, action, id };
  }

  if (action === "delete-backup-job") {
    const id = String(params?.id || "");
    if (!id) throw new Error("id required for delete-backup-job");
    await pveRequest(cfg, `/cluster/backup/${id}`, { method: "DELETE" });
    return { ok: true, action, id };
  }

  if (!["start", "shutdown", "reboot", "stop"].includes(action)) {
    throw new Error("Unsupported guest action");
  }
  await pvePost(cfg, `/nodes/${encodeURIComponent(node)}/${kind}/${vmid}/status/${action}`);
  return { ok: true, action, vmid, type: kind, node };
}

export async function fetchGuestRrd(instanceId: string, type: string, vmid: number, timeframe = "hour") {
  const cfg = await loadProxmoxConfig(instanceId);
  const { node } = await resolveNodeName(cfg);
  const kind = guestKind(type);
  const { data } = await pveRequest<Array<Record<string, unknown>>>(
    cfg,
    `/nodes/${encodeURIComponent(node)}/${kind}/${vmid}/rrddata?timeframe=${encodeURIComponent(timeframe)}&cf=AVERAGE`,
  );
  return { node, type: kind, vmid, timeframe, points: data || [] };
}
