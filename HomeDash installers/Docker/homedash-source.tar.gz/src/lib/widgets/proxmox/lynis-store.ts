import { promises as fs } from "node:fs";
import path from "node:path";

/**
 * Server-side copy of the last good Lynis audit so the Security tab keeps
 * showing it after a page refresh, a Homedash restart or a host reboot —
 * even when ProxMenux is slow, down, or briefly returns an empty report.
 */
type Stored = { savedAt: number; tools: unknown; report: unknown };

function dataDir() {
  return process.env.HOMEDASH_DATA_DIR || path.join(process.cwd(), "data");
}

function fileFor(instanceId: string) {
  const safe = String(instanceId || "proxmox-nodes").replace(/[^a-zA-Z0-9_-]/g, "_");
  return path.join(dataDir(), `proxmox-lynis-${safe}.json`);
}

/** ProxMenux answers either `{ success, report: {...} }` or the bare report. */
export function unwrapLynisReport(raw: unknown): Record<string, unknown> | null {
  if (!raw || typeof raw !== "object") return null;
  const wrap = raw as Record<string, unknown>;
  const inner = "report" in wrap ? wrap.report : wrap;
  return inner && typeof inner === "object" ? (inner as Record<string, unknown>) : null;
}

function firstNum(r: Record<string, unknown>, keys: string[]): number | null {
  for (const k of keys) {
    const v = r[k];
    if (v != null && v !== "" && Number.isFinite(Number(v))) return Number(v);
  }
  return null;
}

/** Report holds any audit content at all (may still be a half-written partial). */
export function isUsableLynisReport(raw: unknown): boolean {
  const r = unwrapLynisReport(raw);
  if (!r) return false;
  const arr = (v: unknown) => (Array.isArray(v) ? v.length : 0);
  return (
    isCompleteLynisReport(raw) ||
    arr(r.sections) > 0 ||
    arr(r.warnings) > 0 ||
    arr(r.suggestions) > 0
  );
}

/**
 * A FINISHED audit: Lynis reports a hardening index or a tests count only at the
 * end of a run. Partial reports (scan still running) lack both — those must never
 * replace the saved copy.
 */
export function isCompleteLynisReport(raw: unknown): boolean {
  const r = unwrapLynisReport(raw);
  if (!r) return false;
  const idx = firstNum(r, ["hardening_index", "hardening", "lynis_hardening_index"]);
  const tests = firstNum(r, ["tests_performed", "tests_executed", "lynis_tests_done", "tests_done", "total_tests"]);
  return idx != null || (tests != null && tests > 0);
}

export function lynisToolsInstalled(tools: unknown): boolean {
  const t = tools as { tools?: { lynis?: { installed?: boolean } }; lynis?: { installed?: boolean } } | null;
  return Boolean(t?.tools?.lynis?.installed ?? t?.lynis?.installed);
}

/** Stable identity of a finished audit — avoids rewriting the file every poll for volatile fields. */
function reportFingerprint(raw: unknown): string {
  const r = unwrapLynisReport(raw);
  if (!r) return "";
  const len = (v: unknown) => (Array.isArray(v) ? v.length : 0);
  return [r.datetime_start, r.hardening_index, r.proxmox_adjusted_score, r.tests_performed, len(r.warnings), len(r.suggestions), len(r.sections)].join("|");
}

function toolsFingerprint(raw: unknown): string {
  const t = raw as { tools?: { lynis?: Record<string, unknown> }; lynis?: Record<string, unknown> } | null | undefined;
  const l = t?.tools?.lynis || t?.lynis;
  return l ? [l.installed, l.last_scan, l.hardening_index].join("|") : "";
}

export async function loadLynisStore(instanceId: string): Promise<Stored | null> {
  try {
    const parsed = JSON.parse(await fs.readFile(fileFor(instanceId), "utf8")) as Stored;
    return parsed && typeof parsed === "object" ? parsed : null;
  } catch {
    return null;
  }
}

export async function saveLynisStore(
  instanceId: string,
  patch: { tools?: unknown; report?: unknown },
): Promise<void> {
  try {
    const prev = (await loadLynisStore(instanceId)) || { savedAt: 0, tools: null, report: null };
    const next: Stored = {
      savedAt: Date.now(),
      tools: patch.tools !== undefined ? patch.tools : prev.tools,
      report: patch.report !== undefined ? patch.report : prev.report,
    };
    await fs.mkdir(dataDir(), { recursive: true });
    const file = fileFor(instanceId);
    const tmp = `${file}.tmp`;
    await fs.writeFile(tmp, JSON.stringify(next), "utf8");
    await fs.rename(tmp, file);
  } catch {
    /* read-only data dir — the browser copy still covers refreshes */
  }
}

export async function clearLynisReportStore(instanceId: string): Promise<void> {
  const prev = await loadLynisStore(instanceId);
  if (prev) await saveLynisStore(instanceId, { report: null });
}

/**
 * Pick what the tab should show: live data when it is real, otherwise the
 * saved copy (flagged stale so the UI can say so). Saves fresh good data.
 */
export async function resolveLynisSecurity(
  instanceId: string,
  live: { tools: unknown; report: unknown },
): Promise<{ tools: unknown; report: unknown; savedAt?: number; stale?: boolean }> {
  const saved = await loadLynisStore(instanceId);
  const liveComplete = isCompleteLynisReport(live.report);
  const liveToolsOk = lynisToolsInstalled(live.tools);

  const patch: { tools?: unknown; report?: unknown } = {};
  if (liveToolsOk) patch.tools = live.tools;
  if (liveComplete) patch.report = live.report;
  if (patch.tools !== undefined || patch.report !== undefined) {
    // Only write when something actually changed, to avoid a disk write per poll.
    const changed =
      (patch.report !== undefined && reportFingerprint(patch.report) !== reportFingerprint(saved?.report)) ||
      (patch.tools !== undefined && toolsFingerprint(patch.tools) !== toolsFingerprint(saved?.tools));
    if (changed) await saveLynisStore(instanceId, patch);
  }

  const tools = liveToolsOk ? live.tools : saved?.tools && lynisToolsInstalled(saved.tools) ? saved.tools : live.tools;
  if (liveComplete) return { tools, report: live.report };
  if (saved?.report && isCompleteLynisReport(saved.report)) {
    return { tools, report: saved.report, savedAt: saved.savedAt, stale: true };
  }
  // Nothing finished on record: show whatever partial data exists (UI labels it as incomplete).
  if (isUsableLynisReport(live.report)) return { tools, report: live.report };
  return { tools, report: null };
}
