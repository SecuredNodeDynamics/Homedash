/**
 * Dependency-free PDF writer + Lynis security audit report layout.
 * Produces a real, multi-page A4 PDF (standard Helvetica fonts) for ONE Proxmox node
 * and triggers a browser download. No external libraries, no pop-ups, no window.print().
 */

export type PdfTone = "good" | "warn" | "bad" | "muted";

export type PdfFinding = {
  testId: string;
  description: string;
  context?: string;
  solution?: string;
  expected: boolean;
};

export type PdfReportData = {
  node: string;
  hostname: string;
  os: string;
  kernel: string;
  lynisVersion: string;
  scanTime: string;
  generatedAt: Date;
  score: number | null;
  rawScore: number | null;
  tone: PdfTone;
  toneLabel: string;
  warnings: PdfFinding[];
  suggestions: PdfFinding[];
  testsRun: string;
  sections: { name: string; checks: string[] }[];
  firewallActive: boolean;
  malwareScanner: boolean;
  savedCopy: boolean;
  partial: boolean;
};

/* ───────────────────────── fonts / encoding ───────────────────────── */

// Helvetica advance widths for ASCII 32..126 (per 1000 em).
const W_REG = [
  278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556,
  556, 556, 278, 278, 584, 584, 584, 556, 1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778,
  667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556, 333, 556, 556, 500, 556, 556, 278, 556,
  556, 222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584,
];
const W_BOLD = [
  278, 333, 474, 556, 556, 889, 722, 238, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556,
  556, 556, 333, 333, 584, 584, 584, 611, 975, 722, 722, 722, 722, 667, 611, 778, 722, 278, 556, 722, 611, 833, 722, 778,
  667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 333, 278, 333, 584, 556, 333, 556, 611, 556, 611, 556, 333, 611,
  611, 278, 278, 556, 278, 889, 611, 611, 611, 611, 389, 556, 333, 611, 556, 778, 556, 556, 500, 389, 280, 389, 584,
];

// Unicode → WinAnsi byte for the few non-ASCII characters we expect. width = [regular, bold].
const SPECIAL: Record<string, [number, number, number]> = {
  "\u2014": [0x97, 1000, 1000], // em dash
  "\u2013": [0x96, 556, 556], // en dash
  "\u2018": [0x91, 222, 278],
  "\u2019": [0x92, 222, 278],
  "\u201c": [0x93, 333, 500],
  "\u201d": [0x94, 333, 500],
  "\u2022": [0x95, 350, 350], // bullet
  "\u00b7": [0xb7, 278, 278], // middle dot
  "\u2026": [0x85, 1000, 1000], // ellipsis
  "\u00d7": [0xd7, 584, 584], // ×
  "\u2192": [0x2d, 584, 584], // → drawn as "-"
};

// eslint-disable-next-line no-control-regex
const ANSI_RE = /(?:\u001b)?\[[0-9;]*[A-Za-z]/g;

function clean(input: unknown): string {
  return String(input ?? "")
    .replace(ANSI_RE, "")
    .replace(/\r/g, "")
    .replace(/\t/g, "  ");
}

function byteFor(ch: string): number {
  const code = ch.charCodeAt(0);
  if (code >= 32 && code <= 126) return code;
  const sp = SPECIAL[ch];
  if (sp) return sp[0];
  return 0x3f; // "?"
}

function charWidth(ch: string, bold: boolean): number {
  const code = ch.charCodeAt(0);
  if (code >= 32 && code <= 126) return (bold ? W_BOLD : W_REG)[code - 32];
  const sp = SPECIAL[ch];
  if (sp) return bold ? sp[2] : sp[1];
  return bold ? W_BOLD["?".charCodeAt(0) - 32] : W_REG["?".charCodeAt(0) - 32];
}

function textWidth(s: string, size: number, bold: boolean): number {
  let w = 0;
  for (const ch of s) w += charWidth(ch, bold);
  return (w * size) / 1000;
}

function pdfString(s: string): string {
  let out = "(";
  for (const ch of s) {
    const b = byteFor(ch);
    if (b === 0x28 || b === 0x29 || b === 0x5c) out += "\\" + String.fromCharCode(b);
    else if (b >= 32 && b <= 126) out += String.fromCharCode(b);
    else out += "\\" + b.toString(8).padStart(3, "0");
  }
  return out + ")";
}

/* ───────────────────────── low level page builder ───────────────────────── */

const PAGE_W = 595.28;
const PAGE_H = 841.89;
const MARGIN = 40;
const CONTENT_W = PAGE_W - MARGIN * 2;
const FOOTER_H = 34;
const BOTTOM = PAGE_H - FOOTER_H;

function rgb(hex: string): string {
  const n = parseInt(hex.replace("#", ""), 16);
  const f = (v: number) => (v / 255).toFixed(3);
  return `${f((n >> 16) & 255)} ${f((n >> 8) & 255)} ${f(n & 255)}`;
}
const num = (n: number) => (Math.round(n * 100) / 100).toString();

const C = {
  ink: "#0f172a",
  body: "#334155",
  muted: "#64748b",
  faint: "#94a3b8",
  rule: "#e2e8f0",
  card: "#f1f5f9",
  navy: "#0b1220",
  navy2: "#1e293b",
  cyan: "#22d3ee",
  cyanDark: "#0891b2",
  good: "#16a34a",
  warn: "#d97706",
  bad: "#dc2626",
  neutral: "#64748b",
};
const TONE_HEX: Record<PdfTone, string> = { good: C.good, warn: C.warn, bad: C.bad, muted: C.neutral };

class Pages {
  pages: string[] = [];
  private cur: string[] = [];
  y = 0;

  constructor() {
    this.newPage(true);
  }

  newPage(first = false) {
    if (!first) this.pages.push(this.cur.join("\n"));
    this.cur = [];
    this.y = MARGIN;
  }

  finish(): string[] {
    this.pages.push(this.cur.join("\n"));
    return this.pages;
  }

  ensure(h: number) {
    if (this.y + h > BOTTOM) this.newPage();
  }

  raw(op: string) {
    this.cur.push(op);
  }

  text(s: string, x: number, baseline: number, size: number, bold: boolean, color: string) {
    this.raw(`BT /${bold ? "F2" : "F1"} ${num(size)} Tf ${rgb(color)} rg ${num(x)} ${num(PAGE_H - baseline)} Td ${pdfString(s)} Tj ET`);
  }

  rect(x: number, y: number, w: number, h: number, fill: string) {
    this.raw(`${rgb(fill)} rg ${num(x)} ${num(PAGE_H - y - h)} ${num(w)} ${num(h)} re f`);
  }

  rrect(x: number, y: number, w: number, h: number, r: number, fill: string, stroke?: string) {
    const k = 0.5523 * r;
    const x0 = x, x1 = x + w, yt = PAGE_H - y, yb = PAGE_H - y - h;
    const p = [
      `${num(x0 + r)} ${num(yt)} m`,
      `${num(x1 - r)} ${num(yt)} l`,
      `${num(x1 - r + k)} ${num(yt)} ${num(x1)} ${num(yt - r + k)} ${num(x1)} ${num(yt - r)} c`,
      `${num(x1)} ${num(yb + r)} l`,
      `${num(x1)} ${num(yb + r - k)} ${num(x1 - r + k)} ${num(yb)} ${num(x1 - r)} ${num(yb)} c`,
      `${num(x0 + r)} ${num(yb)} l`,
      `${num(x0 + r - k)} ${num(yb)} ${num(x0)} ${num(yb + r - k)} ${num(x0)} ${num(yb + r)} c`,
      `${num(x0)} ${num(yt - r)} l`,
      `${num(x0)} ${num(yt - r + k)} ${num(x0 + r - k)} ${num(yt)} ${num(x0 + r)} ${num(yt)} c h`,
    ].join(" ");
    if (stroke) this.raw(`${rgb(fill)} rg ${rgb(stroke)} RG 0.8 w ${p} B`);
    else this.raw(`${rgb(fill)} rg ${p} f`);
  }

  line(x1: number, y1: number, x2: number, y2: number, color: string, width = 0.8) {
    this.raw(`${rgb(color)} RG ${num(width)} w ${num(x1)} ${num(PAGE_H - y1)} m ${num(x2)} ${num(PAGE_H - y2)} l S`);
  }

  /** Arc from 12 o'clock clockwise by `frac` of a full turn (0..1). */
  arc(cx: number, cy: number, r: number, frac: number, color: string, width: number) {
    const f = Math.max(0, Math.min(1, frac));
    if (f <= 0) return;
    const steps = Math.max(2, Math.ceil(f * 120));
    const pts: string[] = [];
    for (let i = 0; i <= steps; i++) {
      const a = (f * 2 * Math.PI * i) / steps;
      const px = cx + r * Math.sin(a);
      const py = PAGE_H - (cy - r * Math.cos(a));
      pts.push(`${num(px)} ${num(py)} ${i === 0 ? "m" : "l"}`);
    }
    this.raw(`${rgb(color)} RG ${num(width)} w 1 J 1 j ${pts.join(" ")} S 0 J 0 j`);
  }
}

function wrap(s: string, size: number, bold: boolean, maxW: number): string[] {
  const out: string[] = [];
  for (const para of clean(s).split("\n")) {
    const words = para.split(/\s+/).filter(Boolean);
    if (!words.length) {
      out.push("");
      continue;
    }
    let line = "";
    for (let word of words) {
      // hard-break words that are wider than the line
      while (textWidth(word, size, bold) > maxW) {
        let cut = word.length;
        while (cut > 1 && textWidth(word.slice(0, cut), size, bold) > maxW) cut--;
        if (line) {
          out.push(line);
          line = "";
        }
        out.push(word.slice(0, cut));
        word = word.slice(cut);
      }
      const trial = line ? `${line} ${word}` : word;
      if (textWidth(trial, size, bold) <= maxW) line = trial;
      else {
        out.push(line);
        line = word;
      }
    }
    if (line) out.push(line);
  }
  return out;
}

/* ───────────────────────── report layout ───────────────────────── */

function trunc(s: string, size: number, bold: boolean, maxW: number): string {
  if (textWidth(s, size, bold) <= maxW) return s;
  let t = s;
  while (t.length > 1 && textWidth(`${t}…`, size, bold) > maxW) t = t.slice(0, -1);
  return `${t}…`;
}

function fmtGenerated(d: Date): string {
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

export function buildSecurityPdf(d: PdfReportData): Uint8Array {
  const node = clean(d.node) || clean(d.hostname) || "Proxmox node";
  const toneHex = TONE_HEX[d.tone];

  const doc = new Pages();

  /* ---- header band (first page) ---- */
  doc.rect(0, 0, PAGE_W, 128, C.navy);
  doc.rect(0, 128, PAGE_W, 3, C.cyan);
  doc.text("SECURITY AUDIT REPORT", MARGIN, 44, 8.5, true, C.cyan);
  doc.text(trunc(node, 26, true, CONTENT_W - 120), MARGIN, 76, 26, true, "#ffffff");
  doc.text("Lynis hardening audit via ProxMenux", MARGIN, 96, 9.5, false, "#94a3b8");
  doc.text(`Scanned ${clean(d.scanTime)}  ·  Report generated ${fmtGenerated(d.generatedAt)}`, MARGIN, 111, 8.5, false, "#64748b");

  // score ring
  const rcx = PAGE_W - MARGIN - 38;
  const rcy = 64;
  doc.arc(rcx, rcy, 32, 1, C.navy2, 8);
  if (d.score != null) doc.arc(rcx, rcy, 32, d.score / 100, toneHex, 8);
  const scoreStr = d.score != null ? String(d.score) : "—";
  const sw = textWidth(scoreStr, 24, true);
  doc.text(scoreStr, rcx - sw / 2, rcy + 4, 24, true, d.score != null ? toneHex : "#94a3b8");
  const sub = "/100";
  doc.text(sub, rcx - textWidth(sub, 8, false) / 2, rcy + 17, 8, false, "#94a3b8");

  doc.y = 152;

  /* ---- verdict line ---- */
  const verdict =
    d.score != null
      ? `${d.toneLabel} — security hardening score ${d.score}/100`
      : d.partial
        ? "Score pending — the audit report is incomplete"
        : "No score reported for this audit";
  doc.rect(MARGIN, doc.y, 4, 30, toneHex);
  doc.text(verdict, MARGIN + 14, doc.y + 13, 12.5, true, C.ink);
  const rawNote =
    d.score != null && d.rawScore != null && d.rawScore !== d.score
      ? `Proxmox-adjusted score. Lynis raw hardening index: ${d.rawScore}. Scale: Critical 0–49, Moderate 50–69, Good 70–100.`
      : "Scale: Critical 0–49, Moderate 50–69, Good 70–100.";
  doc.text(rawNote, MARGIN + 14, doc.y + 25, 8, false, C.muted);
  doc.y += 44;

  if (d.savedCopy || d.partial) {
    const msg = d.partial
      ? "Incomplete report: the audit was probably still running when this PDF was created. The score and final results may be missing."
      : "This PDF was created from the last saved report — ProxMenux did not return a fresh one.";
    const lines = wrap(msg, 8.5, false, CONTENT_W - 24);
    const h = lines.length * 11 + 14;
    doc.rrect(MARGIN, doc.y, CONTENT_W, h, 5, "#fffbeb", "#fcd34d");
    lines.forEach((ln, i) => doc.text(ln, MARGIN + 12, doc.y + 15 + i * 11, 8.5, false, "#92400e"));
    doc.y += h + 12;
  }

  /* ---- stat cards ---- */
  const warnAct = d.warnings.filter((w) => !w.expected).length;
  const sugAct = d.suggestions.filter((w) => !w.expected).length;
  const expW = d.warnings.length - warnAct;
  const expS = d.suggestions.length - sugAct;
  const cards: { label: string; value: string; sub: string; color: string }[] = [
    { label: "ACTIONABLE WARNINGS", value: String(warnAct), sub: `${d.warnings.length} total${expW ? ` · ${expW} PVE expected` : ""}`, color: warnAct ? C.bad : C.good },
    { label: "ACTIONABLE SUGGESTIONS", value: String(sugAct), sub: `${d.suggestions.length} total${expS ? ` · ${expS} PVE expected` : ""}`, color: sugAct ? C.warn : C.good },
    { label: "TESTS RUN", value: d.testsRun, sub: `${d.sections.length} ${d.sections.length === 1 ? "section" : "sections"}`, color: C.ink },
    { label: "FIREWALL", value: d.firewallActive ? "Active" : "Inactive", sub: d.malwareScanner ? "Malware scanner present" : "No malware scanner", color: d.firewallActive ? C.good : C.bad },
  ];
  const gap = 8;
  const cw = (CONTENT_W - gap * 3) / 4;
  cards.forEach((c, i) => {
    const x = MARGIN + i * (cw + gap);
    doc.rrect(x, doc.y, cw, 64, 6, C.card);
    doc.text(trunc(c.label, 6.5, true, cw - 16), x + 10, doc.y + 15, 6.5, true, C.muted);
    doc.text(trunc(c.value, 20, true, cw - 16), x + 10, doc.y + 38, 20, true, c.color);
    doc.text(trunc(c.sub, 7, false, cw - 16), x + 10, doc.y + 55, 7, false, C.muted);
  });
  doc.y += 64 + 22;

  /* ---- helpers ---- */
  const heading = (title: string, count?: number) => {
    doc.ensure(44);
    doc.rect(MARGIN, doc.y, 3, 14, C.cyanDark);
    doc.text(title, MARGIN + 10, doc.y + 11, 12, true, C.ink);
    if (count != null) {
      const label = String(count);
      const tx = MARGIN + 10 + textWidth(title, 12, true) + 8;
      const pw = textWidth(label, 8, true) + 12;
      doc.rrect(tx, doc.y + 1, pw, 14, 7, C.card);
      doc.text(label, tx + 6, doc.y + 11, 8, true, C.muted);
    }
    doc.line(MARGIN, doc.y + 20, MARGIN + CONTENT_W, doc.y + 20, C.rule, 0.8);
    doc.y += 30;
  };

  /* ---- system ---- */
  heading("System");
  const sys: [string, string][] = [
    ["Node", node],
    ["Hostname", clean(d.hostname) || "—"],
    ["Operating system", clean(d.os) || "—"],
    ["Kernel", clean(d.kernel) || "—"],
    ["Lynis version", d.lynisVersion ? `v${d.lynisVersion}` : "—"],
    ["Malware scanner", d.malwareScanner ? "Present" : "Missing"],
  ];
  const colW = (CONTENT_W - 16) / 2;
  const rows = Math.ceil(sys.length / 2);
  doc.ensure(rows * 30 + 8);
  sys.forEach(([k, v], i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    const x = MARGIN + col * (colW + 16);
    const y = doc.y + row * 30;
    doc.rrect(x, y, colW, 25, 5, C.card);
    doc.text(k.toUpperCase(), x + 9, y + 10, 6.5, true, C.muted);
    doc.text(trunc(v, 9, true, colW - 18), x + 9, y + 21, 9, true, C.ink);
  });
  doc.y += rows * 30 + 14;

  /* ---- findings ---- */
  const finding = (f: PdfFinding, kind: "warn" | "sug") => {
    const innerW = CONTENT_W - 22;
    const barColor = f.expected ? C.faint : kind === "warn" ? C.bad : C.warn;
    const desc = wrap(f.description || "(no description)", 9, true, innerW - 80);
    const ctx = f.context ? wrap(f.context, 8, false, innerW) : [];
    const sol = f.solution ? wrap(`Solution: ${f.solution}`, 8, false, innerW) : [];
    const h = 10 + 11 + desc.length * 11.5 + (ctx.length ? ctx.length * 10.5 + 3 : 0) + (sol.length ? sol.length * 10.5 + 3 : 0) + 8;
    doc.ensure(h + 6);
    const y0 = doc.y;
    doc.rrect(MARGIN, y0, CONTENT_W, h, 5, "#ffffff", C.rule);
    doc.rect(MARGIN, y0 + 3, 3, h - 6, barColor);
    let y = y0 + 15;
    const id = clean(f.testId);
    doc.text(trunc(id, 8, true, 180), MARGIN + 14, y, 8, true, C.cyanDark);
    const tag = f.expected ? "PVE expected" : "Actionable";
    const tw = textWidth(tag, 6.8, true) + 12;
    const tagFill = f.expected ? C.card : kind === "warn" ? "#fee2e2" : "#fef3c7";
    const tagInk = f.expected ? C.muted : kind === "warn" ? "#b91c1c" : "#b45309";
    doc.rrect(MARGIN + CONTENT_W - tw - 10, y0 + 6, tw, 13, 6.5, tagFill);
    doc.text(tag, MARGIN + CONTENT_W - tw - 4, y0 + 15.5, 6.8, true, tagInk);
    y += 14;
    desc.forEach((ln) => {
      doc.text(ln, MARGIN + 14, y, 9, true, C.ink);
      y += 11.5;
    });
    if (ctx.length) {
      y += 1;
      ctx.forEach((ln) => {
        doc.text(ln, MARGIN + 14, y, 8, false, C.muted);
        y += 10.5;
      });
    }
    if (sol.length) {
      y += 1;
      sol.forEach((ln) => {
        const isFirst = ln === sol[0];
        if (isFirst && ln.startsWith("Solution:")) {
          doc.text("Solution:", MARGIN + 14, y, 8, true, C.body);
          doc.text(ln.slice(9), MARGIN + 14 + textWidth("Solution:", 8, true), y, 8, false, C.body);
        } else doc.text(ln, MARGIN + 14, y, 8, false, C.body);
        y += 10.5;
      });
    }
    doc.y = y0 + h + 6;
  };

  const group = (title: string, items: PdfFinding[], kind: "warn" | "sug", emptyMsg: string) => {
    heading(title, items.length);
    if (!items.length) {
      doc.ensure(24);
      doc.text(emptyMsg, MARGIN, doc.y + 10, 9, false, C.muted);
      doc.y += 28;
      return;
    }
    const act = items.filter((i) => !i.expected);
    const exp = items.filter((i) => i.expected);
    const sub = (label: string) => {
      doc.ensure(30);
      doc.text(label, MARGIN, doc.y + 8, 8, true, C.muted);
      doc.y += 16;
    };
    if (act.length) {
      sub(`ACTIONABLE (${act.length})`);
      act.forEach((f) => finding(f, kind));
    }
    if (exp.length) {
      sub(`PVE EXPECTED — normal for Proxmox VE (${exp.length})`);
      exp.forEach((f) => finding(f, kind));
    }
    doc.y += 10;
  };

  if (!d.warnings.some((w) => !w.expected)) {
    heading("Needs attention");
    doc.rrect(MARGIN, doc.y, CONTENT_W, 26, 5, "#f0fdf4", "#86efac");
    doc.text("No actionable warnings in this audit.", MARGIN + 12, doc.y + 17, 9.5, true, "#166534");
    doc.y += 40;
  }
  group("Warnings", d.warnings, "warn", "No warnings were reported.");
  group("Suggestions", d.suggestions, "sug", "No suggestions were reported.");

  /* ---- checks performed ---- */
  if (d.sections.length) {
    heading("Checks performed", d.sections.length);
    d.sections.forEach((s) => {
      const names = s.checks.map(clean).filter(Boolean);
      const lines = names.length ? wrap(names.join("  ·  "), 7.5, false, CONTENT_W - 12) : [];
      doc.ensure(30 + Math.min(lines.length, 3) * 10);
      const title = `${clean(s.name)}`;
      doc.text(trunc(title, 9.5, true, CONTENT_W - 90), MARGIN, doc.y + 9, 9.5, true, C.ink);
      const cnt = `${names.length} ${names.length === 1 ? "check" : "checks"}`;
      doc.text(cnt, MARGIN + CONTENT_W - textWidth(cnt, 8, false), doc.y + 9, 8, false, C.muted);
      doc.y += 16;
      lines.forEach((ln) => {
        doc.ensure(11);
        doc.text(ln, MARGIN + 6, doc.y + 7, 7.5, false, C.muted);
        doc.y += 10;
      });
      doc.line(MARGIN, doc.y + 3, MARGIN + CONTENT_W, doc.y + 3, C.rule, 0.5);
      doc.y += 10;
    });
  }

  const pageStreams = doc.finish();
  const total = pageStreams.length;

  /* ---- footers (need total page count) ---- */
  const withFooters = pageStreams.map((content, i) => {
    const f = new Pages();
    f.line(MARGIN, PAGE_H - 30, PAGE_W - MARGIN, PAGE_H - 30, C.rule, 0.6);
    f.text(`${node}  ·  Lynis Security Audit`, MARGIN, PAGE_H - 17, 7.5, false, C.faint);
    const right = `Page ${i + 1} of ${total}`;
    f.text(right, PAGE_W - MARGIN - textWidth(right, 7.5, false), PAGE_H - 17, 7.5, false, C.faint);
    const footerOps = f.finish()[0];
    return `${content}\n${footerOps}`;
  });

  return assemblePdf(withFooters, `Security Audit - ${node}`);
}

/* ───────────────────────── PDF file assembly ───────────────────────── */

function assemblePdf(pageContents: string[], title: string): Uint8Array {
  const objs: string[] = [];
  // 1 catalog, 2 pages, 3 regular font, 4 bold font, 5 info, then (page, content) pairs
  const kids: number[] = [];
  const firstPageObj = 6;
  pageContents.forEach((_, i) => kids.push(firstPageObj + i * 2));
  objs[1] = "<< /Type /Catalog /Pages 2 0 R >>";
  objs[2] = `<< /Type /Pages /Kids [${kids.map((k) => `${k} 0 R`).join(" ")}] /Count ${kids.length} >>`;
  objs[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>";
  objs[4] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>";
  objs[5] = `<< /Title ${pdfString(title)} /Producer (Homedash Proxmox widget) /Creator (Homedash Proxmox widget) >>`;
  pageContents.forEach((content, i) => {
    const pageNo = firstPageObj + i * 2;
    objs[pageNo] =
      `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${num(PAGE_W)} ${num(PAGE_H)}] ` +
      `/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${pageNo + 1} 0 R >>`;
    objs[pageNo + 1] = `<< /Length ${content.length} >>\nstream\n${content}\nendstream`;
  });

  let out = "%PDF-1.4\n%\u00e2\u00e3\u00cf\u00d3\n";
  const offsets: number[] = [];
  for (let n = 1; n < objs.length; n++) {
    offsets[n] = out.length;
    out += `${n} 0 obj\n${objs[n]}\nendobj\n`;
  }
  const xref = out.length;
  out += `xref\n0 ${objs.length}\n0000000000 65535 f \n`;
  for (let n = 1; n < objs.length; n++) out += `${String(offsets[n]).padStart(10, "0")} 00000 n \n`;
  out += `trailer\n<< /Size ${objs.length} /Root 1 0 R /Info 5 0 R >>\nstartxref\n${xref}\n%%EOF`;

  const bytes = new Uint8Array(out.length);
  for (let i = 0; i < out.length; i++) bytes[i] = out.charCodeAt(i) & 0xff;
  return bytes;
}

export function pdfFileName(node: string, when: Date): string {
  const p = (n: number) => String(n).padStart(2, "0");
  const stamp = `${when.getFullYear()}${p(when.getMonth() + 1)}${p(when.getDate())}-${p(when.getHours())}${p(when.getMinutes())}`;
  const safe = clean(node).replace(/[^A-Za-z0-9._-]+/g, "-").replace(/^-+|-+$/g, "") || "node";
  return `security-audit-${safe}-${stamp}.pdf`;
}

export function downloadPdf(bytes: Uint8Array, filename: string) {
  const blob = new Blob([bytes as BlobPart], { type: "application/pdf" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
}
