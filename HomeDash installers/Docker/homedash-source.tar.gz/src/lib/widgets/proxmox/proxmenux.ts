import { joinUrl } from "@/lib/proxy";
import { prxTargets, type ProxmoxConfig } from "./config";

export async function prxFetch(
  cfg: ProxmoxConfig,
  path: string,
  init: RequestInit = {},
): Promise<unknown> {
  const token = cfg.prxToken?.trim();
  if (!token) throw new Error("Configure ProxMenux API key in Settings");
  const urls = prxTargets(cfg);
  if (!urls.length) throw new Error("Configure ProxMenux URL in Settings");

  let lastError: Error | undefined;
  for (const base of urls) {
    try {
      const response = await fetch(joinUrl(base, path), {
        ...init,
        headers: {
          Accept: "application/json",
          Authorization: `Bearer ${token}`,
          ...(init.body ? { "Content-Type": "application/json" } : {}),
          ...(init.headers || {}),
        },
        cache: "no-store",
        signal: init.signal || AbortSignal.timeout(12_000),
      });
      if (response.status === 401 || response.status === 403) {
        throw new Error("ProxMenux API key rejected");
      }
      if (!response.ok) throw new Error(`ProxMenux HTTP ${response.status}`);
      if (response.status === 204) return null;
      const type = response.headers.get("content-type") || "";
      if (type.includes("application/json")) return response.json();
      return response.text();
    } catch (cause) {
      lastError = cause instanceof Error ? cause : new Error("ProxMenux request failed");
      // Don't burn a Cloudflare fallback timeout after an intentional abort/timeout.
      if (lastError.name === "AbortError" || /aborted|timeout/i.test(lastError.message)) {
        throw lastError;
      }
    }
  }
  throw lastError || new Error("Could not reach ProxMenux");
}

export function prxWsBase(prxUrl: string, ticket?: string) {
  const url = new URL(prxUrl);
  const scheme = url.protocol === "https:" ? "wss:" : "ws:";
  const base = `${scheme}//${url.host}/ws/terminal`;
  return ticket ? `${base}?ticket=${encodeURIComponent(ticket)}` : base;
}

export function prxScriptWsUrl(prxUrl: string, sessionId: string, ticket: string) {
  const url = new URL(prxUrl);
  const scheme = url.protocol === "https:" ? "wss:" : "ws:";
  return `${scheme}//${url.host}/ws/script/${encodeURIComponent(sessionId)}?ticket=${encodeURIComponent(ticket)}`;
}

export async function issuePrxTerminalTicket(cfg: ProxmoxConfig): Promise<{ ticket: string; base: string; wsUrl: string }> {
  const token = cfg.prxToken?.trim();
  if (!token) throw new Error("Configure ProxMenux API key for terminal access");
  const urls = prxTargets(cfg);
  let lastError: Error | undefined;
  for (const base of urls) {
    try {
      const healthResponse = await fetch(joinUrl(base, "/api/terminal/health"), {
        headers: { Accept: "application/json", Authorization: `Bearer ${token}` },
        cache: "no-store",
        signal: AbortSignal.timeout(8_000),
      }).catch(() => null);
      const response = await fetch(joinUrl(base, "/api/terminal/ticket"), {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: "{}",
        cache: "no-store",
        signal: AbortSignal.timeout(10_000),
      });
      // Older ProxMenux Monitor releases expose /ws/terminal but predate the
      // short-lived ticket route. Only use their legacy handshake when the
      // terminal health endpoint proves this is a live Monitor service.
      if (
        healthResponse?.ok &&
        (response.status === 404 || response.status === 405)
      ) {
        const authStatus = await fetch(joinUrl(base, "/api/auth/status"), {
          headers: { Accept: "application/json", Authorization: `Bearer ${token}` },
          cache: "no-store",
          signal: AbortSignal.timeout(8_000),
        })
          .then(async (result) =>
            result.ok
              ? (await result.json()) as { auth_enabled?: boolean; declined?: boolean }
              : null,
          )
          .catch(() => null);
        if (authStatus?.auth_enabled && !authStatus.declined) {
          throw new Error(
            "ProxMenux Monitor is missing the authenticated terminal ticket API; update or reinstall ProxMenux Monitor",
          );
        }
        return { ticket: "", base, wsUrl: prxWsBase(base) };
      }
      if (response.status === 401 || response.status === 403) {
        let reason = "";
        try {
          const body = (await response.clone().json()) as { error?: string };
          if (body?.error) reason = ` (${body.error})`;
        } catch {
          // ProxMenux's 401/403 body isn't always JSON — ignore and use the generic message.
        }
        throw new Error(
          `ProxMenux API key rejected${reason} — generate a new token in ProxMenux Monitor ` +
            "(Security tab → API Access Tokens) and update it in Settings",
        );
      }
      if (!response.ok) throw new Error(`Terminal ticket HTTP ${response.status}`);
      const body = (await response.json()) as { ticket?: string };
      if (!body.ticket) throw new Error("ProxMenux did not return a terminal ticket");
      return { ticket: body.ticket, base, wsUrl: prxWsBase(base, body.ticket) };
    } catch (cause) {
      lastError = cause instanceof Error ? cause : new Error("Terminal ticket failed");
    }
  }
  throw lastError || new Error("Could not issue ProxMenux terminal ticket");
}
