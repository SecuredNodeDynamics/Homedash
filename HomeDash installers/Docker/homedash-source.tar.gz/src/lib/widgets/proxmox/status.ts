import { pveRequest, resolveNodeName } from "./client";
import { loadProxmoxConfig, type ProxmoxConfig } from "./config";
import {
  fmtBytes,
  fmtBps,
  fmtUptime,
  iowaitColor,
  loadColor,
  percent,
  pctColor,
  tempColor,
} from "./format";
import { fetchGlancesBundle, type GlancesBundle } from "./glances";
import { prxFetch } from "./proxmenux";
import { resolveLynisSecurity } from "./lynis-store";

type HardwareBlock = {
  cpu?: Record<string, unknown>;
  motherboard?: Record<string, unknown>;
  bios?: Record<string, unknown>;
  memory_modules?: Array<Record<string, unknown>>;
  temperatures?: Array<Record<string, unknown>>;
  gpus?: Array<Record<string, unknown>>;
  pci_devices?: Array<Record<string, unknown>>;
};

export type GuestUpdateCheck = {
  available: boolean;
  count: number;
  security_count: number;
  last_check?: string | null;
  packages?: Array<{
    name?: string;
    Package?: string;
    current?: string;
    latest?: string;
    Version?: string;
    NewVersion?: string;
    security?: boolean;
  }>;
};

export type PveGuest = {
  id: number;
  name: string;
  type: "vm" | "lxc";
  kind: "qemu" | "lxc";
  status: string;
  cpu: number;
  cpus: number;
  mem: number;
  maxmem: number;
  disk: number;
  maxdisk: number;
  diskread: number;
  diskwrite: number;
  netin: number;
  netout: number;
  uptime: number;
  ips?: string[];
  updateCheck?: GuestUpdateCheck | null;
};

export type ProxmoxStatusPayload = {
  href: string;
  openFallbackUrl: string | null;
  connectionSource: "private" | "public" | "unknown";
  prxHref: string | null;
  prxOpenFallbackUrl: string | null;
  node: string;
  online: boolean;
  pveOnline: boolean;
  glancesOnline: boolean;
  uptime: number;
  uptimeLabel: string;
  color: string;
  iface: string;
  backupMount: string | null;
  label: string;
  cpu: number;
  memory: { used: number; total: number; percent: number };
  disk: { used: number; total: number; percent: number };
  vms: PveGuest[];
  lxcs: PveGuest[];
  storageCount: number;
  overview: OverviewData;
  guests: GuestsSummary;
  storage: StorageSummary;
  network: NetworkSummary;
  hardware: unknown | null;
  backups: BackupsSummary | null;
  security: unknown | null;
  prxConfigured: boolean;
  updatedAt: number;
  /** Sections whose live fetch failed this poll and were filled from the last good copy. */
  degraded?: string[];
};

export type BackupsSummary = {
  items: Array<Record<string, unknown>>;
  schedules: Array<Record<string, unknown>>;
};

export type OverviewData = {
  liveCpuPct: number;
  liveCpuColor: string;
  liveMemPct: number;
  liveMemColor: string;
  liveMemUsed: string;
  liveMemTotal: string;
  diskPct: number;
  diskColor: string;
  diskUsed: string;
  diskTotal: string;
  cpuTemp: number | null;
  loadDisplay: string;
  loadSub: string;
  loadBarColor: string;
  swapDisplay: string;
  swapSub: string;
  swapColor: string;
  procDisplay: string;
  procSub: string;
  procColor: string;
  rxBytes: number;
  txBytes: number;
  rxLabel: string;
  txLabel: string;
  ioWaitPct: number | null;
  ioWaitColor: string;
  bupPct: number | null;
  bupColor: string;
  bupUsed: string;
  bupTotal: string;
  bupNote: string;
  bupLabel: string;
  kernelVersion: string;
  hasKernelUpdate: boolean;
  updateCount: number;
  updateColor: string;
  updateLabel: string;
  updates: Array<{ Package?: string; name?: string; Version?: string; NewVersion?: string }>;
  topProcs: Array<{ name?: string; cmdline?: string; cpu_percent?: number; memory_percent?: number; status?: string }>;
};

export type GuestsSummary = {
  total: number;
  running: number;
  vmCount: number;
  lxcCount: number;
  cpuUsedSum: number;
  cpuAllocSum: number;
  hostCpus: number;
  memUsedSum: number;
  memAllocSum: number;
  hostMemTotal: number;
  diskUsedSum: number;
  diskAllocSum: number;
  items: PveGuest[];
};

export type StorageSummary = {
  stores: Array<Record<string, unknown>>;
  disks: Array<Record<string, unknown>>;
  remoteMounts: Array<Record<string, unknown>>;
};

export type NetworkSummary = {
  rrd: Array<Record<string, unknown>>;
  ifaces: Array<Record<string, unknown>>;
  flowGuests: Array<{ id: number; name: string; type: "vm" | "lxc"; kind: "qemu" | "lxc"; status: string; netin: number; netout: number }>;
};

function mapGuests(items: Array<Record<string, unknown>>, type: "vm" | "lxc"): PveGuest[] {
  return items.map((item) => ({
    id: Number(item.vmid || 0),
    name: String(item.name || `${type.toUpperCase()} ${item.vmid || ""}`),
    type,
    kind: type === "vm" ? "qemu" : "lxc",
    status: String(item.status || "unknown"),
    cpu: Number(item.cpu || 0),
    cpus: Number(item.cpus || 1),
    mem: Number(item.mem || 0),
    maxmem: Number(item.maxmem || 0),
    disk: Number(item.disk || 0),
    maxdisk: Number(item.maxdisk || 0),
    diskread: Number(item.diskread || 0),
    diskwrite: Number(item.diskwrite || 0),
    netin: Number(item.netin || 0),
    netout: Number(item.netout || 0),
    uptime: Number(item.uptime || 0),
    ips: [],
  }));
}

function isUsefulGuestIp(ip: string) {
  const v = String(ip || "").trim();
  if (!v) return false;
  if (v === "127.0.0.1" || v === "::1") return false;
  if (v.startsWith("169.254.")) return false;
  if (v.toLowerCase().startsWith("fe80:")) return false;
  return true;
}

function normalizeUpdateCheck(raw: unknown): GuestUpdateCheck | null {
  if (!raw || typeof raw !== "object") return null;
  const uc = raw as Record<string, unknown>;
  const packages = Array.isArray(uc.packages) ? uc.packages : [];
  const count = Number(uc.count) || packages.length || 0;
  const available = uc.available === true || count > 0;
  if (!available && count <= 0) return null;
  return {
    available: true,
    count: count || packages.length,
    security_count: Number(uc.security_count) || 0,
    last_check: (uc.last_check || uc.last_checked || uc.last_checked_iso || null) as string | null,
    packages: packages as GuestUpdateCheck["packages"],
  };
}

function parseIpsFromInterfaces(ifaces: unknown): string[] {
  const list = Array.isArray(ifaces) ? ifaces : [];
  const v4: string[] = [];
  const v6: string[] = [];
  for (const iface of list) {
    const row = iface as Record<string, unknown>;
    const name = String(row?.name || "");
    if (!name || name === "lo") continue;
    const addrs = Array.isArray(row["ip-addresses"]) ? (row["ip-addresses"] as Array<Record<string, unknown>>) : [];
    if (addrs.length) {
      for (const a of addrs) {
        const ip = String(a?.["ip-address"] || "")
          .split("/")[0]
          .trim();
        if (!isUsefulGuestIp(ip)) continue;
        const typ = String(a?.["ip-address-type"] || "").toLowerCase();
        if (typ === "inet" || typ === "ipv4" || /^\d+\.\d+\.\d+\.\d+$/.test(ip)) v4.push(ip);
        else if (typ === "inet6" || typ === "ipv6" || ip.includes(":")) v6.push(ip);
      }
      continue;
    }
    const inet = String(row?.inet || "")
      .split("/")[0]
      .trim();
    if (isUsefulGuestIp(inet) && /^\d+\.\d+\.\d+\.\d+$/.test(inet)) v4.push(inet);
    const inet6 = String(row?.inet6 || "")
      .split("/")[0]
      .trim();
    if (isUsefulGuestIp(inet6) && inet6.includes(":")) v6.push(inet6);
  }
  return [...new Set([...v4, ...v6])];
}

function parseIpsFromConfig(config: Record<string, unknown> | null | undefined): string[] {
  const ips: string[] = [];
  if (!config) return ips;
  for (const [key, raw] of Object.entries(config)) {
    const val = String(raw || "");
    if (/^net\d+$/i.test(key)) {
      const ip4 = val.match(/(?:^|,)ip=([^,]+)/i);
      const ip6 = val.match(/(?:^|,)ip6=([^,]+)/i);
      if (ip4?.[1] && !/^dhcp$/i.test(ip4[1])) {
        const cleaned = ip4[1].split("/")[0].trim();
        if (isUsefulGuestIp(cleaned)) ips.push(cleaned);
      }
      if (ip6?.[1] && !/^(auto|dhcp)$/i.test(ip6[1])) {
        const cleaned = ip6[1].split("/")[0].trim();
        if (isUsefulGuestIp(cleaned)) ips.push(cleaned);
      }
    }
    if (/^ipconfig\d+$/i.test(key)) {
      const ip4 = val.match(/(?:^|,)ip=([^,]+)/i);
      const ip6 = val.match(/(?:^|,)ip6=([^,]+)/i);
      if (ip4?.[1] && !/^dhcp$/i.test(ip4[1])) {
        const cleaned = ip4[1].split("/")[0].trim();
        if (isUsefulGuestIp(cleaned)) ips.push(cleaned);
      }
      if (ip6?.[1] && !/^(auto|dhcp)$/i.test(ip6[1])) {
        const cleaned = ip6[1].split("/")[0].trim();
        if (isUsefulGuestIp(cleaned)) ips.push(cleaned);
      }
    }
  }
  return [...new Set(ips)];
}

function extractIpsFromPrxGuest(match: Record<string, unknown>): string[] {
  const rawIps = match.ips || match.ip_addresses || match.ip || match.addresses;
  const ips: string[] = [];
  if (Array.isArray(rawIps)) {
    for (const value of rawIps) {
      const ip =
        typeof value === "string"
          ? value
          : String((value as { address?: string; ip?: string })?.address || (value as { ip?: string })?.ip || "");
      const cleaned = ip.replace(/\/\d+$/, "").trim();
      if (isUsefulGuestIp(cleaned)) ips.push(cleaned);
    }
  } else if (typeof rawIps === "string") {
    const cleaned = rawIps.replace(/\/\d+$/, "").trim();
    if (isUsefulGuestIp(cleaned)) ips.push(cleaned);
  }
  return [...new Set(ips)];
}

const GUEST_IP_TTL_MS = 60_000;
const guestIpCache = new Map<string, { ips: string[]; at: number }>();

function guestIpCacheKey(cfg: ProxmoxConfig, node: string, guest: PveGuest) {
  return `${cfg.pveUrl || cfg.fallbackUrl || ""}:${node}:${guest.kind}:${guest.id}`;
}

async function fetchGuestRuntimeIps(cfg: ProxmoxConfig, node: string, guest: PveGuest): Promise<string[]> {
  const base = `/nodes/${encodeURIComponent(node)}/${guest.kind}/${guest.id}`;
  if (guest.kind === "lxc") {
    const { data } = await pveRequest<unknown>(cfg, `${base}/interfaces`);
    return parseIpsFromInterfaces(data);
  }
  try {
    const { data } = await pveRequest<unknown>(cfg, `${base}/agent/network-get-interfaces`);
    const ifaces = Array.isArray(data)
      ? data
      : Array.isArray((data as { result?: unknown })?.result)
        ? ((data as { result: unknown[] }).result)
        : [];
    return parseIpsFromInterfaces(ifaces);
  } catch {
    return [];
  }
}

async function resolveGuestIps(cfg: ProxmoxConfig, node: string, guest: PveGuest): Promise<string[]> {
  let ips: string[] = [];
  if (guest.status === "running") {
    try {
      ips = await fetchGuestRuntimeIps(cfg, node, guest);
    } catch {
      ips = [];
    }
  }
  if (!ips.length) {
    try {
      const { data } = await pveRequest<Record<string, unknown>>(
        cfg,
        `/nodes/${encodeURIComponent(node)}/${guest.kind}/${guest.id}/config`,
      );
      ips = parseIpsFromConfig(data);
    } catch {
      ips = [];
    }
  }
  return ips;
}

async function mapPool<T>(items: T[], concurrency: number, fn: (item: T) => Promise<void>) {
  if (!items.length) return;
  const queue = items.slice();
  const workers = Array.from({ length: Math.min(concurrency, queue.length) }, async () => {
    while (queue.length) {
      const item = queue.shift();
      if (item === undefined) return;
      await fn(item);
    }
  });
  await Promise.all(workers);
}

async function enrichGuests(
  cfg: ProxmoxConfig,
  node: string,
  guests: PveGuest[],
  vmsPayload: unknown = null,
) {
  // ProxMenux: package update_check (+ rare IP fields). PVE: runtime/config IPs.
  const payload = vmsPayload ?? (await fetchPrxOptional(cfg, "/api/vms", 2500));
  const list = Array.isArray(payload)
    ? (payload as Array<Record<string, unknown>>)
    : ((((payload as { vms?: unknown[] } | null)?.vms) || []) as Array<Record<string, unknown>>);

  const byId = new Map<number, Record<string, unknown>>();
  for (const item of list) {
    const id = Number(item.vmid || 0);
    if (id) byId.set(id, item);
  }

  const now = Date.now();
  const needIp: PveGuest[] = [];

  for (const guest of guests) {
    const match = byId.get(guest.id);
    if (match) {
      guest.updateCheck = normalizeUpdateCheck(match.update_check);
      const prxIps = extractIpsFromPrxGuest(match);
      if (prxIps.length) guest.ips = prxIps;
    }

    if (guest.ips?.length) continue;
    const key = guestIpCacheKey(cfg, node, guest);
    const cached = guestIpCache.get(key);
    if (cached && now - cached.at < GUEST_IP_TTL_MS) {
      guest.ips = cached.ips;
      continue;
    }
    needIp.push(guest);
  }

  await mapPool(needIp, 6, async (guest) => {
    const key = guestIpCacheKey(cfg, node, guest);
    try {
      const ips = await resolveGuestIps(cfg, node, guest);
      guestIpCache.set(key, { ips, at: Date.now() });
      guest.ips = ips;
    } catch {
      if (!guestIpCache.has(key)) guestIpCache.set(key, { ips: [], at: Date.now() });
      guest.ips = guestIpCache.get(key)?.ips || [];
    }
  });

  return guests;
}

function isWholeDisk(disk: Record<string, unknown>) {
  const devpath = String(disk.devpath || "");
  if (!devpath) return false;
  if (disk.parent) return false;
  if (/p\d+$/.test(devpath) || /-\d+$/.test(devpath)) return false;
  return true;
}

function isRemoteStorage(store: Record<string, unknown>) {
  const type = String(store.type || "").toLowerCase();
  return /nfs|cifs|rbd|iscsi|pbs|cephfs|gluster/.test(type) || Boolean(store.shared);
}

function normalizeMountPath(p: unknown): string {
  return String(p || "")
    .trim()
    .replace(/\/+$/, "")
    .toLowerCase();
}

type BackupDetection = {
  pct: number | null;
  used: number;
  total: number;
  label: string;
  note: string;
};

/**
 * Figures out which storage/mount represents "the backup drive" without
 * requiring the user to type a path in Settings.
 *
 * Priority:
 *  1. Manual override (cfg.backupMount) — still respected if set, matched
 *     against Glances-reported filesystems (trailing-slash/case tolerant).
 *  2. Auto: any PVE storage whose `content` list includes "backup". PVE
 *     already knows exactly which storages vzdump can target and reports
 *     used/total directly, so this needs no filesystem-path guessing.
 *     A non-"local" dedicated backup storage is preferred over the default
 *     "local" storage when both qualify.
 *  3. Fallback: a Glances-reported filesystem whose mount point mentions
 *     "backup" and isn't root — for setups where the drive is mounted but
 *     not registered as a PVE storage.
 */
function detectBackupStorage(
  cfg: ProxmoxConfig,
  stores: Array<Record<string, unknown>>,
  glDisk: Array<Record<string, unknown>> | null | undefined,
): BackupDetection {
  const manualTarget = normalizeMountPath(cfg.backupMount);
  if (manualTarget) {
    const match = Array.isArray(glDisk)
      ? glDisk.find((d) => normalizeMountPath(d.mnt_point) === manualTarget) || null
      : null;
    if (match) {
      return {
        pct: percent(Number(match.used || 0), Number(match.size || 0)),
        used: Number(match.used || 0),
        total: Number(match.size || 0),
        label: String(cfg.backupMount),
        note: "",
      };
    }
    return {
      pct: null,
      used: 0,
      total: 0,
      label: String(cfg.backupMount),
      note: `No filesystem mounted at "${cfg.backupMount}"`,
    };
  }

  const backupStores = stores.filter((s) => /\bbackup\b/.test(String(s.content || "").toLowerCase()));
  if (backupStores.length) {
    const chosen = backupStores.find((s) => String(s.storage) !== "local") || backupStores[0];
    const total = Number(chosen.total || 0);
    const used = Number(chosen.used || 0);
    return {
      pct: total > 0 ? percent(used, total) : null,
      used,
      total,
      label: String(chosen.storage || "backup"),
      note: total > 0 ? "" : "Backup storage found but has no usage data yet",
    };
  }

  const guess = Array.isArray(glDisk)
    ? glDisk.find((d) => /backup/i.test(String(d.mnt_point || "")) && d.mnt_point !== "/") || null
    : null;
  if (guess) {
    return {
      pct: percent(Number(guess.used || 0), Number(guess.size || 0)),
      used: Number(guess.used || 0),
      total: Number(guess.size || 0),
      label: String(guess.mnt_point || "backup"),
      note: "",
    };
  }

  return { pct: null, used: 0, total: 0, label: "", note: "No backup storage detected" };
}

function buildOverview(
  cfg: ProxmoxConfig,
  status: Record<string, unknown>,
  updates: Array<Record<string, unknown>>,
  glances: GlancesBundle | null,
  stores: Array<Record<string, unknown>>,
): OverviewData {
  const memory = (status.memory as { used?: number; total?: number } | undefined) || undefined;
  const rootfs = (status.rootfs as { used?: number; total?: number } | undefined) || undefined;
  const cpuPct = Math.round(Number(status.cpu || 0) * 100);
  const memPct = memory ? percent(Number(memory.used || 0), Number(memory.total || 0)) : 0;
  const rootDisk = rootfs ? percent(Number(rootfs.used || 0), Number(rootfs.total || 0)) : 0;

  const glCpu = glances?.cpu;
  const glMem = glances?.mem;
  const glNet = glances?.network;
  const glProc = glances?.processlist;
  const glSensors = glances?.sensors;
  const glDisk = glances?.fs;
  const glLoad = glances?.load;
  const glSwap = glances?.swap;
  const glQuicklook = glances?.quicklook;

  const liveCpuPct = glCpu?.total != null ? Math.round(Number(glCpu.total)) : cpuPct;
  const liveMemPct = glMem ? percent(Number(glMem.used || 0), Number(glMem.total || 0)) : memPct;
  const liveMemUsed = glMem ? fmtBytes(Number(glMem.used || 0)) : fmtBytes(Number(memory?.used || 0));
  const liveMemTotal = glMem ? fmtBytes(Number(glMem.total || 0)) : fmtBytes(Number(memory?.total || 0));

  const iface = cfg.iface || "vmbr0";
  const netIface = Array.isArray(glNet)
    ? glNet.find((n) => n.interface_name === iface) || glNet.find((n) => n.interface_name !== "lo") || null
    : null;
  const rxBytes = Number(netIface?.bytes_recv_rate_per_sec || 0);
  const txBytes = Number(netIface?.bytes_sent_rate_per_sec || 0);

  const rootFs = Array.isArray(glDisk) ? glDisk.find((d) => d.mnt_point === "/") || null : null;
  const diskPct = rootFs ? percent(Number(rootFs.used || 0), Number(rootFs.size || 0)) : rootDisk;
  const diskUsed = rootFs ? fmtBytes(Number(rootFs.used || 0)) : fmtBytes(Number(rootfs?.used || 0));
  const diskTotal = rootFs ? fmtBytes(Number(rootFs.size || 0)) : fmtBytes(Number(rootfs?.total || 0));

  const backup = detectBackupStorage(cfg, stores, glDisk);

  let cpuTemp: number | null = null;
  if (Array.isArray(glSensors)) {
    const sensor =
      glSensors.find((s) => String(s.label || "").toLowerCase().includes((cfg.cpuSensor || "").toLowerCase())) ||
      glSensors.find((s) => s.type === "cpu_thermal" || String(s.label || "").toLowerCase().includes("cpu"));
    cpuTemp = sensor?.value != null ? Number(sensor.value) : null;
  }

  const loadMin1 = glLoad?.min1 ?? null;
  const loadMin5 = glLoad?.min5 ?? null;
  const cpuCores = glLoad?.cpucore ?? glCpu?.cpucore ?? 1;
  const swapPct = glSwap
    ? percent(Number(glSwap.used || 0), Number(glSwap.total || 0))
    : glQuicklook?.swap != null
      ? Math.round(Number(glQuicklook.swap))
      : null;

  const procTotal = Array.isArray(glProc) ? glProc.length : null;
  const procRunning = Array.isArray(glProc) ? glProc.filter((p) => p.status === "R").length : null;
  const topProcs = Array.isArray(glProc)
    ? [...glProc].sort((a, b) => Number(b.cpu_percent || 0) - Number(a.cpu_percent || 0)).slice(0, 5)
    : [];

  const updateCount = updates.length;
  const kernelRaw = String(status.kversion || "");
  const kernelVersion =
    kernelRaw.replace(/^Linux\s*/i, "").replace(/#.*/, "").trim() || "—";
  const hasKernelUpdate = updates.some((u) => /pve-kernel|linux-image/i.test(String(u.Package || u.name || "")));
  const updateColor = updateCount === 0 ? "#6ee7b7" : updateCount < 5 ? "#fbbf24" : "#f87171";
  const ioWaitPct = glCpu?.iowait != null ? Math.round(Number(glCpu.iowait) * 10) / 10 : null;

  return {
    liveCpuPct,
    liveCpuColor: pctColor(liveCpuPct),
    liveMemPct,
    liveMemColor: pctColor(liveMemPct),
    liveMemUsed,
    liveMemTotal,
    diskPct,
    diskColor: pctColor(diskPct),
    diskUsed: diskUsed || "—",
    diskTotal: diskTotal || "—",
    cpuTemp,
    loadDisplay: loadMin1 != null ? loadMin1.toFixed(2) : "—",
    loadSub:
      loadMin1 != null && loadMin5 != null
        ? `5m: ${loadMin5.toFixed(2)} · ${cpuCores} cores`
        : cpuCores > 1
          ? `${cpuCores} cores`
          : "",
    loadBarColor: loadMin1 != null ? loadColor(loadMin1, Number(cpuCores) || 1) : "#6ee7b7",
    swapDisplay: swapPct != null ? `${swapPct}%` : "—",
    swapSub: glSwap ? `${fmtBytes(Number(glSwap.used || 0))} / ${fmtBytes(Number(glSwap.total || 0))}` : "",
    swapColor: swapPct != null ? pctColor(swapPct) : "#6ee7b7",
    procDisplay: procTotal != null ? String(procTotal) : "—",
    procSub: procRunning != null && procRunning > 0 ? `${procRunning} running` : procTotal != null ? "all sleeping" : "",
    procColor: procTotal != null ? (procTotal > 400 ? "#fbbf24" : "#6ee7b7") : "#6ee7b7",
    rxBytes,
    txBytes,
    rxLabel: fmtBps(rxBytes),
    txLabel: fmtBps(txBytes),
    ioWaitPct,
    ioWaitColor: ioWaitPct != null ? iowaitColor(ioWaitPct) : "#6ee7b7",
    bupPct: backup.pct,
    bupColor: backup.pct != null ? pctColor(backup.pct) : "rgba(255,255,255,0.25)",
    bupUsed: backup.total > 0 ? fmtBytes(backup.used) : "—",
    bupTotal: backup.total > 0 ? fmtBytes(backup.total) : "—",
    bupNote: backup.note,
    bupLabel: backup.label,
    kernelVersion,
    hasKernelUpdate,
    updateCount,
    updateColor,
    updateLabel: updateCount === 0 ? "Up to date" : `${updateCount} update${updateCount !== 1 ? "s" : ""} available`,
    updates: updates as OverviewData["updates"],
    topProcs: topProcs as OverviewData["topProcs"],
  };
}

function buildGuestsSummary(status: Record<string, unknown>, vms: PveGuest[], lxcs: PveGuest[]): GuestsSummary {
  const items = [...vms, ...lxcs].sort((a, b) => {
    const ar = a.status === "running" ? 0 : 1;
    const br = b.status === "running" ? 0 : 1;
    if (ar !== br) return ar - br;
    return a.name.localeCompare(b.name, undefined, { sensitivity: "base" });
  });
  const memory = (status.memory as { total?: number } | undefined) || undefined;
  const cpuinfo = (status.cpuinfo as { cpus?: number; cores?: number } | undefined) || undefined;
  let cpuUsedSum = 0;
  let cpuAllocSum = 0;
  let memUsedSum = 0;
  let memAllocSum = 0;
  let diskUsedSum = 0;
  let diskAllocSum = 0;
  for (const g of items) {
    cpuAllocSum += g.cpus || 1;
    cpuUsedSum += g.cpu * (g.cpus || 1);
    memUsedSum += g.mem;
    memAllocSum += g.maxmem;
    diskUsedSum += g.disk;
    diskAllocSum += g.maxdisk;
  }
  return {
    total: items.length,
    running: items.filter((g) => g.status === "running").length,
    vmCount: vms.length,
    lxcCount: lxcs.length,
    cpuUsedSum,
    cpuAllocSum,
    hostCpus: Number(cpuinfo?.cpus || cpuinfo?.cores || 0),
    memUsedSum,
    memAllocSum,
    hostMemTotal: Number(memory?.total || 0),
    diskUsedSum,
    diskAllocSum,
    items,
  };
}

function collectRemoteMounts(glances: GlancesBundle | null, stores: Array<Record<string, unknown>>) {
  const fromPve = stores.filter(isRemoteStorage);
  const fromGlances = (glances?.fs || [])
    .filter((fs) => {
      const type = String(fs.fs_type || "").toLowerCase();
      const device = String(fs.device_name || "");
      return /nfs|cifs|smb|fuse|sshfs/.test(type) || device.includes(":");
    })
    .map((fs) => ({
      storage: String(fs.mnt_point || fs.device_name || "mount"),
      type: String(fs.fs_type || "remote"),
      used: Number(fs.used || 0),
      total: Number(fs.size || 0),
      mnt_point: fs.mnt_point,
      device_name: fs.device_name,
      remote: true,
    }));
  return [...fromPve, ...fromGlances];
}

const prxCache = new Map<string, { at: number; value: unknown }>();
const PRX_CACHE_TTL_MS = 12_000;

async function settleWithin<T>(promise: Promise<T>, timeoutMs: number, fallback: T): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      promise,
      new Promise<T>((resolve) => {
        timer = setTimeout(() => resolve(fallback), timeoutMs);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

async function fetchPrxOptional(cfg: ProxmoxConfig, path: string, timeoutMs = 12_000) {
  if (!cfg.prxToken?.trim() || !prxTargetsSafe(cfg)) return null;
  const cacheKey = `${cfg.prxUrl || ""}|${cfg.prxFallbackUrl || ""}|${path}`;
  const cached = prxCache.get(cacheKey);
  if (cached && Date.now() - cached.at < PRX_CACHE_TTL_MS) return cached.value;

  // Give the underlying request real room to finish — some ProxMenux
  // endpoints (esp. /api/security/tools checking for Lynis) can take a
  // couple seconds on a busy node, longer than the soft per-poll budget
  // below. Hard-aborting at the poll's short timeout meant slow endpoints
  // could NEVER complete and their cache would never fill in, permanently
  // showing stale/empty results (e.g. "Lynis Not Installed"). Instead, let
  // the request keep running in the background past the race so it can
  // still populate the cache for the next poll, and fall back to the last
  // known-good cached value (rather than null) if this poll doesn't wait
  // for it.
  const requestPromise = prxFetch(cfg, path, { signal: AbortSignal.timeout(Math.max(timeoutMs, 8_000)) })
    .then((value) => {
      prxCache.set(cacheKey, { at: Date.now(), value });
      return value;
    })
    .catch(() => null);

  return settleWithin(requestPromise, timeoutMs, cached?.value ?? null);
}

function prxTargetsSafe(cfg: ProxmoxConfig) {
  return Boolean(cfg.prxUrl || cfg.prxFallbackUrl);
}

/** Glances often reports bits/s; ProxMenux reports Mbps. */
function normalizeSpeedMbps(speed: unknown) {
  const n = Number(speed);
  if (!Number.isFinite(n) || n <= 0) return 0;
  if (n >= 1e6) return Math.round(n / 1e6);
  return Math.round(n);
}

function isVirtualIfaceName(name: string) {
  return /^(lo|veth|fwbr|fwpr|fwln|tap|tun|docker|br-|virbr|vnet|cni|flannel|cali|tailscale|wg|zt)/i.test(name || "");
}

function isBridgeIfaceName(name: string) {
  return /^vmbr/i.test(name || "");
}

function ifaceIsUp(raw: Record<string, unknown>) {
  if (typeof raw.up === "boolean") return raw.up;
  if (typeof raw.isup === "boolean") return raw.isup;
  if (typeof raw.is_up === "boolean") return raw.is_up;
  const status = String(raw.status || raw.operstate || raw.state || "").toLowerCase();
  if (status === "up") return true;
  if (status === "down") return false;
  const rx = Number(raw.rx ?? raw.rx_Bps ?? raw.bytes_recv_rate_per_sec ?? 0);
  const tx = Number(raw.tx ?? raw.tx_Bps ?? raw.bytes_sent_rate_per_sec ?? 0);
  if (rx + tx > 64) return true;
  return null;
}

function normalizeIface(raw: Record<string, unknown>, forcedKind?: string) {
  const name = String(raw.name || raw.interface_name || raw.iface || "").trim();
  if (!name) return null;

  const type = String(raw.type || "").toLowerCase();
  let kind = forcedKind || String(raw.kind || "");
  if (!kind) {
    if (type === "bridge" || isBridgeIfaceName(name)) kind = "bridge";
    else if (type === "vm_lxc" || isVirtualIfaceName(name)) kind = "virtual";
    else if (type === "physical" || type === "nic") kind = "nic";
    else kind = isBridgeIfaceName(name) ? "bridge" : isVirtualIfaceName(name) ? "virtual" : "nic";
  }

  const upGuess = ifaceIsUp(raw);
  const up = upGuess == null ? false : upGuess;
  const status = String(raw.status || (upGuess == null ? "unknown" : up ? "up" : "down")).toLowerCase();
  const speed = normalizeSpeedMbps(raw.speed ?? raw.max_speed);
  const rx = Number(raw.rx ?? raw.rx_Bps ?? raw.bytes_recv_rate_per_sec ?? 0);
  const tx = Number(raw.tx ?? raw.tx_Bps ?? raw.bytes_sent_rate_per_sec ?? 0);

  return {
    ...raw,
    name,
    kind,
    type: type || kind,
    status,
    up: upGuess == null ? (rx + tx > 0 ? true : up) : up,
    speed,
    max_speed: normalizeSpeedMbps(raw.max_speed ?? raw.speed) || speed,
    mtu: raw.mtu ?? null,
    duplex: raw.duplex ?? null,
    rx,
    tx,
    rx_Bps: rx,
    tx_Bps: tx,
    mac: raw.mac_address || raw.mac || null,
    mac_address: raw.mac_address || raw.mac || null,
    bridge_owner: raw.bridge_owner || null,
    bridge_members: Array.isArray(raw.bridge_members) ? raw.bridge_members : [],
    bridge_physical_interface: raw.bridge_physical_interface || null,
    addresses: Array.isArray(raw.addresses) ? raw.addresses : [],
  } as Record<string, unknown>;
}

function glancesIfaceMap(glances: GlancesBundle | null) {
  const map = new Map<string, Record<string, unknown>>();
  for (const iface of glances?.network || []) {
    const name = String(iface.interface_name || iface.name || "").trim();
    if (!name) continue;
    map.set(name, iface);
  }
  return map;
}

function enrichFromGlances(iface: Record<string, unknown>, glancesMap: Map<string, Record<string, unknown>>) {
  const name = String(iface.name || "");
  const gl = glancesMap.get(name);
  if (!gl) return iface;
  const rx = Number(iface.rx || 0);
  const tx = Number(iface.tx || 0);
  const glRx = Number(gl.bytes_recv_rate_per_sec || 0);
  const glTx = Number(gl.bytes_sent_rate_per_sec || 0);
  // Prefer live Glances rates when ProxMenux counters look stale/zero.
  if (rx + tx <= 0 && glRx + glTx > 0) {
    return { ...iface, rx: glRx, tx: glTx, rx_Bps: glRx, tx_Bps: glTx };
  }
  return iface;
}

function buildNetworkIfaces(prxNetwork: unknown, glances: GlancesBundle | null) {
  const glancesMap = glancesIfaceMap(glances);
  const out: Array<Record<string, unknown>> = [];
  const seen = new Set<string>();

  if (prxNetwork && typeof prxNetwork === "object") {
    const net = prxNetwork as {
      physical_interfaces?: Array<Record<string, unknown>>;
      bridge_interfaces?: Array<Record<string, unknown>>;
    };
    for (const raw of net.physical_interfaces || []) {
      const iface = normalizeIface(raw, "nic");
      if (!iface) continue;
      const enriched = enrichFromGlances(iface, glancesMap);
      out.push(enriched);
      seen.add(String(enriched.name));
    }
    for (const raw of net.bridge_interfaces || []) {
      const iface = normalizeIface(raw, "bridge");
      if (!iface) continue;
      const enriched = enrichFromGlances(iface, glancesMap);
      out.push(enriched);
      seen.add(String(enriched.name));
    }
  }

  // Glances fallback / supplement (skip guest veth noise; keep VPN as virtual).
  if (!out.length && Array.isArray(glances?.network)) {
    for (const raw of glances.network) {
      const name = String(raw.interface_name || raw.name || "");
      if (!name || name === "lo") continue;
      if (/^(veth|fwbr|fwpr|fwln|tap|docker|br-)/i.test(name)) continue;
      const iface = normalizeIface({
        ...raw,
        name,
        isup: raw.isup,
        status: typeof raw.isup === "boolean" ? (raw.isup ? "up" : "down") : "unknown",
        speed: raw.speed,
        mtu: raw.mtu,
        duplex: raw.duplex,
        rx: raw.bytes_recv_rate_per_sec,
        tx: raw.bytes_sent_rate_per_sec,
        mac_address: raw.mac_address || raw.mac,
      });
      if (!iface) continue;
      out.push(iface);
      seen.add(String(iface.name));
    }
  } else if (out.length && glancesMap.size) {
    // Add virtual overlays (e.g. tailscale0) ProxMenux omits, without polluting physical.
    for (const [name, raw] of glancesMap) {
      if (seen.has(name) || !isVirtualIfaceName(name)) continue;
      if (/^(veth|fwbr|fwpr|fwln|tap|docker|br-|lo)/i.test(name)) continue;
      const iface = normalizeIface({
        ...raw,
        name,
        isup: raw.isup,
        status: typeof raw.isup === "boolean" ? (raw.isup ? "up" : "down") : "unknown",
        speed: raw.speed,
        rx: raw.bytes_recv_rate_per_sec,
        tx: raw.bytes_sent_rate_per_sec,
        mac_address: raw.mac_address || raw.mac,
      }, "virtual");
      if (iface) out.push(iface);
    }
  }

  return out;
}

function classifyConnectionSource(base: string, cfg: ProxmoxConfig): "private" | "public" | "unknown" {
  const normalize = (url?: string | null) => (url || "").trim().replace(/\/+$/, "").toLowerCase();
  const target = normalize(base);
  if (!target) return "unknown";
  const privateUrl = normalize(cfg.pvePrivateUrl);
  const publicUrl = normalize(cfg.fallbackUrl);
  if (privateUrl && target === privateUrl) return "private";
  if (publicUrl && target === publicUrl) return "public";
  if (privateUrl && !publicUrl) return "private";
  if (publicUrl && !privateUrl) return "public";
  return "unknown";
}

// Last good value per instance + section. A timed-out Proxmox call used to become an
// empty list, which wiped guests/storage/backups from the UI until the next good poll.
const lastGood = new Map<string, unknown>();

function keepGood<T>(instanceId: string, key: string, value: T | null | undefined, empty: T, degraded: string[]): T {
  const k = `${instanceId}:${key}`;
  if (value !== null && value !== undefined) {
    lastGood.set(k, value);
    return value;
  }
  degraded.push(key);
  return (lastGood.get(k) as T | undefined) ?? empty;
}

type PveList = { data: Array<Record<string, unknown>> | null; base: string };

/** Like pveRequest for list endpoints, but a failure is reported as data: null (not []). */
async function pveList(cfg: ProxmoxConfig, path: string, base: string): Promise<PveList> {
  try {
    const res = await pveRequest<Array<Record<string, unknown>>>(cfg, path);
    return { data: Array.isArray(res.data) ? res.data : res.data == null ? [] : null, base: res.base };
  } catch {
    return { data: null, base };
  }
}

export async function fetchProxmoxStatus(instanceId: string): Promise<ProxmoxStatusPayload> {
  const cfg = await loadProxmoxConfig(instanceId);
  const { node, base, online } = await resolveNodeName(cfg);
  const connectionSource = classifyConnectionSource(base, cfg);

  // Run PVE + Glances + ProxMenux together. Soft-timeout slow ProxMenux paths
  // (esp. /api/security/tools on busy nodes) so Network/Overview aren't blocked.
  const [
    statusResult,
    vmsResult,
    lxcsResult,
    storageResult,
    disksResult,
    updatesResult,
    rrdResult,
    glances,
    prxHardware,
    prxNetwork,
    prxSecurityTools,
    prxLynisReport,
    prxStorage,
    prxVms,
    backupSchedulesResult,
  ] = await Promise.all([
    pveRequest<Record<string, unknown>>(cfg, `/nodes/${encodeURIComponent(node)}/status`),
    pveList(cfg, `/nodes/${encodeURIComponent(node)}/qemu`, base),
    pveList(cfg, `/nodes/${encodeURIComponent(node)}/lxc`, base),
    pveList(cfg, `/nodes/${encodeURIComponent(node)}/storage`, base),
    pveList(cfg, `/nodes/${encodeURIComponent(node)}/disks/list`, base),
    pveList(cfg, `/nodes/${encodeURIComponent(node)}/apt/update`, base),
    pveList(cfg, `/nodes/${encodeURIComponent(node)}/rrddata?timeframe=hour&cf=AVERAGE`, base),
    // Glances enriches the overview but must never hold up core PVE data.
    settleWithin(fetchGlancesBundle(cfg), 2_500, null),
    fetchPrxOptional(cfg, "/api/hardware", 2500),
    fetchPrxOptional(cfg, "/api/network", 2500),
    fetchPrxOptional(cfg, "/api/security/tools", 2000),
    fetchPrxOptional(cfg, "/api/security/lynis/report", 2000),
    fetchPrxOptional(cfg, "/api/storage", 2500),
    fetchPrxOptional(cfg, "/api/vms", 2500),
    pveList(cfg, "/cluster/backup", base),
  ]);

  const degraded: string[] = [];
  const good = <T,>(key: string, value: T | null | undefined, empty: T): T =>
    keepGood(instanceId, key, value, empty, degraded);
  const status = statusResult.data || {};
  const vmsRaw = good("vms", vmsResult.data, [] as Array<Record<string, unknown>>);
  const lxcsRaw = good("lxcs", lxcsResult.data, [] as Array<Record<string, unknown>>);
  let vms = mapGuests(vmsRaw, "vm");
  let lxcs = mapGuests(lxcsRaw, "lxc");
  // Attach ProxMenux update_check + PVE runtime/config IPs (cached).
  // Guest-agent IP discovery can be slow or unsupported. Give cached/direct
  // results a brief window, then return the core dashboard while enrichment
  // completes for the next poll.
  const baseGuests = [...vms, ...lxcs];
  const enriched = await settleWithin(enrichGuests(cfg, node, baseGuests, prxVms), 1_800, baseGuests);
  vms = enriched.filter((g) => g.type === "vm");
  lxcs = enriched.filter((g) => g.type === "lxc");
  const stores = good("stores", storageResult.data, [] as Array<Record<string, unknown>>).filter((s) => s && s.storage);
  const disks = good("disks", disksResult.data, [] as Array<Record<string, unknown>>).filter(isWholeDisk);
  const updates = good("updates", updatesResult.data, [] as Array<Record<string, unknown>>);
  const memory = (status.memory as { used?: number; total?: number } | undefined) || undefined;
  const rootfs = (status.rootfs as { used?: number; total?: number } | undefined) || undefined;
  const memUsed = Number(memory?.used || status.mem || 0);
  const memTotal = Number(memory?.total || status.maxmem || 0);
  const diskUsed = Number(rootfs?.used || status.disk || 0);
  const diskTotal = Number(rootfs?.total || status.maxdisk || 0);

  const overview = buildOverview(cfg, status, updates, glances, stores);
  const guests = buildGuestsSummary(status, vms, lxcs);

  const ifaces = buildNetworkIfaces(prxNetwork, glances);

  // Fetch backup contents for each storage that supports them
  const backupItems: Array<Record<string, unknown>> = [];
  const backupStorages = stores.filter((s) => String(s.content || "").includes("backup"));
  const perStorage = await Promise.all(
    backupStorages.map(async (s) => {
      const key = `backup:${String(s.storage)}`;
      try {
        const { data } = await pveRequest<Array<Record<string, unknown>>>(
          cfg,
          `/nodes/${encodeURIComponent(node)}/storage/${encodeURIComponent(String(s.storage))}/content?content=backup`,
        );
        const items = Array.isArray(data)
          ? data.map((item) => {
              const volid = String(item.volid || "");
              const type = volid.includes("vzdump-qemu-") ? "vm" : "lxc";
              return { ...item, storage: s.storage, type } as Record<string, unknown>;
            })
          : [];
        return good(key, items, [] as Array<Record<string, unknown>>);
      } catch {
        // Slow/unreachable backup storage: keep its last known list instead of dropping it.
        return good(key, null, [] as Array<Record<string, unknown>>);
      }
    }),
  );
  perStorage.forEach((items) => backupItems.push(...items));

  // Storage shared across cluster nodes (NFS/PBS/etc.) returns every VMID's
  // backups regardless of which node created them, so without this a node
  // widget would list every other node's backups too. Scope to VMIDs that
  // actually belong to this node's own guest list.
  const nodeGuestIds = new Set([...vms, ...lxcs].map((g) => g.id));
  const nodeBackupItems = backupItems.filter((item) => nodeGuestIds.has(Number(item.vmid)));

  // Merge ProxMenux disk inventory when available
  let enrichedDisks = disks;
  if (prxStorage) {
    const list = Array.isArray(prxStorage)
      ? prxStorage
      : ((prxStorage as { disks?: unknown[]; physical_disks?: unknown[] }).disks ||
          (prxStorage as { physical_disks?: unknown[] }).physical_disks ||
          []) as Array<Record<string, unknown>>;
    if (list.length) {
      enrichedDisks = disks.map((disk) => {
        const match = list.find((item) => {
          const a = String(item.name || item.devpath || "").replace(/^\/dev\//, "");
          const b = String(disk.devpath || disk.name || "").replace(/^\/dev\//, "");
          return a && b && (a === b || a.includes(b) || b.includes(a));
        });
        if (!match) return disk;
        // Promote ProxMenux connection/health fields so USB external filtering works
        // even when PVE reports type:"ssd" for a USB bridge (e.g. WD Game Drive).
        const connection = String(match.connection_type || match.transport || match.protocol || "");
        return {
          ...disk,
          __prx: match,
          transport: disk.transport || connection || disk.transport,
          protocol: disk.protocol || connection || disk.protocol,
          temperature: disk.temperature ?? match.temperature,
          power_on_hours: disk.power_on_hours ?? match.power_on_hours,
          power_cycles: disk.power_cycles ?? match.power_cycles,
          health: disk.health && !/unknown/i.test(String(disk.health))
            ? disk.health
            : (match.smart_status || match.health || disk.health),
          model: disk.model && !/_nvme$/i.test(String(disk.model))
            ? disk.model
            : (match.model || disk.model),
          serial: disk.serial || match.serial,
          percentage_used: disk.percentage_used ?? match.percentage_used,
        };
      });
    }
  }

  return {
    href: cfg.pveUrl || base,
    openFallbackUrl: cfg.openFallbackUrl || cfg.fallbackUrl || null,
    connectionSource,
    prxHref: cfg.prxUrl || null,
    prxOpenFallbackUrl: cfg.prxOpenFallbackUrl || cfg.prxFallbackUrl || null,
    node,
    online: online && Boolean(glances || status),
    pveOnline: online,
    glancesOnline: Boolean(glances),
    uptime: Number(status.uptime || 0),
    uptimeLabel: fmtUptime(Number(status.uptime || 0)),
    color: cfg.color || "#6ee7b7",
    iface: cfg.iface || "vmbr0",
    backupMount: cfg.backupMount || null,
    label: instanceId,
    cpu: Math.round(Number(status.cpu || 0) * 100),
    memory: { used: memUsed, total: memTotal, percent: percent(memUsed, memTotal) },
    disk: { used: diskUsed, total: diskTotal, percent: percent(diskUsed, diskTotal) },
    vms,
    lxcs,
    storageCount: stores.length,
    overview,
    guests,
    storage: {
      stores,
      disks: enrichedDisks,
      remoteMounts: collectRemoteMounts(glances, stores),
    },
    network: {
      rrd: good("rrd", rrdResult.data, [] as Array<Record<string, unknown>>),
      ifaces,
      flowGuests: guests.items
        .filter((g) => g.status === "running")
        .map((g) => ({
          id: g.id,
          name: g.name,
          type: g.type,
          kind: g.kind,
          status: g.status,
          netin: g.netin,
          netout: g.netout,
        })),
    },
    hardware: good("hardware", (prxHardware as HardwareBlock | null) || null, null as HardwareBlock | null),
    backups: {
      items: nodeBackupItems,
      schedules: good("schedules", backupSchedulesResult.data, [] as Array<Record<string, unknown>>),
    },
    security: await resolveLynisSecurity(instanceId, {
      tools: prxSecurityTools,
      report: prxLynisReport,
    }),
    prxConfigured: Boolean(cfg.prxToken?.trim() && prxTargetsSafe(cfg)),
    updatedAt: Date.now(),
    degraded,
  };
}
