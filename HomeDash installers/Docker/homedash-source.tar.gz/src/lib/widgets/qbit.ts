import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, hasConnectionUrl, openUrlsFromConfig, primaryConnectionUrl } from "@/lib/open-href";
import { invalidateStatusCache } from "@/lib/status-cache";

type QbitConfig = {
  baseUrl: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  /** qBittorrent WebUI API key (Preferences -> WebUI -> API Key). Requires
   *  qBittorrent >= 5.2.0 / WebAPI >= 2.14.1. Sent as a Bearer token on every
   *  request — username/password login is no longer supported by this widget. */
  apiKey: string;
  /** Raw, unmodified config values — kept alongside `baseUrl` (which gets
   *  overwritten with primaryConnectionUrl()'s pick below) so connection
   *  source classification always compares against what was actually
   *  configured, not whichever URL happened to be chosen as primary. */
  rawBaseUrl?: string;
  rawFallbackUrl?: string;
};

/** Which candidate base URL last answered successfully for a given API key.
 *  There's no login/logout round-trip with API-key auth (the key itself is
 *  sent on every request), so this only caches *which* base to use — not a
 *  session. */
type ResolvedBase = { base: string; expiresAt: number };
const resolvedBases = new Map<string, ResolvedBase>();

export type QbitConnectionSource = "private" | "public" | "unknown";

function apiRoot(url: string) {
  return String(url || "").replace(/\/$/, "");
}

function classifyConnectionSource(cfg: QbitConfig, base: string): QbitConnectionSource {
  const normalized = apiRoot(base);
  if (!normalized) return "unknown";
  // Compare against the raw config values, not `cfg.baseUrl` — by this point
  // `cfg.baseUrl` has already been overwritten with primaryConnectionUrl()'s
  // pick, which can silently substitute the wrong URL and mislabel a
  // successful private connection as "public" (or vice versa).
  if (cfg.rawBaseUrl && apiRoot(cfg.rawBaseUrl) === normalized) return "private";
  if (cfg.rawFallbackUrl && apiRoot(cfg.rawFallbackUrl) === normalized) return "public";
  return "unknown";
}

async function config(instanceId: string): Promise<QbitConfig> {
  const cfg = (await readWidgetConfig(instanceId)) as Partial<QbitConfig>;
  if (!hasConnectionUrl(cfg) || !cfg.apiKey) {
    throw new Error("Configure a Private - IP or Fallback Public URL, and an API key in Settings");
  }
  return {
    ...cfg,
    baseUrl: primaryConnectionUrl(cfg),
    rawBaseUrl: cfg.baseUrl,
    rawFallbackUrl: cfg.fallbackUrl,
  } as QbitConfig;
}

function targets(cfg: QbitConfig) {
  return connectionCandidates(cfg).map((url) => url.replace(/\/$/, ""));
}

function authHeaders(cfg: QbitConfig, extra?: HeadersInit): HeadersInit {
  // qBittorrent >= 5.2.0 (WebAPI >= 2.14.1) authenticates API-key requests via
  // a bearer token on every call. There is no session cookie and no
  // login/logout round-trip to perform first.
  return { Authorization: `Bearer ${cfg.apiKey}`, ...(extra || {}) };
}

async function resolveBase(instanceId: string, cfg: QbitConfig) {
  const cached = resolvedBases.get(instanceId);
  if (cached && cached.expiresAt > Date.now()) return cached;

  let lastError: Error | undefined;
  for (const base of targets(cfg)) {
    try {
      // A cheap, always-available endpoint used purely to confirm the API
      // key is accepted at this base URL — no state is created server-side.
      const response = await fetch(joinUrl(base, "/api/v2/app/version"), {
        headers: authHeaders(cfg),
        cache: "no-store",
        signal: AbortSignal.timeout(8000),
      });
      if (response.status === 401 || response.status === 403) {
        throw new Error(
          "qBittorrent rejected the API key. Check it was copied correctly and that qBittorrent is 5.2.0+ (WebAPI 2.14.1+).",
        );
      }
      if (!response.ok) throw new Error(`qBittorrent HTTP ${response.status}`);
      const resolved = { base, expiresAt: Date.now() + 30 * 60_000 };
      resolvedBases.set(instanceId, resolved);
      return resolved;
    } catch (cause) {
      lastError = cause instanceof Error ? cause : new Error("Could not reach qBittorrent");
    }
  }
  throw lastError || new Error("Could not reach qBittorrent");
}

async function api<T>(instanceId: string, path: string, init: RequestInit = {}, retry = true): Promise<T> {
  const cfg = await config(instanceId);
  const resolved = await resolveBase(instanceId, cfg);
  const response = await fetch(joinUrl(resolved.base, `/api/v2${path}`), {
    ...init,
    headers: authHeaders(cfg, init.headers),
    cache: "no-store",
    signal: AbortSignal.timeout(8000),
  });
  if ((response.status === 401 || response.status === 403) && retry) {
    resolvedBases.delete(instanceId);
    return api<T>(instanceId, path, init, false);
  }
  if (!response.ok) throw new Error(`qBittorrent HTTP ${response.status}`);
  if (response.status === 204 || response.headers.get("content-length") === "0") return {} as T;
  const text = await response.text();
  if (!text) return {} as T;
  try {
    return JSON.parse(text) as T;
  } catch {
    // Many qBittorrent action endpoints (torrents/add, /resume, /pause,
    // /recheck, /delete) reply with the plain-text body "Ok." on success
    // instead of JSON. The HTTP status already confirmed success above, so
    // treat any non-JSON body here as a successful no-op result rather than
    // surfacing a JSON parse error ("Unexpected token 'O', "Ok." is not
    // valid JSON") up to the widget's UI.
    return {} as T;
  }
}

export async function fetchQbitStatus(instanceId: string) {
  const cfg = await config(instanceId);
  const [torrents, transfer, main, categoriesMap, preferences] = await Promise.all([
    api<Array<Record<string, unknown>>>(instanceId, "/torrents/info?sort=added_on&reverse=true"),
    api<Record<string, unknown>>(instanceId, "/transfer/info"),
    api<{ server_state?: Record<string, unknown> }>(instanceId, "/sync/maindata"),
    api<Record<string, { name?: string; savePath?: string }>>(instanceId, "/torrents/categories"),
    api<{ save_path?: string }>(instanceId, "/app/preferences"),
  ]);
  const { href, openFallbackUrl } = openUrlsFromConfig(cfg);
  const session = resolvedBases.get(instanceId);
  const categories = Object.keys(categoriesMap || {}).sort((left, right) =>
    left.localeCompare(right, undefined, { sensitivity: "base" }),
  );
  // Each category can carry its own save path in qBittorrent; surface that
  // alongside the category names so the Add Torrent form can auto-fill the
  // save location the moment a category is picked, instead of leaving it on
  // the global default.
  const categorySavePaths: Record<string, string> = {};
  for (const [name, meta] of Object.entries(categoriesMap || {})) {
    if (meta?.savePath) categorySavePaths[name] = meta.savePath;
  }
  return {
    href,
    openFallbackUrl,
    torrents,
    transfer,
    freeSpace: Number(main.server_state?.free_space_on_disk || transfer.free_space_on_disk || 0),
    connectionSource: classifyConnectionSource(cfg, session?.base || ""),
    categories,
    categorySavePaths,
    // The save path configured server-side in qBittorrent's own Settings ->
    // Downloads -> "Default Save Path". Used to pre-fill "Save files to
    // location" in the Add Torrent dialog so it matches qBittorrent's own
    // default rather than sitting empty.
    defaultSavePath: preferences?.save_path || "",
  };
}

const paths: Record<string, string> = {
  resume: "/torrents/resume",
  pause: "/torrents/pause",
  recheck: "/torrents/recheck",
  delete: "/torrents/delete",
};

export async function qbitAction(instanceId: string, action: string, hashes: string, deleteFiles = false) {
  const path = paths[action];
  if (!path) throw new Error("Unsupported qBittorrent action");
  await api(instanceId, path, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams(action === "delete" ? { hashes, deleteFiles: String(deleteFiles) } : { hashes }),
  });
  invalidateStatusCache(`qbit:${instanceId}`);
  return { ok: true };
}

export type AddTorrentParams = {
  urls: string;
  autoTMM: boolean;
  savepath?: string;
  rename?: string;
  category?: string;
  startTorrent: boolean;
  addToTopOfQueue: boolean;
  stopCondition: "None" | "MetadataReceived" | "FilesChecked";
  skipChecking: boolean;
  contentLayout: "Original" | "Subfolder" | "NoSubfolder";
  sequentialDownload: boolean;
  firstLastPiecePrio: boolean;
  dlLimitKib?: number;
  upLimitKib?: number;
};

function magnetHashes(urls: string): string[] {
  const hashes: string[] = [];
  for (const match of urls.matchAll(/urn:btih:([a-fA-F0-9]{40}|[a-zA-Z2-7]{32})/g)) {
    hashes.push(match[1].toLowerCase());
  }
  return hashes;
}

export async function qbitAddTorrent(instanceId: string, params: AddTorrentParams) {
  const form: Record<string, string> = {
    urls: params.urls,
    autoTMM: String(params.autoTMM),
    paused: String(!params.startTorrent),
    skip_checking: String(params.skipChecking),
    contentLayout: params.contentLayout,
    sequentialDownload: String(params.sequentialDownload),
    firstLastPiecePrio: String(params.firstLastPiecePrio),
  };
  if (!params.autoTMM && params.savepath) form.savepath = params.savepath;
  if (params.rename) form.rename = params.rename;
  if (params.category) form.category = params.category;
  if (params.stopCondition !== "None") form.stopCondition = params.stopCondition;
  if (params.dlLimitKib) form.dlLimit = String(Math.round(params.dlLimitKib * 1024));
  if (params.upLimitKib) form.upLimit = String(Math.round(params.upLimitKib * 1024));

  await api(instanceId, "/torrents/add", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams(form),
  });

  if (params.addToTopOfQueue) {
    const hashes = magnetHashes(params.urls);
    if (hashes.length) {
      // Best-effort: only magnet links carry a hash we can target directly;
      // .torrent-file URLs are queued by qBittorrent without one available here.
      await api(instanceId, "/torrents/topPrio", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({ hashes: hashes.join("|") }),
      }).catch(() => {});
    }
  }

  invalidateStatusCache(`qbit:${instanceId}`);
  return { ok: true };
}
