import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import {
  connectionCandidates,
  hasConnectionUrl,
  isPrivateConnectionUrl,
  primaryConnectionUrl,
} from "@/lib/open-href";
import { cachedStatus, invalidateStatusCache } from "@/lib/status-cache";

type Config = {
  baseUrl: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  apiKey: string;
  username?: string;
  password?: string;
};

export type SeerrRequest = {
  id: number;
  status: number;
  is4k?: boolean;
  serverId?: number;
  createdAt?: string;
  updatedAt?: string;
  seasons?: Array<{ seasonNumber: number; status: number }>;
  requestedBy?: { displayName?: string; username?: string };
  media?: {
    mediaType?: string;
    tmdbId?: number;
    status?: number;
    title?: string;
    name?: string;
    posterPath?: string | null;
    radarrId?: number | null;
    sonarrId?: number | null;
    radarrId4k?: number | null;
    sonarrId4k?: number | null;
    serviceId?: number;
    serviceId4k?: number;
  };
};

export type SeerrSearchItem = {
  id: number;
  mediaType: string;
  title?: string;
  name?: string;
  releaseDate?: string;
  firstAirDate?: string;
  posterPath?: string | null;
  backdropPath?: string | null;
  overview?: string;
  voteAverage?: number;
  mediaInfo?: { status?: number; seasons?: Array<{ seasonNumber: number; status: number }> };
};

type MediaMeta = { title: string; posterPath: string | null };

export type SeerrConnectionSource = "private" | "public" | "unknown";

function apiRoot(url: string) {
  return String(url || "").replace(/\/$/, "");
}

async function classifyConnectionSource(
  instanceId: string,
  base: string,
): Promise<SeerrConnectionSource> {
  const raw = (await readWidgetConfig(instanceId)) as Partial<Config>;
  const normalized = apiRoot(base);
  if (raw.baseUrl && apiRoot(raw.baseUrl) === normalized) return "private";
  if (raw.publicUrl && apiRoot(raw.publicUrl) === normalized) return "private";
  if (raw.fallbackUrl && apiRoot(raw.fallbackUrl) === normalized) return "public";
  if (raw.openFallbackUrl && apiRoot(raw.openFallbackUrl) === normalized) return "public";
  return "unknown";
}

const MEDIA_META_TTL_MS = 6 * 60 * 60 * 1000;
const mediaMetaCache = new Map<string, { expiresAt: number; value: MediaMeta }>();
const mediaMetaInflight = new Map<string, Promise<MediaMeta>>();

const STATUS_TAKE = 40;
const ENRICH_CONCURRENCY = 16;

async function loadConfig(instanceId: string): Promise<Config> {
  const value = (await readWidgetConfig(instanceId)) as Partial<Config>;
  const hasAnyUrl = [value.baseUrl, value.fallbackUrl, value.publicUrl, value.openFallbackUrl].some(
    Boolean,
  );
  if (!hasAnyUrl || !value.apiKey) {
    throw new Error("Configure a Private - IP or Fallback Public URL, and API key in Settings");
  }
  return { ...value, baseUrl: primaryConnectionUrl(value) } as Config;
}

function headers(apiKey: string, extra: Record<string, string> = {}) {
  return {
    "Content-Type": "application/json",
    "X-Api-Key": apiKey,
    ...extra,
  };
}

class SeerrHttpError extends Error {
  status?: number;
  constructor(message: string, status?: number) {
    super(message);
    this.name = "SeerrHttpError";
    this.status = status;
  }
}

/** Cache for Seerr session cookies. */
const sessionCache = new Map<string, { cookie: string; expiresAt: number }>();

async function getSessionCookie(config: Config, baseUrl: string): Promise<string | null> {
  if (!config.username || !config.password) return null;

  const cacheKey = `${baseUrl}:${config.username}`;
  const hit = sessionCache.get(cacheKey);
  if (hit && hit.expiresAt > Date.now()) return hit.cookie;

  const authEndpoints = ["/api/v1/auth/jellyfin", "/api/v1/auth/local"];

  for (const endpoint of authEndpoints) {
    try {
      const response = await fetch(joinUrl(baseUrl, endpoint), {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Api-Key": config.apiKey },
        body: JSON.stringify({
          username: config.username,
          email: config.username,
          password: config.password
        }),
        cache: "no-store",
        signal: AbortSignal.timeout(10_000),
      });

      if (response.ok) {
        const setCookie = response.headers.get("set-cookie");
        if (setCookie) {
          const cookie = setCookie.split(";")[0];
          sessionCache.set(cacheKey, { cookie, expiresAt: Date.now() + 24 * 60 * 60 * 1000 });
          return cookie;
        }
      }
    } catch {
      continue;
    }
  }
  return null;
}

async function seerrFetch<T>(
  config: Config,
  path: string,
  init: RequestInit = {},
): Promise<{ data: T; baseUrl: string }> {
  let last: unknown;
  const bases = Array.from(
    new Set(
      [config.baseUrl, config.fallbackUrl, config.publicUrl, config.openFallbackUrl].filter(
        Boolean,
      ) as string[],
    ),
  ).sort((a, b) => Number(isPrivateConnectionUrl(b)) - Number(isPrivateConnectionUrl(a)));

  const isMutation = ["POST", "PUT", "DELETE"].includes(init.method || "GET");

  for (const base of bases) {
    try {
      const fetchHeaders: Record<string, string> = {
        ...headers(config.apiKey),
        ...(init.headers as Record<string, string> | undefined),
      };

      if (isMutation) {
        const cookie = await getSessionCookie(config, base);
        if (cookie) fetchHeaders["Cookie"] = cookie;
      }

      const response = await fetch(joinUrl(base, `/api/v1${path}`), {
        ...init,
        headers: fetchHeaders,
        cache: "no-store",
        signal: AbortSignal.timeout(15_000),
      });

      const text = await response.text();
      let data: T;
      try {
        data = text ? JSON.parse(text) : (null as T);
      } catch {
        if (!response.ok) {
          throw new SeerrHttpError(
            `Seerr error (${init.method || "GET"} ${path}, HTTP ${response.status})`,
            response.status,
          );
        }
        throw new Error(`Invalid JSON response from Seerr (${init.method || "GET"} ${path}, HTTP ${response.status})`);
      }

      if (!response.ok) {
        const upstreamMessage = (data as any)?.message || (data as any)?.error;
        throw new SeerrHttpError(
          `${upstreamMessage || "Seerr error"} (${init.method || "GET"} ${path}, HTTP ${response.status})`,
          response.status,
        );
      }
      return { data, baseUrl: base };
    } catch (error) {
      last = error;
      if (isMutation && error instanceof SeerrHttpError && (error.status === 401 || error.status === 403)) {
        sessionCache.delete(`${base}:${config.username}`);
      }
    }
  }
  throw last instanceof Error ? last : new Error("Seerr unavailable");
}

function readMediaMeta(key: string): MediaMeta | undefined {
  const hit = mediaMetaCache.get(key);
  if (!hit) return undefined;
  if (hit.expiresAt <= Date.now()) {
    mediaMetaCache.delete(key);
    return undefined;
  }
  return hit.value;
}

function writeMediaMeta(key: string, value: MediaMeta) {
  mediaMetaCache.set(key, { value, expiresAt: Date.now() + MEDIA_META_TTL_MS });
}

async function enrichMedia(config: Config, mediaType: string, tmdbId: number): Promise<MediaMeta> {
  const key = `${mediaType}:${tmdbId}`;
  const cached = readMediaMeta(key);
  if (cached) return cached;

  const pending = mediaMetaInflight.get(key);
  if (pending) return pending;

  const promise = (async () => {
    try {
      const endpoint = mediaType === "tv" ? `/tv/${tmdbId}` : `/movie/${tmdbId}`;
      const { data } = await seerrFetch<{
        title?: string;
        name?: string;
        originalTitle?: string;
        originalName?: string;
        posterPath?: string | null;
      }>(config, endpoint);
      const info: MediaMeta = {
        title: data.title || data.name || data.originalTitle || data.originalName || "Unknown",
        posterPath: data.posterPath || null,
      };
      writeMediaMeta(key, info);
      return info;
    } catch {
      const info: MediaMeta = { title: "Unknown", posterPath: null };
      mediaMetaCache.set(key, { value: info, expiresAt: Date.now() + 60_000 });
      return info;
    } finally {
      mediaMetaInflight.delete(key);
    }
  })();

  mediaMetaInflight.set(key, promise);
  return promise;
}

async function mapPool<T, R>(items: T[], concurrency: number, worker: (item: T) => Promise<R>) {
  const results: R[] = new Array(items.length);
  let next = 0;
  async function run() {
    while (next < items.length) {
      const index = next++;
      results[index] = await worker(items[index]);
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, items.length || 1) }, () => run()));
  return results;
}

async function enrichRequestList(config: Config, raw: SeerrRequest[]): Promise<SeerrRequest[]> {
  const needingEnrich: Array<{ mediaType: string; tmdbId: number }> = [];
  const seen = new Set<string>();

  for (const req of raw) {
    const mt = req.media?.mediaType;
    const tid = req.media?.tmdbId;
    if (!mt || !tid) continue;
    const key = `${mt}:${tid}`;
    if (seen.has(key)) continue;
    seen.add(key);

    const existingTitle = req.media?.title || req.media?.name;
    const existingPoster = req.media?.posterPath;
    if (existingTitle && existingPoster) {
      writeMediaMeta(key, { title: existingTitle, posterPath: existingPoster });
      continue;
    }
    if (readMediaMeta(key)) continue;
    needingEnrich.push({ mediaType: mt, tmdbId: tid });
  }

  await mapPool(needingEnrich, ENRICH_CONCURRENCY, async (entry) => {
    await enrichMedia(config, entry.mediaType, entry.tmdbId);
  });

  return raw.map((req) => {
    const mt = req.media?.mediaType;
    const tid = req.media?.tmdbId;
    const detail = mt && tid ? readMediaMeta(`${mt}:${tid}`) : undefined;
    return {
      ...req,
      media: {
        ...req.media,
        title: detail?.title || req.media?.title || req.media?.name || "Unknown",
        posterPath: detail?.posterPath || req.media?.posterPath || null,
      },
    };
  });
}

async function seerrStatusUncached(instanceId: string) {
  const config = await loadConfig(instanceId);

  const params = new URLSearchParams({
    take: String(STATUS_TAKE),
    skip: "0",
    sort: "added",
  });
  const [{ data: counts, baseUrl: activeBase }, { data: requestPage }] = await Promise.all([
    seerrFetch<Record<string, number>>(config, "/request/count"),
    seerrFetch<{ results?: SeerrRequest[] }>(config, `/request?${params}`),
  ]);

  const raw = requestPage?.results || [];
  const requests = await enrichRequestList(config, raw);

  return {
    counts: counts || {},
    requests,
    publicUrl: config.publicUrl?.trim() || config.baseUrl,
    openFallbackUrl: config.openFallbackUrl?.trim() || config.fallbackUrl?.trim() || "",
    connectionSource: await classifyConnectionSource(instanceId, activeBase),
  };
}

export async function seerrStatus(instanceId: string) {
  return cachedStatus(`seerr:${instanceId}`, 45_000, () => seerrStatusUncached(instanceId));
}

export function invalidateSeerrStatus(instanceId: string) {
  invalidateStatusCache(`seerr:${instanceId}`);
}

export async function seerrSearch(instanceId: string, query: string) {
  const config = await loadConfig(instanceId);
  if (!query.trim())
    return {
      results: [] as SeerrSearchItem[],
      publicUrl: config.publicUrl || config.baseUrl,
      openFallbackUrl: config.openFallbackUrl?.trim() || config.fallbackUrl?.trim() || "",
    };
  const { data } = await seerrFetch<{ results?: SeerrSearchItem[] } | SeerrSearchItem[]>(
    config,
    `/search?query=${encodeURIComponent(query)}&page=1&language=en`,
  );
  const results = Array.isArray(data)
    ? data
    : Array.isArray(data?.results)
      ? data.results
      : [];
  return {
    results: results
      .filter((item) => item.mediaType === "movie" || item.mediaType === "tv")
      .slice(0, 9),
    publicUrl: config.publicUrl?.trim() || config.baseUrl,
    openFallbackUrl: config.openFallbackUrl?.trim() || config.fallbackUrl?.trim() || "",
  };
}

export async function seerrMediaDetail(instanceId: string, mediaType: string, mediaId: number) {
  const config = await loadConfig(instanceId);
  const path = mediaType === "tv" ? `/tv/${mediaId}` : `/movie/${mediaId}`;
  const { data } = await seerrFetch<Record<string, unknown>>(config, path);
  return {
    detail: data,
    publicUrl: config.publicUrl?.trim() || config.baseUrl,
    openFallbackUrl: config.openFallbackUrl?.trim() || config.fallbackUrl?.trim() || "",
  };
}

export type SeerrLibrary = { id: string; name: string; enabled: boolean };

/**
 * Reads the configured Jellyfin/Emby libraries.
 * Seerr exposes these as part of the main /settings/jellyfin payload
 * (GET /api/v1/settings/jellyfin -> { ..., libraries: SeerrLibrary[] }),
 * not from a dedicated /settings/jellyfin/library[/ies] resource.
 */
export async function seerrLibraries(instanceId: string) {
  const config = await loadConfig(instanceId);
  const { data } = await seerrFetch<{ libraries?: SeerrLibrary[] }>(config, "/settings/jellyfin");
  return { libraries: data?.libraries || [] };
}

/**
 * Triggers a fresh library sync from the media server.
 * Seerr's real endpoint is GET /api/v1/settings/jellyfin/library?sync=true,
 * optionally with an `enable` query param (comma-separated library IDs) to
 * keep already-enabled libraries enabled across the resync. It responds to
 * the sync call itself with sync-status, so we re-fetch settings afterward
 * for the up-to-date library list.
 */
export async function seerrSyncLibraries(instanceId: string) {
  const config = await loadConfig(instanceId);
  const { libraries: current } = await seerrLibraries(instanceId);
  const activeIds = current.filter((lib) => lib.enabled).map((lib) => lib.id);

  const query = new URLSearchParams({ sync: "true" });
  if (activeIds.length > 0) query.set("enable", activeIds.join(","));

  await seerrFetch(config, `/settings/jellyfin/library?${query.toString()}`);
  // A library sync can change which media is now processed/available in
  // Jellyfin, so the widget's cached Processing/Available/Missing counts
  // must not be served stale after this call.
  invalidateSeerrStatus(instanceId);
  return seerrLibraries(instanceId);
}

/**
 * Enables/disables a single library.
 * Seerr has no per-library PUT/POST endpoint - the toggle is a single
 * GET /api/v1/settings/jellyfin/library?enable=id1,id2,... call carrying the
 * *full* desired set of enabled library IDs (omit `enable` entirely to
 * disable all of them). We compute that set from the current libraries,
 * apply the toggle, and re-fetch settings for the resulting state.
 */
export async function seerrSetLibraryEnabled(
  instanceId: string,
  libraryId: string,
  enabled: boolean,
) {
  const config = await loadConfig(instanceId);
  const { libraries: current } = await seerrLibraries(instanceId);
  const activeIds = current.filter((lib) => lib.enabled).map((lib) => lib.id);

  const nextIds = enabled
    ? Array.from(new Set([...activeIds, libraryId]))
    : activeIds.filter((id) => id !== libraryId);

  const query = new URLSearchParams();
  if (nextIds.length > 0) query.set("enable", nextIds.join(","));
  const qs = query.toString();

  await seerrFetch(config, `/settings/jellyfin/library${qs ? `?${qs}` : ""}`);
  return seerrLibraries(instanceId);
}

export type SeerrSyncStatus = {
  running: boolean;
  progress: number;
  total: number;
  currentLibrary?: SeerrLibrary;
  libraries: SeerrLibrary[];
};

/**
 * Status of Seerr's manual/scheduled full library scan (media availability
 * scan), as shown by the progress bar in Seerr's own settings UI.
 * GET /api/v1/settings/jellyfin/sync
 */
export async function seerrSyncStatus(instanceId: string): Promise<SeerrSyncStatus> {
  const config = await loadConfig(instanceId);
  const { data } = await seerrFetch<Partial<SeerrSyncStatus>>(config, "/settings/jellyfin/sync");
  return {
    running: !!data?.running,
    progress: data?.progress ?? 0,
    total: data?.total ?? 0,
    currentLibrary: data?.currentLibrary,
    libraries: data?.libraries || [],
  };
}

/** Starts a full manual library scan. POST /api/v1/settings/jellyfin/sync { start: true } */
export async function seerrStartLibraryScan(instanceId: string) {
  const config = await loadConfig(instanceId);
  await seerrFetch(config, "/settings/jellyfin/sync", {
    method: "POST",
    body: JSON.stringify({ start: true }),
  });
  invalidateSeerrStatus(instanceId);
  return seerrSyncStatus(instanceId);
}

/** Cancels an in-progress library scan. POST /api/v1/settings/jellyfin/sync { cancel: true } */
export async function seerrCancelLibraryScan(instanceId: string) {
  const config = await loadConfig(instanceId);
  await seerrFetch(config, "/settings/jellyfin/sync", {
    method: "POST",
    body: JSON.stringify({ cancel: true }),
  });
  invalidateSeerrStatus(instanceId);
  return seerrSyncStatus(instanceId);
}

export async function seerrServices(instanceId: string, type: "radarr" | "sonarr") {
  const config = await loadConfig(instanceId);
  const { data } = await seerrFetch<
    Array<{
      id: number;
      name: string;
      isDefault?: boolean;
      activeDirectory?: string;
    }>
  >(config, `/service/${type}`);
  return { services: data || [] };
}

export async function seerrServiceDetail(
  instanceId: string,
  type: "radarr" | "sonarr",
  id: number,
) {
  const config = await loadConfig(instanceId);
  const { data } = await seerrFetch<{
    rootFolders?: Array<{ path: string; freeSpace?: number }>;
  }>(config, `/service/${type}/${id}`);
  return { detail: data || {} };
}

export async function seerrRequestAction(
  instanceId: string,
  requestId: number,
  action: "approve" | "decline",
) {
  const config = await loadConfig(instanceId);
  await seerrFetch(config, `/request/${requestId}/${action}`, { method: "POST" });
  invalidateSeerrStatus(instanceId);
  return { ok: true };
}

export async function seerrCreateRequest(
  instanceId: string,
  body: {
    mediaType: string;
    mediaId: number;
    seasons?: number[];
    serverId?: number | null;
    rootFolder?: string | null;
  },
) {
  const config = await loadConfig(instanceId);
  const payload: Record<string, unknown> = {
    mediaType: body.mediaType,
    mediaId: body.mediaId,
  };
  if (body.mediaType === "tv") {
    payload.seasons = body.seasons?.length ? body.seasons : [1];
  }
  if (body.serverId != null) payload.serverId = body.serverId;
  if (body.rootFolder) payload.rootFolder = body.rootFolder;

  await seerrFetch(config, "/request", {
    method: "POST",
    body: JSON.stringify(payload),
  });
  invalidateSeerrStatus(instanceId);
  return { ok: true };
}

export async function seerrProcessing(instanceId: string) {
  const config = await loadConfig(instanceId);
  const params = new URLSearchParams({
    take: String(STATUS_TAKE),
    skip: "0",
    filter: "processing",
  });
  const { data, baseUrl: activeBase } = await seerrFetch<{ results?: SeerrRequest[] }>(config, `/request?${params}`);
  const requests = await enrichRequestList(config, data?.results || []);
  return {
    requests,
    publicUrl: config.publicUrl?.trim() || config.baseUrl,
    openFallbackUrl: config.openFallbackUrl?.trim() || config.fallbackUrl?.trim() || "",
    connectionSource: await classifyConnectionSource(instanceId, activeBase),
  };
}

/** Ask Seerr to re-send a request to Radarr/Sonarr (POST /request/{id}/retry). */
export async function seerrRetryRequest(instanceId: string, requestId: number) {
  const config = await loadConfig(instanceId);
  await seerrFetch(config, `/request/${requestId}/retry`, { method: "POST" });
  invalidateSeerrStatus(instanceId);
  return { ok: true };
}

export async function seerrDeleteRequest(instanceId: string, requestId: number) {
  const config = await loadConfig(instanceId);
  await seerrFetch(config, `/request/${requestId}`, { method: "DELETE" });
  invalidateSeerrStatus(instanceId);
  return { ok: true };
}

export type SeerrServiceConfig = {
  id: number;
  name: string;
  hostname: string;
  port: number;
  apiKey: string;
  useSsl?: boolean;
  baseUrl?: string;
  externalUrl?: string;
};

/** Build a link to this request's movie/series page in Radarr/Sonarr. */
export async function seerrArrLink(instanceId: string, requestId: number) {
  const config = await loadConfig(instanceId);
  const { data: request } = await seerrFetch<SeerrRequest>(config, `/request/${requestId}`);
  const media = request?.media as (NonNullable<SeerrRequest["media"]> & {
    serviceUrl?: string;
    externalServiceSlug?: string;
  }) | undefined;
  if (!media) return { url: "", label: "" };
  const mediaType = media.mediaType || (media.sonarrId ? "tv" : "movie");
  const serviceType = mediaType === "tv" ? "sonarr" : "radarr";
  const label = serviceType === "sonarr" ? "Sonarr" : "Radarr";
  const is4k = !!request?.is4k;
  const arrId = is4k
    ? mediaType === "tv"
      ? media.sonarrId4k
      : media.radarrId4k
    : mediaType === "tv"
      ? media.sonarrId
      : media.radarrId;
  if (!arrId) return { url: "", label };

  const serviceId = is4k ? media.serviceId4k : media.serviceId;
  const { data: services } = await seerrFetch<SeerrServiceConfig[]>(config, `/service/${serviceType}`);
  const service =
    (services || []).find((s) => s.id === serviceId) ||
    (services || []).find((s) => s.id === request?.serverId) ||
    (services || [])[0];
  const page = serviceType === "sonarr" ? "series" : "movie";

  // Browser-facing base: Seerr's configured external URL, else host:port.
  let base = "";
  if (service?.externalUrl?.trim()) {
    base = service.externalUrl.trim().replace(/\/+$/, "");
  } else if (service?.hostname && service.port) {
    const proto = service.useSsl ? "https" : "http";
    base = `${proto}://${service.hostname}:${service.port}${(service.baseUrl || "").replace(/\/+$/, "")}`;
  } else if (media.serviceUrl) {
    return { url: media.serviceUrl, label };
  }
  if (!base) return { url: "", label };

  // Resolve the page slug from the *arr itself; fall back to what Seerr stored.
  let slug = "";
  if (service?.hostname && service.port && service.apiKey) {
    try {
      const proto = service.useSsl ? "https" : "http";
      const apiBase = `${proto}://${service.hostname}:${service.port}${(service.baseUrl || "").replace(/\/+$/, "")}`;
      const res = await fetch(`${apiBase}/api/v3/${page === "series" ? "series" : "movie"}/${arrId}`, {
        headers: { "X-Api-Key": service.apiKey },
        cache: "no-store",
        signal: AbortSignal.timeout(6_000),
      });
      if (res.ok) {
        const json = (await res.json()) as { titleSlug?: string };
        slug = String(json.titleSlug || "");
      }
    } catch {
      /* use fallback slug */
    }
  }
  if (!slug) slug = media.externalServiceSlug || (serviceType === "radarr" && media.tmdbId ? String(media.tmdbId) : "");
  if (!slug) return { url: "", label };
  return { url: `${base}/${page}/${encodeURIComponent(slug)}`, label };
}

export async function seerrRemoveFromArr(instanceId: string, requestId: number) {
  const config = await loadConfig(instanceId);
  const { data: request } = await seerrFetch<SeerrRequest>(config, `/request/${requestId}`);
  const media = request?.media;
  if (!media) throw new Error("Request has no linked media");
  const mediaType = media.mediaType || (media.sonarrId ? "tv" : "movie");
  const serviceType = mediaType === "tv" ? "sonarr" : "radarr";
  const is4k = !!request?.is4k;
  const arrId = is4k
    ? mediaType === "tv"
      ? media.sonarrId4k
      : media.radarrId4k
    : mediaType === "tv"
      ? media.sonarrId
      : media.radarrId;
  if (!arrId) throw new Error(`No ${serviceType} ID linked to this request`);
  const serviceId = is4k ? media.serviceId4k : media.serviceId;
  const { data: services } = await seerrFetch<SeerrServiceConfig[]>(config, `/service/${serviceType}`);
  const service =
    (services || []).find((s) => s.id === serviceId) ||
    (services || []).find((s) => s.id === request?.serverId) ||
    (services || [])[0];
  if (!service) throw new Error(`No ${serviceType} server configured in Seerr`);
  if (!service.hostname || !service.port || !service.apiKey) {
    throw new Error(`${service.name || serviceType} is missing hostname/port/API key in Seerr`);
  }
  const proto = service.useSsl ? "https" : "http";
  const base = `${service.baseUrl || ""}`.replace(/\/+$/, "");
  const resource = serviceType === "sonarr" ? "series" : "movie";
  const url = `${proto}://${service.hostname}:${service.port}${base}/api/v3/${resource}/${arrId}?deleteFiles=true`;
  const response = await fetch(url, {
    method: "DELETE",
    headers: { "X-Api-Key": service.apiKey },
    cache: "no-store",
    signal: AbortSignal.timeout(10_000),
  });
  if (!response.ok) {
    throw new Error(`${service.name || serviceType} delete failed (HTTP ${response.status})`);
  }
  invalidateSeerrStatus(instanceId);
  return { ok: true, serviceType, serviceName: service.name };
}
