import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, hasConnectionUrl, primaryConnectionUrl } from "@/lib/open-href";

type Config = {
  baseUrl: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  username?: string;
  password?: string;
};

function openFallbackFor(cfg: Config) {
  return (cfg.openFallbackUrl || cfg.fallbackUrl || "").trim();
}

type Session = { cookie: string; base: string; expiresAt: number };
const sessions = new Map<string, Session>();
const SESSION_TTL_MS = 30 * 60_000;

const ACTIVE_BUCKETS = new Set(["queued", "resolving", "locating", "downloading"]);
const DONE_BUCKETS = new Set(["complete"]);
const FAIL_BUCKETS = new Set(["error", "cancelled"]);

type SmTask = {
  title?: string;
  author?: string;
  preview?: string;
  progress?: number;
  status_message?: string;
  status?: string;
  bucket?: string;
  content_type?: string;
  format?: string;
  added_time?: number;
  [key: string]: unknown;
};

type SmRequest = {
  status?: string;
  delivery_state?: string;
  created_at?: string;
  book_data?: { title?: string; author?: string; name?: string };
  release_data?: { title?: string; author?: string };
  [key: string]: unknown;
};

type Snapshot = {
  status?: Record<string, Record<string, SmTask>>;
  requests?: SmRequest[];
};

function bases(cfg: Config) {
  return connectionCandidates(cfg).map((u) => u.replace(/\/$/, ""));
}

async function loadConfig(instanceId: string): Promise<Config> {
  const value = (await readWidgetConfig(instanceId)) as Partial<Config>;
  if (!hasConnectionUrl(value)) {
    throw new Error("Configure a Private - IP or Fallback Public URL in Settings");
  }
  if (!value.username || !value.password) {
    throw new Error("Configure Shelfmark username and password in Settings");
  }
  return { ...value, baseUrl: primaryConnectionUrl(value) } as Config;
}

function cookieHeaderFrom(response: Response) {
  const getSetCookie = (response.headers as Headers & { getSetCookie?: () => string[] }).getSetCookie;
  const parts = typeof getSetCookie === "function" ? getSetCookie.call(response.headers) : [];
  if (parts.length) {
    return parts.map((c) => c.split(";")[0]?.trim()).filter(Boolean).join("; ");
  }
  const raw = response.headers.get("set-cookie") || "";
  if (!raw) return "";
  return raw
    .split(/,(?=[^;]+?=)/)
    .map((c) => c.split(";")[0]?.trim())
    .filter(Boolean)
    .join("; ");
}

async function ensureSession(instanceId: string, cfg: Config): Promise<Session> {
  const cached = sessions.get(instanceId);
  if (cached && cached.expiresAt > Date.now()) return cached;

  let last: unknown;
  for (const base of bases(cfg)) {
    try {
      const checkRes = await fetch(joinUrl(base, "/api/auth/check"), {
        cache: "no-store",
        signal: AbortSignal.timeout(8_000),
      });
      if (checkRes.ok) {
        const check = (await checkRes.json().catch(() => ({}))) as {
          auth_required?: boolean;
          authenticated?: boolean;
        };
        if (check.auth_required === false || check.authenticated) {
          const cookie = cookieHeaderFrom(checkRes) || sessions.get(instanceId)?.cookie || "";
          const session = { cookie, base, expiresAt: Date.now() + SESSION_TTL_MS };
          sessions.set(instanceId, session);
          return session;
        }
      }

      const loginRes = await fetch(joinUrl(base, "/api/auth/login"), {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({
          username: cfg.username,
          password: cfg.password,
          remember_me: true,
        }),
        cache: "no-store",
        signal: AbortSignal.timeout(8_000),
      });
      const loginData = (await loginRes.json().catch(() => ({}))) as { error?: string };
      if (!loginRes.ok || loginData.error) {
        throw new Error(loginData.error || `Shelfmark login ${loginRes.status}`);
      }
      const cookie = cookieHeaderFrom(loginRes);
      if (!cookie) throw new Error("Shelfmark did not return a session cookie");
      const session = { cookie, base, expiresAt: Date.now() + SESSION_TTL_MS };
      sessions.set(instanceId, session);
      return session;
    } catch (error) {
      last = error;
    }
  }
  throw last instanceof Error ? last : new Error("Could not authenticate with Shelfmark");
}

async function apiFetch<T>(instanceId: string, cfg: Config, path: string, retry = true): Promise<{ data: T; href: string }> {
  const session = await ensureSession(instanceId, cfg);
  const res = await fetch(joinUrl(session.base, path), {
    headers: {
      Accept: "application/json",
      ...(session.cookie ? { Cookie: session.cookie } : {}),
    },
    cache: "no-store",
    signal: AbortSignal.timeout(12_000),
  });
  if ((res.status === 401 || res.status === 403) && retry) {
    sessions.delete(instanceId);
    return apiFetch(instanceId, cfg, path, false);
  }
  if (!res.ok) throw new Error(`Shelfmark HTTP ${res.status}`);
  if (res.status === 204) return { data: null as T, href: session.base };
  return { data: (await res.json()) as T, href: session.base };
}

function flattenTasks(statusObj: Snapshot["status"]): SmTask[] {
  const tasks: SmTask[] = [];
  if (!statusObj || typeof statusObj !== "object") return tasks;
  for (const [bucket, items] of Object.entries(statusObj)) {
    if (!items || typeof items !== "object") continue;
    for (const task of Object.values(items)) {
      if (task && typeof task === "object") tasks.push({ ...task, bucket });
    }
  }
  return tasks;
}

function sortTasks(tasks: SmTask[]) {
  return tasks.slice().sort((a, b) => (b.added_time || 0) - (a.added_time || 0));
}

function requestTitle(req: SmRequest) {
  const book = req.book_data || {};
  const release = req.release_data || {};
  return book.title || release.title || book.name || "Untitled request";
}

function requestAuthor(req: SmRequest) {
  const book = req.book_data || {};
  const release = req.release_data || {};
  return book.author || release.author || "";
}

function mapTask(task: SmTask) {
  return {
    title: task.title || "Unknown",
    author: task.author || "",
    preview: task.preview || "",
    progress: Number(task.progress) || 0,
    status: task.status_message || task.status || task.bucket || "",
    bucket: task.bucket || "",
    type: String(task.content_type || task.format || "").replace(/_/g, " "),
  };
}

export async function shelfmarkStatus(instanceId: string, tab = "overview") {
  const cfg = await loadConfig(instanceId);
  const { data: snap, href } = await apiFetch<Snapshot>(instanceId, cfg, "/api/activity/snapshot");
  const tasks = sortTasks(flattenTasks(snap?.status));
  const requests = Array.isArray(snap?.requests) ? snap.requests : [];
  const key = (tab || "overview").toLowerCase();

  if (key === "active") {
    return {
      href,
      openFallbackUrl: openFallbackFor(cfg),
      tab: "active",
      items: tasks.filter((t) => ACTIVE_BUCKETS.has(String(t.bucket))).slice(0, 16).map(mapTask),
    };
  }

  if (key === "recent") {
    return {
      href,
      openFallbackUrl: openFallbackFor(cfg),
      tab: "recent",
      items: tasks.filter((t) => DONE_BUCKETS.has(String(t.bucket))).slice(0, 16).map(mapTask),
    };
  }

  if (key === "requests") {
    return {
      href,
      openFallbackUrl: openFallbackFor(cfg),
      tab: "requests",
      items: requests.slice(0, 16).map((req) => ({
        title: requestTitle(req),
        author: requestAuthor(req),
        status: req.status || "pending",
        delivery: req.delivery_state || "",
        createdAt: req.created_at || "",
      })),
    };
  }

  const active = tasks.filter((t) => ACTIVE_BUCKETS.has(String(t.bucket))).length;
  const complete = tasks.filter((t) => DONE_BUCKETS.has(String(t.bucket))).length;
  const failed = tasks.filter((t) => FAIL_BUCKETS.has(String(t.bucket))).length;
  const pendingRequests = requests.filter((r) => String(r.status || "").toLowerCase() === "pending").length;

  return {
    href,
    openFallbackUrl: openFallbackFor(cfg),
    tab: "overview",
    active,
    complete,
    failed,
    pendingRequests,
    recent: tasks.filter((t) => DONE_BUCKETS.has(String(t.bucket))).slice(0, 6).map(mapTask),
    requests: requests.slice(0, 6).map((req) => ({
      title: requestTitle(req),
      author: requestAuthor(req),
      status: req.status || "pending",
    })),
  };
}

export async function shelfmarkCover(instanceId: string, previewPath: string) {
  if (!previewPath) throw new Error("Missing preview path");
  if (/^https?:\/\//i.test(previewPath)) {
    const res = await fetch(previewPath, { cache: "no-store", signal: AbortSignal.timeout(12_000) });
    if (!res.ok) throw new Error(`Shelfmark cover HTTP ${res.status}`);
    return res;
  }
  const cfg = await loadConfig(instanceId);
  const session = await ensureSession(instanceId, cfg);
  const path = previewPath.startsWith("/") ? previewPath : `/${previewPath}`;
  const res = await fetch(joinUrl(session.base, path), {
    headers: {
      Accept: "image/*",
      ...(session.cookie ? { Cookie: session.cookie } : {}),
    },
    cache: "no-store",
    signal: AbortSignal.timeout(12_000),
  });
  if (!res.ok) throw new Error(`Shelfmark cover HTTP ${res.status}`);
  return res;
}
