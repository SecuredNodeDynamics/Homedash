import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, hasConnectionUrl, openUrlsFromConfig, primaryConnectionUrl } from "@/lib/open-href";

type Config = {
  baseUrl?: string;
  fallbackUrl?: string;
  apiKey?: string;
  serverId?: string;
  color?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
};

type SpeedResult = {
  download: number;
  upload: number;
  ping: number;
  jitter: number;
  isp: string;
  server: string;
  resultUrl: string;
  createdAt: string;
};

export type SpeedtestConnectionSource = "private" | "public" | "unknown";

function apiRoot(url: string) {
  return String(url || "").replace(/\/$/, "");
}

// Classifies which URL a request actually connected through. This must compare
// against the raw config values (read fresh from config), not `cfg.baseUrl` —
// by the time a caller holds `cfg`, `cfg.baseUrl` has already been passed through
// `primaryConnectionUrl()`, which can substitute the fallback URL as "primary"
// and would otherwise cause a successful private connection to be mislabeled
// as public (or vice versa).
async function classifyConnectionSource(
  id: string,
  base: string,
): Promise<SpeedtestConnectionSource> {
  const raw = (await readWidgetConfig(id)) as Config;
  const normalized = apiRoot(base);
  if (raw.baseUrl && apiRoot(raw.baseUrl) === normalized) return "private";
  if (raw.fallbackUrl && apiRoot(raw.fallbackUrl) === normalized) return "public";
  return "unknown";
}

async function loadConfig(id: string) {
  const value = (await readWidgetConfig(id)) as Config;
  if (!hasConnectionUrl(value) || !value.apiKey?.trim()) {
    throw new Error("Configure a Private - IP or Fallback Public URL, and API key in Settings");
  }
  return {
    baseUrl: primaryConnectionUrl(value),
    fallbackUrl: value.fallbackUrl?.trim() || "",
    apiKey: value.apiKey.trim(),
    serverId: value.serverId?.trim() || "",
    color: value.color?.trim() || "#22c55e",
    publicUrl: value.publicUrl?.trim() || "",
    openFallbackUrl: value.openFallbackUrl?.trim() || "",
  };
}

async function api(id: string, path: string, init?: RequestInit) {
  const cfg = await loadConfig(id);
  let lastError: unknown;
  for (const base of connectionCandidates(cfg)) {
    try {
      const response = await fetch(joinUrl(base, path), {
        ...init,
        headers: {
          Authorization: `Bearer ${cfg.apiKey}`,
          Accept: "application/json",
          ...(init?.body ? { "Content-Type": "application/json" } : {}),
          ...init?.headers,
        },
        cache: "no-store",
        signal: AbortSignal.timeout(init?.method === "POST" ? 120_000 : 10_000),
      });
      if (!response.ok) throw new Error(`Speedtest HTTP ${response.status}`);
      const { href, openFallbackUrl } = openUrlsFromConfig(cfg);
      return {
        data: await response.json().catch(() => null),
        href: href || base,
        openFallbackUrl,
        accent: cfg.color,
        serverId: cfg.serverId,
        connectionSource: await classifyConnectionSource(id, base),
      };
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("Speedtest unavailable");
}

function mapResult(raw: Record<string, unknown> | null | undefined): SpeedResult | null {
  if (!raw) return null;
  const nested = (raw.data || {}) as Record<string, unknown>;
  const ping = (nested.ping || {}) as Record<string, unknown>;
  const server = (nested.server || {}) as Record<string, unknown>;
  const result = (nested.result || {}) as Record<string, unknown>;
  return {
    download: Number(raw.download || 0),
    upload: Number(raw.upload || 0),
    ping: Number(raw.ping || 0),
    jitter: Number(ping.jitter || nested.jitter || 0),
    isp: String(nested.isp || ""),
    server: String(server.name || server.host || ""),
    resultUrl: String(result.url || ""),
    createdAt: String(raw.created_at || ""),
  };
}

export type SpeedHistoryPoint = {
  download: number;
  upload: number;
  ping: number;
  createdAt: string;
};

export async function fetchSpeedtestStatus(id: string) {
  const { data, href, openFallbackUrl, accent, connectionSource } = await api(
    id,
    "/api/v1/results?per_page=24&sort=-created_at",
  );
  const rows = Array.isArray(data?.data) ? (data.data as Array<Record<string, unknown>>) : [];
  const mapped = rows.map(mapResult).filter((row): row is SpeedResult => Boolean(row));
  const history: SpeedHistoryPoint[] = [...mapped]
    .reverse()
    .map((row) => ({
      download: row.download,
      upload: row.upload,
      ping: row.ping,
      createdAt: row.createdAt,
    }));

  const downloads = history.map((row) => row.download).filter((value) => value > 0);
  const uploads = history.map((row) => row.upload).filter((value) => value > 0);
  const pings = history.map((row) => row.ping).filter((value) => value > 0);
  const avg = (values: number[]) =>
    values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0;

  return {
    href,
    openFallbackUrl,
    accent,
    connectionSource,
    latest: mapped[0] || null,
    history,
    stats: {
      downloadAvg: avg(downloads),
      downloadPeak: downloads.length ? Math.max(...downloads) : 0,
      uploadAvg: avg(uploads),
      uploadPeak: uploads.length ? Math.max(...uploads) : 0,
      pingAvg: avg(pings),
      pingBest: pings.length ? Math.min(...pings) : 0,
      samples: history.length,
    },
  };
}

export async function runSpeedtest(id: string) {
  const cfg = await loadConfig(id);
  const body = cfg.serverId ? { serverId: Number(cfg.serverId) } : {};
  await api(id, "/api/v1/speedtests/run", {
    method: "POST",
    body: JSON.stringify(body),
  });
  return { ok: true };
}
