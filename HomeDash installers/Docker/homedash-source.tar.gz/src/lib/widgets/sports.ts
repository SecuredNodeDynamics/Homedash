export type SportKey = "soccer" | "football" | "golf" | "basketball" | "baseball" | "tennis";

export type EventState = "pre" | "in" | "post";

export type SportCompetitor = {
  id: string;
  name: string;
  abbrev: string;
  score: string;
  winner: boolean;
  logo: string;
};

export type SportEvent = {
  id: string;
  rawId: string;
  sport: SportKey;
  league: string;
  sportPath: string;
  leaguePath: string;
  name: string;
  shortName: string;
  state: EventState;
  statusDetail: string;
  startTime: string;
  venue: string;
  network: string;
  competitors: SportCompetitor[];
  href: string;
};

// A game can show a gamecast (injuries / last five / standings) when it's a
// team sport with two identified competitors — not for golf/tennis fields.
export function isGamecastable(event: SportEvent): boolean {
  return (
    isTeamSport(event.sport) &&
    event.competitors.length === 2 &&
    event.competitors.every((c) => c.id)
  );
}

export type SportSummary = {
  events: SportEvent[];
  liveCount: number;
  todayCount: number;
  error?: string;
};

export type SportsStatus = {
  updatedAt: string;
  sports: Record<SportKey, SportSummary>;
};

export const SPORT_ORDER: SportKey[] = [
  "soccer",
  "football",
  "golf",
  "basketball",
  "baseball",
  "tennis",
];

export const SPORT_META: Record<SportKey, { label: string; icon: string; color: string }> = {
  soccer: { label: "Soccer", icon: "⚽", color: "#4ade80" },
  football: { label: "Football", icon: "🏈", color: "#fb923c" },
  golf: { label: "Golf", icon: "⛳", color: "#a3e635" },
  basketball: { label: "Basketball", icon: "🏀", color: "#f97316" },
  baseball: { label: "Baseball", icon: "⚾", color: "#38bdf8" },
  tennis: { label: "Tennis", icon: "🎾", color: "#facc15" },
};

// ESPN's unauthenticated "site" API — same data that powers espn.com's public
// scoreboards. No API key. Some sports query more than one league/tour and
// the results are merged so "compare sports" reflects the whole day, not a
// single competition.
type EndpointSource = { url: string; league: string; sportPath: string; leaguePath: string };

const ENDPOINTS: Record<SportKey, EndpointSource[]> = {
  soccer: [
    { url: "https://site.api.espn.com/apis/site/v2/sports/soccer/eng.1/scoreboard", league: "Premier League", sportPath: "soccer", leaguePath: "eng.1" },
    { url: "https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.champions/scoreboard", league: "Champions League", sportPath: "soccer", leaguePath: "uefa.champions" },
    { url: "https://site.api.espn.com/apis/site/v2/sports/soccer/usa.1/scoreboard", league: "MLS", sportPath: "soccer", leaguePath: "usa.1" },
  ],
  football: [
    { url: "https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard", league: "NFL", sportPath: "football", leaguePath: "nfl" },
  ],
  golf: [
    { url: "https://site.api.espn.com/apis/site/v2/sports/golf/pga/scoreboard", league: "PGA Tour", sportPath: "golf", leaguePath: "pga" },
  ],
  basketball: [
    { url: "https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard", league: "NBA", sportPath: "basketball", leaguePath: "nba" },
  ],
  baseball: [
    { url: "https://site.api.espn.com/apis/site/v2/sports/baseball/mlb/scoreboard", league: "MLB", sportPath: "baseball", leaguePath: "mlb" },
  ],
  tennis: [
    { url: "https://site.api.espn.com/apis/site/v2/sports/tennis/atp/scoreboard", league: "ATP", sportPath: "tennis", leaguePath: "atp" },
    { url: "https://site.api.espn.com/apis/site/v2/sports/tennis/wta/scoreboard", league: "WTA", sportPath: "tennis", leaguePath: "wta" },
  ],
};

type RawTeam = {
  displayName?: string;
  shortDisplayName?: string;
  abbreviation?: string;
  logo?: string;
};

type RawAthlete = {
  displayName?: string;
  shortName?: string;
  headshot?: { href?: string };
};

type RawCompetitor = {
  order?: number;
  score?: string | number;
  winner?: boolean;
  team?: RawTeam;
  athlete?: RawAthlete;
};

type RawEvent = {
  id?: string;
  name?: string;
  shortName?: string;
  date?: string;
  links?: Array<{ href?: string }>;
  status?: { type?: { state?: string; detail?: string; shortDetail?: string } };
  competitions?: Array<{
    venue?: { fullName?: string };
    status?: { type?: { state?: string; detail?: string; shortDetail?: string } };
    competitors?: RawCompetitor[];
    broadcasts?: Array<{ names?: string[] }>;
    geoBroadcasts?: Array<{ media?: { shortName?: string } }>;
  }>;
};

type RawCompetition = NonNullable<RawEvent["competitions"]>[number];

function competitionNetwork(competition: RawCompetition | undefined): string {
  const names = (competition?.broadcasts || []).flatMap((b) => b.names || []).filter(Boolean);
  if (names.length) return Array.from(new Set(names)).join(", ");
  const geo = (competition?.geoBroadcasts || []).map((g) => g.media?.shortName).filter((n): n is string => Boolean(n));
  if (geo.length) return Array.from(new Set(geo)).join(", ");
  return "";
}

function competitorName(c: RawCompetitor) {
  return c.team?.shortDisplayName || c.team?.displayName || c.athlete?.displayName || "TBD";
}

function competitorAbbrev(c: RawCompetitor) {
  return c.team?.abbreviation || c.athlete?.shortName || competitorName(c).slice(0, 3).toUpperCase();
}

type RawCompetitorWithId = RawCompetitor & { id?: string | number; team?: RawTeam & { id?: string | number }; athlete?: RawAthlete & { id?: string | number } };

function mapEvent(raw: RawEvent, sport: SportKey, source: EndpointSource): SportEvent | null {
  if (!raw.id) return null;
  const competition = raw.competitions?.[0];
  const statusType = raw.status?.type || competition?.status?.type || {};
  const state = ((statusType.state as EventState) || "pre") as EventState;
  const rawCompetitors = (Array.isArray(competition?.competitors) ? competition!.competitors! : []) as RawCompetitorWithId[];
  const isFieldSport = sport === "golf" || sport === "tennis";

  const competitors: SportCompetitor[] = rawCompetitors
    .slice()
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
    .slice(0, isFieldSport ? 5 : rawCompetitors.length)
    .map((c) => ({
      id: String(c.team?.id ?? c.athlete?.id ?? c.id ?? ""),
      name: competitorName(c),
      abbrev: competitorAbbrev(c),
      score: c.score != null ? String(c.score) : "",
      winner: Boolean(c.winner),
      logo: c.team?.logo || c.athlete?.headshot?.href || "",
    }));

  return {
    id: `${sport}-${source.league}-${raw.id}`,
    rawId: String(raw.id),
    sport,
    league: source.league,
    sportPath: source.sportPath,
    leaguePath: source.leaguePath,
    name: raw.name || raw.shortName || "Event",
    shortName: raw.shortName || raw.name || "",
    state,
    statusDetail: statusType.shortDetail || statusType.detail || "",
    startTime: raw.date || "",
    venue: competition?.venue?.fullName || "",
    network: competitionNetwork(competition),
    competitors,
    href: raw.links?.[0]?.href || "",
  };
}

async function fetchEspn<T>(url: string): Promise<T> {
  const response = await fetch(url, {
    cache: "no-store",
    signal: AbortSignal.timeout(10_000),
    headers: { "User-Agent": "Mozilla/5.0 (compatible; Homedash/1.0)" },
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return (await response.json()) as T;
}

async function fetchOne(source: EndpointSource, sport: SportKey): Promise<SportEvent[]> {
  const data = await fetchEspn<{ events?: RawEvent[] }>(source.url);
  const events = Array.isArray(data?.events) ? data.events : [];
  return events
    .map((event) => mapEvent(event, sport, source))
    .filter((event): event is SportEvent => event !== null);
}

async function fetchSportEvents(sport: SportKey): Promise<SportEvent[]> {
  const sources = ENDPOINTS[sport];
  const results = await Promise.allSettled(sources.map((source) => fetchOne(source, sport)));
  const events = results.flatMap((result) => (result.status === "fulfilled" ? result.value : []));
  const allFailed = results.every((result) => result.status === "rejected");
  if (allFailed && results.length) {
    const first = results[0];
    throw first.status === "rejected" && first.reason instanceof Error
      ? first.reason
      : new Error(`Failed to load ${sport} scores`);
  }
  return events;
}

export async function sportsStatus(): Promise<SportsStatus> {
  const results = await Promise.allSettled(SPORT_ORDER.map((sport) => fetchSportEvents(sport)));
  const now = new Date();
  const todayKey = now.toISOString().slice(0, 10);
  const sports = {} as Record<SportKey, SportSummary>;

  SPORT_ORDER.forEach((sport, index) => {
    const result = results[index];
    if (result.status === "fulfilled") {
      const events = result.value.slice().sort((a, b) => a.startTime.localeCompare(b.startTime));
      sports[sport] = {
        events,
        liveCount: events.filter((event) => event.state === "in").length,
        todayCount: events.filter((event) => event.startTime.slice(0, 10) === todayKey).length,
      };
    } else {
      sports[sport] = {
        events: [],
        liveCount: 0,
        todayCount: 0,
        error: result.reason instanceof Error ? result.reason.message : "Failed to load",
      };
    }
  });

  return { updatedAt: now.toISOString(), sports };
}

// =====================================================================
// Teams, team stats & player (roster / statistical leader) data.
//
// Golf and tennis are individual sports — there's nothing to "pick a
// team" for, so the widget instead lets people compare two athletes
// already appearing in that sport's current events (handled client-side
// from data we already fetch above). Soccer, football, basketball and
// baseball are team sports and get a real team picker + comparison
// backed by ESPN's team & roster endpoints below.
// =====================================================================

export type TeamSport = "soccer" | "football" | "basketball" | "baseball";

export const TEAM_SPORTS: TeamSport[] = ["soccer", "football", "basketball", "baseball"];

export function isTeamSport(sport: SportKey): sport is TeamSport {
  return (TEAM_SPORTS as SportKey[]).includes(sport);
}

export type LeagueOption = { leaguePath: string; sportPath: string; label: string };

export const TEAM_LEAGUES: Record<TeamSport, LeagueOption[]> = {
  soccer: [
    { sportPath: "soccer", leaguePath: "eng.1", label: "Premier League" },
    { sportPath: "soccer", leaguePath: "uefa.champions", label: "Champions League" },
    { sportPath: "soccer", leaguePath: "usa.1", label: "MLS" },
  ],
  football: [{ sportPath: "football", leaguePath: "nfl", label: "NFL" }],
  basketball: [{ sportPath: "basketball", leaguePath: "nba", label: "NBA" }],
  baseball: [{ sportPath: "baseball", leaguePath: "mlb", label: "MLB" }],
};

export type TeamSummary = {
  id: string;
  name: string;
  shortName: string;
  abbrev: string;
  logo: string;
};

type RawTeamsResponse = {
  sports?: Array<{ leagues?: Array<{ teams?: Array<{ team?: RawTeamSummary }> }> }>;
};

type RawTeamSummary = {
  id?: string;
  displayName?: string;
  shortDisplayName?: string;
  name?: string;
  abbreviation?: string;
  logos?: Array<{ href?: string }>;
};

export async function fetchTeams(sportPath: string, leaguePath: string): Promise<TeamSummary[]> {
  const url = `https://site.api.espn.com/apis/site/v2/sports/${sportPath}/${leaguePath}/teams?limit=200`;
  const data = await fetchEspn<RawTeamsResponse>(url);
  const raw = data.sports?.[0]?.leagues?.[0]?.teams ?? [];
  return raw
    .map((entry) => entry.team)
    .filter((team): team is RawTeamSummary => Boolean(team && team.id))
    .map((team) => ({
      id: String(team.id),
      name: team.displayName || team.name || "",
      shortName: team.shortDisplayName || team.name || team.displayName || "",
      abbrev: team.abbreviation || "",
      logo: team.logos?.[0]?.href || "",
    }))
    .filter((team) => team.name)
    .sort((a, b) => a.name.localeCompare(b.name));
}

export type StatItem = { name: string; label: string; value: string };

export type TeamLeader = {
  category: string;
  athleteName: string;
  athleteHeadshot: string;
  value: string;
};

export type RosterPlayer = {
  id: string;
  name: string;
  jersey: string;
  position: string;
  headshot: string;
};

export type TeamDetail = {
  id: string;
  name: string;
  logo: string;
  color: string;
  recordSummary: string;
  standingSummary: string;
  stats: StatItem[];
  leaders: TeamLeader[];
  roster: RosterPlayer[];
};

type RawStatItem = { name?: string; shortDisplayName?: string; displayName?: string; displayValue?: string };
type RawRecordItem = { type?: string; summary?: string; stats?: RawStatItem[] };
type RawLeaderEntry = {
  displayValue?: string;
  athlete?: { displayName?: string; headshot?: { href?: string } };
};
type RawLeaderCategory = { name?: string; displayName?: string; shortDisplayName?: string; leaders?: RawLeaderEntry[] };

type RawTeamDetailResponse = {
  team?: {
    id?: string;
    displayName?: string;
    color?: string;
    logos?: Array<{ href?: string }>;
    standingSummary?: string;
    record?: { items?: RawRecordItem[] };
    leaders?: RawLeaderCategory[];
  };
};

type RawRosterAthlete = {
  id?: string | number;
  displayName?: string;
  fullName?: string;
  jersey?: string;
  position?: { abbreviation?: string; name?: string };
  headshot?: { href?: string };
};

type RawRosterResponse = {
  athletes?: Array<RawRosterAthlete | { items?: RawRosterAthlete[] }>;
};

async function fetchTeamRoster(sportPath: string, leaguePath: string, teamId: string): Promise<RosterPlayer[]> {
  const url = `https://site.api.espn.com/apis/site/v2/sports/${sportPath}/${leaguePath}/teams/${teamId}/roster`;
  const data = await fetchEspn<RawRosterResponse>(url);
  const groups = Array.isArray(data.athletes) ? data.athletes : [];
  const flat: RawRosterAthlete[] = [];
  for (const group of groups) {
    if (group && Array.isArray((group as { items?: RawRosterAthlete[] }).items)) {
      flat.push(...((group as { items?: RawRosterAthlete[] }).items || []));
    } else if (group && "displayName" in group) {
      flat.push(group as RawRosterAthlete);
    }
  }
  return flat
    .map((athlete) => ({
      id: String(athlete.id ?? ""),
      name: athlete.displayName || athlete.fullName || "",
      jersey: athlete.jersey || "",
      position: athlete.position?.abbreviation || athlete.position?.name || "",
      headshot: athlete.headshot?.href || "",
    }))
    .filter((player) => player.name);
}

export async function fetchTeamDetail(sportPath: string, leaguePath: string, teamId: string): Promise<TeamDetail> {
  const [teamResult, rosterResult] = await Promise.allSettled([
    fetchEspn<RawTeamDetailResponse>(
      `https://site.api.espn.com/apis/site/v2/sports/${sportPath}/${leaguePath}/teams/${teamId}`,
    ),
    fetchTeamRoster(sportPath, leaguePath, teamId),
  ]);

  if (teamResult.status === "rejected") {
    throw teamResult.reason instanceof Error ? teamResult.reason : new Error("Failed to load team");
  }

  const team = teamResult.value.team || {};
  const overallRecord = team.record?.items?.find((item) => item.type === "total") || team.record?.items?.[0];
  const stats: StatItem[] = (overallRecord?.stats || [])
    .filter((stat) => stat.displayValue != null)
    .map((stat) => ({
      name: stat.name || "",
      label: stat.shortDisplayName || stat.displayName || stat.name || "",
      value: stat.displayValue || "",
    }));

  const leaders: TeamLeader[] = [];
  for (const category of team.leaders || []) {
    const top = category.leaders?.[0];
    if (!top) continue;
    leaders.push({
      category: category.shortDisplayName || category.displayName || category.name || "",
      athleteName: top.athlete?.displayName || "",
      athleteHeadshot: top.athlete?.headshot?.href || "",
      value: top.displayValue || "",
    });
  }

  return {
    id: team.id || teamId,
    name: team.displayName || "",
    logo: team.logos?.[0]?.href || "",
    color: team.color ? `#${team.color}` : "",
    recordSummary: overallRecord?.summary || "",
    standingSummary: team.standingSummary || "",
    stats,
    leaders,
    roster: rosterResult.status === "fulfilled" ? rosterResult.value : [],
  };
}

// =====================================================================
// Standings — league table, grouped by conference/division when the
// league has them (NFL/NBA/MLB), flat when it doesn't (soccer).
// =====================================================================

export type StandingsRow = {
  teamId: string;
  name: string;
  abbrev: string;
  logo: string;
  wins: string;
  losses: string;
  pct: string;
  gamesBack: string;
  streak: string;
};

export type StandingsGroup = {
  label: string;
  rows: StandingsRow[];
};

type RawStandingsStat = { name?: string; displayValue?: string };
type RawStandingsEntry = {
  team?: { id?: string; displayName?: string; abbreviation?: string; logos?: Array<{ href?: string }> };
  stats?: RawStandingsStat[];
};
type RawStandingsGroup = {
  name?: string;
  standings?: { entries?: RawStandingsEntry[] };
  children?: RawStandingsGroup[];
};
type RawStandingsResponse = {
  children?: RawStandingsGroup[];
  standings?: { entries?: RawStandingsEntry[] };
};

function statValue(stats: RawStandingsStat[] | undefined, name: string): string {
  return stats?.find((s) => s.name === name)?.displayValue ?? "";
}

function mapStandingsEntry(entry: RawStandingsEntry): StandingsRow {
  return {
    teamId: entry.team?.id || "",
    name: entry.team?.displayName || "",
    abbrev: entry.team?.abbreviation || "",
    logo: entry.team?.logos?.[0]?.href || "",
    wins: statValue(entry.stats, "wins"),
    losses: statValue(entry.stats, "losses"),
    pct: statValue(entry.stats, "winPercent"),
    gamesBack: statValue(entry.stats, "gamesBehind"),
    streak: statValue(entry.stats, "streak"),
  };
}

// Recurse through the (possibly nested — conference > division) group tree
// and flatten to leaf groups that actually contain entries.
function flattenStandingsGroups(groups: RawStandingsGroup[] | undefined, prefix = ""): StandingsGroup[] {
  const out: StandingsGroup[] = [];
  for (const group of groups || []) {
    const label = prefix ? `${prefix} ${group.name || ""}`.trim() : group.name || "";
    if (group.standings?.entries?.length) {
      out.push({ label, rows: group.standings.entries.map(mapStandingsEntry) });
    }
    if (group.children?.length) {
      out.push(...flattenStandingsGroups(group.children, label));
    }
  }
  return out;
}

export async function fetchStandings(sportPath: string, leaguePath: string): Promise<StandingsGroup[]> {
  const url = `https://site.api.espn.com/apis/v2/sports/${sportPath}/${leaguePath}/standings`;
  const data = await fetchEspn<RawStandingsResponse>(url);
  if (data.children?.length) return flattenStandingsGroups(data.children);
  if (data.standings?.entries?.length) {
    return [{ label: "", rows: data.standings.entries.map(mapStandingsEntry) }];
  }
  return [];
}

// =====================================================================
// News — league headlines for the "latest" rail.
// =====================================================================

export type NewsItem = {
  id: string;
  headline: string;
  description: string;
  image: string;
  href: string;
  published: string;
};

type RawNewsArticle = {
  headline?: string;
  description?: string;
  published?: string;
  images?: Array<{ url?: string }>;
  links?: { web?: { href?: string } };
};

export async function fetchNews(sportPath: string, leaguePath: string): Promise<NewsItem[]> {
  const url = `https://site.api.espn.com/apis/site/v2/sports/${sportPath}/${leaguePath}/news`;
  const data = await fetchEspn<{ articles?: RawNewsArticle[] }>(url);
  return (data.articles || [])
    .filter((a) => a.headline)
    .slice(0, 8)
    .map((a, i) => ({
      id: String(i),
      headline: a.headline || "",
      description: a.description || "",
      image: a.images?.[0]?.url || "",
      href: a.links?.web?.href || "",
      published: a.published || "",
    }));
}

// =====================================================================
// Game detail (gamecast) — injury report + each team's last five games,
// mirroring what ESPN shows on a matchup page.
// =====================================================================

export type InjuryEntry = {
  athleteName: string;
  position: string;
  status: string;
  detail: string;
};

export type TeamInjuries = {
  teamId: string;
  teamName: string;
  teamLogo: string;
  injuries: InjuryEntry[];
};

export type RecentGame = {
  date: string;
  opponentAbbrev: string;
  opponentLogo: string;
  result: string; // e.g. "W 112-108"
  home: boolean;
};

export type GameDetail = {
  venue: string;
  city: string;
  startTime: string;
  network: string;
  injuries: TeamInjuries[];
  recentGames: Record<string, RecentGame[]>; // keyed by teamId
};

type RawInjuryDetail = { type?: string; returnDate?: string };
type RawInjuryItem = {
  status?: string;
  details?: RawInjuryDetail;
  athlete?: { displayName?: string; position?: { abbreviation?: string } };
};
type RawInjuryGroup = { team?: { id?: string; displayName?: string; logos?: Array<{ href?: string }>; logo?: string }; injuries?: RawInjuryItem[] };
type RawSummaryResponse = {
  gameInfo?: { venue?: { fullName?: string; address?: { city?: string; state?: string } } };
  injuries?: RawInjuryGroup[];
  header?: {
    competitions?: Array<{ date?: string; broadcasts?: Array<{ names?: string[] }> }>;
  };
};

async function fetchGameSummary(sportPath: string, leaguePath: string, eventId: string): Promise<RawSummaryResponse> {
  const url = `https://site.api.espn.com/apis/site/v2/sports/${sportPath}/${leaguePath}/summary?event=${encodeURIComponent(eventId)}`;
  return fetchEspn<RawSummaryResponse>(url);
}

type RawScheduleEvent = {
  date?: string;
  competitions?: Array<{
    status?: { type?: { state?: string } };
    competitors?: Array<{ homeAway?: string; winner?: boolean; score?: { displayValue?: string }; team?: { id?: string; abbreviation?: string; logo?: string; logos?: Array<{ href?: string }> } }>;
  }>;
};

async function fetchTeamRecentGames(sportPath: string, leaguePath: string, teamId: string): Promise<RecentGame[]> {
  const url = `https://site.api.espn.com/apis/site/v2/sports/${sportPath}/${leaguePath}/teams/${teamId}/schedule`;
  const data = await fetchEspn<{ events?: RawScheduleEvent[] }>(url);
  const events = Array.isArray(data.events) ? data.events : [];
  const played = events.filter((e) => e.competitions?.[0]?.status?.type?.state === "post");
  played.sort((a, b) => (b.date || "").localeCompare(a.date || ""));
  return played.slice(0, 5).map((event) => {
    const competition = event.competitions![0];
    const competitors = competition.competitors || [];
    const self = competitors.find((c) => String(c.team?.id) === String(teamId));
    const opponent = competitors.find((c) => String(c.team?.id) !== String(teamId));
    const won = Boolean(self?.winner);
    return {
      date: event.date || "",
      opponentAbbrev: opponent?.team?.abbreviation || "",
      opponentLogo: opponent?.team?.logo || opponent?.team?.logos?.[0]?.href || "",
      result: `${won ? "W" : "L"} ${self?.score?.displayValue || ""}-${opponent?.score?.displayValue || ""}`,
      home: self?.homeAway === "home",
    };
  });
}

export async function fetchGameDetail(
  sportPath: string,
  leaguePath: string,
  eventId: string,
  teamIds: [string, string],
): Promise<GameDetail> {
  const [summaryResult, gamesAResult, gamesBResult] = await Promise.allSettled([
    fetchGameSummary(sportPath, leaguePath, eventId),
    fetchTeamRecentGames(sportPath, leaguePath, teamIds[0]),
    fetchTeamRecentGames(sportPath, leaguePath, teamIds[1]),
  ]);

  const summary = summaryResult.status === "fulfilled" ? summaryResult.value : {};
  const competitionMeta = summary.header?.competitions?.[0];

  const injuries: TeamInjuries[] = (summary.injuries || []).map((group) => ({
    teamId: group.team?.id || "",
    teamName: group.team?.displayName || "",
    teamLogo: group.team?.logos?.[0]?.href || group.team?.logo || "",
    injuries: (group.injuries || []).map((item) => ({
      athleteName: item.athlete?.displayName || "",
      position: item.athlete?.position?.abbreviation || "",
      status: item.status || "",
      detail: item.details?.type || "",
    })),
  }));

  const recentGames: Record<string, RecentGame[]> = {};
  recentGames[teamIds[0]] = gamesAResult.status === "fulfilled" ? gamesAResult.value : [];
  recentGames[teamIds[1]] = gamesBResult.status === "fulfilled" ? gamesBResult.value : [];

  return {
    venue: summary.gameInfo?.venue?.fullName || "",
    city: [summary.gameInfo?.venue?.address?.city, summary.gameInfo?.venue?.address?.state].filter(Boolean).join(", "),
    startTime: competitionMeta?.date || "",
    network: (competitionMeta?.broadcasts || []).flatMap((b) => b.names || []).join(", "),
    injuries,
    recentGames,
  };
}
