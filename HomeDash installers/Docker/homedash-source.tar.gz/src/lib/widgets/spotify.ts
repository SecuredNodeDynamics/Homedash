import { readWidgetConfig } from "@/lib/config";

// ── Types ───────────────────────────────────────────────────────────────

export type SpotifyDevice = {
  id: string | null;
  name: string;
  type: string;
  isActive: boolean;
  isPrivateSession: boolean;
  volumePercent: number | null;
};

export type SpotifyTrack = {
  id: string | null;
  name: string;
  artists: string;
  album: string;
  albumArtUrl: string | null;
  durationMs: number;
  uri: string | null;
  externalUrl: string | null;
};

export type SpotifyPlaybackState = {
  isPlaying: boolean;
  progressMs: number | null;
  shuffle: boolean;
  repeat: "off" | "track" | "context";
  device: SpotifyDevice | null;
  track: SpotifyTrack | null;
};

export type SpotifyRecentItem = {
  playedAt: string;
  track: SpotifyTrack;
};

export type SpotifyPlaylist = {
  id: string;
  name: string;
  ownerName: string;
  trackCount: number;
  imageUrl: string | null;
  uri: string;
  externalUrl: string | null;
};

export type SpotifyStatus = {
  playback: SpotifyPlaybackState | null;
  playbackError: string | null;
  recentlyPlayed: SpotifyRecentItem[];
  devices: SpotifyDevice[];
  playlists: SpotifyPlaylist[];
};

type SpotifyConfig = {
  clientId: string;
  clientSecret: string;
  refreshToken: string;
};

// ── Config + token handling ────────────────────────────────────────────

export async function loadSpotifyConfig(instanceId: string): Promise<SpotifyConfig> {
  const config = (await readWidgetConfig(instanceId)) as Partial<SpotifyConfig>;
  if (!config.clientId || !config.clientSecret) {
    throw new Error("Add a Spotify Client ID and Client Secret in Settings");
  }
  if (!config.refreshToken) {
    throw new Error("Add a Spotify Refresh Token in Settings");
  }
  return {
    clientId: config.clientId,
    clientSecret: config.clientSecret,
    refreshToken: config.refreshToken,
  };
}

type CachedToken = { accessToken: string; expiresAt: number };
const tokenCache = new Map<string, CachedToken>();

async function getAccessToken(instanceId: string, config: SpotifyConfig): Promise<string> {
  const cached = tokenCache.get(instanceId);
  if (cached && cached.expiresAt - 30_000 > Date.now()) {
    return cached.accessToken;
  }

  const basic = Buffer.from(`${config.clientId}:${config.clientSecret}`).toString("base64");
  const response = await fetch("https://accounts.spotify.com/api/token", {
    method: "POST",
    headers: {
      Authorization: `Basic ${basic}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: new URLSearchParams({
      grant_type: "refresh_token",
      refresh_token: config.refreshToken,
    }),
    cache: "no-store",
    signal: AbortSignal.timeout(10000),
  });

  if (!response.ok) {
    if (response.status === 400 || response.status === 401) {
      throw new Error("Spotify rejected the Client ID/Secret or Refresh Token");
    }
    throw new Error(`Spotify token refresh returned ${response.status}`);
  }

  const json = await response.json();
  const accessToken = String(json.access_token || "");
  const expiresInMs = (Number(json.expires_in) || 3600) * 1000;
  if (!accessToken) throw new Error("Spotify did not return an access token");

  tokenCache.set(instanceId, { accessToken, expiresAt: Date.now() + expiresInMs });
  return accessToken;
}

async function spotifyFetch(
  instanceId: string,
  config: SpotifyConfig,
  path: string,
  init: RequestInit = {},
): Promise<Response> {
  const accessToken = await getAccessToken(instanceId, config);
  const response = await fetch(`https://api.spotify.com/v1${path}`, {
    ...init,
    headers: {
      ...(init.headers || {}),
      Authorization: `Bearer ${accessToken}`,
      Accept: "application/json",
    },
    cache: "no-store",
    signal: AbortSignal.timeout(10000),
  });

  if (response.status === 401) {
    // Access token may have been invalidated early — refresh once and retry.
    tokenCache.delete(instanceId);
    const retryToken = await getAccessToken(instanceId, config);
    return fetch(`https://api.spotify.com/v1${path}`, {
      ...init,
      headers: {
        ...(init.headers || {}),
        Authorization: `Bearer ${retryToken}`,
        Accept: "application/json",
      },
      cache: "no-store",
      signal: AbortSignal.timeout(10000),
    });
  }

  return response;
}

// ── Normalizers ─────────────────────────────────────────────────────────

function toTrack(raw: Record<string, unknown> | null | undefined): SpotifyTrack | null {
  if (!raw || !raw.id) return null;
  const artists = Array.isArray(raw.artists)
    ? (raw.artists as Record<string, unknown>[]).map((a) => String(a.name ?? "")).filter(Boolean).join(", ")
    : "";
  const album = (raw.album || {}) as Record<string, unknown>;
  const images = Array.isArray(album.images) ? (album.images as Record<string, unknown>[]) : [];
  const externalUrls = (raw.external_urls || {}) as Record<string, unknown>;
  return {
    id: String(raw.id),
    name: String(raw.name ?? "Unknown track"),
    artists: artists || "Unknown artist",
    album: String(album.name ?? ""),
    albumArtUrl: images.length ? String(images[0].url ?? "") || null : null,
    durationMs: Number(raw.duration_ms) || 0,
    uri: typeof raw.uri === "string" ? raw.uri : null,
    externalUrl: typeof externalUrls.spotify === "string" ? externalUrls.spotify : null,
  };
}

function toDevice(raw: Record<string, unknown>): SpotifyDevice {
  return {
    id: raw.id ? String(raw.id) : null,
    name: String(raw.name ?? "Unknown device"),
    type: String(raw.type ?? ""),
    isActive: Boolean(raw.is_active),
    isPrivateSession: Boolean(raw.is_private_session),
    volumePercent: typeof raw.volume_percent === "number" ? raw.volume_percent : null,
  };
}

function toPlaylist(raw: Record<string, unknown>): SpotifyPlaylist {
  const images = Array.isArray(raw.images) ? (raw.images as Record<string, unknown>[]) : [];
  const owner = (raw.owner || {}) as Record<string, unknown>;
  const tracks = (raw.tracks || {}) as Record<string, unknown>;
  const externalUrls = (raw.external_urls || {}) as Record<string, unknown>;
  return {
    id: String(raw.id ?? ""),
    name: String(raw.name ?? "Untitled playlist"),
    ownerName: String(owner.display_name ?? ""),
    trackCount: Number(tracks.total) || 0,
    imageUrl: images.length ? String(images[0].url ?? "") || null : null,
    uri: String(raw.uri ?? ""),
    externalUrl: typeof externalUrls.spotify === "string" ? externalUrls.spotify : null,
  };
}

// ── Status ──────────────────────────────────────────────────────────────

async function fetchPlayback(instanceId: string, config: SpotifyConfig): Promise<SpotifyPlaybackState | null> {
  const response = await spotifyFetch(instanceId, config, "/me/player?additional_types=track");
  if (response.status === 204) return null;
  if (!response.ok) throw new Error(`Spotify player status returned ${response.status}`);
  const json = await response.json();
  if (!json || !json.item) return null;
  return {
    isPlaying: Boolean(json.is_playing),
    progressMs: typeof json.progress_ms === "number" ? json.progress_ms : null,
    shuffle: Boolean(json.shuffle_state),
    repeat: json.repeat_state === "track" || json.repeat_state === "context" ? json.repeat_state : "off",
    device: json.device ? toDevice(json.device) : null,
    track: toTrack(json.item),
  };
}

async function fetchRecentlyPlayed(instanceId: string, config: SpotifyConfig): Promise<SpotifyRecentItem[]> {
  const response = await spotifyFetch(instanceId, config, "/me/player/recently-played?limit=20");
  if (!response.ok) throw new Error(`Spotify recently-played returned ${response.status}`);
  const json = await response.json();
  const items = Array.isArray(json?.items) ? json.items : [];
  return items
    .map((row: Record<string, unknown>) => {
      const track = toTrack(row.track as Record<string, unknown>);
      if (!track) return null;
      return { playedAt: String(row.played_at ?? ""), track };
    })
    .filter(Boolean) as SpotifyRecentItem[];
}

async function fetchDevices(instanceId: string, config: SpotifyConfig): Promise<SpotifyDevice[]> {
  const response = await spotifyFetch(instanceId, config, "/me/player/devices");
  if (!response.ok) throw new Error(`Spotify devices returned ${response.status}`);
  const json = await response.json();
  const devices = Array.isArray(json?.devices) ? json.devices : [];
  return devices.map((row: Record<string, unknown>) => toDevice(row));
}

async function fetchPlaylists(instanceId: string, config: SpotifyConfig): Promise<SpotifyPlaylist[]> {
  const response = await spotifyFetch(instanceId, config, "/me/playlists?limit=30");
  if (!response.ok) throw new Error(`Spotify playlists returned ${response.status}`);
  const json = await response.json();
  const items = Array.isArray(json?.items) ? json.items : [];
  return items.map((row: Record<string, unknown>) => toPlaylist(row));
}

export async function fetchSpotifyStatus(instanceId: string): Promise<SpotifyStatus> {
  const config = await loadSpotifyConfig(instanceId);

  // Now Playing is fetched separately from the other panels so a failure there
  // (e.g. Spotify hiccup, transient 5xx) can't take the whole widget down —
  // Recent/Devices/Playlists should still render from whatever did succeed.
  const [playbackResult, recentlyPlayed, devices, playlists] = await Promise.all([
    fetchPlayback(instanceId, config).then(
      (value) => ({ ok: true as const, value }),
      (error: unknown) => ({ ok: false as const, error }),
    ),
    fetchRecentlyPlayed(instanceId, config).catch(() => []),
    fetchDevices(instanceId, config).catch(() => []),
    fetchPlaylists(instanceId, config).catch(() => []),
  ]);

  const playback = playbackResult.ok ? playbackResult.value : null;
  const playbackError = playbackResult.ok
    ? null
    : playbackResult.error instanceof Error
      ? playbackResult.error.message
      : "Failed to load Now Playing";

  return { playback, playbackError, recentlyPlayed, devices, playlists };
}

// ── Actions ─────────────────────────────────────────────────────────────

export type SpotifyActionKind =
  | "play"
  | "pause"
  | "next"
  | "previous"
  | "seek"
  | "volume"
  | "shuffle"
  | "repeat"
  | "transfer-playback"
  | "play-playlist"
  | "play-track";

async function sendAction(
  instanceId: string,
  config: SpotifyConfig,
  path: string,
  method: string,
  body?: Record<string, unknown>,
) {
  const response = await spotifyFetch(instanceId, config, path, {
    method,
    headers: body ? { "Content-Type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });

  if (!response.ok) {
    if (response.status === 401 || response.status === 403) {
      throw new Error("Spotify rejected the request (check scopes on the refresh token)");
    }
    if (response.status === 404) {
      throw new Error("No active Spotify device — open Spotify on a device first");
    }
    if (response.status === 429) {
      throw new Error("Spotify is rate-limiting requests — try again shortly");
    }
    let message = `Spotify returned ${response.status}`;
    try {
      const errJson = await response.json();
      if (errJson?.error?.message) message = String(errJson.error.message);
    } catch {
      // ignore non-JSON error bodies
    }
    throw new Error(message);
  }
  if (response.status === 204) return null;
  const text = await response.text();
  return text ? JSON.parse(text) : null;
}

export async function performSpotifyAction(
  instanceId: string,
  kind: SpotifyActionKind,
  payload: Record<string, unknown>,
) {
  const config = await loadSpotifyConfig(instanceId);
  const deviceQuery = payload.deviceId ? `?device_id=${encodeURIComponent(String(payload.deviceId))}` : "";

  switch (kind) {
    case "play":
      return sendAction(instanceId, config, `/me/player/play${deviceQuery}`, "PUT");
    case "pause":
      return sendAction(instanceId, config, `/me/player/pause${deviceQuery}`, "PUT");
    case "next":
      return sendAction(instanceId, config, `/me/player/next${deviceQuery}`, "POST");
    case "previous":
      return sendAction(instanceId, config, `/me/player/previous${deviceQuery}`, "POST");
    case "seek": {
      const ms = Math.max(0, Number(payload.positionMs) || 0);
      return sendAction(instanceId, config, `/me/player/seek?position_ms=${ms}`, "PUT");
    }
    case "volume": {
      const percent = Math.min(100, Math.max(0, Number(payload.volumePercent) || 0));
      return sendAction(instanceId, config, `/me/player/volume?volume_percent=${percent}`, "PUT");
    }
    case "shuffle":
      return sendAction(instanceId, config, `/me/player/shuffle?state=${Boolean(payload.state)}`, "PUT");
    case "repeat": {
      const state = payload.state === "track" || payload.state === "context" ? payload.state : "off";
      return sendAction(instanceId, config, `/me/player/repeat?state=${state}`, "PUT");
    }
    case "transfer-playback": {
      const deviceId = String(payload.deviceId || "");
      if (!deviceId) throw new Error("Missing device id");
      return sendAction(instanceId, config, "/me/player", "PUT", {
        device_ids: [deviceId],
        play: Boolean(payload.play),
      });
    }
    case "play-playlist": {
      const uri = String(payload.uri || "");
      if (!uri) throw new Error("Missing playlist uri");
      return sendAction(instanceId, config, `/me/player/play${deviceQuery}`, "PUT", { context_uri: uri });
    }
    case "play-track": {
      const uri = String(payload.uri || "");
      if (!uri) throw new Error("Missing track uri");
      return sendAction(instanceId, config, `/me/player/play${deviceQuery}`, "PUT", { uris: [uri] });
    }
    default:
      throw new Error("Unknown action");
  }
}
