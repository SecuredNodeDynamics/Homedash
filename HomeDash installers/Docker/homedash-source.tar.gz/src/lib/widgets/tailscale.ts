import { readWidgetConfig } from "@/lib/config";

export type TailscaleDevice = {
  id: string;
  nodeId: string;
  name: string;
  fqdn: string;
  hostname: string;
  os: string;
  addresses: string[];
  tags: string[];
  lastSeen: string | null;
  connectedToControl: boolean | null;
  advertisedRoutes: string[];
  enabledRoutes: string[];
  authorized: boolean;
  clientVersion: string;
  updateAvailable: boolean;
  isExitNode: boolean;
  online: boolean;
};

export type TailscaleStatus = {
  devices: TailscaleDevice[];
  publicUrl: string;
  overviewLimit: number;
};

type TailscaleConfig = {
  apiKey?: string;
  proxyUrl?: string;
  tailnet?: string;
  publicUrl?: string;
  overviewLimit?: string;
};

function isOnline(device: Pick<TailscaleDevice, "connectedToControl" | "lastSeen">) {
  if (typeof device.connectedToControl === "boolean") return device.connectedToControl;
  if (!device.lastSeen) return false;
  return Date.now() - new Date(device.lastSeen).getTime() < 180_000;
}

function isExitNode(device: Pick<TailscaleDevice, "advertisedRoutes" | "enabledRoutes">) {
  return [...device.advertisedRoutes, ...device.enabledRoutes].some(
    (route) => route === "0.0.0.0/0" || route === "::/0",
  );
}

function proxyEndpoint(proxyUrl: string, tailnet: string) {
  const base = proxyUrl.replace(/\/+$/, "");
  return `${base}/api/v2/tailnet/${encodeURIComponent(tailnet)}/devices?fields=all`;
}

export async function fetchTailscaleStatus(instanceId: string): Promise<TailscaleStatus> {
  const config = (await readWidgetConfig(instanceId)) as TailscaleConfig;
  const apiKey = config.apiKey?.trim();
  const proxyUrl = config.proxyUrl?.trim();
  if (!apiKey) throw new Error("Configure a Tailscale API key in Settings");
  if (!proxyUrl) throw new Error("Configure a Tailscale proxy URL in Settings");

  const response = await fetch(proxyEndpoint(proxyUrl, config.tailnet?.trim() || "_"), {
    headers: {
      Authorization: `Bearer ${apiKey}`,
      Accept: "application/json",
    },
    cache: "no-store",
    signal: AbortSignal.timeout(8000),
  });

  if (!response.ok) {
    const message = await response.text().catch(() => "");
    throw new Error(message || `Tailscale HTTP ${response.status}`);
  }

  const data = (await response.json()) as { devices?: Array<Record<string, unknown>> };
  const devices = (data.devices || []).map((device): TailscaleDevice => {
    const connectedToControl =
      typeof device.connectedToControl === "boolean" ? device.connectedToControl : null;
    const mapped = {
      id: String(device.id || ""),
      nodeId: String(device.nodeId || ""),
      name: String(device.name || device.hostname || "Unknown").split(".")[0] || "Unknown",
      fqdn: String(device.name || ""),
      hostname: String(device.hostname || ""),
      os: String(device.os || ""),
      addresses: Array.isArray(device.addresses) ? device.addresses.map(String) : [],
      tags: Array.isArray(device.tags) ? device.tags.map(String) : [],
      lastSeen: typeof device.lastSeen === "string" ? device.lastSeen : null,
      connectedToControl,
      advertisedRoutes: Array.isArray(device.advertisedRoutes)
        ? device.advertisedRoutes.map(String)
        : [],
      enabledRoutes: Array.isArray(device.enabledRoutes) ? device.enabledRoutes.map(String) : [],
      authorized: device.authorized !== false,
      clientVersion: String(device.clientVersion || ""),
      updateAvailable: device.updateAvailable === true,
      isExitNode: false,
      online: false,
    };
    mapped.isExitNode = isExitNode(mapped);
    mapped.online = isOnline(mapped);
    return mapped;
  });

  return {
    devices,
    publicUrl: config.publicUrl?.trim() || "https://login.tailscale.com/admin/machines",
    overviewLimit: Math.max(0, Number(config.overviewLimit || 0) || 0),
  };
}
