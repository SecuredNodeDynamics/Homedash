/** Client-safe Tracearr aggregate helpers (ported from Homepage widget). */

export type HistoryEntry = Record<string, unknown>;

export type DayBucket = {
  labels: string[];
  keys: string[];
  plays: number[];
  duration: number[];
};

export type NamedCount = { name: string; count: number };
export type TopUser = { uid: string; name: string; plays: number; duration: number };

export function asArray(value: unknown): HistoryEntry[] {
  if (Array.isArray(value)) return value as HistoryEntry[];
  if (value && typeof value === "object" && Array.isArray((value as { data?: unknown[] }).data)) {
    return (value as { data: HistoryEntry[] }).data;
  }
  return [];
}

export function num(value: unknown, fallback = 0): number {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

export function fmtDuration(secs: number): string {
  const total = num(secs, 0);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

export function getDurationSeconds(entry: HistoryEntry): number {
  const msFields = [
    entry.totalDurationMs,
    entry.durationMs,
    entry.progressMs,
    entry.duration_ms,
    entry.progress_ms,
  ];
  for (const value of msFields) {
    const n = Number(value);
    if (Number.isFinite(n) && n > 0) return Math.round(n / 1000);
  }

  const starts = [entry.startedAt, entry.started_at, entry.startTime, entry.start_time];
  const stops = [
    entry.stoppedAt,
    entry.stopped_at,
    entry.stopTime,
    entry.stop_time,
    entry.endedAt,
    entry.ended_at,
    entry.endTime,
    entry.end_time,
  ];
  for (const s of starts) {
    for (const t of stops) {
      if (!s || !t) continue;
      const start = new Date(String(s)).getTime();
      const stop = new Date(String(t)).getTime();
      if (!Number.isNaN(start) && !Number.isNaN(stop) && stop > start) {
        return Math.round((stop - start) / 1000);
      }
    }
  }

  const secFields = [
    entry.duration,
    entry.watchTime,
    entry.watch_time,
    entry.durationSeconds,
    entry.duration_seconds,
    entry.playDuration,
    entry.play_duration,
    entry.playbackDuration,
    entry.playback_duration,
    entry.watchedDuration,
    entry.watched_duration,
    entry.sessionDuration,
    entry.session_duration,
    entry.elapsed,
    entry.elapsedSeconds,
    entry.elapsed_seconds,
    entry.runtime,
    entry.runtimeSeconds,
    entry.runtime_seconds,
    entry.minutesWatched != null ? Number(entry.minutesWatched) * 60 : null,
    entry.minutes_watched != null ? Number(entry.minutes_watched) * 60 : null,
    entry.hoursWatched != null ? Number(entry.hoursWatched) * 3600 : null,
    entry.hours_watched != null ? Number(entry.hours_watched) * 3600 : null,
  ];
  for (const value of secFields) {
    const n = Number(value);
    if (Number.isFinite(n) && n > 0) return n;
  }

  if (entry.watchTime && typeof entry.watchTime === "object") {
    const wt = entry.watchTime as Record<string, unknown>;
    const nested = [
      wt.seconds,
      wt.minutes != null ? Number(wt.minutes) * 60 : null,
      wt.hours != null ? Number(wt.hours) * 3600 : null,
      wt.value,
    ];
    for (const value of nested) {
      const n = Number(value);
      if (Number.isFinite(n) && n > 0) return n;
    }
  }

  return 0;
}

function entryTimestamp(entry: HistoryEntry): string | null {
  const ts =
    entry.startedAt ||
    entry.stoppedAt ||
    entry.date ||
    entry.timestamp ||
    entry.started_at ||
    entry.startTime ||
    entry.created_at ||
    entry.time;
  return ts != null ? String(ts) : null;
}

export function dayKeyFromTs(ts: string): string | null {
  const d = new Date(ts);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString().slice(0, 10);
}

export function getHistoryPlays(
  history: unknown,
  activity: Record<string, unknown> | null | undefined,
  days: number,
): DayBucket {
  const hist = asArray(history);
  const activityPlays = Array.isArray(activity?.plays) ? (activity!.plays as HistoryEntry[]) : [];
  const source = hist.length ? hist : activityPlays;
  const now = new Date();
  const buckets: Record<string, { plays: number; duration: number }> = {};

  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    buckets[key] = { plays: 0, duration: 0 };
  }

  for (const entry of source) {
    const ts = entryTimestamp(entry);
    if (!ts) continue;
    const key = dayKeyFromTs(ts);
    if (!key || !buckets[key]) continue;
    buckets[key].plays += num(entry.count, 1);
    buckets[key].duration += getDurationSeconds(entry);
  }

  const keys = Object.keys(buckets);
  return {
    keys,
    labels: keys.map((k) => {
      const [, m, d] = k.split("-");
      return `${Number(m)}/${Number(d)}`;
    }),
    plays: Object.values(buckets).map((b) => b.plays),
    duration: Object.values(buckets).map((b) => Math.round(b.duration / 60)),
  };
}

export type BandwidthBucket = {
  keys: string[];
  labels: string[];
  avgMbps: number[];
  sessions: number[];
};

/** Daily average bitrate (Mbps) + session counts from history. */
export function getDailyBandwidth(history: unknown, days: number): BandwidthBucket {
  const hist = asArray(history);
  const now = new Date();
  const buckets: Record<string, { bitrateSum: number; bitrateN: number; sessions: number }> = {};

  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    buckets[key] = { bitrateSum: 0, bitrateN: 0, sessions: 0 };
  }

  for (const entry of hist) {
    const ts = entryTimestamp(entry);
    if (!ts) continue;
    const key = dayKeyFromTs(ts);
    if (!key || !buckets[key]) continue;
    buckets[key].sessions += 1;
    const bitrate = num(entry.bitrate ?? entry.bitRate ?? entry.videoBitrate, 0);
    if (bitrate > 0) {
      buckets[key].bitrateSum += bitrate;
      buckets[key].bitrateN += 1;
    }
  }

  const keys = Object.keys(buckets);
  return {
    keys,
    labels: keys.map((k) => {
      const [, m, d] = k.split("-");
      return `${Number(m)}/${Number(d)}`;
    }),
    avgMbps: Object.values(buckets).map((b) =>
      b.bitrateN ? Math.round((b.bitrateSum / b.bitrateN / 1000) * 100) / 100 : 0,
    ),
    sessions: Object.values(buckets).map((b) => b.sessions),
  };
}

function pickUserName(value: unknown): string | null {
  if (!value) return null;
  if (typeof value === "string") return value;
  if (typeof value === "number") return String(value);
  if (typeof value === "object") {
    const o = value as Record<string, unknown>;
    const picked =
      o.displayName || o.display_name || o.username || o.name || o.email || o.title || o.label || o.id;
    return picked != null ? String(picked) : null;
  }
  return null;
}

function pickUserId(value: unknown): string | null {
  if (!value) return null;
  if (typeof value === "string" || typeof value === "number") return String(value);
  if (typeof value === "object") {
    const o = value as Record<string, unknown>;
    const picked = o.id || o.userId || o.user_id || o.username || o.email;
    return picked != null ? String(picked) : null;
  }
  return null;
}

export function getDevices(history: unknown, activity: Record<string, unknown> | null | undefined): NamedCount[] {
  const platforms = Array.isArray(activity?.platforms) ? (activity!.platforms as HistoryEntry[]) : [];
  if (platforms.length) {
    return platforms
      .filter((p) => num(p.count) > 0)
      .sort((a, b) => num(b.count) - num(a.count))
      .slice(0, 8)
      .map((p) => ({
        name: String(p.platform || p.name || p.device || "Unknown"),
        count: num(p.count),
      }));
  }

  const map: Record<string, number> = {};
  for (const e of asArray(history)) {
    const raw = e.player || e.device || e.client || e.platform || e.product || e.app || "Unknown";
    const key =
      typeof raw === "object" && raw
        ? String(
            (raw as Record<string, unknown>).name ||
              (raw as Record<string, unknown>).title ||
              (raw as Record<string, unknown>).platform ||
              (raw as Record<string, unknown>).product ||
              "Unknown",
          )
        : String(raw);
    map[key] = (map[key] || 0) + 1;
  }
  return Object.entries(map)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([name, count]) => ({ name, count }));
}

export type DeviceHealthRow = {
  name: string;
  sessions: number;
  directPlayRate: number;
};

export type TranscodeHotspotRow = {
  device: string;
  codec: string;
  transcodes: number;
  percentOfTotal: number;
};

function entryPlatform(entry: HistoryEntry): string {
  return String(entry.platform || entry.product || entry.device || entry.player || "Unknown");
}

function isDirectPlay(entry: HistoryEntry): boolean {
  const vd = String(entry.videoDecision || "").toLowerCase();
  if (vd === "directplay") return true;
  if (entry.isTranscode === true) return false;
  if (vd.includes("transcode")) return false;
  if (entry.isTranscode === false) return true;
  return false;
}

function isTranscodeSession(entry: HistoryEntry): boolean {
  if (entry.isTranscode === true) return true;
  const vd = String(entry.videoDecision || "").toLowerCase();
  const ad = String(entry.audioDecision || "").toLowerCase();
  return vd === "transcode" || ad === "transcode";
}

/** Direct play rate by device/platform from history sessions. */
export function getDeviceHealth(history: unknown): DeviceHealthRow[] {
  const map: Record<string, { sessions: number; directPlay: number }> = {};
  for (const e of asArray(history)) {
    const name = entryPlatform(e);
    if (!map[name]) map[name] = { sessions: 0, directPlay: 0 };
    map[name].sessions += 1;
    if (isDirectPlay(e)) map[name].directPlay += 1;
  }
  return Object.entries(map)
    .map(([name, v]) => ({
      name,
      sessions: v.sessions,
      directPlayRate: v.sessions ? (v.directPlay / v.sessions) * 100 : 0,
    }))
    .sort((a, b) => b.sessions - a.sessions || b.directPlayRate - a.directPlayRate)
    .slice(0, 8);
}

/** Top device + source codec combos that cause the most transcodes. */
export function getTranscodeHotspots(history: unknown, limit = 5): TranscodeHotspotRow[] {
  const map: Record<string, { device: string; codec: string; count: number }> = {};
  let total = 0;
  for (const e of asArray(history)) {
    if (!isTranscodeSession(e)) continue;
    total += 1;
    const device = entryPlatform(e);
    const video = String(e.sourceVideoCodec || e.videoCodec || "?").toUpperCase();
    const audio = String(e.sourceAudioCodec || e.audioCodec || "?").toUpperCase();
    const codec = `${video} + ${audio}`;
    const key = `${device}|${codec}`;
    if (!map[key]) map[key] = { device, codec, count: 0 };
    map[key].count += 1;
  }
  if (!total) return [];
  return Object.values(map)
    .sort((a, b) => b.count - a.count)
    .slice(0, limit)
    .map((row) => ({
      device: row.device,
      codec: row.codec,
      transcodes: row.count,
      percentOfTotal: Math.round((row.count / total) * 100),
    }));
}

export const COMPAT_CODECS = ["AV1", "H.264", "HEVC"] as const;
export type CompatCodec = (typeof COMPAT_CODECS)[number];

export type CompatCell = {
  sessions: number;
  directPlayRate: number;
} | null;

export type CompatMatrixRow = {
  device: string;
  sessions: number;
  cells: Record<CompatCodec, CompatCell>;
};

function normalizeVideoCodec(raw: unknown): CompatCodec | null {
  const c = String(raw || "")
    .toUpperCase()
    .replace(/\s+/g, "");
  if (c === "AV1") return "AV1";
  if (c === "H264" || c === "H.264" || c === "AVC") return "H.264";
  if (c === "HEVC" || c === "H265" || c === "H.265") return "HEVC";
  return null;
}

/** Direct play rates by device × video codec, sorted by session volume. */
export function getCompatibilityMatrix(history: unknown): CompatMatrixRow[] {
  const map: Record<
    string,
    { sessions: number; codecs: Record<CompatCodec, { total: number; direct: number }> }
  > = {};

  for (const e of asArray(history)) {
    const device = entryPlatform(e);
    const codec = normalizeVideoCodec(e.sourceVideoCodec || e.videoCodec);
    if (!map[device]) {
      map[device] = {
        sessions: 0,
        codecs: {
          AV1: { total: 0, direct: 0 },
          "H.264": { total: 0, direct: 0 },
          HEVC: { total: 0, direct: 0 },
        },
      };
    }
    map[device].sessions += 1;
    if (!codec) continue;
    map[device].codecs[codec].total += 1;
    if (isDirectPlay(e)) map[device].codecs[codec].direct += 1;
  }

  return Object.entries(map)
    .map(([device, v]) => {
      const cells = {} as Record<CompatCodec, CompatCell>;
      for (const codec of COMPAT_CODECS) {
        const cell = v.codecs[codec];
        cells[codec] =
          cell.total > 0
            ? { sessions: cell.total, directPlayRate: (cell.direct / cell.total) * 100 }
            : null;
      }
      return { device, sessions: v.sessions, cells };
    })
    .filter((row) => COMPAT_CODECS.some((c) => row.cells[c] != null))
    .sort((a, b) => b.sessions - a.sessions)
    .slice(0, 8);
}

export function compatTone(rate: number): "good" | "mid" | "bad" {
  if (rate >= 80) return "good";
  if (rate >= 50) return "mid";
  return "bad";
}

export type MostWatchedKind = "movie" | "show";
export type MostWatchedSort = "plays" | "watchHours" | "viewers" | "completion";
export type MostWatchedRange = 7 | 30 | 90 | 365 | 0;

export type MostWatchedItem = {
  id: string;
  title: string;
  year: number | null;
  kind: MostWatchedKind;
  plays: number;
  watchHours: number;
  viewers: number;
  completion: number;
};

export const MOST_WATCHED_RANGES: Array<{ value: MostWatchedRange; label: string }> = [
  { value: 7, label: "Last 7 Days" },
  { value: 30, label: "Last 30 Days" },
  { value: 90, label: "Last 90 Days" },
  { value: 365, label: "1 Year" },
  { value: 0, label: "All History" },
];

function sessionWatchMs(entry: HistoryEntry): number {
  const duration = num(entry.durationMs, 0);
  if (duration > 0) return duration;
  const progress = num(entry.progressMs, 0);
  if (progress > 0) return progress;
  return getDurationSeconds(entry) * 1000;
}

function sessionCompleted(entry: HistoryEntry): boolean {
  if (entry.watched === true) return true;
  const total = num(entry.totalDurationMs, 0);
  const progress = num(entry.progressMs, 0);
  if (total > 0 && progress / total >= 0.9) return true;
  return false;
}

function entryViewerId(entry: HistoryEntry): string {
  const rawUser = entry.user || entry.userInfo || entry.account || entry.username || entry.userId || entry.user_id;
  return (
    pickUserId(rawUser) ||
    pickUserId(entry.userId) ||
    pickUserId(entry.user_id) ||
    pickUserName(rawUser) ||
    "unknown"
  );
}

function withinRange(ts: string | null, days: MostWatchedRange): boolean {
  if (!ts || days === 0) return true;
  const t = new Date(ts).getTime();
  if (!Number.isFinite(t)) return false;
  return t >= Date.now() - days * 24 * 60 * 60 * 1000;
}

function isMovieEntry(entry: HistoryEntry): boolean {
  const type = String(entry.mediaType || entry.type || "").toLowerCase();
  return type === "movie" || type === "movies";
}

function isShowEntry(entry: HistoryEntry): boolean {
  const type = String(entry.mediaType || entry.type || "").toLowerCase();
  return type === "episode" || type === "show" || type === "series" || type === "tv" || type === "season";
}

/** Aggregate most-watched movies or TV shows from history. */
export function getMostWatched(
  history: unknown,
  kind: MostWatchedKind,
  days: MostWatchedRange = 30,
): MostWatchedItem[] {
  type Acc = {
    id: string;
    title: string;
    year: number | null;
    kind: MostWatchedKind;
    plays: number;
    watchMs: number;
    viewers: Set<string>;
    completedViewers: Set<string>;
  };
  const map: Record<string, Acc> = {};

  for (const entry of asArray(history)) {
    if (kind === "movie" ? !isMovieEntry(entry) : !isShowEntry(entry)) continue;
    if (!withinRange(entryTimestamp(entry), days)) continue;

    let title = "";
    let year: number | null = null;
    let id = "";

    if (kind === "movie") {
      title = String(entry.mediaTitle || entry.title || entry.name || "Unknown").trim();
      year = num(entry.year, 0) || null;
      id = `movie:${title.toLowerCase()}|${year || ""}`;
    } else {
      title = String(entry.showTitle || entry.grandparentTitle || entry.seriesName || entry.mediaTitle || "Unknown").trim();
      year = num(entry.year, 0) || null;
      id = `show:${title.toLowerCase()}`;
    }
    if (!title) continue;

    if (!map[id]) {
      map[id] = {
        id,
        title,
        year,
        kind,
        plays: 0,
        watchMs: 0,
        viewers: new Set(),
        completedViewers: new Set(),
      };
    }

    const row = map[id];
    row.plays += 1;
    row.watchMs += sessionWatchMs(entry);
    const viewer = entryViewerId(entry);
    row.viewers.add(viewer);
    if (sessionCompleted(entry)) row.completedViewers.add(viewer);
    if (!row.year && year) row.year = year;
  }

  return Object.values(map)
    .map((row) => ({
      id: row.id,
      title: row.title,
      year: row.year,
      kind: row.kind,
      plays: row.plays,
      watchHours: Math.round((row.watchMs / 3_600_000) * 10) / 10,
      viewers: row.viewers.size,
      completion: row.viewers.size
        ? Math.round((row.completedViewers.size / row.viewers.size) * 100)
        : 0,
    }))
    .sort((a, b) => b.plays - a.plays || b.watchHours - a.watchHours);
}

export function sortMostWatched(
  items: MostWatchedItem[],
  sort: MostWatchedSort,
  dir: "asc" | "desc",
): MostWatchedItem[] {
  const mul = dir === "asc" ? 1 : -1;
  return [...items].sort((a, b) => {
    const av = a[sort];
    const bv = b[sort];
    if (av === bv) return b.plays - a.plays;
    return (av < bv ? -1 : 1) * mul;
  });
}

export function getTopUsers(history: unknown, users: unknown): TopUser[] {
  const hist = asArray(history);
  const usersArr = asArray(users);
  const map: Record<string, TopUser> = {};

  for (const e of hist) {
    const rawUser = e.user || e.userInfo || e.userObject || e.account || e.username || e.userId || e.user_id;
    const uid =
      pickUserId(rawUser) || pickUserId(e.userId) || pickUserId(e.user_id) || pickUserName(rawUser);
    if (!uid) continue;
    if (!map[uid]) {
      map[uid] = {
        uid,
        name: pickUserName(rawUser) || `User ${uid}`,
        plays: 0,
        duration: 0,
      };
    }
    map[uid].plays += 1;
    map[uid].duration += getDurationSeconds(e);
  }

  return Object.values(map)
    .map((u) => {
      const info = usersArr.find((x) => {
        const xid = x?.id || x?.userId || x?.user_id || x?.username || x?.email;
        return String(xid) === String(u.uid);
      });
      return {
        ...u,
        name: pickUserName(info) || u.name || `User ${u.uid}`,
      };
    })
    .sort((a, b) => b.plays - a.plays)
    .slice(0, 8);
}

export function getLibraries(history: unknown): NamedCount[] {
  const map: Record<string, number> = {};
  for (const e of asArray(history)) {
    const raw =
      e.library ||
      e.libraryName ||
      e.library_name ||
      e.section ||
      e.sectionTitle ||
      e.mediaType ||
      e.type ||
      "Unknown";
    let key = String(raw);
    if (key === "track" || key === "Track") key = "Music";
    else if (key === "movie" || key === "Movie") key = "Movies";
    else if (key === "episode" || key === "Episode" || key === "show" || key === "Show") key = "TV";
    map[key] = (map[key] || 0) + 1;
  }
  return Object.entries(map)
    .sort((a, b) => b[1] - a[1])
    .map(([name, count]) => ({ name, count }));
}

export function sessionTitle(entry: HistoryEntry): string {
  const media =
    (entry.media || entry.item || entry.video || entry.track || entry.episode || entry.movie || entry.show || {}) as
      | string
      | Record<string, unknown>;
  if (typeof media === "string") return media;
  return String(
    entry.mediaTitle ||
      entry.title ||
      entry.fullTitle ||
      entry.showTitle ||
      entry.grandparentTitle ||
      entry.parentTitle ||
      media.title ||
      media.name ||
      entry.name ||
      "Unknown media",
  );
}

export function sessionUser(entry: HistoryEntry): string {
  const user = entry.user || entry.userInfo || entry.account || entry.username || entry.userId || entry.user_id;
  if (!user) return "";
  if (typeof user === "string" || typeof user === "number") return String(user);
  const o = user as Record<string, unknown>;
  return String(o.displayName || o.display_name || o.username || o.name || o.email || "");
}

export function sessionsForDay(history: unknown, dateKey: string): HistoryEntry[] {
  return asArray(history).filter((e) => {
    const ts = entryTimestamp(e);
    if (!ts) return false;
    return dayKeyFromTs(ts) === dateKey;
  });
}

export const CHART_COLORS = {
  teal: ["rgba(34,211,238,0.85)", "rgba(34,211,238,0.18)"] as const,
  blue: ["rgba(96,165,250,0.85)", "rgba(96,165,250,0.18)"] as const,
  purple: ["rgba(167,139,250,0.85)", "rgba(167,139,250,0.18)"] as const,
  amber: ["rgba(251,191,36,0.85)", "rgba(251,191,36,0.18)"] as const,
  green: ["rgba(6,182,212,0.85)", "rgba(6,182,212,0.18)"] as const,
  rose: ["rgba(251,113,133,0.85)", "rgba(251,113,133,0.18)"] as const,
  indigo: ["rgba(129,140,248,0.85)", "rgba(129,140,248,0.18)"] as const,
  orange: ["rgba(251,146,60,0.85)", "rgba(251,146,60,0.18)"] as const,
};

export const CHART_PALETTE = Object.values(CHART_COLORS);

/** Concurrent streams over time from activity.concurrent (direct / directStream / transcode). */
export type ConcurrentBucket = {
  labels: string[];
  direct: number[];
  directStream: number[];
  transcode: number[];
};

export function getConcurrentStreams(activity: Record<string, unknown> | null | undefined): ConcurrentBucket {
  const rows = Array.isArray(activity?.concurrent) ? (activity!.concurrent as HistoryEntry[]) : [];
  const sorted = [...rows].sort((a, b) => {
    const ta = new Date(String(a.date || a.day || a.timestamp || 0)).getTime();
    const tb = new Date(String(b.date || b.day || b.timestamp || 0)).getTime();
    return ta - tb;
  });

  return {
    labels: sorted.map((row) => {
      const raw = String(row.date || row.day || "");
      const d = new Date(raw);
      if (Number.isNaN(d.getTime())) return raw.slice(0, 10);
      return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
    }),
    direct: sorted.map((row) => num(row.direct ?? row.directPlay, 0)),
    directStream: sorted.map((row) => num(row.directStream, 0)),
    transcode: sorted.map((row) => num(row.transcode, 0)),
  };
}

/* ── Storage helpers ─────────────────────────────────────────────── */

export type StoragePeriod = "7d" | "30d" | "1y" | "all";
export type StaleCategory = "never_watched" | "stale";
export type StaleSort = "title" | "size" | "added" | "staleFor";

export type StoragePayload = {
  current?: { totalSizeBytes?: string | number; totalItems?: number; lastUpdated?: string | null };
  history?: Array<{ day?: string; totalSizeBytes?: string | number }>;
  growthRate?: { bytesPerDay?: string | number; bytesPerMonth?: string | number };
  predictions?: {
    day30?: { predicted?: string; min?: string; max?: string } | null;
    day90?: { predicted?: string; min?: string; max?: string } | null;
    day365?: { predicted?: string; min?: string; max?: string } | null;
    confidence?: "high" | "medium" | "low" | null;
    minDataDays?: number;
    currentDataDays?: number;
    message?: string;
  };
};

export type StaleItem = {
  id: string;
  title: string;
  mediaType: string;
  year: number | null;
  serverName: string;
  fileSize: number;
  addedAt: string | null;
  daysStale: number;
  resolution: string | null;
  category: StaleCategory;
};

export function fmtBytes(bytes: number, digits = 1): string {
  const n = Math.max(0, Number(bytes) || 0);
  if (n < 1000) return `${Math.round(n)} B`;
  const units = ["KB", "MB", "GB", "TB", "PB"];
  let v = n;
  let i = -1;
  do {
    v /= 1000;
    i += 1;
  } while (v >= 1000 && i < units.length - 1);
  const d = v >= 100 ? 0 : v >= 10 ? 1 : digits;
  return `${v.toFixed(d)} ${units[i]}`;
}

export function fmtBytesSigned(bytes: number): string {
  const n = Number(bytes) || 0;
  if (n === 0) return "0 B";
  const sign = n > 0 ? "+" : "−";
  return `${sign}${fmtBytes(Math.abs(n))}`;
}

export function relativeAgo(iso: string | null | undefined): string {
  if (!iso) return "—";
  const t = new Date(iso).getTime();
  if (!Number.isFinite(t)) return "—";
  const days = Math.max(0, Math.floor((Date.now() - t) / 86_400_000));
  if (days < 1) return "today";
  if (days < 30) return `${days} day${days === 1 ? "" : "s"} ago`;
  const months = Math.floor(days / 30);
  if (months < 12) return `${months} month${months === 1 ? "" : "s"} ago`;
  const years = Math.floor(months / 12);
  return `${years} year${years === 1 ? "" : "s"} ago`;
}

export function fmtDaysStale(days: number): string {
  const d = Math.max(0, Math.round(days));
  if (d < 30) return `${d} day${d === 1 ? "" : "s"}`;
  const months = Math.floor(d / 30);
  if (months < 12) return `${months} month${months === 1 ? "" : "s"}`;
  const years = Math.floor(months / 12);
  return `${years} year${years === 1 ? "" : "s"}`;
}

export function fmtResolution(raw: string | null | undefined): string {
  if (!raw) return "—";
  const v = String(raw).toLowerCase();
  if (v === "4k" || v === "uhd" || v === "2160p") return "4K";
  if (v === "1080p" || v === "fhd") return "1080p";
  if (v === "720p" || v === "hd") return "720p";
  if (v === "480p" || v === "sd") return "480p";
  return String(raw).toUpperCase();
}

export function mediaTypeLabel(raw: string | null | undefined): "Movie" | "TV" | "Music" | "Other" {
  const v = String(raw || "").toLowerCase();
  if (v === "movie" || v === "movies") return "Movie";
  if (v === "show" || v === "series" || v === "episode" || v === "tv" || v === "season") return "TV";
  if (
    v === "music" ||
    v === "artist" ||
    v === "album" ||
    v === "track" ||
    v === "song" ||
    v === "audio"
  ) {
    return "Music";
  }
  return "Other";
}

export function parseStaleItems(raw: unknown): StaleItem[] {
  if (!Array.isArray(raw)) return [];
  return raw.map((row, i) => {
    const o = (row || {}) as Record<string, unknown>;
    return {
      id: String(o.id || `stale-${i}`),
      title: String(o.title || "Unknown"),
      mediaType: String(o.mediaType || o.media_type || "unknown"),
      year: num(o.year, 0) || null,
      serverName: String(o.serverName || o.server_name || "—"),
      fileSize: num(o.fileSize ?? o.file_size, 0),
      addedAt: o.addedAt != null ? String(o.addedAt) : o.added_at != null ? String(o.added_at) : null,
      daysStale: num(o.daysStale ?? o.days_stale, 0),
      resolution: o.resolution != null ? String(o.resolution) : o.video_resolution != null ? String(o.video_resolution) : null,
      category: String(o.category || "") === "never_watched" ? "never_watched" : "stale",
    };
  });
}

export function sortStaleItems(items: StaleItem[], sort: StaleSort, dir: "asc" | "desc"): StaleItem[] {
  const mul = dir === "asc" ? 1 : -1;
  return [...items].sort((a, b) => {
    let av: number | string = 0;
    let bv: number | string = 0;
    if (sort === "title") {
      av = a.title.toLowerCase();
      bv = b.title.toLowerCase();
    } else if (sort === "size") {
      av = a.fileSize;
      bv = b.fileSize;
    } else if (sort === "added") {
      av = a.addedAt ? new Date(a.addedAt).getTime() : 0;
      bv = b.addedAt ? new Date(b.addedAt).getTime() : 0;
    } else {
      av = a.daysStale;
      bv = b.daysStale;
    }
    if (av === bv) return b.fileSize - a.fileSize;
    return (av < bv ? -1 : 1) * mul;
  });
}

export type StorageTrendSeries = {
  labels: string[];
  historical: Array<number | null>;
  prediction: Array<number | null>;
  predMin: Array<number | null>;
  predMax: Array<number | null>;
  unit: string;
  nowIndex: number;
};

function pickUnit(maxBytes: number): { unit: string; divisor: number } {
  if (maxBytes >= 1e15) return { unit: "PB", divisor: 1e15 };
  if (maxBytes >= 1e12) return { unit: "TB", divisor: 1e12 };
  if (maxBytes >= 1e9) return { unit: "GB", divisor: 1e9 };
  if (maxBytes >= 1e6) return { unit: "MB", divisor: 1e6 };
  return { unit: "KB", divisor: 1e3 };
}

function dayLabel(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return `${d.getMonth() + 1}/${d.getDate()}`;
}

/** Build dual-series storage trend (historical + optional prediction cone). */
export function buildStorageTrend(
  storage: StoragePayload | null | undefined,
  showPredictions: boolean,
  period: StoragePeriod,
): StorageTrendSeries {
  const history = Array.isArray(storage?.history) ? storage!.history! : [];
  const histValues = history.map((h) => num(h.totalSizeBytes, 0));
  const last = histValues[histValues.length - 1] || 0;
  const predKey: "day30" | "day365" =
    period === "1y" || period === "all" ? "day365" : "day30";
  const pred = storage?.predictions?.[predKey] || storage?.predictions?.day30 || null;

  let maxBytes = Math.max(...histValues, 1);
  if (showPredictions && pred) {
    maxBytes = Math.max(maxBytes, num(pred.max, 0), num(pred.predicted, 0));
  }
  const { unit, divisor } = pickUnit(maxBytes);
  const toUnit = (b: number) => Math.round((b / divisor) * 100) / 100;

  const labels = history.map((h) => dayLabel(String(h.day || "")));
  const historical: Array<number | null> = histValues.map(toUnit);
  const prediction: Array<number | null> = histValues.map(() => null);
  const predMin: Array<number | null> = histValues.map(() => null);
  const predMax: Array<number | null> = histValues.map(() => null);
  const nowIndex = Math.max(0, historical.length - 1);

  if (showPredictions && pred && historical.length) {
    const steps = period === "1y" || period === "all" ? 6 : period === "7d" ? 3 : 4;
    const lastLabelDate = history[history.length - 1]?.day
      ? new Date(String(history[history.length - 1]!.day))
      : new Date();
    const predicted = num(pred.predicted, last);
    const min = num(pred.min, predicted);
    const max = num(pred.max, predicted);
    const daysHorizon = predKey === "day365" ? 365 : 30;

    // Anchor prediction at "now"
    prediction[nowIndex] = historical[nowIndex];
    predMin[nowIndex] = historical[nowIndex];
    predMax[nowIndex] = historical[nowIndex];

    for (let i = 1; i <= steps; i++) {
      const t = i / steps;
      const d = new Date(lastLabelDate);
      d.setDate(d.getDate() + Math.round(daysHorizon * t));
      labels.push(dayLabel(d.toISOString()));
      historical.push(null);
      prediction.push(toUnit(last + (predicted - last) * t));
      predMin.push(toUnit(last + (min - last) * t));
      predMax.push(toUnit(last + (max - last) * t));
    }
  }

  return { labels, historical, prediction, predMin, predMax, unit, nowIndex };
}
