import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, hasConnectionUrl, openUrlsFromConfig, primaryConnectionUrl } from "@/lib/open-href";

type Config = {
  baseUrl: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  /** Public API key (`trr_pub_*`) for /api/v1/public/* */
  apiKey?: string;
  /** Tracearr account email for Library/Storage session auth */
  email?: string;
  /** Tracearr account password for Library/Storage session auth */
  password?: string;
  /** Optional long-lived refresh token (alternative to email/password) */
  refreshToken?: string;
  /** Optional static access JWT override (skips login) */
  sessionToken?: string;
  /** Raw, unmodified config values — kept alongside `baseUrl` (which gets
   *  overwritten with primaryConnectionUrl()'s pick below) so connection
   *  source classification always compares against what was actually
   *  configured, not whichever URL happened to be chosen as primary. */
  rawBaseUrl?: string;
  rawFallbackUrl?: string;
};

type SessionTokens = {
  accessToken?: string;
  cookie?: string;
  refreshToken?: string;
  expiresAt: number;
};

const sessionCache = new Map<string, SessionTokens>();
const sessionInflight = new Map<string, Promise<SessionTokens | null>>();
const ACCESS_TTL_MS = 8 * 60_000;

export type TracearrConnectionSource = "private" | "public" | "unknown";

// Tracks, per widget instance, which base URL last responded successfully so
// we can report whether we're pulling from the Private or Public URL, and so
// we can try that URL first on the next request.
const activeBases = new Map<string, string>();

function apiRoot(url: string) {
  return String(url || "").replace(/\/+$/, "");
}

function orderedCandidates(instanceId: string, cfg: Config) {
  const urls = connectionCandidates(cfg);
  const active = activeBases.get(instanceId);
  return active ? [...new Set([active, ...urls])] : urls;
}

function classifyConnectionSource(cfg: Config, instanceId: string): TracearrConnectionSource {
  const base = activeBases.get(instanceId);
  if (!base) return "unknown";
  const normalized = apiRoot(base);
  // Compare against the raw config values, not `cfg.baseUrl` — by this point
  // `cfg.baseUrl` has already been overwritten with primaryConnectionUrl()'s
  // pick, which can silently substitute the wrong URL and mislabel a
  // successful private connection as "public" (or vice versa).
  if (cfg.rawBaseUrl && apiRoot(cfg.rawBaseUrl) === normalized) return "private";
  if (cfg.rawFallbackUrl && apiRoot(cfg.rawFallbackUrl) === normalized) return "public";
  return "unknown";
}

async function loadConfig(id: string) {
  const value = (await readWidgetConfig(id)) as Partial<Config>;
  if (!hasConnectionUrl(value)) {
    throw new Error("Configure a Private - IP or Fallback Public URL in Settings");
  }
  return {
    ...value,
    baseUrl: primaryConnectionUrl(value),
    rawBaseUrl: value.baseUrl,
    rawFallbackUrl: value.fallbackUrl,
  } as Config;
}

function hasLibraryCredentials(cfg: Config) {
  return !!(
    cfg.sessionToken?.trim() ||
    cfg.refreshToken?.trim() ||
    (cfg.email?.trim() && cfg.password)
  );
}

function jwtExpMs(token: string): number | null {
  try {
    const part = token.split(".")[1];
    if (!part) return null;
    const json = JSON.parse(Buffer.from(part, "base64url").toString("utf8")) as { exp?: number };
    return typeof json.exp === "number" ? json.exp * 1000 : null;
  } catch {
    return null;
  }
}

function cacheKey(instanceId: string, base: string) {
  return `${instanceId}:${base}`;
}

function storeSession(instanceId: string, base: string, session: SessionTokens) {
  const exp = session.accessToken ? jwtExpMs(session.accessToken) : null;
  sessionCache.set(cacheKey(instanceId, base), {
    ...session,
    expiresAt: exp ? exp - 30_000 : session.expiresAt,
  });
}

function responseCookies(headers: Headers): string {
  const values = typeof headers.getSetCookie === "function"
    ? headers.getSetCookie()
    : [headers.get("set-cookie") || ""];
  return values
    .flatMap((value) => value.split(/,(?=\s*[^;,=\s]+=[^;,]+)/))
    .map((value) => value.trim().split(";", 1)[0])
    .filter(Boolean)
    .join("; ");
}

async function loginLocal(cfg: Config, base: string): Promise<SessionTokens> {
  const email = cfg.email?.trim();
  if (!email || !cfg.password) throw new Error("Tracearr email and password required");
  const origin = new URL(base).origin;
  const modern = await fetch(joinUrl(base, "/api/v1/auth/sign-in/email"), {
    method: "POST",
    // Better Auth validates browser-style sign-in requests against Origin.
    // Homedash signs in server-side, so fetch does not add it automatically.
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Origin: origin,
      Referer: `${origin}/`,
    },
    body: JSON.stringify({ email, password: cfg.password, rememberMe: true }),
    cache: "no-store",
    signal: AbortSignal.timeout(12_000),
  });
  const modernData = (await modern.json().catch(() => ({}))) as {
    token?: string;
    message?: string;
    error?: string;
    code?: string;
  };
  const modernToken = modernData.token || modern.headers.get("set-auth-token") || "";
  const modernCookie = responseCookies(modern.headers);
  if (modern.ok && (modernToken || modernCookie)) {
    return {
      accessToken: modernToken || undefined,
      cookie: modernCookie || undefined,
      expiresAt: Date.now() + ACCESS_TTL_MS,
    };
  }
  // Tracearr before the Better Auth migration used /auth/login. Only fall
  // back when the modern route is absent; invalid credentials must not cause
  // a second login attempt and trip the sign-in rate limiter.
  if (modern.status !== 404 && modern.status !== 405) {
    throw new Error(
      modernData.message || modernData.error || modernData.code || `Tracearr sign-in HTTP ${modern.status}`,
    );
  }

  const legacy = await fetch(joinUrl(base, "/api/v1/auth/login"), {
    method: "POST",
    headers: { Accept: "application/json", "Content-Type": "application/json" },
    body: JSON.stringify({ type: "local", email, password: cfg.password }),
    cache: "no-store",
    signal: AbortSignal.timeout(12_000),
  });
  const data = (await legacy.json().catch(() => ({}))) as {
    accessToken?: string;
    refreshToken?: string;
    message?: string;
  };
  if (!legacy.ok) throw new Error(data.message || `Tracearr login HTTP ${legacy.status}`);
  if (!data.accessToken || !data.refreshToken) {
    throw new Error("Tracearr login returned no tokens");
  }
  return {
    accessToken: data.accessToken,
    refreshToken: data.refreshToken,
    expiresAt: jwtExpMs(data.accessToken) ?? Date.now() + ACCESS_TTL_MS,
  };
}

async function refreshAccess(base: string, refreshToken: string): Promise<SessionTokens> {
  const res = await fetch(joinUrl(base, "/api/v1/auth/refresh"), {
    method: "POST",
    headers: { Accept: "application/json", "Content-Type": "application/json" },
    body: JSON.stringify({ refreshToken }),
    cache: "no-store",
    signal: AbortSignal.timeout(12_000),
  });
  const data = (await res.json().catch(() => ({}))) as {
    accessToken?: string;
    refreshToken?: string;
    message?: string;
  };
  if (!res.ok) throw new Error(data.message || `Tracearr refresh ${res.status}`);
  if (!data.accessToken || !data.refreshToken) {
    throw new Error("Tracearr refresh returned no tokens");
  }
  return {
    accessToken: data.accessToken,
    refreshToken: data.refreshToken,
    expiresAt: jwtExpMs(data.accessToken) ?? Date.now() + ACCESS_TTL_MS,
  };
}

async function resolveLibraryToken(
  instanceId: string,
  cfg: Config,
  base: string,
  force = false,
): Promise<SessionTokens | null> {
  if (cfg.sessionToken?.trim()) {
    return { accessToken: cfg.sessionToken.trim(), expiresAt: Date.now() + ACCESS_TTL_MS };
  }

  const key = cacheKey(instanceId, base);
  const cached = sessionCache.get(key);
  if (!force && cached && Date.now() < cached.expiresAt) {
    return cached;
  }
  const pending = sessionInflight.get(key);
  if (pending) return pending;

  const authenticate = (async () => {
    const seededRefresh = cached?.refreshToken || cfg.refreshToken?.trim();
    if (seededRefresh) {
      try {
        const tokens = await refreshAccess(base, seededRefresh);
        storeSession(instanceId, base, tokens);
        return tokens;
      } catch {
        sessionCache.delete(key);
        if (!cfg.email?.trim() || !cfg.password) return null;
      }
    }

    if (cfg.email?.trim() && cfg.password) {
      const tokens = await loginLocal(cfg, base);
      storeSession(instanceId, base, tokens);
      return tokens;
    }
    return null;
  })();
  sessionInflight.set(key, authenticate);
  try {
    return await authenticate;
  } finally {
    if (sessionInflight.get(key) === authenticate) sessionInflight.delete(key);
  }
}

async function requestPublic<T>(
  instanceId: string,
  cfg: Config,
  path: string,
  opts: { timeoutMs?: number } = {},
): Promise<T> {
  let last: unknown;
  const headers: HeadersInit = {
    Accept: "application/json",
    ...(cfg.apiKey ? { Authorization: `Bearer ${cfg.apiKey}` } : {}),
  };
  for (const base of orderedCandidates(instanceId, cfg)) {
    try {
      const res = await fetch(joinUrl(base, path), {
        headers,
        cache: "no-store",
        signal: AbortSignal.timeout(opts.timeoutMs ?? 12_000),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json() as T;
      activeBases.set(instanceId, base);
      return json;
    } catch (error) {
      if (activeBases.get(instanceId) === base) activeBases.delete(instanceId);
      last = error;
    }
  }
  throw last instanceof Error ? last : new Error("Tracearr unavailable");
}

async function requestLibrary<T>(
  instanceId: string,
  cfg: Config,
  path: string,
  opts: { timeoutMs?: number } = {},
): Promise<T> {
  if (!hasLibraryCredentials(cfg)) {
    throw new Error("Tracearr library auth not configured");
  }

  let last: unknown;
  for (const base of orderedCandidates(instanceId, cfg)) {
    try {
      for (const force of [false, true]) {
        const session = await resolveLibraryToken(instanceId, cfg, base, force);
        if (!session) throw new Error("Tracearr library login failed");
        const res = await fetch(joinUrl(base, path), {
          headers: {
            Accept: "application/json",
            ...(session.accessToken ? { Authorization: `Bearer ${session.accessToken}` } : {}),
            ...(session.cookie ? { Cookie: session.cookie } : {}),
          },
          cache: "no-store",
          signal: AbortSignal.timeout(opts.timeoutMs ?? 12_000),
        });
        if ((res.status === 401 || res.status === 403) && !force && !cfg.sessionToken) {
          sessionCache.delete(cacheKey(instanceId, base));
          continue;
        }
        if (!res.ok) {
          const detail = (await res.json().catch(() => ({}))) as { message?: string; error?: string };
          throw new Error(detail.message || detail.error || `Tracearr storage HTTP ${res.status}`);
        }
        const json = await res.json() as T;
        activeBases.set(instanceId, base);
        return json;
      }
    } catch (error) {
      if (activeBases.get(instanceId) === base) activeBases.delete(instanceId);
      last = error;
    }
  }
  throw last instanceof Error ? last : new Error("Tracearr library unavailable");
}

function asArray(value: unknown): unknown[] {
  if (Array.isArray(value)) return value;
  if (value && typeof value === "object" && Array.isArray((value as { data?: unknown[] }).data)) {
    return (value as { data: unknown[] }).data;
  }
  return [];
}

async function settled<T>(promise: Promise<T>): Promise<T | null> {
  try {
    return await promise;
  } catch {
    return null;
  }
}

function tzParam() {
  try {
    return encodeURIComponent(Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC");
  } catch {
    return "UTC";
  }
}

export async function tracearrStatus(instanceId: string) {
  const cfg = await loadConfig(instanceId);
  const tz = tzParam();
  const libraryAuthConfigured = hasLibraryCredentials(cfg);

  const historyPageCount = 20;
  const historyPagePromises = Array.from({ length: historyPageCount }, (_, i) =>
    settled(requestPublic<unknown>(instanceId, cfg, `/api/v1/public/history?pageSize=100&page=${i + 1}`)),
  );

  const [
    health,
    stats,
    today,
    activity,
    users,
    streams,
    storage,
    duplicates,
    staleSummary,
    staleItems,
    neverWatchedItems,
    ...historyPages
  ] = await Promise.all([
    settled(requestPublic<Record<string, unknown>>(instanceId, cfg, "/api/v1/public/health")),
    settled(requestPublic<Record<string, unknown>>(instanceId, cfg, "/api/v1/public/stats")),
    settled(requestPublic<Record<string, unknown>>(instanceId, cfg, "/api/v1/public/stats/today")),
    settled(requestPublic<Record<string, unknown>>(instanceId, cfg, "/api/v1/public/activity")),
    settled(requestPublic<unknown>(instanceId, cfg, "/api/v1/public/users")),
    settled(requestPublic<unknown>(instanceId, cfg, "/api/v1/public/streams")),
    settled(
      requestLibrary<Record<string, unknown>>(
        instanceId,
        cfg,
        `/api/v1/library/storage?period=30d&timezone=${tz}`,
        { timeoutMs: 20_000 },
      ),
    ),
    settled(
      requestLibrary<Record<string, unknown>>(
        instanceId,
        cfg,
        "/api/v1/library/duplicates?page=1&pageSize=20",
        { timeoutMs: 20_000 },
      ),
    ),
    settled(
      requestLibrary<Record<string, unknown>>(
        instanceId,
        cfg,
        "/api/v1/library/stale?staleDays=90&category=all&page=1&pageSize=1&sortBy=size&sortOrder=desc",
        { timeoutMs: 25_000 },
      ),
    ),
    settled(
      requestLibrary<Record<string, unknown>>(
        instanceId,
        cfg,
        "/api/v1/library/stale?staleDays=90&category=stale&page=1&pageSize=20&sortBy=size&sortOrder=desc",
        { timeoutMs: 25_000 },
      ),
    ),
    settled(
      requestLibrary<Record<string, unknown>>(
        instanceId,
        cfg,
        "/api/v1/library/stale?staleDays=90&category=never_watched&page=1&pageSize=20&sortBy=size&sortOrder=desc",
        { timeoutMs: 25_000 },
      ),
    ),
    ...historyPagePromises,
  ]);

  const history = historyPages.flatMap((page) => asArray(page));
  const hasCore = !!(health || stats || today);
  if (!hasCore) throw new Error("Tracearr unavailable");

  const storageAvailable = !!(storage || duplicates || staleSummary || staleItems || neverWatchedItems);

  return {
    ...openUrlsFromConfig(cfg),
    health,
    stats: stats || {},
    today: today || {},
    activity: activity || {},
    users: asArray(users),
    streams: streams || { data: [] },
    history,
    storage: storage || null,
    duplicates: duplicates || null,
    libraryAuthConfigured,
    connectionSource: classifyConnectionSource(cfg, instanceId),
    stale: {
      summary: (staleSummary as { summary?: unknown } | null)?.summary
        || (staleItems as { summary?: unknown } | null)?.summary
        || (neverWatchedItems as { summary?: unknown } | null)?.summary
        || null,
      staleItems: (staleItems as { items?: unknown[] } | null)?.items || [],
      neverWatchedItems: (neverWatchedItems as { items?: unknown[] } | null)?.items || [],
      available: storageAvailable,
    },
  };
}

/** Fetch storage trend for a specific period (used by Storage tab range toggles). */
export async function tracearrStorage(instanceId: string, period: string) {
  const cfg = await loadConfig(instanceId);
  const safe = ["7d", "30d", "90d", "1y", "all"].includes(period) ? period : "30d";
  const tz = tzParam();
  return requestLibrary<Record<string, unknown>>(
    instanceId,
    cfg,
    `/api/v1/library/storage?period=${safe}&timezone=${tz}`,
    { timeoutMs: 20_000 },
  );
}
