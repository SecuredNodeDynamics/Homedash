import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, hasConnectionUrl, openUrlsFromConfig, primaryConnectionUrl } from "@/lib/open-href";

function classifyConnectionSource(base: string, cfg: Config): "private" | "public" | "unknown" {
  const normalize = (url?: string | null) => (url || "").trim().replace(/\/+$/, "").toLowerCase();
  const target = normalize(base);
  if (!target) return "unknown";
  const privateUrl = normalize(cfg.baseUrl);
  const publicUrl = normalize(cfg.fallbackUrl);
  if (privateUrl && target === privateUrl) return "private";
  if (publicUrl && target === publicUrl) return "public";
  if (privateUrl && !publicUrl) return "private";
  if (publicUrl && !privateUrl) return "public";
  return "unknown";
}

type Config = { baseUrl: string; fallbackUrl?: string; openFallbackUrl?: string; apiKey: string };
const value = (v: any) => Number(v?.parsed ?? v?.rawvalue ?? v?.rawval ?? v ?? 0) || 0;

// `portals` is a map of label -> URL (e.g. { "Web UI": "http://10.0.0.5:8080/" }) on
// apps that expose one; shape can vary slightly across TrueNAS versions, so this
// reads defensively instead of assuming a single format.
function firstPortalUrl(portals: any): string | null {
  if (!portals) return null;
  if (Array.isArray(portals)) return typeof portals[0] === "string" ? portals[0] : portals[0]?.url || null;
  if (typeof portals === "object") {
    const first = Object.values(portals)[0];
    return typeof first === "string" ? first : null;
  }
  return null;
}

async function withApi<T>(instanceId: string, fn: (api: (path: string, init?: RequestInit) => Promise<any>) => Promise<T>) {
  const raw = (await readWidgetConfig(instanceId)) as Config;
  if (!hasConnectionUrl(raw) || !raw.apiKey) {
    throw new Error("Configure a Private - IP or Fallback Public URL, and API key");
  }
  const cfg = { ...raw, baseUrl: primaryConnectionUrl(raw) };
  let lastError: unknown;
  for (const base of connectionCandidates(cfg)) {
    try {
      const api = async (path: string, init?: RequestInit) => {
        const response = await fetch(joinUrl(base, `/api/v2.0/${path}`), {
          ...init,
          headers: { Authorization: `Bearer ${cfg.apiKey}`, Accept: "application/json", ...(init?.body ? { "Content-Type": "application/json" } : {}), ...(init?.headers || {}) },
          cache: "no-store",
          signal: AbortSignal.timeout(15_000),
        });
        if (!response.ok) throw new Error(`TrueNAS HTTP ${response.status}`);
        const text = await response.text();
        return text ? JSON.parse(text) : null;
      };
      const result = await fn(api);
      return { result, cfg, connectionSource: classifyConnectionSource(base, raw) };
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("TrueNAS unavailable");
}

export async function fetchTruenasStatus(instanceId: string) {
  const { result, cfg, connectionSource } = await withApi(instanceId, async (api) => {
    const [system, pools, alerts, boot, apps, update] = await Promise.all([
      api("system/info"),
      api("pool"),
      api("alert/list"),
      api("boot/get_state").catch(() => null),
      api("app").catch(() => []),
      api("update/check_available").catch(() => null),
    ]);

    const enrichedPools = await Promise.all(
      (Array.isArray(pools) ? pools : []).map(async (pool: any) => {
        let dataset: any;
        try {
          const result = await api(`pool/dataset?id=${encodeURIComponent(pool.name)}`);
          dataset = Array.isArray(result) ? result.find((d) => d.name === pool.name) || result[0] : result;
        } catch {}
        const scan = pool.scan || null;
        return {
          id: pool.id,
          name: pool.name,
          healthy: pool.healthy !== false && pool.status !== "OFFLINE",
          status: pool.status || (pool.healthy === false ? "DEGRADED" : "HEALTHY"),
          used: value(dataset?.used),
          available: value(dataset?.available),
          scan: scan
            ? {
                function: scan.function || null,
                state: scan.state || null,
                endTime: scan.end_time?.$date || null,
                percentage: typeof scan.percentage === "number" ? scan.percentage : null,
                errors: typeof scan.errors === "number" ? scan.errors : null,
              }
            : null,
        };
      }),
    );

    const bootUsed = value(boot?.properties?.allocated ?? boot?.allocated);
    const bootFree = value(boot?.properties?.free ?? boot?.free);
    const host = {
      name: boot?.name || "boot-pool",
      healthy: boot ? boot.healthy !== false && boot.status !== "OFFLINE" : true,
      status: boot?.status || "—",
      used: bootUsed,
      available: bootFree,
    };

    const enrichedApps = (Array.isArray(apps) ? apps : []).map((a: any) => ({
      id: a.id || a.name,
      name: a.name || a.id,
      state: a.state || "UNKNOWN",
      version: a.human_version || a.version || "",
      latestVersion: a.latest_human_version || a.latest_version || a.latest_app_version || "",
      upgradeAvailable: Boolean(a.upgrade_available),
      imageUpdatesAvailable: Boolean(a.image_updates_available),
      containers: Number(a.active_workloads?.containers || 0),
      usedPorts: Array.isArray(a.active_workloads?.used_ports)
        ? a.active_workloads.used_ports.map((p: any) => ({
            containerPort: p.container_port,
            protocol: p.protocol,
            hostPort: p.host_ports?.[0]?.host_port ?? null,
          }))
        : [],
      portalUrl: firstPortalUrl(a.portals),
    }));

    return {
      system: {
        hostname: system?.hostname || "TrueNAS",
        version: system?.version || system?.full_version || "—",
        uptime: Number(system?.uptime_seconds || system?.uptime || 0),
        loadavg: system?.loadavg || [],
        model: system?.model || "",
        cores: Number(system?.cores || 0),
        physicalCores: Number(system?.physical_cores || 0),
        physmem: Number(system?.physmem || 0),
      },
      pools: enrichedPools,
      host,
      apps: enrichedApps,
      update: (() => {
        const changes = Array.isArray(update?.changes) ? update.changes : [];
        const last = changes[changes.length - 1];
        return {
          available: update?.status === "AVAILABLE",
          version: update?.new_version || update?.version || last?.version || "",
          changes: changes.length,
          changelog: last?.changelog || "",
          releaseNotesUrl: last?.release_notes_url || null,
        };
      })(),
      alerts: (Array.isArray(alerts) ? alerts : [])
        .filter((a: any) => a.dismissed === false)
        .map((a: any) => ({
          uuid: a.uuid || a.id,
          level: a.level,
          message: a.formatted || a.text,
          klass: a.klass,
          datetime: a.datetime?.$date || null,
          lastOccurrence: a.last_occurrence?.$date || null,
        }))
        .slice(0, 20),
    };
  });

  return { ...openUrlsFromConfig(cfg), ...result, connectionSource };
}

export async function runTruenasAction(instanceId: string, action: string, targetId?: string) {
  return (
    await withApi(instanceId, async (api) => {
      switch (action) {
        case "start-app":
          if (!targetId) throw new Error("appId required");
          return api(`app/id/${encodeURIComponent(targetId)}/start`, { method: "POST" });
        case "stop-app":
          if (!targetId) throw new Error("appId required");
          return api(`app/id/${encodeURIComponent(targetId)}/stop`, { method: "POST" });
        case "restart-app":
          if (!targetId) throw new Error("appId required");
          await api(`app/id/${encodeURIComponent(targetId)}/stop`, { method: "POST" });
          return api(`app/id/${encodeURIComponent(targetId)}/start`, { method: "POST" });
        case "upgrade-app":
          if (!targetId) throw new Error("appId required");
          return api(`app/id/${encodeURIComponent(targetId)}/upgrade`, { method: "POST", body: JSON.stringify({ app_version: "latest" }) });
        case "system-update":
          return api("update/update", { method: "POST", body: JSON.stringify({}) });
        case "scrub-pool":
          if (!targetId) throw new Error("poolId required");
          return api(`pool/id/${encodeURIComponent(targetId)}/scrub`, { method: "POST", body: JSON.stringify({ action: "START" }) });
        case "dismiss-alert":
          if (!targetId) throw new Error("alert uuid required");
          // TrueNAS's REST bridge for a method with a single scalar positional
          // argument (alert.dismiss(uuid)) expects the body to be that bare
          // JSON-encoded value — e.g. "abc-123" — not {"uuid": "abc-123"} or
          // ["abc-123"]. Wrapping it fails schema validation with HTTP 422.
          return api("alert/dismiss", { method: "POST", body: JSON.stringify(targetId) });
        default:
          throw new Error(`Unknown action: ${action}`);
      }
    })
  ).result;
}
