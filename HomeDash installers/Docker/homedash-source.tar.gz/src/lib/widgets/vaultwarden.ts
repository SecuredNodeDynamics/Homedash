import { request as httpsRequest } from "node:https";
import { request as httpRequestRaw } from "node:http";
import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { hasConnectionUrl, openUrlsFromConfig, primaryConnectionUrl, connectionCandidates } from "@/lib/open-href";

type Config = {
  baseUrl?: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  adminToken?: string;
  /** "user.<uuid>" — from the vault at Account Settings → Security → Keys. */
  apiKeyClientId?: string;
  /** That same user's API key, used as client_secret. */
  apiKeyClientSecret?: string;
};

export type VaultwardenUser = {
  id: string;
  email: string;
  name: string;
  enabled: boolean;
  emailVerified: boolean;
  premium: boolean;
  twoFactorEnabled: boolean;
  createdAt?: string;
};

export type VaultwardenStatus = {
  href: string;
  openFallbackUrl: string;
  connectionSource: "private" | "public" | "unknown";
  /** Why the Private - IP base was skipped, set only when connectionSource !== "private". */
  privateConnectionError?: string;
  domain: string;
  webVaultEnabled: boolean;
  websocketEnabled: boolean;
  signupsAllowed: boolean;
  invitationsAllowed: boolean;
  smtpEnabled: boolean;
  userCount: number;
  enabledUserCount: number;
  twoFactorCount: number;
  premiumCount: number;
};

export type VaultwardenUserAction = "enable" | "disable" | "delete" | "deauth" | "remove-2fa";
const USER_ACTIONS = new Set<VaultwardenUserAction>(["enable", "disable", "delete", "deauth", "remove-2fa"]);
export function isVaultwardenUserAction(v: string): v is VaultwardenUserAction {
  return USER_ACTIONS.has(v as VaultwardenUserAction);
}

// ---- transport: mirrors the docker widget's approach of trusting the exact
// "Private - IP" URL even when it presents a self-signed/internal-CA cert,
// while keeping full certificate validation for the public fallback URL. ----

type FetchLikeResponse = {
  ok: boolean;
  status: number;
  headers: { get(name: string): string | null };
  text(): Promise<string>;
  json(): Promise<any>;
};

function headersToPlain(init?: RequestInit["headers"]): Record<string, string> {
  const out: Record<string, string> = {};
  if (!init) return out;
  if (typeof Headers !== "undefined" && init instanceof Headers) {
    init.forEach((v, k) => (out[k] = v));
    return out;
  }
  if (Array.isArray(init)) {
    for (const [k, v] of init) out[k] = String(v);
    return out;
  }
  Object.assign(out, init as Record<string, string>);
  return out;
}

function insecureFetch(url: string, init: RequestInit = {}): Promise<FetchLikeResponse> {
  return new Promise((resolve, reject) => {
    let parsed: URL;
    try {
      parsed = new URL(url);
    } catch (err) {
      reject(err as Error);
      return;
    }
    const isHttps = parsed.protocol === "https:";
    const doRequest = isHttps ? httpsRequest : httpRequestRaw;
    const method = String(init.method || "GET").toUpperCase();
    const headers = headersToPlain(init.headers);

    let bodyBuf: Buffer | undefined;
    const rawBody = init.body as unknown;
    if (typeof rawBody === "string") bodyBuf = Buffer.from(rawBody);
    else if (rawBody instanceof Uint8Array) bodyBuf = Buffer.from(rawBody);
    if (bodyBuf && headers["Content-Length"] === undefined && headers["content-length"] === undefined) {
      headers["Content-Length"] = String(bodyBuf.length);
    }

    const req = doRequest(
      {
        hostname: parsed.hostname,
        port: parsed.port || (isHttps ? 443 : 80),
        path: `${parsed.pathname}${parsed.search}`,
        method,
        headers,
        rejectUnauthorized: false,
      } as any,
      (res) => {
        const chunks: Buffer[] = [];
        res.on("data", (chunk) => chunks.push(chunk as Buffer));
        res.on("end", () => {
          const buf = Buffer.concat(chunks);
          const status = res.statusCode || 0;
          const rawHeaders = res.headers || {};
          resolve({
            ok: status >= 200 && status < 300,
            status,
            headers: {
              get: (name: string) => {
                const v = rawHeaders[name.toLowerCase()];
                if (Array.isArray(v)) return v.join(", ");
                return v ?? null;
              },
            },
            text: async () => buf.toString("utf8"),
            json: async () => (buf.length ? JSON.parse(buf.toString("utf8")) : null),
          });
        });
      },
    );
    req.on("error", reject);
    const signal = init.signal;
    if (signal) {
      if (signal.aborted) {
        req.destroy();
        reject(new Error("The operation was aborted"));
        return;
      }
      signal.addEventListener(
        "abort",
        () => {
          req.destroy();
          reject(new Error("The operation was aborted"));
        },
        { once: true },
      );
    }
    if (bodyBuf) req.write(bodyBuf);
    req.end();
  });
}

function apiRoot(url: string) {
  return String(url || "").replace(/\/+$/, "");
}

function tlsFetch(privateUrl: string, base: string, url: string, init: RequestInit): Promise<FetchLikeResponse> {
  const isPrivateHttps = base.startsWith("https://") && !!privateUrl && apiRoot(base) === apiRoot(privateUrl);
  if (isPrivateHttps) return insecureFetch(url, init);
  return fetch(url, init) as unknown as Promise<FetchLikeResponse>;
}

function orderedBases(cfg: Config): string[] {
  const seen = new Set<string>();
  const bases: string[] = [];
  const push = (url?: string) => {
    const v = String(url || "").trim();
    if (!v || seen.has(v)) return;
    seen.add(v);
    bases.push(v);
  };
  push(cfg.baseUrl);
  push(cfg.fallbackUrl);
  if (bases.length) return bases;
  return connectionCandidates(cfg);
}

export type VaultwardenConnectionSource = "private" | "public" | "unknown";

function classifySource(conn: { privateUrl: string; fallbackUrl: string }, base: string): VaultwardenConnectionSource {
  const normalized = apiRoot(base);
  if (conn.privateUrl && apiRoot(conn.privateUrl) === normalized) return "private";
  if (conn.fallbackUrl && apiRoot(conn.fallbackUrl) === normalized) return "public";
  return "unknown";
}

async function withBases<T>(bases: string[], run: (base: string) => Promise<T>): Promise<T> {
  let lastError: unknown;
  for (const base of bases) {
    try {
      return await run(base);
    } catch (error) {
      const cause = error instanceof Error && "cause" in error ? (error as { cause?: unknown }).cause : undefined;
      console.warn(
        `[vaultwarden] base ${base} failed, trying next candidate:`,
        error instanceof Error ? error.message : error,
        cause ? `| cause: ${cause instanceof Error ? cause.message : String(cause)}` : "",
      );
      lastError = error;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("Vaultwarden unavailable");
}

type ResolvedConnection = {
  baseUrl: string;
  privateUrl: string;
  fallbackUrl: string;
  bases: string[];
  href: string;
  openFallbackUrl: string;
  adminToken: string;
};

function readConfig(cfg: Config): ResolvedConnection {
  if (!hasConnectionUrl(cfg)) {
    throw new Error("Configure a Private - IP or Fallback Public URL in Settings");
  }
  if (!String(cfg.adminToken || "").trim()) {
    throw new Error("Configure the Vaultwarden Admin Token in Settings");
  }
  const { href, openFallbackUrl } = openUrlsFromConfig(cfg);
  return {
    baseUrl: primaryConnectionUrl(cfg),
    privateUrl: String(cfg.baseUrl || "").trim(),
    fallbackUrl: String(cfg.fallbackUrl || "").trim(),
    bases: orderedBases(cfg),
    href: href || primaryConnectionUrl(cfg),
    openFallbackUrl,
    adminToken: String(cfg.adminToken || "").trim(),
  };
}

async function resolveConnection(instanceId: string) {
  const cfg = (await readWidgetConfig(instanceId)) as Config;
  return readConfig(cfg);
}

// ---- admin session: Vaultwarden's admin JSON/HTML routes are all gated behind
// a short-lived `VW_ADMIN` JWT cookie, obtained by POSTing the plaintext admin
// token as a login form (there is no bearer-token API for these routes). Cache
// the cookie per instance+base and transparently re-login on expiry/401,
// rather than re-authenticating on every request. ----

type Session = { cookie: string; base: string; expiresAt: number };
const sessions = new Map<string, Session>();

function parseCookie(setCookieHeader: string | null): string | null {
  if (!setCookieHeader) return null;
  const match = /VW_ADMIN=([^;]+)/.exec(setCookieHeader);
  return match ? `VW_ADMIN=${match[1]}` : null;
}

async function login(privateUrl: string, base: string, adminToken: string): Promise<string> {
  const body = `token=${encodeURIComponent(adminToken)}`;
  const response = await tlsFetch(privateUrl, base, joinUrl(base, "/admin"), {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      Accept: "text/html",
    },
    body,
    redirect: "manual",
    cache: "no-store",
    signal: AbortSignal.timeout(15_000),
  } as RequestInit);
  // A successful login redirects (303); an invalid token responds 401 with the login page.
  if (response.status === 401 || response.status === 429) {
    throw new Error(response.status === 429 ? "Vaultwarden rate-limited the admin login" : "Invalid admin token");
  }
  const cookie = parseCookie(response.headers.get("set-cookie"));
  if (!cookie) throw new Error("Vaultwarden admin login did not return a session cookie");
  return cookie;
}

async function getSession(conn: ResolvedConnection, base: string): Promise<string> {
  const key = `${base}`;
  const cached = sessions.get(key);
  if (cached && cached.expiresAt > Date.now()) return cached.cookie;
  const cookie = await login(conn.privateUrl, base, conn.adminToken);
  // The admin session JWT is valid for 20 minutes server-side; refresh a little early.
  sessions.set(key, { cookie, base, expiresAt: Date.now() + 18 * 60_000 });
  return cookie;
}

function invalidateSession(base: string) {
  sessions.delete(base);
}

/** Runs an authenticated admin call, retrying once after a fresh login on 401. */
async function adminFetch(
  conn: ResolvedConnection,
  base: string,
  path: string,
  init: RequestInit = {},
): Promise<FetchLikeResponse> {
  for (let attempt = 0; attempt < 2; attempt += 1) {
    const cookie = await getSession(conn, base);
    const response = await tlsFetch(conn.privateUrl, base, joinUrl(base, path), {
      ...init,
      headers: { ...(init.headers as Record<string, string>), Cookie: cookie, Accept: "application/json" },
      cache: "no-store",
      signal: AbortSignal.timeout(15_000),
    });
    if (response.status !== 401) return response;
    invalidateSession(base);
    if (attempt === 1) return response;
  }
  throw new Error("Vaultwarden admin session expired");
}

// ---- users (real JSON endpoint: GET /admin/users) ----

function toUser(raw: any): VaultwardenUser {
  return {
    id: String(raw?.Id || raw?.id || ""),
    email: String(raw?.Email || raw?.email || ""),
    name: String(raw?.Name || raw?.name || "") || String(raw?.Email || raw?.email || ""),
    enabled: Boolean(raw?.UserEnabled ?? raw?.userEnabled ?? true),
    emailVerified: Boolean(raw?.EmailVerified ?? raw?.emailVerified),
    premium: Boolean(raw?.Premium ?? raw?.premium),
    twoFactorEnabled: Boolean(raw?.TwoFactorEnabled ?? raw?.twoFactorEnabled),
    createdAt: raw?.CreatedAt ? String(raw.CreatedAt) : undefined,
  };
}

export async function fetchVaultwardenUsers(instanceId: string): Promise<VaultwardenUser[]> {
  const conn = await resolveConnection(instanceId);
  return withBases(conn.bases, async (base) => {
    const res = await adminFetch(conn, base, "/admin/users");
    if (!res.ok) throw new Error(`Vaultwarden HTTP ${res.status}`);
    const raw = await res.json();
    const list = Array.isArray(raw) ? raw : [];
    return list.map(toUser).sort((a, b) => a.email.localeCompare(b.email));
  });
}

export async function vaultwardenUserAction(instanceId: string, userId: string, action: VaultwardenUserAction) {
  if (!isVaultwardenUserAction(action)) throw new Error("Invalid Vaultwarden user action");
  const id = String(userId || "").trim();
  if (!id) throw new Error("Missing user id");
  const conn = await resolveConnection(instanceId);
  const path = `/admin/users/${encodeURIComponent(id)}/${action === "delete" ? "delete" : action}`;
  await withBases(conn.bases, async (base) => {
    const res = await adminFetch(conn, base, path, { method: "POST" });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      throw new Error(text || `Vaultwarden HTTP ${res.status}`);
    }
  });
}

// ---- removed feature compat stubs: the Organizations tab (and its
// /api/widgets/vaultwarden/organizations route) was removed in 0.1.4. These
// exports exist only so that an install which fails to delete the old route
// file (e.g. an install script predating removedFiles support) still
// compiles instead of hard-failing the build. Calling them is a bug. ----

export async function fetchVaultwardenOrgs(_instanceId: string): Promise<Array<Record<string, unknown>>> {
  throw new Error("Organizations are no longer supported by this widget");
}

export async function deleteVaultwardenOrg(_instanceId: string, _orgId: string): Promise<void> {
  throw new Error("Organizations are no longer supported by this widget");
}

// ---- config: GET /admin/diagnostics/config returns the effective config as
// JSON (used by Vaultwarden's own support-bundle feature); secrets like
// admin_token/database_url/smtp_password come back masked. POST /admin/config
// merges in only the fields present in the body (Vaultwarden's ConfigBuilder is
// all-Optional and only overrides fields that are actually sent) — so toggles
// here send just the one changed field rather than resubmitting the masked
// snapshot, which would otherwise overwrite secrets with the literal mask. ----

export type VaultwardenConfig = Record<string, unknown>;

export async function fetchVaultwardenConfig(instanceId: string): Promise<VaultwardenConfig> {
  const conn = await resolveConnection(instanceId);
  return withBases(conn.bases, async (base) => {
    const res = await adminFetch(conn, base, "/admin/diagnostics/config");
    if (!res.ok) throw new Error(`Vaultwarden HTTP ${res.status}`);
    return res.json();
  });
}

export async function updateVaultwardenConfig(instanceId: string, patch: Record<string, unknown>): Promise<VaultwardenConfig> {
  if (!patch || !Object.keys(patch).length) throw new Error("Missing config patch");
  const conn = await resolveConnection(instanceId);
  return withBases(conn.bases, async (base) => {
    const res = await adminFetch(conn, base, "/admin/config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(patch),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      throw new Error(text || `Vaultwarden HTTP ${res.status}`);
    }
    // Read the config straight back from the same base rather than trusting
    // the 200 and echoing the requested value: a 200 here only means
    // Vaultwarden accepted and validated the patch, not that the specific
    // field ended up set the way we asked (e.g. an environment variable of
    // the same name can still take precedence depending on instance setup).
    // Returning the real post-save value lets the UI show what's actually
    // persisted instead of a hopeful guess.
    const confirmRes = await adminFetch(conn, base, "/admin/diagnostics/config");
    if (!confirmRes.ok) throw new Error(`Vaultwarden HTTP ${confirmRes.status}`);
    return confirmRes.json();
  });
}

// ---- status summary ----

export async function fetchVaultwardenStatus(instanceId: string): Promise<VaultwardenStatus> {
  const conn = await resolveConnection(instanceId);
  const { href, openFallbackUrl, bases, privateUrl } = conn;

  // Walk bases in order (Private - IP always first, see orderedBases). Unlike
  // the generic withBases helper, this keeps the *reason* the private base
  // was skipped, so the UI can tell "never configured" apart from "timed out"
  // apart from "wrong admin token" instead of just showing an orange dot.
  let privateConnectionError: string | undefined;
  let lastError: unknown;

  for (const base of bases) {
    try {
      const [usersRes, configRes] = await Promise.all([
        adminFetch(conn, base, "/admin/users"),
        adminFetch(conn, base, "/admin/diagnostics/config"),
      ]);
      if (!usersRes.ok) throw new Error(`Vaultwarden HTTP ${usersRes.status}`);
      if (!configRes.ok) throw new Error(`Vaultwarden HTTP ${configRes.status}`);

      const usersRaw = await usersRes.json();
      const users = (Array.isArray(usersRaw) ? usersRaw : []).map(toUser);
      const config = await configRes.json();
      const connectionSource = classifySource(conn, base);

      return {
        href,
        openFallbackUrl,
        connectionSource,
        privateConnectionError: connectionSource === "private" ? undefined : privateConnectionError,
        domain: String(config?.domain || ""),
        webVaultEnabled: Boolean(config?.web_vault_enabled),
        websocketEnabled: Boolean(config?.enable_websocket),
        signupsAllowed: Boolean(config?.signups_allowed),
        invitationsAllowed: Boolean(config?.invitations_allowed),
        smtpEnabled: Boolean(config?._enable_smtp ?? config?.smtp_host),
        userCount: users.length,
        enabledUserCount: users.filter((u) => u.enabled).length,
        twoFactorCount: users.filter((u) => u.twoFactorEnabled).length,
        premiumCount: users.filter((u) => u.premium).length,
      };
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      if (apiRoot(base) === apiRoot(privateUrl)) privateConnectionError = message;
      console.warn(`[vaultwarden] base ${base} failed, trying next candidate:`, message);
      lastError = error;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("Vaultwarden unavailable");
}

// ---- Personal API Key auth (client_id/client_secret): this is NOT the
// Bitwarden Public API — Vaultwarden doesn't implement that (scope
// "api.organization" against /identity/connect/token 404s/500s there).
// What client_id/client_secret DOES drive on Vaultwarden is the same Personal
// API Key flow `bw login --apikey` uses: client_id is literally
// "user.<uuid>", client_secret is that one user's API key (Account Settings →
// Security → Keys), scope=api, grant_type=client_credentials. The resulting
// bearer token authenticates as that single vault user against the ordinary
// /api/* routes — not as the instance. Every function below can therefore
// only see/manage orgs where that user already holds Owner or Admin, can't
// list every user on the server, can't touch instance config, and is
// completely separate from the admin-token session logic above. ----

export type VaultwardenOrgMembership = {
  id: string;
  name: string;
  /** 0 Owner, 1 Admin, 2 User, 3 Manager, 4 Custom */
  type: number;
};

export type VaultwardenOrgMember = {
  /** organizationUserId — the id every action below expects, distinct from the vault-wide userId. */
  id: string;
  userId: string | null;
  name: string;
  email: string;
  /** 0 Owner, 1 Admin, 2 User, 3 Manager, 4 Custom */
  type: number;
  /** -1 Revoked, 0 Invited, 1 Accepted, 2 Confirmed */
  status: number;
  twoFactorEnabled: boolean;
};

export type VaultwardenOrgMemberAction = "reinvite" | "revoke" | "restore" | "remove";
const ORG_MEMBER_ACTIONS = new Set<VaultwardenOrgMemberAction>(["reinvite", "revoke", "restore", "remove"]);
export function isVaultwardenOrgMemberAction(v: string): v is VaultwardenOrgMemberAction {
  return ORG_MEMBER_ACTIONS.has(v as VaultwardenOrgMemberAction);
}

type ResolvedApiKeyConnection = {
  bases: string[];
  privateUrl: string;
  clientId: string;
  clientSecret: string;
};

function readApiKeyConnection(cfg: Config): ResolvedApiKeyConnection {
  if (!hasConnectionUrl(cfg)) {
    throw new Error("Configure a Private - IP or Fallback Public URL in Settings");
  }
  const clientId = String(cfg.apiKeyClientId || "").trim();
  const clientSecret = String(cfg.apiKeyClientSecret || "").trim();
  if (!clientId || !clientSecret) {
    throw new Error("Configure the Personal API Key Client ID and Client Secret in Settings");
  }
  if (!clientId.startsWith("user.")) {
    throw new Error('Client ID should look like "user.<uuid>" — copy it from the vault at Account Settings → Security → Keys');
  }
  return {
    bases: orderedBases(cfg),
    privateUrl: String(cfg.baseUrl || "").trim(),
    clientId,
    clientSecret,
  };
}

async function resolveApiKeyConnection(instanceId: string): Promise<ResolvedApiKeyConnection> {
  const cfg = (await readWidgetConfig(instanceId)) as Config;
  return readApiKeyConnection(cfg);
}

// Vaultwarden requires a device identity on every /identity/connect/token call
// (grant_type=password and grant_type=client_credentials alike) or it 400s
// with "No device id provided" — the values aren't validated against
// anything, they just need to be present, with device_identifier stable per
// caller so refresh/device bookkeeping on the server stays sane.
const DEVICE_IDENTIFIER = "8f3b6a2e-3f7f-4b8a-9c0d-6f6f6b6a5b4c";
const DEVICE_NAME = "hdwidget";
const DEVICE_TYPE = "21"; // Bitwarden's DeviceType enum value for "SDK" — closest fit for a headless integration

type ApiKeyToken = { accessToken: string; expiresAt: number };
const apiKeyTokens = new Map<string, ApiKeyToken>();

function apiKeyTokenKey(base: string, clientId: string) {
  return `${base}::${clientId}`;
}

async function fetchApiKeyToken(conn: ResolvedApiKeyConnection, base: string): Promise<string> {
  const key = apiKeyTokenKey(base, conn.clientId);
  const cached = apiKeyTokens.get(key);
  if (cached && cached.expiresAt > Date.now()) return cached.accessToken;

  const body = new URLSearchParams({
    grant_type: "client_credentials",
    scope: "api",
    client_id: conn.clientId,
    client_secret: conn.clientSecret,
    device_identifier: DEVICE_IDENTIFIER,
    device_name: DEVICE_NAME,
    device_type: DEVICE_TYPE,
  }).toString();

  const res = await tlsFetch(conn.privateUrl, base, joinUrl(base, "/identity/connect/token"), {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" },
    body,
    cache: "no-store",
    signal: AbortSignal.timeout(15_000),
  } as RequestInit);

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    let message = `Vaultwarden HTTP ${res.status}`;
    try {
      const parsed = JSON.parse(text);
      message = String(parsed?.error_description || parsed?.error || message);
    } catch {
      // response wasn't JSON — keep the generic HTTP-status message
    }
    if (res.status === 429) throw new Error("Vaultwarden rate-limited the login attempt");
    throw new Error(res.status === 400 ? `Invalid Client ID/Secret (${message})` : message);
  }

  const data = await res.json();
  const accessToken = String(data?.access_token || "");
  if (!accessToken) throw new Error("Vaultwarden token response did not include an access_token");
  const expiresIn = Number(data?.expires_in) || 3600;
  // Refresh a little early rather than racing the server-side expiry.
  apiKeyTokens.set(key, { accessToken, expiresAt: Date.now() + Math.max(expiresIn - 60, 30) * 1000 });
  return accessToken;
}

function invalidateApiKeyToken(base: string, clientId: string) {
  apiKeyTokens.delete(apiKeyTokenKey(base, clientId));
}

/** Runs an authenticated /api call as the personal-API-key user, retrying once after a fresh token on 401. */
async function apiKeyFetch(
  conn: ResolvedApiKeyConnection,
  base: string,
  path: string,
  init: RequestInit = {},
): Promise<FetchLikeResponse> {
  for (let attempt = 0; attempt < 2; attempt += 1) {
    const token = await fetchApiKeyToken(conn, base);
    const res = await tlsFetch(conn.privateUrl, base, joinUrl(base, path), {
      ...init,
      headers: { ...(init.headers as Record<string, string>), Authorization: `Bearer ${token}`, Accept: "application/json" },
      cache: "no-store",
      signal: AbortSignal.timeout(15_000),
    });
    if (res.status !== 401) return res;
    invalidateApiKeyToken(base, conn.clientId);
    if (attempt === 1) return res;
  }
  throw new Error("Vaultwarden personal API key session expired");
}

// ---- orgs this user can manage: GET /api/accounts/profile is the same call
// the web vault makes on load; it returns the logged-in user's profile with
// an embedded "organizations" array. Filtered to Owner/Admin because Manager
// and User roles can't call the member-management endpoints below anyway. ----

export async function fetchVaultwardenMyOrganizations(instanceId: string): Promise<VaultwardenOrgMembership[]> {
  const conn = await resolveApiKeyConnection(instanceId);
  return withBases(conn.bases, async (base) => {
    const res = await apiKeyFetch(conn, base, "/api/accounts/profile");
    if (!res.ok) throw new Error(`Vaultwarden HTTP ${res.status}`);
    const raw = await res.json();
    const orgs = Array.isArray(raw?.organizations) ? raw.organizations : Array.isArray(raw?.Organizations) ? raw.Organizations : [];
    return orgs
      .map((o: any) => ({
        id: String(o?.id ?? o?.Id ?? ""),
        name: String(o?.name ?? o?.Name ?? "(unnamed)"),
        type: Number(o?.type ?? o?.Type ?? 2),
      }))
      .filter((o: VaultwardenOrgMembership) => o.type <= 1) // Owner or Admin only
      .sort((a: VaultwardenOrgMembership, b: VaultwardenOrgMembership) => a.name.localeCompare(b.name));
  });
}

// ---- org member management: GET/DELETE/PUT/POST /api/organizations/{orgId}/users/*
// — the same endpoints the web vault's People page calls, scoped to one org.
// No invite/confirm here: confirming an invited member requires re-encrypting
// the org key with that member's public key client-side, which this token
// alone can't do safely. ----

function toOrgMember(raw: any): VaultwardenOrgMember {
  return {
    id: String(raw?.id ?? raw?.Id ?? ""),
    userId: raw?.userId ?? raw?.UserId ?? null,
    name: String(raw?.name ?? raw?.Name ?? "") || String(raw?.email ?? raw?.Email ?? ""),
    email: String(raw?.email ?? raw?.Email ?? ""),
    type: Number(raw?.type ?? raw?.Type ?? 2),
    status: Number(raw?.status ?? raw?.Status ?? 0),
    twoFactorEnabled: Boolean(raw?.twoFactorEnabled ?? raw?.TwoFactorEnabled),
  };
}

export async function fetchVaultwardenOrgMembers(instanceId: string, orgId: string): Promise<VaultwardenOrgMember[]> {
  const id = String(orgId || "").trim();
  if (!id) throw new Error("Missing organization id");
  const conn = await resolveApiKeyConnection(instanceId);
  return withBases(conn.bases, async (base) => {
    const res = await apiKeyFetch(conn, base, `/api/organizations/${encodeURIComponent(id)}/users`);
    if (!res.ok) throw new Error(`Vaultwarden HTTP ${res.status}`);
    const raw = await res.json();
    const list = Array.isArray(raw?.data) ? raw.data : Array.isArray(raw) ? raw : [];
    return list.map(toOrgMember).sort((a: VaultwardenOrgMember, b: VaultwardenOrgMember) => a.email.localeCompare(b.email));
  });
}

function orgMemberActionRequest(orgId: string, memberId: string, action: VaultwardenOrgMemberAction): { method: string; path: string } {
  const org = encodeURIComponent(orgId);
  const member = encodeURIComponent(memberId);
  switch (action) {
    case "reinvite":
      return { method: "POST", path: `/api/organizations/${org}/users/${member}/reinvite` };
    case "revoke":
      return { method: "PUT", path: `/api/organizations/${org}/users/${member}/revoke` };
    case "restore":
      return { method: "PUT", path: `/api/organizations/${org}/users/${member}/restore` };
    case "remove":
      return { method: "DELETE", path: `/api/organizations/${org}/users/${member}` };
  }
}

export async function vaultwardenOrgMemberAction(
  instanceId: string,
  orgId: string,
  memberId: string,
  action: VaultwardenOrgMemberAction,
) {
  if (!isVaultwardenOrgMemberAction(action)) throw new Error("Invalid organization member action");
  const org = String(orgId || "").trim();
  const member = String(memberId || "").trim();
  if (!org) throw new Error("Missing organization id");
  if (!member) throw new Error("Missing member id");

  const conn = await resolveApiKeyConnection(instanceId);
  const { method, path } = orgMemberActionRequest(org, member, action);
  await withBases(conn.bases, async (base) => {
    const res = await apiKeyFetch(conn, base, path, { method });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      throw new Error(text || `Vaultwarden HTTP ${res.status}`);
    }
  });
}

// ---- vault summary: METADATA ONLY, never decrypted. GET /api/ciphers (the
// same call the web vault makes on load) returns each cipher's type,
// favorite flag, and revision/creation timestamps in the clear — those are
// server-side bookkeeping fields, not vault secrets. The name/username/
// password/notes/URI fields on every cipher are Bitwarden EncStrings,
// symmetric-key-encrypted client-side with a key derived from the master
// password; this widget only ever holds an admin token or a personal-API-key
// bearer token, neither of which can derive that key, so those fields are
// deliberately left untouched and unread here. Do not extend this to surface
// cipher contents or to create/edit ciphers — a cipher written without the
// correct encryption key is stored successfully but reads back as a broken,
// undecryptable item in the real vault. ----

export type VaultwardenVaultSummary = {
  totalItems: number;
  logins: number;
  secureNotes: number;
  cards: number;
  identities: number;
  favorites: number;
  /** ISO timestamp of the most recently modified item, if any. */
  lastChangedAt?: string;
};

export async function fetchVaultwardenVaultSummary(instanceId: string): Promise<VaultwardenVaultSummary> {
  const conn = await resolveApiKeyConnection(instanceId);
  return withBases(conn.bases, async (base) => {
    const res = await apiKeyFetch(conn, base, "/api/ciphers");
    if (!res.ok) throw new Error(`Vaultwarden HTTP ${res.status}`);
    const raw = await res.json();
    const list: any[] = Array.isArray(raw?.Data) ? raw.Data : Array.isArray(raw?.data) ? raw.data : [];
    const items = list.filter((c) => !(c?.DeletedDate ?? c?.deletedDate));

    let logins = 0;
    let secureNotes = 0;
    let cards = 0;
    let identities = 0;
    let favorites = 0;
    let lastChangedAt: string | undefined;

    for (const c of items) {
      switch (Number(c?.Type ?? c?.type ?? 0)) {
        case 1:
          logins += 1;
          break;
        case 2:
          secureNotes += 1;
          break;
        case 3:
          cards += 1;
          break;
        case 4:
          identities += 1;
          break;
      }
      if (c?.Favorite ?? c?.favorite) favorites += 1;
      const rev = String(c?.RevisionDate ?? c?.revisionDate ?? "");
      if (rev && (!lastChangedAt || rev > lastChangedAt)) lastChangedAt = rev;
    }

    return { totalItems: items.length, logins, secureNotes, cards, identities, favorites, lastChangedAt };
  });
}
