import https from "https";
import { URL } from "url";
import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, primaryConnectionUrl } from "@/lib/open-href";

type Config = Record<string, string>;

export type WazuhAgent = {
  id: string;
  name: string;
  ip: string;
  status: string;
  os: string;
  version: string;
};

export type WazuhSummary = {
  total: number;
  active: number;
  disconnected: number;
  never_connected: number;
  pending: number;
};

export type WazuhAlert = {
  timestamp: string | null;
  ruleId: string;
  description: string;
  level: number;
  groups: string[];
  agentName: string;
  agentIp: string;
};

export type WazuhAlertResult = {
  hits: WazuhAlert[];
  counts: Record<string, number>;
  total: number;
  hasMore: boolean;
  searchAfter: unknown[] | null;
};

export type WazuhStatus = {
  href: string;
  openFallbackUrl: string;
  summary: WazuhSummary;
  agents: WazuhAgent[];
  alerts: WazuhAlertResult | null;
  alertError: string | null;
  agentNames: string[];
};

const ALERT_PAGE_SIZE = 25;

const TAB_GROUPS: Record<string, string[] | null> = {
  all: null,
  syscheck: ["syscheck"],
  auth: ["authentication_success", "authentication_failed", "sshd", "pam"],
  system: ["ossec", "rootcheck", "systemd", "syslog", "dpkg"],
  vuln: ["vulnerability-detector"],
};

function timeoutMs(ms: number) {
  return AbortSignal.timeout(ms);
}

/**
 * Wazuh manager + OpenSearch almost always present a self-signed / private CA
 * cert on LAN. Node's default fetch rejects those, which made Homedash skip the
 * working Private - IP and fall through to the Cloudflare URL (404 / 1010).
 */
function insecureHttpsJson<T>(
  url: string,
  init: { method?: string; headers?: Record<string, string>; body?: string } = {},
  ms = 12_000,
): Promise<T> {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const req = https.request(
      {
        protocol: parsed.protocol,
        hostname: parsed.hostname,
        port: parsed.port || 443,
        path: `${parsed.pathname}${parsed.search}`,
        method: init.method || "GET",
        headers: init.headers,
        rejectUnauthorized: false,
        timeout: ms,
      },
      (res) => {
        const chunks: Buffer[] = [];
        res.on("data", (chunk) => chunks.push(Buffer.from(chunk)));
        res.on("end", () => {
          const text = Buffer.concat(chunks).toString("utf8");
          const status = res.statusCode || 500;
          if (status >= 400) {
            reject(new Error(`Request failed (${status})`));
            return;
          }
          try {
            resolve((text ? JSON.parse(text) : {}) as T);
          } catch (error) {
            reject(error);
          }
        });
      },
    );
    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("Request timeout"));
    });
    if (init.body) req.write(init.body);
    req.end();
  });
}

async function fetchJson<T>(url: string, init: RequestInit = {}, ms = 10_000): Promise<T> {
  if (url.startsWith("https:")) {
    return insecureHttpsJson<T>(
      url,
      {
        method: (init.method as string | undefined) || "GET",
        headers: init.headers as Record<string, string> | undefined,
        body: typeof init.body === "string" ? init.body : undefined,
      },
      ms,
    );
  }

  const response = await fetch(url, {
    ...init,
    cache: "no-store",
    signal: timeoutMs(ms),
  });
  if (!response.ok) throw new Error(`Request failed (${response.status})`);
  return response.json() as Promise<T>;
}

async function withFallback<T>(
  bases: string[],
  run: (base: string) => Promise<T>,
): Promise<{ value: T; base: string }> {
  let lastError: unknown;
  for (const base of bases) {
    try {
      return { value: await run(base), base };
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("All Wazuh URLs failed");
}

function authCandidates(config: Config) {
  return connectionCandidates(config);
}

async function authenticate(bases: string[], username: string, password: string) {
  const basic = `Basic ${Buffer.from(`${username}:${password}`).toString("base64")}`;
  return withFallback(bases, async (base) => {
    const data = await fetchJson<{ data?: { token?: string } }>(
      joinUrl(base, "/security/user/authenticate"),
      {
        method: "POST",
        headers: {
          Authorization: basic,
          "Content-Type": "application/json",
        },
      },
      8_000,
    );
    const token = data.data?.token;
    if (!token) throw new Error("No token in Wazuh auth response");
    return token;
  });
}

async function wazuhGet<T>(bases: string[], token: string, path: string): Promise<T> {
  return (
    await withFallback(bases, async (base) =>
      fetchJson<T>(joinUrl(base, path), {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      }),
    )
  ).value;
}

function parseSummary(raw: unknown): WazuhSummary {
  const outer = (raw as { data?: unknown })?.data ?? raw ?? {};
  const nested = (outer as { data?: unknown })?.data ?? outer;
  const record = (nested || {}) as Record<string, unknown>;
  const conn = (record.connection || record) as Record<string, number>;
  const cfg = (record.configuration || {}) as Record<string, number>;
  const active = Number(conn.active || 0);
  const disconnected = Number(conn.disconnected || 0);
  const never_connected = Number(conn.never_connected ?? cfg.never_connected ?? 0);
  const pending = Number(conn.pending ?? cfg.pending ?? 0);
  const total = Number(record.total ?? active + disconnected + never_connected + pending);
  return { total, active, disconnected, never_connected, pending };
}

function mapAgent(raw: Record<string, unknown>): WazuhAgent {
  const os = (raw.os || {}) as Record<string, unknown>;
  return {
    id: String(raw.id || ""),
    name: String(raw.name || raw.id || "?"),
    ip: String(raw.ip || ""),
    status: String(raw.status || ""),
    os: String(os.name || os.platform || ""),
    version: String(raw.version || ""),
  };
}

function rangeMs(range: string) {
  if (range === "7d") return 7 * 24 * 60 * 60 * 1000;
  if (range === "30d") return 30 * 24 * 60 * 60 * 1000;
  return 24 * 60 * 60 * 1000;
}

export async function fetchWazuhAlerts(
  instanceId: string,
  options: {
    tab?: string;
    agent?: string;
    range?: string;
    searchAfter?: unknown[] | null;
  } = {},
): Promise<WazuhAlertResult> {
  const config = (await readWidgetConfig(instanceId)) as Config;
  const osUrl = (config.opensearchUrl || "").trim();
  if (!osUrl) throw new Error("Configure OpenSearch URL for alerts");

  const osUser = (config.osUsername || config.osUser || "admin").trim();
  const osPass = (config.osPassword || config.osPass || "").trim();
  if (!osPass) throw new Error("Configure OpenSearch password for alerts");

  const tab = options.tab || "all";
  const agent = options.agent || "all";
  const range = options.range || "24h";
  const must: unknown[] = [];
  const groups = TAB_GROUPS[tab] ?? null;
  if (groups) must.push({ terms: { "rule.groups": groups } });
  if (agent !== "all") must.push({ term: { "agent.name": agent } });
  must.push({
    range: { timestamp: { gte: new Date(Date.now() - rangeMs(range)).toISOString() } },
  });

  const body: Record<string, unknown> = {
    size: ALERT_PAGE_SIZE,
    sort: [{ timestamp: { order: "desc" } }],
    _source: [
      "timestamp",
      "rule.id",
      "rule.description",
      "rule.level",
      "rule.groups",
      "agent.name",
      "agent.ip",
    ],
    collapse: { field: "rule.id" },
    query: must.length ? { bool: { must } } : { match_all: {} },
  };

  if (!options.searchAfter?.length) {
    body.aggs = {
      by_level: {
        range: {
          field: "rule.level",
          ranges: [
            { key: "low", from: 1, to: 7 },
            { key: "medium", from: 7, to: 11 },
            { key: "high", from: 11, to: 14 },
            { key: "critical", from: 14, to: 20 },
          ],
        },
      },
    };
  } else {
    body.search_after = options.searchAfter;
  }

  const auth = `Basic ${Buffer.from(`${osUser}:${osPass}`).toString("base64")}`;
  const index = (config.opensearchIndex || "wazuh-alerts-4.x-*").trim();
  const data = await insecureHttpsJson<{
    hits?: {
      hits?: Array<{ _source?: Record<string, unknown>; sort?: unknown[] }>;
      total?: { value?: number } | number;
    };
    aggregations?: { by_level?: { buckets?: Array<{ key: string; doc_count: number }> } };
  }>(joinUrl(osUrl, `/${index}/_search`), {
    method: "POST",
    headers: {
      Authorization: auth,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });

  const hitsRaw = data.hits?.hits || [];
  const totalRaw = data.hits?.total;
  const total = typeof totalRaw === "number" ? totalRaw : Number(totalRaw?.value || 0);
  const counts: Record<string, number> = {};
  for (const bucket of data.aggregations?.by_level?.buckets || []) {
    counts[bucket.key] = bucket.doc_count;
  }

  return {
    hits: hitsRaw.map((hit) => {
      const source = hit._source || {};
      const rule = (source.rule || {}) as Record<string, unknown>;
      const agentInfo = (source.agent || {}) as Record<string, unknown>;
      return {
        timestamp: typeof source.timestamp === "string" ? source.timestamp : null,
        ruleId: String(rule.id || ""),
        description: String(rule.description || "Unknown rule"),
        level: Number(rule.level) || 0,
        groups: Array.isArray(rule.groups) ? rule.groups.map(String) : [],
        agentName: String(agentInfo.name || "?"),
        agentIp: String(agentInfo.ip || ""),
      };
    }),
    counts,
    total,
    hasMore: hitsRaw.length === ALERT_PAGE_SIZE,
    searchAfter: hitsRaw.length ? hitsRaw[hitsRaw.length - 1]?.sort || null : null,
  };
}

export async function fetchWazuhStatus(instanceId: string): Promise<WazuhStatus> {
  const config = (await readWidgetConfig(instanceId)) as Config;
  const username = config.username?.trim();
  const password = config.password?.trim();
  const bases = authCandidates(config);
  if (!bases.length || !username || !password) {
    throw new Error(
      "Configure a Private - IP or Fallback Public URL, username, and password in Settings",
    );
  }

  const { value: token, base: activeBase } = await authenticate(bases, username, password);
  const ordered = [activeBase, ...bases.filter((base) => base !== activeBase)];

  const [summaryRaw, agentsRaw] = await Promise.all([
    wazuhGet<{ data?: unknown }>(ordered, token, "/agents/summary/status"),
    wazuhGet<{ data?: { affected_items?: Array<Record<string, unknown>>; data?: { affected_items?: Array<Record<string, unknown>> } } }>(
      ordered,
      token,
      "/agents?limit=500&sort=-dateAdd&status=active,disconnected",
    ),
  ]);

  const agentsNested = agentsRaw.data?.data?.affected_items || agentsRaw.data?.affected_items || [];
  const agents = agentsNested.map(mapAgent);
  const summary = parseSummary(summaryRaw);
  const agentNames = [
    ...new Set(
      agents
        .map((agent) => agent.name)
        .filter((name) => name && name !== "?"),
    ),
  ].sort((a, b) => a.localeCompare(b));

  let alerts: WazuhAlertResult | null = null;
  let alertError: string | null = null;
  if ((config.opensearchUrl || "").trim() && (config.osPassword || config.osPass || "").trim()) {
    try {
      alerts = await fetchWazuhAlerts(instanceId, { tab: "all", agent: "all", range: "7d" });
    } catch (error) {
      alertError = error instanceof Error ? error.message : "Alerts unavailable";
    }
  }

  return {
    href: (config.publicUrl || config.dashboardUrl || primaryConnectionUrl(config) || "").trim(),
    openFallbackUrl: (config.openFallbackUrl || config.fallbackUrl || "").trim(),
    summary,
    agents,
    alerts,
    alertError,
    agentNames,
  };
}
