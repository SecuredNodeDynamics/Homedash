import { readWidgetConfig } from "@/lib/config";

type Config = {
  location?: string;
  units?: string;
  latitude?: string;
  longitude?: string;
};

export type WeatherStatus = {
  href: string;
  units: "imperial" | "metric";
  place: string;
  latitude: number;
  longitude: number;
  temperature: number;
  feelsLike: number;
  humidity: number;
  windSpeed: number;
  weatherCode: number;
  condition: string;
  isDay: boolean;
  source: "device" | "coords" | "location";
};

export type WeatherCoords = {
  latitude: number;
  longitude: number;
};

const WMO_LABELS: Record<number, string> = {
  0: "Clear sky",
  1: "Mainly clear",
  2: "Partly cloudy",
  3: "Overcast",
  45: "Fog",
  48: "Depositing rime fog",
  51: "Light drizzle",
  53: "Drizzle",
  55: "Heavy drizzle",
  56: "Freezing drizzle",
  57: "Heavy freezing drizzle",
  61: "Slight rain",
  63: "Rain",
  65: "Heavy rain",
  66: "Freezing rain",
  67: "Heavy freezing rain",
  71: "Slight snow",
  73: "Snow",
  75: "Heavy snow",
  77: "Snow grains",
  80: "Slight showers",
  81: "Showers",
  82: "Heavy showers",
  85: "Slight snow showers",
  86: "Heavy snow showers",
  95: "Thunderstorm",
  96: "Thunderstorm with hail",
  99: "Thunderstorm with heavy hail",
};

function weatherLabel(code: number) {
  return WMO_LABELS[code] || `Code ${code}`;
}

function parseCoord(value: string | number | null | undefined) {
  if (value == null || value === "") return null;
  const n = typeof value === "number" ? value : Number(String(value).trim());
  return Number.isFinite(n) ? n : null;
}

async function loadConfig(id: string) {
  const value = (await readWidgetConfig(id)) as Config;
  const units = value.units?.trim().toLowerCase() === "metric" ? "metric" : "imperial";
  const latitude = parseCoord(value.latitude);
  const longitude = parseCoord(value.longitude);
  const location = value.location?.trim() || "";
  if ((latitude == null) !== (longitude == null)) {
    throw new Error("Set both latitude and longitude, or leave both blank");
  }
  return { location, units: units as "imperial" | "metric", latitude, longitude };
}

type GeoPlace = {
  name: string;
  admin1?: string;
  country?: string;
  country_code?: string;
  latitude: number;
  longitude: number;
};

function formatPlace(place: { name: string; admin1?: string; country?: string; country_code?: string }) {
  const parts = [place.name, place.admin1, place.country || place.country_code].filter(Boolean);
  return parts.join(", ");
}

const US_STATE_NAMES: Record<string, string> = {
  al: "Alabama",
  ak: "Alaska",
  az: "Arizona",
  ar: "Arkansas",
  ca: "California",
  co: "Colorado",
  ct: "Connecticut",
  de: "Delaware",
  fl: "Florida",
  ga: "Georgia",
  hi: "Hawaii",
  id: "Idaho",
  il: "Illinois",
  in: "Indiana",
  ia: "Iowa",
  ks: "Kansas",
  ky: "Kentucky",
  la: "Louisiana",
  me: "Maine",
  md: "Maryland",
  ma: "Massachusetts",
  mi: "Michigan",
  mn: "Minnesota",
  ms: "Mississippi",
  mo: "Missouri",
  mt: "Montana",
  ne: "Nebraska",
  nv: "Nevada",
  nh: "New Hampshire",
  nj: "New Jersey",
  nm: "New Mexico",
  ny: "New York",
  nc: "North Carolina",
  nd: "North Dakota",
  oh: "Ohio",
  ok: "Oklahoma",
  or: "Oregon",
  pa: "Pennsylvania",
  ri: "Rhode Island",
  sc: "South Carolina",
  sd: "South Dakota",
  tn: "Tennessee",
  tx: "Texas",
  ut: "Utah",
  vt: "Vermont",
  va: "Virginia",
  wa: "Washington",
  wv: "West Virginia",
  wi: "Wisconsin",
  wy: "Wyoming",
  dc: "District of Columbia",
};

function normalizeLocationQuery(raw: string) {
  return raw.trim().replace(/\s+/g, " ");
}

/** Open-Meteo often fails on "City, ST" — try several cleaned variants. */
function locationQueryVariants(raw: string): string[] {
  const input = normalizeLocationQuery(raw);
  if (!input) return [];
  const variants: string[] = [];
  const push = (value: string) => {
    const next = normalizeLocationQuery(value);
    if (next && !variants.some((v) => v.toLowerCase() === next.toLowerCase())) variants.push(next);
  };

  push(input);
  push(input.replace(/,/g, " "));

  const parts = input.split(",").map((p) => p.trim()).filter(Boolean);
  if (parts.length >= 2) {
    const city = parts[0];
    const regionRaw = parts[1].replace(/\./g, "").trim();
    const regionKey = regionRaw.toLowerCase();
    const expanded = US_STATE_NAMES[regionKey] || regionRaw;
    push(`${city} ${expanded}`);
    push(city);
  } else {
    const tokens = input.split(/\s+/);
    if (tokens.length >= 2) {
      const maybeState = tokens[tokens.length - 1].replace(/\./g, "").toLowerCase();
      if (US_STATE_NAMES[maybeState]) {
        const city = tokens.slice(0, -1).join(" ");
        push(`${city} ${US_STATE_NAMES[maybeState]}`);
        push(city);
      }
    }
  }

  return variants;
}

function scorePlace(place: GeoPlace, preferredRegion: string) {
  if (!preferredRegion) return 0;
  const admin = (place.admin1 || "").toLowerCase();
  const region = preferredRegion.toLowerCase();
  const expanded = US_STATE_NAMES[region] || preferredRegion;
  if (admin === region || admin === expanded.toLowerCase()) return 100;
  if (admin.startsWith(region) || admin.includes(expanded.toLowerCase())) return 80;
  return 0;
}

async function searchPlaces(name: string, count = 5): Promise<GeoPlace[]> {
  const url = new URL("https://geocoding-api.open-meteo.com/v1/search");
  url.searchParams.set("name", name);
  url.searchParams.set("count", String(count));
  url.searchParams.set("language", "en");
  url.searchParams.set("format", "json");
  const response = await fetch(url, {
    cache: "no-store",
    signal: AbortSignal.timeout(10_000),
  });
  if (!response.ok) throw new Error(`Geocoding HTTP ${response.status}`);
  const json = (await response.json()) as { results?: GeoPlace[] };
  return Array.isArray(json.results) ? json.results : [];
}

async function geocode(location: string): Promise<GeoPlace> {
  const variants = locationQueryVariants(location);
  const commaRegion = location
    .split(",")
    .map((p) => p.trim())
    .filter(Boolean)[1]
    ?.replace(/\./g, "")
    .trim();
  const tokenRegion = (() => {
    const tokens = normalizeLocationQuery(location).split(/\s+/);
    const last = tokens[tokens.length - 1]?.replace(/\./g, "").toLowerCase() || "";
    return US_STATE_NAMES[last] ? last : "";
  })();
  const preferredRegion = commaRegion || tokenRegion;

  let lastError: Error | null = null;
  for (const query of variants) {
    try {
      const results = await searchPlaces(query, preferredRegion ? 8 : 3);
      if (!results.length) continue;
      if (preferredRegion) {
        const ranked = [...results].sort(
          (a, b) => scorePlace(b, preferredRegion) - scorePlace(a, preferredRegion),
        );
        if (scorePlace(ranked[0], preferredRegion) > 0) return ranked[0];
      }
      return results[0];
    } catch (error) {
      lastError = error instanceof Error ? error : new Error("Geocoding failed");
    }
  }
  throw lastError || new Error(`No results for “${location}”`);
}

export async function reverseGeocode(latitude: number, longitude: number): Promise<string> {
  const url = new URL("https://api.bigdatacloud.net/data/reverse-geocode-client");
  url.searchParams.set("latitude", String(latitude));
  url.searchParams.set("longitude", String(longitude));
  url.searchParams.set("localityLanguage", "en");
  try {
    const response = await fetch(url, {
      cache: "no-store",
      signal: AbortSignal.timeout(10_000),
    });
    if (!response.ok) return `${latitude.toFixed(2)}, ${longitude.toFixed(2)}`;
    const json = (await response.json()) as {
      city?: string;
      locality?: string;
      principalSubdivision?: string;
      countryCode?: string;
      countryName?: string;
    };
    const city = json.city || json.locality || "";
    const region = json.principalSubdivision || "";
    const country = json.countryCode || json.countryName || "";
    const parts = [city, region, country].filter(Boolean);
    return parts.length ? parts.join(", ") : `${latitude.toFixed(2)}, ${longitude.toFixed(2)}`;
  } catch {
    return `${latitude.toFixed(2)}, ${longitude.toFixed(2)}`;
  }
}

export async function fetchWeatherStatus(
  id: string,
  overrides?: Partial<WeatherCoords>,
): Promise<WeatherStatus> {
  const cfg = await loadConfig(id);

  const overrideLat = parseCoord(overrides?.latitude);
  const overrideLon = parseCoord(overrides?.longitude);

  let latitude: number | null = null;
  let longitude: number | null = null;
  let place = cfg.location;
  let source: WeatherStatus["source"] = "location";

  if (cfg.latitude != null && cfg.longitude != null) {
    latitude = cfg.latitude;
    longitude = cfg.longitude;
    source = "coords";
    place = cfg.location || (await reverseGeocode(latitude, longitude));
  } else if (overrideLat != null && overrideLon != null) {
    latitude = overrideLat;
    longitude = overrideLon;
    source = "device";
    place = await reverseGeocode(latitude, longitude);
  } else if (cfg.location) {
    const geo = await geocode(cfg.location);
    latitude = geo.latitude;
    longitude = geo.longitude;
    place = formatPlace(geo);
    source = "location";
  } else {
    throw new Error("Allow location access, or set a city / lat-lon in Settings");
  }

  const tempUnit = cfg.units === "metric" ? "celsius" : "fahrenheit";
  const windUnit = cfg.units === "metric" ? "kmh" : "mph";

  const url = new URL("https://api.open-meteo.com/v1/forecast");
  url.searchParams.set("latitude", String(latitude));
  url.searchParams.set("longitude", String(longitude));
  url.searchParams.set(
    "current",
    "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,is_day",
  );
  url.searchParams.set("temperature_unit", tempUnit);
  url.searchParams.set("wind_speed_unit", windUnit);
  url.searchParams.set("timezone", "auto");

  const response = await fetch(url, {
    cache: "no-store",
    signal: AbortSignal.timeout(10_000),
  });
  if (!response.ok) throw new Error(`Weather HTTP ${response.status}`);
  const json = (await response.json()) as {
    current?: {
      temperature_2m?: number;
      apparent_temperature?: number;
      relative_humidity_2m?: number;
      weather_code?: number;
      wind_speed_10m?: number;
      is_day?: number;
    };
  };
  const current = json.current;
  if (!current) throw new Error("Weather response missing current conditions");

  const weatherCode = Number(current.weather_code ?? 0);
  const href = `https://open-meteo.com/#/lat=${latitude}&lng=${longitude}&zoom=8`;

  return {
    href,
    units: cfg.units,
    place: place || `${latitude.toFixed(2)}, ${longitude.toFixed(2)}`,
    latitude,
    longitude,
    temperature: Number(current.temperature_2m ?? 0),
    feelsLike: Number(current.apparent_temperature ?? 0),
    humidity: Number(current.relative_humidity_2m ?? 0),
    windSpeed: Number(current.wind_speed_10m ?? 0),
    weatherCode,
    condition: weatherLabel(weatherCode),
    isDay: Number(current.is_day ?? 1) === 1,
    source,
  };
}
