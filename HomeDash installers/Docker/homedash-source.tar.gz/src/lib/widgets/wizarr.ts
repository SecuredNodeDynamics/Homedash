import { readWidgetConfig } from "@/lib/config";
import { joinUrl } from "@/lib/proxy";
import { connectionCandidates, hasConnectionUrl, openUrlsFromConfig, primaryConnectionUrl } from "@/lib/open-href";

type Config = {
  baseUrl: string;
  fallbackUrl?: string;
  publicUrl?: string;
  openFallbackUrl?: string;
  apiKey: string;
};

export type WizarrUser = {
  id?: number | string;
  username?: string;
  email?: string;
  server?: string;
  media_server?: string;
  created_at?: string;
  createdAt?: string;
};

export type WizarrInvitation = {
  id?: number | string;
  code?: string;
  token?: string;
  label?: string;
  display_name?: string;
  expires?: string;
  status?: string;
  used_by?: number | string;
  uses?: number;
  unlimited?: boolean;
  max_uses?: number;
  url?: string;
};

export type WizarrServer = {
  id?: number | string;
  name?: string;
  server_type?: string;
};

export type WizarrConnectionSource = "private" | "public" | "unknown";

function apiRoot(url: string) {
  return String(url || "").replace(/\/$/, "");
}

// Classifies which URL a request actually connected through. This must compare
// against the raw config values (read fresh from config), not `cfg.baseUrl` —
// by the time a caller holds `cfg`, `cfg.baseUrl` has already been passed through
// `primaryConnectionUrl()`, which can substitute the fallback URL as "primary"
// and would otherwise cause a successful private connection to be mislabeled
// as public (or vice versa).
async function classifyConnectionSource(
  instanceId: string,
  base: string,
): Promise<WizarrConnectionSource> {
  const raw = (await readWidgetConfig(instanceId)) as Partial<Config>;
  const normalized = apiRoot(base);
  if (raw.baseUrl && apiRoot(raw.baseUrl) === normalized) return "private";
  if (raw.fallbackUrl && apiRoot(raw.fallbackUrl) === normalized) return "public";
  return "unknown";
}

function unwrapList<T>(value: unknown, keys: string[]): T[] {
  if (Array.isArray(value)) return value as T[];
  if (!value || typeof value !== "object") return [];
  const obj = value as Record<string, unknown>;
  for (const key of keys) {
    if (Array.isArray(obj[key])) return obj[key] as T[];
  }
  if (Array.isArray(obj.data)) return obj.data as T[];
  return [];
}

async function loadConfig(instanceId: string): Promise<Config> {
  const value = (await readWidgetConfig(instanceId)) as Partial<Config>;
  if (!hasConnectionUrl(value) || !value.apiKey) {
    throw new Error("Configure a Private - IP or Fallback Public URL, and API key in Settings");
  }
  return { ...value, baseUrl: primaryConnectionUrl(value) } as Config;
}

async function wzrFetch<T>(
  config: Config,
  path: string,
  init: RequestInit = {},
): Promise<{ data: T; baseUrl: string }> {
  let last: unknown;
  const bases = connectionCandidates(config);
  for (const base of bases) {
    try {
      const response = await fetch(joinUrl(base, path), {
        ...init,
        headers: {
          "X-API-KEY": config.apiKey,
          Accept: "application/json",
          "Content-Type": "application/json",
          ...(init.headers as Record<string, string> | undefined),
        },
        cache: "no-store",
        signal: AbortSignal.timeout(10_000),
      });
      if (!response.ok) throw new Error(`Wizarr ${response.status}: ${path}`);
      if (response.status === 204) return { data: null as T, baseUrl: base };
      const text = await response.text();
      return { data: (text ? JSON.parse(text) : null) as T, baseUrl: base };
    } catch (error) {
      last = error;
    }
  }
  throw last instanceof Error ? last : new Error("Wizarr unavailable");
}

export async function wizarrStatus(instanceId: string) {
  const config = await loadConfig(instanceId);
  const [usersRes, invitesRes, serversRes] = await Promise.allSettled([
    wzrFetch(config, "/api/users"),
    wzrFetch(config, "/api/invitations"),
    wzrFetch(config, "/api/servers"),
  ]);

  const users =
    usersRes.status === "fulfilled"
      ? unwrapList<WizarrUser>(usersRes.value.data, ["users"])
      : [];
  const invitations =
    invitesRes.status === "fulfilled"
      ? unwrapList<WizarrInvitation>(invitesRes.value.data, ["invitations"])
      : [];
  const servers =
    serversRes.status === "fulfilled"
      ? unwrapList<WizarrServer>(serversRes.value.data, ["servers"])
      : [];

  const failed =
    usersRes.status === "rejected" &&
    invitesRes.status === "rejected" &&
    serversRes.status === "rejected";
  if (failed) {
    const reason =
      usersRes.status === "rejected"
        ? usersRes.reason
        : invitesRes.status === "rejected"
          ? invitesRes.reason
          : serversRes.status === "rejected"
            ? serversRes.reason
            : null;
    throw reason instanceof Error ? reason : new Error("Wizarr unavailable");
  }

  const activeBase =
    (usersRes.status === "fulfilled" && usersRes.value.baseUrl) ||
    (invitesRes.status === "fulfilled" && invitesRes.value.baseUrl) ||
    (serversRes.status === "fulfilled" && serversRes.value.baseUrl) ||
    config.baseUrl;

  return {
    ...openUrlsFromConfig(config),
    baseUrl: activeBase,
    users,
    invitations,
    servers,
    connectionSource: await classifyConnectionSource(instanceId, activeBase),
  };
}

export async function wizarrCreateInvite(
  instanceId: string,
  payload: {
    server_ids: string | number;
    duration: string;
    allow_downloads: boolean;
    allow_live_tv: boolean;
    expires_in_days?: number;
    label?: string;
  },
) {
  const config = await loadConfig(instanceId);
  const { data, baseUrl } = await wzrFetch<Record<string, unknown>>(config, "/api/invitations", {
    method: "POST",
    body: JSON.stringify(payload),
  });
  const rawUrl =
    (data?.url as string | undefined) ||
    ((data?.invitation as { url?: string } | undefined)?.url) ||
    ((data?.data as { url?: string } | undefined)?.url) ||
    "";
  if (!rawUrl) throw new Error("No invitation URL in response");

  const publicBase = (config.publicUrl?.trim() || config.baseUrl).replace(/\/$/, "");
  const url = rawUrl
    .replace(baseUrl.replace(/\/$/, ""), publicBase)
    .replace("https://wizarr.janzenmediagroup.com", publicBase)
    .replace(config.baseUrl.replace(/\/$/, ""), publicBase);

  return { url, raw: data };
}

export async function wizarrDeleteInvite(instanceId: string, id: string) {
  const config = await loadConfig(instanceId);
  await wzrFetch(config, `/api/invitations/${encodeURIComponent(id)}`, { method: "DELETE" });
  return { ok: true };
}
