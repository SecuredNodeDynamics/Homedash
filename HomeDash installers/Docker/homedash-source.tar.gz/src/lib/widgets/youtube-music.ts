import { readWidgetConfig } from "@/lib/config";

// ── Types ───────────────────────────────────────────────────────────────
//
// Shapes mirror the YTMDA Companion Server API v1:
// https://github.com/ytmdesktop/ytmdesktop/wiki/v2-%E2%80%90-Companion-Server-API-v1

export type YtmLikeStatus = "liked" | "disliked" | "indifferent" | "unknown";

export type YtmTrack = {
  id: string | null;
  title: string;
  artists: string;
  album: string | null;
  thumbnailUrl: string | null;
  durationMs: number;
  likeStatus: YtmLikeStatus;
  isLive: boolean;
};

export type YtmPlaybackState = {
  isPlaying: boolean;
  isBuffering: boolean;
  progressMs: number | null;
  volume: number | null;
  muted: boolean;
  repeat: "off" | "all" | "one";
  track: YtmTrack | null;
  playlistId: string | null;
};

export type YtmRecentItem = { playedAt: string; track: YtmTrack };

export type YtmQueueItem = {
  index: number; // position within items+automixItems, used for playQueueIndex
  videoId: string | null;
  title: string;
  author: string;
  durationLabel: string;
  thumbnailUrl: string | null;
  selected: boolean;
  isAutomix: boolean;
};

export type YtmPlaylist = {
  id: string;
  title: string;
};

export type YtmStatus = {
  playback: YtmPlaybackState | null;
  playbackError: string | null;
  recentlyPlayed: YtmRecentItem[];
  queue: YtmQueueItem[];
  playlists: YtmPlaylist[];
};

type YtmConfig = {
  host: string;
  port: number;
  token: string;
};

// ── Config ──────────────────────────────────────────────────────────────

export async function loadYtmConfig(instanceId: string): Promise<YtmConfig> {
  const config = (await readWidgetConfig(instanceId)) as Partial<{
    host: string;
    port: string;
    token: string;
  }>;
  if (!config.token) {
    throw new Error("Pair with YouTube Music Desktop App and add the Companion Server Token in Settings");
  }
  const host = (config.host || "127.0.0.1").trim();
  const port = Number(config.port) || 9863;
  return { host, port, token: config.token };
}

// ── Fetch helper ────────────────────────────────────────────────────────

async function ytmFetch(config: YtmConfig, path: string, init: RequestInit = {}): Promise<Response> {
  const url = `http://${config.host}:${config.port}/api/v1${path}`;
  let response: Response;
  try {
    response = await fetch(url, {
      ...init,
      headers: {
        ...(init.headers || {}),
        Authorization: config.token,
        Accept: "application/json",
      },
      cache: "no-store",
      signal: AbortSignal.timeout(10_000),
    });
  } catch {
    throw new Error(`Couldn't reach YouTube Music Desktop App at ${config.host}:${config.port}`);
  }

  if (response.status === 401 || response.status === 403) {
    throw new Error("YTMDA rejected the token — re-pair in the Companion Server settings");
  }
  return response;
}

// ── Normalizers ─────────────────────────────────────────────────────────

type RawThumbnail = { url?: unknown; width?: unknown; height?: unknown };

function pickThumbnail(thumbnails: unknown, preferLargest: boolean): string | null {
  const list = Array.isArray(thumbnails) ? (thumbnails as RawThumbnail[]) : [];
  if (!list.length) return null;
  const sorted = [...list].sort((a, b) => (Number(a.width) || 0) - (Number(b.width) || 0));
  const pick = preferLargest ? sorted[sorted.length - 1] : sorted[0];
  return typeof pick?.url === "string" ? pick.url : null;
}

function toLikeStatus(raw: unknown): YtmLikeStatus {
  if (raw === 2) return "liked";
  if (raw === 0) return "disliked";
  if (raw === 1) return "indifferent";
  return "unknown";
}

function toTrack(video: Record<string, unknown> | null | undefined, preferLargeArt = true): YtmTrack | null {
  if (!video || !video.id) return null;
  return {
    id: String(video.id),
    title: String(video.title ?? "Unknown title"),
    artists: String(video.author ?? "Unknown artist"),
    album: typeof video.album === "string" ? video.album : null,
    thumbnailUrl: pickThumbnail(video.thumbnails, preferLargeArt),
    durationMs: (Number(video.durationSeconds) || 0) * 1000,
    likeStatus: toLikeStatus(video.likeStatus),
    isLive: Boolean(video.isLive),
  };
}

function toRepeat(mode: unknown): "off" | "all" | "one" {
  if (mode === 1) return "all";
  if (mode === 2) return "one";
  return "off";
}

// ── State (Now Playing + Queue) ────────────────────────────────────────

type RawState = {
  player?: {
    trackState?: number;
    videoProgress?: number;
    volume?: number;
    muted?: boolean;
    queue?: {
      items?: Record<string, unknown>[];
      automixItems?: Record<string, unknown>[];
      repeatMode?: number;
      selectedItemIndex?: number;
    } | null;
  };
  video?: Record<string, unknown> | null;
  playlistId?: string | null;
};

async function fetchState(
  config: YtmConfig,
): Promise<{ playback: YtmPlaybackState | null; queue: YtmQueueItem[] }> {
  const response = await ytmFetch(config, "/state");
  if (!response.ok) throw new Error(`YTMDA state endpoint returned ${response.status}`);
  const json = (await response.json()) as RawState;

  const player = json.player || {};
  const track = toTrack(json.video, true);
  const trackState = Number(player.trackState);

  const playback: YtmPlaybackState | null = track
    ? {
        isPlaying: trackState === 1,
        isBuffering: trackState === 2,
        progressMs: typeof player.videoProgress === "number" ? player.videoProgress * 1000 : null,
        volume: typeof player.volume === "number" ? player.volume : null,
        muted: Boolean(player.muted),
        repeat: toRepeat(player.queue?.repeatMode),
        track,
        playlistId: json.playlistId ?? null,
      }
    : null;

  const items = Array.isArray(player.queue?.items) ? player.queue!.items! : [];
  const automixItems = Array.isArray(player.queue?.automixItems) ? player.queue!.automixItems! : [];
  const flat = [...items, ...automixItems];
  const queue: YtmQueueItem[] = flat.map((row, index) => ({
    index,
    videoId: typeof row.videoId === "string" ? row.videoId : null,
    title: String(row.title ?? "Unknown title"),
    author: String(row.author ?? ""),
    durationLabel: String(row.duration ?? ""),
    thumbnailUrl: pickThumbnail(row.thumbnails, false),
    selected: Boolean(row.selected),
    isAutomix: index >= items.length,
  }));

  return { playback, queue };
}

async function fetchPlaylists(config: YtmConfig): Promise<YtmPlaylist[]> {
  const response = await ytmFetch(config, "/playlists");
  if (!response.ok) throw new Error(`YTMDA playlists endpoint returned ${response.status}`);
  const json = await response.json();
  const items = Array.isArray(json) ? json : [];
  return items
    .map((row: Record<string, unknown>) => ({
      id: String(row.id ?? ""),
      title: String(row.title ?? "Untitled playlist"),
    }))
    .filter((p: YtmPlaylist) => p.id);
}

// ── Locally-tracked recent history ─────────────────────────────────────
//
// YTMDA's Companion Server has no "recently played" endpoint, so we keep a
// small rolling log per instance in memory, updated whenever the polled
// state shows a different track than last time. This only reflects plays
// that happened while this server process has been running.

type RecentEntry = { playedAt: string; track: YtmTrack };
const recentHistory = new Map<string, RecentEntry[]>();
const lastSeenTrackId = new Map<string, string>();
const MAX_RECENT = 25;

function recordIfNewTrack(instanceId: string, track: YtmTrack | null) {
  if (!track || !track.id) return;
  if (lastSeenTrackId.get(instanceId) === track.id) return;
  lastSeenTrackId.set(instanceId, track.id);

  const history = recentHistory.get(instanceId) ?? [];
  history.unshift({ playedAt: new Date().toISOString(), track });
  recentHistory.set(instanceId, history.slice(0, MAX_RECENT));
}

// ── Status ──────────────────────────────────────────────────────────────

export async function fetchYtmStatus(instanceId: string): Promise<YtmStatus> {
  const config = await loadYtmConfig(instanceId);

  // Now Playing/queue is fetched separately from playlists so a failure in
  // one (e.g. YTMDA closed, network hiccup) doesn't take out data that did
  // load successfully — same pattern as the Spotify widget's status route.
  const stateResult = await fetchState(config).then(
    (value) => ({ ok: true as const, value }),
    (error: unknown) => ({ ok: false as const, error }),
  );
  const playlists = await fetchPlaylists(config).catch(() => []);

  const playback = stateResult.ok ? stateResult.value.playback : null;
  const queue = stateResult.ok ? stateResult.value.queue : [];
  const playbackError = stateResult.ok
    ? null
    : stateResult.error instanceof Error
      ? stateResult.error.message
      : "Failed to load Now Playing";

  if (stateResult.ok) {
    recordIfNewTrack(instanceId, stateResult.value.playback?.track ?? null);
  }
  const recentlyPlayed = recentHistory.get(instanceId) ?? [];

  return { playback, playbackError, recentlyPlayed, queue, playlists };
}

// ── Actions ─────────────────────────────────────────────────────────────

export type YtmActionKind =
  | "play"
  | "pause"
  | "next"
  | "previous"
  | "seek"
  | "volume"
  | "mute"
  | "unmute"
  | "shuffle"
  | "repeat"
  | "toggle-like"
  | "toggle-dislike"
  | "play-queue-index"
  | "play-video"
  | "play-playlist";

async function sendCommand(config: YtmConfig, command: string, data?: unknown) {
  const response = await ytmFetch(config, "/command", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data === undefined ? { command } : { command, data }),
  });

  if (!response.ok) {
    if (response.status === 429) {
      throw new Error("YTMDA is rate-limiting requests — try again shortly");
    }
    let message = `YTMDA command returned ${response.status}`;
    try {
      const errJson = await response.json();
      if (errJson?.error) message = String(errJson.error);
    } catch {
      // ignore non-JSON error bodies
    }
    throw new Error(message);
  }
  return null;
}

export async function performYtmAction(
  instanceId: string,
  kind: YtmActionKind,
  payload: Record<string, unknown>,
) {
  const config = await loadYtmConfig(instanceId);

  switch (kind) {
    case "play":
      return sendCommand(config, "play");
    case "pause":
      return sendCommand(config, "pause");
    case "next":
      return sendCommand(config, "next");
    case "previous":
      return sendCommand(config, "previous");
    case "seek": {
      const seconds = Math.max(0, Math.round((Number(payload.positionMs) || 0) / 1000));
      return sendCommand(config, "seekTo", seconds);
    }
    case "volume": {
      const percent = Math.min(100, Math.max(0, Number(payload.volumePercent) || 0));
      return sendCommand(config, "setVolume", percent);
    }
    case "mute":
      return sendCommand(config, "mute");
    case "unmute":
      return sendCommand(config, "unmute");
    case "shuffle":
      return sendCommand(config, "shuffle");
    case "repeat": {
      const mode = payload.mode === "all" ? 1 : payload.mode === "one" ? 2 : 0;
      return sendCommand(config, "repeatMode", mode);
    }
    case "toggle-like":
      return sendCommand(config, "toggleLike");
    case "toggle-dislike":
      return sendCommand(config, "toggleDislike");
    case "play-queue-index": {
      const index = Number(payload.index);
      if (!Number.isInteger(index) || index < 0) throw new Error("Missing queue index");
      return sendCommand(config, "playQueueIndex", index);
    }
    case "play-video": {
      const videoId = String(payload.videoId || "");
      if (!videoId) throw new Error("Missing video id");
      return sendCommand(config, "changeVideo", { videoId, playlistId: null });
    }
    case "play-playlist": {
      const playlistId = String(payload.playlistId || "");
      if (!playlistId) throw new Error("Missing playlist id");
      return sendCommand(config, "changeVideo", { videoId: null, playlistId });
    }
    default:
      throw new Error("Unknown action");
  }
}
