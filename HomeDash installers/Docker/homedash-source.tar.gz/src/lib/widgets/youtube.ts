import { readWidgetConfig } from "@/lib/config";

type Config = {
  apiKey?: string;
  channels?: string;
};

type YtSearchItem = {
  id: string;
  title: string;
  channel: string;
  thumbnail: string;
  publishedAt: string;
};

async function cfg(instanceId: string) {
  return (await readWidgetConfig(instanceId)) as Config;
}

function parseVideoId(input: string): string | null {
  const value = String(input || "").trim();
  if (!value) return null;
  if (/^[\w-]{11}$/.test(value)) return value;
  try {
    const url = new URL(value.startsWith("http") ? value : `https://${value}`);
    if (url.hostname.includes("youtu.be")) {
      const id = url.pathname.split("/").filter(Boolean)[0];
      return id && /^[\w-]{11}$/.test(id) ? id : null;
    }
    if (url.hostname.includes("youtube.com")) {
      const v = url.searchParams.get("v");
      if (v && /^[\w-]{11}$/.test(v)) return v;
      const parts = url.pathname.split("/").filter(Boolean);
      if ((parts[0] === "embed" || parts[0] === "shorts" || parts[0] === "live") && parts[1] && /^[\w-]{11}$/.test(parts[1])) {
        return parts[1];
      }
    }
  } catch {
    /* not a URL */
  }
  return null;
}

export function youtubeThumb(id: string) {
  return `https://i.ytimg.com/vi/${encodeURIComponent(id)}/hqdefault.jpg`;
}

export function youtubeWatchUrl(id: string) {
  return `https://www.youtube.com/watch?v=${encodeURIComponent(id)}`;
}

export function youtubeEmbedUrl(id: string) {
  return `https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}?autoplay=1&rel=0`;
}

export async function youtubeSearch(instanceId: string, query: string) {
  const config = await cfg(instanceId);
  const q = String(query || "").trim();
  if (!q) return { items: [] as YtSearchItem[] };

  const directId = parseVideoId(q);
  if (directId) {
    return {
      items: [
        {
          id: directId,
          title: `Video ${directId}`,
          channel: "YouTube",
          thumbnail: youtubeThumb(directId),
          publishedAt: "",
        },
      ] satisfies YtSearchItem[],
      direct: true,
    };
  }

  if (!config.apiKey) {
    throw new Error("Add a YouTube Data API key in Settings to search, or paste a video URL/ID");
  }

  const params = new URLSearchParams({
    part: "snippet",
    type: "video",
    maxResults: "12",
    q,
    key: config.apiKey,
  });
  const response = await fetch(`https://www.googleapis.com/youtube/v3/search?${params}`, {
    cache: "no-store",
    signal: AbortSignal.timeout(10000),
  });
  const json = (await response.json()) as {
    error?: { message?: string };
    items?: Array<{
      id?: { videoId?: string };
      snippet?: {
        title?: string;
        channelTitle?: string;
        publishedAt?: string;
        thumbnails?: { medium?: { url?: string }; high?: { url?: string }; default?: { url?: string } };
      };
    }>;
  };
  if (!response.ok) {
    throw new Error(json.error?.message || `YouTube search failed (${response.status})`);
  }

  const items = (json.items || [])
    .map((item) => {
      const id = item.id?.videoId;
      if (!id) return null;
      const thumb =
        item.snippet?.thumbnails?.medium?.url ||
        item.snippet?.thumbnails?.high?.url ||
        item.snippet?.thumbnails?.default?.url ||
        youtubeThumb(id);
      return {
        id,
        title: item.snippet?.title || "Untitled",
        channel: item.snippet?.channelTitle || "",
        thumbnail: thumb,
        publishedAt: item.snippet?.publishedAt || "",
      } satisfies YtSearchItem;
    })
    .filter(Boolean) as YtSearchItem[];

  return { items, direct: false };
}

export async function youtubeChannelFeed(instanceId: string) {
  const config = await cfg(instanceId);
  const configured = String(config.channels || "")
    .split(",")
    .map((id) => id.trim())
    .filter(Boolean);

  // Built-in defaults so Live always has cards before Settings are filled in.
  const defaults = [
    "UCAuKGTrlew8mwuaze6HI-Kg",
    "UCaICGDabRMrPLmXnyIfH29w",
    "UCXHS4zp25ITnryx8Q9a1_1w",
  ];
  const channels = (configured.length ? configured : defaults).slice(0, 4);

  if (config.apiKey && !configured.length) {
    try {
      const params = new URLSearchParams({
        part: "snippet",
        chart: "mostPopular",
        maxResults: "12",
        regionCode: "US",
        key: config.apiKey,
      });
      const response = await fetch(`https://www.googleapis.com/youtube/v3/videos?${params}`, {
        cache: "no-store",
        signal: AbortSignal.timeout(10000),
      });
      const json = (await response.json()) as {
        items?: Array<{
          id?: string;
          snippet?: {
            title?: string;
            channelTitle?: string;
            publishedAt?: string;
            thumbnails?: { medium?: { url?: string }; high?: { url?: string } };
          };
        }>;
      };
      if (response.ok && json.items?.length) {
        return {
          items: json.items
            .map((item) => {
              const id = item.id;
              if (!id) return null;
              return {
                id,
                title: item.snippet?.title || "Untitled",
                channel: item.snippet?.channelTitle || "",
                thumbnail:
                  item.snippet?.thumbnails?.medium?.url ||
                  item.snippet?.thumbnails?.high?.url ||
                  youtubeThumb(id),
                publishedAt: item.snippet?.publishedAt || "",
              } satisfies YtSearchItem;
            })
            .filter(Boolean) as YtSearchItem[],
        };
      }
    } catch {
      /* fall through to channel RSS */
    }
  }

  const results = await Promise.all(channels.map((channelId) => fetchChannelVideos(channelId, config.apiKey)));

  const items = results
    .flat()
    .sort((a, b) => Date.parse(b.publishedAt || "") - Date.parse(a.publishedAt || ""))
    .slice(0, 12);

  return { items };
}

async function fetchChannelVideos(channelId: string, apiKey?: string): Promise<YtSearchItem[]> {
  if (apiKey) {
    try {
      const params = new URLSearchParams({
        part: "snippet",
        channelId,
        order: "date",
        type: "video",
        maxResults: "4",
        key: apiKey,
      });
      const response = await fetch(`https://www.googleapis.com/youtube/v3/search?${params}`, {
        cache: "no-store",
        signal: AbortSignal.timeout(10000),
      });
      const json = (await response.json()) as {
        items?: Array<{
          id?: { videoId?: string };
          snippet?: {
            title?: string;
            channelTitle?: string;
            publishedAt?: string;
            thumbnails?: { medium?: { url?: string }; high?: { url?: string } };
          };
        }>;
      };
      if (response.ok) {
        return (json.items || [])
          .map((item) => {
            const id = item.id?.videoId;
            if (!id) return null;
            return {
              id,
              title: item.snippet?.title || "Untitled",
              channel: item.snippet?.channelTitle || "",
              thumbnail:
                item.snippet?.thumbnails?.medium?.url ||
                item.snippet?.thumbnails?.high?.url ||
                youtubeThumb(id),
              publishedAt: item.snippet?.publishedAt || "",
            } satisfies YtSearchItem;
          })
          .filter(Boolean) as YtSearchItem[];
      }
    } catch {
      /* fall through */
    }
  }

  try {
    const feedUrl = `https://www.youtube.com/feeds/videos.xml?channel_id=${encodeURIComponent(channelId)}`;
    const proxy = await fetch(
      `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(feedUrl)}`,
      { cache: "no-store", signal: AbortSignal.timeout(10000) },
    );
    if (proxy.ok) {
      const json = (await proxy.json()) as {
        items?: Array<{ title?: string; link?: string; thumbnail?: string; pubDate?: string; author?: string }>;
      };
      const mapped = (json.items || [])
        .slice(0, 4)
        .map((item) => {
          const id = parseVideoId(item.link || "") || "";
          return {
            id,
            title: item.title || "Untitled",
            channel: item.author || "",
            thumbnail: item.thumbnail || (id ? youtubeThumb(id) : ""),
            publishedAt: item.pubDate || "",
          } satisfies YtSearchItem;
        })
        .filter((item) => item.id);
      if (mapped.length) return mapped;
    }
  } catch {
    /* try raw atom */
  }

  try {
    const response = await fetch(
      `https://www.youtube.com/feeds/videos.xml?channel_id=${encodeURIComponent(channelId)}`,
      {
        cache: "no-store",
        signal: AbortSignal.timeout(10000),
        headers: { Accept: "application/atom+xml,application/xml,text/xml" },
      },
    );
    if (!response.ok) return [];
    const xml = await response.text();
    return parseAtomFeed(xml).slice(0, 4);
  } catch {
    return [];
  }
}

function parseAtomFeed(xml: string): YtSearchItem[] {
  const entries = xml.split(/<entry[\s>]/i).slice(1);
  return entries
    .map((entry) => {
      const id =
        entry.match(/<yt:videoId>([^<]+)<\/yt:videoId>/i)?.[1] ||
        entry.match(/<id>yt:video:([^<]+)<\/id>/i)?.[1] ||
        "";
      if (!id) return null;
      const title = decodeXml(entry.match(/<title[^>]*>([^<]*)<\/title>/i)?.[1] || "Untitled");
      const channel = decodeXml(entry.match(/<name>([^<]*)<\/name>/i)?.[1] || "");
      const publishedAt = entry.match(/<published>([^<]*)<\/published>/i)?.[1] || "";
      const thumb =
        entry.match(/<media:thumbnail[^>]*url="([^"]+)"/i)?.[1] || youtubeThumb(id);
      return {
        id,
        title,
        channel,
        thumbnail: thumb,
        publishedAt,
      } satisfies YtSearchItem;
    })
    .filter(Boolean) as YtSearchItem[];
}

function decodeXml(value: string) {
  return value
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");
}

export { parseVideoId };
