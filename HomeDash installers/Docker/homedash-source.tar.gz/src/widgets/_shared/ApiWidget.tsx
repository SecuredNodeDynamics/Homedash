"use client";

import { useCallback, useState } from "react";
import { useWidgetInstance } from "./instance-context";
import { useOpenHref } from "./use-open-href";
import { useWidgetPoll } from "./use-widget-poll";

type Data = {
  href: string;
  openFallbackUrl?: string;
  stats: Array<[string, number]>;
  items: unknown[];
};

const label = (item: unknown) => {
  if (typeof item === "string") return item;
  if (!item || typeof item !== "object") return "Unknown";
  const value = item as Record<string, unknown>;
  return String(value.title || value.name || value.username || value.artistName || value.displayTitle || value.label || "Untitled");
};

export function ApiWidget({ id, name, prefix }: { id: string; name: string; prefix: string }) {
  const instance = useWidgetInstance();
  const [data, setData] = useState<Data>();
  const [error, setError] = useState("");
  const load = useCallback(async () => {
    try {
      const response = await fetch(`/api/widgets/${encodeURIComponent(id)}/status?instance=${encodeURIComponent(instance?.instanceId || id)}`);
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Failed to load");
      setData(payload);
      setError("");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Failed to load");
    }
  }, [id, instance?.instanceId]);
  const { rootRef } = useWidgetPoll(load, { intervalMs: 60_000 });
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);

  return <div className="hd-widget-body" ref={rootRef}><div className={`${prefix}-host`}><div className={`${prefix}-shell`}>
    <header className={`${prefix}-hdr`}><div className={`${prefix}-hdr-left`}><b className={`${prefix}-title`}>{instance?.label || name}</b></div>{data && <a className={`${prefix}-open-link`} href={openHref} target="_blank" rel="noreferrer">Open</a>}</header>
    {data ? <><div className={`${prefix}-stat-grid`}>{data.stats.map(([key, value]) => <div className={`${prefix}-stat`} key={key}><strong>{Number(value).toLocaleString()}</strong><span>{key}</span></div>)}</div>
      <div className={`${prefix}-scroll`}>{data.items.length ? data.items.map((item, index) => <div className={`${prefix}-row`} key={index}><div className={`${prefix}-row-body`}><div className={`${prefix}-row-title`}>{label(item)}</div></div></div>) : <div className={`${prefix}-empty`}>No items to display</div>}</div>
    </> : <div className={`${prefix}-empty`}>{error || "Loading…"}</div>}
  </div></div></div>;
}
