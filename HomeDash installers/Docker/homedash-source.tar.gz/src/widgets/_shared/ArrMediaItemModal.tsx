"use client";

import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import type { ArrQueueCard } from "./ArrOverviewWidget";

type ItemTab = "all" | "monitored" | "episodes" | "queued";
type Action = "monitor" | "unmonitor" | "search" | "refresh" | "queue-remove" | "queue-blocklist";

export function ArrMediaItemModal({
  kind,
  instanceId,
  item,
  tab,
  onClose,
  onChanged,
}: {
  kind: "radarr" | "sonarr";
  instanceId: string;
  item: ArrQueueCard;
  tab: ItemTab;
  onClose: () => void;
  onChanged: () => void;
}) {
  const [working, setWorking] = useState<Action | "">("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [monitored, setMonitored] = useState(Boolean(item.monitored));
  const queued = tab === "queued";
  const targetId = queued ? item.queueId : item.mediaId;

  useEffect(() => {
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = overflow;
      document.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  async function run(action: Action) {
    if (!targetId) {
      setError("This item does not include the required Radarr/Sonarr id.");
      return;
    }
    if (
      (action === "queue-remove" || action === "queue-blocklist") &&
      !window.confirm(
        action === "queue-blocklist"
          ? `Remove “${item.title}” from the download client and add the release to the blocklist?`
          : `Remove “${item.title}” from the download client?`,
      )
    ) return;

    setWorking(action);
    setMessage("");
    setError("");
    try {
      const response = await fetch(`/api/widgets/${kind}/media-manager`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, action, targetId }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Action failed");
      const labels: Record<Action, string> = {
        monitor: "Monitoring enabled.",
        unmonitor: "Monitoring disabled.",
        search: "Automatic search started.",
        refresh: "Refresh and scan started.",
        "queue-remove": "Download removed from the queue.",
        "queue-blocklist": "Download removed and release blocklisted.",
      };
      setMessage(labels[action]);
      if (action === "monitor") setMonitored(true);
      if (action === "unmonitor") setMonitored(false);
      onChanged();
      if (queued) window.setTimeout(onClose, 650);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Action failed");
    } finally {
      setWorking("");
    }
  }

  return createPortal(
    <div className="arr-item-modal-scrim" role="presentation" onMouseDown={onClose}>
      <section
        className="arr-item-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="arr-item-modal-title"
        onMouseDown={(event) => event.stopPropagation()}
      >
        <div className="arr-item-modal__hero">
          {item.poster ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={item.poster} alt="" />
          ) : <div className="arr-item-modal__placeholder">{item.title.charAt(0)}</div>}
          <div>
            <span>{kind === "radarr" ? "Radarr" : "Sonarr"} · {queued ? "Queue" : "Library"}</span>
            <h2 id="arr-item-modal-title">{item.title}</h2>
            <p>{item.meta || item.state || "Media item"}</p>
            {item.state ? <em>{item.state}</em> : null}
          </div>
          <button type="button" className="arr-tool-btn" onClick={onClose}>Close</button>
        </div>

        {item.progress != null ? (
          <div className="arr-item-modal__progress">
            <span style={{ width: `${item.progress}%` }} />
            <small>{item.progress}% complete</small>
          </div>
        ) : null}

        {error ? <div className="arr-manager__notice is-error">{error}</div> : null}
        {message ? <div className="arr-manager__notice is-success">{message}</div> : null}

        <div className="arr-item-modal__actions">
          {item.href ? (
            <a className="arr-item-action is-primary" href={item.href} target="_blank" rel="noopener noreferrer">
              Open in {kind === "radarr" ? "Radarr" : "Sonarr"}
            </a>
          ) : null}
          {queued ? (
            <>
              <button type="button" className="arr-item-action" disabled={Boolean(working)} onClick={() => void run("queue-remove")}>
                {working === "queue-remove" ? "Removing…" : "Remove download"}
              </button>
              <button type="button" className="arr-item-action is-danger" disabled={Boolean(working)} onClick={() => void run("queue-blocklist")}>
                {working === "queue-blocklist" ? "Removing…" : "Remove & blocklist"}
              </button>
            </>
          ) : (
            <>
              <button type="button" className="arr-item-action" disabled={Boolean(working)} onClick={() => void run(monitored ? "unmonitor" : "monitor")}>
                {working === "monitor" || working === "unmonitor"
                  ? "Updating…"
                  : monitored ? "Stop monitoring" : "Start monitoring"}
              </button>
              <button type="button" className="arr-item-action" disabled={Boolean(working)} onClick={() => void run("search")}>
                {working === "search" ? "Starting…" : "Automatic search"}
              </button>
              <button type="button" className="arr-item-action" disabled={Boolean(working)} onClick={() => void run("refresh")}>
                {working === "refresh" ? "Starting…" : "Refresh & scan"}
              </button>
            </>
          )}
        </div>
      </section>
    </div>,
    document.body,
  );
}
