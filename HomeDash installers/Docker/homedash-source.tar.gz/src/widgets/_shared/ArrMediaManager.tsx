"use client";

import { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import type { ArrInteractiveRelease, ArrManagerMissingItem } from "@/lib/widgets/arr";

function formatBytes(value: number) {
  if (!(value > 0)) return "Unknown size";
  const units = ["B", "KB", "MB", "GB", "TB"];
  const power = Math.min(units.length - 1, Math.floor(Math.log(value) / Math.log(1024)));
  return `${(value / 1024 ** power).toFixed(power >= 3 ? 2 : 0)} ${units[power]}`;
}

export function ArrMediaManager({
  kind,
  instanceId,
  initialQuery = "",
  onClose,
}: {
  kind: "radarr" | "sonarr";
  instanceId: string;
  initialQuery?: string;
  onClose: () => void;
}) {
  const [items, setItems] = useState<ArrManagerMissingItem[]>([]);
  const [query, setQuery] = useState(initialQuery);
  const [selected, setSelected] = useState<ArrManagerMissingItem | null>(null);
  const [releases, setReleases] = useState<ArrInteractiveRelease[]>([]);
  const [loadingItems, setLoadingItems] = useState(true);
  const [searching, setSearching] = useState(false);
  const [grabbing, setGrabbing] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const filtered = useMemo(() => {
    const value = query.trim().toLocaleLowerCase();
    if (!value) return items;
    return items.filter((item) =>
      `${item.title} ${item.subtitle}`.toLocaleLowerCase().includes(value),
    );
  }, [items, query]);

  useEffect(() => {
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = overflow;
      document.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const response = await fetch(
          `/api/widgets/${kind}/media-manager?instance=${encodeURIComponent(instanceId)}&action=missing`,
        );
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Could not load missing media");
        if (!cancelled) {
          const nextItems = (Array.isArray(data.items) ? data.items : []) as ArrManagerMissingItem[];
          setItems(nextItems);
          if (initialQuery) {
            const normalized = initialQuery.trim().toLocaleLowerCase();
            const match =
              nextItems.find((item) => item.title.trim().toLocaleLowerCase() === normalized) ||
              nextItems.find((item) => item.title.toLocaleLowerCase().includes(normalized));
            if (match) void searchReleases(match);
          }
        }
      } catch (reason) {
        if (!cancelled) setError(reason instanceof Error ? reason.message : "Could not load missing media");
      } finally {
        if (!cancelled) setLoadingItems(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [initialQuery, instanceId, kind]);

  async function searchReleases(item: ArrManagerMissingItem) {
    setSelected(item);
    setReleases([]);
    setMessage("");
    setError("");
    setSearching(true);
    try {
      const response = await fetch(
        `/api/widgets/${kind}/media-manager?instance=${encodeURIComponent(instanceId)}&action=search&targetId=${item.id}`,
      );
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Interactive search failed");
      const next = (Array.isArray(data.releases) ? data.releases : []) as ArrInteractiveRelease[];
      next.sort((a, b) => Number(a.rejected) - Number(b.rejected) || (b.seeders || 0) - (a.seeders || 0));
      setReleases(next);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Interactive search failed");
    } finally {
      setSearching(false);
    }
  }

  async function grab(release: ArrInteractiveRelease) {
    if (!selected) return;
    const confirmed = window.confirm(
      `Grab “${release.title}” from ${release.indexer}?`,
    );
    if (!confirmed) return;
    setGrabbing(release.guid);
    setError("");
    setMessage("");
    try {
      const response = await fetch(`/api/widgets/${kind}/media-manager`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          instance: instanceId,
          guid: release.guid,
          indexerId: release.indexerId,
        }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not grab release");
      setMessage(`Sent “${release.title}” to ${kind === "radarr" ? "Radarr" : "Sonarr"}.`);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Could not grab release");
    } finally {
      setGrabbing("");
    }
  }

  return createPortal(
    <div className="arr-manager-scrim" role="presentation" onMouseDown={onClose}>
      <section
        className="arr-manager"
        role="dialog"
        aria-modal="true"
        aria-labelledby="arr-manager-title"
        onMouseDown={(event) => event.stopPropagation()}
      >
        <header className="arr-manager__head">
          <div>
            <span>{kind === "radarr" ? "Radarr" : "Sonarr"}</span>
            <h2 id="arr-manager-title">Missing media manager</h2>
            <p>Search your interactive indexers and choose the release to grab.</p>
          </div>
          <button type="button" className="arr-tool-btn" onClick={onClose}>Close</button>
        </header>

        <div className="arr-manager__body">
          <aside className="arr-manager__missing">
            <div className="arr-manager__search">
              <svg viewBox="0 0 24 24" width="17" height="17" aria-hidden="true">
                <path fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" d="m21 21-4.4-4.4M19 11.5A7.5 7.5 0 1 1 4 11.5a7.5 7.5 0 0 1 15 0Z" />
              </svg>
              <input
                type="search"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder={`Filter missing ${kind === "radarr" ? "movies" : "episodes"}…`}
                autoFocus
              />
            </div>
            <div className="arr-manager__section-title">
              <span>Missing</span>
              <small>{filtered.length}</small>
            </div>
            <div className="arr-manager__media-list">
              {loadingItems ? <div className="arr-manager__empty">Loading missing media…</div> : null}
              {!loadingItems && !filtered.length ? (
                <div className="arr-manager__empty">{query ? "No matching media" : "Nothing is missing"}</div>
              ) : null}
              {filtered.map((item) => (
                <button
                  type="button"
                  key={`${item.id}:${item.mediaId}`}
                  className={`arr-manager__media${selected?.id === item.id ? " is-active" : ""}`}
                  onClick={() => void searchReleases(item)}
                >
                  {item.poster ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={item.poster} alt="" />
                  ) : <span className="arr-manager__media-placeholder">{item.title.charAt(0)}</span>}
                  <span>
                    <strong>{item.title}</strong>
                    <small>{item.subtitle}</small>
                  </span>
                  <b aria-hidden="true">›</b>
                </button>
              ))}
            </div>
          </aside>

          <main className="arr-manager__releases">
            <div className="arr-manager__release-head">
              <div>
                <span>Interactive search</span>
                <strong>{selected?.title || "Select missing media"}</strong>
                {selected ? <small>{selected.subtitle}</small> : null}
              </div>
              {releases.length ? <em>{releases.length} releases</em> : null}
            </div>
            {error ? <div className="arr-manager__notice is-error">{error}</div> : null}
            {message ? <div className="arr-manager__notice is-success">{message}</div> : null}
            {searching ? <div className="arr-manager__empty">Searching configured indexers…</div> : null}
            {!selected && !searching ? (
              <div className="arr-manager__empty arr-manager__empty--hero">
                <span>⌕</span>
                Choose a missing title to search every configured indexer.
              </div>
            ) : null}
            {selected && !searching && !releases.length && !error ? (
              <div className="arr-manager__empty">No releases were returned.</div>
            ) : null}
            <div className="arr-manager__release-list">
              {releases.map((release) => (
                <article className={`arr-manager__release${release.rejected ? " is-rejected" : ""}`} key={`${release.indexerId}:${release.guid}`}>
                  <div className="arr-manager__release-copy">
                    <strong title={release.title}>{release.title}</strong>
                    <div>
                      <span>{release.quality}</span>
                      <span>{formatBytes(release.size)}</span>
                      <span>{release.indexer}</span>
                      {release.seeders != null ? <span>{release.seeders} seeders</span> : null}
                      {release.ageHours != null ? <span>{Math.round(release.ageHours)}h old</span> : null}
                    </div>
                    {release.rejected && release.rejections.length ? (
                      <small>{release.rejections.join(" · ")}</small>
                    ) : null}
                  </div>
                  <button
                    type="button"
                    className="arr-manager__grab"
                    disabled={Boolean(grabbing)}
                    onClick={() => void grab(release)}
                  >
                    {grabbing === release.guid ? "Grabbing…" : release.rejected ? "Grab anyway" : "Grab"}
                  </button>
                </article>
              ))}
            </div>
          </main>
        </div>
      </section>
    </div>,
    document.body,
  );
}
