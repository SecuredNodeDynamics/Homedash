"use client";

import { useCallback, useEffect, useMemo, useState, type CSSProperties, useLayoutEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";
import "@/styles/widgets/arr.widgets.css";
import { ArrMediaManager } from "./ArrMediaManager";
import { ArrMediaItemModal } from "./ArrMediaItemModal";

export type ArrStat = {
  label: string;
  value: number | string;
  tone?: "warn" | "active" | "ok" | "bad";
  /** When set, clicking this stat switches the cover list tab. */
  tab?: "all" | "monitored" | "episodes" | "missing" | "queued";
};

type ConnectionSource = "private" | "public" | "unknown";

const CONNECTION_SOURCE_LABEL: Record<ConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

function ConnectionCorner({ source }: { source: ConnectionSource }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const mark = (
    <div
      className={`arr-corner-source arr-corner-source--${source}`}
      title={CONNECTION_SOURCE_LABEL[source]}
      aria-label={CONNECTION_SOURCE_LABEL[source]}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}


export type ArrQueueCard = {
  id: string;
  title: string;
  meta?: string;
  state?: string;
  progress?: number | null;
  poster?: string;
  href?: string;
  mediaId?: number;
  queueId?: number;
  monitored?: boolean;
};

type MediaTab = "all" | "monitored" | "episodes" | "missing" | "queued";
type DetailTab = Exclude<MediaTab, "missing">;

type Props = {
  apiId: string;
  fallbackId: string;
  initialTab?: MediaTab;
  accentClass?: string;
  pollMs?: number;
  mapData: (data: Record<string, unknown>) => {
    href: string;
    connectionSource?: ConnectionSource;
    stats: ArrStat[];
    summary?: string[];
    queueItems?: ArrQueueCard[];
    missingItems?: ArrQueueCard[];
    libraryItems?: ArrQueueCard[];
    monitoredItems?: ArrQueueCard[];
    episodeItems?: ArrQueueCard[];
  };
};

type HiddenEntry = { id: string; title: string; at: number };

const hiddenStorageKey = (apiId: string, instanceId: string) => `hd:${apiId}:${instanceId}:hidden-missing`;

function readLocalHidden(key: string): HiddenEntry[] {
  try {
    const parsed = JSON.parse(window.localStorage.getItem(key) || "[]") as unknown;
    return Array.isArray(parsed) ? (parsed as HiddenEntry[]).filter((e) => e && typeof e.id === "string") : [];
  } catch {
    return [];
  }
}

function writeLocalHidden(key: string, list: HiddenEntry[]) {
  try {
    window.localStorage.setItem(key, JSON.stringify(list));
  } catch {
    /* storage unavailable */
  }
}

export default function ArrOverviewWidget({
  apiId,
  fallbackId,
  initialTab = "missing",
  accentClass = "",
  pollMs = 120_000,
  mapData,
}: Props) {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || fallbackId;
  const [payload, setPayload] = useState<Record<string, unknown> | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [mediaTab, setMediaTab] = useState<MediaTab>(initialTab);
  const [managerOpen, setManagerOpen] = useState(false);
  const [managerInitialQuery, setManagerInitialQuery] = useState("");
  const [selectedMedia, setSelectedMedia] = useState<{
    item: ArrQueueCard;
    tab: DetailTab;
  } | null>(null);

  const [hiddenList, setHiddenList] = useState<HiddenEntry[]>([]);
  const [showHidden, setShowHidden] = useState(false);
  const hiddenKey = hiddenStorageKey(apiId, instanceId);
  const hiddenIds = useMemo(() => new Set(hiddenList.map((e) => e.id)), [hiddenList]);

  // Hidden list lives on the server (persistent, shared across devices);
  // localStorage is a mirror/fallback if the server route is unavailable.
  useEffect(() => {
    if (apiId !== "radarr" && apiId !== "sonarr") return;
    let cancelled = false;
    setHiddenList(readLocalHidden(hiddenKey));
    (async () => {
      try {
        const res = await fetch(`/api/widgets/${encodeURIComponent(apiId)}/hidden?instance=${encodeURIComponent(instanceId)}`);
        if (!res.ok) return;
        const json = (await res.json()) as { hidden?: HiddenEntry[] };
        if (cancelled || !Array.isArray(json.hidden)) return;
        setHiddenList(json.hidden);
        writeLocalHidden(hiddenKey, json.hidden);
      } catch {
        /* keep local fallback */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [apiId, instanceId, hiddenKey]);

  const setItemHidden = useCallback(
    async (item: ArrQueueCard, hidden: boolean) => {
      const next = [
        ...hiddenList.filter((e) => e.id !== item.id),
        ...(hidden ? [{ id: item.id, title: item.title, at: Date.now() }] : []),
      ];
      setHiddenList(next);
      writeLocalHidden(hiddenKey, next);
      try {
        const res = await fetch(`/api/widgets/${encodeURIComponent(apiId)}/hidden?instance=${encodeURIComponent(instanceId)}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: item.id, title: item.title, hidden }),
        });
        if (res.ok) {
          const json = (await res.json()) as { hidden?: HiddenEntry[] };
          if (Array.isArray(json.hidden)) {
            setHiddenList(json.hidden);
            writeLocalHidden(hiddenKey, json.hidden);
          }
        }
      } catch {
        /* local copy already saved */
      }
    },
    [apiId, instanceId, hiddenKey, hiddenList],
  );

  const load = useCallback(async () => {
    try {
      const response = await fetch(
        `/api/widgets/${encodeURIComponent(apiId)}/status?instance=${encodeURIComponent(instanceId)}`,
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || `Failed to load ${apiId}`);
      setPayload(json);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unavailable");
    } finally {
      setLoading(false);
    }
  }, [apiId, instanceId]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: pollMs });

  const view = payload ? mapData(payload) : null;
  const openFallbackUrl = payload ? String(payload.openFallbackUrl || "") : "";
  const openHref = useOpenHref(view?.href, openFallbackUrl);
  const connectionSource: ConnectionSource = view?.connectionSource || "unknown";
  const allMissingItems = view?.missingItems || [];
  const hiddenMissingCount = allMissingItems.filter((item) => hiddenIds.has(item.id)).length;
  const missingItems = showHidden
    ? allMissingItems
    : allMissingItems.filter((item) => !hiddenIds.has(item.id));
  const canHide = apiId === "radarr" || apiId === "sonarr";
  const queueItems = view?.queueItems || [];
  const libraryItems = view?.libraryItems || [];
  const monitoredItems = view?.monitoredItems || [];
  const episodeItems = view?.episodeItems || [];
  const hasMediaTabs = Boolean(view?.stats.some((stat) => stat.tab));
  const activeItems =
    mediaTab === "all"
      ? libraryItems
      : mediaTab === "monitored"
        ? monitoredItems
        : mediaTab === "episodes"
          ? episodeItems
          : mediaTab === "queued"
            ? queueItems
            : missingItems;
  const listLabel =
    mediaTab === "all"
      ? apiId === "radarr"
        ? "Movies"
        : "Series"
      : mediaTab === "monitored"
        ? "Monitored"
        : mediaTab === "episodes"
          ? "Episodes by series"
          : mediaTab === "queued"
            ? "Active downloads"
            : "Missing";

  if (loading && !view) {
    return (
      <div className={`hd-widget-body arr-body ${accentClass}`.trim()} ref={rootRef}>
        <div className="arr-toolbar">
          <div className="arr-toolbar-left">
            <span className="arr-status arr-status--idle">Connecting</span>
          </div>
        </div>
        <div className="arr-skeleton-row" />
        <div className="arr-skeleton-row" />
      </div>
    );
  }

  if (!view) {
    return (
      <div className={`hd-widget-body arr-body ${accentClass}`.trim()} ref={rootRef}>
        <div className="arr-toolbar">
          <div className="arr-toolbar-left">
            <span className="arr-status arr-status--warn">Offline</span>
          </div>
          <div className="arr-toolbar-right">
            <button className="arr-tool-btn" type="button" onClick={load}>
              Retry
            </button>
          </div>
        </div>
        <div className="arr-error">⚠ {error}</div>
      </div>
    );
  }

  return (
    <div className={`hd-widget-body arr-body ${accentClass}`.trim()} ref={rootRef}>
      <div className="arr-toolbar">
        <div className="arr-toolbar-left">
          <span className={`arr-status ${error ? "arr-status--warn" : "arr-status--active"}`}>
            {error ? "Degraded" : "Online"}
          </span>
        </div>
        <div className="arr-toolbar-right">
          {apiId === "radarr" || apiId === "sonarr" ? (
            <button
              className="arr-tool-btn"
              type="button"
              onClick={() => {
                setManagerInitialQuery("");
                setManagerOpen(true);
              }}
            >
              Find media
            </button>
          ) : null}
          {openHref ? (
            <a className="arr-tool-btn arr-tool-btn--open" href={openHref} target="_blank" rel="noopener noreferrer">
              Open
            </a>
          ) : null}
        </div>
      </div>

      {error ? <div className="arr-inline-error">{error}</div> : null}

      <div className="arr-stat-grid">
        {view.stats.map((rawStat) => {
          const stat =
            rawStat.tab === "missing" && canHide && typeof rawStat.value === "number"
              ? { ...rawStat, value: Math.max(0, rawStat.value - hiddenMissingCount) }
              : rawStat;
          const isTab = Boolean(stat.tab);
          const isActive = isTab && mediaTab === stat.tab;
          const className = [
            "arr-stat",
            stat.tone ? `arr-stat--${stat.tone}` : "",
            isTab ? "arr-stat--tab" : "",
            isActive ? "arr-stat--tab-active" : "",
          ]
            .filter(Boolean)
            .join(" ");

          if (isTab && stat.tab) {
            return (
              <button
                className={className}
                type="button"
                key={stat.label}
                aria-pressed={isActive}
                onClick={() => setMediaTab(stat.tab!)}
              >
                <div className="arr-stat-value">
                  {typeof stat.value === "number" ? stat.value.toLocaleString() : stat.value}
                </div>
                <div className="arr-stat-label">{stat.label}</div>
              </button>
            );
          }

          return (
            <div className={className} key={stat.label}>
              <div className="arr-stat-value">
                {typeof stat.value === "number" ? stat.value.toLocaleString() : stat.value}
              </div>
              <div className="arr-stat-label">{stat.label}</div>
            </div>
          );
        })}
      </div>

      {hasMediaTabs ? (
        <div className="arr-queue">
          <div className="arr-queue__label">
            {listLabel}
            <span className="arr-queue__count">{activeItems.length}</span>
            {mediaTab === "missing" && canHide && hiddenMissingCount > 0 ? (
              <button
                type="button"
                className={`arr-hide-toggle${showHidden ? " arr-hide-toggle--on" : ""}`}
                aria-pressed={showHidden}
                onClick={() => setShowHidden((v) => !v)}
              >
                {showHidden ? "Hide hidden" : `Show hidden (${hiddenMissingCount})`}
              </button>
            ) : null}
          </div>
          {activeItems.length ? (
            <div className="arr-queue__grid" key={mediaTab}>
              {activeItems.map((item, index) => {
                const isHidden = mediaTab === "missing" && hiddenIds.has(item.id);
                const card = (
                  <>
                    <div className="arr-queue__art">
                      {mediaTab === "missing" && canHide ? (
                        <button
                          type="button"
                          className="arr-hide-btn"
                          title={isHidden ? "Show in Missing again" : "Hide from Missing"}
                          aria-label={isHidden ? `Show ${item.title} again` : `Hide ${item.title}`}
                          onClick={(event) => {
                            event.preventDefault();
                            event.stopPropagation();
                            void setItemHidden(item, !isHidden);
                          }}
                        >
                          {isHidden ? "Show" : "Hide"}
                        </button>
                      ) : null}
                      {item.poster ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={item.poster} alt="" loading="lazy" decoding="async" />
                      ) : (
                        <div className="arr-queue__placeholder">{item.title.charAt(0)}</div>
                      )}
                      {item.progress != null ? (
                        <div className="arr-queue__progress" aria-hidden="true">
                          <span style={{ width: `${item.progress}%` }} />
                        </div>
                      ) : null}
                      {item.state ? <span className="arr-queue__state">{item.state}</span> : null}
                    </div>
                    <div className="arr-queue__title">{item.title}</div>
                    {item.meta ? <div className="arr-queue__meta">{item.meta}</div> : null}
                  </>
                );

                const className = `arr-queue__card${isHidden ? " arr-queue__card--hidden" : ""}`;
                const style = { ["--arr-queue-i" as string]: index } as CSSProperties;

                return item.href ? (
                  <a
                    key={item.id}
                    className={className}
                    href={item.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    title={item.title}
                    style={style}
                    onClick={(event) => {
                      if (apiId === "radarr" || apiId === "sonarr") {
                        event.preventDefault();
                        if (mediaTab !== "missing") {
                          setSelectedMedia({ item, tab: mediaTab });
                          return;
                        }
                        setManagerInitialQuery(item.title);
                        setManagerOpen(true);
                      }
                    }}
                  >
                    {card}
                  </a>
                ) : (
                  <div key={item.id} className={className} title={item.title} style={style}>
                    {card}
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="arr-queue__empty">
              {mediaTab === "queued"
                ? "Nothing in queue"
                : mediaTab === "missing"
                  ? hiddenMissingCount > 0
                    ? `All missing media is hidden (${hiddenMissingCount})`
                    : "No missing media"
                  : "No media found"}
            </div>
          )}
        </div>
      ) : queueItems.length ? (
        <div className="arr-queue">
          <div className="arr-queue__label">
            Active downloads
            <span className="arr-queue__count">{queueItems.length}</span>
          </div>
          <div className="arr-queue__grid">
            {queueItems.map((item, index) => (
              <a
                key={item.id}
                className="arr-queue__card"
                href={item.href || "#"}
                target="_blank"
                rel="noopener noreferrer"
                title={item.title}
                style={{ ["--arr-queue-i" as string]: index } as CSSProperties}
              >
                <div className="arr-queue__art">
                  {item.poster ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={item.poster} alt="" loading="lazy" decoding="async" />
                  ) : (
                    <div className="arr-queue__placeholder">{item.title.charAt(0)}</div>
                  )}
                  {item.progress != null ? (
                    <div className="arr-queue__progress" aria-hidden="true">
                      <span style={{ width: `${item.progress}%` }} />
                    </div>
                  ) : null}
                  {item.state ? <span className="arr-queue__state">{item.state}</span> : null}
                </div>
                <div className="arr-queue__title">{item.title}</div>
                {item.meta ? <div className="arr-queue__meta">{item.meta}</div> : null}
              </a>
            ))}
          </div>
        </div>
      ) : null}

      {view.summary?.length ? (
        <div className="arr-summary">
          {view.summary.map((line) => (
            <span key={line}>{line}</span>
          ))}
        </div>
      ) : null}
      {managerOpen && (apiId === "radarr" || apiId === "sonarr") ? (
        <ArrMediaManager
          kind={apiId}
          instanceId={instanceId}
          initialQuery={managerInitialQuery}
          onClose={() => setManagerOpen(false)}
        />
      ) : null}
      {selectedMedia && (apiId === "radarr" || apiId === "sonarr") ? (
        <ArrMediaItemModal
          kind={apiId}
          instanceId={instanceId}
          item={selectedMedia.item}
          tab={selectedMedia.tab}
          onClose={() => setSelectedMedia(null)}
          onChanged={() => void load()}
        />
      ) : null}
      <ConnectionCorner source={connectionSource} />
    </div>
  );
}
