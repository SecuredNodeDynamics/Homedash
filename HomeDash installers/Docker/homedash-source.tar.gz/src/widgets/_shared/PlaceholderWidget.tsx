"use client";

import { useEffect, useState } from "react";
import type { WidgetManifest } from "@/lib/types";
import { useWidgetInstance } from "./instance-context";

export function PlaceholderWidget({ manifest }: { manifest: WidgetManifest }) {
  const instance = useWidgetInstance();
  const configId = instance?.instanceId || manifest.id;
  const [configured, setConfigured] = useState<boolean | null>(null);

  useEffect(() => {
    let alive = true;
    fetch(`/api/widgets/${encodeURIComponent(configId)}/config`)
      .then((r) => r.json())
      .then((cfg: Record<string, string>) => {
        if (!alive) return;
        const hasAny = Object.values(cfg || {}).some((v) => Boolean(String(v || "").trim()));
        const required = (manifest.configFields || []).filter((f) => f.required);
        const ok = required.length ? required.every((f) => Boolean(cfg[f.key]?.trim())) : hasAny;
        setConfigured(ok || hasAny);
      })
      .catch(() => alive && setConfigured(false));
    return () => {
      alive = false;
    };
  }, [manifest, configId]);

  return (
    <div className="hd-widget-body">
      <div className="hd-widget-placeholder">
        <strong>{instance?.label || manifest.name}</strong>
        <div>{manifest.description}</div>
        <div
          className={`hd-widget-status ${
            configured ? "hd-widget-status--ready" : "hd-widget-status--needs-config"
          }`}
        >
          {configured === null
            ? "Checking config…"
            : configured
              ? "Credentials loaded · full UI port next"
              : "Needs configuration in Settings"}
        </div>
      </div>
    </div>
  );
}
