"use client";

import type { WidgetManifest, WidgetModule } from "@/lib/types";
import { PlaceholderWidget } from "./PlaceholderWidget";

export function createPlaceholderWidget(manifest: WidgetManifest): WidgetModule {
  function Component() {
    return <PlaceholderWidget manifest={manifest} />;
  }
  Component.displayName = `${manifest.id}Placeholder`;
  return {
    manifest,
    load: async () => ({ default: Component }),
  };
}
