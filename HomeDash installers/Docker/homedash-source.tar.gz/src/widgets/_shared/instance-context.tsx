"use client";

import { createContext, useContext } from "react";

export type WidgetInstanceContextValue = {
  instanceId: string;
  widgetId: string;
  label: string;
  iconUrl?: string | null;
  /** Card chrome — widgets with their own header (e.g. Proxmox) should honor these. */
  showIcon?: boolean;
  showTitle?: boolean;
};

const WidgetInstanceContext = createContext<WidgetInstanceContextValue | null>(null);

export function WidgetInstanceProvider({
  value,
  children,
}: {
  value: WidgetInstanceContextValue;
  children: React.ReactNode;
}) {
  return <WidgetInstanceContext.Provider value={value}>{children}</WidgetInstanceContext.Provider>;
}

export function useWidgetInstance() {
  return useContext(WidgetInstanceContext);
}
