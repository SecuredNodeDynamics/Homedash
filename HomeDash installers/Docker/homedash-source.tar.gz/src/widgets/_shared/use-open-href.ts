"use client";

import { useMemo, useSyncExternalStore } from "react";
import { resolveOpenHref } from "@/lib/open-href";

function subscribe() {
  return () => {};
}

function getHostname() {
  return typeof window !== "undefined" ? window.location.hostname : "";
}

function getServerHostname() {
  return "";
}

/** Pick LAN vs Cloudflare Open URL from the current Homedash host. */
export function useOpenHref(primary?: string | null, fallback?: string | null) {
  const hostname = useSyncExternalStore(subscribe, getHostname, getServerHostname);
  return useMemo(
    () => resolveOpenHref(primary, fallback, hostname),
    [primary, fallback, hostname],
  );
}
