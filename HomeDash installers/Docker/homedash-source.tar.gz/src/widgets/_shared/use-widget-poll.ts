"use client";

import { useCallback, useEffect, useRef, useState } from "react";

type QueuedLoad = {
  run: () => Promise<void>;
  cancelled: () => boolean;
};

const loadQueue: QueuedLoad[] = [];
let activeLoads = 0;

function concurrencyLimit() {
  if (typeof window === "undefined") return 4;
  const mobile =
    window.matchMedia?.("(max-width: 900px)").matches ||
    /Android|iPhone|iPad|Mobile/i.test(window.navigator.userAgent);
  return mobile ? 4 : 8;
}

function drainLoadQueue() {
  const limit = concurrencyLimit();
  while (activeLoads < limit && loadQueue.length) {
    const next = loadQueue.shift();
    if (!next || next.cancelled()) continue;
    activeLoads += 1;
    void next.run().finally(() => {
      activeLoads = Math.max(0, activeLoads - 1);
      drainLoadQueue();
    });
  }
}

function enqueueLoad(item: QueuedLoad) {
  loadQueue.push(item);
  drainLoadQueue();
}

type Options = {
  /** Poll interval in ms. */
  intervalMs: number;
  /** When false, no initial load and no polling. Default true. */
  enabled?: boolean;
  /** IntersectionObserver rootMargin. Default "200px". */
  rootMargin?: string;
  /**
   * When true (default), skip polls while the observed root is outside the
   * viewport. Pass false to only gate on document.hidden.
   */
  requireInView?: boolean;
};

/**
 * Call `load` when allowed, on an interval while the page is visible and the
 * widget is near the viewport, and once when returning from hidden / offscreen.
 *
 * Attach `rootRef` to the widget's root element for viewport gating.
 */
export function useWidgetPoll(load: () => void | Promise<void>, options: Options) {
  const {
    intervalMs,
    enabled = true,
    rootMargin = "200px",
    requireInView = true,
  } = options;

  const loadRef = useRef(load);
  loadRef.current = load;

  const [rootEl, setRootEl] = useState<Element | null>(null);
  const rootRef = useCallback((node: Element | null) => {
    setRootEl(node);
  }, []);

  const inViewRef = useRef(!requireInView);
  const enabledRef = useRef(enabled);
  enabledRef.current = enabled;

  useEffect(() => {
    if (!enabled) return;
    if (requireInView && !rootEl) return;

    let cancelled = false;
    let pollTimer: number | undefined;
    const recoveryTimers = new Set<number>();
    let observer: IntersectionObserver | undefined;
    let inFlight = false;
    let rerunRequested = false;
    let lastStartedAt = 0;

    const canRun = () =>
      enabledRef.current &&
      !cancelled &&
      typeof document !== "undefined" &&
      !document.hidden &&
      (!requireInView || inViewRef.current);

    const schedulePoll = () => {
      if (pollTimer != null) window.clearTimeout(pollTimer);
      if (cancelled || !enabledRef.current) return;
      pollTimer = window.setTimeout(() => {
        run();
      }, intervalMs);
    };

    const run = (allowQuickRepeat = false) => {
      if (!canRun()) return;
      const now = Date.now();
      if (!allowQuickRepeat && now - lastStartedAt < 750) return;
      if (inFlight) {
        rerunRequested = true;
        return;
      }
      inFlight = true;
      enqueueLoad({
        cancelled: () => cancelled || !enabledRef.current,
        run: async () => {
          if (!canRun()) {
            inFlight = false;
            return;
          }
          lastStartedAt = Date.now();
          try {
            await loadRef.current();
          } catch {
            // Widgets own their visible error state. Recovery pulses below retry
            // transient failures without replacing successfully cached data.
          } finally {
            inFlight = false;
            schedulePoll();
            if (rerunRequested) {
              rerunRequested = false;
              run(true);
            }
          }
        },
      });
    };

    if (requireInView && typeof IntersectionObserver !== "undefined" && rootEl) {
      inViewRef.current = false;
      observer = new IntersectionObserver(
        (entries) => {
          const entry = entries[0];
          const next = Boolean(entry?.isIntersecting);
          const was = inViewRef.current;
          inViewRef.current = next;
          if (next && !was) {
            run();
            const retry = window.setTimeout(() => {
              recoveryTimers.delete(retry);
              run(true);
            }, 2500);
            recoveryTimers.add(retry);
          }
        },
        { root: null, rootMargin, threshold: 0 },
      );
      observer.observe(rootEl);
    } else {
      inViewRef.current = true;
      run();
    }

    // Some Android WebViews delay or miss the first IntersectionObserver
    // callback. Check the rendered position directly as a startup fallback.
    if (requireInView && rootEl) {
      const startupCheck = window.setTimeout(() => {
        recoveryTimers.delete(startupCheck);
        const rect = rootEl.getBoundingClientRect();
        const margin = 240;
        if (rect.bottom >= -margin && rect.top <= window.innerHeight + margin) {
          inViewRef.current = true;
          run();
        }
      }, 120);
      recoveryTimers.add(startupCheck);
    }

    schedulePoll();

    const recover = () => {
      if (document.hidden || !navigator.onLine) return;
      run();
      const followup = window.setTimeout(() => {
        recoveryTimers.delete(followup);
        run(true);
      }, 1800);
      recoveryTimers.add(followup);
    };
    const onVisibility = () => {
      if (!document.hidden) recover();
    };
    const onPageShow = () => recover();
    const onOnline = () => recover();
    const onFocus = () => recover();
    document.addEventListener("visibilitychange", onVisibility);
    window.addEventListener("pageshow", onPageShow);
    window.addEventListener("online", onOnline);
    window.addEventListener("focus", onFocus);

    return () => {
      cancelled = true;
      if (pollTimer != null) window.clearTimeout(pollTimer);
      recoveryTimers.forEach((timer) => window.clearTimeout(timer));
      recoveryTimers.clear();
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("pageshow", onPageShow);
      window.removeEventListener("online", onOnline);
      window.removeEventListener("focus", onFocus);
      observer?.disconnect();
    };
  }, [enabled, intervalMs, rootMargin, requireInView, rootEl]);

  return { rootRef };
}
