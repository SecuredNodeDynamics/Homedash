"use client";
import "@/styles/widgets/adguard.widget.css";


import { useCallback, useEffect, useState, useLayoutEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";
import { useAuthPermission } from "@/lib/use-auth-permission";

type ConnectionSource = "private" | "public" | "unknown";

type TopEntry = { name: string; count: number };

type Status = {
  href: string;
  openFallbackUrl?: string;
  protectionEnabled: boolean;
  safeBrowsingEnabled: boolean;
  parentalEnabled: boolean;
  queries: number;
  blocked: number;
  blockRate: number;
  averageRate: number;
  connectionSource?: ConnectionSource;
  topBlocked?: TopEntry[];
  topClients?: TopEntry[];
};

function PauseIcon() {
  return (
    <svg className="agh-icon-svg" viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <rect x="4" y="3" width="3" height="10" rx="1" fill="currentColor" />
      <rect x="9" y="3" width="3" height="10" rx="1" fill="currentColor" />
    </svg>
  );
}

function PlayIcon() {
  return (
    <svg className="agh-icon-svg" viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <path d="M4.5 2.8c0-.9.98-1.46 1.76-1.01l7 4.2c.75.45.75 1.53 0 1.98l-7 4.2c-.78.45-1.76-.1-1.76-1V2.8Z" fill="currentColor" />
    </svg>
  );
}

function ClockIcon() {
  return (
    <svg className="agh-icon-svg" viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <circle cx="8" cy="8" r="6.25" stroke="currentColor" strokeWidth="1.3" />
      <path d="M8 4.6V8l2.6 1.5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function ChevronIcon({ open }: { open: boolean }) {
  return (
    <svg
      className={`agh-icon-svg agh-chevron${open ? " is-open" : ""}`}
      viewBox="0 0 16 16"
      fill="none"
      aria-hidden="true"
    >
      <path d="M4 6l4 4 4-4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

const CONNECTION_SOURCE_LABEL: Record<ConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

function ConnectionCorner({ source }: { source: ConnectionSource }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const mark = (
    <div
      className={`agh-corner-source agh-corner-source--${source}`}
      title={CONNECTION_SOURCE_LABEL[source]}
      aria-label={CONNECTION_SOURCE_LABEL[source]}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}


type Toggle = "filtering" | "safebrowsing" | "parental";

const PAUSE_DURATIONS = [
  { label: "30s", ms: 30_000 },
  { label: "1m", ms: 60_000 },
  { label: "5m", ms: 5 * 60_000 },
  { label: "15m", ms: 15 * 60_000 },
  { label: "30m", ms: 30 * 60_000 },
  { label: "1h", ms: 60 * 60_000 },
  { label: "Until on", ms: 0 },
];

function formatNumber(value: number) {
  return Number(value || 0).toLocaleString();
}

function formatRemaining(ms: number) {
  const seconds = Math.max(0, Math.ceil(ms / 1000));
  return `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
}

export default function AdguardControlWidget() {
  const canControlServices = useAuthPermission("widgets.control");
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "adguard-control";
  const [data, setData] = useState<Status | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState("");
  const [pauseIndex, setPauseIndex] = useState(2);
  const [pauseEndsAt, setPauseEndsAt] = useState(0);
  const [now, setNow] = useState(Date.now());
  const [pauseMenuOpen, setPauseMenuOpen] = useState(false);
  const pauseMenuRef = useRef<HTMLDivElement>(null);
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);

  useEffect(() => {
    if (!pauseMenuOpen) return;
    function onPointerDown(event: PointerEvent) {
      if (!pauseMenuRef.current?.contains(event.target as Node)) setPauseMenuOpen(false);
    }
    function onKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") setPauseMenuOpen(false);
    }
    document.addEventListener("pointerdown", onPointerDown);
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("pointerdown", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [pauseMenuOpen]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch(
        `/api/widgets/adguard-control/status?instance=${encodeURIComponent(instanceId)}`,
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load AdGuard");
      setData(json);
      setError("");
      if (json.protectionEnabled) setPauseEndsAt(0);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Failed to load AdGuard");
      setData(null);
    } finally {
      setLoading(false);
    }
  }, [instanceId]);

  const paused = Boolean(data && !data.protectionEnabled);
  const intervalMs = paused ? 15_000 : 120_000;
  const { rootRef } = useWidgetPoll(load, { intervalMs });

  useEffect(() => {
    if (!pauseEndsAt) return;
    const interval = window.setInterval(() => {
      const time = Date.now();
      setNow(time);
      if (time >= pauseEndsAt) {
        setPauseEndsAt(0);
        load();
      }
    }, 1000);
    return () => window.clearInterval(interval);
  }, [load, pauseEndsAt]);

  async function action(toggle: Toggle, enabled: boolean, duration = 0) {
    setBusy(toggle);
    setError("");
    try {
      const response = await fetch("/api/widgets/adguard-control/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, toggle, enabled, duration }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to update AdGuard");
      setPauseEndsAt(!enabled && toggle === "filtering" && duration > 0 ? Date.now() + duration : 0);
      await load();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Failed to update AdGuard");
    } finally {
      setBusy("");
    }
  }

  if (loading && !data) {
    return (
      <div className="hd-widget-body agh-body" ref={rootRef}>
        <div className="agh-skeleton-card" />
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="hd-widget-body agh-body" ref={rootRef}>
        <div className="agh-toolbar">
          <div className="agh-toolbar-left">
            <span className="agh-status agh-status--off">Offline</span>
          </div>
          <div className="agh-toolbar-right">
            <button className="agh-tool-btn" type="button" onClick={load}>
              Retry
            </button>
          </div>
        </div>
        <div className="agh-inst-error">{error}</div>
      </div>
    );
  }

  if (!data) return <div className="hd-widget-body agh-body" ref={rootRef} />;

  const remaining = pauseEndsAt - now;
  const timedPause = paused && remaining > 0;
  const statusLabel = error ? "Degraded" : paused ? "Paused" : "Protected";
  const statusClass = error ? "agh-status--warn" : paused ? "agh-status--paused" : "agh-status--on";
  const protectionLine = timedPause
    ? `Paused · resumes in ${formatRemaining(remaining)}`
    : paused
      ? "Protection disabled"
      : "Protection active";

  const connectionSource: ConnectionSource = data.connectionSource || "unknown";

  return (
    <div className={`hd-widget-body agh-body${paused ? " is-paused" : ""}${canControlServices ? "" : " is-readonly"}`} ref={rootRef}>
      <ConnectionCorner source={connectionSource} />
      <div className="agh-sticky-head">
        <div className="agh-toolbar">
          <div className="agh-toolbar-left">
            <span className={`agh-status ${statusClass}`}>
              {timedPause ? `Paused · ${formatRemaining(remaining)}` : statusLabel}
            </span>
          </div>
          <div className="agh-toolbar-right">
            {openHref ? (
              <a className="agh-tool-btn agh-tool-btn--open" href={openHref} target="_blank" rel="noopener noreferrer">
                Open
              </a>
            ) : null}
          </div>
        </div>

        <div className="agh-stats-row">
          <div className="agh-stat">
            <div className="agh-stat-val">{formatNumber(data.queries)}</div>
            <div className="agh-stat-lbl">Queries</div>
          </div>
          <div className="agh-stat">
            <div className="agh-stat-val agh-stat-val--blocked">{formatNumber(data.blocked)}</div>
            <div className="agh-stat-lbl">Blocked</div>
          </div>
          <div className="agh-stat">
            <div className="agh-stat-val agh-stat-val--rate">{data.blockRate.toFixed(1)}%</div>
            <div className="agh-stat-lbl">Block rate</div>
          </div>
          <div className="agh-stat">
            <div className="agh-stat-val agh-stat-val--avg">{data.averageRate.toFixed(1)}/s</div>
            <div className="agh-stat-lbl">Avg rate</div>
          </div>
        </div>
      </div>

      <div className={`agh-protection${paused ? " is-paused" : ""}`}>
        <div className="agh-protection__head">
          <div className="agh-protection__title">DNS protection</div>
          <div className={`agh-protection__state${paused ? " is-paused" : ""}`}>{protectionLine}</div>
        </div>

        <div className="agh-protection__controls">
          {paused ? (
            <button
              className="agh-protection__action agh-protection__action--resume"
              type="button"
              disabled={Boolean(busy)}
              onClick={() => action("filtering", true)}
            >
              <PlayIcon />
              <span>{busy === "filtering" ? "Enabling…" : "Re-enable now"}</span>
            </button>
          ) : (
            <>
              <div className="agh-pause-dropdown" ref={pauseMenuRef}>
                <button
                  type="button"
                  className="agh-pause-dropdown__trigger"
                  disabled={Boolean(busy)}
                  aria-haspopup="listbox"
                  aria-expanded={pauseMenuOpen}
                  onClick={() => setPauseMenuOpen((open) => !open)}
                >
                  <ClockIcon />
                  <span>{PAUSE_DURATIONS[pauseIndex]?.label}</span>
                  <ChevronIcon open={pauseMenuOpen} />
                </button>
                {pauseMenuOpen ? (
                  <div className="agh-pause-dropdown__menu" role="listbox">
                    {PAUSE_DURATIONS.map((duration, index) => (
                      <button
                        key={duration.label}
                        type="button"
                        role="option"
                        aria-selected={pauseIndex === index}
                        className={`agh-pause-dropdown__option${pauseIndex === index ? " is-active" : ""}`}
                        onClick={() => {
                          setPauseIndex(index);
                          setPauseMenuOpen(false);
                        }}
                      >
                        {duration.label}
                      </button>
                    ))}
                  </div>
                ) : null}
              </div>
              <button
                className="agh-protection__action agh-protection__action--pause"
                type="button"
                disabled={Boolean(busy)}
                onClick={() => action("filtering", false, PAUSE_DURATIONS[pauseIndex]?.ms || 0)}
              >
                <PauseIcon />
                <span>{busy === "filtering" ? "Pausing…" : "Pause"}</span>
              </button>
            </>
          )}
        </div>
      </div>

      <div className="agh-secondary">
        {(
          [
            ["safebrowsing", "Safe Browsing", data.safeBrowsingEnabled],
            ["parental", "Parental Control", data.parentalEnabled],
          ] as const
        ).map(([id, label, enabled]) => (
          <div className={`agh-secondary__card${enabled ? " is-on" : ""}`} key={id}>
            <span className="agh-secondary__label">{label}</span>
            <button
              className={`agh-toggle-btn${enabled ? " agh-toggle-btn--on" : ""}`}
              type="button"
              aria-pressed={enabled}
              aria-label={`${label}: ${enabled ? "enabled" : "disabled"}`}
              title={enabled ? "Enabled — click to disable" : "Disabled — click to enable"}
              disabled={Boolean(busy)}
              onClick={() => action(id, !enabled)}
            >
              <span className="agh-toggle-knob" />
            </button>
          </div>
        ))}
      </div>

      <div className="agh-top-grid">
        {(
          [
            ["Top Blocked", data.topBlocked],
            ["Top Clients", data.topClients],
          ] as const
        ).map(([title, entries]) => (
          <div className="agh-top-card" key={title}>
            <div className="agh-top-card__title">{title}</div>
            {entries && entries.length ? (
              <ul className="agh-top-list">
                {entries.map((entry) => (
                  <li className="agh-top-list__row" key={entry.name}>
                    <span className="agh-top-list__name" title={entry.name}>
                      {entry.name}
                    </span>
                    <span className="agh-top-list__count">{formatNumber(entry.count)}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="agh-top-empty">No data yet</div>
            )}
          </div>
        ))}
      </div>

      {error ? <div className="agh-inst-error">{error}</div> : null}
    </div>
  );
}
