import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "adguard-control",
  name: "AdGuard",
  description: "DNS blocking controls",
  version: "0.1.7",
  category: "Network",
  defaultSize: { w: 4, h: 6, minW: 3, minH: 4 },
  configFields: [
    { key: "baseUrl", label: "Private - IP", type: "url", placeholder: "http://10.0.0.1" },
    { key: "fallbackUrl", label: "Fallback Public URL", type: "url" , placeholder: "https://adguard.example.com" },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url", placeholder: "http://10.0.0.1" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    { key: "username", label: "Username", type: "text" },
    { key: "password", label: "Password", type: "password" },
  ],
};
