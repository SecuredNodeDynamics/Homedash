"use client";

import "@/styles/widgets/ai-chat.widget.css";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";

type DashboardWidget = {
  instanceId: string;
  widgetId: string;
  title: string;
  tabId: string;
  tabName: string;
};

type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
  provider?: string;
  model?: string;
  citations?: string[];
  handoffFrom?: string;
  attachments?: string[];
};
type PendingAttachment = {
  id: string;
  name: string;
  type: string;
  data: string;
  size: number;
};

const PROVIDERS: Record<string, { label: string; short: string; icon: string; color: string }> = {
  openai: {
    label: "ChatGPT",
    short: "OpenAI",
    icon: "/icons/ai-openai.svg",
    color: "#a7f3d0",
  },
  gemini: {
    label: "Gemini",
    short: "Google",
    icon: "/icons/ai-gemini.svg",
    color: "#c4b5fd",
  },
  claude: {
    label: "Claude",
    short: "Anthropic",
    icon: "/icons/ai-claude.svg",
    color: "#fdba74",
  },
  perplexity: {
    label: "Perplexity",
    short: "Sonar",
    icon: "/icons/ai-perplexity.svg",
    color: "#67e8f9",
  },
};

const STARTERS = [
  "Summarize today’s priorities",
  "Help me think through a decision",
  "Draft a concise email",
  "Explain a complex topic",
];
function sourceHost(url: string) {
  try { return new URL(url).hostname; } catch { return "Source"; }
}
function safeStatusValue(value: unknown, depth = 0): unknown {
  if (depth > 4) return undefined;
  if (Array.isArray(value)) {
    return value.slice(0, 20).map((item) => safeStatusValue(item, depth + 1));
  }
  if (value && typeof value === "object") {
    const clean: Record<string, unknown> = {};
    for (const [key, item] of Object.entries(value as Record<string, unknown>)) {
      if (/(?:api.?key|token|password|secret|cookie|authorization|headers?|url|href|image|poster|thumb|logo|icon|art)/i.test(key)) {
        continue;
      }
      const next = safeStatusValue(item, depth + 1);
      if (next !== undefined) clean[key] = next;
    }
    return clean;
  }
  if (typeof value === "string") return value.slice(0, 500);
  if (typeof value === "number" || typeof value === "boolean" || value == null) return value;
  return undefined;
}
function messageId() {
  try {
    if (typeof globalThis.crypto?.randomUUID === "function") {
      return globalThis.crypto.randomUUID();
    }
  } catch {
    // Fall through for older/insecure WebViews.
  }
  return `msg-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

export default function AiChatWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "ai-chat";
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [attachments, setAttachments] = useState<PendingAttachment[]>([]);
  const [uploadOpen, setUploadOpen] = useState(false);
  const [uploadDragActive, setUploadDragActive] = useState(false);
  const [busy, setBusy] = useState(false);
  const [thinkingProviderId, setThinkingProviderId] = useState("");
  const [switching, setSwitching] = useState(false);
  const [error, setError] = useState("");
  const [providerId, setProviderId] = useState("openai");
  const [providerModel, setProviderModel] = useState("");
  const [providerLogos, setProviderLogos] = useState<Record<string, string>>({});
  const [configuredProviders, setConfiguredProviders] = useState<Record<string, boolean> | null>(null);
  const [configured, setConfigured] = useState(true);
  const [persistenceMode, setPersistenceMode] = useState<"none" | "widget" | "shared" | null>(null);
  const [dashboardWidgets, setDashboardWidgets] = useState<DashboardWidget[]>([]);
  const endRef = useRef<HTMLDivElement>(null);
  const attachmentInputRef = useRef<HTMLInputElement>(null);
  const skipStorageWriteRef = useRef(false);
  const storageKey = persistenceMode === "shared"
    ? "homedash:ai-chat:shared"
    : persistenceMode === "widget"
      ? `homedash:ai-chat:${instanceId}`
      : "";

  async function addAttachmentFiles(fileList: FileList | File[]) {
    const availableSlots = Math.max(0, 4 - attachments.length);
    const files = Array.from(fileList).slice(0, availableSlots);
    const accepted: PendingAttachment[] = [];
    for (const file of files) {
      if (file.size > 8 * 1024 * 1024) {
        setError(`${file.name} exceeds the 8 MB attachment limit`);
        continue;
      }
      const extension = file.name.split(".").pop()?.toLowerCase();
      const normalizedType =
        file.type
        || (extension === "pdf" ? "application/pdf"
          : extension === "json" ? "application/json"
            : extension === "md" ? "text/markdown"
              : extension === "csv" ? "text/csv"
                : "text/plain");
      if (!/^(image\/(?:png|jpeg|webp|gif)|application\/pdf|text\/(?:plain|markdown|csv)|application\/json)$/.test(normalizedType)) {
        setError(`${file.name} is not a supported image or document`);
        continue;
      }
      try {
        const dataUrl = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(String(reader.result || ""));
          reader.onerror = () => reject(new Error(`Could not read ${file.name}`));
          reader.readAsDataURL(file);
        });
        accepted.push({
          id: messageId(),
          name: file.name,
          type: normalizedType,
          data: dataUrl.slice(dataUrl.indexOf(",") + 1),
          size: file.size,
        });
      } catch (reason) {
        setError(reason instanceof Error ? reason.message : `Could not read ${file.name}`);
      }
    }
    if (accepted.length) {
      setAttachments((current) => [...current, ...accepted].slice(0, 4));
      setError("");
    }
  }

  useEffect(() => {
    if (!persistenceMode) return;
    if (!storageKey) {
      setMessages([]);
      return;
    }
    try {
      const saved = JSON.parse(localStorage.getItem(storageKey) || "[]");
      skipStorageWriteRef.current = true;
      if (Array.isArray(saved)) setMessages(saved.slice(-40));
    } catch {
      // Start a clean conversation if local history is malformed.
    }
  }, [persistenceMode, storageKey]);
  useEffect(() => {
    let active = true;
    void (async () => {
      const response = await fetch(`/api/widgets/ai-chat/info?instance=${encodeURIComponent(instanceId)}`);
      let data = await response.json();
      if (!active || data.error) return;
      const availability = data.configuredProviders && typeof data.configuredProviders === "object"
        ? data.configuredProviders as Record<string, boolean>
        : {};
      if (!data.configured) {
        const fallback = Object.keys(PROVIDERS).find((id) => availability[id]);
        if (fallback && fallback !== data.provider) {
          const switchResponse = await fetch("/api/widgets/ai-chat/info", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ instance: instanceId, provider: fallback }),
          });
          const switched = await switchResponse.json();
          if (switchResponse.ok) data = switched;
        }
      }
      if (!active) return;
        setProviderId(String(data.provider || "openai"));
        setProviderModel(String(data.model || ""));
        setConfigured(Boolean(data.configured));
        setPersistenceMode(
          ["none", "widget", "shared"].includes(data.conversationPersistence)
            ? data.conversationPersistence
            : "widget",
        );
        setProviderLogos(data.logos && typeof data.logos === "object" ? data.logos : {});
        setConfiguredProviders(
          data.configuredProviders && typeof data.configuredProviders === "object"
            ? data.configuredProviders
            : {},
        );
        window.dispatchEvent(new CustomEvent("homedash:ai-chat-provider", {
          detail: {
            instanceId,
            provider: String(data.provider || "openai"),
            logo: String(data.logo || ""),
          },
        }));
    })().catch(() => {
      if (active) setConfiguredProviders({});
    });
    return () => { active = false; };
  }, [instanceId]);
  useEffect(() => {
    let active = true;
    void fetch("/api/settings")
      .then((response) => response.json())
      .then((settings) => {
        if (!active) return;
        const instances = new Map(
          (Array.isArray(settings.widgetInstances) ? settings.widgetInstances : [])
            .map((item: Record<string, unknown>) => [String(item.id || ""), item]),
        );
        const widgets: DashboardWidget[] = [];
        for (const tab of Array.isArray(settings.tabs) ? settings.tabs : []) {
          for (const instanceId of Array.isArray(tab.widgetIds) ? tab.widgetIds : []) {
            const instance = instances.get(String(instanceId)) as Record<string, unknown> | undefined;
            widgets.push({
              instanceId: String(instanceId),
              widgetId: String(instance?.widgetId || instanceId),
              title: String(instance?.label || instance?.widgetId || instanceId),
              tabId: String(tab.id || ""),
              tabName: String(tab.name || tab.id || "Dashboard"),
            });
          }
        }
        setDashboardWidgets(widgets);
      })
      .catch(() => undefined);
    return () => { active = false; };
  }, []);
  useEffect(() => {
    if (!persistenceMode || !storageKey) {
      endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
      return;
    }
    if (skipStorageWriteRef.current) {
      skipStorageWriteRef.current = false;
      endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
      return;
    }
    try {
      localStorage.setItem(storageKey, JSON.stringify(messages.slice(-40)));
    } catch {
      // Chat still works when storage is unavailable or full.
    }
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, persistenceMode, storageKey]);

  async function send(seed?: string) {
    const content = (seed ?? input).trim();
    if ((!content && !attachments.length) || busy) return;
    const currentAttachments = attachments;
    try {
      const requestedAgent = content.match(
        /^\s*(?:hey\s+)?(gemini|chat\s*gpt|openai|perplexity|claude)\b/i,
      )?.[1]?.toLowerCase().replace(/\s+/g, "");
      setThinkingProviderId(
        requestedAgent === "chatgpt" ? "openai" : requestedAgent || providerId,
      );
      const prompt = content || "Please review the attached files.";
      const user: ChatMessage = {
        id: messageId(),
        role: "user",
        content: prompt,
        attachments: currentAttachments.map((file) => file.name),
      };
      const next = [...messages, user];
      setMessages(next);
      setInput("");
      setAttachments([]);
      setError("");
      const openCommand = prompt.match(
        /^\s*(?:please\s+)?(?:open(?:\s+up)?|show|find|go\s+to|take\s+me\s+to|bring\s+up)\s+(?:the\s+)?(.+?)(?:\s+for\s+me)?[.!?]*\s*$/i,
      );
      if (openCommand) {
        const requested = openCommand[1]
          .replace(/\s+widget\s*$/i, "")
          .trim()
          .toLowerCase();
        const match = dashboardWidgets
          .map((item) => ({
            item,
            score:
              item.title.toLowerCase() === requested || item.widgetId.toLowerCase() === requested
                ? 3
                : item.title.toLowerCase().includes(requested)
                    || requested.includes(item.title.toLowerCase())
                    || item.widgetId.toLowerCase().includes(requested)
                  ? 2
                  : 0,
          }))
          .sort((a, b) => b.score - a.score)[0];
        if (match?.score) {
          setMessages((current) => [...current, {
            id: messageId(),
            role: "assistant",
            content: `Opening ${match.item.title} on the ${match.item.tabName} dashboard.`,
            provider: providerId,
            model: providerModel,
          }]);
          window.setTimeout(() => {
            const visible = document.querySelector<HTMLElement>(
              `[data-instance-id="${CSS.escape(match.item.instanceId)}"]`,
            );
            if (visible) {
              visible.scrollIntoView({ behavior: "smooth", block: "center" });
              visible.classList.add("hd-widget--search-hit");
              window.setTimeout(() => visible.classList.remove("hd-widget--search-hit"), 1800);
              return;
            }
            try {
              window.sessionStorage.setItem("homedash:focus-widget", match.item.instanceId);
            } catch {
              // Navigation still works when session storage is unavailable.
            }
            window.location.assign(`/t/${encodeURIComponent(match.item.tabId)}`);
          }, 350);
          return;
        }
      }
      setBusy(true);
      const lowerContent = prompt.toLowerCase();
      const asksAboutDashboard =
        /\b(widget|dashboard|homedash|status|service|services)\b/i.test(prompt)
        || dashboardWidgets.some((item) =>
          lowerContent.includes(item.title.toLowerCase())
          || lowerContent.includes(item.widgetId.toLowerCase()),
        );
      let dashboardContext = "";
      if (asksAboutDashboard) {
        const inventory = dashboardWidgets
          .map((item) => `- ${item.title} (${item.widgetId}) on ${item.tabName}`)
          .join("\n");
        const visibleStatus = Array.from(
          document.querySelectorAll<HTMLElement>("[data-instance-id][data-widget-id]"),
        ).map((card) => {
          const title =
            card.querySelector<HTMLElement>(".hd-widget__title")?.innerText.trim()
            || card.dataset.widgetId
            || "Widget";
          const text = card.querySelector<HTMLElement>(".hd-widget__content")?.innerText
            .replace(/\s+/g, " ")
            .trim()
            .slice(0, 900);
          return text ? `- ${title}: ${text}` : `- ${title}: no visible status text`;
        }).join("\n");
        const referencedWidgets = dashboardWidgets.filter((item) => {
          const names = [item.title, item.widgetId]
            .flatMap((name) => [name.toLowerCase(), ...name.toLowerCase().split(/[^a-z0-9]+/)])
            .filter((name) => name.length >= 4 && name !== "widget");
          return names.some((name) => lowerContent.includes(name));
        });
        const uniqueReferenced = Array.from(
          new Map(referencedWidgets.map((item) => [item.instanceId, item])).values(),
        ).slice(0, 8);
        const remoteStatuses = await Promise.all(uniqueReferenced.map(async (item) => {
          try {
            const statusResponse = await fetch(
              `/api/widgets/${encodeURIComponent(item.widgetId)}/status?instance=${encodeURIComponent(item.instanceId)}`,
              { cache: "no-store" },
            );
            const status = await statusResponse.json().catch(() => ({}));
            if (!statusResponse.ok) {
              return `- ${item.title} (${item.tabName}): status unavailable — ${String(status.error || `HTTP ${statusResponse.status}`).slice(0, 240)}`;
            }
            const safe = safeStatusValue(status);
            return `- ${item.title} (${item.tabName}): ${JSON.stringify(safe).slice(0, 4_000)}`;
          } catch (reason) {
            return `- ${item.title} (${item.tabName}): status request failed — ${
              reason instanceof Error ? reason.message : "unknown error"
            }`;
          }
        }));
        dashboardContext = `Available widgets:\n${inventory}

Visible widget information on the current dashboard:
${visibleStatus || "None loaded."}

Live server-side status for widgets referenced in the question (available regardless of active dashboard tab):
${remoteStatuses.length ? remoteStatuses.join("\n") : "No specific widget was identified in the question."}`;
      }
      const response = await fetch("/api/widgets/ai-chat/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          instance: instanceId,
          messages: next.map(({ role, content: text }) => ({ role, content: text })),
          dashboardContext,
          attachments: currentAttachments.map(({ name, type, data, size }) => ({
            name, type, data, size,
          })),
        }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "AI request failed");
      if (!String(data.text || "").trim()) throw new Error("The provider returned an empty response");
      const answeringProvider = String(data.provider || providerId);
      if (answeringProvider !== providerId) {
        setProviderId(answeringProvider);
        setProviderModel(String(data.model || ""));
        setConfigured(true);
        window.dispatchEvent(new CustomEvent("homedash:ai-chat-provider", {
          detail: {
            instanceId,
            provider: answeringProvider,
            logo: providerLogos[answeringProvider] || "",
          },
        }));
      }
      setMessages((current) => [...current, {
        id: messageId(),
        role: "assistant",
        content: String(data.text),
        provider: String(data.provider || "AI"),
        model: String(data.model || ""),
        citations: Array.isArray(data.citations) ? data.citations.map(String) : [],
        handoffFrom: data.smartSwitched ? String(data.previousProvider || "") : undefined,
      }]);
    } catch (reason) {
      if (currentAttachments.length) {
        setAttachments((current) => current.length ? current : currentAttachments);
      }
      setError(reason instanceof Error ? reason.message : "AI request failed");
    } finally {
      setBusy(false);
      setThinkingProviderId("");
    }
  }
  const provider = PROVIDERS[providerId] || PROVIDERS.openai;

  async function switchProvider(nextProvider: string) {
    if (nextProvider === providerId || busy || switching) return;
    setSwitching(true);
    setError("");
    try {
      const response = await fetch("/api/widgets/ai-chat/info", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, provider: nextProvider }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Failed to switch AI provider");
      const selected = String(data.provider || nextProvider);
      setProviderId(selected);
      setProviderModel(String(data.model || ""));
      setConfigured(Boolean(data.configured));
      setProviderLogos(data.logos && typeof data.logos === "object" ? data.logos : {});
      setConfiguredProviders(
        data.configuredProviders && typeof data.configuredProviders === "object"
          ? data.configuredProviders
          : {},
      );
      window.dispatchEvent(new CustomEvent("homedash:ai-chat-provider", {
        detail: { instanceId, provider: selected, logo: String(data.logo || "") },
      }));
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Failed to switch AI provider");
    } finally {
      setSwitching(false);
    }
  }

  return (
    <div className="hd-widget-body aic-body">
      <div className="aic-topbar">
        <div className="aic-agent-controls">
          <div className="aic-agent-switcher" aria-label="Select AI provider">
            {Object.entries(PROVIDERS).filter(([id]) => configuredProviders?.[id]).map(([id, item]) => (
              <button
                type="button"
                key={id}
                className={id === providerId ? "is-active" : ""}
                disabled={busy || switching}
                title={`Switch to ${item.label}`}
                aria-label={`Switch to ${item.label}`}
                aria-pressed={id === providerId}
                onClick={() => void switchProvider(id)}
                style={{ "--aic-provider": item.color } as React.CSSProperties}
              >
                <img src={providerLogos[id] || item.icon} alt="" />
                <span>{item.label}</span>
              </button>
            ))}
          </div>
          <div className="aic-provider aic-provider--status" style={{ "--aic-provider": provider.color } as React.CSSProperties}>
            <i className={busy || switching ? "is-busy" : ""} />
            <em>{switching ? "Switching" : busy ? "Thinking" : configured ? "Ready" : "Needs API key"}</em>
            {providerModel ? <small>{providerModel}</small> : null}
          </div>
        </div>
        <div className="aic-top-actions">
          <button
            type="button"
            disabled={!storageKey || busy || switching}
            title="Load the newest saved conversation"
            onClick={() => {
              if (!storageKey) return;
              try {
                const saved = JSON.parse(localStorage.getItem(storageKey) || "[]");
                if (!Array.isArray(saved)) throw new Error("Saved conversation is invalid");
                skipStorageWriteRef.current = true;
                setMessages(saved.slice(-40));
                setError("");
              } catch (reason) {
                setError(reason instanceof Error ? reason.message : "Conversation sync failed");
              }
            }}
          >
            <span aria-hidden="true">↻</span>
            Sync
          </button>
          <button
            type="button"
            disabled={!messages.length || busy}
            onClick={() => {
              setMessages([]);
              setError("");
              if (storageKey) localStorage.removeItem(storageKey);
            }}
          >
            New chat
          </button>
        </div>
      </div>

      <main className="aic-thread">
        {!messages.length ? (
          <div className="aic-welcome">
            <div className="aic-orb" style={{ "--aic-provider": provider.color } as React.CSSProperties}>
              <img src={providerLogos[providerId] || provider.icon} alt={`${provider.label} logo`} />
            </div>
            <h2>How can I help?</h2>
            <p>Chat with {provider.label} to write, research, analyze, plan, and reason.</p>
            <div>
              {STARTERS.map((starter) => <button type="button" key={starter} onClick={() => void send(starter)}>{starter}<span>›</span></button>)}
            </div>
          </div>
        ) : (
          messages.map((message) => (
            <article
              className={`aic-message is-${message.role}`}
              key={message.id}
              style={message.role === "assistant"
                ? {
                    "--aic-message-provider":
                      (PROVIDERS[message.provider || providerId] || provider).color,
                  } as React.CSSProperties
                : undefined}
            >
              <div className="aic-avatar">
                {message.role === "user" ? "You" : (
                  <img
                    src={
                      providerLogos[message.provider || providerId]
                      || (PROVIDERS[message.provider || providerId] || provider).icon
                    }
                    alt=""
                  />
                )}
              </div>
              <div className="aic-bubble">
                {message.role === "assistant" ? (
                  <div className="aic-message-meta">
                    <span>{message.provider}</span>
                    {message.model ? <span>{message.model}</span> : null}
                    {message.handoffFrom ? <span>Smart switch from {message.handoffFrom}</span> : null}
                    <button type="button" onClick={() => void navigator.clipboard.writeText(message.content)}>Copy</button>
                  </div>
                ) : null}
                <div className="aic-text">{message.content}</div>
                {message.attachments?.length ? (
                  <div className="aic-message-files">
                    {message.attachments.map((name) => <span key={name}>📎 {name}</span>)}
                  </div>
                ) : null}
                {message.citations?.length ? (
                  <div className="aic-citations">
                    <strong>Sources</strong>
                    {message.citations.slice(0, 8).map((url, index) => (
                      <a href={url} target="_blank" rel="noopener noreferrer" key={url}>{index + 1}. {sourceHost(url)}</a>
                    ))}
                  </div>
                ) : null}
              </div>
            </article>
          ))
        )}
        {busy ? (
          <div
            className="aic-thinking"
            style={{
              "--aic-thinking-color":
                (PROVIDERS[thinkingProviderId || providerId] || provider).color,
            } as React.CSSProperties}
            aria-label={`${(PROVIDERS[thinkingProviderId || providerId] || provider).label} is thinking`}
          >
            <i /><i /><i />
          </div>
        ) : null}
        <div ref={endRef} />
      </main>

      {error ? <div className="aic-error">{error}</div> : null}
      <footer className="aic-composer">
        {attachments.length ? (
          <div className="aic-attachments">
            {attachments.map((file) => (
              <span key={file.id}>
                <strong>{file.type.startsWith("image/") ? "Image" : "Document"}</strong>
                {file.name}
                <button
                  type="button"
                  aria-label={`Remove ${file.name}`}
                  onClick={() => setAttachments((current) => current.filter((item) => item.id !== file.id))}
                >
                  ×
                </button>
              </span>
            ))}
          </div>
        ) : null}
        <button
          type="button"
          className="aic-upload"
          disabled={busy || attachments.length >= 4}
          title="Attach images or documents"
          aria-label="Attach images or documents"
          onClick={() => setUploadOpen(true)}
        >
          ＋
        </button>
        <input
          ref={attachmentInputRef}
          type="file"
          accept="image/png,image/jpeg,image/webp,image/gif,application/pdf,text/plain,text/markdown,text/csv,application/json,.txt,.md,.csv,.json,.pdf"
          multiple
          hidden
          onChange={(event) => {
            void addAttachmentFiles(event.target.files || []);
            event.target.value = "";
          }}
        />
        <textarea
          value={input}
          rows={1}
          placeholder="Message your AI assistant…"
          onChange={(event) => setInput(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === "Enter" && !event.shiftKey) {
              event.preventDefault();
              void send();
            }
          }}
        />
        <button
          className="aic-send"
          type="button"
          disabled={(!input.trim() && !attachments.length) || busy}
          onClick={() => void send()}
          aria-label="Send message"
        >
          ↑
        </button>
        <span>Enter to send · Shift+Enter for a new line</span>
      </footer>
      {uploadOpen && typeof document !== "undefined"
        ? createPortal(
            <div
              className="aic-upload-scrim"
              role="presentation"
              onMouseDown={() => setUploadOpen(false)}
            >
              <section
                className="aic-upload-modal"
                role="dialog"
                aria-modal="true"
                aria-labelledby="aic-upload-title"
                onMouseDown={(event) => event.stopPropagation()}
              >
                <header>
                  <div>
                    <small>AI CHAT</small>
                    <h2 id="aic-upload-title">Add attachments</h2>
                    <p>Upload images or documents for the selected agent to review.</p>
                  </div>
                  <button type="button" aria-label="Close upload window" onClick={() => setUploadOpen(false)}>×</button>
                </header>
                <button
                  type="button"
                  className={`aic-upload-dropzone${uploadDragActive ? " is-dragging" : ""}`}
                  onClick={() => attachmentInputRef.current?.click()}
                  onDragEnter={(event) => {
                    event.preventDefault();
                    setUploadDragActive(true);
                  }}
                  onDragOver={(event) => {
                    event.preventDefault();
                    setUploadDragActive(true);
                  }}
                  onDragLeave={(event) => {
                    event.preventDefault();
                    if (event.currentTarget === event.target) setUploadDragActive(false);
                  }}
                  onDrop={(event) => {
                    event.preventDefault();
                    setUploadDragActive(false);
                    void addAttachmentFiles(event.dataTransfer.files);
                  }}
                >
                  <span>＋</span>
                  <strong>Drop files here</strong>
                  <em>or click to browse your device</em>
                  <small>PNG, JPEG, WebP, GIF, PDF, TXT, MD, CSV, JSON · 8 MB each</small>
                </button>
                <div className="aic-upload-list">
                  <div>
                    <strong>Selected files</strong>
                    <span>{attachments.length}/4</span>
                  </div>
                  {attachments.length ? attachments.map((file) => (
                    <article key={file.id}>
                      <span>{file.type.startsWith("image/") ? "IMG" : "DOC"}</span>
                      <div><strong>{file.name}</strong><small>{(file.size / 1024 / 1024).toFixed(2)} MB</small></div>
                      <button
                        type="button"
                        aria-label={`Remove ${file.name}`}
                        onClick={() => setAttachments((current) => current.filter((item) => item.id !== file.id))}
                      >
                        Remove
                      </button>
                    </article>
                  )) : <p>No files selected yet.</p>}
                </div>
                <footer>
                  <button type="button" onClick={() => setUploadOpen(false)}>Cancel</button>
                  <button
                    type="button"
                    disabled={attachments.length >= 4}
                    onClick={() => attachmentInputRef.current?.click()}
                  >
                    Browse files
                  </button>
                  <button type="button" className="is-primary" onClick={() => setUploadOpen(false)}>
                    Done
                  </button>
                </footer>
              </section>
            </div>,
            document.body,
          )
        : null}
    </div>
  );
}
