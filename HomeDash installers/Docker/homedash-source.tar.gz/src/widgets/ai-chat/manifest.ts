import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "ai-chat",
  name: "AI Chat",
  description: "Chat with OpenAI, Gemini, Claude, or Perplexity",
  version: "1.0.0",
  category: "General",
  defaultSize: { w: 5, h: 5, minW: 3, minH: 3 },
  hostClass: "ai-chat-host",
  configFields: [
    {
      key: "provider",
      label: "AI Provider",
      type: "select",
      options: [
        { value: "openai", label: "ChatGPT / OpenAI" },
        { value: "gemini", label: "Google Gemini" },
        { value: "claude", label: "Anthropic Claude" },
        { value: "perplexity", label: "Perplexity" },
      ],
    },
    { key: "apiKey", label: "API Key", type: "password", required: true },
    { key: "model", label: "Model", placeholder: "Leave blank for provider default" },
    {
      key: "enabled",
      label: "Agent Status",
      type: "select",
      required: true,
      options: [
        { value: "true", label: "Enabled — show in widget" },
        { value: "false", label: "Disabled — hide from widget" },
      ],
    },
    {
      key: "systemPrompt",
      label: "System Prompt",
      placeholder: "You are a helpful, concise dashboard assistant.",
    },
    {
      key: "conversationPersistence",
      label: "Conversation Persistence",
      type: "select",
      required: true,
      options: [
        { value: "widget", label: "This AI Chat widget only" },
        { value: "shared", label: "Shared across all AI Chat widgets" },
        { value: "none", label: "Do not save conversations" },
      ],
    },
  ],
};
