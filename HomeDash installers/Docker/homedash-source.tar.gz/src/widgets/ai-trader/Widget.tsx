"use client";

import "@/styles/widgets/ai-trader.widget.css";
import { useEffect, useMemo, useState } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import type { BacktestResult, PaperTrade, TraderStrategy } from "@/lib/widgets/ai-trader";

type AssetType = "stock" | "crypto";
type Tab = "lab" | "trades" | "analysis";
type Ranked = BacktestResult[];

const STRATEGIES: Record<TraderStrategy, { name: string; description: string }> = {
  sma: { name: "SMA Crossover", description: "Trades when a fast moving average crosses a slower trend." },
  rsi: { name: "RSI Reversion", description: "Buys oversold conditions and exits when momentum becomes overbought." },
  momentum: { name: "Momentum", description: "Follows directional price strength over a configurable lookback." },
};

function money(value: number) {
  return value.toLocaleString(undefined, { style: "currency", currency: "USD", maximumFractionDigits: 2 });
}
function percent(value: number) {
  return `${value >= 0 ? "+" : ""}${value.toFixed(2)}%`;
}

function Curve({ result }: { result: BacktestResult }) {
  const width = 900;
  const height = 210;
  const values = result.equity;
  const benchmark = result.prices.map((price) => result.initialCapital * price / result.prices[0]);
  const all = [...values, ...benchmark];
  const min = Math.min(...all);
  const max = Math.max(...all);
  const range = max - min || 1;
  const points = (series: number[]) => series.map((value, index) => {
    const x = series.length === 1 ? 0 : index / (series.length - 1) * width;
    const y = height - ((value - min) / range) * height;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(" ");
  return (
    <div className="ait-chart">
      <div className="ait-chart-legend"><span className="strategy">Strategy</span><span className="benchmark">Buy & hold</span></div>
      <svg viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" aria-label="Backtest equity curve">
        <defs>
          <linearGradient id="ait-fill" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#38bdf8" stopOpacity=".3" /><stop offset="1" stopColor="#38bdf8" stopOpacity="0" /></linearGradient>
        </defs>
        <polyline className="benchmark-line" points={points(benchmark)} />
        <polygon className="strategy-fill" points={`0,${height} ${points(values)} ${width},${height}`} />
        <polyline className="strategy-line" points={points(values)} />
      </svg>
    </div>
  );
}

function TradeRow({ trade, prices }: { trade: PaperTrade; prices: number[] }) {
  const progress = prices.length > 1 ? Math.round((trade.index / (prices.length - 1)) * 100) : 0;
  return (
    <div className="ait-trade">
      <span className={`ait-side is-${trade.side}`}>{trade.side}</span>
      <div><strong>{money(trade.price)}</strong><small>{trade.reason} · {progress}% through test</small></div>
      <div><strong>{trade.quantity.toFixed(4)}</strong><small>units</small></div>
      <div className={trade.pnl == null ? "" : trade.pnl >= 0 ? "positive" : "negative"}>
        <strong>{trade.pnl == null ? money(trade.value) : money(trade.pnl)}</strong>
        <small>{trade.pnl == null ? "position value" : "realized P/L"}</small>
      </div>
    </div>
  );
}

export default function AiTraderWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "ai-trader";
  const storageKey = `homedash.ai-trader.${instanceId}`;
  const [tab, setTab] = useState<Tab>("lab");
  const [assetType, setAssetType] = useState<AssetType>("stock");
  const [asset, setAsset] = useState("AAPL");
  const [range, setRange] = useState(90);
  const [strategy, setStrategy] = useState<TraderStrategy>("sma");
  const [capital, setCapital] = useState(10_000);
  const [feePct, setFeePct] = useState(0.1);
  const [stopLossPct, setStopLossPct] = useState(8);
  const [takeProfitPct, setTakeProfitPct] = useState(18);
  const [fast, setFast] = useState(5);
  const [slow, setSlow] = useState(20);
  const [period, setPeriod] = useState(14);
  const [buyThreshold, setBuyThreshold] = useState(30);
  const [sellThreshold, setSellThreshold] = useState(70);
  const [stockDataInstance, setStockDataInstance] = useState("invest-stocks");
  const [result, setResult] = useState<BacktestResult | null>(null);
  const [ranked, setRanked] = useState<Ranked>([]);
  const [busy, setBusy] = useState<"run" | "optimize" | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch(`/api/widgets/ai-trader/info?instance=${encodeURIComponent(instanceId)}`)
      .then((response) => response.json())
      .then((data) => {
        setStockDataInstance(String(data.stockDataInstance || "invest-stocks"));
        setCapital(Number(data.defaultCapital) || 10_000);
      }).catch(() => undefined);
    try {
      const saved = JSON.parse(localStorage.getItem(storageKey) || "null");
      if (saved?.result) {
        setResult(saved.result);
        setAsset(saved.asset || "AAPL");
        setAssetType(saved.assetType === "crypto" ? "crypto" : "stock");
      }
    } catch { /* ignore malformed browser state */ }
  }, [instanceId, storageKey]);

  useEffect(() => {
    if (strategy === "momentum") {
      setBuyThreshold(2);
      setSellThreshold(-2);
    } else if (strategy === "rsi") {
      setBuyThreshold(30);
      setSellThreshold(70);
    }
  }, [strategy]);

  const closedTrades = useMemo(() => result?.trades.filter((trade) => trade.side === "sell") || [], [result]);

  async function execute(optimize: boolean) {
    setBusy(optimize ? "optimize" : "run");
    setError("");
    try {
      const response = await fetch("/api/widgets/ai-trader/backtest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          assetType, asset, range, strategy, capital, feePct, stopLossPct, takeProfitPct,
          fast, slow, period, buyThreshold, sellThreshold, optimize, stockDataInstance,
        }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data.result) throw new Error(data.error || `HTTP ${response.status}`);
      setResult(data.result);
      setRanked(Array.isArray(data.ranked) ? data.ranked : []);
      if (optimize) {
        const params = data.result.params;
        setFast(params.fast); setSlow(params.slow); setPeriod(params.period);
        setBuyThreshold(params.buyThreshold); setSellThreshold(params.sellThreshold);
      }
      localStorage.setItem(storageKey, JSON.stringify({
        result: data.result, asset, assetType, savedAt: Date.now(),
      }));
      setTab("analysis");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Backtest failed");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="ait-root">
      <header className="ait-head">
        <div className="ait-title"><span>AI</span><div><strong>Strategy Lab</strong><small>Paper simulation · no live orders</small></div></div>
        <nav>{(["lab", "analysis", "trades"] as Tab[]).map((item) => <button type="button" className={tab === item ? "is-active" : ""} key={item} onClick={() => setTab(item)}>{item}</button>)}</nav>
        <span className="ait-paper">Paper only</span>
      </header>

      {tab === "lab" ? (
        <div className="ait-lab">
          <section className="ait-form">
            <div className="ait-section-title"><b>01</b><div><strong>Market</strong><small>Choose the historical instrument</small></div></div>
            <div className="ait-segment"><button type="button" className={assetType === "stock" ? "is-active" : ""} onClick={() => { setAssetType("stock"); setAsset("AAPL"); }}>Stocks</button><button type="button" className={assetType === "crypto" ? "is-active" : ""} onClick={() => { setAssetType("crypto"); setAsset("bitcoin"); }}>Crypto</button></div>
            <div className="ait-fields two"><label><span>{assetType === "stock" ? "Ticker symbol" : "CoinGecko ID"}</span><input value={asset} onChange={(event) => setAsset(event.target.value)} placeholder={assetType === "stock" ? "AAPL" : "bitcoin"} /></label><label><span>History</span><select value={range} onChange={(event) => setRange(Number(event.target.value))}><option value={30}>30 days</option><option value={90}>90 days</option><option value={180}>180 days</option><option value={365}>1 year</option></select></label></div>
            <div className="ait-section-title"><b>02</b><div><strong>Algorithm</strong><small>{STRATEGIES[strategy].description}</small></div></div>
            <div className="ait-strategies">{(Object.entries(STRATEGIES) as [TraderStrategy, typeof STRATEGIES[TraderStrategy]][]).map(([key, meta]) => <button type="button" key={key} className={strategy === key ? "is-active" : ""} onClick={() => setStrategy(key)}><strong>{meta.name}</strong><small>{key === "sma" ? "Trend" : key === "rsi" ? "Mean reversion" : "Trend strength"}</small></button>)}</div>
            <div className="ait-fields three">
              {strategy === "sma" ? <><label><span>Fast average</span><input type="number" value={fast} onChange={(e) => setFast(Number(e.target.value))} /></label><label><span>Slow average</span><input type="number" value={slow} onChange={(e) => setSlow(Number(e.target.value))} /></label></> : <label><span>Lookback period</span><input type="number" value={period} onChange={(e) => setPeriod(Number(e.target.value))} /></label>}
              {strategy !== "sma" ? <><label><span>Buy trigger</span><input type="number" value={buyThreshold} onChange={(e) => setBuyThreshold(Number(e.target.value))} /></label><label><span>Sell trigger</span><input type="number" value={sellThreshold} onChange={(e) => setSellThreshold(Number(e.target.value))} /></label></> : null}
            </div>
            <div className="ait-section-title"><b>03</b><div><strong>Risk & capital</strong><small>Model fees and automatic exits</small></div></div>
            <div className="ait-fields four"><label><span>Starting capital</span><input type="number" value={capital} onChange={(e) => setCapital(Number(e.target.value))} /></label><label><span>Fee %</span><input type="number" step=".01" value={feePct} onChange={(e) => setFeePct(Number(e.target.value))} /></label><label><span>Stop loss %</span><input type="number" value={stopLossPct} onChange={(e) => setStopLossPct(Number(e.target.value))} /></label><label><span>Take profit %</span><input type="number" value={takeProfitPct} onChange={(e) => setTakeProfitPct(Number(e.target.value))} /></label></div>
          </section>
          <aside className="ait-launch">
            <div className="ait-orb">AI</div><h3>Ready to simulate</h3><p>Backtest the current rules or let the optimizer compare parameter combinations using the same historical sample.</p>
            {error ? <div className="ait-error">{error}</div> : null}
            <button type="button" className="primary" disabled={Boolean(busy)} onClick={() => execute(false)}>{busy === "run" ? "Running simulation…" : "Run backtest"}</button>
            <button type="button" disabled={Boolean(busy)} onClick={() => execute(true)}>{busy === "optimize" ? "Testing strategies…" : "Smart optimize"}</button>
            <small>Historical performance is not a prediction of future results.</small>
          </aside>
        </div>
      ) : null}

      {tab === "analysis" ? result ? (
        <div className="ait-analysis">
          <div className="ait-metrics">
            <article><span>Final equity</span><strong>{money(result.finalEquity)}</strong><small className={result.returnPct >= 0 ? "positive" : "negative"}>{percent(result.returnPct)}</small></article>
            <article><span>Buy & hold</span><strong>{percent(result.benchmarkPct)}</strong><small>benchmark return</small></article>
            <article><span>Max drawdown</span><strong className="negative">-{result.maxDrawdownPct.toFixed(2)}%</strong><small>peak-to-trough risk</small></article>
            <article><span>Win rate</span><strong>{result.winRatePct.toFixed(1)}%</strong><small>{closedTrades.length} completed trades</small></article>
            <article><span>Sharpe</span><strong>{result.sharpe.toFixed(2)}</strong><small>risk-adjusted score</small></article>
            <article><span>Profit factor</span><strong>{result.profitFactor >= 99 ? "∞" : result.profitFactor.toFixed(2)}</strong><small>gross wins ÷ losses</small></article>
          </div>
          <Curve result={result} />
          <div className="ait-insights">
            <article><b>Executive readout</b><p>The strategy {result.returnPct > result.benchmarkPct ? "outperformed" : "underperformed"} buy-and-hold by {Math.abs(result.returnPct - result.benchmarkPct).toFixed(2)} percentage points with a maximum modeled drawdown of {result.maxDrawdownPct.toFixed(2)}%.</p></article>
            <article><b>Risk signal</b><p>{result.sharpe >= 1 ? "Risk-adjusted performance was favorable in this sample." : result.sharpe > 0 ? "Returns were positive relative to volatility, but the edge was modest." : "The tested rules did not compensate for observed volatility."}</p></article>
          </div>
          {ranked.length ? <div className="ait-ranked"><strong>Optimizer finalists</strong>{ranked.map((item, index) => <span key={`${item.score}-${index}`}>#{index + 1} {percent(item.returnPct)} · DD {item.maxDrawdownPct.toFixed(1)}% · score {item.score.toFixed(1)}</span>)}</div> : null}
        </div>
      ) : <div className="ait-empty">Configure and run a paper backtest to generate analysis.</div> : null}

      {tab === "trades" ? result ? <div className="ait-trades">{result.trades.length ? result.trades.map((trade, index) => <TradeRow key={`${trade.index}-${trade.side}-${index}`} trade={trade} prices={result.prices} />) : <div className="ait-empty">The strategy produced no trades for this sample.</div>}</div> : <div className="ait-empty">No paper trades yet.</div> : null}
    </div>
  );
}
