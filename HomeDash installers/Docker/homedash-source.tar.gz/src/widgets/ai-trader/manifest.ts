import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "ai-trader",
  name: "AI Trader",
  description: "Paper-trading strategy lab for stocks and crypto",
  version: "1.0.0",
  category: "Invest",
  hostClass: "ai-trader-host",
  defaultSize: { w: 8, h: 6, minW: 5, minH: 4 },
  configFields: [
    {
      key: "stockDataInstance",
      label: "Stocks widget data source",
      placeholder: "invest-stocks",
    },
    {
      key: "defaultCapital",
      label: "Default paper capital",
      type: "number",
      placeholder: "10000",
    },
  ],
};
