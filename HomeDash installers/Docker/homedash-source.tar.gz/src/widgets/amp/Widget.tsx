"use client";
import "@/styles/widgets/amp.widget.css";

import { useCallback, useState } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type Metric = { name: string; value: number; max: number; percent: number; units: string };
type Server = {
  id: string;
  instanceName: string;
  name: string;
  description: string;
  game: string;
  running: boolean;
  state: number;
  stateLabel: string;
  address: string;
  port: number;
  diskMB: number;
  metrics: Metric[];
  image: string;
  directUrl: string;
};
type Data = {
  href: string;
  openFallbackUrl?: string;
  servers: Server[];
  summary: { total: number; running: number; stopped: number };
};
type Action = "start" | "stop" | "restart" | "kill" | "update" | "manage";

function metricFor(server: Server, pattern: RegExp) {
  return server.metrics.find((metric) => pattern.test(metric.name));
}

function ActionIcon({ name }: { name: "update" | "share" | "external" | "manage" | "play" | "stop" | "restart" }) {
  const paths = {
    update: <><path d="M12 3v12" /><path d="m7 10 5 5 5-5" /><path d="M5 21h14" /></>,
    share: <><circle cx="18" cy="5" r="3" /><circle cx="6" cy="12" r="3" /><circle cx="18" cy="19" r="3" /><path d="m8.6 10.5 6.8-4" /><path d="m8.6 13.5 6.8 4" /></>,
    external: <><path d="M15 3h6v6" /><path d="m10 14 11-11" /><path d="M18 13v7a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h7" /></>,
    manage: <><path d="M12 2 4 6v6c0 5 3.4 8.4 8 10 4.6-1.6 8-5 8-10V6Z" /><circle cx="12" cy="11" r="3" /><path d="M7.7 17c1.2-1.3 2.6-2 4.3-2s3.1.7 4.3 2" /></>,
    play: <path d="m8 5 11 7-11 7Z" />,
    stop: <rect x="6" y="6" width="12" height="12" rx="1" />,
    restart: <><path d="M20 11a8 8 0 1 0-2.3 5.7" /><path d="M20 4v7h-7" /></>,
  };
  return <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">{paths[name]}</svg>;
}

export default function AmpWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "amp";
  const [data, setData] = useState<Data | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState("");
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);

  const load = useCallback(async () => {
    try {
      const response = await fetch(`/api/widgets/amp/status?instance=${encodeURIComponent(instanceId)}`, {
        cache: "no-store",
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "AMP unavailable");
      setData(json);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "AMP unavailable");
    } finally {
      setLoading(false);
    }
  }, [instanceId]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: 5_000 });

  const act = async (server: Server, action: Action) => {
    const warning =
      action === "kill"
        ? `Force kill ${server.name}? Unsaved game state may be lost.`
        : action === "manage"
          ? ""
          : action === "update"
            ? `Update ${server.name}?`
            : "";
    if (warning && !window.confirm(warning)) return;
    const key = `${server.id}:${action}`;
    setBusy(key);
    try {
      const response = await fetch("/api/widgets/amp/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          instance: instanceId,
          instanceName: server.instanceName,
          serverId: server.id,
          action,
        }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Action failed");
      if (action === "manage") {
        const managedPath =
          (typeof json.result === "string" && json.result)
          || (typeof json.result?.Result === "string" && json.result.Result)
          || server.directUrl;
        if (managedPath) {
          let managedUrl = managedPath;
          try {
            managedUrl = new URL(managedPath, openHref || data?.href || server.directUrl).toString();
          } catch {
            // Keep an already usable absolute URL unchanged.
          }
          window.open(managedUrl, "_blank", "noopener,noreferrer");
        }
        return;
      }
      setError("");
      for (const delay of [300, 1_200, 2_500, 5_000]) {
        window.setTimeout(() => void load(), delay);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Action failed");
    } finally {
      setBusy("");
    }
  };

  if (loading && !data) {
    return <div className="hd-widget-body amp-body amp-loading" ref={rootRef}>Connecting to AMP…</div>;
  }
  if (!data) {
    return (
      <div className="hd-widget-body amp-body" ref={rootRef}>
        <div className="amp-error"><strong>AMP unavailable</strong><span>{error}</span><button onClick={load}>Retry</button></div>
      </div>
    );
  }

  return (
    <div className="hd-widget-body amp-body" ref={rootRef}>
      <div className="amp-toolbar">
        <div className="amp-summary">
          <span className="amp-live-dot" />
          <strong>{data.summary.running}</strong> running
          <span className="amp-divider" />
          {data.summary.total} servers
        </div>
        {openHref ? <a href={openHref} target="_blank" rel="noopener noreferrer">Open AMP</a> : null}
      </div>
      {error ? <div className="amp-inline-error">{error}</div> : null}
      <div className="amp-server-list">
        {data.servers.map((server) => {
          const cpu = metricFor(server, /cpu/i);
          const memory = metricFor(server, /memory|ram/i);
          const users = metricFor(server, /users|players/i);
          return (
            <article className={`amp-server${server.running ? " is-running" : " is-stopped"}`} key={server.id}>
              <div className="amp-server-art" aria-hidden>
                <div className="amp-server-art-fallback">
                  <span>🎮</span>
                  <b>{server.game.slice(0, 2).toUpperCase()}</b>
                </div>
                {server.image ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={server.image}
                    alt=""
                    loading="lazy"
                    onError={(event) => {
                      event.currentTarget.style.display = "none";
                    }}
                  />
                ) : null}
              </div>
              <div className="amp-server-shade" />
              <div className="amp-server-content">
                <div className="amp-server-head">
                  <div className="amp-server-title">
                    <strong>{server.name}</strong>
                    <span>{server.address ? `${server.address}:${server.port}` : server.game}</span>
                  </div>
                  <span className={`amp-state state-${server.state}${server.running ? " is-online" : ""}`}>
                    {server.running ? "Running" : "Offline"}
                    <i><ActionIcon name={server.running ? "play" : "stop"} /></i>
                  </span>
                </div>
                {server.running ? (
                  <div className="amp-metrics">
                    <div><span className="amp-metric-icon">⚙</span><span>CPU <b>{cpu ? `${Math.round(cpu.percent)}%` : "—"}</b></span></div>
                    <div><span className="amp-metric-icon">▥</span><span>Memory <b>{memory ? `${Math.round(memory.percent)}%` : "—"}</b></span></div>
                    <div><span className="amp-metric-icon">♟</span><span>Users <b>{users ? `${Math.round(users.value)}${users.max ? `/${Math.round(users.max)}` : ""}` : "—"}</b></span></div>
                  </div>
                ) : (
                  <div className="amp-offline-copy">
                    <strong>Instance not running</strong>
                    <span>Use the Start button to launch this instance.</span>
                  </div>
                )}
                <div className="amp-actions">
                  {!server.running ? (
                    <>
                      <button type="button" disabled={Boolean(busy)} onClick={() => act(server, "update")} title="Update instance" aria-label="Update instance"><ActionIcon name="update" /></button>
                      <button type="button" className="is-start" disabled={Boolean(busy)} onClick={() => act(server, "start")} title="Start server" aria-label="Start server"><ActionIcon name="play" /></button>
                    </>
                  ) : (
                    <>
                      <button type="button" className="is-danger" disabled={Boolean(busy)} onClick={() => act(server, "stop")} title="Stop server" aria-label="Stop server"><ActionIcon name="stop" /></button>
                      <button type="button" disabled={Boolean(busy)} onClick={() => act(server, "update")} title="Update instance" aria-label="Update instance"><ActionIcon name="update" /></button>
                    </>
                  )}
                  {busy.startsWith(`${server.id}:`) ? <span className="amp-working">Working…</span> : null}
                </div>
              </div>
            </article>
          );
        })}
        {!data.servers.length ? <div className="amp-empty">No managed game instances found.</div> : null}
      </div>
    </div>
  );
}
