import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "amp",
  name: "AMP Game Servers",
  description: "Monitor and control CubeCoders AMP game servers",
  version: "0.1.0",
  category: "Games",
  hostClass: "amp-host",
  defaultSize: { w: 5, h: 7, minW: 3, minH: 5 },
  configFields: [
    { key: "baseUrl", label: "Private - IP", type: "url", placeholder: "http://10.0.0.20:8080" },
    { key: "fallbackUrl", label: "Fallback Public URL", type: "url", placeholder: "https://amp.example.com" },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url", placeholder: "http://10.0.0.20:8080" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://amp.example.com" },
    { key: "username", label: "AMP username", type: "text", required: true },
    { key: "password", label: "AMP password", type: "password", required: true },
    { key: "twoFactorToken", label: "Two-factor token", type: "password", placeholder: "Optional current token" },
    { key: "allowNonAdminControls", label: "Allow non-admin users to control AMP instances", type: "checkbox" },
  ],
};
