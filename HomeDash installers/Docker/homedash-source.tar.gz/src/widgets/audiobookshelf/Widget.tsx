"use client";
import "@/styles/widgets/audiobookshelf.widget.css";


import { useCallback, useEffect, useState, useLayoutEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";
import { resolveOpenHref } from "@/lib/open-href";
import type { AbsBook, AbsConnectionSource, AbsSession, AbsTab } from "@/lib/widgets/audiobookshelf";

type Library = { id: string; name: string; mediaType?: string; totalItems?: number };

type StatusPayload = {
  href: string;
  openFallbackUrl?: string;
  tab: AbsTab;
  libraryId?: string | null;
  libraries?: Library[];
  totals?: { items: number; authors: number; duration: number; size: number };
  recent?: AbsBook[];
  items?: AbsBook[];
  sessions?: AbsSession[];
  connectionSource?: AbsConnectionSource;
  error?: string;
};

const CONNECTION_SOURCE_LABEL: Record<AbsConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

function ConnectionCorner({ source }: { source: AbsConnectionSource }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const mark = (
    <div
      className={`abs-corner-source abs-corner-source--${source}`}
      title={CONNECTION_SOURCE_LABEL[source]}
      aria-label={CONNECTION_SOURCE_LABEL[source]}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}


const TABS: { key: AbsTab; label: string }[] = [
  { key: "library", label: "Library" },
  { key: "continue", label: "Continue" },
  { key: "recent", label: "Recent" },
  { key: "playing", label: "Now Playing" },
];

const POLL_MS = 60_000;

function fmtDuration(secs: number) {
  if (!secs || secs <= 0) return "—";
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  if (h >= 1) return `${h}h ${m}m`;
  return `${m}m`;
}

function fmtBytes(bytes: number) {
  if (!bytes || bytes <= 0) return "—";
  if (bytes >= 1e12) return `${(bytes / 1e12).toFixed(2)} TB`;
  if (bytes >= 1e9) return `${(bytes / 1e9).toFixed(2)} GB`;
  if (bytes >= 1e6) return `${(bytes / 1e6).toFixed(1)} MB`;
  return `${(bytes / 1e3).toFixed(0)} KB`;
}

function coverUrl(instanceId: string, id?: string, width = 280) {
  if (!id) return "";
  const q = new URLSearchParams({ instance: instanceId, id, width: String(width) });
  return `/api/widgets/audiobookshelf/cover?${q.toString()}`;
}

function BookGlyph() {
  return (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden>
      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
      <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
    </svg>
  );
}

function BookCard({
  item,
  instanceId,
  index,
  caseView,
  onSelect,
}: {
  item: AbsBook;
  instanceId: string;
  index: number;
  caseView: boolean;
  onSelect: (item: AbsBook) => void;
}) {
  const [coverFailed, setCoverFailed] = useState(false);
  const cover = coverUrl(instanceId, item.id);
  const sub = [item.author, item.series, item.duration ? fmtDuration(item.duration) : ""]
    .filter(Boolean)
    .join(" · ");
  return (
    <button
      type="button"
      className={`abs-card${caseView ? " abs-card--case" : ""}`}
      onClick={() => onSelect(item)}
      style={{ animationDelay: `${index * 35}ms` }}
      title={item.title}
    >
      {caseView ? (
        <span className="abs-book-spine" aria-hidden="true">
          {cover && !coverFailed ? <img src={cover} alt="" loading="lazy" decoding="async" /> : null}
          <span>{item.title}</span>
        </span>
      ) : null}
      <div className="abs-card-art">
        {cover && !coverFailed ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={cover}
            alt=""
            loading="lazy"
            decoding="async"
            onError={() => setCoverFailed(true)}
          />
        ) : (
          <div className="abs-card-placeholder">
            <BookGlyph />
          </div>
        )}
        {item.progress != null ? (
          <div className="abs-card-progress">
            <span style={{ width: `${Math.max(0, Math.min(100, item.progress))}%` }} />
          </div>
        ) : null}
      </div>
      <div className="abs-card-meta">
        <div className="abs-card-title">{item.title}</div>
        {sub ? <div className="abs-card-sub">{sub}</div> : null}
      </div>
    </button>
  );
}

export default function Widget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "audiobookshelf";

  const [tab, setTab] = useState<AbsTab>("library");
  const [libraryId, setLibraryId] = useState<string>("");
  const [data, setData] = useState<StatusPayload | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [caseView, setCaseView] = useState(false);
  const [bookShelf, setBookShelf] = useState(false);
  const [selectedBook, setSelectedBook] = useState<AbsBook | null>(null);

  useEffect(() => {
    if (!selectedBook) return;
    const close = (event: KeyboardEvent) => {
      if (event.key === "Escape") setSelectedBook(null);
    };
    window.addEventListener("keydown", close);
    return () => window.removeEventListener("keydown", close);
  }, [selectedBook]);

  useEffect(() => {
    let alive = true;
    const loadAppearance = () =>
      fetch(`/api/widgets/audiobookshelf/appearance?instance=${encodeURIComponent(instanceId)}&t=${Date.now()}`, {
        cache: "no-store",
      })
        .then((response) => response.json())
        .then((appearance) => {
          if (!alive) return;
          if (typeof appearance.caseView === "boolean") setCaseView(appearance.caseView);
          if (typeof appearance.bookShelf === "boolean") setBookShelf(appearance.bookShelf);
        })
        .catch(() => undefined);
    void loadAppearance();
    const reload = (event: Event) => {
      const detail = (event as CustomEvent<{ instanceId?: string; caseView?: boolean; bookShelf?: boolean }>).detail;
      if (detail?.instanceId !== instanceId) return;
      if (typeof detail.caseView === "boolean") setCaseView(detail.caseView);
      if (typeof detail.bookShelf === "boolean") setBookShelf(detail.bookShelf);
      void loadAppearance();
    };
    window.addEventListener("homedash:widget-config-saved", reload);
    return () => {
      alive = false;
      window.removeEventListener("homedash:widget-config-saved", reload);
    };
  }, [instanceId]);

  const load = useCallback(
    async (opts?: { soft?: boolean }) => {
      if (!opts?.soft) setLoading(true);
      try {
        const q = new URLSearchParams({ instance: instanceId, tab });
        if (libraryId) q.set("libraryId", libraryId);
        const r = await fetch(`/api/widgets/audiobookshelf/status?${q.toString()}`);
        const j = (await r.json()) as StatusPayload & { error?: string };
        if (!r.ok) throw new Error(j.error || "Failed to load Audiobookshelf");
        setData(j);
        if (!libraryId && j.libraryId) setLibraryId(String(j.libraryId));
        setError("");
      } catch (e) {
        setError(e instanceof Error ? e.message : "Audiobookshelf unavailable");
      } finally {
        setLoading(false);
      }
    },
    [instanceId, tab, libraryId],
  );

  useEffect(() => {
    void load();
  }, [load]);

  const softPoll = useCallback(() => {
    void load({ soft: true });
  }, [load]);
  const { rootRef } = useWidgetPoll(softPoll, { intervalMs: POLL_MS });

  const href = useOpenHref(data?.href, data?.openFallbackUrl);
  const libraries = data?.libraries || [];
  const isOnline = Boolean(data) && !error;
  const connectionSource = data?.connectionSource;

  function renderBody() {
    if (loading && !data) {
      return (
        <div className="abs-skeleton-wrap">
          {Array.from({ length: 5 }, (_, i) => (
            <div className="abs-skeleton-row" key={i} />
          ))}
        </div>
      );
    }
    if (error && !data) return <div className="abs-empty">{error}</div>;

    if (tab === "playing") {
      const sessions = data?.sessions || [];
      if (!sessions.length) {
        return (
          <div className="abs-empty">
            <BookGlyph />
            <div>Nothing playing right now</div>
          </div>
        );
      }
      return (
        <div className="abs-song-list">
          {sessions.map((s, i) => (
            <a
              key={`${s.id}-${i}`}
              className="abs-song-row abs-now-playing-row"
              href={resolveOpenHref(s.href, s.openFallbackUrl)}
              target="_blank"
              rel="noopener noreferrer"
              style={{ animationDelay: `${i * 25}ms` }}
            >
              <div className="abs-song-art">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={coverUrl(instanceId, s.id, 120)} alt="" loading="lazy" />
                <div className="abs-playing-dot" />
              </div>
              <div className="abs-song-body">
                <div className="abs-song-title">{s.title}</div>
                <div className="abs-song-meta">{s.author}</div>
                <div className="abs-session-bar">
                  <span style={{ width: `${s.pct}%` }} />
                </div>
              </div>
              <div className="abs-song-right">
                {s.user ? <span className="abs-song-user">{s.user}</span> : null}
                <span className="abs-song-dur">{s.pct}%</span>
                <div className="abs-equalizer" aria-label="Now playing">
                  <span />
                  <span />
                  <span />
                </div>
              </div>
            </a>
          ))}
        </div>
      );
    }

    if (tab === "continue" || tab === "recent") {
      const items = data?.items || [];
      if (!items.length) {
        return (
          <div className="abs-empty">
            {tab === "continue" ? "Nothing in progress" : "No recently added items"}
          </div>
        );
      }
      return (
        <div className={`abs-card-grid${caseView ? " abs-card-grid--case" : ""}${caseView && bookShelf ? " abs-card-grid--shelf" : ""}`}>
          {items.map((item, i) => (
            <BookCard key={item.id} item={item} instanceId={instanceId} index={i} caseView={caseView} onSelect={setSelectedBook} />
          ))}
        </div>
      );
    }

    const totals = data?.totals || { items: 0, authors: 0, duration: 0, size: 0 };
    const recent = data?.recent || [];
    return (
      <>
        <div className="abs-stats-grid">
          <div className="abs-stat-card">
            <div className="abs-stat-num">{totals.items.toLocaleString()}</div>
            <div className="abs-stat-label">Books & Shows</div>
          </div>
          <div className="abs-stat-card">
            <div className="abs-stat-num">{totals.authors.toLocaleString()}</div>
            <div className="abs-stat-label">Authors</div>
          </div>
          <div className="abs-stat-card">
            <div className="abs-stat-num">{fmtDuration(totals.duration)}</div>
            <div className="abs-stat-label">Total Duration</div>
          </div>
          <div className="abs-stat-card">
            <div className="abs-stat-num">{fmtBytes(totals.size)}</div>
            <div className="abs-stat-label">Library Size</div>
          </div>
        </div>
        {recent.length ? (
          <>
            <div className="abs-section-label" style={{ marginTop: 16 }}>
              Recently Added
            </div>
            <div className={`abs-card-grid${caseView ? " abs-card-grid--case" : ""}${caseView && bookShelf ? " abs-card-grid--shelf" : ""}`}>
              {recent.map((item, i) => (
                <BookCard key={item.id} item={item} instanceId={instanceId} index={i} caseView={caseView} onSelect={setSelectedBook} />
              ))}
            </div>
          </>
        ) : null}
      </>
    );
  }

  return (
    <div className="hd-widget-body abs-body-flat" ref={rootRef}>
      <ConnectionCorner source={connectionSource || "unknown"} />
      <div className="abs-shell">
        <div className="abs-toolbar">
          <div className="abs-toolbar-left">
            <span className={`abs-status-pill ${isOnline ? "abs-status-pill--ok" : "abs-status-pill--offline"}`}>
              <span className="abs-status-dot" aria-hidden="true" />
              {isOnline ? "Online" : "Offline"}
            </span>
          </div>
          <div className="abs-toolbar-right">
            {href ? (
              <a className="abs-open-btn" href={href} target="_blank" rel="noopener noreferrer">
                Open
              </a>
            ) : null}
          </div>
        </div>

        <div className="abs-controls">
          <div className="abs-tabs" role="tablist">
            {TABS.map((t) => (
              <button
                key={t.key}
                type="button"
                role="tab"
                className={`abs-tab${tab === t.key ? " abs-tab--active" : ""}`}
                aria-selected={tab === t.key}
                onClick={() => setTab(t.key)}
              >
                <span>{t.label}</span>
              </button>
            ))}
          </div>
        </div>

        {libraries.length ? (
          <div className="abs-lib-switcher">
            <div className="abs-section-label">Libraries</div>
            <div className="abs-lib-grid">
              {libraries.map((lib) => (
                <button
                  key={lib.id}
                  type="button"
                  className={`abs-lib-card abs-lib-card--btn${libraryId === lib.id ? " abs-lib-card--active" : ""}`}
                  aria-pressed={libraryId === lib.id}
                  onClick={() => setLibraryId(lib.id)}
                >
                  <div className="abs-lib-name">{lib.name}</div>
                  <div className="abs-lib-meta">
                    {lib.mediaType || "library"}
                    {lib.totalItems != null ? ` · ${lib.totalItems.toLocaleString()} items` : ""}
                  </div>
                </button>
              ))}
            </div>
          </div>
        ) : null}

        <div className="abs-panel">{renderBody()}</div>
        {error && data ? <div className="abs-empty">{error}</div> : null}
      </div>
      {selectedBook && typeof document !== "undefined" ? createPortal((
        <div className="abs-book-modal" role="dialog" aria-modal="true" aria-label={`Details for ${selectedBook.title}`} onMouseDown={(event) => {
          if (event.target === event.currentTarget) setSelectedBook(null);
        }}>
          <div className="abs-book-modal__book">
            <button className="abs-book-modal__close" type="button" onClick={() => setSelectedBook(null)} aria-label="Close book details">×</button>
            <div className="abs-book-modal__cover" aria-hidden="true">
              <div className="abs-book-modal__binding">
                <span className="abs-book-modal__binding-title">{selectedBook.title}</span>
                {selectedBook.author ? <span className="abs-book-modal__binding-author">{selectedBook.author}</span> : null}
              </div>
            </div>
            <div className="abs-book-modal__pages">
              <div className="abs-book-modal__eyebrow">Book details</div>
              <h2>{selectedBook.title}</h2>
              {selectedBook.author ? <div className="abs-book-modal__author">by {selectedBook.author}</div> : null}
              <div className="abs-book-modal__facts">
                {selectedBook.series ? <span>{selectedBook.series}</span> : null}
                {selectedBook.narrator ? <span>Narrated by {selectedBook.narrator}</span> : null}
                {selectedBook.publishedYear ? <span>{selectedBook.publishedYear}</span> : null}
                {selectedBook.duration ? <span>{fmtDuration(selectedBook.duration)}</span> : null}
              </div>
              <div className="abs-book-modal__synopsis">
                {selectedBook.synopsis || "No synopsis is available for this title."}
              </div>
              {selectedBook.genres?.length ? <div className="abs-book-modal__genres">{selectedBook.genres.slice(0, 5).map((genre) => <span key={genre}>{genre}</span>)}</div> : null}
              <a className="abs-book-modal__open" href={resolveOpenHref(selectedBook.href, selectedBook.openFallbackUrl)} target="_blank" rel="noopener noreferrer">Open in Audiobookshelf</a>
            </div>
          </div>
        </div>
      ), document.body) : null}
    </div>
  );
}
