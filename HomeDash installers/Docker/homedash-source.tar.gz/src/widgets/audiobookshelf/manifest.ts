import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "audiobookshelf",
  name: "Audiobookshelf",
  description: "Libraries, continue listening, recent titles, and now playing",
  version: "0.2.9",
  category: "Media",
  defaultSize: { w: 5, h: 5, minW: 3, minH: 3 },
  hostClass: "abs-widget-host",
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "http://10.0.0.1:13378",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      placeholder: "https://audiobookshelf.example.com",
    },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url", placeholder: "http://10.0.0.1:13378" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    {
      key: "pathPrefix",
      label: "Path prefix",
      type: "text",
      placeholder: "/audiobookshelf",
    },
    {
      key: "apiKey",
      label: "API token",
      type: "password",
      required: true,
    },
    { key: "caseView", label: "Case View", type: "checkbox" },
    { key: "bookShelf", label: "Shelf", type: "checkbox" },
  ],
};
