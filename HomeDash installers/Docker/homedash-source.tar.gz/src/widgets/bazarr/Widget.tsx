import "@/styles/widgets/bazarr.widget.css";
import "@/styles/widgets/arr.widgets.css";

import { ApiWidget } from "../_shared/ApiWidget";
export default function BazarrWidget() { return <ApiWidget id="bazarr" name="Bazarr" prefix="bzr" />; }
