import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "bazarr",
  name: "Bazarr",
  description: "Subtitle management",
  version: "0.1.0",
  category: "Media",
  defaultSize: { w: 4, h: 4, minW: 2, minH: 2 },
  hostClass: "bzr-host",
  configFields: [
  {
    "key": "baseUrl",
    "label": "Private - IP",
    "type": "url",
    "placeholder": "http://10.0.0.1:6767"
  },
  {
    "key": "fallbackUrl",
    "label": "Fallback Public URL",
    "type": "url",
    "placeholder": "https://bazarr.example.com"
  },
  {
    "key": "publicUrl",
    "label": "OPEN - Private URL",
    "type": "url",
    "placeholder": "http://10.0.0.1:6767"
  },
  {
    "key": "openFallbackUrl",
    "label": "OPEN - Public URL",
    "type": "url",
    "placeholder": "https://… (Cloudflare)"
  },
  {
    "key": "apiKey",
    "label": "API Key",
    "type": "password",
    "required": true
  }
],
};
