"use client";
import "@/styles/widgets/bookmark.shortcuts.widget.css";


import { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "../_shared/instance-context";
import type { BookmarkItem } from "@/lib/types";
import { formatBookmarksWidgetTitle } from "@/lib/bookmarks";

function ipSuffix(ip?: string) {
  if (!ip) return "";
  const trimmed = ip.trim();
  if (trimmed.startsWith(".")) return trimmed;
  if (trimmed === "0.0.0.0") return "";
  const parts = trimmed.split(".");
  if (parts.length === 4) return `.${parts[3]}`;
  return trimmed;
}

function resolveLocalUrl(item: BookmarkItem) {
  const local = item.localUrl?.trim();
  if (local) return local;
  const ip = item.ip?.trim();
  if (ip && ip !== "0.0.0.0") return `http://${ip}`;
  return "";
}

function resolvePublicUrl(item: BookmarkItem) {
  return item.publicUrl?.trim() || "";
}

function looksLikeTunnel(url: string) {
  if (!url) return false;
  try {
    const host = new URL(url).hostname;
    return Boolean(host) && !/^\d{1,3}(\.\d{1,3}){3}$/.test(host);
  } catch {
    return true;
  }
}

export default function Widget() {
  const instance = useWidgetInstance();
  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>([]);
  const [query, setQuery] = useState("");
  const [groupName, setGroupName] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState<BookmarkItem | null>(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    let alive = true;
    setLoading(true);
    fetch(`/api/widgets/bookmarks/status?instance=${encodeURIComponent(instance?.instanceId || "bookmarks")}`)
      .then(async (res) => {
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.error || "Failed to load bookmarks");
        return data;
      })
      .then((data) => {
        if (!alive) return;
        setBookmarks(Array.isArray(data.bookmarks) ? data.bookmarks : []);
        setGroupName(typeof data.groupName === "string" ? data.groupName : "");
        setError("");
      })
      .catch((err) => {
        if (!alive) return;
        setError(err instanceof Error ? err.message : "Failed to load bookmarks");
        setBookmarks([]);
        setGroupName("");
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [instance?.instanceId]);

  useEffect(() => {
    if (!active) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setActive(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [active]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return bookmarks;
    return bookmarks.filter((item) => {
      const hay = [item.name, item.ip, item.localUrl, item.publicUrl, item.category]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();
      return hay.includes(q);
    });
  }, [bookmarks, query]);

  const showSearch = bookmarks.length > 6;

  useEffect(() => {
    if (!showSearch && query) setQuery("");
  }, [showSearch, query]);

  const localHref = active ? resolveLocalUrl(active) : "";
  const publicHref = active ? resolvePublicUrl(active) : "";
  const showIp =
    Boolean(active?.ip?.trim()) && active?.ip?.trim() !== "0.0.0.0";
  const showLocal = Boolean(localHref);
  const showTunnel =
    Boolean(publicHref) &&
    looksLikeTunnel(publicHref) &&
    publicHref !== localHref;

  return (
    <div className="hd-widget-body bmark-body-flat">
      <div className="bmark-shell">
        <div className={`bmark-toolbar${showSearch ? "" : " bmark-toolbar--no-search"}`}>
          <div className="bmark-toolbar-left">
            <span className="bmark-title">
              {formatBookmarksWidgetTitle(groupName || undefined)}
            </span>
            <span className="bmark-count">
              {filtered.length}
              {query.trim() && filtered.length !== bookmarks.length ? ` / ${bookmarks.length}` : ""}{" "}
              link{filtered.length === 1 ? "" : "s"}
            </span>
          </div>
          {showSearch ? (
            <input
              className="bmark-search"
              type="search"
              placeholder="Search bookmarks…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              aria-label="Search bookmarks"
            />
          ) : null}
        </div>

        {loading ? <div className="bmark-empty">Loading…</div> : null}
        {error ? <div className="bmark-empty bmark-empty--err">{error}</div> : null}

        {!loading && !error && !filtered.length ? (
          <div className="bmark-empty">
            {bookmarks.length
              ? "No bookmarks match that search."
              : "Add bookmarks in Settings → BookMarks."}
          </div>
        ) : null}

        {!loading && filtered.length ? (
          <div className="bmark-host-grid">
            {filtered.map((item) => {
              const hasTunnel = looksLikeTunnel(resolvePublicUrl(item));
              return (
                <button
                  className="bmark-host-card"
                  type="button"
                  key={item.id}
                  title={item.publicUrl || item.localUrl || item.ip || item.name}
                  onClick={() => setActive(item)}
                >
                  {hasTunnel ? (
                    <div className="bmark-host-cf" title="Cloudflare tunnel available">
                      ☁
                    </div>
                  ) : null}
                  <div className="bmark-host-icon">
                    {item.icon ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={item.icon} alt="" loading="lazy" />
                    ) : (
                      <span>{item.name.slice(0, 1).toUpperCase()}</span>
                    )}
                  </div>
                  <div className="bmark-host-name">{item.name}</div>
                  {item.ip ? <div className="bmark-host-ip">{ipSuffix(item.ip)}</div> : null}
                  {item.category ? <div className="bmark-host-role">{item.category}</div> : null}
                  <div className="bmark-host-dot" aria-hidden />
                </button>
              );
            })}
          </div>
        ) : null}
      </div>

      {mounted && active
        ? createPortal(
            <div
              className="bmark-modal-overlay is-open"
              role="presentation"
              onClick={() => setActive(null)}
            >
              <div
                className="bmark-modal"
                role="dialog"
                aria-modal="true"
                aria-label={active.name}
                onClick={(event) => event.stopPropagation()}
              >
                <button
                  className="bmark-modal-close"
                  type="button"
                  aria-label="Close"
                  onClick={() => setActive(null)}
                >
                  ✕
                </button>
                <div className="bmark-modal-icon">
                  {active.icon ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={active.icon} alt="" />
                  ) : (
                    <span>{active.name.slice(0, 1).toUpperCase()}</span>
                  )}
                </div>
                <div className="bmark-modal-name">{active.name}</div>
                {active.category ? <div className="bmark-modal-role">{active.category}</div> : null}
                {showIp ? (
                  <div className="bmark-modal-rows">
                    <div className="bmark-modal-row">
                      <span className="bmark-modal-label">IP Address</span>
                      <span className="bmark-modal-value">{active.ip}</span>
                    </div>
                  </div>
                ) : (
                  <div className="bmark-modal-spacer" />
                )}
                <div className="bmark-modal-btns">
                  {showLocal ? (
                    <a
                      className="bmark-modal-btn bmark-modal-btn--local"
                      href={localHref}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => setActive(null)}
                    >
                      🏠 Local IP
                    </a>
                  ) : null}
                  {showTunnel ? (
                    <a
                      className="bmark-modal-btn bmark-modal-btn--tunnel"
                      href={publicHref}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => setActive(null)}
                    >
                      ☁️ Public URL
                    </a>
                  ) : null}
                  {!showLocal && !showTunnel && publicHref ? (
                    <a
                      className="bmark-modal-btn bmark-modal-btn--tunnel"
                      href={publicHref}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => setActive(null)}
                    >
                      Open
                    </a>
                  ) : null}
                </div>
              </div>
            </div>,
            document.body,
          )
        : null}
    </div>
  );
}
