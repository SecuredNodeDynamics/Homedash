import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "bookmarks",
  name: "Bookmarks",
  description: "Searchable shortcut grid from a Settings → BookMarks group",
  version: "0.3.0",
  category: "General",
  defaultSize: { w: 6, h: 8, minW: 3, minH: 4 },
  hostClass: "bmark-host",
  configFields: [
    {
      key: "groupId",
      label: "Bookmark group",
      type: "select",
      required: true,
      placeholder: "Select a group",
    },
  ],
};
