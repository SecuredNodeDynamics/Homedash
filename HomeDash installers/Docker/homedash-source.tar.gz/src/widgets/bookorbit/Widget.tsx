"use client";
import "@/styles/widgets/bookorbit.widget.css";


import { useCallback, useEffect, useRef, useState, type ReactNode, useLayoutEffect } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type TabKey = "overview" | "reading" | "recent" | "stats";

type Book = {
  id: string;
  title: string;
  author: string;
  progress: number | null;
  coverUrl?: string;
};

type BoConnectionSource = "private" | "public" | "unknown";

const CONNECTION_SOURCE_LABEL: Record<BoConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

function ConnectionCorner({ source }: { source: BoConnectionSource }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const mark = (
    <div
      className={`bo-corner-source bo-corner-source--${source}`}
      title={CONNECTION_SOURCE_LABEL[source]}
      aria-label={CONNECTION_SOURCE_LABEL[source]}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}


type StatusPayload = {
  href: string;
  openFallbackUrl?: string;
  connectionSource?: BoConnectionSource;
  tab: TabKey;
  books?: number | Book[];
  authors?: number;
  goalCompleted?: number;
  goalBooks?: number;
  dayStreak?: number;
  completed?: number;
  pages?: number;
  readingSeconds?: number;
  sessions?: number;
  readingCount?: number;
  reading?: Book[];
  error?: string;
};

const TABS: { key: TabKey; label: string }[] = [
  { key: "overview", label: "Overview" },
  { key: "reading", label: "Reading" },
  { key: "recent", label: "Recent" },
  { key: "stats", label: "Stats" },
];

const POLL_MS = 60_000;

function coverSrc(instanceId: string, book: Book) {
  if (book.coverUrl && /^https?:\/\//i.test(book.coverUrl)) return book.coverUrl;
  if (!book.id) return "";
  return `/api/widgets/bookorbit/cover?instance=${encodeURIComponent(instanceId)}&book=${encodeURIComponent(book.id)}`;
}

function fmtNum(n: number | null | undefined) {
  const v = Number(n || 0);
  return Number.isFinite(v) ? v.toLocaleString() : "0";
}

function fmtDuration(seconds: number | null | undefined) {
  const s = Number(seconds || 0);
  if (!Number.isFinite(s) || s <= 0) return "0m";
  const h = Math.floor(s / 3600);
  const m = Math.round((s % 3600) / 60);
  return h ? `${h}h ${m}m` : `${m}m`;
}

function goalPct(done: number, total: number) {
  if (!total) return 0;
  return Math.max(0, Math.min(100, Math.round((Number(done || 0) / Number(total)) * 100)));
}

function CoverArt({ src, alt }: { src: string; alt: string }) {
  const [missing, setMissing] = useState(!src);
  useEffect(() => {
    setMissing(!src);
  }, [src]);
  if (!src || missing) return <div className="bo-card-placeholder">BO</div>;
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img src={src} alt={alt} loading="lazy" decoding="async" onError={() => setMissing(true)} />
  );
}

function Skeleton() {
  return (
    <div className="bo-skeleton-wrap">
      {Array.from({ length: 4 }, (_, i) => (
        <div key={i} className="bo-skeleton-row" />
      ))}
    </div>
  );
}

function BookCard({
  book,
  index,
  href,
  instanceId,
}: {
  book: Book;
  index: number;
  href: string;
  instanceId: string;
}) {
  const link = book.id ? `${href.replace(/\/$/, "")}/book/${book.id}?tab=details` : href;
  const progress = book.progress;
  return (
    <a
      className="bo-card"
      href={link}
      target="_blank"
      rel="noopener noreferrer"
      style={{ animationDelay: `${index * 35}ms` }}
      title={book.title}
    >
      <div className="bo-card-art">
        <CoverArt src={coverSrc(instanceId, book)} alt={book.title} />
        {progress != null ? (
          <div className="bo-progress">
            <span style={{ width: `${progress}%` }} />
          </div>
        ) : null}
      </div>
      <div className="bo-card-meta">
        <div className="bo-card-title">{book.title}</div>
        {book.author ? <div className="bo-card-sub">{book.author}</div> : null}
      </div>
    </a>
  );
}

export default function BookOrbitWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "bookorbit";
  const [tab, setTab] = useState<TabKey>("overview");
  const [cache, setCache] = useState<Partial<Record<TabKey, StatusPayload>>>({});
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const tabRef = useRef(tab);
  const cacheRef = useRef(cache);
  tabRef.current = tab;
  cacheRef.current = cache;

  const data = cache[tab] || null;
  const rawHref = data?.href || Object.values(cache).find((v) => v?.href)?.href || "";
  const rawOpenFallbackUrl =
    data?.openFallbackUrl || Object.values(cache).find((v) => v?.openFallbackUrl)?.openFallbackUrl || "";
  const href = useOpenHref(rawHref, rawOpenFallbackUrl);
  const isOnline = Boolean(href || data) && !error;
  const connectionSource: BoConnectionSource =
    data?.connectionSource || Object.values(cache).find((v) => v?.connectionSource)?.connectionSource || "unknown";

  const load = useCallback(
    async (nextTab: TabKey = tabRef.current, opts?: { soft?: boolean; force?: boolean }) => {
      if (!opts?.force && !opts?.soft && cacheRef.current[nextTab]) {
        setLoading(false);
        setError("");
        return;
      }
      if (!opts?.soft) setLoading(true);
      try {
        const response = await fetch(
          `/api/widgets/bookorbit/status?instance=${encodeURIComponent(instanceId)}&tab=${encodeURIComponent(nextTab)}`,
        );
        const json = (await response.json()) as StatusPayload;
        if (!response.ok) throw new Error(json.error || "Failed to load BookOrbit");
        setCache((prev) => {
          const next = { ...prev, [nextTab]: json };
          cacheRef.current = next;
          return next;
        });
        setError("");
      } catch (cause) {
        setError(cause instanceof Error ? cause.message : "Failed to load BookOrbit");
      } finally {
        setLoading(false);
      }
    },
    [instanceId],
  );

  useEffect(() => {
    void load(tab, { force: !cacheRef.current[tab] });
  }, [tab, load]);

  const softPoll = useCallback(() => {
    void load(tabRef.current, { soft: true, force: true });
  }, [load]);
  const { rootRef } = useWidgetPoll(softPoll, { intervalMs: POLL_MS });

  function renderPanel(): ReactNode {
    if (loading && !data) return <Skeleton />;
    if (error && !data) return <div className="bo-error">{error}</div>;
    if (!data) return <Skeleton />;

    if (tab === "overview") {
      const goalBooks = data.goalBooks || 0;
      const goalCompleted = data.goalCompleted || 0;
      const reading = Array.isArray(data.reading) ? data.reading : [];
      const streak = data.dayStreak || 0;
      return (
        <div className="bo-overview">
          <div className="bo-stat-strip">
            <div className="bo-stat">
              <div className="bo-stat-num">{fmtNum(typeof data.books === "number" ? data.books : 0)}</div>
              <div className="bo-stat-label">Books</div>
            </div>
            <div className="bo-stat">
              <div className="bo-stat-num">{fmtNum(data.authors)}</div>
              <div className="bo-stat-label">Authors</div>
            </div>
            <div className="bo-stat">
              <div className="bo-stat-num">{fmtNum(data.completed ?? reading.length)}</div>
              <div className="bo-stat-label">Completed</div>
            </div>
            <div className="bo-stat">
              <div className="bo-stat-num">{streak > 0 ? fmtNum(streak) : fmtNum(data.readingCount ?? reading.length)}</div>
              <div className="bo-stat-label">{streak > 0 ? "Day Streak" : "In Progress"}</div>
            </div>
          </div>
          {goalBooks ? (
            <div className="bo-goal-row">
              <div className="bo-goal-meta">
                Goal {fmtNum(goalCompleted)}/{fmtNum(goalBooks)}
              </div>
              <div className="bo-goal">
                <span style={{ width: `${goalPct(goalCompleted, goalBooks)}%` }} />
              </div>
            </div>
          ) : null}
          {reading.length ? (
            <>
              <div className="bo-section-label">Currently Reading</div>
              <div className="bo-card-grid">
                {reading.map((book, index) => (
                  <BookCard
                    key={book.id || `${book.title}-${index}`}
                    book={book}
                    index={index}
                    href={href}
                    instanceId={instanceId}
                  />
                ))}
              </div>
            </>
          ) : (
            <div className="bo-muted">Nothing in progress — open Reading for your shelf</div>
          )}
        </div>
      );
    }

    if (tab === "stats") {
      return (
        <div className="bo-stats-grid">
          <div className="bo-stat-card">
            <div className="bo-stat-num">{fmtNum(data.completed)}</div>
            <div className="bo-stat-label">Completed</div>
          </div>
          <div className="bo-stat-card">
            <div className="bo-stat-num">{fmtNum(data.pages)}</div>
            <div className="bo-stat-label">Pages</div>
          </div>
          <div className="bo-stat-card">
            <div className="bo-stat-num">{fmtDuration(data.readingSeconds)}</div>
            <div className="bo-stat-label">Read Time</div>
          </div>
          <div className="bo-stat-card">
            <div className="bo-stat-num">{fmtNum(data.sessions)}</div>
            <div className="bo-stat-label">Sessions</div>
          </div>
        </div>
      );
    }

    const books = Array.isArray(data.books) ? data.books : [];
    if (!books.length) {
      return (
        <div className="bo-empty">
          {tab === "reading" ? "Nothing in progress" : "No recent books found"}
        </div>
      );
    }
    return (
      <div className="bo-card-grid">
        {books.map((book, index) => (
          <BookCard key={book.id || `${book.title}-${index}`} book={book} index={index} href={href} instanceId={instanceId} />
        ))}
      </div>
    );
  }

  return (
    <div className="hd-widget-body bo-body-flat" ref={rootRef}>
      <ConnectionCorner source={connectionSource} />
      <div className="bo-shell">
        <div className="bo-toolbar">
          <div className="bo-toolbar-left">
            <span className={`bo-status-pill ${isOnline ? "bo-status-pill--ok" : "bo-status-pill--warn"}`}>
              <span className="bo-status-dot" aria-hidden="true" />
              {isOnline ? "Online" : "Offline"}
            </span>
          </div>
          <div className="bo-toolbar-right">
            {href ? (
              <a className="bo-open-btn" href={href} target="_blank" rel="noopener noreferrer">
                Open
              </a>
            ) : null}
          </div>
        </div>

        <div className="bo-controls">
          <div className="bo-tabs" role="tablist">
            {TABS.map((item) => (
              <button
                key={item.key}
                className={`bo-tab${tab === item.key ? " bo-tab--active" : ""}`}
                type="button"
                role="tab"
                aria-selected={tab === item.key}
                onClick={() => setTab(item.key)}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>

        <div className="bo-panel">{renderPanel()}</div>
        {error && data ? <div className="bo-error">{error}</div> : null}
      </div>
    </div>
  );
}
