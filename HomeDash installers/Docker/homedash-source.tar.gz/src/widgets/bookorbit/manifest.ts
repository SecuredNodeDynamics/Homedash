import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "bookorbit",
  name: "BookOrbit",
  description: "Reading goals, continue reading, and library stats",
  version: "0.3.3",
  category: "Media",
  defaultSize: { w: 5, h: 5, minW: 3, minH: 3 },
  hostClass: "bo-widget-host",
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "http://10.0.0.1",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      required: false,
      placeholder: "https://bookorbit.example.com",
    },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url", placeholder: "http://10.0.0.1" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    {
      key: "username",
      label: "Username",
      type: "text",
      required: false,
    },
    {
      key: "password",
      label: "Password",
      type: "password",
      required: false,
    },
    {
      key: "apiKey",
      label: "API Key / Token",
      type: "password",
      required: false,
    },
  ],
};
