"use client";
import "@/styles/widgets/checkmk.widget.css";


import { useCallback, useState, type CSSProperties } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type Problem = {
  host: string;
  description: string;
  output: string;
  state: number;
  acknowledged: boolean;
  changed: number;
};

type Host = {
  name: string;
  state: number;
  acknowledged: boolean;
  address: string;
};

type Data = {
  href: string;
  openFallbackUrl?: string;
  hosts: { up: number; down: number; unreach: number; unknown: number; total: number };
  hostList: Host[];
  problems: Problem[];
  summary: { warn: number; crit: number; unknown: number };
};

const COLORS = ["#6ee7b7", "#fbbf24", "#f87171", "#a78bfa"];
const NAMES = ["OK", "WARN", "CRIT", "UNKNOWN"];
const HOST_STATE = [
  { label: "UP", color: "#6ee7b7", bg: "rgba(110,231,183,0.06)", border: "rgba(110,231,183,0.18)" },
  { label: "DOWN", color: "#f87171", bg: "rgba(248,113,113,0.06)", border: "rgba(248,113,113,0.18)" },
  { label: "UNREACH", color: "#fb923c", bg: "rgba(251,146,60,0.06)", border: "rgba(251,146,60,0.18)" },
  { label: "UNKNOWN", color: "#a78bfa", bg: "rgba(167,139,250,0.06)", border: "rgba(167,139,250,0.18)" },
] as const;

function timeAgo(stamp: number) {
  if (!stamp) return "";
  const seconds = Math.max(0, Math.floor(Date.now() / 1000 - stamp));
  if (seconds < 60) return `${seconds}s ago`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
}

function HostCard({ host }: { host: Host }) {
  const meta = HOST_STATE[host.state] || HOST_STATE[3];
  const down = host.state !== 0;
  return (
    <div
      className={`cmk-host-card${down ? " cmk-host-card--down" : " cmk-host-card--up"}`}
      style={
        {
          ["--hc-bg" as string]: meta.bg,
          ["--hc-border" as string]: meta.border,
          ["--hc-color" as string]: meta.color,
        } as CSSProperties
      }
      title={[host.name, host.address, meta.label, host.acknowledged ? "acked" : ""]
        .filter(Boolean)
        .join(" · ")}
    >
      <div className="cmk-host-card-icon" aria-hidden>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <rect x="2" y="3" width="20" height="14" rx="2" />
          <line x1="8" y1="21" x2="16" y2="21" />
          <line x1="12" y1="17" x2="12" y2="21" />
        </svg>
      </div>
      <div className="cmk-host-card-info">
        <div className="cmk-host-card-name">{host.name}</div>
        <div className="cmk-host-card-meta">
          {host.address ? <span className="cmk-host-card-addr">{host.address}</span> : null}
          <span className="cmk-host-card-state">
            {meta.label}
            {host.acknowledged ? " ✓" : ""}
          </span>
        </div>
      </div>
      <span className={`cmk-host-card-status${down ? "" : " cmk-host-card-status--on"}`} aria-label={meta.label} />
    </div>
  );
}

export default function CheckmkWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "checkmk";
  const [data, setData] = useState<Data | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);

  const load = useCallback(async () => {
    try {
      const response = await fetch(
        `/api/widgets/checkmk/status?instance=${encodeURIComponent(instanceId)}`,
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load Checkmk");
      setData(json);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Checkmk unavailable");
    } finally {
      setLoading(false);
    }
  }, [instanceId]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: 120_000 });

  if (loading && !data) {
    return (
      <div className="hd-widget-body cmk-body" ref={rootRef}>
        <div className="cmk-toolbar">
          <span className="cmk-status-pill cmk-status-pill--loading">
            <span className="cmk-status-dot" />
            Loading
          </span>
        </div>
        <div className="cmk-skeleton-wrap">
          <div className="cmk-skeleton-row" />
          <div className="cmk-skeleton-row" />
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="hd-widget-body cmk-body" ref={rootRef}>
        <div className="cmk-toolbar">
          <span className="cmk-status-pill cmk-status-pill--offline">
            <span className="cmk-status-dot" />
            Offline
          </span>
          <button className="cmk-open-link" type="button" onClick={load}>
            Retry
          </button>
        </div>
        <div className="cmk-error">
          <b>CheckMK Unavailable</b>
          <div>{error}</div>
        </div>
      </div>
    );
  }

  const healthy = data.hosts.down === 0 && data.hosts.unreach === 0 && !data.summary.crit;
  const overallColor = healthy ? COLORS[0] : data.summary.crit ? COLORS[2] : COLORS[1];
  const healthPct = data.hosts.total ? Math.round((data.hosts.up / data.hosts.total) * 100) : 0;
  const hostCards = [...(data.hostList || [])]
    .sort((a, b) => a.state - b.state || a.name.localeCompare(b.name))
    .slice(0, 24);

  return (
    <div className="hd-widget-body cmk-body" ref={rootRef}>
      <div className="cmk-toolbar">
        <span className="cmk-status-pill cmk-status-pill--online">
          <span className="cmk-status-dot" />
          Online
        </span>
        <div className="cmk-toolbar-right">
          <a className="cmk-open-link" href={openHref} target="_blank" rel="noopener noreferrer">
            Open
          </a>
        </div>
      </div>

      <div className="cmk-host-overview">
        <div className="cmk-host-summary">
          <div className="cmk-host-big">
            <span className="cmk-host-num" style={{ color: overallColor }}>
              {data.hosts.up}
            </span>
            <span className="cmk-host-denom">/ {data.hosts.total}</span>
          </div>
          <div className="cmk-host-label">Hosts UP</div>
          <div className="cmk-host-bar-wrap">
            <div
              className="cmk-host-bar-fill"
              style={{ width: `${healthPct}%`, background: overallColor }}
            />
          </div>
        </div>
        <div className="cmk-host-pills">
          {(
            [
              ["up", data.hosts.up, COLORS[0]],
              ["down", data.hosts.down, COLORS[2]],
              ["unreach", data.hosts.unreach, "#fb923c"],
              ["unknown", data.hosts.unknown, COLORS[3]],
            ] as const
          ).map(([key, value, color]) => (
            <div className="cmk-stat-pill" key={key}>
              <span className="cmk-stat-dot" style={{ background: color }} />
              <span className="cmk-stat-num" style={{ color }}>
                {value}
              </span>
              <span className="cmk-stat-lbl">{key}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="cmk-main-grid">
        <div className="cmk-hosts-col">
          {hostCards.length ? (
            <>
              <div className="cmk-hosts-label">
                Hosts
                <span className="cmk-hosts-count">{data.hosts.total} total</span>
              </div>
              <div className="cmk-host-grid">
                {hostCards.map((host) => (
                  <HostCard host={host} key={host.name} />
                ))}
              </div>
            </>
          ) : null}
        </div>

        <div className="cmk-divider" />

        <div className="cmk-svc-panel">
          <div className="cmk-svc-header">
            <span className="cmk-section-label">Service problems</span>
            <div className="cmk-svc-chips">
              {data.problems.length ? (
                <>
                  {data.summary.crit ? (
                    <span className="cmk-chip" style={{ color: COLORS[2], borderColor: `${COLORS[2]}40` }}>
                      {data.summary.crit} CRIT
                    </span>
                  ) : null}
                  {data.summary.warn ? (
                    <span className="cmk-chip" style={{ color: COLORS[1], borderColor: `${COLORS[1]}40` }}>
                      {data.summary.warn} WARN
                    </span>
                  ) : null}
                  {data.summary.unknown ? (
                    <span className="cmk-chip" style={{ color: COLORS[3], borderColor: `${COLORS[3]}40` }}>
                      {data.summary.unknown} UNKN
                    </span>
                  ) : null}
                </>
              ) : (
                <span className="cmk-chip" style={{ color: COLORS[0], borderColor: `${COLORS[0]}40` }}>
                  All OK
                </span>
              )}
            </div>
          </div>

          <div className="cmk-svc-list">
            {data.problems.length ? (
              data.problems.map((problem) => (
                <div className="cmk-svc-row" key={`${problem.host}-${problem.description}`}>
                  <div className="cmk-svc-left">
                    <span className="cmk-svc-dot" style={{ background: COLORS[problem.state] || COLORS[3] }} />
                    <div className="cmk-svc-body">
                      <div className="cmk-svc-title">
                        {problem.host} — {problem.description}
                        {problem.acknowledged ? " ✓" : ""}
                      </div>
                      {problem.output ? <div className="cmk-svc-output">{problem.output}</div> : null}
                    </div>
                  </div>
                  <div className="cmk-svc-right">
                    <span
                      className="cmk-svc-chip"
                      style={{
                        color: COLORS[problem.state] || COLORS[3],
                        borderColor: `${COLORS[problem.state] || COLORS[3]}40`,
                      }}
                    >
                      {NAMES[problem.state] || "UNKNOWN"}
                    </span>
                    {problem.changed ? (
                      <span className="cmk-svc-when">{timeAgo(problem.changed)}</span>
                    ) : null}
                  </div>
                </div>
              ))
            ) : (
              <div className="cmk-all-ok">
                <div className="cmk-all-ok-icon">✓</div>
                <div className="cmk-all-ok-label">All services OK</div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
