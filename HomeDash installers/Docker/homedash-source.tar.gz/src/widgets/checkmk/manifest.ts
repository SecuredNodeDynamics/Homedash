import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "checkmk",
  name: "Checkmk",
  description: "Host and service monitoring overview",
  version: "0.2.2",
  category: "Infra",
  defaultSize: { w: 5, h: 6, minW: 3, minH: 4 },
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "https://10.0.0.1",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      placeholder: "https://checkmk.example.com",
    },
    {
      key: "publicUrl",
      label: "OPEN - Private URL",
      type: "url",
      placeholder: "https://10.0.0.1",
    },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    {
      key: "siteName",
      label: "Site name",
      type: "text",
      placeholder: "monitoring",
    },
    { key: "username", label: "Username", type: "text", required: true },
    { key: "password", label: "Password / secret", type: "password", required: true },
  ],
};
