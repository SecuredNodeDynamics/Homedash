"use client";

import { useEffect, useState } from "react";

export default function ClockWidget() {
  const [now, setNow] = useState<Date | null>(null);

  useEffect(() => {
    setNow(new Date());
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  const time = now
    ? now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })
    : "––:––:––";
  const date = now
    ? now.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" })
    : "\u00a0";

  return (
    <div className="hd-widget-body hd-widget-body--center">
      <div className="hd-clock-time" suppressHydrationWarning>
        {time}
      </div>
      <div className="hd-clock-date" suppressHydrationWarning>
        {date}
      </div>
    </div>
  );
}
