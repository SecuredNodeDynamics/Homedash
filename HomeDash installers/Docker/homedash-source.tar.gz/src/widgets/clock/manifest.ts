import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "clock",
  name: "Clock",
  description: "Live local time and date",
  version: "0.1.0",
  category: "System",
  hostClass: "hd-system-host",
  defaultSize: { w: 4, h: 3, minW: 2, minH: 2 },
  configFields: [],
};
