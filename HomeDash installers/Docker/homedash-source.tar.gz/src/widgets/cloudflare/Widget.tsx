"use client";
import "@/styles/widgets/cloudflare.widget.css";


import { useCallback, useState } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type Analytics = {
  requests: number;
  bytes: number;
  cachedRequests: number;
  uniques: number;
  threats: number;
  threatTypes: Array<{ name: string; count: number }>;
  threatCountries?: Array<{ name: string; count: number }>;
  hostBreakdown?: Array<{ host: string; requests: number }>;
};

type Status = {
  dashboardUrl: string;
  tunnel: { name: string; status: string; createdAt: string | null };
  connections: Array<{ id: string; name: string; active: boolean }>;
  zones: Array<{ id: string; name: string; active: boolean; analytics: Analytics | null }>;
};

function big(value: number) {
  if (value >= 1e9) return `${(value / 1e9).toFixed(2)}B`;
  if (value >= 1e6) return `${(value / 1e6).toFixed(1)}M`;
  if (value >= 1e3) return `${(value / 1e3).toFixed(0)}K`;
  return value.toLocaleString();
}

function bytes(value: number) {
  if (value >= 1e12) return `${(value / 1e12).toFixed(2)} TB`;
  if (value >= 1e9) return `${(value / 1e9).toFixed(2)} GB`;
  if (value >= 1e6) return `${(value / 1e6).toFixed(1)} MB`;
  if (value >= 1e3) return `${(value / 1e3).toFixed(0)} KB`;
  return `${value} B`;
}

function statusClass(status: string) {
  const normalized = status.toLowerCase();
  if (normalized === "healthy") return "healthy";
  if (normalized === "degraded") return "degraded";
  if (normalized === "down" || normalized === "inactive") return normalized;
  return "unknown";
}

function securityEventsHref(accountIdOrDash: string, zoneName?: string) {
  if (!zoneName) return accountIdOrDash;
  try {
    const url = new URL(accountIdOrDash);
    const parts = url.pathname.split("/").filter(Boolean);
    const accountId = parts[0];
    if (!accountId) return accountIdOrDash;
    return `https://dash.cloudflare.com/${encodeURIComponent(accountId)}/${encodeURIComponent(zoneName)}/security/events`;
  } catch {
    return accountIdOrDash;
  }
}

function Stat({
  label,
  value,
  sub,
  good = false,
}: {
  label: string;
  value: string;
  sub?: string;
  good?: boolean;
}) {
  return (
    <div className="cf-stat">
      <div className="cf-stat__label">{label}</div>
      <div className={`cf-stat__value${good ? " cf-stat__value--good" : ""}`}>{value}</div>
      {sub ? <div className="cf-stat__sub">{sub}</div> : null}
    </div>
  );
}

export default function CloudflareWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "cloudflare";
  const [data, setData] = useState<Status | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<"overview" | "requests">("overview");

  const load = useCallback(
    async (manual = false) => {
      if (!manual) setLoading(true);
      try {
        const response = await fetch(
          `/api/widgets/cloudflare/status?instance=${encodeURIComponent(instanceId)}`,
          { cache: "no-store", signal: AbortSignal.timeout(28_000) },
        );
        const json = await response.json();
        if (!response.ok) throw new Error(json.error || "Failed to load Cloudflare");
        setData(json);
        setError("");
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to load Cloudflare");
      } finally {
        setLoading(false);
      }
    },
    [instanceId],
  );

  const { rootRef } = useWidgetPoll(load, { intervalMs: 60_000 });

  if (!data && loading) {
    return (
      <div className="hd-widget-body cf-body" ref={rootRef}>
        <div className="cf-toolbar">
          <span className="cf-status-text">Loading…</span>
        </div>
        <div className="cf-skeleton-line" style={{ width: "55%", height: 16 }} />
        <div className="cf-skeleton-line" style={{ height: 88 }} />
        <div className="cf-skeleton-line" style={{ height: 88 }} />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="hd-widget-body cf-body" ref={rootRef}>
        <div className="cf-toolbar">
          <span className="cf-status-text">Offline</span>
          <button className="cf-refresh-btn" type="button" onClick={() => load(true)} aria-label="Retry">
            Retry
          </button>
        </div>
        <div className="cf-error">
          <div>Cloudflare Unavailable</div>
          <div>{error}</div>
        </div>
      </div>
    );
  }

  const analytics = data.zones
    .map((zone) => zone.analytics)
    .filter((value): value is Analytics => value !== null);
  const totals = analytics.reduce(
    (total, value) => ({
      requests: total.requests + value.requests,
      bytes: total.bytes + value.bytes,
      cached: total.cached + value.cachedRequests,
      uniques: total.uniques + value.uniques,
      threats: total.threats + value.threats,
    }),
    { requests: 0, bytes: 0, cached: 0, uniques: 0, threats: 0 },
  );
  const threatTypes = Object.entries(
    analytics
      .flatMap((value) => value.threatTypes)
      .reduce<Record<string, number>>((result, item) => {
        result[item.name] = (result[item.name] || 0) + item.count;
        return result;
      }, {}),
  )
    .sort(([, a], [, b]) => b - a)
    .slice(0, 6);
  const threatCountries = Object.entries(
    analytics
      .flatMap((value) => value.threatCountries || [])
      .reduce<Record<string, number>>((result, item) => {
        result[item.name] = (result[item.name] || 0) + item.count;
        return result;
      }, {}),
  )
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5);
  if (totals.threats > 0 && !threatTypes.length) {
    threatTypes.push(["Blocked / mitigated", totals.threats]);
  }

  const hostTotals = new Map<string, { requests: number; zoneName: string }>();
  for (const zone of data.zones) {
    const breakdown = zone.analytics?.hostBreakdown || [];
    for (const item of breakdown) {
      const existing = hostTotals.get(item.host);
      if (existing) existing.requests += item.requests;
      else hostTotals.set(item.host, { requests: item.requests, zoneName: zone.name });
    }
  }
  const topHosts = Array.from(hostTotals.entries())
    .map(([host, info]) => ({ host, requests: info.requests, zoneName: info.zoneName }))
    .sort((a, b) => b.requests - a.requests)
    .slice(0, 15);
  const topHostsMax = topHosts.reduce((max, item) => Math.max(max, item.requests), 0);

  const activeConnectors = data.connections.filter((connection) => connection.active).length;
  const badge = statusClass(data.tunnel.status);
  const cacheRate = totals.requests
    ? `${((totals.cached / totals.requests) * 100).toFixed(1)}%`
    : "—";
  const primaryZone =
    data.zones.find((zone) => (zone.analytics?.threats || 0) > 0) || data.zones[0];
  const eventsHref = securityEventsHref(data.dashboardUrl, primaryZone?.name);

  return (
    <div className="hd-widget-body cf-body" ref={rootRef}>
      <div className="cf-toolbar">
        <div className={`cf-status-badge cf-status-badge--${badge}`}>
          <span className="cf-status-dot" />
          {data.tunnel.status}
        </div>
        <div className="cf-toolbar-right">
          <a className="cf-open-link" href={data.dashboardUrl} target="_blank" rel="noopener noreferrer">
            Open
          </a>
        </div>
      </div>

      <div className="cf-tabs" role="tablist">
        <button
          type="button"
          role="tab"
          className={`cf-tab${tab === "overview" ? " cf-tab--active" : ""}`}
          aria-selected={tab === "overview"}
          onClick={() => setTab("overview")}
        >
          Overview
        </button>
        <button
          type="button"
          role="tab"
          className={`cf-tab${tab === "requests" ? " cf-tab--active" : ""}`}
          aria-selected={tab === "requests"}
          onClick={() => setTab("requests")}
        >
          Top Requests
        </button>
      </div>

      <div className="cf-grid">
        <Stat label="Zones" value={String(data.zones.length)} sub="managed" good={data.zones.length > 0} />
        <Stat
          label="Requests 24h"
          value={analytics.length ? big(totals.requests) : "N/A"}
          sub="all zones"
          good={totals.requests > 0}
        />
        <Stat
          label="Bandwidth 24h"
          value={analytics.length ? bytes(totals.bytes) : "N/A"}
          sub="all zones"
        />
        <Stat
          label="Cache Rate"
          value={analytics.length ? cacheRate : "N/A"}
          sub="of requests"
          good={totals.cached > 0}
        />
        <Stat
          label="Unique IPs 24h"
          value={analytics.length ? big(totals.uniques) : "N/A"}
          sub="visitors"
        />
        <Stat
          label="Connections"
          value={String(activeConnectors)}
          sub={`${data.connections.length} total edges`}
          good={activeConnectors > 0}
        />
        <Stat
          label="Tunnel Created"
          value={
            data.tunnel.createdAt
              ? new Date(data.tunnel.createdAt).toLocaleDateString()
              : "—"
          }
        />
      </div>

      {tab === "overview" ? (
        <>
          <div className="cf-connections">
            {data.connections.length ? (
              data.connections.map((connection) => (
                <div className="cf-conn" key={connection.id}>
                  <span
                    className={`cf-conn__dot cf-conn__dot--${connection.active ? "active" : "inactive"}`}
                  />
                  {connection.name}
                </div>
              ))
            ) : (
              <div className="cf-conn">No connections recorded</div>
            )}
          </div>

          <section className="cf-threats">
            <div className="cf-threats__header">
              <div className="cf-threats__title">Managed Zones</div>
              <span className="cf-threats__count">{data.zones.length}</span>
            </div>
            <div className="cf-threat-list">
              {data.zones.length ? (
                data.zones.map((zone) => {
                  const reqs = zone.analytics?.requests;
                  const cached = zone.analytics?.cachedRequests;
                  const zoneCache =
                    reqs && cached != null ? ` · ${((cached / reqs) * 100).toFixed(1)}% cached` : "";
                  return (
                    <div className="cf-threat-row" key={zone.id}>
                      <span className="cf-threat-row__name">
                        <span
                          style={{
                            color: zone.active ? "rgba(251,146,60,.9)" : "rgba(248,113,113,.9)",
                          }}
                        >
                          ●{" "}
                        </span>
                        {zone.name}
                      </span>
                      <span>
                        {zone.analytics ? `${big(zone.analytics.requests)} req/24h${zoneCache}` : "N/A"}
                      </span>
                    </div>
                  );
                })
              ) : (
                <div className="cf-stat__sub">No zones found — check Zone:Read on the proxy token</div>
              )}
            </div>
          </section>

          <div className="cf-scroll">
            <section className={`cf-threats${totals.threats ? " cf-threats--has-threats" : ""}`}>
              <div className="cf-threats__header">
                <div className="cf-threats__title">Security Threats (24h)</div>
                <span
                  className={`cf-threats__count${totals.threats ? " cf-threats__count--has-threats" : ""}`}
                >
                  {totals.threats.toLocaleString()}
                </span>
              </div>
              {totals.threats ? (
                <>
                  <div className="cf-threat-list">
                    {threatTypes.map(([name, count]) => (
                      <div className="cf-threat-row" key={name}>
                        <span className="cf-threat-row__name">{name}</span>
                        <span className="cf-threat-row__count">{count.toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                  {threatCountries.length ? (
                    <>
                      <div className="cf-threats__subtitle">Top countries</div>
                      <div className="cf-threat-list">
                        {threatCountries.map(([name, count]) => (
                          <div className="cf-threat-row" key={name}>
                            <span className="cf-threat-row__name">{name}</span>
                            <span className="cf-threat-row__count">{count.toLocaleString()}</span>
                          </div>
                        ))}
                      </div>
                    </>
                  ) : null}
                  <a
                    className="cf-threats__link"
                    href={eventsHref}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    View security events
                  </a>
                </>
              ) : (
                <div className="cf-stat__sub">No threats detected</div>
              )}
            </section>
          </div>
        </>
      ) : (
        <div className="cf-scroll">
          <section className="cf-threats">
            <div className="cf-threats__header">
              <div className="cf-threats__title">Top Requests by Host (24h)</div>
              <span className="cf-threats__count">{topHosts.length}</span>
            </div>
            <div className="cf-threat-list">
              {topHosts.length ? (
                topHosts.map((item, index) => (
                  <div className="cf-threat-row cf-threat-row--bar" key={item.host}>
                    <span className="cf-threat-row__rank">{index + 1}</span>
                    <span className="cf-threat-row__name" title={item.zoneName}>
                      {item.host}
                    </span>
                    <span className="cf-threat-row__count">{big(item.requests)} req</span>
                    <div
                      className="cf-threat-row__bar"
                      style={{
                        width: topHostsMax ? `${Math.max(4, (item.requests / topHostsMax) * 100)}%` : "0%",
                      }}
                    />
                  </div>
                ))
              ) : (
                <div className="cf-stat__sub">
                  No per-host request data yet — this fills in once zones with traffic have been
                  polled at least once.
                </div>
              )}
            </div>
          </section>
        </div>
      )}
    </div>
  );
}
