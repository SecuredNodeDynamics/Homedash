import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "cloudflare",
  name: "Cloudflare",
  description: "Tunnel, zones, and edge analytics",
  version: "0.2.0",
  category: "Network",
  defaultSize: { w: 5, h: 4, minW: 3, minH: 3 },
  configFields: [
    {
      key: "proxyUrl",
      label: "Proxy URL",
      type: "url",
      required: true,
      placeholder: "https://cf-proxy.example.com",
    },
    {
      key: "publicUrl",
      label: "Dashboard / Open URL",
      type: "url",
      placeholder: "https://dash.cloudflare.com/…/home/overview",
    },
    {
      key: "accountId",
      label: "Account ID",
      type: "text",
      required: true,
    },
    {
      key: "tunnelId",
      label: "Tunnel ID",
      type: "text",
      required: true,
    },
    {
      key: "apiToken",
      label: "API Token (optional)",
      type: "password",
    },
    {
      key: "originMap",
      label: "Origin map JSON (optional)",
      type: "text",
      placeholder: '{"connector-uuid":"proxmox1"}',
    },
  ],
};
