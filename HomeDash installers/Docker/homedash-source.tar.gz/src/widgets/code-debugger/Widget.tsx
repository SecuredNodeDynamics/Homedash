"use client";

import "@/styles/widgets/code-debugger.widget.css";
import { useEffect, useMemo, useRef, useState } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import type { DebugFinding, DebugSeverity } from "@/lib/widgets/code-debugger";

type SourceFile = { id: string; name: string; content: string };
type Analysis = {
  findings: DebugFinding[];
  counts: Record<DebugSeverity, number>;
  score: number;
  lines: number;
};
type Provider = "gemini" | "perplexity";
type View = "editor" | "overview" | "findings" | "ai";

const DEFAULT_CODE = `// Paste code here or upload source files.\n// Code is analyzed as text and is never executed.\n`;
const ACCEPTED = ".js,.jsx,.ts,.tsx,.mjs,.cjs,.html,.css,.java,.json,.py,.php,.rb,.go,.rs,.c,.h,.cpp,.cs,.sh,.sql,.vue,.svelte,.yaml,.yml,.xml,.txt,.md";

function id() {
  return `debug-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}

export default function CodeDebuggerWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "code-debugger";
  const inputRef = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<SourceFile[]>([{ id: id(), name: "snippet.js", content: DEFAULT_CODE }]);
  const [activeId, setActiveId] = useState("");
  const [provider, setProvider] = useState<Provider>("gemini");
  const [configured, setConfigured] = useState<Record<Provider, boolean>>({ gemini: false, perplexity: false });
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [aiReport, setAiReport] = useState("");
  const [aiMeta, setAiMeta] = useState("");
  const [view, setView] = useState<View>("editor");
  const [filter, setFilter] = useState<DebugSeverity | "all">("all");
  const [busy, setBusy] = useState<"local" | "ai" | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    setActiveId((current) => current || files[0]?.id || "");
  }, [files]);

  useEffect(() => {
    fetch(`/api/widgets/code-debugger/info?instance=${encodeURIComponent(instanceId)}`)
      .then((response) => response.json())
      .then((data) => {
        setProvider(data.provider === "perplexity" ? "perplexity" : "gemini");
        setConfigured({
          gemini: Boolean(data.configured?.gemini),
          perplexity: Boolean(data.configured?.perplexity),
        });
      }).catch(() => undefined);
  }, [instanceId]);

  const active = files.find((file) => file.id === activeId) || files[0];
  const visibleFindings = useMemo(() =>
    analysis?.findings.filter((finding) => filter === "all" || finding.severity === filter) || [],
  [analysis, filter]);

  async function addFiles(list: FileList | File[]) {
    const picked = Array.from(list).slice(0, Math.max(0, 12 - files.length));
    const loaded: SourceFile[] = [];
    for (const file of picked) {
      if (file.size > 300_000) {
        setError(`${file.name} exceeds the 300 KB per-file limit.`);
        continue;
      }
      try {
        const content = await file.text();
        if (content.includes("\u0000")) {
          setError(`${file.name} appears to be binary and was skipped.`);
          continue;
        }
        loaded.push({ id: id(), name: file.name.slice(0, 180), content });
      } catch {
        setError(`Could not read ${file.name}.`);
      }
    }
    if (loaded.length) {
      setFiles((current) => [...current, ...loaded]);
      setActiveId(loaded[0].id);
      setAnalysis(null);
      setAiReport("");
    }
  }

  function updateActive(content: string) {
    if (!active) return;
    setFiles((current) => current.map((file) => file.id === active.id ? { ...file, content } : file));
  }

  async function analyze(ai: boolean) {
    setBusy(ai ? "ai" : "local");
    setError("");
    try {
      const response = await fetch("/api/widgets/code-debugger/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          instance: instanceId,
          provider,
          ai,
          files: files.map(({ name, content }) => ({ name, content })),
        }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data.analysis) throw new Error(data.error || `HTTP ${response.status}`);
      setAnalysis(data.analysis);
      if (data.ai?.text) {
        setAiReport(String(data.ai.text));
        setAiMeta(`${data.ai.provider} · ${data.ai.model}`);
        setView("ai");
      } else {
        setView("overview");
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Analysis failed");
    } finally {
      setBusy(null);
    }
  }

  function removeFile(fileId: string) {
    if (files.length === 1) {
      setFiles([{ id: id(), name: "snippet.js", content: DEFAULT_CODE }]);
      return;
    }
    const next = files.filter((file) => file.id !== fileId);
    setFiles(next);
    if (fileId === activeId) setActiveId(next[0].id);
  }

  return (
    <div className="cdb-root" onDragOver={(event) => event.preventDefault()} onDrop={(event) => { event.preventDefault(); void addFiles(event.dataTransfer.files); }}>
      <header className="cdb-head">
        <div className="cdb-brand"><span>&lt;/&gt;</span><div><strong>Code Debugger</strong><small>Static security and quality analysis</small></div></div>
        <nav>{(["editor", "overview", "findings", "ai"] as View[]).map((item) => <button type="button" key={item} className={view === item ? "is-active" : ""} disabled={item !== "editor" && !analysis && item !== "ai"} onClick={() => setView(item)}>{item === "ai" ? "AI report" : item}</button>)}</nav>
        <button type="button" className="cdb-upload" onClick={() => inputRef.current?.click()}>＋ Upload</button>
        <input ref={inputRef} hidden multiple type="file" accept={ACCEPTED} onChange={(event) => { if (event.target.files) void addFiles(event.target.files); event.target.value = ""; }} />
      </header>

      {view === "editor" ? (
        <div className="cdb-workspace">
          <aside className="cdb-files">
            <header><strong>Source files</strong><span>{files.length}/12</span></header>
            {files.map((file) => <button type="button" key={file.id} className={file.id === active?.id ? "is-active" : ""} onClick={() => setActiveId(file.id)}><span>{file.name.split(".").pop()?.slice(0, 3).toUpperCase()}</span><strong>{file.name}</strong><i onClick={(event) => { event.stopPropagation(); removeFile(file.id); }}>×</i></button>)}
            <div className="cdb-drop">Drop source files here<br /><small>Text only · 300 KB each</small></div>
          </aside>
          <section className="cdb-editor">
            <div className="cdb-editorbar"><input value={active?.name || ""} onChange={(event) => setFiles((current) => current.map((file) => file.id === active?.id ? { ...file, name: event.target.value } : file))} /><span>{active?.content.split("\n").length || 0} lines</span></div>
            <textarea spellCheck={false} value={active?.content || ""} onChange={(event) => updateActive(event.target.value)} aria-label="Code to analyze" />
          </section>
          <aside className="cdb-run">
            <div className="cdb-shield">⌁</div><h3>Review workspace</h3><p>Scan every loaded file for security risks, probable bugs, and engineering improvements.</p>
            <button type="button" className="primary" disabled={Boolean(busy)} onClick={() => analyze(false)}>{busy === "local" ? "Scanning…" : "Run static scan"}</button>
            <div className="cdb-provider">
              <span>AI reviewer</span>
              <div><button type="button" className={provider === "gemini" ? "is-active gemini" : ""} disabled={!configured.gemini} onClick={() => setProvider("gemini")}><img src="/icons/ai-gemini.svg" alt="" />Gemini</button><button type="button" className={provider === "perplexity" ? "is-active perplexity" : ""} disabled={!configured.perplexity} onClick={() => setProvider("perplexity")}><img src="/icons/ai-perplexity.svg" alt="" />Perplexity</button></div>
            </div>
            <button type="button" disabled={Boolean(busy) || !configured[provider]} onClick={() => analyze(true)}>{busy === "ai" ? `${provider} is reviewing…` : "Deep AI review"}</button>
            <small>Detected credentials are redacted before AI review. Configure API keys in widget settings.</small>
            {error ? <div className="cdb-error">{error}</div> : null}
          </aside>
        </div>
      ) : null}

      {view === "overview" && analysis ? (
        <div className="cdb-overview">
          <div className="cdb-score"><div style={{ "--score": `${analysis.score * 3.6}deg` } as React.CSSProperties}><strong>{analysis.score}</strong><span>/100</span></div><h3>{analysis.score >= 85 ? "Low observed risk" : analysis.score >= 60 ? "Review recommended" : "Immediate attention"}</h3><p>Rule-based score across {files.length} files and {analysis.lines.toLocaleString()} lines.</p></div>
          <div className="cdb-counts">{(["critical", "high", "medium", "low", "info"] as DebugSeverity[]).map((severity) => <button type="button" key={severity} onClick={() => { setFilter(severity); setView("findings"); }}><span className={`is-${severity}`}>{analysis.counts[severity]}</span><strong>{severity}</strong><small>findings</small></button>)}</div>
          <section className="cdb-summary"><article><b>Security posture</b><p>{analysis.counts.critical || analysis.counts.high ? `${analysis.counts.critical + analysis.counts.high} high-priority security findings require review before deployment.` : "No critical or high-severity pattern matches were detected by the local scanner."}</p></article><article><b>Recommended next step</b><p>{configured[provider] ? `Run the ${provider} deep review for contextual debugging, corrected examples, and a remediation roadmap.` : "Configure Gemini or Perplexity in widget settings for contextual AI review."}</p></article></section>
        </div>
      ) : null}

      {view === "findings" && analysis ? (
        <div className="cdb-findings">
          <header><strong>{visibleFindings.length} findings</strong><select value={filter} onChange={(event) => setFilter(event.target.value as DebugSeverity | "all")}><option value="all">All severities</option>{(["critical", "high", "medium", "low", "info"] as DebugSeverity[]).map((severity) => <option key={severity} value={severity}>{severity}</option>)}</select></header>
          {visibleFindings.map((finding) => <article key={finding.id}><span className={`cdb-severity is-${finding.severity}`}>{finding.severity}</span><div><header><strong>{finding.title}</strong><code>{finding.file}:{finding.line}</code></header><p>{finding.detail}</p>{finding.excerpt ? <pre>{finding.excerpt}</pre> : null}<footer><b>Fix</b> {finding.remediation}</footer></div></article>)}
          {!visibleFindings.length ? <div className="cdb-empty">No matching findings.</div> : null}
        </div>
      ) : null}

      {view === "ai" ? aiReport ? <div className="cdb-ai"><header><div><img src={provider === "gemini" ? "/icons/ai-gemini.svg" : "/icons/ai-perplexity.svg"} alt="" /><span><strong>AI security review</strong><small>{aiMeta}</small></span></div><button type="button" disabled={Boolean(busy)} onClick={() => analyze(true)}>↻ Run again</button></header><pre>{aiReport}</pre><footer>AI output can be incomplete or incorrect. Validate fixes and test before deployment.</footer></div> : <div className="cdb-empty">Run a configured Gemini or Perplexity deep review to generate the executive report.</div> : null}
    </div>
  );
}
