import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "code-debugger",
  name: "Code Debugger",
  description: "Static debugging, security review, and AI-assisted code analysis",
  version: "1.0.0",
  category: "Productivity",
  hostClass: "code-debugger-host",
  defaultSize: { w: 8, h: 6, minW: 5, minH: 4 },
  configFields: [
    {
      key: "provider",
      label: "Default AI reviewer",
      type: "select",
      options: [
        { value: "gemini", label: "Google Gemini" },
        { value: "perplexity", label: "Perplexity" },
      ],
    },
    { key: "geminiApiKey", label: "Gemini API Key", type: "password" },
    { key: "geminiModel", label: "Gemini model", placeholder: "gemini-3.6-flash" },
    { key: "perplexityApiKey", label: "Perplexity API Key", type: "password" },
    { key: "perplexityModel", label: "Perplexity model", placeholder: "sonar-pro" },
  ],
};
