"use client";

import "@/styles/widgets/code-notes.widget.css";
import { useEffect, useMemo, useRef, useState } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";

type Language = "html" | "css" | "java" | "nodejs";
type CodeDocument = { id: string; name: string; language: Language; code: string; updatedAt: number };
type Output = { kind: "info" | "success" | "error"; lines: string[] };

const LANGUAGE_LABELS: Record<Language, string> = {
  html: "HTML",
  css: "CSS",
  java: "Java",
  nodejs: "Node.js",
};

const STARTERS: Record<Language, string> = {
  html: `<main class="card">\n  <h1>Hello, Homedash!</h1>\n  <p>Edit this HTML and press Run.</p>\n</main>`,
  css: `.demo-card {\n  padding: 2rem;\n  border-radius: 1rem;\n  color: white;\n  background: linear-gradient(135deg, #2563eb, #7c3aed);\n}`,
  java: `public class Main {\n  public static void main(String[] args) {\n    System.out.println("Hello, Homedash!");\n  }\n}`,
  nodejs: `const values = [4, 8, 15, 16, 23, 42];\nconst total = values.reduce((sum, value) => sum + value, 0);\nconsole.log("Total:", total);\nassert(total === 108, "Expected the total to equal 108");`,
};

function newDocumentId() {
  if (typeof globalThis.crypto?.randomUUID === "function") {
    return globalThis.crypto.randomUUID();
  }
  const random = new Uint32Array(4);
  if (typeof globalThis.crypto?.getRandomValues === "function") {
    globalThis.crypto.getRandomValues(random);
  } else {
    for (let index = 0; index < random.length; index += 1) {
      random[index] = Math.floor(Math.random() * 0xffffffff);
    }
  }
  return `code-${Date.now().toString(36)}-${Array.from(random, (value) => value.toString(36)).join("-")}`;
}

function makeDocument(language: Language, index: number): CodeDocument {
  const extension = { html: "html", css: "css", java: "java", nodejs: "js" }[language];
  return {
    id: newDocumentId(),
    name: language === "java" ? "Main.java" : `note-${index}.${extension}`,
    language,
    code: STARTERS[language],
    updatedAt: Date.now(),
  };
}

function javaDiagnostics(code: string): Output {
  const errors: string[] = [];
  let braces = 0;
  let parentheses = 0;
  for (const char of code.replace(/"(?:\\.|[^"\\])*"/g, "\"\"")) {
    if (char === "{") braces += 1;
    if (char === "}") braces -= 1;
    if (char === "(") parentheses += 1;
    if (char === ")") parentheses -= 1;
    if (braces < 0) errors.push("Unexpected closing brace.");
    if (parentheses < 0) errors.push("Unexpected closing parenthesis.");
  }
  if (braces !== 0) errors.push(`Unbalanced braces (${Math.abs(braces)} unmatched).`);
  if (parentheses !== 0) errors.push(`Unbalanced parentheses (${Math.abs(parentheses)} unmatched).`);
  if (!/\bclass\s+[A-Za-z_$][\w$]*/.test(code)) errors.push("No Java class declaration found.");
  if (!/\bstatic\s+void\s+main\s*\(/.test(code)) errors.push("No static void main(...) entry point found.");
  code.split("\n").forEach((line, index) => {
    const clean = line.trim();
    if (/^(System\.out\.|return\b|(?:int|long|double|float|boolean|String)\s+\w+\s*=)/.test(clean)
      && !/[;{}]$/.test(clean)) errors.push(`Line ${index + 1}: statement may be missing a semicolon.`);
  });
  return errors.length
    ? { kind: "error", lines: ["Java compile check failed:", ...Array.from(new Set(errors))] }
    : { kind: "success", lines: ["Java compile check passed.", "Class structure, entry point, delimiters, and common statements look valid.", "Java execution is disabled to protect the dashboard host."] };
}

function runNode(code: string, onOutput: (output: Output) => void) {
  const workerSource = `
    const stringify = (v) => {
      if (typeof v === "string") return v;
      try { return JSON.stringify(v); } catch { return String(v); }
    };
    const send = (level, args) => postMessage({ level, text: args.map(stringify).join(" ") });
    console = {
      log: (...args) => send("log", args),
      info: (...args) => send("log", args),
      warn: (...args) => send("warn", args),
      error: (...args) => send("error", args)
    };
    const assert = (condition, message = "Assertion failed") => {
      if (!condition) throw new Error(message);
      send("pass", ["✓", message === "Assertion failed" ? "Assertion passed" : message]);
    };
    onmessage = ({ data }) => {
      try {
        const result = Function('"use strict";\\n' + data)();
        if (result !== undefined) send("log", ["Result:", result]);
        postMessage({ done: true });
      } catch (error) {
        postMessage({ level: "error", text: error?.stack || error?.message || String(error), done: true });
      }
    };
  `;
  const blobUrl = URL.createObjectURL(new Blob([workerSource], { type: "text/javascript" }));
  const worker = new Worker(blobUrl);
  const lines: string[] = [];
  let failed = false;
  const finish = () => {
    worker.terminate();
    URL.revokeObjectURL(blobUrl);
    onOutput({
      kind: failed ? "error" : "success",
      lines: lines.length ? lines : ["Completed with no console output."],
    });
  };
  const timer = window.setTimeout(() => {
    failed = true;
    lines.push("Execution stopped after 3 seconds.");
    finish();
  }, 3000);
  worker.onmessage = (event) => {
    if (event.data?.text) {
      lines.push(String(event.data.text));
      if (event.data.level === "error") failed = true;
    }
    if (event.data?.done) {
      window.clearTimeout(timer);
      finish();
    }
  };
  worker.onerror = (event) => {
    window.clearTimeout(timer);
    failed = true;
    lines.push(event.message || "Worker execution failed.");
    finish();
  };
  worker.postMessage(code);
}

export default function CodeNotesWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "code-notes";
  const [documents, setDocuments] = useState<CodeDocument[]>([]);
  const [activeId, setActiveId] = useState("");
  const [language, setLanguage] = useState<Language>("nodejs");
  const [output, setOutput] = useState<Output>({ kind: "info", lines: ["Ready. Run a note to see output and diagnostics."] });
  const [preview, setPreview] = useState("");
  const [loading, setLoading] = useState(true);
  const [saveState, setSaveState] = useState<"saved" | "saving" | "error">("saved");
  const hydrated = useRef(false);

  useEffect(() => {
    let cancelled = false;
    const fallback = makeDocument("nodejs", 1);
    // Render a usable editor immediately. The saved notebook replaces this
    // scratch file when it arrives, so a slow API can never trap the widget.
    setDocuments([fallback]);
    setActiveId(fallback.id);
    setLanguage(fallback.language);
    setLoading(false);

    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 8000);
    fetch(`/api/widgets/code-notes/notes?instance=${encodeURIComponent(instanceId)}`, {
      signal: controller.signal,
    })
      .then(async (response) => {
        const data = await response.json().catch(() => ({}));
        if (!response.ok) {
          throw new Error(
            typeof data.error === "string"
              ? data.error
              : `Could not load notes (HTTP ${response.status})`,
          );
        }
        return data;
      })
      .then((data) => {
        if (cancelled) return;
        const loaded = Array.isArray(data.documents) && data.documents.length
          ? data.documents as CodeDocument[]
          : [makeDocument("nodejs", 1)];
        setDocuments(loaded);
        setActiveId(loaded[0].id);
        setLanguage(loaded[0].language);
        hydrated.current = true;
      })
      .catch((error) => {
        if (cancelled) return;
        hydrated.current = true;
        setOutput({
          kind: "error",
          lines: [
            error instanceof DOMException && error.name === "AbortError"
              ? "Loading saved notes timed out."
              : error instanceof Error ? error.message : "Could not load saved notes.",
            "A temporary notebook was opened so you can continue working.",
          ],
        });
      })
      .finally(() => {
        window.clearTimeout(timeout);
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
      controller.abort();
      window.clearTimeout(timeout);
      hydrated.current = false;
    };
  }, [instanceId]);

  useEffect(() => {
    if (!hydrated.current || !documents.length) return;
    setSaveState("saving");
    const timer = window.setTimeout(() => {
      fetch("/api/widgets/code-notes/notes", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, documents }),
      }).then((response) => {
        if (!response.ok) throw new Error("Save failed");
        setSaveState("saved");
      }).catch(() => setSaveState("error"));
    }, 650);
    return () => window.clearTimeout(timer);
  }, [documents, instanceId]);

  const active = useMemo(
    () => documents.find((document) => document.id === activeId) || documents[0],
    [documents, activeId],
  );

  function updateActive(patch: Partial<CodeDocument>) {
    if (!active) return;
    setDocuments((current) => current.map((document) =>
      document.id === active.id ? { ...document, ...patch, updatedAt: Date.now() } : document));
  }

  function addDocument() {
    const created = makeDocument(language, documents.length + 1);
    setDocuments((current) => [...current, created]);
    setActiveId(created.id);
    setOutput({ kind: "info", lines: [`Created ${created.name}`] });
  }

  function removeDocument() {
    if (!active || documents.length === 1) return;
    const next = documents.filter((document) => document.id !== active.id);
    setDocuments(next);
    setActiveId(next[0].id);
    setLanguage(next[0].language);
  }

  function selectDocument(document: CodeDocument) {
    setActiveId(document.id);
    setLanguage(document.language);
    setPreview("");
  }

  function run() {
    if (!active) return;
    setPreview("");
    setOutput({ kind: "info", lines: [`Running ${active.name}…`] });
    if (active.language === "nodejs") {
      runNode(active.code, setOutput);
      return;
    }
    if (active.language === "java") {
      setOutput(javaDiagnostics(active.code));
      return;
    }
    const source = active.language === "html"
      ? `<!doctype html><html><head><meta charset="utf-8"><style>body{font-family:system-ui;margin:0;padding:24px;background:#111827;color:#e5e7eb}</style></head><body>${active.code}</body></html>`
      : `<!doctype html><html><head><meta charset="utf-8"><style>body{font-family:system-ui;padding:24px;background:#111827;color:#e5e7eb}${active.code}</style></head><body><section class="demo-card"><h1>CSS Preview</h1><p>Your stylesheet is applied to this preview card.</p><button>Example button</button></section></body></html>`;
    setPreview(source);
    setOutput({ kind: "success", lines: [`${LANGUAGE_LABELS[active.language]} preview rendered in a sandbox.`] });
  }

  if (loading || !active) return <div className="cn-state">Loading code notebook…</div>;

  return (
    <div className="cn-root">
      <aside className="cn-sidebar">
        <div className="cn-sidebar-head">
          <strong>Files</strong>
          <button type="button" onClick={addDocument} title="New code note">＋</button>
        </div>
        <div className="cn-files">
          {documents.map((document) => (
            <button type="button" className={document.id === active.id ? "is-active" : ""} key={document.id} onClick={() => selectDocument(document)}>
              <span className={`cn-lang cn-lang--${document.language}`}>{LANGUAGE_LABELS[document.language].slice(0, 2)}</span>
              <span><strong>{document.name}</strong><small>{LANGUAGE_LABELS[document.language]}</small></span>
            </button>
          ))}
        </div>
      </aside>
      <section className="cn-workspace">
        <header className="cn-toolbar">
          <input aria-label="File name" value={active.name} onChange={(event) => updateActive({ name: event.target.value })} />
          <select aria-label="Language" value={active.language} onChange={(event) => {
            const next = event.target.value as Language;
            setLanguage(next);
            updateActive({ language: next });
          }}>
            {Object.entries(LANGUAGE_LABELS).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
          </select>
          <span className={`cn-save cn-save--${saveState}`}>{saveState}</span>
          <button type="button" className="cn-btn" onClick={removeDocument} disabled={documents.length === 1}>Delete</button>
          <button type="button" className="cn-btn cn-btn--run" onClick={run}>▶ {active.language === "java" ? "Check" : "Run"}</button>
        </header>
        <div className="cn-editor-wrap">
          <div className="cn-lines" aria-hidden="true">{active.code.split("\n").map((_, index) => <span key={index}>{index + 1}</span>)}</div>
          <textarea
            className="cn-editor"
            aria-label={`${LANGUAGE_LABELS[active.language]} code editor`}
            spellCheck={false}
            value={active.code}
            onChange={(event) => updateActive({ code: event.target.value })}
            onKeyDown={(event) => {
              if (event.key === "Tab") {
                event.preventDefault();
                const target = event.currentTarget;
                const start = target.selectionStart;
                const next = `${active.code.slice(0, start)}  ${active.code.slice(target.selectionEnd)}`;
                updateActive({ code: next });
                requestAnimationFrame(() => target.setSelectionRange(start + 2, start + 2));
              }
              if ((event.ctrlKey || event.metaKey) && event.key === "Enter") run();
            }}
          />
        </div>
        <section className="cn-console">
          <header><strong>{preview ? "Preview" : "Console"}</strong><button type="button" onClick={() => { setPreview(""); setOutput({ kind: "info", lines: [] }); }}>Clear</button></header>
          {preview ? (
            <iframe title={`${active.name} preview`} sandbox="" srcDoc={preview} />
          ) : (
            <pre className={`is-${output.kind}`}>{output.lines.join("\n") || "Console cleared."}</pre>
          )}
        </section>
      </section>
    </div>
  );
}
