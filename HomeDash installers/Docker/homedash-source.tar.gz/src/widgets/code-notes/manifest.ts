import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "code-notes",
  name: "Code Notes",
  description: "Programming notebook with safe previews, checks, and debug output",
  version: "1.0.0",
  category: "Productivity",
  hostClass: "code-notes-host",
  defaultSize: { w: 7, h: 6, minW: 4, minH: 4 },
  configFields: [],
};
