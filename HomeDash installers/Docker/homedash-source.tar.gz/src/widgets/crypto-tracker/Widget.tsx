"use client";

import "@/styles/widgets/crypto-tracker.widget.css";
import { useCallback, useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import type { CryptoMarketItem } from "@/lib/widgets/invest-crypto";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type View = "watchlist" | "compare" | "trends";
type Period = "1h" | "24h" | "7d";

function price(value: number | null) {
  if (value == null) return "—";
  if (value >= 1) return `$${value.toLocaleString(undefined, { maximumFractionDigits: 2 })}`;
  return `$${value.toFixed(6)}`;
}
function compact(value: number | null) {
  if (value == null) return "—";
  return `$${Intl.NumberFormat("en", { notation: "compact", maximumFractionDigits: 2 }).format(value)}`;
}
function pct(value: number | null) {
  return value == null ? "—" : `${value >= 0 ? "+" : ""}${value.toFixed(2)}%`;
}
function change(item: CryptoMarketItem, period: Period) {
  return period === "1h"
    ? item.price_change_percentage_1h_in_currency
    : period === "7d"
      ? item.price_change_percentage_7d_in_currency
      : item.price_change_percentage_24h_in_currency;
}
function momentum(item: CryptoMarketItem) {
  return (
    (item.price_change_percentage_1h_in_currency || 0) * 0.15 +
    (item.price_change_percentage_24h_in_currency || 0) * 0.45 +
    (item.price_change_percentage_7d_in_currency || 0) * 0.4
  );
}
function trendLabel(score: number) {
  if (score >= 4) return "Strong bullish";
  if (score >= 1) return "Bullish";
  if (score <= -4) return "Strong bearish";
  if (score <= -1) return "Bearish";
  return "Neutral";
}

function LineChart({
  series,
}: {
  series: Array<{ values: number[]; color: string; label?: string }>;
}) {
  const width = 600;
  const height = 150;
  const paths = series.map((entry) => {
    if (entry.values.length < 2) return "";
    const normalized = entry.values.map((value) => ((value / entry.values[0]) - 1) * 100);
    const all = series.flatMap((row) =>
      row.values.length ? row.values.map((value) => ((value / row.values[0]) - 1) * 100) : [],
    );
    const min = Math.min(...all);
    const max = Math.max(...all);
    const range = max - min || 1;
    return normalized
      .map((value, index) => {
        const x = (index / (normalized.length - 1)) * width;
        const y = height - ((value - min) / range) * (height - 14) - 7;
        return `${index ? "L" : "M"}${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(" ");
  });
  return (
    <svg className="ct-chart" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none">
      <line x1="0" y1={height / 2} x2={width} y2={height / 2} />
      {paths.map((path, index) => (
        <path d={path} key={series[index].label || index} style={{ stroke: series[index].color }} />
      ))}
    </svg>
  );
}

function CoinModal({ item, onClose }: { item: CryptoMarketItem; onClose: () => void }) {
  const [days, setDays] = useState(7);
  const [values, setValues] = useState(item.sparkline);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const key = (event: KeyboardEvent) => event.key === "Escape" && onClose();
    window.addEventListener("keydown", key);
    return () => {
      document.body.style.overflow = overflow;
      window.removeEventListener("keydown", key);
    };
  }, [onClose]);
  useEffect(() => {
    if (days === 7 && item.sparkline.length) {
      setValues(item.sparkline);
      return;
    }
    let active = true;
    setLoading(true);
    fetch(`/api/widgets/crypto-tracker/chart?id=${encodeURIComponent(item.id)}&days=${days}`)
      .then((response) => response.json().then((data) => ({ response, data })))
      .then(({ response, data }) => {
        if (!response.ok) throw new Error(data.error);
        if (active) setValues(data.prices || []);
      })
      .catch(() => {
        if (active) setValues(item.sparkline || []);
      })
      .finally(() => active && setLoading(false));
    return () => { active = false; };
  }, [days, item.id, item.sparkline]);
  const score = momentum(item);
  const range = item.current_price && item.high_24h != null && item.low_24h != null
    ? ((item.high_24h - item.low_24h) / item.current_price) * 100 : 0;
  const liquidity = item.market_cap && item.total_volume ? (item.total_volume / item.market_cap) * 100 : 0;
  return createPortal(
    <div className="ct-modal-scrim" onMouseDown={onClose}>
      <section className="ct-modal" role="dialog" aria-modal="true" onMouseDown={(event) => event.stopPropagation()}>
        <header>
          <img src={item.image} alt="" />
          <div><span>#{item.market_cap_rank || "—"} · {item.symbol}</span><h2>{item.name}</h2></div>
          <div className="ct-modal-price"><strong>{price(item.current_price)}</strong><span className={score >= 0 ? "up" : "down"}>{trendLabel(score)}</span></div>
          <button type="button" onClick={onClose}>×</button>
        </header>
        <div className="ct-modal-tabs">
          {[1, 7, 30, 90].map((value) => <button className={days === value ? "active" : ""} key={value} onClick={() => setDays(value)}>{value === 1 ? "24H" : `${value}D`}</button>)}
        </div>
        <div className="ct-modal-chart">{loading ? <span>Loading market history…</span> : <LineChart series={[{ values, color: score >= 0 ? "#34d399" : "#fb7185" }]} />}</div>
        <div className="ct-modal-metrics">
          <div><span>Market cap</span><strong>{compact(item.market_cap)}</strong></div>
          <div><span>24h volume</span><strong>{compact(item.total_volume)}</strong></div>
          <div><span>24h range</span><strong>{range.toFixed(2)}%</strong></div>
          <div><span>Liquidity ratio</span><strong>{liquidity.toFixed(2)}%</strong></div>
          <div><span>7d change</span><strong>{pct(item.price_change_percentage_7d_in_currency)}</strong></div>
          <div><span>Momentum score</span><strong>{score.toFixed(2)}</strong></div>
        </div>
        <div className="ct-analysis">
          <strong>Smart market read</strong>
          <p>
            {trendLabel(score)} momentum across the weighted 1-hour, 24-hour, and 7-day periods.
            {range > 8 ? " Short-term volatility is elevated." : " Short-term price dispersion is contained."}
            {liquidity > 10 ? " Trading activity is high relative to market capitalization." : " Liquidity should be considered before larger positions."}
          </p>
          <small>Market analytics are informational and are not investment advice.</small>
        </div>
      </section>
    </div>,
    document.body,
  );
}

export default function CryptoTrackerWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "crypto-tracker";
  const [items, setItems] = useState<CryptoMarketItem[]>([]);
  const [view, setView] = useState<View>("watchlist");
  const [period, setPeriod] = useState<Period>("24h");
  const [selected, setSelected] = useState<CryptoMarketItem | null>(null);
  const [leftId, setLeftId] = useState("");
  const [rightId, setRightId] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [rootNode, setRootNode] = useState<HTMLElement | null>(null);
  const [compactWide, setCompactWide] = useState(false);
  const load = useCallback(async () => {
    try {
      const response = await fetch(`/api/widgets/crypto-tracker/status?instance=${encodeURIComponent(instanceId)}`);
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Tracker unavailable");
      setItems(data.items || []);
      setPeriod(data.defaultInterval || "24h");
      setLeftId((current) => current || data.items?.[0]?.id || "");
      setRightId((current) => current || data.items?.[1]?.id || data.items?.[0]?.id || "");
      setError("");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Tracker unavailable");
    } finally { setLoading(false); }
  }, [instanceId]);
  const { rootRef } = useWidgetPoll(load, { intervalMs: 120_000 });
  const attachRoot = useCallback((node: HTMLDivElement | null) => {
    rootRef(node);
    setRootNode(node);
  }, [rootRef]);
  useEffect(() => {
    if (!rootNode) return;
    const update = () => {
      const rect = rootNode.getBoundingClientRect();
      setCompactWide(rect.width >= 760 && rect.height <= 285);
    };
    update();
    const observer = new ResizeObserver(update);
    observer.observe(rootNode);
    return () => observer.disconnect();
  }, [rootNode]);
  const sorted = useMemo(() => [...items].sort((a, b) => momentum(b) - momentum(a)), [items]);
  const left = items.find((item) => item.id === leftId);
  const right = items.find((item) => item.id === rightId);
  const totalCap = items.reduce((sum, item) => sum + (item.market_cap || 0), 0);
  const totalVolume = items.reduce((sum, item) => sum + (item.total_volume || 0), 0);
  const gainers = items.filter((item) => (change(item, period) || 0) > 0).length;
  return (
    <div className={`hd-widget-body ct-body${compactWide ? " is-wide-compact" : ""}`} ref={attachRoot}>
      <div className="ct-wide-mode">
        <div className="ct-wide-head">
          <div>
            <strong>{items.length} assets</strong>
            <span>{compact(totalCap)} combined market cap · {gainers} advancing</span>
          </div>
          <div>{(["1h", "24h", "7d"] as Period[]).map((name) => <button className={period === name ? "active" : ""} key={name} onClick={() => setPeriod(name)}>{name}</button>)}</div>
        </div>
        <div className="ct-wide-coins">
          {items.map((item) => {
            const value = change(item, period);
            return (
              <button type="button" key={item.id} onClick={() => setSelected(item)}>
                <img src={item.image} alt="" />
                <div>
                  <span><strong>{item.symbol}</strong> {item.name}</span>
                  <b>{price(item.current_price)}</b>
                </div>
                <em className={(value || 0) >= 0 ? "up" : "down"}>{pct(value)}</em>
              </button>
            );
          })}
        </div>
      </div>
      <div className="ct-toolbar">
        <div>{(["watchlist", "compare", "trends"] as View[]).map((name) => <button className={view === name ? "active" : ""} key={name} onClick={() => setView(name)}>{name}</button>)}</div>
        <div>{(["1h", "24h", "7d"] as Period[]).map((name) => <button className={period === name ? "active" : ""} key={name} onClick={() => setPeriod(name)}>{name}</button>)}</div>
      </div>
      <div className="ct-summary">
        <div><span>Tracked assets</span><strong>{items.length}</strong></div>
        <div><span>Combined cap</span><strong>{compact(totalCap)}</strong></div>
        <div><span>24h volume</span><strong>{compact(totalVolume)}</strong></div>
        <div><span>Advancing</span><strong>{gainers}/{items.length}</strong></div>
      </div>
      <main className="ct-content">
        {loading && !items.length ? <div className="ct-state">Loading crypto markets…</div> : null}
        {error ? <div className="ct-state error">{error}</div> : null}
        {view === "watchlist" ? (
          <div className="ct-grid">{items.map((item) => {
            const value = change(item, period);
            return <button className="ct-coin" key={item.id} onClick={() => setSelected(item)}>
              <div className="ct-coin-head"><img src={item.image} alt="" /><div><strong>{item.symbol}</strong><span>{item.name}</span></div><b>#{item.market_cap_rank || "—"}</b></div>
              <div className="ct-coin-price"><strong>{price(item.current_price)}</strong><span className={(value || 0) >= 0 ? "up" : "down"}>{pct(value)}</span></div>
              <LineChart series={[{ values: item.sparkline.slice(period === "1h" ? -3 : period === "24h" ? -24 : undefined), color: (value || 0) >= 0 ? "#34d399" : "#fb7185" }]} />
              <div className="ct-coin-foot"><span>Cap {compact(item.market_cap)}</span><span>Vol {compact(item.total_volume)}</span></div>
            </button>;
          })}</div>
        ) : null}
        {view === "compare" && left && right ? (
          <div className="ct-compare">
            <div className="ct-compare-selects"><select value={leftId} onChange={(e) => setLeftId(e.target.value)}>{items.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}</select><span>versus</span><select value={rightId} onChange={(e) => setRightId(e.target.value)}>{items.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}</select></div>
            <div className="ct-compare-chart"><div><span className="a" />{left.symbol}<span className="b" />{right.symbol}</div><LineChart series={[{ values: left.sparkline, color: "#60a5fa", label: left.id }, { values: right.sparkline, color: "#c084fc", label: right.id }]} /></div>
            <div className="ct-table">
              {[
                ["Price", price(left.current_price), price(right.current_price)],
                [`${period} change`, pct(change(left, period)), pct(change(right, period))],
                ["Market cap", compact(left.market_cap), compact(right.market_cap)],
                ["24h volume", compact(left.total_volume), compact(right.total_volume)],
                ["Momentum", momentum(left).toFixed(2), momentum(right).toFixed(2)],
              ].map((row) => <div key={row[0]}><span>{row[0]}</span><strong>{row[1]}</strong><strong>{row[2]}</strong></div>)}
            </div>
          </div>
        ) : null}
        {view === "trends" ? <div className="ct-trends">{sorted.map((item, index) => {
          const score = momentum(item);
          return <button key={item.id} onClick={() => setSelected(item)}><b>#{index + 1}</b><img src={item.image} alt="" /><div><strong>{item.name}</strong><span>{trendLabel(score)}</span></div><div className="ct-trend-periods"><span>1h {pct(item.price_change_percentage_1h_in_currency)}</span><span>24h {pct(item.price_change_percentage_24h_in_currency)}</span><span>7d {pct(item.price_change_percentage_7d_in_currency)}</span></div><em className={score >= 0 ? "up" : "down"}>{score.toFixed(2)}</em></button>;
        })}</div> : null}
      </main>
      <footer className="ct-footer"><span>CoinGecko market data</span><span>Smart signals are informational, not investment advice</span></footer>
      {selected ? <CoinModal item={selected} onClose={() => setSelected(null)} /> : null}
    </div>
  );
}
