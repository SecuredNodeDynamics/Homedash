import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "crypto-tracker",
  name: "Crypto Tracker",
  description: "Smart crypto market analysis, trends, charts, and comparisons",
  version: "1.0.0",
  category: "Invest",
  defaultSize: { w: 6, h: 5, minW: 4, minH: 3 },
  hostClass: "crypto-tracker-host",
  configFields: [
    {
      key: "coins",
      label: "CoinGecko IDs (comma-separated)",
      placeholder: "bitcoin,ethereum,solana,binancecoin,ripple",
    },
    {
      key: "defaultInterval",
      label: "Default analysis period (1h, 24h, or 7d)",
      placeholder: "24h",
    },
  ],
};
