"use client";
import "@/styles/widgets/dispatcharr.widget.css";


import { useCallback, useState } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type Data = {
  href: string;
  openFallbackUrl?: string;
  recordings: number;
  channels: number;
  active: number;
  items: Array<{ title: string; meta?: string }>;
};

export default function DispatcharrWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "dispatcharr";
  const [data, setData] = useState<Data | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [updatedAt, setUpdatedAt] = useState("");
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);

  const load = useCallback(async () => {
    try {
      const response = await fetch(
        `/api/widgets/dispatcharr/status?instance=${encodeURIComponent(instanceId)}`,
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load Dispatcharr");
      setData(json);
      setError("");
      setUpdatedAt(
        new Date().toLocaleTimeString("en-US", {
          hour: "numeric",
          minute: "2-digit",
          second: "2-digit",
          hour12: true,
        }),
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unavailable");
    } finally {
      setLoading(false);
    }
  }, [instanceId]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: 60_000 });

  if (loading && !data) {
    return (
      <div className="hd-widget-body arr-body" ref={rootRef}>
        <div className="arr-toolbar">
          <span className="arr-status-text">Loading…</span>
        </div>
        <div className="arr-skeleton-row" />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="hd-widget-body arr-body" ref={rootRef}>
        <div className="arr-toolbar">
          <span className="arr-status-text">Offline</span>
          <button className="arr-tool-btn" type="button" onClick={load}>
            Retry
          </button>
        </div>
        <div className="arr-error">⚠ {error}</div>
      </div>
    );
  }

  return (
    <div className="hd-widget-body arr-body arr-widget--dispatcharr" ref={rootRef}>
      <div className="arr-toolbar">
        <div className="arr-toolbar-left">
          <span className="arr-status-text">{error ? "Degraded" : "Online"}</span>
          {updatedAt ? <span className="arr-updated">{updatedAt}</span> : null}
        </div>
        <div className="arr-toolbar-right">
          <button className="arr-tool-btn" type="button" onClick={load} aria-label="Refresh">
            ↻
          </button>
          <a className="arr-tool-btn" href={openHref} target="_blank" rel="noopener noreferrer">
            Open
          </a>
        </div>
      </div>

      <div className="arr-stat-grid">
        <div className="arr-stat">
          <div className="arr-stat-value">{data.recordings.toLocaleString()}</div>
          <div className="arr-stat-label">Recordings</div>
        </div>
        <div className="arr-stat">
          <div className="arr-stat-value">{data.channels.toLocaleString()}</div>
          <div className="arr-stat-label">Channels</div>
        </div>
        <div className={`arr-stat${data.active ? " arr-stat--active" : ""}`}>
          <div className="arr-stat-value">{data.active.toLocaleString()}</div>
          <div className="arr-stat-label">Active</div>
        </div>
      </div>

      {data.items?.length ? (
        <div className="arr-list">
          {data.items.map((item, index) => (
            <div className="arr-list__row" key={`${item.title}-${index}`}>
              <strong>{item.title}</strong>
              {item.meta ? <span>{item.meta}</span> : null}
            </div>
          ))}
        </div>
      ) : (
        <div className="arr-summary">
          <span>No recordings yet</span>
        </div>
      )}
    </div>
  );
}
