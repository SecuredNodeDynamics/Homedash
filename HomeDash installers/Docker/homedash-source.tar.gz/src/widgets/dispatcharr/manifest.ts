import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "dispatcharr",
  name: "Dispatcharr",
  description: "TV recordings and channels",
  version: "0.2.0",
  category: "Media",
  defaultSize: { w: 4, h: 4, minW: 2, minH: 2 },
  hostClass: "dsp-host",
  configFields: [
    { key: "baseUrl", label: "Private - IP", type: "url", placeholder: "http://10.0.0.1:9191" },
    { key: "fallbackUrl", label: "Fallback Public URL", type: "url", placeholder: "https://dispatcharr.example.com" },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url", placeholder: "http://10.0.0.1:9191" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    { key: "username", label: "Username", type: "text", required: true },
    { key: "password", label: "Password", type: "password", required: true },
  ],
};
