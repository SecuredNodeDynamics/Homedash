"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { matchesTermOverlayViewport, useTermOverlayLock } from "@/lib/term-overlay";

const TERM_THEME = {
  background: "#0b1220",
  foreground: "#e2e8f0",
  cursor: "#93c5fd",
  cursorAccent: "#0b1220",
  selectionBackground: "#1e3a5f",
} as const;

function useEscapeClose(onClose: () => void) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        onClose();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);
}

export function DockerTermModal({
  instanceId,
  containerId,
  containerName,
  onClose,
}: {
  instanceId: string;
  containerId: string;
  containerName: string;
  onClose: () => void;
}) {
  const [error, setError] = useState("");
  const [status, setStatus] = useState<"connecting" | "online" | "offline" | "unavailable">("connecting");
  const mountRef = useRef<HTMLDivElement | null>(null);
  const termRef = useRef<{
    clear: () => void;
    dispose: () => void;
    write: (s: string) => void;
    focus: () => void;
    cols: number;
    rows: number;
    onData: (cb: (d: string) => void) => { dispose: () => void };
  } | null>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const close = useCallback(() => onClose(), [onClose]);
  useEscapeClose(close);
  useTermOverlayLock();

  useEffect(() => {
    let cancelled = false;
    let term: typeof termRef.current = null;
    let socket: WebSocket | null = null;
    let dataDisp: { dispose: () => void } | null = null;
    let onResize: (() => void) | null = null;
    let fit: { fit: () => void; dispose?: () => void } | null = null;

    void (async () => {
      try {
        const response = await fetch("/api/widgets/docker/exec/session", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ instance: instanceId, containerId }),
        });
        const json = await response.json();
        if (!response.ok) {
          const message = String(json.error || "Exec session failed");
          if (!cancelled) {
            setError(message);
            setStatus("unavailable");
          }
          return;
        }
        if (cancelled) return;

        const [{ Terminal }, { FitAddon }] = await Promise.all([
          import("@xterm/xterm"),
          import("@xterm/addon-fit"),
        ]);
        // @ts-expect-error xterm CSS has no type declarations
        await import("@xterm/xterm/css/xterm.css"); 
        if (cancelled || !mountRef.current) return;

        const mobile = matchesTermOverlayViewport();
        const terminal = new Terminal({
          cursorBlink: true,
          fontSize: mobile ? 14 : 13,
          fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
          theme: TERM_THEME,
          convertEol: true,
        });
        const fitAddon = new FitAddon();
        terminal.loadAddon(fitAddon);
        terminal.open(mountRef.current);
        const helper = mountRef.current.querySelector(".xterm-helper-textarea") as HTMLTextAreaElement | null;
        if (helper) helper.style.fontSize = "16px";

        const refit = () => {
          try {
            fitAddon.fit();
          } catch {
            /* ignore */
          }
        };
        refit();
        requestAnimationFrame(refit);
        window.setTimeout(refit, 150);

        term = terminal as unknown as typeof termRef.current;
        termRef.current = term;
        fit = fitAddon;

        onResize = refit;
        window.addEventListener("resize", onResize);
        window.visualViewport?.addEventListener("resize", onResize);

        const wsUrl =
          String(json.wsUrl || "") ||
          `${window.location.protocol === "https:" ? "wss" : "ws"}://${window.location.host}${json.wsPath}`;

        socket = new WebSocket(wsUrl);
        socket.binaryType = "arraybuffer";
        socketRef.current = socket;
        socket.onopen = () => {
          setStatus("online");
          refit();
          if (!mobile) terminal.focus();
        };
        socket.onmessage = (event) => {
          if (typeof event.data === "string") {
            terminal.write(event.data);
            return;
          }
          const bytes = new Uint8Array(event.data as ArrayBuffer);
          terminal.write(Array.from(bytes, (b) => String.fromCharCode(b)).join(""));
        };
        socket.onerror = () => {
          setError("WebSocket error");
          setStatus("offline");
        };
        socket.onclose = () => setStatus("offline");
        dataDisp = terminal.onData((chunk) => {
          if (socket?.readyState === WebSocket.OPEN) socket.send(chunk);
        });
      } catch (cause) {
        if (!cancelled) {
          const message = cause instanceof Error ? cause.message : "Terminal failed";
          setError(message);
          setStatus("unavailable");
        }
      }
    })();

    return () => {
      cancelled = true;
      if (onResize) {
        window.removeEventListener("resize", onResize);
        window.visualViewport?.removeEventListener("resize", onResize);
      }
      dataDisp?.dispose();
      socket?.close();
      term?.dispose();
      termRef.current = null;
      socketRef.current = null;
      void fit;
    };
  }, [instanceId, containerId]);

  function clearTerminal() {
    const terminal = termRef.current;
    if (!terminal) return;
    // Clear both xterm scrollback and the active viewport while preserving the
    // Docker/Portainer exec WebSocket and shell session.
    terminal.clear();
    terminal.write("\x1b[2J\x1b[3J\x1b[H");
    window.requestAnimationFrame(() => terminal.focus());
  }

  if (typeof document === "undefined") return null;

  const unavailable = status === "unavailable";

  return createPortal(
    <div className="dk-modal-backdrop" role="presentation">
      <div
        className={`dk-modal dk-modal--term${unavailable ? " dk-modal--term-empty" : ""}`}
        role="dialog"
        aria-modal="true"
        onClick={(e) => e.stopPropagation()}
      >
        <header className="dk-modal__head">
          <div className="dk-modal__head-text">
            <div className="dk-modal__kicker">Console</div>
            <h2>{containerName}</h2>
          </div>
          <div className="dk-modal__head-actions">
            {!unavailable ? (
              <>
                <span className={`dk-term-status dk-term-status--${status}`}>
                  <span className="dk-term-dot" />
                  {status}
                </span>
                <button type="button" className="dk-action" onClick={clearTerminal} title="Clear terminal">
                  Clear
                </button>
              </>
            ) : null}
            <button type="button" className="dk-action dk-action--stop" onClick={close}>
              Close
            </button>
          </div>
        </header>
        {unavailable ? (
          <div className="dk-term-unavailable">
            <div className="dk-term-unavailable__title">Console unavailable</div>
            <p className="dk-term-unavailable__text">
              {error ||
                "This container has no shell. Distroless and scratch images cannot open an interactive console."}
            </p>
            <p className="dk-term-unavailable__hint">
              Use Logs for triage, or open a container that includes bash/sh.
            </p>
          </div>
        ) : (
          <>
            {error ? <div className="dk-modal__error">{error}</div> : null}
            <div className="dk-term-body" ref={mountRef} />
          </>
        )}
      </div>
    </div>,
    document.body,
  );
}

export function DockerLogsModal({
  instanceId,
  containerId,
  containerName,
  onClose,
}: {
  instanceId: string;
  containerId: string;
  containerName: string;
  onClose: () => void;
}) {
  const [logs, setLogs] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [tail, setTail] = useState(200);
  const close = useCallback(() => onClose(), [onClose]);
  useEscapeClose(close);
  useTermOverlayLock();

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch(
        `/api/widgets/docker/logs?instance=${encodeURIComponent(instanceId)}&id=${encodeURIComponent(containerId)}&tail=${tail}`,
      );
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to load logs");
      setLogs(String(json.logs || ""));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load logs");
    } finally {
      setLoading(false);
    }
  }, [instanceId, containerId, tail]);

  useEffect(() => {
    void load();
  }, [load]);

  if (typeof document === "undefined") return null;

  return createPortal(
    <div className="dk-modal-backdrop" role="presentation">
      <div
        className="dk-modal dk-modal--logs"
        role="dialog"
        aria-modal="true"
        onClick={(e) => e.stopPropagation()}
      >
        <header className="dk-modal__head">
          <div className="dk-modal__head-text">
            <div className="dk-modal__kicker">Logs</div>
            <h2>{containerName}</h2>
          </div>
          <div className="dk-modal__head-actions">
            <select
              className="dk-filter-select"
              value={tail}
              onChange={(e) => setTail(Number(e.target.value))}
              aria-label="Log lines"
            >
              <option value={100}>100 lines</option>
              <option value={200}>200 lines</option>
              <option value={500}>500 lines</option>
              <option value={1000}>1000 lines</option>
            </select>
            <button
              type="button"
              className="dk-action dk-action--restart"
              disabled={loading}
              onClick={() => void load()}
            >
              {loading ? "…" : "Refresh"}
            </button>
            <button type="button" className="dk-action dk-action--stop" onClick={close}>
              Close
            </button>
          </div>
        </header>
        {error ? <div className="dk-modal__error">{error}</div> : null}
        <pre className="dk-logs-body">{loading && !logs ? "Loading…" : logs || "No log output"}</pre>
      </div>
    </div>,
    document.body,
  );
}
