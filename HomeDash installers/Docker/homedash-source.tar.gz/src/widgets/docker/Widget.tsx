"use client";
import "@/styles/widgets/docker.widget.css";


import { useCallback, useEffect, useMemo, useState, useLayoutEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";
import { DockerLogsModal, DockerTermModal } from "./DockerModals";
import { useAuthPermission } from "@/lib/use-auth-permission";

type DockerContainer = {
  id: string;
  name: string;
  image: string;
  state: string;
  status: string;
  ports: string;
};

type DockerConnectionSource = "private" | "public" | "unknown";

const CONNECTION_SOURCE_LABEL: Record<DockerConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

function ConnectionCorner({ source }: { source: DockerConnectionSource }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const mark = (
    <div
      className={`dk-corner-source dk-corner-source--${source}`}
      title={CONNECTION_SOURCE_LABEL[source]}
      aria-label={CONNECTION_SOURCE_LABEL[source]}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}


type Status = {
  href: string;
  openFallbackUrl?: string;
  connectionSource?: DockerConnectionSource;
  provider: string;
  host: string;
  running: number;
  stopped: number;
  paused: number;
  total: number;
  containers: DockerContainer[];
};

type DockerVolume = {
  name: string;
  driver: string;
  mountpoint: string;
  created?: string;
  inUse: boolean;
};

type ContainerAction = "start" | "stop" | "restart" | "pause" | "unpause" | "remove";
type TabKey = "containers" | "volumes" | "maintenance";
type StateFilter = "all" | "running" | "stopped";

function stateClass(state: string) {
  if (state === "running") return "dk-state--running";
  if (state === "paused") return "dk-state--paused";
  if (state === "restarting") return "dk-state--warn";
  return "dk-state--stopped";
}

function formatBytes(n: number) {
  if (!n) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let v = n;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i += 1;
  }
  return `${v.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

export default function DockerWidget() {
  const canUseTerminal = useAuthPermission("terminals.use");
  const canControlServices = useAuthPermission("widgets.control");
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "docker";
  const [data, setData] = useState<Status | null>(null);
  const [volumes, setVolumes] = useState<DockerVolume[]>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState("");
  const [tab, setTab] = useState<TabKey>("containers");
  const [query, setQuery] = useState("");
  const [stateFilter, setStateFilter] = useState<StateFilter>("all");
  const [logsFor, setLogsFor] = useState<DockerContainer | null>(null);
  const [termFor, setTermFor] = useState<DockerContainer | null>(null);
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);
  const [pruneBusy, setPruneBusy] = useState(false);
  const [pruneMsg, setPruneMsg] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch(
        `/api/widgets/docker/status?instance=${encodeURIComponent(instanceId)}`,
      );
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to load Docker");
      setData(json);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load Docker");
      setData(null);
    } finally {
      setLoading(false);
    }
  }, [instanceId]);

  const loadVolumes = useCallback(async () => {
    try {
      const res = await fetch(
        `/api/widgets/docker/volumes?instance=${encodeURIComponent(instanceId)}`,
      );
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to load volumes");
      setVolumes(Array.isArray(json.volumes) ? json.volumes : []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load volumes");
    }
  }, [instanceId]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: 60_000 });

  useEffect(() => {
    if (tab === "volumes") void loadVolumes();
  }, [tab, loadVolumes]);

  const filtered = useMemo(() => {
    const list = data?.containers || [];
    const q = query.trim().toLowerCase();
    return list.filter((c) => {
      if (stateFilter === "running" && c.state !== "running" && c.state !== "paused") return false;
      if (stateFilter === "stopped" && (c.state === "running" || c.state === "paused")) return false;
      if (!q) return true;
      return (
        c.name.toLowerCase().includes(q) ||
        c.image.toLowerCase().includes(q) ||
        c.status.toLowerCase().includes(q)
      );
    });
  }, [data, query, stateFilter]);

  async function runAction(containerId: string, action: ContainerAction) {
    if (action === "remove") {
      const ok = window.confirm("Force-remove this container?");
      if (!ok) return;
    }
    setBusyId(containerId);
    setError("");
    try {
      const res = await fetch("/api/widgets/docker/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, containerId, action }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || `Failed to ${action}`);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : `Failed to ${action}`);
    } finally {
      setBusyId("");
    }
  }

  async function removeVolume(name: string, inUse: boolean) {
    const ok = window.confirm(
      inUse
        ? `Volume “${name}” may be in use. Force delete?`
        : `Delete volume “${name}”?`,
    );
    if (!ok) return;
    setBusyId(`vol:${name}`);
    setError("");
    try {
      const res = await fetch("/api/widgets/docker/volumes", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, name, force: inUse }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to delete volume");
      await loadVolumes();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to delete volume");
    } finally {
      setBusyId("");
    }
  }

  async function pruneImages() {
    const ok = window.confirm("Prune unused Docker images on this host?");
    if (!ok) return;
    setPruneBusy(true);
    setPruneMsg("");
    setError("");
    try {
      const res = await fetch("/api/widgets/docker/prune", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, target: "images" }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Prune failed");
      setPruneMsg(
        `Removed ${Number(json.imagesDeleted || 0)} image refs · reclaimed ${formatBytes(Number(json.spaceReclaimed || 0))}`,
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "Prune failed");
    } finally {
      setPruneBusy(false);
    }
  }

  if (loading && !data) {
    return (
      <div className="hd-widget-body dk-body" ref={rootRef}>
        <div className="dk-toolbar">
          <span className="dk-status-pill dk-status-pill--loading">
            <span className="dk-status-dot" />
            Loading
          </span>
        </div>
        <div className="dk-skeleton-card" />
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="hd-widget-body dk-body" ref={rootRef}>
        <div className="dk-toolbar">
          <span className="dk-status-pill dk-status-pill--offline">
            <span className="dk-status-dot" />
            Offline
          </span>
          <button className="dk-open-link" type="button" onClick={load}>
            Retry
          </button>
        </div>
        <div className="dk-inst-error">{error}</div>
      </div>
    );
  }

  if (!data) return <div className="hd-widget-body dk-body" ref={rootRef} />;

  const statusLabel = error ? "Degraded" : "Online";
  const statusClass = error ? "dk-status-pill--warn" : "dk-status-pill--online";
  const showPaused = data.paused > 0;
  const connectionSource: DockerConnectionSource = data.connectionSource || "unknown";

  return (
    <div className={`hd-widget-body dk-body${canControlServices ? "" : " is-readonly"}`} ref={rootRef}>
      <ConnectionCorner source={connectionSource} />
      <div className="dk-toolbar">
        <span className={`dk-status-pill ${statusClass}`}>
          <span className="dk-status-dot" />
          {statusLabel}
        </span>
        <div className="dk-toolbar-right">
          {openHref ? (
            <a className="dk-open-link" href={openHref} target="_blank" rel="noopener noreferrer">
              Open
            </a>
          ) : null}
        </div>
      </div>

      <div className="dk-host-line" title={data.host}>
        {data.host}
        <span className="dk-host-meta">
          {" "}
          · {data.provider === "portainer" ? "Portainer" : "Engine"}
        </span>
      </div>

      <div className={`dk-stats-row${showPaused ? " dk-stats-row--4" : ""}`}>
        <div className="dk-stat">
          <div className="dk-stat-val dk-stat-val--running">{data.running}</div>
          <div className="dk-stat-lbl">Running</div>
        </div>
        <div className="dk-stat">
          <div className="dk-stat-val dk-stat-val--stopped">{data.stopped}</div>
          <div className="dk-stat-lbl">Stopped</div>
        </div>
        {showPaused ? (
          <div className="dk-stat">
            <div className="dk-stat-val dk-stat-val--paused">{data.paused}</div>
            <div className="dk-stat-lbl">Paused</div>
          </div>
        ) : null}
        <div className="dk-stat">
          <div className="dk-stat-val">{data.total}</div>
          <div className="dk-stat-lbl">Total</div>
        </div>
      </div>

      <div className="dk-tabs" role="tablist" aria-label="Docker sections">
        {(
          [
            ["containers", "Containers"],
            ["volumes", "Volumes"],
            ["maintenance", "Maintenance"],
          ] as const
        ).map(([key, label]) => (
          <button
            key={key}
            type="button"
            role="tab"
            aria-selected={tab === key}
            className={`dk-tab${tab === key ? " is-active" : ""}`}
            onClick={() => setTab(key)}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "containers" ? (
        <>
          <div className="dk-filters">
            <input
              className="dk-search"
              type="search"
              placeholder="Filter containers…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <div className="dk-filter-chips">
              {(
                [
                  ["all", "All"],
                  ["running", "Running"],
                  ["stopped", "Stopped"],
                ] as const
              ).map(([key, label]) => (
                <button
                  key={key}
                  type="button"
                  className={`dk-chip${stateFilter === key ? " is-active" : ""}`}
                  onClick={() => setStateFilter(key)}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          <div className="dk-list dk-list--cards">
            {!filtered.length ? (
              <div className="dk-empty">No containers</div>
            ) : (
              filtered.map((c) => {
                const running = c.state === "running";
                const paused = c.state === "paused";
                const busy = busyId === c.id;
                return (
                  <article
                    className={`dk-card dk-card--container dk-card--${c.state}`}
                    key={c.id}
                  >
                    <header className="dk-card-head">
                      <h3 className="dk-card-name" title={c.name}>
                        {c.name}
                      </h3>
                      <span className={`dk-state ${stateClass(c.state)}`}>{c.state}</span>
                    </header>

                    <div className="dk-card-body">
                      <div className="dk-kv">
                        <span className="dk-kv-label">Image</span>
                        <span className="dk-kv-value" title={c.image}>
                          {c.image}
                        </span>
                      </div>
                      {c.ports ? (
                        <div className="dk-kv">
                          <span className="dk-kv-label">Ports</span>
                          <span className="dk-kv-value dk-kv-value--mono" title={c.ports}>
                            {c.ports}
                          </span>
                        </div>
                      ) : null}
                      <div className="dk-kv">
                        <span className="dk-kv-label">Status</span>
                        <span className="dk-kv-value" title={c.status}>
                          {c.status}
                        </span>
                      </div>
                    </div>

                    <footer className="dk-card-foot">
                      <div className="dk-card-primary">
                        {running || paused ? (
                          paused ? (
                            <button
                              type="button"
                              className="dk-action dk-action--start"
                              disabled={busy}
                              onClick={() => runAction(c.id, "unpause")}
                            >
                              Unpause
                            </button>
                          ) : (
                            <button
                              type="button"
                              className="dk-action dk-action--stop"
                              disabled={busy}
                              onClick={() => runAction(c.id, "stop")}
                            >
                              {busy ? "…" : "Stop"}
                            </button>
                          )
                        ) : (
                          <button
                            type="button"
                            className="dk-action dk-action--start"
                            disabled={busy}
                            onClick={() => runAction(c.id, "start")}
                          >
                            {busy ? "…" : "Start"}
                          </button>
                        )}
                        <button
                          type="button"
                          className="dk-action dk-action--restart"
                          onPointerUp={(e) => {
                            e.stopPropagation();
                            setLogsFor(c);
                          }}
                          onClick={(e) => {
                            e.stopPropagation();
                            setLogsFor(c);
                          }}
                        >
                          Logs
                        </button>
                        {canUseTerminal && (running || paused) && (
                          <button
                            type="button"
                            className="dk-action dk-action--start"
                            onPointerUp={(e) => {
                              e.stopPropagation();
                              setTermFor(c);
                            }}
                            onClick={(e) => {
                              e.stopPropagation();
                              setTermFor(c);
                            }}
                          >
                            Console
                          </button>
                        )}
                      </div>
                      <div className="dk-card-secondary">
                        {(running || paused) && !paused ? (
                          <>
                            <button
                              type="button"
                              className="dk-link-action"
                              disabled={busy}
                              onClick={() => runAction(c.id, "restart")}
                            >
                              Restart
                            </button>
                            <button
                              type="button"
                              className="dk-link-action"
                              disabled={busy}
                              onClick={() => runAction(c.id, "pause")}
                            >
                              Pause
                            </button>
                          </>
                        ) : null}
                        <button
                          type="button"
                          className="dk-link-action dk-link-action--danger"
                          disabled={busy}
                          onClick={() => runAction(c.id, "remove")}
                        >
                          Remove
                        </button>
                      </div>
                    </footer>
                  </article>
                );
              })
            )}
          </div>
        </>
      ) : null}

      {tab === "volumes" ? (
        <div className="dk-list dk-list--cards dk-list--volumes">
          {!volumes.length ? (
            <div className="dk-empty">No volumes</div>
          ) : (
            volumes.map((vol) => (
              <article
                className={`dk-card dk-card--volume${vol.inUse ? " is-used" : " is-free"}`}
                key={vol.name}
              >
                <header className="dk-card-head">
                  <h3 className="dk-card-name" title={vol.name}>
                    {vol.name}
                  </h3>
                  <span className={`dk-state ${vol.inUse ? "dk-state--running" : "dk-state--stopped"}`}>
                    {vol.inUse ? "in use" : "unused"}
                  </span>
                </header>

                <div className="dk-card-body">
                  <div className="dk-kv">
                    <span className="dk-kv-label">Driver</span>
                    <span className="dk-kv-value">{vol.driver || "—"}</span>
                  </div>
                  <div className="dk-kv">
                    <span className="dk-kv-label">Mount</span>
                    <span className="dk-kv-value dk-kv-value--path" title={vol.mountpoint}>
                      {vol.mountpoint || "—"}
                    </span>
                  </div>
                </div>

                <footer className="dk-card-foot">
                  <button
                    type="button"
                    className="dk-action dk-action--stop dk-action--block"
                    disabled={busyId === `vol:${vol.name}`}
                    onClick={() => removeVolume(vol.name, vol.inUse)}
                  >
                    {busyId === `vol:${vol.name}` ? "Deleting…" : "Delete volume"}
                  </button>
                </footer>
              </article>
            ))
          )}
        </div>
      ) : null}

      {tab === "maintenance" ? (
        <div className="dk-maint">
          <div className="dk-maint__card">
            <div className="dk-maint__title">Prune unused images</div>
            <p className="dk-maint__hint">
              Removes dangling and unused images on this Docker host. Containers and tagged images in
              use are kept.
            </p>
            <button
              type="button"
              className="dk-action dk-action--restart"
              disabled={pruneBusy}
              onClick={() => void pruneImages()}
            >
              {pruneBusy ? "Pruning…" : "Prune images"}
            </button>
            {pruneMsg ? <div className="dk-maint__result">{pruneMsg}</div> : null}
          </div>
        </div>
      ) : null}

      {error ? <div className="dk-inst-error">{error}</div> : null}

      {logsFor ? (
        <DockerLogsModal
          instanceId={instanceId}
          containerId={logsFor.id}
          containerName={logsFor.name}
          onClose={() => setLogsFor(null)}
        />
      ) : null}
      {termFor ? (
        <DockerTermModal
          instanceId={instanceId}
          containerId={termFor.id}
          containerName={termFor.name}
          onClose={() => setTermFor(null)}
        />
      ) : null}
    </div>
  );
}
