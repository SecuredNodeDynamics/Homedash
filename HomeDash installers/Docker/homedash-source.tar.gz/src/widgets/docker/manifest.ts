import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "docker",
  name: "Docker",
  description: "Containers, console, volumes, and image prune",
  version: "0.3.8",
  category: "Infra",
  defaultSize: { w: 4, h: 7, minW: 3, minH: 5 },
  hostClass: "docker-host",
  configFields: [
    {
      key: "provider",
      label: "Provider",
      type: "select",
      options: [
        { value: "engine", label: "Docker Engine" },
        { value: "portainer", label: "Portainer" },
      ],
    },
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "http://10.0.0.1:2375",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      placeholder: "https://docker.example.com",
    },
    {
      key: "publicUrl",
      label: "OPEN - Private URL",
      type: "url",
      placeholder: "http://10.0.0.1:2375",
    },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    {
      key: "apiKey",
      label: "API Key",
      type: "password",
      placeholder: "Required for Portainer; optional for Engine proxy",
    },
    {
      key: "endpointId",
      label: "Portainer endpoint ID",
      type: "text",
      placeholder: "1",
    },
  ],
};
