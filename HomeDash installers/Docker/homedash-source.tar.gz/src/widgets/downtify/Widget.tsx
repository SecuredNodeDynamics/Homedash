"use client";
import "@/styles/widgets/downtify.widget.css";


import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";
import { songCover, statusClass, type DowntifySong } from "@/lib/widgets/downtify-media";

type Tab = "overview" | "recent" | "library" | "search";
type LibraryView = "artists" | "albums" | "tracks";
type SearchMode = "albums" | "tracks";

type StatusPayload = {
  href: string;
  openFallbackUrl?: string;
  summary: Record<string, unknown> | null;
  queue: DowntifySong[];
  history: DowntifySong[];
  capabilities: Record<string, unknown> | null;
  health: Record<string, unknown> | null;
  monitor: Array<Record<string, unknown>>;
  coreOnline: boolean;
  coreErrors: number;
  historyOk?: boolean;
  connectionSource?: ConnectionSource;
  error?: string;
};

type ConnectionSource = "private" | "public" | "unknown";

const CONNECTION_SOURCE_LABEL: Record<ConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

type LibraryGroup = {
  name: string;
  kind: "artist" | "album";
  count: number;
  cover: string;
  artist?: string;
  monitored?: boolean;
  albumCount?: number;
  albums?: Array<{ name: string; cover: string; count: number }>;
};

type PopupState =
  | { kind: "track"; item: DowntifySong }
  | { kind: "media"; item: LibraryGroup }
  | null;

const TABS: Array<{ key: Tab; label: string }> = [
  { key: "overview", label: "Overview" },
  { key: "recent", label: "Recent" },
  { key: "library", label: "Library" },
  { key: "search", label: "Search" },
];

const SEARCH_LIMIT = 12;

function normText(value: unknown) {
  return String(value || "")
    .replace(/\s+/g, " ")
    .trim();
}

function songTitle(item: DowntifySong) {
  return item?.title || item?.name || item?.song?.title || item?.song?.name || "Unknown track";
}

function songArtists(item: DowntifySong) {
  const fromSong = item?.song?.artists || item?.song?.artist;
  const artists = item?.artists || item?.artist || fromSong;
  if (Array.isArray(artists)) return artists.filter(Boolean).join(", ");
  return String(artists || "");
}

function songAlbum(item: DowntifySong) {
  return item?.album || item?.album_name || item?.song?.album || item?.song?.album_name || "";
}

function songStatus(item: DowntifySong) {
  return String(item?.status || "unknown");
}

function songUrl(item: DowntifySong) {
  const song = item?.song || item || {};
  if (song.url || song.source_url || item?.url || item?.source_url) {
    return String(song.url || song.source_url || item?.url || item?.source_url || "");
  }
  const videoId = song.videoId || song.video_id || item?.videoId || item?.video_id;
  if (videoId) return `https://music.youtube.com/watch?v=${encodeURIComponent(String(videoId))}`;
  const browseId = song.browse_id || song.browseId || item?.browse_id || item?.browseId;
  if (browseId) return `https://music.youtube.com/browse/${encodeURIComponent(String(browseId))}`;
  return "";
}

function songFile(item: DowntifySong) {
  const song = item?.song || item || {};
  return String(
    item?.filename ||
      item?.file ||
      (item as { path?: string }).path ||
      song.filename ||
      song.file ||
      (song as { path?: string }).path ||
      "",
  );
}

function songType(item: DowntifySong) {
  const song = item?.song || item || {};
  const type = String(song.media_type || song.type || item?.media_type || item?.type || "track").toLowerCase();
  if (type.includes("album")) return "album";
  if (type.includes("artist")) return "artist";
  if (type.includes("playlist")) return "playlist";
  return "track";
}

function firstNumber(...values: unknown[]) {
  for (const value of values) {
    const n = typeof value === "number" ? value : Number(value);
    if (Number.isFinite(n) && n > 0) return n;
  }
  return 0;
}

function fmtBytes(bytes: number) {
  if (!bytes || bytes <= 0) return "-";
  if (bytes >= 1e12) return `${(bytes / 1e12).toFixed(2)} TB`;
  if (bytes >= 1e9) return `${(bytes / 1e9).toFixed(2)} GB`;
  if (bytes >= 1e6) return `${(bytes / 1e6).toFixed(1)} MB`;
  if (bytes >= 1e3) return `${(bytes / 1e3).toFixed(0)} KB`;
  return `${bytes} B`;
}

function fmtDate(value?: string) {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

function libraryKey(title: string, artists: string, album = "") {
  return [title, artists, album].map((v) => normText(v).toLowerCase()).join("|");
}

function libraryIndex(library: DowntifySong[]) {
  const tracks = new Set<string>();
  const artists = new Set<string>();
  const albums = new Set<string>();
  for (const item of library || []) {
    const title = songTitle(item);
    const artist = songArtists(item);
    const album = songAlbum(item);
    if (title && artist) tracks.add(libraryKey(title, artist, album));
    if (artist) {
      artist
        .split(",")
        .map(normText)
        .filter(Boolean)
        .forEach((v) => artists.add(v.toLowerCase()));
    }
    if (album) albums.add(libraryKey(album, artist));
  }
  return { tracks, artists, albums };
}

function isOwned(item: DowntifySong, index: ReturnType<typeof libraryIndex>) {
  const type = songType(item);
  const title = songTitle(item);
  const artist = songArtists(item);
  const album = songAlbum(item);
  if (type === "album") {
    return index.albums.has(libraryKey(title || album, artist)) || index.albums.has(libraryKey(album, artist));
  }
  if (type === "artist") return index.artists.has(normText(title || artist).toLowerCase());
  return index.tracks.has(libraryKey(title, artist, album));
}

function groupedMedia(
  items: DowntifySong[],
  keyFn: (item: DowntifySong) => string,
  kind: "artist" | "album",
  instanceId: string,
): LibraryGroup[] {
  const groups = new Map<string, LibraryGroup & { albumsMap: Map<string, { name: string; cover: string; count: number }> }>();
  for (const item of items || []) {
    const name = normText(keyFn(item));
    if (!name) continue;
    const key = name.toLowerCase();
    const current =
      groups.get(key) ||
      ({
        name,
        kind,
        count: 0,
        cover: "",
        albumsMap: new Map(),
      } as LibraryGroup & { albumsMap: Map<string, { name: string; cover: string; count: number }> });
    current.count += 1;
    if (!current.artist) current.artist = songArtists(item);
    const albumName = songAlbum(item);
    if (albumName) {
      const albumKey = albumName.toLowerCase();
      const album = current.albumsMap.get(albumKey) || { name: albumName, cover: "", count: 0 };
      album.count += 1;
      if (!album.cover) album.cover = songCover(item, instanceId, 200);
      current.albumsMap.set(albumKey, album);
    }
    if (!current.cover) current.cover = songCover(item, instanceId, 240);
    groups.set(key, current);
  }
  return Array.from(groups.values())
    .map((item) => {
      const albums = Array.from(item.albumsMap.values()).sort((a, b) => a.name.localeCompare(b.name));
      return {
        name: item.name,
        kind: item.kind,
        count: item.count,
        cover: item.cover,
        artist: item.artist,
        albumCount: albums.length,
        albums,
      };
    })
    .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
}

function clientId() {
  const key = "downtify_homedash_client_id";
  try {
    let id = localStorage.getItem(key);
    if (!id) {
      id = `homedash-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
      localStorage.setItem(key, id);
    }
    return id;
  } catch {
    return "homedash-widget";
  }
}

function MusicIcon({ size = 17 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden>
      <path d="M9 18V5l12-2v13" />
      <circle cx="6" cy="18" r="3" />
      <circle cx="18" cy="16" r="3" />
    </svg>
  );
}

function ConnectionCorner({ source }: { source: ConnectionSource }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const mark = (
    <div
      className={`downtify-corner-source downtify-corner-source--${source}`}
      title={CONNECTION_SOURCE_LABEL[source]}
      aria-label={CONNECTION_SOURCE_LABEL[source]}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}

function Cover({
  src,
  alt,
  className,
  missingClass,
  children,
}: {
  src: string;
  alt: string;
  className: string;
  missingClass?: string;
  children?: ReactNode;
}) {
  const [missing, setMissing] = useState(!src);
  useEffect(() => {
    setMissing(!src);
  }, [src]);
  const miss = missingClass || `${className.trim().split(/\s+/)[0]}--missing`;
  return (
    <div className={`${className}${missing || !src ? ` ${miss}` : ""}`}>
      {src && !missing ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={src} alt={alt} loading="lazy" decoding="async" onError={() => setMissing(true)} />
      ) : (
        <div className="downtify-song-placeholder">
          <MusicIcon />
        </div>
      )}
      {children}
    </div>
  );
}

export default function DowntifyWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "downtify";
  const [data, setData] = useState<StatusPayload | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<Tab>("overview");
  const [library, setLibrary] = useState<DowntifySong[]>([]);
  const [libraryLoading, setLibraryLoading] = useState(false);
  const [libraryView, setLibraryView] = useState<LibraryView>("artists");
  const [searchMode, setSearchMode] = useState<SearchMode>("albums");
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<DowntifySong[]>([]);
  const [searchMessage, setSearchMessage] = useState("");
  const [searchLoading, setSearchLoading] = useState(false);
  const [downloadBusy, setDownloadBusy] = useState<number | null>(null);
  const [popup, setPopup] = useState<PopupState>(null);
  const sliderRef = useRef<HTMLDivElement | null>(null);
  const overviewSliderRef = useRef<HTMLDivElement | null>(null);
  const libraryRef = useRef<DowntifySong[]>([]);
  libraryRef.current = library;

  const href = data?.href || "";
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);

  const load = useCallback(async () => {
    try {
      const response = await fetch(
        `/api/widgets/downtify/status?instance=${encodeURIComponent(instanceId)}`,
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load Downtify");
      setData(json);
      setError(json.coreOnline ? "" : String(json.error || ""));
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Failed to load Downtify");
    } finally {
      setLoading(false);
    }
  }, [instanceId]);

  const loadLibrary = useCallback(async (force = false) => {
    if (libraryRef.current.length && !force) return libraryRef.current;
    setLibraryLoading(true);
    try {
      const response = await fetch("/api/widgets/downtify/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, action: "library" }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Library failed");
      const items = Array.isArray(json.library) ? (json.library as DowntifySong[]) : [];
      setLibrary(items);
      return items;
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : "Library failed";
      setError(message);
      return libraryRef.current;
    } finally {
      setLibraryLoading(false);
    }
  }, [instanceId]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: 45_000 });

  useEffect(() => {
    if (tab === "library" || tab === "search") {
      void loadLibrary();
    }
  }, [tab, loadLibrary]);

  useEffect(() => {
    if (!popup) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setPopup(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [popup]);

  const recentItems = useMemo(
    () =>
      (data?.history || [])
        .filter((item) => {
          const status = songStatus(item).toLowerCase();
          return ["done", "completed", "ok", "skipped", "error", "failed"].includes(status) || status === "unknown";
        })
        .slice(0, 25),
    [data?.history],
  );

  const monitored = useMemo(() => {
    return new Set(
      (data?.monitor || [])
        .filter((item) => String(item?.kind || "").toLowerCase() === "artist" && item.enabled !== false)
        .map((item) => normText(item?.name).toLowerCase())
        .filter(Boolean),
    );
  }, [data?.monitor]);

  const recentArtists = useMemo(() => {
    const order: string[] = [];
    const groups = new Map<
      string,
      {
        name: string;
        cover: string;
        count: number;
        latestDate: string;
        latestStatus: string;
        albumsMap: Map<string, { name: string; cover: string; count: number }>;
      }
    >();

    for (const item of recentItems) {
      const name = normText(songArtists(item).split(",")[0] || "");
      if (!name) continue;
      const key = name.toLowerCase();
      let current = groups.get(key);
      if (!current) {
        order.push(key);
        current = {
          name,
          cover: "",
          count: 0,
          latestDate: "",
          latestStatus: songStatus(item),
          albumsMap: new Map(),
        };
        groups.set(key, current);
      }
      current.count += 1;
      if (!current.cover) current.cover = songCover(item, instanceId, 240);
      if (!current.latestDate) {
        current.latestDate = fmtDate(item?.completed_at || item?.updated_at || item?.created_at);
      }
      const albumName = songAlbum(item);
      if (albumName) {
        const albumKey = albumName.toLowerCase();
        const album = current.albumsMap.get(albumKey) || { name: albumName, cover: "", count: 0 };
        album.count += 1;
        if (!album.cover) album.cover = songCover(item, instanceId, 200);
        current.albumsMap.set(albumKey, album);
      }
    }

    return order.map((key) => {
      const item = groups.get(key)!;
      const albums = Array.from(item.albumsMap.values()).sort((a, b) => a.name.localeCompare(b.name));
      return {
        name: item.name,
        kind: "artist" as const,
        count: item.count,
        cover: item.cover,
        albumCount: albums.length,
        albums,
        latestDate: item.latestDate,
        latestStatus: item.latestStatus,
        monitored: monitored.has(key),
      };
    });
  }, [recentItems, instanceId, monitored]);

  const ownedIndex = useMemo(() => libraryIndex(library), [library]);

  const libraryArtists = useMemo(() => {
    return groupedMedia(library, (item) => songArtists(item).split(",")[0] || "", "artist", instanceId).map(
      (item) => ({ ...item, monitored: monitored.has(item.name.toLowerCase()) }),
    );
  }, [library, instanceId, monitored]);

  const libraryAlbums = useMemo(
    () => groupedMedia(library, (item) => songAlbum(item), "album", instanceId),
    [library, instanceId],
  );

  const overviewStats = useMemo(() => {
    const summary = (data?.summary || {}) as Record<string, any>;
    const health = (data?.health || {}) as Record<string, any>;
    const queue = data?.queue || [];
    const libraryStats = summary.counts?.library || {};
    const queueSummary = summary.counts?.queue || {};
    const downloadsStorage = summary.storage?.downloads || health.downloads || {};
    const tools = summary.tools || health.tools || {};
    const libraryTotal = firstNumber(
      libraryStats.tracks,
      downloadsStorage.audio_count,
      downloadsStorage.file_count,
    );
    const artists = firstNumber(libraryStats.artists);
    const albums = firstNumber(libraryStats.albums);
    const size = downloadsStorage.size_bytes || 0;
    const freeBytes = firstNumber(
      downloadsStorage.free_bytes,
      downloadsStorage.available_bytes,
      downloadsStorage.free,
      downloadsStorage.available,
      downloadsStorage.disk?.free_bytes,
      downloadsStorage.disk?.available_bytes,
    );
    const reportedTotalBytes = firstNumber(
      downloadsStorage.total_bytes,
      downloadsStorage.capacity_bytes,
      downloadsStorage.total,
      downloadsStorage.capacity,
      downloadsStorage.disk?.total_bytes,
      downloadsStorage.disk?.capacity_bytes,
    );
    const totalBytes = reportedTotalBytes || (freeBytes ? size + freeBytes : 0);
    const storagePercent = totalBytes ? Math.min(100, Math.max(0, Math.round((size / totalBytes) * 100))) : 0;
    const storageMeterWidth = totalBytes ? Math.max(4, storagePercent) : 100;
    const storageTitle = totalBytes ? `${fmtBytes(size)} of ${fmtBytes(totalBytes)} used` : `${fmtBytes(size)} used`;
    const storageSub = totalBytes && freeBytes ? `${fmtBytes(freeBytes)} available` : "Storage";
    const librarySizeGb = size > 0 ? `${(size / 1e9).toFixed(size >= 1e10 ? 1 : 2)} GB` : "-";
    const ffmpegReady = tools.ffmpeg?.available ?? data?.capabilities?.ffmpeg;
    const ytDlpReady = tools.yt_dlp?.available;
    const readyTools = [ffmpegReady, ytDlpReady].filter(Boolean).length;
    const knownTools = [ffmpegReady, ytDlpReady].filter((value) => value !== undefined && value !== null).length;
    const toolsValue = knownTools ? `${readyTools}/2` : "-";
    const hasHealth = !!(data?.summary || data?.health);
    return {
      libraryTotal,
      artists,
      albums,
      queueCount: firstNumber(queueSummary.total, queue.length),
      toolsValue,
      librarySizeGb,
      storageTitle,
      storageSub,
      storagePercent,
      storageMeterWidth,
      totalBytes,
      ffmpegReady,
      ytDlpReady,
      readyTools,
      knownTools,
      hasHealth,
    };
  }, [data]);

  async function performSearch(query: string, mode: SearchMode = searchMode) {
    const q = normText(query);
    setSearchQuery(q);
    setSearchMode(mode);
    setSearchResults([]);
    if (q.length < 2) {
      setSearchMessage("Type at least 2 characters");
      return;
    }
    setSearchLoading(true);
    setSearchMessage("");
    try {
      const response = await fetch("/api/widgets/downtify/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, action: "search", query: q }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Search failed");
      const results = (Array.isArray(json.results) ? json.results : []) as DowntifySong[];
      const filtered = results
        .filter((item) => {
          const type = songType(item);
          return mode === "albums" ? type === "album" : type === "track";
        })
        .slice(0, SEARCH_LIMIT);
      setSearchResults(filtered);
      setSearchMessage(filtered.length ? "" : "No matches found");
    } catch (cause) {
      setSearchMessage(cause instanceof Error ? cause.message : "Search failed");
    } finally {
      setSearchLoading(false);
    }
  }

  async function requestDownload(item: DowntifySong, index: number) {
    setDownloadBusy(index);
    try {
      const response = await fetch("/api/widgets/downtify/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          instance: instanceId,
          action: "download",
          item,
          clientId: clientId(),
        }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Request failed");
      setSearchMessage(json.message || `Queued ${songTitle(item)}`);
      void load();
    } catch (cause) {
      setSearchMessage(cause instanceof Error ? cause.message : "Request failed");
    } finally {
      setDownloadBusy(null);
    }
  }

  function toolPill(available: unknown) {
    if (available === undefined || available === null) {
      return <span className="downtify-pill downtify-pill--muted">checking</span>;
    }
    return (
      <span className={`downtify-pill ${available ? "downtify-pill--ok" : "downtify-pill--warn"}`}>
        {available ? "ready" : "missing"}
      </span>
    );
  }

  const status = !data
    ? { cls: "downtify-pill--muted", txt: "Offline" }
    : data.coreOnline
      ? { cls: "downtify-pill--ok", txt: "Online" }
      : { cls: "downtify-pill--warn", txt: "Offline" };
  const connectionSource: ConnectionSource = data?.connectionSource || "unknown";

  if (loading && !data) {
    return (
      <div className="hd-widget-body downtify-body-flat" ref={rootRef}>
        <div className="downtify-shell">
          <div className="downtify-empty">
            <div>Loading Downtify…</div>
          </div>
        </div>
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="hd-widget-body downtify-body-flat" ref={rootRef}>
        <div className="downtify-shell">
          <div className="downtify-toolbar">
            <span className={`downtify-pill ${status.cls}`}>{status.txt}</span>
            <button className="downtify-open-btn" type="button" onClick={load}>
              Retry
            </button>
          </div>
          <div className="downtify-empty" style={{ color: "#f87171" }}>
            <div>{error}</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="hd-widget-body downtify-body-flat" ref={rootRef}>
      <ConnectionCorner source={connectionSource} />
      <div className="downtify-shell">
        <div className="downtify-toolbar">
          <div className="downtify-toolbar-left">
            <span className={`downtify-pill ${status.cls}`}>{status.txt}</span>
          </div>
          <div className="downtify-toolbar-right">
            {openHref ? (
              <a className="downtify-open-btn" href={openHref} target="_blank" rel="noopener noreferrer">
                Open
              </a>
            ) : null}
          </div>
        </div>

        <div className="downtify-tabs" role="tablist">
          {TABS.map((item) => (
            <button
              key={item.key}
              type="button"
              role="tab"
              aria-selected={tab === item.key}
              className={`downtify-tab${tab === item.key ? " downtify-tab--active" : ""}`}
              onClick={() => setTab(item.key)}
            >
              {item.label}
            </button>
          ))}
        </div>

        <div className="downtify-panel">
          {tab === "overview" ? (
            <div className="downtify-panel-scroll">
              <div className="downtify-overview">
                <div className="downtify-overview-hero">
                  <div className="downtify-overview-orb">
                    <MusicIcon size={28} />
                  </div>
                  <div className="downtify-overview-copy">
                    <div className="downtify-section-label">Library</div>
                    <div className="downtify-overview-total">
                      {overviewStats.libraryTotal.toLocaleString()}
                    </div>
                    <div className="downtify-muted">
                      {overviewStats.artists.toLocaleString()} artists ·{" "}
                      {overviewStats.albums.toLocaleString()} albums
                    </div>
                  </div>
                </div>
                <div className="downtify-overview-stats">
                  <div className="downtify-overview-stat">
                    <div className="downtify-overview-stat-icon">
                      <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                        <path d="M8 6h13" />
                        <path d="M8 12h13" />
                        <path d="M8 18h13" />
                        <path d="M3 6h.01" />
                        <path d="M3 12h.01" />
                        <path d="M3 18h.01" />
                      </svg>
                    </div>
                    <div>
                      <div className="downtify-stat-num">{overviewStats.queueCount.toLocaleString()}</div>
                      <div className="downtify-stat-label">Queue</div>
                    </div>
                  </div>
                  <div className="downtify-overview-stat">
                    <div className="downtify-overview-stat-icon">
                      <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                        <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.3-3.3a5 5 0 0 1-6.7 6.7L7 20l-3-3 7.3-7.3a5 5 0 0 1 6.7-6.7l-3.3 3.3z" />
                      </svg>
                    </div>
                    <div>
                      <div className="downtify-stat-num">{overviewStats.toolsValue}</div>
                      <div className="downtify-stat-label">Tools Ready</div>
                    </div>
                  </div>
                  <div className="downtify-overview-stat">
                    <div className="downtify-overview-stat-icon">
                      <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                        <ellipse cx="12" cy="5" rx="9" ry="3" />
                        <path d="M3 5v14c0 1.7 4 3 9 3s9-1.3 9-3V5" />
                        <path d="M3 12c0 1.7 4 3 9 3s9-1.3 9-3" />
                      </svg>
                    </div>
                    <div>
                      <div className="downtify-stat-num">{overviewStats.librarySizeGb}</div>
                      <div className="downtify-stat-label">Library Size</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="downtify-overview-grid">
                <div className="downtify-mini-panel downtify-storage-panel">
                  <div className="downtify-panel-head">
                    <div>
                      <div className="downtify-section-label">Storage</div>
                      <div className="downtify-panel-title">{overviewStats.storageTitle}</div>
                      <div className="downtify-muted">{overviewStats.storageSub}</div>
                    </div>
                    <span
                      className={`downtify-pill ${overviewStats.totalBytes ? "downtify-pill--active" : "downtify-pill--muted"}`}
                    >
                      {overviewStats.totalBytes ? `${overviewStats.storagePercent}% used` : "used"}
                    </span>
                  </div>
                  <div className="downtify-queue-meter">
                    <span style={{ width: `${overviewStats.storageMeterWidth}%` }} />
                  </div>
                </div>
                <div className="downtify-mini-panel downtify-system-panel">
                  <div className="downtify-panel-head">
                    <div>
                      <div className="downtify-section-label">System</div>
                      <div className="downtify-panel-title">
                        {overviewStats.knownTools
                          ? overviewStats.readyTools === 2
                            ? "Ready to download"
                            : overviewStats.hasHealth
                              ? "Needs attention"
                              : "Checking tools"
                          : "Checking tools"}
                      </div>
                    </div>
                  </div>
                  <div className="downtify-tool-grid">
                    <div className="downtify-tool-chip">
                      <span>ffmpeg</span>
                      {toolPill(overviewStats.ffmpegReady)}
                    </div>
                    <div className="downtify-tool-chip">
                      <span>yt-dlp</span>
                      {toolPill(overviewStats.ytDlpReady)}
                    </div>
                  </div>
                </div>
              </div>

              {recentItems.length ? (
                <div className="downtify-slider-shell downtify-section-spaced">
                  <div className="downtify-slider-head">
                    <div>
                      <div className="downtify-panel-title">Latest completed tracks</div>
                    </div>
                    <div className="downtify-slider-actions">
                      <button
                        className="downtify-slider-btn downtify-slider-btn--left"
                        type="button"
                        aria-label="Scroll recent downloads left"
                        onClick={() =>
                          overviewSliderRef.current?.scrollBy({ left: -240, behavior: "smooth" })
                        }
                      >
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="m15 18-6-6 6-6" />
                        </svg>
                      </button>
                      <button
                        className="downtify-slider-btn downtify-slider-btn--right"
                        type="button"
                        aria-label="Scroll recent downloads right"
                        onClick={() =>
                          overviewSliderRef.current?.scrollBy({ left: 240, behavior: "smooth" })
                        }
                      >
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="m9 18 6-6-6-6" />
                        </svg>
                      </button>
                    </div>
                  </div>
                  <div className="downtify-track-slider" ref={overviewSliderRef}>
                    {recentItems.map((item, index) => {
                      const statusLabel = songStatus(item);
                      const title = songTitle(item);
                      const meta = [
                        songArtists(item),
                        songAlbum(item),
                        fmtDate(item?.completed_at || item?.updated_at || item?.created_at),
                      ]
                        .filter(Boolean)
                        .join(" · ");
                      return (
                        <button
                          key={`${title}-${index}`}
                          className="downtify-track-card"
                          type="button"
                          style={{ animationDelay: `${index * 25}ms` }}
                          onClick={() => setPopup({ kind: "track", item })}
                        >
                          <Cover src={songCover(item, instanceId, 200)} alt={title} className="downtify-track-card__art">
                            <div className="downtify-track-card__shade" />
                            <span className={`downtify-track-card__pill ${statusClass(statusLabel)}`}>
                              {statusLabel}
                            </span>
                          </Cover>
                          <div className="downtify-track-card__meta">
                            <div className="downtify-track-card__title">{title}</div>
                            <div className="downtify-track-card__sub">{meta}</div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ) : null}

              {data?.coreErrors ? (
                <div className="downtify-footer-note">
                  {data.coreErrors} core endpoint{data.coreErrors === 1 ? "" : "s"} unavailable
                </div>
              ) : null}
            </div>
          ) : null}

          {tab === "recent" ? (
            <div className="downtify-panel-scroll">
              {recentArtists.length ? (
                <div className="downtify-slider-shell">
                  <div className="downtify-slider-head">
                    <div>
                      <div className="downtify-section-label">Recent Artists</div>
                      <div className="downtify-panel-title">
                        {recentArtists.length.toLocaleString()} latest artists from downloads
                      </div>
                    </div>
                    <div className="downtify-slider-actions">
                      <button
                        className="downtify-slider-btn downtify-slider-btn--left"
                        type="button"
                        aria-label="Scroll recent artists left"
                        onClick={() => sliderRef.current?.scrollBy({ left: -240, behavior: "smooth" })}
                      >
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="m15 18-6-6 6-6" />
                        </svg>
                      </button>
                      <button
                        className="downtify-slider-btn downtify-slider-btn--right"
                        type="button"
                        aria-label="Scroll recent artists right"
                        onClick={() => sliderRef.current?.scrollBy({ left: 240, behavior: "smooth" })}
                      >
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="m9 18 6-6-6-6" />
                        </svg>
                      </button>
                    </div>
                  </div>
                  <div className="downtify-track-slider" ref={sliderRef}>
                    {recentArtists.map((artist, index) => {
                      const meta = [
                        `${artist.count.toLocaleString()} track${artist.count === 1 ? "" : "s"}`,
                        artist.albumCount
                          ? `${artist.albumCount.toLocaleString()} album${artist.albumCount === 1 ? "" : "s"}`
                          : "",
                        artist.latestDate,
                      ]
                        .filter(Boolean)
                        .join(" · ");
                      const full =
                        libraryArtists.find((item) => item.name.toLowerCase() === artist.name.toLowerCase()) ||
                        artist;
                      return (
                        <button
                          key={artist.name}
                          className="downtify-track-card"
                          type="button"
                          style={{ animationDelay: `${index * 25}ms` }}
                          onClick={() => setPopup({ kind: "media", item: full })}
                        >
                          <Cover
                            src={artist.cover}
                            alt={artist.name}
                            className="downtify-track-card__art downtify-track-card__art--artist"
                          >
                            <div className="downtify-track-card__shade" />
                            <span className="downtify-track-card__pill downtify-pill--ok">artist</span>
                          </Cover>
                          <div className="downtify-track-card__meta">
                            <div className="downtify-track-card__title">{artist.name}</div>
                            <div className="downtify-track-card__sub">{meta}</div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <div className="downtify-empty">
                  <div>
                    {data?.historyOk === false
                      ? "Could not load download history. Check the Downtify username and password in widget settings."
                      : "No download history yet"}
                  </div>
                </div>
              )}
            </div>
          ) : null}

          {tab === "library" ? (
            <div className="downtify-library-shell">
              <div className="downtify-library-head">
                <div className="downtify-library-tabs" role="tablist">
                  {(
                    [
                      { key: "artists", label: "Artists", count: libraryArtists.length },
                      { key: "albums", label: "Albums", count: libraryAlbums.length },
                      { key: "tracks", label: "Tracks", count: library.length },
                    ] as const
                  ).map((view) => (
                    <button
                      key={view.key}
                      className={`downtify-library-tab${libraryView === view.key ? " downtify-library-tab--active" : ""}`}
                      type="button"
                      role="tab"
                      aria-selected={libraryView === view.key}
                      onClick={() => setLibraryView(view.key)}
                    >
                      {view.label} <strong>{view.count.toLocaleString()}</strong>
                    </button>
                  ))}
                </div>
              </div>
              <div className="downtify-library-scrollbox">
                {libraryLoading && !library.length ? (
                  <div className="downtify-empty">
                    <div>Loading library…</div>
                  </div>
                ) : !library.length ? (
                  <div className="downtify-empty">
                    <div>
                      {error || "No library files found"}
                    </div>
                  </div>
                ) : (
                  <>
                    <div
                      className={`downtify-library-panel${libraryView === "artists" ? " is-active" : ""}`}
                    >
                      <div className="downtify-library-grid downtify-library-grid--artists">
                        {libraryArtists.map((item, index) => (
                          <div
                            key={item.name}
                            className="downtify-library-card"
                            role="button"
                            tabIndex={0}
                            style={{ animationDelay: `${index * 18}ms` }}
                            onClick={() => setPopup({ kind: "media", item })}
                            onKeyDown={(event) => {
                              if (event.key === "Enter" || event.key === " ") {
                                event.preventDefault();
                                setPopup({ kind: "media", item });
                              }
                            }}
                          >
                            {item.monitored ? (
                              <span className="downtify-library-monitor-eye" title="Monitored artist">
                                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4">
                                  <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z" />
                                  <circle cx="12" cy="12" r="3" />
                                </svg>
                              </span>
                            ) : null}
                            <Cover
                              src={item.cover}
                              alt={item.name}
                              className="downtify-library-card__art downtify-library-card__art--artist"
                              missingClass="downtify-media-art--missing"
                            />
                            <div className="downtify-library-card__name">{item.name}</div>
                            <div className="downtify-library-card__meta">
                              {item.count.toLocaleString()} track{item.count === 1 ? "" : "s"}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div
                      className={`downtify-library-panel${libraryView === "albums" ? " is-active" : ""}`}
                    >
                      <div className="downtify-library-grid">
                        {libraryAlbums.map((item, index) => (
                          <div
                            key={`${item.name}-${item.artist || ""}`}
                            className="downtify-library-card"
                            role="button"
                            tabIndex={0}
                            style={{ animationDelay: `${index * 18}ms` }}
                            onClick={() => setPopup({ kind: "media", item })}
                            onKeyDown={(event) => {
                              if (event.key === "Enter" || event.key === " ") {
                                event.preventDefault();
                                setPopup({ kind: "media", item });
                              }
                            }}
                          >
                            <Cover
                              src={item.cover}
                              alt={item.name}
                              className="downtify-library-card__art"
                              missingClass="downtify-media-art--missing"
                            />
                            <div className="downtify-library-card__name">{item.name}</div>
                            <div className="downtify-library-card__meta">
                              {item.count.toLocaleString()} song{item.count === 1 ? "" : "s"}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div
                      className={`downtify-library-panel${libraryView === "tracks" ? " is-active" : ""}`}
                    >
                      <div className="downtify-library-track-list">
                        {library.map((item, index) => {
                          const title = songTitle(item);
                          return (
                            <div
                              key={`${title}-${index}`}
                              className="downtify-library-track"
                              style={{ animationDelay: `${index * 14}ms` }}
                            >
                              <Cover
                                src={songCover(item, instanceId, 160)}
                                alt={title}
                                className="downtify-library-track__art"
                                missingClass="downtify-media-art--missing"
                              />
                              <div className="downtify-library-track__main">
                                <div className="downtify-library-track__title">{title}</div>
                                <div className="downtify-library-track__meta">
                                  {songArtists(item) || "Unknown artist"}
                                </div>
                              </div>
                              <div className="downtify-library-track__album">
                                {songAlbum(item) || "Unknown album"}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          ) : null}

          {tab === "search" ? (
            <div className="downtify-search-shell">
              <form
                className="downtify-search-form"
                onSubmit={(event) => {
                  event.preventDefault();
                  void performSearch(searchQuery, searchMode);
                }}
              >
                <div className="downtify-search-input-wrap">
                  <input
                    className="downtify-search-input"
                    type="search"
                    value={searchQuery}
                    placeholder="Search albums or tracks"
                    autoComplete="off"
                    onChange={(event) => setSearchQuery(event.target.value)}
                  />
                </div>
                <button className="downtify-search-submit" type="submit" disabled={searchLoading}>
                  Search
                </button>
              </form>
              <div className="downtify-search-modes">
                {(["albums", "tracks"] as SearchMode[]).map((mode) => (
                  <button
                    key={mode}
                    className={`downtify-mode-btn${searchMode === mode ? " downtify-mode-btn--active" : ""}`}
                    type="button"
                    onClick={() => void performSearch(searchQuery, mode)}
                  >
                    {mode}
                  </button>
                ))}
              </div>
              <div className="downtify-search-status">
                {searchLoading ? "Searching..." : searchMessage}
              </div>
              <div className="downtify-search-results">
                {searchResults.length
                  ? searchResults.map((item, index) => {
                      const type = songType(item);
                      const title = songTitle(item);
                      const artists = songArtists(item);
                      const album = songAlbum(item);
                      const url = songUrl(item);
                      const owned = isOwned(item, ownedIndex);
                      const trackCount = Number(
                        item?.track_count ||
                          (item as Record<string, unknown>).tracks_count ||
                          (item as Record<string, unknown>).song_count ||
                          (item as Record<string, unknown>).trackCount ||
                          0,
                      );
                      const bits = [type, artists, album, item?.year || item?.release_date || ""]
                        .filter(Boolean)
                        .join(" · ");
                      return (
                        <div
                          key={`${title}-${index}`}
                          className={`downtify-search-row${owned ? " downtify-search-row--owned" : ""}`}
                          style={{ animationDelay: `${index * 25}ms` }}
                        >
                          <Cover
                            src={songCover(item, instanceId, 160)}
                            alt={title}
                            className="downtify-search-card-art"
                            missingClass="downtify-media-art--missing"
                          />
                          <div className="downtify-search-card-body">
                            <div className="downtify-search-card-topline">
                              <div className="downtify-search-card-type">{type}</div>
                              {type === "album" && trackCount ? (
                                <div className="downtify-search-card-count">
                                  {trackCount.toLocaleString()} tracks
                                </div>
                              ) : null}
                            </div>
                            <div className="downtify-search-card-title">{title}</div>
                            <div className="downtify-search-card-meta">{bits}</div>
                          </div>
                          <div className="downtify-search-actions">
                            {owned ? <span className="downtify-pill downtify-pill--ok">owned</span> : null}
                            <button
                              className="downtify-action-btn"
                              type="button"
                              disabled={!url || owned || downloadBusy === index}
                              onClick={() => void requestDownload(item, index)}
                            >
                              {downloadBusy === index ? "Requesting..." : "Download"}
                            </button>
                          </div>
                        </div>
                      );
                    })
                  : !searchLoading && !searchMessage ? (
                      <div className="downtify-empty">
                        <div>Search for music to request downloads</div>
                      </div>
                    ) : null}
              </div>
            </div>
          ) : null}
        </div>
      </div>

      {popup && typeof document !== "undefined"
        ? createPortal(
            <>
              <div
                className="downtify-popup-backdrop is-open"
                onClick={() => setPopup(null)}
                aria-hidden
              />
              <section
                className="downtify-track-popup is-open"
                role="dialog"
                aria-modal="true"
                aria-label={popup.kind === "track" ? songTitle(popup.item) : popup.item.name}
              >
                {popup.kind === "track" ? (
                  <>
                    <div
                      className="downtify-track-popup__bg"
                      style={
                        songCover(popup.item, instanceId, 400)
                          ? { backgroundImage: `url(${JSON.stringify(songCover(popup.item, instanceId, 400))})` }
                          : undefined
                      }
                    />
                    <div className="downtify-track-popup__body">
                      <button
                        className="downtify-track-popup__close"
                        type="button"
                        aria-label="Close"
                        onClick={() => setPopup(null)}
                      >
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M18 6 6 18" />
                          <path d="m6 6 12 12" />
                        </svg>
                      </button>
                      <Cover
                        src={songCover(popup.item, instanceId, 400)}
                        alt={songTitle(popup.item)}
                        className="downtify-track-popup__art"
                        missingClass="downtify-media-art--missing"
                      />
                      <div className="downtify-track-popup__content">
                        <span className={`downtify-pill ${statusClass(songStatus(popup.item))}`}>
                          {songStatus(popup.item)}
                        </span>
                        <h3>{songTitle(popup.item)}</h3>
                        <div className="downtify-track-popup__meta-grid">
                          <div className="downtify-track-popup__meta-item">
                            <span>Artist</span>
                            <strong>{songArtists(popup.item) || "Unknown artist"}</strong>
                          </div>
                          <div className="downtify-track-popup__meta-item">
                            <span>Album</span>
                            <strong>{songAlbum(popup.item) || "Unknown album"}</strong>
                          </div>
                          {fmtDate(
                            popup.item?.completed_at || popup.item?.updated_at || popup.item?.created_at,
                          ) ? (
                            <div className="downtify-track-popup__meta-item">
                              <span>Added</span>
                              <strong>
                                {fmtDate(
                                  popup.item?.completed_at ||
                                    popup.item?.updated_at ||
                                    popup.item?.created_at,
                                )}
                              </strong>
                            </div>
                          ) : null}
                        </div>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <div
                      className="downtify-track-popup__bg"
                      style={
                        popup.item.cover
                          ? { backgroundImage: `url(${JSON.stringify(popup.item.cover)})` }
                          : undefined
                      }
                    />
                    <div className="downtify-track-popup__body">
                      <button
                        className="downtify-track-popup__close"
                        type="button"
                        aria-label="Close"
                        onClick={() => setPopup(null)}
                      >
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M18 6 6 18" />
                          <path d="m6 6 12 12" />
                        </svg>
                      </button>
                      {popup.item.kind === "artist" ? (
                        <div className="downtify-track-popup__artist-side">
                          <Cover
                            src={popup.item.cover}
                            alt={popup.item.name}
                            className="downtify-track-popup__art downtify-track-popup__art--artist"
                            missingClass="downtify-media-art--missing"
                          />
                          <div
                            className={`downtify-artist-monitor-bubble ${popup.item.monitored ? "is-monitored" : ""}`}
                          >
                            {popup.item.monitored ? "Monitored" : "Not monitored"}
                          </div>
                        </div>
                      ) : (
                        <Cover
                          src={popup.item.cover}
                          alt={popup.item.name}
                          className="downtify-track-popup__art"
                          missingClass="downtify-media-art--missing"
                        />
                      )}
                      <div className="downtify-track-popup__content">
                        <span className="downtify-pill downtify-pill--ok">
                          {popup.item.kind === "artist" ? "artist" : "album"}
                        </span>
                        <h3>{popup.item.name}</h3>
                        {popup.item.kind === "artist" ? (
                          <>
                            <div className="downtify-popup-section-title">
                              {(popup.item.albumCount || 0).toLocaleString()} downloaded album
                              {(popup.item.albumCount || 0) === 1 ? "" : "s"}
                            </div>
                            <div className="downtify-artist-album-grid">
                              {(popup.item.albums || []).map((album) => (
                                <div key={album.name} className="downtify-artist-album-card">
                                  <Cover
                                    src={album.cover}
                                    alt={album.name}
                                    className="downtify-artist-album-card__art"
                                    missingClass="downtify-media-art--missing"
                                  />
                                  <div className="downtify-artist-album-card__name">{album.name}</div>
                                  <div className="downtify-artist-album-card__meta">
                                    {Number(album.count || 0).toLocaleString()} track{album.count === 1 ? "" : "s"}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </>
                        ) : (
                          <div className="downtify-track-popup__meta-grid downtify-track-popup__meta-grid--equal">
                            <div className="downtify-track-popup__meta-item">
                              <span>Tracks</span>
                              <strong>{Number(popup.item.count || 0).toLocaleString()}</strong>
                            </div>
                            <div className="downtify-track-popup__meta-item">
                              <span>Artist</span>
                              <strong>{popup.item.artist || "Various artists"}</strong>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </>
                )}
              </section>
            </>,
            document.body,
          )
        : null}
    </div>
  );
}
