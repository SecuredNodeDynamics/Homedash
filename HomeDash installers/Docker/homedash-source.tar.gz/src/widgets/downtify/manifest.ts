import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "downtify",
  name: "Downtify",
  description: "Music download manager",
  version: "0.2.6",
  category: "Downloads",
  defaultSize: { w: 4, h: 5, minW: 2, minH: 3 },
  hostClass: "downtify-widget-host",
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "http://10.0.0.1",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      placeholder: "https://downtify.example.com",
    },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url", placeholder: "http://10.0.0.1" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    { key: "username", label: "Username", type: "text", placeholder: "Downtify login" },
    { key: "password", label: "Password", type: "password" },
  ],
};
