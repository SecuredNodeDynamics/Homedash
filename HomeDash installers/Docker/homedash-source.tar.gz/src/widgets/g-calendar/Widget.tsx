"use client";
import "@/styles/widgets/google-calendar.widget.css";

import { useCallback, useMemo, useState } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

// ── Types (mirrors src/lib/widgets/google-calendar.ts) ───────────────────

type GCalEvent = {
  id: string;
  calendarId: string;
  calendarLabel: string;
  title: string;
  description: string | null;
  location: string | null;
  start: string;
  end: string;
  allDay: boolean;
  htmlLink: string | null;
};

type GCalCalendarRef = { id: string; label: string };

type GCalCalendarError = { calendarId: string; label: string; message: string };

type StatusPayload = {
  events: GCalEvent[];
  calendars: GCalCalendarRef[];
  errors: GCalCalendarError[];
};

type FormState = {
  mode: "create" | "edit";
  eventId?: string;
  calendarId: string;
  title: string;
  location: string;
  description: string;
  allDay: boolean;
  start: string;
  end: string;
};

// ── Helpers ────────────────────────────────────────────────────────────

const CAL_COLORS = ["#4285f4", "#0f9d58", "#f4b400", "#db4437", "#9c27b0", "#00acc1", "#ff7043"];

function colorForCalendar(calendarId: string, calendars: GCalCalendarRef[]): string {
  const index = Math.max(0, calendars.findIndex((c) => c.id === calendarId));
  return CAL_COLORS[index % CAL_COLORS.length];
}

const DOW = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"] as const;

function pad2(n: number): string {
  return String(n).padStart(2, "0");
}

function keyForDate(date: Date): string {
  return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
}

function dayKey(iso: string): string {
  if (!iso) return "unknown";
  // All-day events come back as a bare "YYYY-MM-DD" with no time/offset.
  // Handing that straight to `new Date()` parses it as UTC midnight, which
  // rolls back to the previous local day west of UTC. Read the digits
  // directly instead of going through Date parsing for these.
  const dateOnly = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
  if (dateOnly) return `${dateOnly[1]}-${dateOnly[2]}-${dateOnly[3]}`;
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "unknown";
  return keyForDate(date);
}

function dayLabel(key: string): string {
  const date = new Date(`${key}T00:00:00`);
  if (Number.isNaN(date.getTime())) return key;
  const today = new Date();
  const todayKey = today.toISOString().slice(0, 10);
  const tomorrow = new Date(today.getTime() + 86_400_000).toISOString().slice(0, 10);
  if (key === todayKey) return "Today";
  if (key === tomorrow) return "Tomorrow";
  return date.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
}

function timeLabel(event: GCalEvent): string {
  if (event.allDay) return "All day";
  const start = new Date(event.start);
  if (Number.isNaN(start.getTime())) return "";
  return start.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });
}

// Converts an ISO datetime (or date) string to the value a
// <input type="datetime-local"> / <input type="date"> expects.
function toInputValue(iso: string, allDay: boolean): string {
  if (!iso) return "";
  if (allDay) return iso.slice(0, 10);
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

function emptyForm(defaultCalendarId: string): FormState {
  const now = new Date();
  now.setMinutes(0, 0, 0);
  now.setHours(now.getHours() + 1);
  const end = new Date(now.getTime() + 60 * 60 * 1000);
  return {
    mode: "create",
    calendarId: defaultCalendarId,
    title: "",
    location: "",
    description: "",
    allDay: false,
    start: toInputValue(now.toISOString(), false),
    end: toInputValue(end.toISOString(), false),
  };
}

function formFromEvent(event: GCalEvent): FormState {
  return {
    mode: "edit",
    eventId: event.id,
    calendarId: event.calendarId,
    title: event.title,
    location: event.location ?? "",
    description: event.description ?? "",
    allDay: event.allDay,
    start: toInputValue(event.start, event.allDay),
    end: toInputValue(event.end, event.allDay),
  };
}

// ── Icons (inline SVG, no external deps) ──────────────────────────────

function Icon({ path, size = 14 }: { path: string; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d={path} />
    </svg>
  );
}

const ICONS = {
  refresh: "M17.65 6.35A8 8 0 1 0 19.94 13h-2.02A6 6 0 1 1 12 6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z",
  plus: "M19 13H13v6h-2v-6H5v-2h6V5h2v6h6z",
  edit: "M3 17.25V21h3.75L17.81 9.94l-3.75-3.75zm17.71-10.04a1 1 0 0 0 0-1.41l-2.51-2.51a1 1 0 0 0-1.41 0l-1.96 1.96 3.75 3.75z",
  trash: "M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6zM19 4h-3.5l-1-1h-5l-1 1H5v2h14z",
  close: "M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 7 19l5.59-5.59L17.59 19 19 17.59 13.41 12z",
  clock: "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm.5 5H11v6l5.25 3.15.75-1.3-4.5-2.65z",
  pin: "M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z",
  link: "M3.9 12a5 5 0 0 1 5-5h4v2h-4a3 3 0 0 0 0 6h4v2h-4a5 5 0 0 1-5-5zm7-1h6v2h-6v-2zm3-4h4a5 5 0 0 1 0 10h-4v-2h4a3 3 0 0 0 0-6h-4V7z",
};

function EventRow({
  event,
  calendars,
  onOpen,
  onDelete,
  deleting,
}: {
  event: GCalEvent;
  calendars: GCalCalendarRef[];
  onOpen: (event: GCalEvent) => void;
  onDelete: (event: GCalEvent) => void;
  deleting: boolean;
}) {
  return (
    <div
      className="gcal-event-row"
      role="button"
      tabIndex={0}
      onClick={() => onOpen(event)}
      onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && onOpen(event)}
    >
      <span className="gcal-event-bar" style={{ background: colorForCalendar(event.calendarId, calendars) }} />
      <div className="gcal-event-body">
        <div className="gcal-event-title">{event.title}</div>
        <div className="gcal-event-meta">
          <span>{timeLabel(event)}</span>
          {event.location && <span>· {event.location}</span>}
        </div>
      </div>
      <div className="gcal-event-actions">
        <button
          className="gcal-icon-btn gcal-icon-btn--danger"
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onDelete(event);
          }}
          disabled={deleting}
          aria-label="Delete"
        >
          <Icon path={ICONS.trash} size={13} />
        </button>
      </div>
    </div>
  );
}

function detailsDateLabel(event: GCalEvent): string {
  const start = new Date(event.start);
  if (Number.isNaN(start.getTime())) return "";
  const dateStr = start.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
  if (event.allDay) return `${dateStr} · All day`;
  const end = new Date(event.end);
  const startTime = start.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });
  const endTime = Number.isNaN(end.getTime()) ? "" : end.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });
  return endTime ? `${dateStr} · ${startTime} – ${endTime}` : `${dateStr} · ${startTime}`;
}

function EventDetails({
  event,
  calendars,
  onClose,
  onEdit,
  onDelete,
  deleting,
}: {
  event: GCalEvent;
  calendars: GCalCalendarRef[];
  onClose: () => void;
  onEdit: (event: GCalEvent) => void;
  onDelete: (event: GCalEvent) => void;
  deleting: boolean;
}) {
  return (
    <div className="gcal-form-overlay" onClick={onClose}>
      <div className="gcal-details" onClick={(e) => e.stopPropagation()}>
        <div className="gcal-details-hdr">
          <span className="gcal-event-bar gcal-details-bar" style={{ background: colorForCalendar(event.calendarId, calendars) }} />
          <div className="gcal-details-title">{event.title}</div>
          <button className="gcal-icon-btn" type="button" onClick={onClose} aria-label="Close">
            <Icon path={ICONS.close} size={13} />
          </button>
        </div>

        <div className="gcal-details-row">
          <Icon path={ICONS.clock} size={14} />
          <span>{detailsDateLabel(event)}</span>
        </div>
        {event.location && (
          <div className="gcal-details-row">
            <Icon path={ICONS.pin} size={14} />
            <span>{event.location}</span>
          </div>
        )}
        {event.description && <div className="gcal-details-desc">{event.description}</div>}
        {event.htmlLink && (
          <a className="gcal-details-row gcal-details-link" href={event.htmlLink} target="_blank" rel="noreferrer">
            <Icon path={ICONS.link} size={14} />
            <span>Open in Google Calendar</span>
          </a>
        )}

        <div className="gcal-form-actions">
          <button
            className="gcal-btn gcal-btn--danger"
            type="button"
            onClick={() => onDelete(event)}
            disabled={deleting}
          >
            {deleting ? "Deleting…" : "Delete"}
          </button>
          <button className="gcal-btn gcal-btn--primary" type="button" onClick={() => onEdit(event)}>
            Edit
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Component ───────────────────────────────────────────────────────────

export default function GoogleCalendarWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "g-calendar";

  const [data, setData] = useState<StatusPayload | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<FormState | null>(null);
  const [formError, setFormError] = useState("");
  const [saving, setSaving] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<string | null>(null);
  const [detailsEvent, setDetailsEvent] = useState<GCalEvent | null>(null);
  const [view, setView] = useState<"month" | "agenda">("month");
  const [cursor, setCursor] = useState(() => new Date());
  const todayKey = useMemo(() => keyForDate(new Date()), []);
  const [selectedDate, setSelectedDate] = useState(() => keyForDate(new Date()));

  const load = useCallback(async () => {
    setError("");
    try {
      const response = await fetch(
        `/api/widgets/g-calendar/status?instance=${encodeURIComponent(instanceId)}`,
        { cache: "no-store", signal: AbortSignal.timeout(15_000) },
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load Google Calendar");
      setData(json as StatusPayload);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Failed to load Google Calendar");
    } finally {
      setLoading(false);
    }
  }, [instanceId]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: 60_000 });

  const calendars = data?.calendars ?? [];
  const events = data?.events ?? [];
  const calendarErrors = data?.errors ?? [];

  const grouped = useMemo(() => {
    const groups = new Map<string, GCalEvent[]>();
    for (const event of events) {
      const key = dayKey(event.start);
      const list = groups.get(key) ?? [];
      list.push(event);
      groups.set(key, list);
    }
    return Array.from(groups.entries()).sort(([a], [b]) => a.localeCompare(b));
  }, [events]);

  const monthLabel = cursor.toLocaleDateString(undefined, { month: "long", year: "numeric" });
  const monthLabelShort = cursor.toLocaleDateString(undefined, { month: "short", year: "numeric" });

  const monthCells = useMemo(() => {
    const year = cursor.getFullYear();
    const month = cursor.getMonth();
    const first = new Date(year, month, 1);
    const startPad = first.getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);

    const byDay = new Map<string, GCalEvent[]>();
    for (const event of events) {
      const key = dayKey(event.start);
      const list = byDay.get(key) ?? [];
      list.push(event);
      byDay.set(key, list);
    }

    const cells: Array<{
      day: number | null;
      key: string;
      events: GCalEvent[];
      isToday: boolean;
      isSelected: boolean;
      isPast: boolean;
    }> = [];

    for (let i = 0; i < startPad; i += 1) {
      cells.push({ day: null, key: `pad-${i}`, events: [], isToday: false, isSelected: false, isPast: false });
    }
    for (let day = 1; day <= daysInMonth; day += 1) {
      const key = `${year}-${pad2(month + 1)}-${pad2(day)}`;
      const cellDate = new Date(year, month, day);
      cells.push({
        day,
        key,
        events: byDay.get(key) ?? [],
        isToday: key === todayKey,
        isSelected: key === selectedDate,
        isPast: cellDate < todayStart,
      });
    }
    return cells;
  }, [cursor, events, todayKey, selectedDate]);

  const selectedEvents = useMemo(
    () => events.filter((event) => dayKey(event.start) === selectedDate).sort((a, b) => a.start.localeCompare(b.start)),
    [events, selectedDate],
  );

  const selectedLabelFull = useMemo(
    () => new Date(`${selectedDate}T00:00:00`).toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" }),
    [selectedDate],
  );
  const selectedLabelShort = useMemo(
    () => new Date(`${selectedDate}T00:00:00`).toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" }),
    [selectedDate],
  );

  const badge = useMemo(() => {
    if (!data) return { label: "Loading", className: "gcal-status-badge--offline" };
    if (calendarErrors.length && calendarErrors.length === calendars.length) {
      return { label: "Unhealthy", className: "gcal-status-badge--unhealthy" };
    }
    if (calendarErrors.length) return { label: "Partial", className: "gcal-status-badge--warning" };
    return { label: `${calendars.length} calendar${calendars.length === 1 ? "" : "s"}`, className: "" };
  }, [data, calendarErrors, calendars]);

  const openCreate = useCallback(() => {
    setFormError("");
    setForm(emptyForm(calendars[0]?.id ?? ""));
  }, [calendars]);

  const openEdit = useCallback((event: GCalEvent) => {
    setFormError("");
    setForm(formFromEvent(event));
    setDetailsEvent(null);
  }, []);

  const openDetails = useCallback((event: GCalEvent) => setDetailsEvent(event), []);
  const closeDetails = useCallback(() => setDetailsEvent(null), []);

  const closeForm = useCallback(() => {
    setForm(null);
    setFormError("");
  }, []);

  const submitForm = useCallback(async () => {
    if (!form) return;
    if (!form.title.trim()) {
      setFormError("Title is required");
      return;
    }
    if (!form.calendarId) {
      setFormError("Choose a calendar");
      return;
    }
    if (!form.start || !form.end) {
      setFormError("Start and end are required");
      return;
    }

    setSaving(true);
    setFormError("");
    try {
      const action = form.mode === "create" ? "create-event" : "update-event";
      const response = await fetch("/api/widgets/g-calendar/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          instance: instanceId,
          action,
          eventId: form.eventId,
          calendarId: form.calendarId,
          title: form.title.trim(),
          location: form.location.trim() || undefined,
          description: form.description.trim() || undefined,
          allDay: form.allDay,
          start: form.start,
          end: form.end,
        }),
        signal: AbortSignal.timeout(15_000),
      });
      const json = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(json.error || "Action failed");
      setForm(null);
      await load();
    } catch (reason) {
      setFormError(reason instanceof Error ? reason.message : "Action failed");
    } finally {
      setSaving(false);
    }
  }, [form, instanceId, load]);

  const deleteEvent = useCallback(
    async (event: GCalEvent) => {
      setPendingDelete(event.id);
      try {
        const response = await fetch("/api/widgets/g-calendar/action", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            instance: instanceId,
            action: "delete-event",
            calendarId: event.calendarId,
            eventId: event.id,
          }),
          signal: AbortSignal.timeout(15_000),
        });
        const json = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(json.error || "Delete failed");
        setDetailsEvent((current) => (current?.id === event.id ? null : current));
        await load();
      } catch (reason) {
        setError(reason instanceof Error ? reason.message : "Delete failed");
      } finally {
        setPendingDelete(null);
      }
    },
    [instanceId, load],
  );

  if (loading && !data) {
    return (
      <div className="hd-widget-body gcal-body-flat" ref={rootRef}>
        <div className="gcal-toolbar">
          <div className="gcal-status-badge gcal-status-badge--offline">
            <span className="gcal-status-dot-pill" />
            Loading
          </div>
        </div>
        {Array.from({ length: 3 }, (_, index) => (
          <div className="gcal-skeleton-row" style={{ animationDelay: `${index * 0.1}s` }} key={index} />
        ))}
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="hd-widget-body gcal-body-flat" ref={rootRef}>
        <div className="gcal-toolbar">
          <div className="gcal-status-badge gcal-status-badge--unhealthy">
            <span className="gcal-status-dot-pill" />
            Unhealthy
          </div>
          <button className="gcal-refresh-btn" type="button" onClick={() => load()} aria-label="Retry">
            <Icon path={ICONS.refresh} />
          </button>
        </div>
        <div className="gcal-error">⚠ {error}</div>
      </div>
    );
  }

  return (
    <div className="hd-widget-body gcal-body-flat" ref={rootRef} style={{ position: "relative" }}>
      <div className="gcal-toolbar">
        <div className="gcal-toolbar-left">
          <div className={`gcal-status-badge ${badge.className}`}>
            <span className="gcal-status-dot-pill" />
            {badge.label}
          </div>
        </div>
        <div className="gcal-month-nav">
          <button
            className="gcal-nav"
            type="button"
            aria-label="Previous month"
            onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))}
          >
            ‹
          </button>
          <span className="gcal-month-label">
            <span className="gcal-month-label__full">{monthLabel}</span>
            <span className="gcal-month-label__short">{monthLabelShort}</span>
          </span>
          <button
            className="gcal-nav"
            type="button"
            aria-label="Next month"
            onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))}
          >
            ›
          </button>
        </div>
        <div className="gcal-toolbar-right">
          <div className="gcal-view-tabs">
            <button
              type="button"
              className={`gcal-view-tab${view === "month" ? " gcal-view-tab--active" : ""}`}
              onClick={() => setView("month")}
            >
              Month
            </button>
            <button
              type="button"
              className={`gcal-view-tab${view === "agenda" ? " gcal-view-tab--active" : ""}`}
              onClick={() => setView("agenda")}
            >
              Agenda
            </button>
          </div>
          <button className="gcal-add-btn" type="button" onClick={openCreate} disabled={!calendars.length}>
            <Icon path={ICONS.plus} size={13} />
            Add
          </button>
          <button className="gcal-refresh-btn" type="button" onClick={() => load()} aria-label="Refresh">
            <Icon path={ICONS.refresh} />
          </button>
        </div>
      </div>

      {calendarErrors.length > 0 && (
        <div className="gcal-warning">
          {calendarErrors.map((e) => `${e.label}: ${e.message}`).join(" · ")}
        </div>
      )}

      <div className={`gcal-main gcal-main--${view}`}>
        {view === "month" ? (
          <div className="gcal-month-wrap">
            <div className="gcal-grid-header">
              {DOW.map((day) => (
                <div className="gcal-dow" key={day}>
                  <span className="gcal-dow__full">{day}</span>
                  <span className="gcal-dow__short" aria-hidden="true">
                    {day.charAt(0)}
                  </span>
                </div>
              ))}
            </div>
            <div className="gcal-grid">
              {monthCells.map((cell) =>
                cell.day == null ? (
                  <div className="gcal-cell gcal-cell--empty" key={cell.key} />
                ) : (
                  <button
                    type="button"
                    key={cell.key}
                    className={`gcal-cell${cell.isToday ? " gcal-cell--today" : ""}${cell.isSelected ? " gcal-cell--selected" : ""}${cell.isPast ? " gcal-cell--past" : ""}`}
                    onClick={() => setSelectedDate(cell.key)}
                  >
                    <div className="gcal-day-num">{cell.day}</div>
                    <div className="gcal-dots">
                      {cell.events.slice(0, 4).map((event, index) => (
                        <span
                          key={`${event.id}#${index}`}
                          className="gcal-dot"
                          style={{ background: colorForCalendar(event.calendarId, calendars) }}
                          title={event.title}
                        />
                      ))}
                      {cell.events.length > 4 ? <span className="gcal-dot-more">+{cell.events.length - 4}</span> : null}
                    </div>
                  </button>
                ),
              )}
            </div>
          </div>
        ) : (
          <div className="gcal-scroll">
            {grouped.length === 0 && <div className="gcal-empty">No events in the next 30 days</div>}
            {grouped.map(([key, dayEvents]) => (
              <div className="gcal-day-group" key={key}>
                <div className="gcal-day-label">{dayLabel(key)}</div>
                {dayEvents.map((event) => (
                  <EventRow
                    key={`${event.calendarId}:${event.id}`}
                    event={event}
                    calendars={calendars}
                    onOpen={openDetails}
                    onDelete={deleteEvent}
                    deleting={pendingDelete === event.id}
                  />
                ))}
              </div>
            ))}
          </div>
        )}
      </div>

      {view === "month" ? (
        <div className="gcal-today-panel">
          <div className="gcal-today-hdr">
            <div className="gcal-today-hdr-main">
              <span className="gcal-today-label">{selectedDate === todayKey ? "Today" : selectedLabelShort}</span>
              {selectedDate === todayKey ? (
                <>
                  <span className="gcal-today-date gcal-today-date--full">{selectedLabelFull}</span>
                  <span className="gcal-today-date gcal-today-date--short">{selectedLabelShort}</span>
                </>
              ) : null}
              <span className="gcal-today-count">
                {selectedEvents.length} event{selectedEvents.length === 1 ? "" : "s"}
              </span>
            </div>
          </div>
          <div className="gcal-today-items">
            {selectedEvents.length ? (
              selectedEvents.map((event) => (
                <EventRow
                  key={event.id}
                  event={event}
                  calendars={calendars}
                  onOpen={openDetails}
                  onDelete={deleteEvent}
                  deleting={pendingDelete === event.id}
                />
              ))
            ) : (
              <div className="gcal-today-empty">
                {selectedDate === todayKey ? "Nothing scheduled for today" : "Nothing scheduled for this day"}
              </div>
            )}
          </div>
        </div>
      ) : null}

      {detailsEvent && !form && (
        <EventDetails
          event={detailsEvent}
          calendars={calendars}
          onClose={closeDetails}
          onEdit={openEdit}
          onDelete={deleteEvent}
          deleting={pendingDelete === detailsEvent.id}
        />
      )}

      {form && (
        <div className="gcal-form-overlay">
          <div className="gcal-form">
            <div className="gcal-form-title">{form.mode === "create" ? "New event" : "Edit event"}</div>

            <label>
              Title
              <input
                type="text"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="Event title"
              />
            </label>

            <label>
              Calendar
              <select
                value={form.calendarId}
                onChange={(e) => setForm({ ...form, calendarId: e.target.value })}
              >
                {calendars.map((cal) => (
                  <option value={cal.id} key={cal.id}>
                    {cal.label}
                  </option>
                ))}
              </select>
            </label>

            <label className="gcal-form-checkbox">
              <input
                type="checkbox"
                checked={form.allDay}
                onChange={(e) => {
                  const allDay = e.target.checked;
                  setForm({
                    ...form,
                    allDay,
                    start: toInputValue(form.start, allDay),
                    end: toInputValue(form.end, allDay),
                  });
                }}
              />
              All day
            </label>

            <div className="gcal-form-row">
              <label>
                Start
                <input
                  type={form.allDay ? "date" : "datetime-local"}
                  value={form.start}
                  onChange={(e) => setForm({ ...form, start: e.target.value })}
                />
              </label>
              <label>
                End
                <input
                  type={form.allDay ? "date" : "datetime-local"}
                  value={form.end}
                  onChange={(e) => setForm({ ...form, end: e.target.value })}
                />
              </label>
            </div>

            <label>
              Location
              <input
                type="text"
                value={form.location}
                onChange={(e) => setForm({ ...form, location: e.target.value })}
                placeholder="Optional"
              />
            </label>

            <label>
              Description
              <textarea
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="Optional"
              />
            </label>

            {formError && <div className="gcal-form-error">⚠ {formError}</div>}

            <div className="gcal-form-actions">
              <button className="gcal-btn" type="button" onClick={closeForm} disabled={saving}>
                Cancel
              </button>
              <button className="gcal-btn gcal-btn--primary" type="button" onClick={submitForm} disabled={saving}>
                {saving ? "Saving…" : form.mode === "create" ? "Create" : "Save"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
