import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "g-calendar",
  name: "Google Calendar",
  description:
    "Upcoming events across one or more Google Calendars, with the ability to add, edit, and delete events — authenticated via a Google service account, no OAuth redirect required",
  version: "0.1.7",
  category: "Productivity",
  defaultSize: { w: 6, h: 6, minW: 4, minH: 4 },
  configFields: [
    {
      key: "serviceAccountEmail",
      label:
        "Service Account Email — Google Cloud Console → IAM & Admin → Service Accounts → create one, enable the Calendar API on the project",
      type: "text",
      placeholder: "g-calendar@your-project.iam.gserviceaccount.com",
    },
    {
      key: "privateKey",
      label:
        "Service Account Private Key — from the downloaded JSON key file, paste the \"private_key\" field's value exactly as written (including the literal \\n sequences)",
      type: "password",
      placeholder: "Paste the private_key value from your JSON key file",
    },
    {
      key: "calendars",
      label:
        "Calendars — comma-separated Label:CalendarID pairs. In each Google Calendar's Settings, share it with the service account email above and grant \"Make changes to events\". Use \"primary\" as the ID for the account's main calendar.",
      type: "text",
      placeholder: "Personal:primary,Family:abc123@group.calendar.google.com",
    },
  ],
};
