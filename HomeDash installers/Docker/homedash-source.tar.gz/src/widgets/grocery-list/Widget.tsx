"use client";

import "@/styles/widgets/grocery-list.widget.css";

import { useEffect, useMemo, useState } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";

type View = "needed" | "all" | "cart";
type Category = "Produce" | "Dairy" | "Pantry" | "Meat" | "Frozen" | "Bakery" | "Household" | "Other";

type GroceryItem = {
  id: string;
  name: string;
  quantity: string;
  category: Category;
  checked: boolean;
  createdAt: number;
};

const CATEGORIES: Category[] = ["Produce", "Dairy", "Pantry", "Meat", "Frozen", "Bakery", "Household", "Other"];
const CATEGORY_ICONS: Record<Category, string> = {
  Produce: "🥬",
  Dairy: "🥛",
  Pantry: "🥫",
  Meat: "🥩",
  Frozen: "❄️",
  Bakery: "🥖",
  Household: "🧻",
  Other: "🛒",
};

function newId() {
  return typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function normalize(value: unknown): GroceryItem[] {
  if (!Array.isArray(value)) return [];
  return value
    .filter((item): item is Partial<GroceryItem> => Boolean(item && typeof item === "object"))
    .map((item) => ({
      id: String(item.id || newId()),
      name: String(item.name || "").trim().slice(0, 120),
      quantity: String(item.quantity || "1").trim().slice(0, 24) || "1",
      category: CATEGORIES.includes(item.category as Category) ? item.category as Category : "Other",
      checked: Boolean(item.checked),
      createdAt: Number(item.createdAt) || Date.now(),
    }))
    .filter((item) => item.name);
}

export default function GroceryListWidget() {
  const instance = useWidgetInstance();
  const storageKey = `homedash.grocery-list.${instance?.instanceId || "grocery-list"}`;
  const [items, setItems] = useState<GroceryItem[]>([]);
  const [name, setName] = useState("");
  const [quantity, setQuantity] = useState("1");
  const [category, setCategory] = useState<Category>("Produce");
  const [view, setView] = useState<View>("needed");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState("");
  const [editQuantity, setEditQuantity] = useState("");
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      setItems(normalize(JSON.parse(localStorage.getItem(storageKey) || "[]")));
    } catch {
      setItems([]);
    }
    setReady(true);
  }, [storageKey]);

  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem(storageKey, JSON.stringify(items));
    } catch {
      /* Browser storage may be unavailable in restricted contexts. */
    }
  }, [items, ready, storageKey]);

  const needed = items.filter((item) => !item.checked).length;
  const inCart = items.length - needed;
  const visible = useMemo(
    () =>
      items.filter((item) =>
        view === "needed" ? !item.checked : view === "cart" ? item.checked : true,
      ),
    [items, view],
  );

  const grouped = useMemo(
    () =>
      CATEGORIES.map((group) => ({
        name: group,
        items: visible.filter((item) => item.category === group),
      })).filter((group) => group.items.length),
    [visible],
  );

  function addItem() {
    const itemName = name.trim();
    if (!itemName) return;
    setItems((current) => [
      ...current,
      {
        id: newId(),
        name: itemName.slice(0, 120),
        quantity: quantity.trim().slice(0, 24) || "1",
        category,
        checked: false,
        createdAt: Date.now(),
      },
    ]);
    setName("");
    setQuantity("1");
  }

  function beginEdit(item: GroceryItem) {
    setEditingId(item.id);
    setEditName(item.name);
    setEditQuantity(item.quantity);
  }

  function saveEdit() {
    if (!editingId) return;
    const nextName = editName.trim().slice(0, 120);
    if (nextName) {
      setItems((current) =>
        current.map((item) =>
          item.id === editingId
            ? { ...item, name: nextName, quantity: editQuantity.trim().slice(0, 24) || "1" }
            : item,
        ),
      );
    } else {
      setItems((current) => current.filter((item) => item.id !== editingId));
    }
    setEditingId(null);
  }

  return (
    <div className="grocery-shell">
      <div className="grocery-summary">
        <div className="grocery-summary-icon" aria-hidden>🛒</div>
        <div className="grocery-summary-copy">
          <strong>{needed ? `${needed} item${needed === 1 ? "" : "s"} to pick up` : items.length ? "Shopping complete" : "Start your shopping list"}</strong>
          <span>{items.length ? `${inCart} of ${items.length} in cart` : "Add items and organize them by aisle"}</span>
        </div>
        <div className="grocery-progress" aria-label={`${inCart} of ${items.length} items in cart`}>
          <span style={{ width: `${items.length ? Math.round((inCart / items.length) * 100) : 0}%` }} />
        </div>
      </div>

      <form
        className="grocery-compose"
        onSubmit={(event) => {
          event.preventDefault();
          addItem();
        }}
      >
        <input
          className="grocery-name"
          value={name}
          maxLength={120}
          placeholder="Add grocery item…"
          aria-label="Grocery item"
          onChange={(event) => setName(event.target.value)}
        />
        <input
          className="grocery-quantity"
          value={quantity}
          maxLength={24}
          placeholder="Qty"
          aria-label="Quantity"
          onChange={(event) => setQuantity(event.target.value)}
        />
        <select value={category} aria-label="Category" onChange={(event) => setCategory(event.target.value as Category)}>
          {CATEGORIES.map((entry) => <option key={entry} value={entry}>{CATEGORY_ICONS[entry]} {entry}</option>)}
        </select>
        <button className="grocery-add" type="submit" disabled={!name.trim()} aria-label="Add grocery item">+</button>
      </form>

      <div className="grocery-toolbar">
        <div className="grocery-views" role="tablist" aria-label="Grocery list view">
          <button type="button" role="tab" aria-selected={view === "needed"} className={view === "needed" ? "is-active" : ""} onClick={() => setView("needed")}>Needed {needed}</button>
          <button type="button" role="tab" aria-selected={view === "all"} className={view === "all" ? "is-active" : ""} onClick={() => setView("all")}>All {items.length}</button>
          <button type="button" role="tab" aria-selected={view === "cart"} className={view === "cart" ? "is-active" : ""} onClick={() => setView("cart")}>In cart {inCart}</button>
        </div>
        {inCart ? <button type="button" className="grocery-clear" onClick={() => setItems((current) => current.filter((item) => !item.checked))}>Clear cart</button> : null}
      </div>

      <div className="grocery-list" aria-live="polite">
        {!ready ? <div className="grocery-empty">Loading list…</div> : null}
        {ready && !visible.length ? (
          <div className="grocery-empty">
            <span aria-hidden>🛒</span>
            {items.length ? `No items in ${view}` : "Your grocery list is empty"}
            <small>{items.length ? "Choose another view" : "Add your first item above"}</small>
          </div>
        ) : null}
        {grouped.map((group) => (
          <section className="grocery-group" key={group.name}>
            <div className="grocery-group-title">
              <span><i aria-hidden>{CATEGORY_ICONS[group.name]}</i>{group.name}</span>
              <span>{group.items.length} {group.items.length === 1 ? "item" : "items"}</span>
            </div>
            {group.items.map((item) => (
              <div className={`grocery-item${item.checked ? " is-checked" : ""}`} key={item.id}>
                <button
                  type="button"
                  className="grocery-check"
                  aria-pressed={item.checked}
                  aria-label={item.checked ? `Return ${item.name} to needed` : `Put ${item.name} in cart`}
                  onClick={() => setItems((current) => current.map((entry) => entry.id === item.id ? { ...entry, checked: !entry.checked } : entry))}
                >
                  <span aria-hidden>{item.checked ? "✓" : ""}</span>
                </button>
                {editingId === item.id ? (
                  <div className="grocery-edit-row">
                    <input
                      autoFocus
                      value={editName}
                      maxLength={120}
                      aria-label={`Edit ${item.name}`}
                      onChange={(event) => setEditName(event.target.value)}
                      onKeyDown={(event) => {
                        if (event.key === "Enter") saveEdit();
                        if (event.key === "Escape") setEditingId(null);
                      }}
                    />
                    <input value={editQuantity} maxLength={24} aria-label="Edit quantity" onChange={(event) => setEditQuantity(event.target.value)} onKeyDown={(event) => event.key === "Enter" && saveEdit()} />
                    <button type="button" onClick={saveEdit}>Save</button>
                  </div>
                ) : (
                  <div className="grocery-copy">
                    <span>{item.name}</span><small><b>QTY</b>{item.quantity}</small>
                  </div>
                )}
                {editingId !== item.id ? <button type="button" className="grocery-edit-button" aria-label={`Edit ${item.name}`} onClick={() => beginEdit(item)}>✎</button> : null}
                <button type="button" className="grocery-delete" aria-label={`Delete ${item.name}`} onClick={() => setItems((current) => current.filter((entry) => entry.id !== item.id))}>×</button>
              </div>
            ))}
          </section>
        ))}
      </div>

      <div className="grocery-footer">
        <span>{needed ? `${needed} item${needed === 1 ? "" : "s"} left to shop` : items.length ? "Shopping complete" : "Ready for your list"}</span>
        <span>Stored in this browser</span>
      </div>
    </div>
  );
}
