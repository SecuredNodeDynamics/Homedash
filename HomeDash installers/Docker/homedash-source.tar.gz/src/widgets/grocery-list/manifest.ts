import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "grocery-list",
  name: "Grocery List",
  description: "Organized shopping list stored in the browser",
  version: "0.1.0",
  category: "Productivity",
  hostClass: "grocery-host",
  defaultSize: { w: 4, h: 7, minW: 2, minH: 4 },
  configFields: [],
};
