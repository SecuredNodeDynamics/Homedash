"use client";
import "@/styles/widgets/homeassistant.widget.css";


import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode, useLayoutEffect } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type HaEntity = {
  entity_id: string;
  state: string;
  attributes: Record<string, unknown>;
  last_changed?: string;
};

type HaDevice = {
  id: string;
  label: string;
  kind: string;
  entityId: string;
  entity: HaEntity;
  area?: string;
  related: HaEntity[];
};

type ConnectionSource = "private" | "public" | "unknown";

type Data = {
  href: string;
  openFallbackUrl?: string;
  location: string;
  weather?: HaEntity;
  alerts: HaEntity[];
  controls: HaEntity[];
  sensors: HaEntity[];
  devices: HaDevice[];
  connectionSource?: ConnectionSource;
};

const CONNECTION_SOURCE_LABEL: Record<ConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

function ConnectionCorner({ source }: { source: ConnectionSource }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const mark = (
    <div
      className={`ha-corner-source ha-corner-source--${source}`}
      title={CONNECTION_SOURCE_LABEL[source]}
      aria-label={CONNECTION_SOURCE_LABEL[source]}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}


const DOMAIN_ICON: Record<string, string> = {
  light: "💡",
  switch: "🔌",
  fan: "🌀",
  cover: "🪟",
  lock: "🔒",
  climate: "🌡",
  camera: "📷",
  media_player: "🎵",
  vacuum: "🧹",
  sensor: "📊",
  binary_sensor: "◎",
};

const GLYPHS: Record<string, ReactNode> = {
  ring: (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path
        d="M12 3v2M6.5 8.5 5 10M17.5 8.5 19 10M6 14a6 6 0 1 1 12 0v3H6v-3zM9 20h6"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  ),
  washer: (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <rect x="4" y="3" width="16" height="18" rx="2" stroke="currentColor" strokeWidth="1.5" />
      <circle cx="12" cy="13" r="4" stroke="currentColor" strokeWidth="1.5" />
      <path d="M8 6h.01M11 6h.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ),
  printer: (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path
        d="M6 9V3h12v6M6 14h12v7H6v-7zM6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  ),
  tv: (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <rect x="3" y="5" width="18" height="12" rx="2" stroke="currentColor" strokeWidth="1.5" />
      <path d="M8 21h8M12 17v4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  ),
};

function domainOf(e: HaEntity | string) {
  return (typeof e === "string" ? e : e.entity_id).split(".")[0] || "unknown";
}

function friendly(e: HaEntity) {
  return String(e.attributes.friendly_name || e.entity_id.split(".")[1]?.replaceAll("_", " ") || e.entity_id);
}

function shortName(e: HaEntity) {
  return friendly(e).replace(/^Front Door\s*/i, "").trim() || friendly(e);
}

function unavailable(e: HaEntity) {
  return ["unknown", "unavailable"].includes(e.state);
}

function timeAgo(iso?: string) {
  if (!iso) return "";
  const diff = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
  if (diff < 60) return `${diff}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

function isRecentActivity(e: HaEntity, minutes = 8) {
  const d = domainOf(e);
  if (d === "binary_sensor") return e.state === "on";
  if (d === "event") {
    const t = Date.parse(e.state);
    return Number.isFinite(t) && Date.now() - t < minutes * 60 * 1000;
  }
  return false;
}

function stateLabel(e: HaEntity) {
  const d = domainOf(e);
  if (d === "climate") {
    const t = e.attributes.current_temperature ?? e.attributes.temperature;
    return t != null ? `${t}°` : e.state;
  }
  if (d === "sensor") {
    const u = e.attributes.unit_of_measurement || "";
    return `${e.state}${u}`;
  }
  if (d === "event") return isRecentActivity(e) ? "Recent" : timeAgo(e.state) || "—";
  if (d === "binary_sensor") {
    const dc = String(e.attributes.device_class || "");
    if (dc === "door" || dc === "window" || /door|lid/i.test(e.entity_id)) {
      if (e.state === "on") return "Open";
      if (e.state === "off") return "Closed";
    }
  }
  return e.state;
}

function tileActive(e: HaEntity) {
  const d = domainOf(e);
  if (["light", "switch", "fan", "input_boolean", "siren"].includes(d)) return e.state === "on";
  if (d === "media_player") return !["off", "idle", "standby"].includes(e.state);
  if (d === "lock") return e.state === "locked";
  if (d === "cover") return e.state === "open";
  if (d === "vacuum") return ["cleaning", "returning"].includes(e.state);
  return false;
}

function weatherText(w?: HaEntity) {
  if (!w) return null;
  const temp = w.attributes.temperature;
  const parts = [temp != null ? `${temp}°` : "", w.state && w.state !== "Temp" ? w.state : ""].filter(Boolean);
  return parts.join(" · ") || stateLabel(w);
}

function cameraUrl(instanceId: string, entityId: string, stream = false) {
  const q = new URLSearchParams({
    instance: instanceId,
    entity: entityId,
    t: String(Date.now()),
  });
  if (stream) q.set("stream", "1");
  return `/api/widgets/homeassistant/camera?${q.toString()}`;
}

function cardStatusLine(device: HaDevice) {
  const { entity, kind, related } = device;
  if (!entity) return "Not linked";
  if (kind === "camera") {
    const battery = related.find((s) => /battery/i.test(s.entity_id));
    const motionSw = related.find((s) => /motion_detection/i.test(s.entity_id));
    const parts: string[] = [];
    if (battery?.state != null) parts.push(`🔋 ${battery.state}%`);
    if (motionSw) parts.push(`Motion ${motionSw.state}`);
    const motionEvt = related.find((s) => domainOf(s) === "event" && /motion/i.test(s.entity_id));
    if (motionEvt) {
      const v = isRecentActivity(motionEvt) ? "Just now" : timeAgo(motionEvt.state);
      if (v) parts.push(`Activity ${v}`);
    }
    if (!parts.length) parts.push(stateLabel(entity));
    return parts.join(" · ");
  }
  if (kind === "media") {
    if (unavailable(entity)) return "Offline";
    const title = entity.attributes.media_title;
    const artist = entity.attributes.media_artist;
    const app = entity.attributes.app_name;
    if (title && artist) return `${title} · ${artist}`;
    if (title) return String(title);
    if (app) return String(app);
    return stateLabel(entity);
  }
  if (kind === "appliance") {
    const toner = related.find((s) => /_bk$|black_toner|toner_remaining/i.test(s.entity_id));
    const parts = [stateLabel(entity)];
    if (toner?.state != null) parts.push(`Toner ${toner.state}%`);
    return parts.join(" · ");
  }
  return [stateLabel(entity), device.area].filter(Boolean).join(" · ");
}

function cardBadge(device: HaDevice) {
  const { entity, kind, related } = device;
  if (!entity) return { text: "Setup", cls: "muted" };
  if (unavailable(entity)) return { text: "Offline", cls: "muted" };
  if (kind === "camera") {
    const motionEvt = related.find((e) => domainOf(e) === "event" && /motion|ding/i.test(e.entity_id));
    if (motionEvt && isRecentActivity(motionEvt)) return { text: "Motion", cls: "active" };
    return { text: "Live", cls: "live" };
  }
  if (kind === "media" && tileActive(entity)) return { text: "On", cls: "active" };
  if (kind === "appliance" && (tileActive(entity) || entity.state === "running")) return { text: "Active", cls: "active" };
  if (tileActive(entity)) return { text: "On", cls: "active" };
  return { text: stateLabel(entity), cls: "muted" };
}

function glyphFor(device: HaDevice) {
  if (GLYPHS[device.id]) return GLYPHS[device.id];
  if (device.kind === "camera") return GLYPHS.ring;
  if (device.kind === "media") return GLYPHS.tv;
  return <span>{DOMAIN_ICON[domainOf(device.entity)] || "•"}</span>;
}

function formatModalStat(e: HaEntity) {
  const id = e.entity_id;
  if (id.includes("battery")) return { label: "Battery", value: `${e.state}%` };
  if (/motion_detection/i.test(id)) return { label: "Motion Detection", value: e.state === "on" ? "Enabled" : "Disabled" };
  if (domainOf(e) === "event" && /ding/i.test(id)) {
    return { label: "Last Ding", value: isRecentActivity(e) ? "Just now" : timeAgo(e.state) || "—" };
  }
  if (domainOf(e) === "event" && /motion/i.test(id)) {
    return { label: "Last Motion", value: isRecentActivity(e) ? "Recent" : timeAgo(e.state) || "—" };
  }
  if (id.includes("last_activity")) return { label: "Last Activity", value: timeAgo(e.state) || "—" };
  if (domainOf(e) === "media_player") {
    if (e.attributes.media_title) return { label: "Now Playing", value: String(e.attributes.media_title) };
    if (e.attributes.app_name) return { label: "App", value: String(e.attributes.app_name) };
  }
  if (domainOf(e) === "sensor" || domainOf(e) === "binary_sensor") {
    return { label: shortName(e), value: stateLabel(e) };
  }
  return null;
}

function modalStats(related: HaEntity[], primary: HaEntity) {
  const stats: { label: string; value: string }[] = [];
  const used = new Set<string>();
  const order = [/battery/i, /motion_detection/i, /ding/i, /motion/i, /last_activity/i, /cycle|status|state|job|mode/i];
  for (const rx of order) {
    const hit = related.find((e) => rx.test(e.entity_id));
    if (!hit || used.has(hit.entity_id)) continue;
    const s = formatModalStat(hit);
    if (!s) continue;
    used.add(hit.entity_id);
    stats.push(s);
  }
  for (const e of related) {
    if (used.has(e.entity_id) || /motion_detection/i.test(e.entity_id)) continue;
    if (domainOf(e) !== "sensor" && domainOf(e) !== "binary_sensor") continue;
    const s = formatModalStat(e);
    if (!s) continue;
    used.add(e.entity_id);
    stats.push(s);
  }
  if (domainOf(primary) === "media_player" && primary.attributes.media_title) {
    stats.unshift({ label: "Now Playing", value: String(primary.attributes.media_title) });
  }
  return stats.slice(0, 6);
}

function modalToggles(related: HaEntity[]) {
  return related.filter(
    (e) =>
      ["switch", "light", "input_boolean"].includes(domainOf(e)) &&
      !unavailable(e) &&
      !/motion_detection|wifi|signal|volume/i.test(e.entity_id),
  );
}

function haEntityUrl(href: string, entityId: string) {
  const base = href.replace(/\/$/, "");
  return `${base}/?more-info-entity-id=${encodeURIComponent(entityId)}`;
}

function CameraThumb({ instanceId, entityId }: { instanceId: string; entityId: string }) {
  const [src, setSrc] = useState(() => cameraUrl(instanceId, entityId));
  const [loaded, setLoaded] = useState(false);
  const [triedStream, setTriedStream] = useState(false);

  return (
    <>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        className={`ha-grid-card-preview ha-cam-img${loaded ? " ha-cam-img--loaded" : ""}`}
        src={src}
        alt=""
        referrerPolicy="no-referrer"
        onLoad={() => setLoaded(true)}
        onError={() => {
          if (triedStream) return;
          setTriedStream(true);
          setSrc(cameraUrl(instanceId, entityId, true));
        }}
      />
    </>
  );
}

type StreamAuth = {
  href: string;
  bases?: string[];
  wsUrl: string;
  wsUrls?: string[];
  token: string;
};

type CameraFeedHealth = "live" | "weak" | "disconnected";

function cameraHealthFromFeed(
  mode: "none" | "webrtc" | "mjpeg" | "snapshot",
  status: string,
): CameraFeedHealth {
  if (mode === "webrtc") return "live";
  if (mode === "mjpeg" || mode === "snapshot") return "weak";
  if (/unavailable|failed|error|denied/i.test(status)) return "disconnected";
  return "weak";
}

/** Ring live view needs HA WebRTC; snapshot/MJPEG are fallbacks only. */
function CameraLiveFeed({
  instanceId,
  entityId,
  openHref,
  onHealthChange,
}: {
  instanceId: string;
  entityId: string;
  openHref: string;
  onHealthChange?: (health: CameraFeedHealth) => void;
}) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);
  const [mode, setMode] = useState<"none" | "webrtc" | "mjpeg" | "snapshot">("none");
  const [status, setStatus] = useState("Connecting…");

  useEffect(() => {
    onHealthChange?.(cameraHealthFromFeed(mode, status));
  }, [mode, status, onHealthChange]);

  useEffect(() => {
    let cancelled = false;
    let ws: WebSocket | null = null;
    let pc: RTCPeerConnection | null = null;
    let snapTimer: ReturnType<typeof setInterval> | undefined;
    let msgId = 0;
    const subs = new Map<
      number,
      { onEvent?: (event: Record<string, unknown>) => void; onError?: (err: Error) => void }
    >();

    const setFeed = (next: typeof mode) => {
      if (!cancelled) setMode(next);
    };

    function cleanupRtc() {
      if (pc) {
        try {
          pc.close();
        } catch {
          /* ignore */
        }
        pc = null;
      }
      if (ws) {
        try {
          ws.close();
        } catch {
          /* ignore */
        }
        ws = null;
      }
      const video = videoRef.current;
      if (video) video.srcObject = null;
    }

    async function wake() {
      try {
        await fetch("/api/widgets/homeassistant/action", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ instance: instanceId, entityId, service: "turn_on" }),
        });
        await new Promise((r) => setTimeout(r, 1000));
      } catch {
        /* continue */
      }
    }

    async function loadAuth(): Promise<StreamAuth> {
      const r = await fetch(`/api/widgets/homeassistant/stream-auth?instance=${encodeURIComponent(instanceId)}`);
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "Stream auth failed");
      return j as StreamAuth;
    }

    function connectWs(wsUrl: string, token: string) {
      return new Promise<WebSocket>((resolve, reject) => {
        const socket = new WebSocket(wsUrl);
        let settled = false;
        const fail = (err: Error) => {
          if (settled) return;
          settled = true;
          clearTimeout(timer);
          try {
            socket.close();
          } catch {
            /* ignore */
          }
          reject(err);
        };
        const timer = setTimeout(() => fail(new Error("WebSocket timeout")), 8000);
        socket.onerror = () => fail(new Error("WebSocket connection failed"));
        socket.onmessage = (ev) => {
          let msg: {
            type: string;
            id?: number;
            success?: boolean;
            error?: { message?: string };
            event?: Record<string, unknown>;
          };
          try {
            msg = JSON.parse(String(ev.data));
          } catch {
            return;
          }
          if (msg.type === "auth_required") {
            socket.send(JSON.stringify({ type: "auth", access_token: token }));
            return;
          }
          if (msg.type === "auth_invalid") {
            fail(new Error("WebSocket auth failed"));
            return;
          }
          if (msg.type === "auth_ok") {
            if (settled) return;
            settled = true;
            clearTimeout(timer);
            resolve(socket);
            return;
          }
          if (msg.type === "event" && msg.id != null && subs.has(msg.id)) {
            subs.get(msg.id)?.onEvent?.(msg.event || {});
          }
          if (msg.type === "result" && msg.id != null && subs.has(msg.id)) {
            if (!msg.success) subs.get(msg.id)?.onError?.(new Error(msg.error?.message || "Request failed"));
          }
        };
      });
    }

    function waitForFrames(video: HTMLVideoElement, ms = 7000) {
      return new Promise<boolean>((resolve) => {
        const start = Date.now();
        const tick = () => {
          if (cancelled) return resolve(false);
          if (video.videoWidth > 0 && video.videoHeight > 0) return resolve(true);
          if (Date.now() - start >= ms) return resolve(false);
          window.setTimeout(tick, 200);
        };
        tick();
      });
    }

    async function startWebRtcOnUrl(wsUrl: string, token: string) {
      const video = videoRef.current;
      if (!video) return false;
      cleanupRtc();
      subs.clear();

      const socket = await connectWs(wsUrl, token);
      ws = socket;

      pc = new RTCPeerConnection({ iceServers: [{ urls: ["stun:stun.l.google.com:19302"] }] });
      pc.addTransceiver("video", { direction: "recvonly" });
      pc.addTransceiver("audio", { direction: "recvonly" });

      let sessionId: string | null = null;
      const pendingLocalIce: RTCIceCandidate[] = [];

      const flushIce = () => {
        if (!sessionId || !socket) return;
        while (pendingLocalIce.length) {
          const candidate = pendingLocalIce.shift();
          if (!candidate) continue;
          socket.send(
            JSON.stringify({
              id: ++msgId,
              type: "camera/webrtc/candidate",
              entity_id: entityId,
              session_id: sessionId,
              candidate: candidate.candidate,
              sdp_mid: candidate.sdpMid,
              sdp_m_line_index: candidate.sdpMLineIndex,
            }),
          );
        }
      };

      pc.ontrack = (ev) => {
        const stream = ev.streams[0] || new MediaStream([ev.track]);
        video.srcObject = stream;
        void video.play().catch(() => {});
      };
      pc.onicecandidate = (ev) => {
        if (!ev.candidate) return;
        pendingLocalIce.push(ev.candidate);
        flushIce();
      };

      const offerId = ++msgId;
      let gotAnswer = false;
      subs.set(offerId, {
        onEvent: (event) => {
          if (event.type === "session") {
            sessionId = String(event.session_id || "");
            flushIce();
          }
          if (event.type === "answer" && event.answer && pc) {
            gotAnswer = true;
            void pc.setRemoteDescription({ type: "answer", sdp: String(event.answer) }).catch(() => {});
          }
          if (event.type === "candidate" && event.candidate && pc) {
            void pc
              .addIceCandidate({
                candidate: String(event.candidate),
                sdpMid: event.sdp_mid != null ? String(event.sdp_mid) : "0",
                sdpMLineIndex: Number(event.sdp_m_line_index ?? 0),
              })
              .catch(() => {});
          }
          if (event.type === "error") {
            console.warn("[HomeAssistant] WebRTC:", event.message);
          }
        },
        onError: (err) => console.warn("[HomeAssistant] WebRTC offer:", err.message),
      });

      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      socket.send(
        JSON.stringify({
          id: offerId,
          type: "camera/webrtc/offer",
          entity_id: entityId,
          offer: offer.sdp,
        }),
      );

      // Wait for answer + decoded frames (ontrack alone can leave a black video).
      const start = Date.now();
      while (!cancelled && Date.now() - start < 8000) {
        if (gotAnswer) break;
        await new Promise((r) => setTimeout(r, 150));
      }
      if (cancelled) return false;
      if (!(await waitForFrames(video, 6000))) return false;
      if (cancelled) return false;
      setFeed("webrtc");
      setStatus("");
      return true;
    }

    async function startWebRtc(auth: StreamAuth) {
      const urls = [...new Set([...(auth.wsUrls || []), auth.wsUrl].filter(Boolean))];
      for (const url of urls) {
        if (cancelled) return false;
        try {
          setStatus("Starting live stream…");
          if (await startWebRtcOnUrl(url, auth.token)) return true;
        } catch (err) {
          console.warn("[HomeAssistant] WebRTC endpoint failed:", url, err);
        }
        cleanupRtc();
      }
      return false;
    }

    function directCameraUrl(base: string, token: string, stream = false) {
      const path = stream ? "camera_proxy_stream" : "camera_proxy";
      return `${base.replace(/\/$/, "")}/api/${path}/${encodeURIComponent(entityId)}?access_token=${encodeURIComponent(token)}&t=${Date.now()}`;
    }

    function startSnapshotLoop(auth: StreamAuth) {
      const img = imgRef.current;
      if (!img) return;
      const bases = [...new Set([...(auth.bases || []), auth.href].filter(Boolean))];
      let baseIndex = 0;
      let triedStream = false;

      const tick = () => {
        const base = bases[baseIndex] || auth.href;
        img.src = directCameraUrl(base, auth.token, triedStream);
      };

      img.onload = () => {
        if (img.naturalWidth < 2) {
          img.onerror?.(new Event("error"));
          return;
        }
        setFeed(triedStream ? "mjpeg" : "snapshot");
        setStatus("");
      };
      img.onerror = () => {
        if (!triedStream) {
          triedStream = true;
          tick();
          return;
        }
        if (baseIndex < bases.length - 1) {
          baseIndex += 1;
          triedStream = false;
          tick();
          return;
        }
        // Last resort: Homedash proxy
        img.src = cameraUrl(instanceId, entityId, false);
      };
      tick();
      snapTimer = setInterval(() => {
        if (document.hidden || cancelled) return;
        tick();
      }, 3000);
    }

    void (async () => {
      setFeed("none");
      setStatus("Connecting…");
      await wake();
      if (cancelled) return;
      let auth: StreamAuth | null = null;
      try {
        auth = await loadAuth();
        if (cancelled) return;
        if (await startWebRtc(auth)) return;
      } catch (err) {
        console.warn("[HomeAssistant] WebRTC unavailable:", err);
      }
      if (cancelled) return;
      cleanupRtc();
      setStatus("Loading snapshot…");
      if (auth) startSnapshotLoop(auth);
      else setStatus("Camera unavailable");
    })();

    return () => {
      cancelled = true;
      if (snapTimer) clearInterval(snapTimer);
      subs.clear();
      cleanupRtc();
    };
  }, [instanceId, entityId]);

  const live = mode === "webrtc" || mode === "mjpeg" || mode === "snapshot";

  return (
    <div className="ha-camera-modal-feed" id="ha-device-modal-feed">
      <div className={`ha-cam-fallback${live ? " ha-cam-placeholder--hidden" : ""}`}>
        <span className="ha-cam-fallback-icon">📷</span>
        <p className="ha-cam-fallback-title">{status || "Connecting…"}</p>
        <p className="ha-cam-fallback-note">Starting live stream via Home Assistant.</p>
        <a className="ha-btn ha-btn--primary" href={openHref} target="_blank" rel="noopener noreferrer">
          Open in HA
        </a>
      </div>
      <video
        ref={videoRef}
        className={`ha-cam-video${mode === "webrtc" ? " ha-cam-video--active" : ""}`}
        autoPlay
        playsInline
        muted
      />
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        ref={imgRef}
        className={`ha-cam-img${mode === "mjpeg" || mode === "snapshot" ? " ha-cam-img--loaded" : ""}`}
        alt=""
        referrerPolicy="no-referrer"
      />
    </div>
  );
}

export default function Widget() {
  const instance = useWidgetInstance();
  const id = instance?.instanceId || "homeassistant";
  const [data, setData] = useState<Data | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState("");
  const [modalId, setModalId] = useState<string | null>(null);
  const [cameraFeedHealth, setCameraFeedHealth] = useState<CameraFeedHealth>("weak");
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);

  const load = useCallback(async () => {
    try {
      const r = await fetch(`/api/widgets/homeassistant/status?instance=${encodeURIComponent(id)}`);
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "Failed to load Home Assistant");
      setData(j);
      setError("");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Home Assistant unavailable");
    }
  }, [id]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: 45_000 });

  const modalDevice = useMemo(
    () => data?.devices.find((d) => d.entityId === modalId || d.entity.entity_id === modalId) || null,
    [data, modalId],
  );

  useEffect(() => {
    if (!modalId) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setModalId(null);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [modalId]);

  async function runService(entityId: string, service?: string) {
    setBusy(entityId);
    try {
      const r = await fetch("/api/widgets/homeassistant/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: id, entityId, service }),
      });
      if (!r.ok) throw new Error("Action failed");
      await load();
    } finally {
      setBusy("");
    }
  }

  const weather = weatherText(data?.weather);
  const alertCount = data?.alerts.length || 0;
  const connectionSource = data?.connectionSource;

  if (!data) {
    return (
      <div className="hd-widget-body ha-body-flat" ref={rootRef}>
        <div className="ha-shell">
          <div className="ha-toolbar">
            <div className="ha-toolbar-left">
              <span className="ha-status ha-status--warn">Offline</span>
            </div>
            <div className="ha-toolbar-right">
              <button className="ha-open-link" type="button" onClick={() => void load()}>
                Retry
              </button>
            </div>
          </div>
          <div className="ha-loading">{error || "Loading Home Assistant…"}</div>
        </div>
      </div>
    );
  }

  return (
    <div className="hd-widget-body ha-body-flat" ref={rootRef}>
      <ConnectionCorner source={connectionSource || "unknown"} />
      <div className="ha-shell">
        <div className="ha-toolbar">
          <div className="ha-toolbar-left">
            <span className={`ha-status ${error ? "ha-status--warn" : "ha-status--ok"}`}>
              {error ? "Degraded" : "Online"}
            </span>
          </div>
          <div className="ha-toolbar-right">
            {openHref ? (
              <a className="ha-open-link" href={openHref} target="_blank" rel="noreferrer">
                Open
              </a>
            ) : null}
          </div>
        </div>

        {(weather || alertCount > 0) && (
          <div className="ha-header-stats">
            {weather ? (
              <div className="ha-chip ha-chip--cyan">
                <span className="ha-chip-value">{weather}</span>
                <span className="ha-chip-label">Weather</span>
              </div>
            ) : null}
            {alertCount > 0 ? (
              <div className="ha-chip ha-chip--red">
                <span className="ha-chip-value">{alertCount}</span>
                <span className="ha-chip-label">Alerts</span>
              </div>
            ) : null}
          </div>
        )}

        <div className="ha-main">
          {data.devices.length ? (
            <div className="ha-device-grid">
              {data.devices.map((device) => {
                const badge = cardBadge(device);
                const active = tileActive(device.entity);
                return (
                  <button
                    key={device.id}
                    type="button"
                    className={`ha-grid-card ha-grid-card--${device.kind} ha-grid-card--${device.id}${active ? " ha-grid-card--active" : ""}`}
                    onClick={() => {
                      setCameraFeedHealth("weak");
                      setModalId(device.entity.entity_id);
                    }}
                    aria-label={`Open ${device.label}`}
                  >
                    <div className={`ha-grid-card-visual ha-grid-card-visual--${device.kind} ha-grid-card-visual--${device.id}`}>
                      <span className="ha-grid-card-glow" aria-hidden="true" />
                      {device.kind === "camera" ? (
                        <CameraThumb instanceId={id} entityId={device.entity.entity_id} />
                      ) : device.kind === "media" && device.entity.attributes.entity_picture ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img className="ha-grid-card-art" src={String(device.entity.attributes.entity_picture)} alt="" />
                      ) : null}
                      <span className="ha-grid-card-glyph">{glyphFor(device)}</span>
                    </div>
                    <div className="ha-grid-card-body">
                      <div className="ha-grid-card-title">{device.label}</div>
                      <div className="ha-grid-card-status">{cardStatusLine(device)}</div>
                    </div>
                    <span className={`ha-grid-card-badge ha-grid-card-badge--${badge.cls}`}>{badge.text}</span>
                  </button>
                );
              })}
            </div>
          ) : (
            <div className="ha-empty">No devices found.</div>
          )}
        </div>

        {error ? <div className="ha-error">{error}</div> : null}
      </div>

      {modalDevice && typeof document !== "undefined"
        ? createPortal(
            <div
              id="ha-camera-modal-overlay"
              className="ha-camera-modal--visible"
              onClick={(e) => {
                if (e.target === e.currentTarget) setModalId(null);
              }}
            >
              <div
                className={`ha-camera-modal${modalDevice.kind === "camera" ? " ha-camera-modal--camera" : ""}`}
                role="dialog"
                aria-modal="true"
                aria-label="Device details"
              >
                <button type="button" className="ha-camera-modal-close" onClick={() => setModalId(null)} aria-label="Close">
                  ✕
                </button>
                <div className="ha-camera-modal-head">
                  <div className="ha-camera-modal-head-text">
                    <div className="ha-camera-modal-title">{modalDevice.label}</div>
                    {modalDevice.kind === "camera" ? (
                      <span className={`ha-camera-modal-badge ha-camera-modal-badge--${cameraFeedHealth}`}>
                        {cameraFeedHealth === "live"
                          ? "Live"
                          : cameraFeedHealth === "weak"
                            ? "Weak"
                            : "Disconnected"}
                      </span>
                    ) : (
                      <div className="ha-camera-modal-sub">
                        {modalDevice.entity.state}
                        {modalDevice.entity.last_changed
                          ? ` · updated ${timeAgo(modalDevice.entity.last_changed)}`
                          : ""}
                      </div>
                    )}
                  </div>
                  {modalDevice.kind === "media" && tileActive(modalDevice.entity) ? (
                    <span className="ha-camera-modal-badge ha-camera-modal-badge--live">Playing</span>
                  ) : null}
                </div>

                {modalDevice.kind === "camera" ? (
                  <CameraLiveFeed
                    instanceId={id}
                    entityId={modalDevice.entity.entity_id}
                    openHref={haEntityUrl(openHref || data.href, modalDevice.entity.entity_id)}
                    onHealthChange={setCameraFeedHealth}
                  />
                ) : (
                  <div id="ha-device-modal-hero">
                    <div className={`ha-device-hero ha-device-hero--${modalDevice.kind} ha-device-hero--${modalDevice.id}`}>
                      {modalDevice.kind === "media" && modalDevice.entity.attributes.entity_picture ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img className="ha-device-hero-art" src={String(modalDevice.entity.attributes.entity_picture)} alt="" />
                      ) : (
                        <span className="ha-device-hero-glyph">{glyphFor(modalDevice)}</span>
                      )}
                      <div className="ha-device-hero-text">
                        <div className="ha-device-hero-title">
                          {modalDevice.kind === "media" && modalDevice.entity.attributes.media_title
                            ? String(modalDevice.entity.attributes.media_title)
                            : modalDevice.label}
                        </div>
                        <div className="ha-device-hero-sub">
                          {modalDevice.kind === "media"
                            ? [
                                modalDevice.entity.attributes.media_artist,
                                modalDevice.entity.attributes.app_name || stateLabel(modalDevice.entity),
                              ]
                                .filter(Boolean)
                                .join(" · ")
                            : stateLabel(modalDevice.entity)}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                <div className="ha-camera-modal-body">
                  {domainOf(modalDevice.entity) === "media_player" ? (
                    <div className="ha-modal-actions-row">
                      <button
                        type="button"
                        className="ha-btn ha-btn--primary"
                        disabled={busy === modalDevice.entity.entity_id}
                        onClick={() => void runService(modalDevice.entity.entity_id, "media_play_pause")}
                      >
                        {["off", "idle", "standby", "paused"].includes(modalDevice.entity.state) ? "Play" : "Pause"}
                      </button>
                      <button
                        type="button"
                        className="ha-btn ha-btn--ghost"
                        disabled={busy === modalDevice.entity.entity_id}
                        onClick={() => void runService(modalDevice.entity.entity_id, "media_stop")}
                      >
                        Stop
                      </button>
                    </div>
                  ) : null}

                  {(() => {
                    const stats = modalStats(modalDevice.related, modalDevice.entity);
                    if (!stats.length) return null;
                    return (
                      <div className="ha-modal-stats">
                        {stats.map((s) => (
                          <div className="ha-modal-stat" key={`${s.label}-${s.value}`}>
                            <span className="ha-modal-stat-label">{s.label}</span>
                            <span className="ha-modal-stat-value">{s.value}</span>
                          </div>
                        ))}
                      </div>
                    );
                  })()}

                  {(() => {
                    const toggles = modalToggles(modalDevice.related);
                    if (!toggles.length) return null;
                    return (
                      <div className="ha-modal-toggles">
                        {toggles.map((e) => {
                          const on = tileActive(e);
                          return (
                            <button
                              key={e.entity_id}
                              type="button"
                              className={`ha-modal-toggle${on ? " ha-modal-toggle--on" : ""}${busy === e.entity_id ? " ha-modal-toggle--busy" : ""}`}
                              disabled={busy === e.entity_id}
                              onClick={() => void runService(e.entity_id)}
                            >
                              <span className="ha-modal-toggle-info">
                                <span className="ha-modal-toggle-name">{shortName(e)}</span>
                                <span className="ha-modal-toggle-state">{e.state}</span>
                              </span>
                              <span className="ha-modal-toggle-track" aria-hidden="true">
                                <span className="ha-modal-toggle-thumb" />
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    );
                  })()}
                </div>

                <div className="ha-camera-modal-actions">
                  <a
                    className="ha-btn ha-btn--primary ha-btn--wide"
                    href={haEntityUrl(openHref || data.href, modalDevice.entity.entity_id)}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Open in Home Assistant
                  </a>
                </div>
              </div>
            </div>,
            document.body,
          )
        : null}
    </div>
  );
}
