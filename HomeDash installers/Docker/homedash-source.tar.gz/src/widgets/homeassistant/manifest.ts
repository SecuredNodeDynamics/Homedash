import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "homeassistant",
  name: "Home Assistant",
  description: "Device grid, camera snapshots, and service controls",
  version: "0.2.5",
  category: "Infra",
  defaultSize: { w: 5, h: 5, minW: 3, minH: 3 },
  hostClass: "ha-host ha-widget-host",
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "http://10.0.0.1:8123",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      placeholder: "https://homeassistant.example.com",
    },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url", placeholder: "http://10.0.0.1:8123" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    {
      key: "token",
      label: "Long-lived token",
      type: "password",
      required: true,
    },
    {
      key: "apiKey",
      label: "API key (alias for token)",
      type: "password",
    },
    {
      key: "devices",
      label: "Devices JSON (optional)",
      type: "text",
      placeholder: '[{"id":"ring","label":"Ring","kind":"camera","entityId":"camera.front_door"}]',
    },
  ],
};
