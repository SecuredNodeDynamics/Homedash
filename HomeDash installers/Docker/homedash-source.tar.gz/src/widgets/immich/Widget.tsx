"use client";
import "@/styles/widgets/immich.widget.css";


import { useCallback, useEffect, useMemo, useRef, useState, type PointerEvent as ReactPointerEvent, useLayoutEffect } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type SortMode = "recent" | "alpha" | "count" | "shared";

type Album = {
  id: string;
  name: string;
  count: number;
  thumbnail: string;
  updatedAt: string;
  lastModified: string;
  shared: boolean;
  owner: string;
  href: string;
};

type AlbumAsset = {
  id: string;
  type: string;
  name: string;
  takenAt: string;
  thumbnail: string;
};

type AlbumDetail = {
  id: string;
  name: string;
  count: number;
  shared: boolean;
  href: string;
  assets: AlbumAsset[];
};

type ConnectionSource = "private" | "public" | "unknown";

const CONNECTION_SOURCE_LABEL: Record<ConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

function ConnectionCorner({ source }: { source: ConnectionSource }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const mark = (
    <div
      className={`immich-corner-source immich-corner-source--${source}`}
      title={CONNECTION_SOURCE_LABEL[source]}
      aria-label={CONNECTION_SOURCE_LABEL[source]}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}


type Data = {
  href: string;
  openFallbackUrl?: string;
  connectionSource?: ConnectionSource;
  albums: Album[];
};

const SORT_TABS: Array<{ key: SortMode; label: string }> = [
  { key: "recent", label: "Recent" },
  { key: "alpha", label: "A–Z" },
  { key: "count", label: "Most photos" },
  { key: "shared", label: "Shared" },
];

const POLL_MS = 5 * 120 * 1000;
const SWIPE_X = 56;
const SWIPE_Y = 90;
const MAX_ZOOM = 3.5;
const MIN_ZOOM = 1;

function formatDate(dateStr?: string) {
  if (!dateStr) return "";
  try {
    return new Date(dateStr).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  } catch {
    return "";
  }
}

function pluralize(n: number, word: string) {
  return `${n.toLocaleString()} ${word}${n !== 1 ? "s" : ""}`;
}

function sortAlbums(list: Album[], mode: SortMode) {
  const copy = [...list];
  if (mode === "alpha") {
    return copy.sort((a, b) => a.name.localeCompare(b.name));
  }
  if (mode === "count") {
    return copy.sort((a, b) => b.count - a.count);
  }
  if (mode === "shared") {
    return copy.filter((a) => a.shared).concat(copy.filter((a) => !a.shared));
  }
  return copy.sort(
    (a, b) => new Date(b.updatedAt || 0).getTime() - new Date(a.updatedAt || 0).getTime(),
  );
}

function PlaceholderArt() {
  return (
    <div className="immich-album-placeholder">
      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden>
        <rect x="3" y="3" width="18" height="18" rx="2" />
        <circle cx="8.5" cy="8.5" r="1.5" />
        <polyline points="21 15 16 10 5 21" />
      </svg>
    </div>
  );
}

function SkeletonGrid({ count = 8 }: { count?: number }) {
  return (
    <div className="immich-grid immich-grid--skeleton">
      {Array.from({ length: count }, (_, i) => (
        <div className="immich-album-card immich-album-card--skeleton" key={i}>
          <div className="immich-album-art immich-skeleton" />
          <div className="immich-album-meta">
            <div className="immich-skeleton immich-skeleton--title" />
            <div className="immich-skeleton immich-skeleton--sub" />
          </div>
        </div>
      ))}
    </div>
  );
}

function AlbumCard({
  album,
  index,
  onOpen,
}: {
  album: Album;
  index: number;
  onOpen: (album: Album) => void;
}) {
  const [broken, setBroken] = useState(false);
  const date = formatDate(album.lastModified || album.updatedAt);
  const showThumb = Boolean(album.thumbnail) && !broken;

  return (
    <button
      type="button"
      className="immich-album-card"
      style={{ animationDelay: `${index * 45}ms` }}
      title={album.name}
      onClick={() => onOpen(album)}
    >
      <div className="immich-album-art">
        {showThumb ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={album.thumbnail}
            alt={album.name}
            loading="lazy"
            decoding="async"
            onError={() => setBroken(true)}
          />
        ) : (
          <PlaceholderArt />
        )}
        <div className="immich-album-overlay">
          <div className="immich-album-count">{pluralize(album.count, "photo")}</div>
          {album.shared ? <div className="immich-album-badge">Shared</div> : null}
        </div>
      </div>
      <div className="immich-album-meta">
        <div className="immich-album-name">{album.name}</div>
        {date ? <div className="immich-album-date">{date}</div> : null}
        {album.owner ? <div className="immich-album-owner">{album.owner}</div> : null}
      </div>
    </button>
  );
}

function AlbumPopup({
  album,
  instanceId,
  onClose,
}: {
  album: Album;
  instanceId: string;
  onClose: () => void;
}) {
  const [detail, setDetail] = useState<AlbumDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [activeId, setActiveId] = useState("");
  const [dragX, setDragX] = useState(0);
  const [dragY, setDragY] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const thumbsRef = useRef<HTMLDivElement>(null);
  const pointersRef = useRef(new Map<number, { x: number; y: number }>());
  const gestureRef = useRef<{
    mode: "none" | "swipe" | "pan" | "pinch";
    startX: number;
    startY: number;
    panX: number;
    panY: number;
    zoom: number;
    pinchDist: number;
    moved: boolean;
  }>({
    mode: "none",
    startX: 0,
    startY: 0,
    panX: 0,
    panY: 0,
    zoom: 1,
    pinchDist: 0,
    moved: false,
  });
  const lastTapRef = useRef(0);

  useEffect(() => {
    let alive = true;
    setLoading(true);
    setError("");
    setDetail(null);
    setActiveId("");
    setZoom(1);
    setPan({ x: 0, y: 0 });
    setDragX(0);
    setDragY(0);
    fetch(
      `/api/widgets/immich/album?instance=${encodeURIComponent(instanceId)}&id=${encodeURIComponent(album.id)}`,
    )
      .then(async (response) => {
        const json = await response.json();
        if (!response.ok) throw new Error(json.error || "Failed to load album");
        if (!alive) return;
        setDetail(json);
        setActiveId(json.assets?.[0]?.id || "");
      })
      .catch((cause) => {
        if (alive) setError(cause instanceof Error ? cause.message : "Failed to load album");
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [album.id, instanceId]);

  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  const assets = detail?.assets || [];
  const activeIndex = Math.max(
    0,
    assets.findIndex((asset) => asset.id === activeId),
  );
  const active = assets[activeIndex] || null;
  const backdrop = active?.thumbnail || album.thumbnail;

  const resetView = useCallback(() => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
    setDragX(0);
    setDragY(0);
  }, []);

  const step = useCallback(
    (dir: -1 | 1) => {
      if (!assets.length) return;
      const next = (activeIndex + dir + assets.length) % assets.length;
      setActiveId(assets[next].id);
      resetView();
    },
    [activeIndex, assets, resetView],
  );

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
      if (event.key === "ArrowRight") step(1);
      if (event.key === "ArrowLeft") step(-1);
      if (event.key === "+" || event.key === "=") setZoom((z) => Math.min(MAX_ZOOM, z + 0.35));
      if (event.key === "-") {
        setZoom((z) => {
          const next = Math.max(MIN_ZOOM, z - 0.35);
          if (next <= 1) setPan({ x: 0, y: 0 });
          return next;
        });
      }
      if (event.key === "0") resetView();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose, resetView, step]);

  useEffect(() => {
    const root = thumbsRef.current;
    if (!root || !activeId) return;
    const thumb = root.querySelector<HTMLElement>(`[data-asset-id="${activeId}"]`);
    thumb?.scrollIntoView({ behavior: "smooth", inline: "center", block: "nearest" });
  }, [activeId]);

  function pointerDistance() {
    const points = [...pointersRef.current.values()];
    if (points.length < 2) return 0;
    const [a, b] = points;
    return Math.hypot(a.x - b.x, a.y - b.y);
  }

  function onPointerDown(event: ReactPointerEvent<HTMLDivElement>) {
    if (event.button != null && event.button !== 0) return;
    const target = event.target as HTMLElement;
    if (target.closest("button, a")) return;

    event.currentTarget.setPointerCapture(event.pointerId);
    pointersRef.current.set(event.pointerId, { x: event.clientX, y: event.clientY });

    const g = gestureRef.current;
    g.startX = event.clientX;
    g.startY = event.clientY;
    g.panX = pan.x;
    g.panY = pan.y;
    g.zoom = zoom;
    g.moved = false;

    if (pointersRef.current.size >= 2) {
      g.mode = "pinch";
      g.pinchDist = pointerDistance() || 1;
      return;
    }

    g.mode = zoom > 1.02 ? "pan" : "swipe";

    const now = Date.now();
    if (now - lastTapRef.current < 280 && pointersRef.current.size === 1) {
      lastTapRef.current = 0;
      if (zoom > 1.05) resetView();
      else {
        setZoom(2.2);
        setPan({ x: 0, y: 0 });
      }
      return;
    }
    lastTapRef.current = now;
  }

  function onPointerMove(event: ReactPointerEvent<HTMLDivElement>) {
    if (!pointersRef.current.has(event.pointerId)) return;
    pointersRef.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
    const g = gestureRef.current;

    if (pointersRef.current.size >= 2) {
      g.mode = "pinch";
      const dist = pointerDistance() || 1;
      if (!g.pinchDist) g.pinchDist = dist;
      const nextZoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, g.zoom * (dist / g.pinchDist)));
      setZoom(nextZoom);
      if (nextZoom <= 1) setPan({ x: 0, y: 0 });
      g.moved = true;
      return;
    }

    const dx = event.clientX - g.startX;
    const dy = event.clientY - g.startY;
    if (Math.hypot(dx, dy) > 8) g.moved = true;

    if (g.mode === "pan" || zoom > 1.02) {
      setPan({ x: g.panX + dx, y: g.panY + dy });
      return;
    }

    if (g.mode === "swipe") {
      if (Math.abs(dx) > Math.abs(dy)) {
        setDragX(dx);
        setDragY(0);
      } else if (dy > 0) {
        setDragY(dy);
        setDragX(0);
      }
    }
  }

  function endPointer(event: ReactPointerEvent<HTMLDivElement>) {
    if (!pointersRef.current.has(event.pointerId)) return;
    pointersRef.current.delete(event.pointerId);
    try {
      event.currentTarget.releasePointerCapture(event.pointerId);
    } catch {
      // already released
    }

    if (pointersRef.current.size >= 2) return;
    if (pointersRef.current.size === 1) {
      const remaining = [...pointersRef.current.values()][0];
      const g = gestureRef.current;
      g.mode = zoom > 1.02 ? "pan" : "swipe";
      g.startX = remaining.x;
      g.startY = remaining.y;
      g.panX = pan.x;
      g.panY = pan.y;
      g.zoom = zoom;
      return;
    }

    const g = gestureRef.current;
    const dx = dragX;
    const dy = dragY;

    if (g.mode === "pinch") {
      if (zoom <= 1.02) resetView();
      g.mode = "none";
      return;
    }

    if (g.mode === "swipe" && g.moved) {
      if (Math.abs(dx) >= SWIPE_X && Math.abs(dx) > Math.abs(dy)) {
        step(dx < 0 ? 1 : -1);
      } else if (dy >= SWIPE_Y) {
        onClose();
        return;
      }
    }

    setDragX(0);
    setDragY(0);
    g.mode = "none";
  }

  const stageStyle = useMemo(() => {
    const closing = dragY > 0 && zoom <= 1.02;
    const opacity = closing ? Math.max(0.35, 1 - dragY / 320) : 1;
    const scale = closing ? Math.max(0.92, 1 - dragY / 900) : 1;
    return {
      transform: `translate3d(${dragX + pan.x}px, ${dragY + pan.y}px, 0) scale(${scale * zoom})`,
      opacity,
      transition: pointersRef.current.size ? "none" : "transform 180ms ease, opacity 180ms ease",
      touchAction: "none" as const,
      cursor: zoom > 1 ? ("grab" as const) : ("default" as const),
    };
  }, [dragX, dragY, pan.x, pan.y, zoom]);

  return createPortal(
    <>
      <div className="immich-popup-backdrop" onClick={onClose} />
      <div className="immich-popup" role="dialog" aria-modal="true" aria-label={album.name}>
        {backdrop ? (
          <div className="immich-popup-bg" style={{ backgroundImage: `url('${backdrop}')` }} />
        ) : null}

        <header className="immich-popup-top">
          <div className="immich-popup-heading">
            <div className="immich-popup-title">{detail?.name || album.name}</div>
            <div className="immich-popup-kicker">
              {[
                pluralize(detail?.count ?? album.count, "photo"),
                album.shared || detail?.shared ? "Shared" : "",
                album.owner,
              ]
                .filter(Boolean)
                .join(" · ")}
            </div>
          </div>
          <div className="immich-popup-top-actions">
            <a
              className="immich-popup-open"
              href={detail?.href || album.href}
              target="_blank"
              rel="noopener noreferrer"
            >
              Open in Immich
            </a>
            <button className="immich-popup-close" type="button" aria-label="Close" onClick={onClose}>
              ×
            </button>
          </div>
        </header>

        <div className="immich-popup-stage">
          {loading ? (
            <div className="immich-popup-empty">Loading album…</div>
          ) : error ? (
            <div className="immich-popup-empty immich-popup-empty--error">{error}</div>
          ) : active ? (
            <div
              className={`immich-popup-hero${zoom > 1.02 ? " immich-popup-hero--zoomed" : ""}`}
              onPointerDown={onPointerDown}
              onPointerMove={onPointerMove}
              onPointerUp={endPointer}
              onPointerCancel={endPointer}
            >
              <div className="immich-popup-hero-frame" style={stageStyle}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={active.thumbnail} alt={active.name} draggable={false} />
              </div>
              <div className="immich-popup-caption">
                <div className="immich-popup-caption-main">
                  <strong>{active.name}</strong>
                  <span>
                    {activeIndex + 1} / {assets.length}
                    {active.takenAt ? ` · ${formatDate(active.takenAt)}` : ""}
                    {active.type === "VIDEO" ? " · Video" : ""}
                  </span>
                </div>
                {assets.length > 1 && zoom <= 1.02 ? (
                  <div className="immich-popup-hint">
                    Swipe · pinch / double-tap to zoom · swipe down to close
                  </div>
                ) : null}
              </div>
            </div>
          ) : (
            <div className="immich-popup-empty">No photos in this album</div>
          )}
        </div>

        {assets.length ? (
          <div className="immich-popup-footer">
            <div
              className="immich-popup-thumbs"
              ref={thumbsRef}
              role="listbox"
              aria-label="Album photos"
            >
              {assets.map((asset) => (
                <button
                  key={asset.id}
                  type="button"
                  role="option"
                  data-asset-id={asset.id}
                  aria-selected={asset.id === activeId}
                  className={`immich-popup-thumb${asset.id === activeId ? " immich-popup-thumb--active" : ""}`}
                  onClick={() => {
                    setActiveId(asset.id);
                    resetView();
                  }}
                  title={asset.name}
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={asset.thumbnail} alt="" loading="lazy" decoding="async" />
                  {asset.type === "VIDEO" ? <span className="immich-popup-video">▶</span> : null}
                </button>
              ))}
            </div>
            <div className="immich-popup-counter">
              {activeIndex + 1} <span>/ {assets.length}</span>
            </div>
          </div>
        ) : null}
      </div>
    </>,
    document.body,
  );
}

export default function ImmichWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "immich";
  const [data, setData] = useState<Data | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<SortMode>("recent");
  const [selected, setSelected] = useState<Album | null>(null);
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);

  const load = useCallback(
    async (opts?: { soft?: boolean }) => {
      if (!opts?.soft) setLoading(true);
      try {
        const response = await fetch(
          `/api/widgets/immich/status?instance=${encodeURIComponent(instanceId)}`,
        );
        const json = await response.json();
        if (!response.ok) throw new Error(json.error || "Failed to load Immich");
        setData(json);
        setError("");
      } catch (cause) {
        if (!opts?.soft) {
          setError(cause instanceof Error ? cause.message : "Failed to load Immich");
        }
      } finally {
        if (!opts?.soft) setLoading(false);
      }
    },
    [instanceId],
  );

  const { rootRef } = useWidgetPoll(load, { intervalMs: POLL_MS });

  const filtered = useMemo(() => {
    if (!data) return [];
    const q = query.trim().toLowerCase();
    const sorted = sortAlbums(data.albums, sort);
    if (!q) return sorted;
    return sorted.filter((a) => a.name.toLowerCase().includes(q));
  }, [data, query, sort]);

  const totalPhotos = useMemo(
    () => (data ? data.albums.reduce((n, a) => n + (a.count || 0), 0) : 0),
    [data],
  );

  if (loading && !data) {
    return (
      <div className="hd-widget-body immich-body-flat" ref={rootRef}>
        <div className="immich-shell immich-shell--loading">
          <SkeletonGrid />
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="hd-widget-body immich-body-flat" ref={rootRef}>
        <div className="immich-shell">
          <div className="immich-toolbar">
            <div className="immich-toolbar-left">
              <span className="immich-status-pill immich-status-pill--warn">
                <span className="immich-status-dot" aria-hidden="true" />
                Offline
              </span>
            </div>
            <div className="immich-toolbar-right">
              <button className="immich-open-btn" type="button" onClick={() => void load()}>
                Retry
              </button>
            </div>
          </div>
          <div className="immich-error">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden>
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="8" x2="12" y2="12" />
              <line x1="12" y1="16" x2="12.01" y2="16" />
            </svg>
            <div className="immich-error-title">Immich Unavailable</div>
            <div className="immich-error-msg">{error || "Failed to load albums"}</div>
          </div>
        </div>
      </div>
    );
  }

  const isOnline = Boolean(data.href || data.albums.length) && !error;
  const connectionSource: ConnectionSource = data.connectionSource || "unknown";

  return (
    <div className="hd-widget-body immich-body-flat" ref={rootRef}>
      <ConnectionCorner source={connectionSource} />
      <div className="immich-shell">
        <div className="immich-toolbar">
          <div className="immich-toolbar-left">
            <span className={`immich-status-pill${isOnline ? " immich-status-pill--ok" : " immich-status-pill--warn"}`}>
              <span className="immich-status-dot" aria-hidden="true" />
              {isOnline ? "Online" : "Offline"}
            </span>
            <span className="immich-meta">
              {pluralize(data.albums.length, "album")} · {pluralize(totalPhotos, "photo")}
            </span>
          </div>
          <div className="immich-toolbar-right">
            {openHref ? (
              <a className="immich-open-btn" href={openHref} target="_blank" rel="noopener noreferrer">
                Open
              </a>
            ) : null}
          </div>
        </div>

        <div className="immich-filter-bar">
          <input
            className="immich-search"
            type="text"
            placeholder="Search albums…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoComplete="off"
          />
          <div className="immich-sort-tabs" role="tablist">
            {SORT_TABS.map((tab) => (
              <button
                key={tab.key}
                type="button"
                role="tab"
                aria-selected={sort === tab.key}
                className={`immich-sort-tab${sort === tab.key ? " immich-sort-tab--active" : ""}`}
                onClick={() => setSort(tab.key)}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {filtered.length ? (
          <div className="immich-grid">
            {filtered.map((album, index) => (
              <AlbumCard
                album={album}
                index={index}
                key={album.id}
                onOpen={setSelected}
              />
            ))}
          </div>
        ) : (
          <div className="immich-empty">
            {query.trim() ? "No albums match your search." : "No albums found."}
          </div>
        )}
      </div>

      {selected ? (
        <AlbumPopup album={selected} instanceId={instanceId} onClose={() => setSelected(null)} />
      ) : null}
    </div>
  );
}
