import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "immich",
  name: "Immich",
  description: "Photo albums with search, sort, and album preview popup",
  version: "0.4.3",
  category: "Media",
  defaultSize: { w: 5, h: 5, minW: 3, minH: 3 },
  hostClass: "immich-albums-host",
  configFields: [
  {
    "key": "baseUrl",
    "label": "Private - IP",
    "type": "url",
    "placeholder": "http://10.0.0.1:2283"
  },
  {
    "key": "fallbackUrl",
    "label": "Fallback Public URL",
    "type": "url",
    "placeholder": "https://immich.example.com"
  },
  {
    "key": "publicUrl",
    "label": "OPEN - Private URL",
    "type": "url",
    "placeholder": "http://10.0.0.1:2283"
  },
  {
    "key": "openFallbackUrl",
    "label": "OPEN - Public URL",
    "type": "url",
    "placeholder": "https://… (Cloudflare)"
  },
  {
    "key": "apiKey",
    "label": "API Key",
    "type": "password",
    "required": true
  }
],
};
