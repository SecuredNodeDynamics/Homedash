"use client";
import "@/styles/widgets/invest.widget.css";


import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "../_shared/instance-context";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";
import type { CryptoMarketItem } from "@/lib/widgets/invest-crypto";

type IntervalKey = "1h" | "24h" | "7d";
type ChartTab = "1h" | "24h" | "7d" | "live";

/** Slice ~7d hourly sparkline for chart tabs (client-safe; keep out of server lib). */
function sparklineForTab(sparkline: number[], tab: ChartTab) {
  if (!sparkline.length) return [];
  if (tab === "7d") return sparkline;
  if (tab === "24h" || tab === "live") return sparkline.slice(-24);
  return sparkline.slice(-3);
}

const INTERVALS: Array<{ label: IntervalKey; field: keyof CryptoMarketItem }> = [
  { label: "1h", field: "price_change_percentage_1h_in_currency" },
  { label: "24h", field: "price_change_percentage_24h_in_currency" },
  { label: "7d", field: "price_change_percentage_7d_in_currency" },
];

const POLL_MS = 240_000;

function fmtPrice(n: number | null | undefined) {
  if (n == null || Number.isNaN(n)) return "—";
  if (n >= 1000) {
    return "$" + n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  if (n >= 1) return "$" + n.toFixed(2);
  if (n >= 0.01) return "$" + n.toFixed(4);
  return "$" + n.toFixed(6);
}

function fmtPct(n: number | null | undefined) {
  if (n == null || Number.isNaN(n)) return "—";
  return (n > 0 ? "+" : "") + n.toFixed(2) + "%";
}

function changeCls(n: number | null | undefined) {
  if (n == null || Number.isNaN(n) || n === 0) return "invest-row-change--flat";
  return n > 0 ? "invest-row-change--up" : "invest-row-change--down";
}

function fmt2(v: number | null | undefined) {
  if (v == null) return "—";
  return "$" + v.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function fmtBig(v: number | null | undefined) {
  if (v == null) return "—";
  if (v >= 1e12) return "$" + (v / 1e12).toFixed(2) + "T";
  if (v >= 1e9) return "$" + (v / 1e9).toFixed(2) + "B";
  if (v >= 1e6) return "$" + (v / 1e6).toFixed(2) + "M";
  return "$" + v.toLocaleString();
}

function pctForInterval(item: CryptoMarketItem, interval: IntervalKey) {
  const field = INTERVALS.find((i) => i.label === interval)?.field
    || "price_change_percentage_1h_in_currency";
  const value = item[field];
  return typeof value === "number" ? value : null;
}

function buildSparkline(values: number[], color: string, W = 280, H = 72) {
  if (!values || values.length < 2) {
    return (
      <svg viewBox={`0 0 ${W} ${H}`} width={W} height={H}>
        <text
          x={W / 2}
          y={H / 2}
          textAnchor="middle"
          fill="rgba(255,255,255,0.2)"
          fontSize="11"
          dominantBaseline="middle"
        >
          No data
        </text>
      </svg>
    );
  }
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;
  const pts = values.map((v, i) => {
    const x = (i / (values.length - 1)) * W;
    const y = H - ((v - min) / range) * H * 0.85 - H * 0.05;
    return { x, y };
  });
  const lineD = `M ${pts.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" L ")}`;
  const areaD = `${lineD} L ${W},${H} L 0,${H} Z`;
  const last = pts[pts.length - 1];
  const gId = `ig-${Math.random().toString(36).slice(2, 8)}`;

  return (
    <svg viewBox={`0 0 ${W} ${H}`} width={W} height={H} style={{ overflow: "visible" }}>
      <defs>
        <linearGradient id={gId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.22" />
          <stop offset="100%" stopColor={color} stopOpacity="0.01" />
        </linearGradient>
      </defs>
      <path d={areaD} fill={`url(#${gId})`} />
      <path
        d={lineD}
        fill="none"
        stroke={color}
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle
        cx={last.x}
        cy={last.y}
        r="3"
        fill={color}
        stroke="rgba(0,0,0,0.4)"
        strokeWidth="1"
      />
    </svg>
  );
}

function CryptoPopup({
  item,
  interval,
  onClose,
}: {
  item: CryptoMarketItem;
  interval: IntervalKey;
  onClose: () => void;
}) {
  const [chartTab, setChartTab] = useState<ChartTab>("live");
  const [prices, setPrices] = useState<number[] | null>(null);
  const [chartLoading, setChartLoading] = useState(true);
  const [chartError, setChartError] = useState("");
  const cacheRef = useRef<Record<string, number[]>>({});

  const pct = pctForInterval(item, interval);
  const chartColor = pct == null ? "#60a5fa" : pct >= 0 ? "#6ee7b7" : "#f87171";

  const meta = useMemo(
    () => [
      { label: "Market Cap", value: fmtBig(item.market_cap) },
      { label: "24h High", value: fmt2(item.high_24h) },
      { label: "24h Low", value: fmt2(item.low_24h) },
      { label: "24h Volume", value: fmtBig(item.total_volume) },
      { label: "Rank", value: item.market_cap_rank ? `#${item.market_cap_rank}` : "—" },
      {
        label: "Circ Supply",
        value: item.circulating_supply
          ? `${item.circulating_supply.toLocaleString("en-US", { maximumFractionDigits: 0 })} ${item.symbol}`
          : "—",
      },
    ],
    [item],
  );

  const stats = useMemo(() => {
    if (!prices || prices.length < 2) return null;
    const min = Math.min(...prices);
    const max = Math.max(...prices);
    const open = prices[0];
    const close = prices[prices.length - 1];
    const chg = ((close - open) / open) * 100;
    const isUp = close >= open;
    return { min, max, open, close, chg, isUp };
  }, [prices]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  useEffect(() => {
    let alive = true;
    const cacheKey = `${item.id}:${chartTab}`;
    const cached = cacheRef.current[cacheKey];
    if (cached) {
      setPrices(cached);
      setChartLoading(false);
      setChartError("");
      return;
    }

    // Prefer markets sparkline — no extra CoinGecko call (avoids HTTP 429)
    const fromSpark = sparklineForTab(item.sparkline || [], chartTab);
    if (fromSpark.length >= 2) {
      cacheRef.current[cacheKey] = fromSpark;
      setPrices(fromSpark);
      setChartLoading(false);
      setChartError("");
      return;
    }

    const days = chartTab === "7d" ? 7 : 1;
    setChartLoading(true);
    setChartError("");
    setPrices(null);
    fetch(
      `/api/widgets/invest-crypto/chart?id=${encodeURIComponent(item.id)}&days=${days}`,
    )
      .then(async (res) => {
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.error || "Chart unavailable");
        return data as { prices?: number[] };
      })
      .then((data) => {
        if (!alive) return;
        const values = Array.isArray(data.prices) ? data.prices : [];
        if (values.length) cacheRef.current[cacheKey] = values;
        setPrices(values);
        setChartLoading(false);
      })
      .catch((err) => {
        if (!alive) return;
        setChartError(err instanceof Error ? err.message : "Chart unavailable");
        setChartLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [chartTab, item.id, item.sparkline]);

  const [imgFailed, setImgFailed] = useState(false);

  return createPortal(
    <div className="invest-popup-backdrop is-open" onClick={onClose}>
      <div
        className="invest-popup invest-popup--centered"
        role="dialog"
        aria-modal="true"
        aria-label={`${item.symbol} details`}
        onClick={(e) => e.stopPropagation()}
      >
        <button type="button" className="invest-popup__close" onClick={onClose} aria-label="Close">
          ✕
        </button>
        <div className="invest-popup__header">
          <div className="invest-popup__header-left">
            <div className="invest-row-icon" style={{ width: 36, height: 36, flexShrink: 0 }}>
              {!imgFailed ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={item.image}
                  alt={item.symbol}
                  style={{ width: 24, height: 24 }}
                  onError={() => setImgFailed(true)}
                />
              ) : (
                item.emoji
              )}
            </div>
            <div>
              <div className="invest-popup__ticker">{item.symbol}</div>
              <div className="invest-popup__name">{item.name}</div>
            </div>
          </div>
          <div className="invest-popup__header-right">
            <div className="invest-popup__price">{fmtPrice(item.current_price)}</div>
            <div className={`invest-row-change ${changeCls(pct)}`} style={{ fontSize: "0.70rem" }}>
              {pct == null || Number.isNaN(pct) ? "" : pct > 0 ? "▲ " : "▼ "}
              {fmtPct(pct)}
            </div>
          </div>
        </div>

        <div className="invest-popup__meta">
          {meta.map((row) => (
            <div className="invest-popup__meta-row" key={row.label}>
              <span className="invest-popup__meta-label">{row.label}</span>
              <span className="invest-popup__meta-value">{row.value}</span>
            </div>
          ))}
        </div>

        <div className="invest-popup__divider" />

        <div className="invest-popup__chart-tabs">
          {(["1h", "24h", "7d", "live"] as ChartTab[]).map((tab) => (
            <button
              key={tab}
              type="button"
              className={`invest-popup__chart-tab${chartTab === tab ? " invest-popup__chart-tab--active" : ""}`}
              onClick={() => setChartTab(tab)}
            >
              {tab === "live" ? "Live" : tab}
            </button>
          ))}
        </div>

        <div className="invest-popup__chart-area">
          {chartLoading ? (
            <div className="invest-popup__chart-loading">
              <svg
                className="invest-popup__spin"
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" />
              </svg>
              Loading chart…
            </div>
          ) : chartError || !prices || prices.length < 2 ? (
            <div className="invest-popup__chart-loading" style={{ color: "rgba(255,255,255,0.3)" }}>
              {chartError || "No data available"}
            </div>
          ) : (
            buildSparkline(prices, chartColor)
          )}
        </div>

        <div className="invest-popup__chart-stats">
          {stats ? (
            <>
              <div className="invest-popup__stat">
                <span>Open</span>
                <span>{fmtPrice(stats.open)}</span>
              </div>
              <div className="invest-popup__stat">
                <span>High</span>
                <span style={{ color: "#6ee7b7" }}>{fmtPrice(stats.max)}</span>
              </div>
              <div className="invest-popup__stat">
                <span>Low</span>
                <span style={{ color: "#f87171" }}>{fmtPrice(stats.min)}</span>
              </div>
              <div className="invest-popup__stat">
                <span>Change</span>
                <span style={{ color: stats.isUp ? "#6ee7b7" : "#f87171" }}>
                  {stats.isUp ? "+" : ""}
                  {stats.chg.toFixed(2)}%
                </span>
              </div>
            </>
          ) : null}
        </div>

        <a
          className="invest-popup__link"
          href={`https://www.coingecko.com/en/coins/${item.id}`}
          target="_blank"
          rel="noopener noreferrer"
        >
          View on CoinGecko ↗
        </a>
      </div>
    </div>,
    document.body,
  );
}

function RowIcon({ src, fallback }: { src: string; fallback: string }) {
  const [failed, setFailed] = useState(false);
  return (
    <div className="invest-row-icon">
      {!failed ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={src} alt="" loading="lazy" onError={() => setFailed(true)} />
      ) : (
        fallback
      )}
    </div>
  );
}

export default function Widget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "invest-crypto";
  const [items, setItems] = useState<CryptoMarketItem[]>([]);
  const [interval, setIntervalKey] = useState<IntervalKey>("1h");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [footer, setFooter] = useState("loading…");
  const [mounted, setMounted] = useState(false);
  const [active, setActive] = useState<CryptoMarketItem | null>(null);
  const appliedDefault = useRef(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const load = useCallback(async () => {
    const response = await fetch(
      `/api/widgets/invest-crypto/status?instance=${encodeURIComponent(instanceId)}`,
    );
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || "Failed to load crypto");
    const next = Array.isArray(data.items) ? (data.items as CryptoMarketItem[]) : [];
    setItems(next);
    if (
      !appliedDefault.current &&
      (data.defaultInterval === "1h" || data.defaultInterval === "24h" || data.defaultInterval === "7d")
    ) {
      appliedDefault.current = true;
      setIntervalKey(data.defaultInterval);
    }
    setFooter(new Date().toLocaleTimeString());
    setError("");
  }, [instanceId]);

  const poll = useCallback(async () => {
    try {
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load crypto");
    } finally {
      setLoading(false);
    }
  }, [load]);
  const { rootRef } = useWidgetPoll(poll, { intervalMs: POLL_MS });

  const openRow = (item: CryptoMarketItem) => {
    setActive(item);
  };

  return (
    <div className="hd-widget-body invest-body-flat" ref={rootRef}>
      <div className="invest-shell">
        <div className="invest-hdr">
          <div className="invest-hdr-title">Crypto Tracker</div>
          <div className="invest-hdr-right">
            <div className="invest-interval-tabs">
              {INTERVALS.map((iv) => (
                <button
                  key={iv.label}
                  type="button"
                  className={`invest-interval-tab${interval === iv.label ? " invest-interval-tab--active" : ""}`}
                  onClick={() => setIntervalKey(iv.label)}
                >
                  {iv.label}
                </button>
              ))}
            </div>
            <span className="invest-badge invest-badge--live">
              <span className="invest-dot invest-dot--blue" />
              Live
            </span>
          </div>
        </div>

        <div className="invest-list">
          {loading && !items.length
            ? Array.from({ length: 8 }, (_, i) => (
                <div
                  className="invest-skeleton"
                  key={i}
                  style={{ marginBottom: 6, animationDelay: `${i * 80}ms` }}
                />
              ))
            : items.map((item) => {
                const pct = pctForInterval(item, interval);
                return (
                  <div
                    className="invest-row invest-row--clickable"
                    key={item.id}
                    role="button"
                    tabIndex={0}
                    onClick={() => openRow(item)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" || e.key === " ") {
                        e.preventDefault();
                        openRow(item);
                      }
                    }}
                  >
                    <div className="invest-row-left">
                      <RowIcon src={item.image} fallback={item.emoji} />
                      <div className="invest-row-names">
                        <div className="invest-row-ticker">{item.symbol}</div>
                        <div className="invest-row-name">{item.name}</div>
                      </div>
                    </div>
                    <div className="invest-row-right">
                      <div className="invest-row-price">{fmtPrice(item.current_price)}</div>
                      <div className={`invest-row-change ${changeCls(pct)}`}>
                        {pct == null || Number.isNaN(pct) ? "" : pct > 0 ? "▲ " : "▼ "}
                        {fmtPct(pct)}
                      </div>
                    </div>
                  </div>
                );
              })}
        </div>

        {error ? (
          <div className="invest-error">
            <div className="invest-error-title">Data unavailable</div>
            <div style={{ fontSize: "0.72rem", marginTop: 4 }}>{error}</div>
          </div>
        ) : null}

        <div className="invest-footer">CoinGecko · {footer}</div>
      </div>

      {mounted && active ? (
        <CryptoPopup
          item={active}
          interval={interval}
          onClose={() => setActive(null)}
        />
      ) : null}
    </div>
  );
}
