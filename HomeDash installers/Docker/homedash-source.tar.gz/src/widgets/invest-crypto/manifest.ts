import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "invest-crypto",
  name: "Crypto",
  description: "Crypto watchlist",
  version: "0.2.0",
  category: "Invest",
  defaultSize: { w: 5, h: 3, minW: 3, minH: 2 },
  hostClass: "invest-host invest-crypto-host",
  configFields: [
    {
      key: "coins",
      label: "CoinGecko IDs (comma-separated)",
      placeholder: "bitcoin,ethereum,solana,binancecoin,ripple,dogecoin,cardano,avalanche-2",
    },
    {
      key: "defaultInterval",
      label: "Default interval (1h, 24h, or 7d)",
      placeholder: "1h",
    },
  ],
};
