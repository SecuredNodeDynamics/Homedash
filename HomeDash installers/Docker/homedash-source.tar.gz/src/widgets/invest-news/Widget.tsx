"use client";
import "@/styles/widgets/invest.widget.css";

import { useCallback, useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "../_shared/instance-context";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type NewsItem = {
  title?: string;
  link?: string;
  pubDate?: string;
  thumbnail?: string;
  description?: string;
  content?: string;
  author?: string;
  categories?: string[];
  source: string;
  category: string;
};

function relativeTime(value?: string) {
  if (!value) return "Recently";
  const time = new Date(value).getTime();
  if (!Number.isFinite(time)) return "Recently";
  const minutes = Math.max(0, Math.round((Date.now() - time) / 60_000));
  if (minutes < 1) return "Just now";
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return days < 7 ? `${days}d ago` : new Date(value).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

function categoryLabel(value: string) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

const TOPIC_STOP_WORDS = new Set([
  "about", "after", "again", "against", "also", "amid", "been", "before", "being",
  "could", "from", "have", "into", "more", "over", "said", "says", "that", "their",
  "there", "these", "they", "this", "through", "under", "what", "when", "where",
  "which", "while", "with", "would", "your",
]);

function articleBrief(item: NewsItem) {
  const sourceText = item.content || item.description || "";
  const fullText = `${item.title || ""}. ${sourceText}`
    .replace(/\s+/g, " ")
    .trim();
  const sentences = (sourceText.match(/[^.!?]+[.!?]+|[^.!?]+$/g) || [])
    .map((sentence) => sentence.trim())
    .filter((sentence, index, list) => sentence.length > 35 && list.indexOf(sentence) === index);
  const synopsis =
    (sourceText.length >= 500 ? sentences.slice(0, 3).join(" ") : item.description?.trim()) ||
    sentences.slice(0, 3).join(" ") ||
    item.title ||
    "The publisher did not include a synopsis in this RSS entry.";
  const keyPoints = sentences
    .sort((a, b) => {
      const score = (value: string) =>
        (/\d|%|\$/.test(value) ? 3 : 0) +
        (/\b(said|reported|expects|plans|will|could|because|according|announced|grew|fell)\b/i.test(value) ? 2 : 0) +
        Math.min(value.length / 100, 2);
      return score(b) - score(a);
    })
    .slice(0, 8);
  if (!keyPoints.length && item.title) keyPoints.push(item.title);

  const normalized = fullText.toLowerCase();
  const lenses: Array<{ match: string[]; label: string; text: string }> = [
    {
      match: ["fed", "interest rate", "inflation", "central bank", "economy", "jobs"],
      label: "Macro",
      text: "This story is sensitive to the macro environment. Rate expectations, inflation, and economic growth can change how investors price risk across several asset classes.",
    },
    {
      match: ["regulation", "regulator", "congress", "senate", "sec ", "policy", "law"],
      label: "Policy",
      text: "The central market variable is policy execution. The practical impact depends on timing, enforcement, and whether the proposal changes operating costs or investor access.",
    },
    {
      match: ["earnings", "revenue", "profit", "sales", "quarter", "guidance"],
      label: "Fundamentals",
      text: "The article centers on company fundamentals. Compare the reported result with expectations and forward guidance; the durability of growth matters more than a single headline number.",
    },
    {
      match: ["bitcoin", "crypto", "ethereum", "token", "blockchain", "stablecoin"],
      label: "Digital assets",
      text: "The story may affect digital-asset sentiment and volatility. Adoption, liquidity, security, and regulatory follow-through are the main factors to watch beyond the immediate headline.",
    },
    {
      match: ["ai ", "artificial intelligence", "technology", "software", "chip", "quantum"],
      label: "Technology",
      text: "The investment question is whether the technology creates durable adoption and cash flow. Execution, competitive advantage, and the time required to commercialize it remain key uncertainties.",
    },
  ];
  const lens = lenses.find((candidate) => candidate.match.some((term) => normalized.includes(term))) || {
    label: categoryLabel(item.category),
    text: "This headline may influence near-term sentiment, but its investment significance depends on measurable follow-through, broader market conditions, and confirmation from additional reporting.",
  };

  const wordCounts = new Map<string, number>();
  fullText
    .toLowerCase()
    .match(/[a-z][a-z-]{3,}/g)
    ?.forEach((word) => {
      if (!TOPIC_STOP_WORDS.has(word)) wordCounts.set(word, (wordCounts.get(word) || 0) + 1);
    });
  const topics = [
    ...(item.categories || []),
    ...Array.from(wordCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .map(([word]) => word),
  ]
    .filter((topic, index, list) => topic && list.indexOf(topic) === index)
    .slice(0, 7);
  const words = Math.max(1, fullText.split(/\s+/).length);
  const executivePriorities: Record<string, string[]> = {
    Macro: [
      "Review exposure to interest-rate, inflation, currency, and demand assumptions.",
      "Stress-test near-term budgets against a slower-growth and higher-cost scenario.",
      "Watch for confirmation in official data and central-bank guidance before changing plans.",
    ],
    Policy: [
      "Identify business units, markets, or partners that could fall within the policy scope.",
      "Estimate compliance cost, implementation lead time, and potential competitive effects.",
      "Assign an owner to monitor the proposal as it moves from announcement to enforcement.",
    ],
    Fundamentals: [
      "Compare reported performance with expectations, prior periods, and management guidance.",
      "Separate durable operating trends from one-time accounting or market effects.",
      "Assess whether the result changes vendor, customer, partner, or investment assumptions.",
    ],
    "Digital assets": [
      "Review treasury, payment, custody, counterparty, and cybersecurity exposure.",
      "Separate immediate price reaction from changes in adoption, liquidity, or regulation.",
      "Require defined risk limits before expanding operational exposure to digital assets.",
    ],
    Technology: [
      "Evaluate whether the capability can improve revenue, productivity, or customer retention.",
      "Compare build, buy, and partner options alongside security and integration requirements.",
      "Set measurable adoption and return thresholds before committing material capital.",
    ],
  };
  const priorities = executivePriorities[lens.label] || [
    "Determine whether the development changes customer demand, cost, competition, or risk.",
    "Validate the headline with primary data and additional reporting before acting.",
    "Assign ownership and a measurable trigger for any follow-up decision.",
  ];
  const executiveQuestions = [
    "What changes for our customers, suppliers, competitors, or investors if this trend continues?",
    "What is our direct exposure, and which assumptions in the current plan should be retested?",
    "Which leading indicator would confirm or disprove the article’s central thesis?",
    "Is action required now, or should leadership monitor for a defined trigger?",
  ];

  return {
    synopsis,
    keyPoints,
    topics,
    lens,
    readingMinutes: Math.max(1, Math.ceil(words / 220)),
    excerptOnly: !item.content || item.content.length < 500,
    priorities,
    executiveQuestions,
  };
}

function NewsReaderModal({ item, onClose }: { item: NewsItem; onClose: () => void }) {
  const [articleContent, setArticleContent] = useState(item.content || "");
  const [reportLoading, setReportLoading] = useState(Boolean(item.link));
  const [reportError, setReportError] = useState("");
  const brief = useMemo(
    () => articleBrief({ ...item, content: articleContent }),
    [articleContent, item],
  );

  useEffect(() => {
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => event.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = overflow;
      window.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  useEffect(() => {
    if (!item.link) {
      setReportLoading(false);
      return;
    }
    let active = true;
    void (async () => {
      try {
        const response = await fetch("/api/widgets/invest-news/article", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ url: item.link }),
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Could not retrieve the full article");
        if (active && data.content) setArticleContent(String(data.content));
      } catch (reason) {
        if (active) {
          setReportError(
            `${reason instanceof Error ? reason.message : "Could not retrieve the full article"}. Using the available RSS excerpt.`,
          );
        }
      } finally {
        if (active) setReportLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, [item.link]);

  return createPortal(
    <div className="inv-reader-scrim" role="presentation" onMouseDown={onClose}>
      <section
        className="inv-reader"
        role="dialog"
        aria-modal="true"
        aria-labelledby="inv-reader-title"
        onMouseDown={(event) => event.stopPropagation()}
      >
        <header className="inv-reader__head">
          <div className="inv-reader__source">{item.source.charAt(0)}</div>
          <div>
            <span>{item.source} · {categoryLabel(item.category)}</span>
            <h2 id="inv-reader-title">{item.title || "News article"}</h2>
          </div>
          <div className="inv-reader__actions">
            {item.link ? (
              <a href={item.link} target="_blank" rel="noopener noreferrer">
                Open original ↗
              </a>
            ) : null}
            <button type="button" onClick={onClose} aria-label="Close article">×</button>
          </div>
        </header>
        <div className="inv-reader__brief">
          <div className="inv-reader__overview">
            {item.thumbnail ? (
              <div className="inv-reader__art">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={item.thumbnail} alt="" />
              </div>
            ) : null}
            <div className="inv-reader__synopsis">
              <span>Executive synopsis</span>
              <p>{brief.synopsis}</p>
              <div className="inv-reader__facts">
                <span>{relativeTime(item.pubDate)}</span>
                <span>{brief.readingMinutes} min feed read</span>
                {item.author ? <span>By {item.author}</span> : null}
                <span>{brief.excerptOnly ? "RSS excerpt" : "Extended RSS content"}</span>
              </div>
              {reportLoading ? (
                <div className="inv-reader__report-status">Building extended executive report from the publisher article…</div>
              ) : null}
              {reportError ? <div className="inv-reader__report-status is-warning">{reportError}</div> : null}
            </div>
          </div>

          <div className="inv-reader__dashboard">
            <section className="inv-reader__panel">
              <div className="inv-reader__panel-title"><span>01</span><strong>Main points</strong></div>
              <ul>
                {brief.keyPoints.map((point) => <li key={point}>{point}</li>)}
              </ul>
            </section>
            <section className="inv-reader__panel">
              <div className="inv-reader__panel-title"><span>02</span><strong>Market lens · {brief.lens.label}</strong></div>
              <p>{brief.lens.text}</p>
              <div className="inv-reader__caution">
                Dashboard analysis based on the publisher&apos;s RSS content—not investment advice.
              </div>
            </section>
            <section className="inv-reader__panel inv-reader__panel--topics">
              <div className="inv-reader__panel-title"><span>03</span><strong>Topic signals</strong></div>
              <div>
                {brief.topics.map((topic) => <span key={topic}>{categoryLabel(topic)}</span>)}
              </div>
            </section>
            <section className="inv-reader__panel inv-reader__panel--executive">
              <div className="inv-reader__panel-title"><span>04</span><strong>Executive action report</strong></div>
              <div className="inv-reader__executive-grid">
                <div>
                  <h3>Leadership priorities</h3>
                  <ul>
                    {brief.priorities.map((priority) => <li key={priority}>{priority}</li>)}
                  </ul>
                </div>
                <div>
                  <h3>Questions for the executive team</h3>
                  <ol>
                    {brief.executiveQuestions.map((question) => <li key={question}>{question}</li>)}
                  </ol>
                </div>
              </div>
            </section>
          </div>
        </div>
        <footer className="inv-reader__foot">
          <span>Summary generated locally from the available RSS entry.</span>
          {item.link ? <a href={item.link} target="_blank" rel="noopener noreferrer">Read the complete original article</a> : null}
        </footer>
      </section>
    </div>,
    document.body,
  );
}

export default function Widget() {
  const instance = useWidgetInstance();
  const [items, setItems] = useState<NewsItem[]>([]);
  const [tab, setTab] = useState("all");
  const [query, setQuery] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [selectedArticle, setSelectedArticle] = useState<NewsItem | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch(
        `/api/widgets/invest-news/status?instance=${encodeURIComponent(instance?.instanceId || "invest-news")}`,
      );
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Failed to load investment news");
      setItems(Array.isArray(data.items) ? data.items : []);
      setLastUpdated(new Date());
      setError("");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Failed to load investment news");
    } finally {
      setLoading(false);
    }
  }, [instance?.instanceId]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: 900_000 });
  const categories = useMemo(
    () => ["all", ...Array.from(new Set(items.map((item) => item.category).filter(Boolean)))],
    [items],
  );
  const visible = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return items.filter((item) => {
      if (tab !== "all" && item.category !== tab) return false;
      if (!normalized) return true;
      return [item.title, item.description, item.source, item.author]
        .some((value) => value?.toLowerCase().includes(normalized));
    });
  }, [items, query, tab]);
  const featured = visible[0];
  const remaining = visible.slice(1);
  const sources = new Set(visible.map((item) => item.source)).size;

  return (
    <div className="hd-widget-body inv-news-host" ref={rootRef}>
      <div className="inv-news-shell">
        <div className="inv-news-toolbar">
          <div className="inv-news-tabs">
            {categories.map((name) => (
              <button
                type="button"
                className={tab === name ? "is-active" : ""}
                key={name}
                onClick={() => setTab(name)}
              >
                {name === "all" ? "Top stories" : categoryLabel(name)}
                <span>{name === "all" ? items.length : items.filter((item) => item.category === name).length}</span>
              </button>
            ))}
          </div>
          <div className="inv-news-toolbar-right">
            <div className="inv-news-summary">
              <strong>{visible.length}</strong> stories · <strong>{sources}</strong> sources
            </div>
            <div className="inv-news-actions">
              <label className="inv-news-search">
                <span aria-hidden="true">⌕</span>
                <input
                  type="search"
                  value={query}
                  placeholder="Search headlines…"
                  onChange={(event) => setQuery(event.target.value)}
                />
              </label>
              <button className={`inv-news-refresh${loading ? " is-loading" : ""}`} type="button" onClick={() => void load()} disabled={loading} aria-label="Refresh news">
                ↻
              </button>
            </div>
          </div>
        </div>

        <main className="inv-news-content">
          {featured ? (
            <>
              <a
                className="inv-news-feature"
                href={featured.link}
                onClick={(event) => {
                  event.preventDefault();
                  setSelectedArticle(featured);
                }}
              >
                {featured.thumbnail ? (
                  <div className="inv-news-feature__image">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={featured.thumbnail} alt="" />
                  </div>
                ) : <div className="inv-news-feature__image is-placeholder">Market Brief</div>}
                <div className="inv-news-feature__body">
                  <div className="inv-news-story-meta">
                    <span>{featured.source}</span>
                    <b className={`is-${featured.category}`}>{categoryLabel(featured.category)}</b>
                    <time>{relativeTime(featured.pubDate)}</time>
                  </div>
                  <h2>{featured.title}</h2>
                  {featured.description ? <p>{featured.description}</p> : null}
                  <div className="inv-news-read">Read full story <span>↗</span></div>
                </div>
              </a>

              <div className="inv-news-grid">
                {remaining.map((item, index) => (
                  <a
                    className="inv-news-card"
                    href={item.link}
                    key={`${item.link}-${index}`}
                    onClick={(event) => {
                      event.preventDefault();
                      setSelectedArticle(item);
                    }}
                  >
                    {item.thumbnail ? (
                      <div className="inv-news-card__image">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img src={item.thumbnail} alt="" loading="lazy" decoding="async" />
                      </div>
                    ) : null}
                    <div className="inv-news-card__body">
                      <div className="inv-news-story-meta">
                        <span>{item.source}</span>
                        <b className={`is-${item.category}`}>{categoryLabel(item.category)}</b>
                      </div>
                      <h3>{item.title}</h3>
                      {item.description ? <p>{item.description}</p> : null}
                      <div className="inv-news-card__foot">
                        <time>{relativeTime(item.pubDate)}</time>
                        <span>Read ↗</span>
                      </div>
                    </div>
                  </a>
                ))}
              </div>
            </>
          ) : loading ? (
            <div className="inv-news-state">Refreshing financial headlines…</div>
          ) : (
            <div className="inv-news-state">No stories match this search or category.</div>
          )}
          {error ? <div className="inv-news-error">{error}</div> : null}
        </main>

        <footer className="inv-news-footer">
          <span>RSS news aggregation</span>
          <span>{lastUpdated ? `Updated ${relativeTime(lastUpdated.toISOString())}` : "Refreshes every 15 minutes"}</span>
        </footer>
      </div>
      {selectedArticle ? (
        <NewsReaderModal item={selectedArticle} onClose={() => setSelectedArticle(null)} />
      ) : null}
    </div>
  );
}
