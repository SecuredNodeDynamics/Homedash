import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "invest-news",
  name: "Invest News",
  description: "Market headlines",
  version: "0.1.0",
  category: "Invest",
  defaultSize: { w: 5, h: 5, minW: 3, minH: 3 },
  hostClass: "invest-host inv-host",
  configFields: [
    { key: "feeds", label: "Feeds JSON", placeholder: '[{"label":"Yahoo Finance","url":"https://…","category":"markets"}]' },
  ],
};
