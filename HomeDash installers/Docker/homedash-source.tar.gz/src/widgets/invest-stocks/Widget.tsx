"use client";
import "@/styles/widgets/invest.widget.css";


import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "../_shared/instance-context";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";
import type { StockQuoteItem } from "@/lib/widgets/invest-stocks";

type ChartTab = "1h" | "24h" | "7d" | "live";

const POLL_MS = 120_000;

function fmtPrice(n: number | null | undefined) {
  if (n == null || Number.isNaN(n)) return "—";
  if (n >= 1000) {
    return "$" + n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  if (n >= 1) return "$" + n.toFixed(2);
  if (n >= 0.01) return "$" + n.toFixed(4);
  return "$" + n.toFixed(6);
}

function fmtPct(n: number | null | undefined) {
  if (n == null || Number.isNaN(n)) return "—";
  return (n > 0 ? "+" : "") + n.toFixed(2) + "%";
}

function changeCls(n: number | null | undefined) {
  if (n == null || Number.isNaN(n) || n === 0) return "invest-row-change--flat";
  return n > 0 ? "invest-row-change--up" : "invest-row-change--down";
}

function fmt2(v: number | null | undefined) {
  if (v == null) return "—";
  return "$" + v.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function buildSparkline(values: number[], color: string, W = 280, H = 72) {
  if (!values || values.length < 2) {
    return (
      <svg viewBox={`0 0 ${W} ${H}`} width={W} height={H}>
        <text
          x={W / 2}
          y={H / 2}
          textAnchor="middle"
          fill="rgba(255,255,255,0.2)"
          fontSize="11"
          dominantBaseline="middle"
        >
          No data
        </text>
      </svg>
    );
  }
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;
  const pts = values.map((v, i) => {
    const x = (i / (values.length - 1)) * W;
    const y = H - ((v - min) / range) * H * 0.85 - H * 0.05;
    return { x, y };
  });
  const lineD = `M ${pts.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" L ")}`;
  const areaD = `${lineD} L ${W},${H} L 0,${H} Z`;
  const last = pts[pts.length - 1];
  const gId = `ig-${Math.random().toString(36).slice(2, 8)}`;

  return (
    <svg viewBox={`0 0 ${W} ${H}`} width={W} height={H} style={{ overflow: "visible" }}>
      <defs>
        <linearGradient id={gId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.22" />
          <stop offset="100%" stopColor={color} stopOpacity="0.01" />
        </linearGradient>
      </defs>
      <path d={areaD} fill={`url(#${gId})`} />
      <path
        d={lineD}
        fill="none"
        stroke={color}
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle
        cx={last.x}
        cy={last.y}
        r="3"
        fill={color}
        stroke="rgba(0,0,0,0.4)"
        strokeWidth="1"
      />
    </svg>
  );
}

function StockPopup({
  item,
  instanceId,
  onClose,
}: {
  item: StockQuoteItem;
  instanceId: string;
  onClose: () => void;
}) {
  const [chartTab, setChartTab] = useState<ChartTab>("live");
  const [prices, setPrices] = useState<number[] | null>(null);
  const [chartLoading, setChartLoading] = useState(true);
  const [chartError, setChartError] = useState("");
  const cacheRef = useRef<Record<string, number[]>>({});

  const pct = item.change;
  const chartColor = pct == null ? "#60a5fa" : pct >= 0 ? "#6ee7b7" : "#f87171";

  const meta = useMemo(
    () => [
      { label: "Open", value: fmt2(item.open) },
      { label: "Day High", value: fmt2(item.high) },
      { label: "Day Low", value: fmt2(item.low) },
      { label: "Prev Close", value: fmt2(item.prevClose) },
    ],
    [item],
  );

  const stats = useMemo(() => {
    if (!prices || prices.length < 2) return null;
    const min = Math.min(...prices);
    const max = Math.max(...prices);
    const open = prices[0];
    const close = prices[prices.length - 1];
    const chg = ((close - open) / open) * 100;
    const isUp = close >= open;
    return { min, max, open, close, chg, isUp };
  }, [prices]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  useEffect(() => {
    let alive = true;
    const cacheKey = `${item.symbol}:${chartTab}`;
    const cached = cacheRef.current[cacheKey];
    if (cached) {
      setPrices(cached);
      setChartLoading(false);
      setChartError("");
      return;
    }

    setChartLoading(true);
    setChartError("");
    setPrices(null);
    fetch(
      `/api/widgets/invest-stocks/chart?symbol=${encodeURIComponent(item.symbol)}` +
        `&tab=${encodeURIComponent(chartTab)}` +
        `&instance=${encodeURIComponent(instanceId)}`,
    )
      .then(async (res) => {
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.error || "Chart unavailable");
        return data as { prices?: number[] };
      })
      .then((data) => {
        if (!alive) return;
        const values = Array.isArray(data.prices) ? data.prices : [];
        if (values.length) cacheRef.current[cacheKey] = values;
        setPrices(values);
        setChartLoading(false);
      })
      .catch((err) => {
        if (!alive) return;
        setChartError(err instanceof Error ? err.message : "Chart unavailable");
        setChartLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [chartTab, item.symbol, instanceId]);

  const [imgFailed, setImgFailed] = useState(false);

  return createPortal(
    <div className="invest-popup-backdrop is-open" onClick={onClose}>
      <div
        className="invest-popup invest-popup--centered"
        role="dialog"
        aria-modal="true"
        aria-label={`${item.symbol} details`}
        onClick={(e) => e.stopPropagation()}
      >
        <button type="button" className="invest-popup__close" onClick={onClose} aria-label="Close">
          ✕
        </button>
        <div className="invest-popup__header">
          <div className="invest-popup__header-left">
            <div className="invest-row-icon" style={{ width: 36, height: 36, flexShrink: 0 }}>
              {!imgFailed ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={item.image}
                  alt={item.symbol}
                  style={{ width: 24, height: 24 }}
                  onError={() => setImgFailed(true)}
                />
              ) : (
                item.symbol[0]
              )}
            </div>
            <div>
              <div className="invest-popup__ticker">{item.symbol}</div>
              <div className="invest-popup__name">{item.name}</div>
            </div>
          </div>
          <div className="invest-popup__header-right">
            <div className="invest-popup__price">{fmtPrice(item.price)}</div>
            <div className={`invest-row-change ${changeCls(pct)}`} style={{ fontSize: "0.70rem" }}>
              {pct == null || Number.isNaN(pct) ? "" : pct > 0 ? "▲ " : "▼ "}
              {fmtPct(pct)}
            </div>
          </div>
        </div>

        <div className="invest-popup__meta">
          {meta.map((row) => (
            <div className="invest-popup__meta-row" key={row.label}>
              <span className="invest-popup__meta-label">{row.label}</span>
              <span className="invest-popup__meta-value">{row.value}</span>
            </div>
          ))}
        </div>

        <div className="invest-popup__divider" />

        <div className="invest-popup__chart-tabs">
          {(["1h", "24h", "7d", "live"] as ChartTab[]).map((tab) => (
            <button
              key={tab}
              type="button"
              className={`invest-popup__chart-tab${chartTab === tab ? " invest-popup__chart-tab--active" : ""}`}
              onClick={() => setChartTab(tab)}
            >
              {tab === "live" ? "Live" : tab}
            </button>
          ))}
        </div>

        <div className="invest-popup__chart-area">
          {chartLoading ? (
            <div className="invest-popup__chart-loading">
              <svg
                className="invest-popup__spin"
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" />
              </svg>
              Loading chart…
            </div>
          ) : chartError || !prices || prices.length < 2 ? (
            <div className="invest-popup__chart-loading" style={{ color: "rgba(255,255,255,0.3)" }}>
              {chartError || "No data available"}
            </div>
          ) : (
            buildSparkline(prices, chartColor)
          )}
        </div>

        <div className="invest-popup__chart-stats">
          {stats ? (
            <>
              <div className="invest-popup__stat">
                <span>Open</span>
                <span>{fmtPrice(stats.open)}</span>
              </div>
              <div className="invest-popup__stat">
                <span>High</span>
                <span style={{ color: "#6ee7b7" }}>{fmtPrice(stats.max)}</span>
              </div>
              <div className="invest-popup__stat">
                <span>Low</span>
                <span style={{ color: "#f87171" }}>{fmtPrice(stats.min)}</span>
              </div>
              <div className="invest-popup__stat">
                <span>Change</span>
                <span style={{ color: stats.isUp ? "#6ee7b7" : "#f87171" }}>
                  {stats.isUp ? "+" : ""}
                  {stats.chg.toFixed(2)}%
                </span>
              </div>
            </>
          ) : null}
        </div>

        <a
          className="invest-popup__link"
          href={`https://finance.yahoo.com/quote/${encodeURIComponent(item.symbol)}`}
          target="_blank"
          rel="noopener noreferrer"
        >
          View on Yahoo Finance ↗
        </a>
      </div>
    </div>,
    document.body,
  );
}

function RowIcon({ src, fallback }: { src: string; fallback: string }) {
  const [failed, setFailed] = useState(false);
  return (
    <div className="invest-row-icon">
      {!failed ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={src} alt="" loading="lazy" onError={() => setFailed(true)} />
      ) : (
        fallback
      )}
    </div>
  );
}

export default function Widget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "invest-stocks";
  const [items, setItems] = useState<StockQuoteItem[]>([]);
  const [marketOpen, setMarketOpen] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [footer, setFooter] = useState("loading…");
  const [mounted, setMounted] = useState(false);
  const [active, setActive] = useState<StockQuoteItem | null>(null);

  useEffect(() => {
    setMounted(true);
  }, []);

  const load = useCallback(async () => {
    const response = await fetch(
      `/api/widgets/invest-stocks/status?instance=${encodeURIComponent(instanceId)}`,
    );
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || "Failed to load stocks");
    const next = Array.isArray(data.items) ? (data.items as StockQuoteItem[]) : [];
    setItems(next);
    setMarketOpen(!!data.marketOpen);
    setFooter(new Date().toLocaleTimeString());
    setError("");
  }, [instanceId]);

  const poll = useCallback(async () => {
    try {
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load stocks");
    } finally {
      setLoading(false);
    }
  }, [load]);
  const { rootRef } = useWidgetPoll(poll, { intervalMs: POLL_MS });

  return (
    <div className="hd-widget-body invest-body-flat" ref={rootRef}>
      <div className="invest-shell">
        <div className="invest-hdr">
          <div className="invest-hdr-title">Stock Tracker</div>
          <div className="invest-hdr-right">
            {marketOpen ? (
              <span className="invest-badge invest-badge--open">
                <span className="invest-dot invest-dot--green" />
                Market Open
              </span>
            ) : (
              <span className="invest-badge invest-badge--closed">
                <span className="invest-dot invest-dot--grey" />
                Market Closed
              </span>
            )}
          </div>
        </div>

        <div className="invest-list">
          {loading && !items.length
            ? Array.from({ length: 10 }, (_, i) => (
                <div
                  className="invest-skeleton"
                  key={i}
                  style={{ marginBottom: 6, animationDelay: `${i * 80}ms` }}
                />
              ))
            : items.map((item) => (
                <div
                  className="invest-row invest-row--clickable"
                  key={item.symbol}
                  role="button"
                  tabIndex={0}
                  onClick={() => setActive(item)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      setActive(item);
                    }
                  }}
                >
                  <div className="invest-row-left">
                    <RowIcon src={item.image} fallback={item.symbol[0]} />
                    <div className="invest-row-names">
                      <div className="invest-row-ticker">{item.symbol}</div>
                      <div className="invest-row-name">{item.name}</div>
                    </div>
                  </div>
                  <div className="invest-row-right">
                    <div className="invest-row-price">{fmtPrice(item.price)}</div>
                    <div className={`invest-row-change ${changeCls(item.change)}`}>
                      {item.change == null || Number.isNaN(item.change)
                        ? ""
                        : item.change > 0
                          ? "▲ "
                          : "▼ "}
                      {fmtPct(item.change)}
                    </div>
                  </div>
                </div>
              ))}
        </div>

        {error ? (
          <div className="invest-error">
            <div className="invest-error-title">Data unavailable</div>
            <div style={{ fontSize: "0.72rem", marginTop: 4 }}>{error}</div>
          </div>
        ) : null}

        <div className="invest-footer">Finnhub · {footer}</div>
      </div>

      {mounted && active ? (
        <StockPopup
          item={active}
          instanceId={instanceId}
          onClose={() => setActive(null)}
        />
      ) : null}
    </div>
  );
}
