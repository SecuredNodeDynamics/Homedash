import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "invest-stocks",
  name: "Stocks",
  description: "Stock watchlist",
  version: "0.2.0",
  category: "Invest",
  defaultSize: { w: 5, h: 3, minW: 3, minH: 2 },
  hostClass: "invest-host invest-stocks-host inv-host",
  configFields: [
    { key: "apiKey", label: "Finnhub API Key", type: "password", required: true },
    {
      key: "symbols",
      label: "Symbols (comma-separated)",
      placeholder: "AMZN,AMD,NVDA,MSFT,AAPL,GOOG,META,TSLA,SPY,QQQ",
    },
    {
      key: "stockProxyUrl",
      label: "Chart proxy URL (optional)",
      placeholder: "https://stock-proxy.janzenmediagroup.com",
    },
  ],
};
