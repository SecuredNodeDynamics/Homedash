"use client";
import "@/styles/widgets/jellyfin-collections-mgr.widget.css";

import { useCallback, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";
import type { JcmStatus } from "@/lib/widgets/jellyfin-collections-mgr";

type ConnectionSource = "private" | "public" | "unknown";

const CONNECTION_SOURCE_LABEL: Record<ConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

function timeAgo(value: string) {
  const ms = Date.parse(value);
  if (!Number.isFinite(ms)) return value;
  const sec = Math.max(0, Math.floor((Date.now() - ms) / 1000));
  if (sec < 60) return "just now";
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m ago`;
  const hr = Math.floor(min / 60);
  if (hr < 48) return `${hr}h ago`;
  return `${Math.floor(hr / 24)}d ago`;
}

function Overview({ c }: { c: NonNullable<JcmStatus["collections"]> }) {
  const titles = Math.max(1, c.movies + c.series);
  const moviePct = Math.round((c.movies / titles) * 100);
  const withPoster = Math.max(0, c.total - c.noPoster);
  const posterPct = Math.round((withPoster / Math.max(1, c.total)) * 100);
  const radius = 26;
  const circ = 2 * Math.PI * radius;
  const maxTop = Math.max(1, ...c.top.map((t) => t.count));
  return (
    <div className="jc-overview">
      <div className="jc-ring" title={`${withPoster} of ${c.total} collections have a poster`}>
        <svg viewBox="0 0 64 64" width="64" height="64" aria-hidden>
          <circle cx="32" cy="32" r={radius} className="jc-ring__track" />
          <circle
            cx="32"
            cy="32"
            r={radius}
            className="jc-ring__fill"
            strokeDasharray={`${(posterPct / 100) * circ} ${circ}`}
            transform="rotate(-90 32 32)"
          />
        </svg>
        <div className="jc-ring__text">
          <strong>{posterPct}%</strong>
          <span>posters</span>
        </div>
      </div>
      <div className="jc-overview__main">
        <div className="jc-split" title={`${c.movies} movies · ${c.series} series`}>
          <div className="jc-split__bar">
            <span className="jc-split__movies" style={{ width: `${moviePct}%` }} />
            <span className="jc-split__series" style={{ width: `${100 - moviePct}%` }} />
          </div>
          <div className="jc-split__legend">
            <span><i className="jc-swatch jc-swatch--movies" />{c.movies} movies</span>
            <span><i className="jc-swatch jc-swatch--series" />{c.series} series</span>
          </div>
        </div>
        {c.top.length ? (
          <div className="jc-top">
            {c.top.slice(0, 4).map((t) => (
              <div key={t.name} className="jc-top__row" title={`${t.name} · ${t.count}`}>
                <span className="jc-top__name">{t.name}</span>
                <span className="jc-top__bar"><span style={{ width: `${(t.count / maxTop) * 100}%` }} /></span>
                <span className="jc-top__count">{t.count}</span>
              </div>
            ))}
          </div>
        ) : null}
      </div>
    </div>
  );
}

const TILE_VIEW: Record<string, View> = {
  Collections: { kind: "collections" },
  Titles: { kind: "titles" },
  Suggestions: { kind: "suggestions" },
  "Needs attention": { kind: "attention" },
  "No poster": { kind: "collections", filter: "noPoster" },
  Missing: { kind: "missing" },
  Empty: { kind: "collections", filter: "empty" },
};

export default function JellyfinCollectionsMgrWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "jellyfin-collections-mgr";
  const [data, setData] = useState<JcmStatus | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const openHref = useOpenHref(data?.publicUrl || "", data?.openFallbackUrl || "");

  const [view, setView] = useState<View | null>(null);
  const [busy, setBusy] = useState("");
  const [confirm, setConfirm] = useState("");
  const [notice, setNotice] = useState<{ ok: boolean; text: string; drift?: boolean } | null>(null);

  const load = useCallback(async (fresh = false) => {
    try {
      const response = await fetch(
        `/api/widgets/jellyfin-collections-mgr/status?instance=${encodeURIComponent(instanceId)}${fresh ? "&fresh=1" : ""}`,
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load Collection Manager");
      setData(json as JcmStatus);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Collection Manager unavailable");
    } finally {
      setLoading(false);
    }
  }, [instanceId]);

  const { rootRef } = useWidgetPoll(() => load(false), { intervalMs: 60_000 });

  const scanning = Boolean(data?.scan?.running);
  useEffect(() => {
    if (!scanning) return;
    const timer = setInterval(() => void load(true), 5000);
    return () => clearInterval(timer);
  }, [scanning, load]);

  async function run(action: string, force = false) {
    setBusy(action);
    setConfirm("");
    setNotice(null);
    try {
      const response = await fetch("/api/widgets/jellyfin-collections-mgr/status", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, action, force }),
      });
      const json = await response.json();
      if (json.status) setData(json.status as JcmStatus);
      setNotice({ ok: Boolean(json.ok), text: json.message || (json.ok ? "Done" : "Failed"), drift: json.drift });
    } catch (err) {
      setNotice({ ok: false, text: err instanceof Error ? err.message : "Action failed" });
    } finally {
      setBusy("");
    }
  }

  if (loading && !data) {
    return (
      <div className="hd-widget-body jc-body" ref={rootRef}>
        <div className="jc-toolbar">
          <span className="jc-pill jc-pill--loading">
            <span className="jc-dot" />
            Loading
          </span>
        </div>
        <div className="jc-skeleton" />
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="hd-widget-body jc-body" ref={rootRef}>
        <div className="jc-toolbar">
          <span className="jc-pill jc-pill--offline">
            <span className="jc-dot" />
            Offline
          </span>
        </div>
        <div className="jc-error">⚠ {error}</div>
        <button className="jc-btn" type="button" onClick={() => load(true)}>
          Retry
        </button>
      </div>
    );
  }

  if (!data) return null;

  const source = (data.connectionSource || "unknown") as ConnectionSource;
  const c = data.collections;
  const tiles: Array<{ label: string; value: number | null; tone?: string }> = [
    { label: "Collections", value: c ? c.total : null },
    { label: "Titles", value: c ? c.movies + c.series : null },
    { label: "Suggestions", value: data.suggestions, tone: "active" },
    { label: "Needs attention", value: data.attention, tone: data.attention ? "warn" : undefined },
    { label: "No poster", value: c ? c.noPoster : null, tone: c && c.noPoster ? "warn" : undefined },
    { label: "Missing", value: data.missing ?? null, tone: data.missing ? "warn" : undefined },
    { label: "Empty", value: c ? c.empty : null, tone: c && c.empty ? "warn" : undefined },
  ].filter((tile) => tile.value !== null);

  return (
    <div className="hd-widget-body jc-body" ref={rootRef}>
      {view ? (
        <ManagerModal
          instance={instanceId}
          view={view}
          setView={setView}
          onClose={() => setView(null)}
          onChanged={() => void load(true)}
        />
      ) : null}
      {source !== "unknown" ? (
        <div
          className={`jc-corner jc-corner--${source}`}
          title={CONNECTION_SOURCE_LABEL[source]}
          aria-label={CONNECTION_SOURCE_LABEL[source]}
        />
      ) : null}
      <div className="jc-toolbar">
        <div className="jc-toolbar-left">
          <span className="jc-pill jc-pill--online">
            <span className="jc-dot" />
            Online
          </span>
          {data.scan?.running ? <span className="jc-pill jc-pill--scan">Scanning…</span> : null}
        </div>
        <div className="jc-toolbar-right">
          <button className="jc-link" type="button" onClick={() => load(true)} title="Refresh">
            <span aria-hidden>⟳</span> Refresh
          </button>
          {openHref ? (
            <a className="jc-open" href={openHref} target="_blank" rel="noopener noreferrer">
              Open
            </a>
          ) : null}
        </div>
      </div>

      {c && c.total > 0 ? <Overview c={c} /> : null}

      {tiles.length ? (
        <div className="jc-stats">
          {tiles.map((tile) => (
            <div
              key={tile.label}
              role="button"
              tabIndex={0}
              title={`Open ${tile.label}`}
              className={`jc-stat jc-stat--click${tile.tone ? ` jc-stat--${tile.tone}` : ""}`}
              onClick={() => setView(TILE_VIEW[tile.label])}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") setView(TILE_VIEW[tile.label]);
              }}
            >
              <div className="jc-stat__value">{tile.value}</div>
              <div className="jc-stat__label">{tile.label}</div>
            </div>
          ))}
        </div>
      ) : null}

      <div className="jc-actions">
        {confirm ? (
          <div className="jc-confirm">
            <span>
              {confirm === "scan" && "Start a scan now? In Auto mode this may apply changes to Jellyfin."}
              {confirm === "undo" && `Undo "${data.undoAvailable?.label || "last change"}"?`}
              {confirm === "undo-force" && "Collections were edited in Jellyfin since. Force the undo anyway?"}
            </span>
            <button
              className="jc-btn jc-btn--go"
              type="button"
              onClick={() => run(confirm === "undo-force" ? "undo" : confirm, confirm === "undo-force")}
            >
              Yes
            </button>
            <button className="jc-btn" type="button" onClick={() => setConfirm("")}>
              Cancel
            </button>
          </div>
        ) : (
          <>
            <button className="jc-btn" type="button" disabled={!!busy || scanning} onClick={() => setConfirm("scan")}>
              {busy === "scan" || scanning ? "Scanning…" : "Scan now"}
            </button>
            <button className="jc-btn" type="button" disabled={!!busy} onClick={() => run("refresh")}>
              {busy === "refresh" ? "Refreshing…" : "Refresh library"}
            </button>
            {data.undoAvailable ? (
              <button className="jc-btn" type="button" disabled={!!busy} onClick={() => setConfirm("undo")}>
                {busy === "undo" ? "Undoing…" : "Undo last change"}
              </button>
            ) : null}
          </>
        )}
      </div>
      {notice ? (
        <div className={`jc-notice jc-notice--${notice.ok ? "ok" : "bad"}`}>
          {notice.text}
          {notice.drift ? (
            <button className="jc-btn" type="button" onClick={() => setConfirm("undo-force")}>
              Force undo…
            </button>
          ) : null}
        </div>
      ) : null}

      {data.recent && data.recent.length ? (
        <div className="jc-activity">
          <div className="jc-section-title">Recent activity</div>
          {data.recent.map((r, i) => (
            <div key={`${r.created}-${i}`} className={`jc-act${r.undone ? " jc-act--undone" : ""}`}>
              <span className={`jc-act__dot jc-act__dot--${r.status === "done" ? "ok" : r.status ? "warn" : "ok"}`} />
              <span className="jc-act__label" title={r.label}>
                {r.label}
              </span>
              <span className="jc-act__time">
                {r.undone ? "undone · " : ""}
                {r.created ? timeAgo(r.created) : ""}
              </span>
            </div>
          ))}
        </div>
      ) : null}

      <div className="jc-rows">
        <div className="jc-row">
          <span className="jc-row__label">Jellyfin</span>
          {data.jellyfin.ok ? (
            <span className="jc-row__value jc-row__value--ok">
              {data.jellyfin.name || "Connected"}
              {data.jellyfin.version ? ` · ${data.jellyfin.version}` : ""}
            </span>
          ) : (
            <span className="jc-row__value jc-row__value--bad">
              {data.jellyfin.configured ? data.jellyfin.error || "Not reachable" : "Not connected"}
            </span>
          )}
        </div>
        {data.lastChange ? (
          <div className="jc-row">
            <span className="jc-row__label">Last change</span>
            <span className="jc-row__value" title={data.lastChange.label}>
              {data.lastChange.label || "Change"}
              {data.lastChange.created ? ` · ${timeAgo(data.lastChange.created)}` : ""}
            </span>
          </div>
        ) : null}
        {data.lastRestorePoint ? (
          <div className="jc-row">
            <span className="jc-row__label">Restore point</span>
            <span className="jc-row__value" title={data.lastRestorePoint.name}>
              {data.lastRestorePoint.created ? timeAgo(data.lastRestorePoint.created) : data.lastRestorePoint.name}
            </span>
          </div>
        ) : null}
        {data.scan?.last ? (
          <div className="jc-row">
            <span className="jc-row__label">Last scan</span>
            <span className="jc-row__value">{timeAgo(data.scan.last)}</span>
          </div>
        ) : null}
      </div>
    </div>
  );
}

/* ===================== Manager screens (opened from the tiles) ===================== */

const BASE = "/api/widgets/jellyfin-collections-mgr/status";

type View =
  | { kind: "collections"; filter?: "all" | "noPoster" | "empty" }
  | { kind: "collection"; id: string; name: string; back: View }
  | { kind: "titles" }
  | { kind: "suggestions" }
  | { kind: "attention" }
  | { kind: "missing" };

type Col = { id: string; name: string; count: number; movies: number; series: number; thumbs: string[]; has_poster: boolean };
type TitleRow = {
  id: string;
  name: string;
  type: string;
  year?: number | null;
  has_poster?: boolean;
  collections?: Array<{ id: string; name: string }>;
};
type Msg = { ok: boolean; text: string };

async function jget<T>(instance: string, path: string): Promise<T> {
  const res = await fetch(`${BASE}?instance=${encodeURIComponent(instance)}&proxy=${encodeURIComponent(path)}`);
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((json as { error?: string }).error || `Request failed (${res.status})`);
  return json as T;
}

async function jpost<T>(instance: string, path: string, body: Record<string, unknown>): Promise<T> {
  const res = await fetch(BASE, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ instance, action: "proxy", path, body }),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((json as { error?: string }).error || `Request failed (${res.status})`);
  return json as T;
}

const errText = (e: unknown) => (e instanceof Error ? e.message : "Something went wrong");
const toggleIn = (list: string[], id: string) => (list.includes(id) ? list.filter((x) => x !== id) : [...list, id]);

function Poster({ instance, id, name }: { instance: string; id?: string; name: string }) {
  const [bad, setBad] = useState(false);
  if (!id || bad) {
    return (
      <div className="jcm-poster jcm-poster--none">
        <span>{(name || "?").slice(0, 2).toUpperCase()}</span>
      </div>
    );
  }
  return (
    <div className="jcm-poster">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        loading="lazy"
        alt=""
        src={`${BASE}?instance=${encodeURIComponent(instance)}&img=${encodeURIComponent(id)}`}
        onError={() => setBad(true)}
      />
    </div>
  );
}

function Flash({ msg }: { msg: Msg | null }) {
  if (!msg) return null;
  return <div className={`jcm-flash jcm-flash--${msg.ok ? "ok" : "bad"}`}>{msg.text}</div>;
}

function Modal({
  title,
  onClose,
  onBack,
  children,
}: {
  title: string;
  onClose: () => void;
  onBack?: () => void;
  children: ReactNode;
}) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [onClose]);
  return createPortal(
    <div
      className="jcm-overlay"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="jcm-modal" role="dialog" aria-label={title}>
        <div className="jcm-modal__head">
          {onBack ? (
            <button type="button" className="jcm-btn" onClick={onBack}>
              ← Back
            </button>
          ) : null}
          <h2>{title}</h2>
          <button type="button" className="jcm-btn jcm-close" onClick={onClose} aria-label="Close">
            ✕
          </button>
        </div>
        <div className="jcm-modal__body">{children}</div>
      </div>
    </div>,
    document.body,
  );
}

function AddToBar({
  instance,
  ids,
  cols,
  onDone,
}: {
  instance: string;
  ids: string[];
  cols: Array<{ id: string; name: string }>;
  onDone: (msg: Msg) => void;
}) {
  const [target, setTarget] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const isNew = target === "__new";
  async function go() {
    setBusy(true);
    try {
      await jpost(instance, "/api/titles/add", {
        ids,
        target: isNew ? "" : target,
        name: isNew ? name.trim() : undefined,
      });
      onDone({ ok: true, text: isNew ? `Created "${name.trim()}"` : "Added to collection" });
      setTarget("");
      setName("");
    } catch (e) {
      onDone({ ok: false, text: errText(e) });
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="jcm-addbar">
      <select value={target} onChange={(e) => setTarget(e.target.value)}>
        <option value="">Add {ids.length} to collection…</option>
        <option value="__new">＋ New collection…</option>
        {cols.map((c) => (
          <option key={c.id} value={c.id}>
            {c.name}
          </option>
        ))}
      </select>
      {isNew ? <input placeholder="New collection name" value={name} onChange={(e) => setName(e.target.value)} /> : null}
      <button
        type="button"
        className="jcm-btn jcm-btn--go"
        disabled={busy || !target || !ids.length || (isNew && !name.trim())}
        onClick={go}
      >
        {busy ? "Working…" : "Add"}
      </button>
    </div>
  );
}

function CollectionsView({
  instance,
  filter0,
  onOpen,
  onChanged,
}: {
  instance: string;
  filter0: "all" | "noPoster" | "empty";
  onOpen: (c: Col) => void;
  onChanged: () => void;
}) {
  const [cols, setCols] = useState<Col[] | null>(null);
  const [err, setErr] = useState("");
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState(filter0);
  const [pick, setPick] = useState(false);
  const [sel, setSel] = useState<string[]>([]);
  const [mode, setMode] = useState<"" | "merge" | "combine" | "delete">("");
  const [keep, setKeep] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<Msg | null>(null);

  const load = useCallback(async () => {
    try {
      const r = await jget<{ collections: Col[] }>(instance, "/api/collections?refresh=1");
      setCols(r.collections || []);
      setErr("");
    } catch (e) {
      setErr(errText(e));
    }
  }, [instance]);
  useEffect(() => {
    void load();
  }, [load]);

  const shown = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return (cols || [])
      .filter((c) => (filter === "noPoster" ? !c.has_poster : filter === "empty" ? c.count === 0 : true))
      .filter((c) => !needle || c.name.toLowerCase().includes(needle))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [cols, q, filter]);

  async function run(fn: () => Promise<unknown>, done: string) {
    setBusy(true);
    try {
      await fn();
      setMsg({ ok: true, text: done });
      setMode("");
      setSel([]);
      setName("");
      setKeep("");
      await load();
      onChanged();
    } catch (e) {
      setMsg({ ok: false, text: errText(e) });
    } finally {
      setBusy(false);
    }
  }

  const selCols = (cols || []).filter((c) => sel.includes(c.id));
  const allSelEmpty = selCols.length > 0 && selCols.every((c) => c.count === 0);

  async function deleteSel() {
    setBusy(true);
    try {
      const r = await jpost<{ message?: string }>(instance, "/api/collections/delete_empty", { ids: sel });
      setMsg({ ok: true, text: r.message || "Empty collections deleted" });
      setMode("");
      setSel([]);
      await load();
      onChanged();
    } catch (e) {
      const text = errText(e);
      setMsg({
        ok: false,
        text: /not found/i.test(text)
          ? "Your Collection Manager needs the small update that adds “delete empty collections” (core.py + server.py)."
          : text,
      });
      setMode("");
    } finally {
      setBusy(false);
    }
  }

  if (err && !cols) return <div className="jcm-empty">⚠ {err}</div>;
  if (!cols) return <div className="jcm-empty">Loading collections…</div>;

  return (
    <>
      <div className="jcm-toolbar">
        <input className="jcm-search" placeholder="Search collections…" value={q} onChange={(e) => setQ(e.target.value)} />
        <div className="jcm-chips">
          {(
            [
              ["all", `All (${cols.length})`],
              ["noPoster", `No poster (${cols.filter((c) => !c.has_poster).length})`],
              ["empty", `Empty (${cols.filter((c) => c.count === 0).length})`],
            ] as const
          ).map(([key, label]) => (
            <button
              key={key}
              type="button"
              className={`jcm-chip${filter === key ? " is-on" : ""}`}
              onClick={() => setFilter(key)}
            >
              {label}
            </button>
          ))}
        </div>
        <button
          type="button"
          className={`jcm-btn${pick ? " jcm-btn--go" : ""}`}
          onClick={() => {
            setPick(!pick);
            setSel([]);
            setMode("");
          }}
        >
          {pick ? "Done selecting" : "Select"}
        </button>
      </div>

      {pick ? (
        <div className="jcm-bar">
          <span>{sel.length} selected</span>
          {mode === "" ? (
            <>
              <button
                type="button"
                className="jcm-btn"
                disabled={sel.length < 2}
                onClick={() => {
                  setMode("merge");
                  setKeep(sel[0] || "");
                }}
              >
                Merge…
              </button>
              <button type="button" className="jcm-btn" disabled={sel.length < 2} onClick={() => setMode("combine")}>
                Combine…
              </button>
              <button
                type="button"
                className="jcm-btn jcm-btn--bad"
                disabled={!allSelEmpty}
                title={allSelEmpty ? "Delete the selected empty collections" : "Only empty collections can be deleted"}
                onClick={() => setMode("delete")}
              >
                Delete…
              </button>
              {filter === "empty" && shown.length ? (
                <button
                  type="button"
                  className="jcm-btn"
                  onClick={() => setSel(sel.length === shown.length ? [] : shown.map((c) => c.id))}
                >
                  {sel.length === shown.length ? "Unselect all" : "Select all"}
                </button>
              ) : null}
              <span className="jcm-hint">Merge moves everything into one collection and deletes the others. Combine makes a new one and leaves yours alone. Delete only works on empty collections.</span>
            </>
          ) : null}
          {mode === "delete" ? (
            <>
              <span className="jcm-hint">
                Delete {sel.length} empty collection{sel.length === 1 ? "" : "s"} from Jellyfin? A restore point is saved first.
              </span>
              <button type="button" className="jcm-btn jcm-btn--bad" disabled={busy} onClick={deleteSel}>
                {busy ? "Deleting…" : "Yes, delete"}
              </button>
              <button type="button" className="jcm-btn" onClick={() => setMode("")}>
                Cancel
              </button>
            </>
          ) : null}
          {mode === "merge" ? (
            <>
              <select value={keep} onChange={(e) => setKeep(e.target.value)}>
                {selCols.map((c) => (
                  <option key={c.id} value={c.id}>
                    Keep: {c.name}
                  </option>
                ))}
              </select>
              <button
                type="button"
                className="jcm-btn jcm-btn--go"
                disabled={busy || !keep}
                onClick={() =>
                  run(
                    () => jpost(instance, "/api/collections/merge", { keep, others: sel.filter((x) => x !== keep) }),
                    "Collections merged",
                  )
                }
              >
                {busy ? "Merging…" : `Merge ${sel.length - 1} into it`}
              </button>
              <button type="button" className="jcm-btn" onClick={() => setMode("")}>
                Cancel
              </button>
            </>
          ) : null}
          {mode === "combine" ? (
            <>
              <input placeholder="New collection name" value={name} onChange={(e) => setName(e.target.value)} />
              <button
                type="button"
                className="jcm-btn jcm-btn--go"
                disabled={busy || !name.trim()}
                onClick={() =>
                  run(() => jpost(instance, "/api/collections/combine", { ids: sel, name: name.trim() }), "Combined")
                }
              >
                {busy ? "Combining…" : "Combine"}
              </button>
              <button type="button" className="jcm-btn" onClick={() => setMode("")}>
                Cancel
              </button>
            </>
          ) : null}
        </div>
      ) : null}
      <Flash msg={msg} />

      {shown.length === 0 ? (
        <div className="jcm-empty">No collections match.</div>
      ) : (
        <div className="jcm-grid">
          {shown.map((c) => {
            const on = sel.includes(c.id);
            return (
              <div
                key={c.id}
                className={`jcm-card${on ? " is-sel" : ""}`}
                onClick={() => (pick ? setSel(toggleIn(sel, c.id)) : onOpen(c))}
                title={c.name}
              >
                <Poster instance={instance} id={c.has_poster ? c.id : c.thumbs[0]} name={c.name} />
                <span className="jcm-badge">{c.count}</span>
                {!c.has_poster ? <span className="jcm-flag">no poster</span> : null}
                {pick ? <span className={`jcm-check${on ? " is-on" : ""}`}>{on ? "✓" : ""}</span> : null}
                <div className="jcm-card__name">{c.name}</div>
                <div className="jcm-card__sub">
                  {c.movies ? `${c.movies} movie${c.movies === 1 ? "" : "s"}` : ""}
                  {c.movies && c.series ? " · " : ""}
                  {c.series ? `${c.series} series` : ""}
                  {!c.movies && !c.series ? "Empty" : ""}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </>
  );
}

function CollectionDetail({
  instance,
  id,
  allCols,
  onChanged,
}: {
  instance: string;
  id: string;
  allCols: Array<{ id: string; name: string }>;
  onChanged: () => void;
}) {
  const [items, setItems] = useState<TitleRow[] | null>(null);
  const [err, setErr] = useState("");
  const [sel, setSel] = useState<string[]>([]);
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<Msg | null>(null);
  const [adding, setAdding] = useState(false);
  const [sq, setSq] = useState("");
  const [results, setResults] = useState<TitleRow[]>([]);
  const [rsel, setRsel] = useState<string[]>([]);
  const [searching, setSearching] = useState(false);

  const load = useCallback(async () => {
    try {
      const r = await jget<{ items: TitleRow[] }>(instance, `/api/collections/${id}`);
      setItems(r.items || []);
      setErr("");
    } catch (e) {
      setErr(errText(e));
    }
  }, [instance, id]);
  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    if (!adding || sq.trim().length < 2) {
      setResults([]);
      return;
    }
    const t = setTimeout(async () => {
      setSearching(true);
      try {
        const r = await jget<{ results: TitleRow[] }>(instance, `/api/library/search?q=${encodeURIComponent(sq.trim())}`);
        setResults(r.results || []);
      } catch (e) {
        setMsg({ ok: false, text: errText(e) });
      } finally {
        setSearching(false);
      }
    }, 350);
    return () => clearTimeout(t);
  }, [sq, adding, instance]);

  async function removeSel() {
    setBusy(true);
    try {
      await jpost(instance, "/api/titles/remove", { ids: sel, collections: [id], allow_orphan: true });
      setMsg({ ok: true, text: `Removed ${sel.length} title${sel.length === 1 ? "" : "s"}` });
      setSel([]);
      setConfirm(false);
      await load();
      onChanged();
    } catch (e) {
      setMsg({ ok: false, text: errText(e) });
    } finally {
      setBusy(false);
    }
  }

  async function addSel() {
    setBusy(true);
    try {
      await jpost(instance, "/api/titles/add", { ids: rsel, target: id });
      setMsg({ ok: true, text: `Added ${rsel.length} title${rsel.length === 1 ? "" : "s"}` });
      setRsel([]);
      setSq("");
      setResults([]);
      setAdding(false);
      await load();
      onChanged();
    } catch (e) {
      setMsg({ ok: false, text: errText(e) });
    } finally {
      setBusy(false);
    }
  }

  if (err && !items) return <div className="jcm-empty">⚠ {err}</div>;
  if (!items) return <div className="jcm-empty">Loading…</div>;
  const have = new Set(items.map((i) => i.id));
  void allCols;

  return (
    <>
      <div className="jcm-toolbar">
        <span className="jcm-count">{items.length} titles</span>
        <button type="button" className="jcm-btn" onClick={() => setSel(sel.length === items.length ? [] : items.map((i) => i.id))}>
          {sel.length === items.length && items.length ? "Clear selection" : "Select all"}
        </button>
        {sel.length && !confirm ? (
          <button type="button" className="jcm-btn jcm-btn--bad" onClick={() => setConfirm(true)}>
            Remove {sel.length} from collection
          </button>
        ) : null}
        {confirm ? (
          <>
            <span className="jcm-hint">Remove {sel.length} title(s) from this collection? (Undo is available in the widget.)</span>
            <button type="button" className="jcm-btn jcm-btn--bad" disabled={busy} onClick={removeSel}>
              {busy ? "Removing…" : "Yes, remove"}
            </button>
            <button type="button" className="jcm-btn" onClick={() => setConfirm(false)}>
              Cancel
            </button>
          </>
        ) : null}
        <button type="button" className={`jcm-btn${adding ? " jcm-btn--go" : ""}`} onClick={() => setAdding(!adding)}>
          {adding ? "Close add" : "＋ Add titles"}
        </button>
      </div>
      <Flash msg={msg} />

      {adding ? (
        <div className="jcm-addpanel">
          <input
            className="jcm-search"
            autoFocus
            placeholder="Search your library to add (2+ letters)…"
            value={sq}
            onChange={(e) => setSq(e.target.value)}
          />
          {searching ? <span className="jcm-hint">Searching…</span> : null}
          {rsel.length ? (
            <button type="button" className="jcm-btn jcm-btn--go" disabled={busy} onClick={addSel}>
              {busy ? "Adding…" : `Add ${rsel.length} to this collection`}
            </button>
          ) : null}
          {results.length ? (
            <div className="jcm-grid jcm-grid--small">
              {results.map((t) => {
                const already = have.has(t.id);
                const on = rsel.includes(t.id);
                return (
                  <div
                    key={t.id}
                    className={`jcm-card${on ? " is-sel" : ""}${already ? " is-dim" : ""}`}
                    onClick={() => !already && setRsel(toggleIn(rsel, t.id))}
                    title={t.name}
                  >
                    <Poster instance={instance} id={t.id} name={t.name} />
                    {already ? <span className="jcm-flag">in collection</span> : null}
                    <span className={`jcm-check${on ? " is-on" : ""}`}>{on ? "✓" : ""}</span>
                    <div className="jcm-card__name">{t.name}</div>
                    <div className="jcm-card__sub">
                      {t.year || ""} {t.type === "Series" ? "· Series" : ""}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : null}
        </div>
      ) : null}

      {items.length === 0 ? (
        <div className="jcm-empty">This collection is empty.</div>
      ) : (
        <div className="jcm-grid">
          {items.map((t) => {
            const on = sel.includes(t.id);
            return (
              <div
                key={t.id}
                className={`jcm-card${on ? " is-sel" : ""}`}
                onClick={() => setSel(toggleIn(sel, t.id))}
                title={t.name}
              >
                <Poster instance={instance} id={t.id} name={t.name} />
                {t.type === "Series" ? <span className="jcm-badge jcm-badge--series">Series</span> : null}
                <span className={`jcm-check${on ? " is-on" : ""}`}>{on ? "✓" : ""}</span>
                <div className="jcm-card__name">{t.name}</div>
                <div className="jcm-card__sub">{t.year || ""}</div>
              </div>
            );
          })}
        </div>
      )}
    </>
  );
}

function TitlesView({ instance, onChanged }: { instance: string; onChanged: () => void }) {
  const [titles, setTitles] = useState<TitleRow[] | null>(null);
  const [cols, setCols] = useState<Array<{ id: string; name: string }>>([]);
  const [err, setErr] = useState("");
  const [q, setQ] = useState("");
  const [type, setType] = useState<"all" | "Movie" | "Series">("all");
  const [chip, setChip] = useState<"" | "none" | "noPoster" | "several">("");
  const [limit, setLimit] = useState(120);
  const [sel, setSel] = useState<string[]>([]);
  const [open, setOpen] = useState<string>("");
  const [msg, setMsg] = useState<Msg | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const r = await jget<{ titles: TitleRow[]; collections: Array<{ id: string; name: string }> }>(
        instance,
        "/api/organize-data?refresh=1",
      );
      setTitles(r.titles || []);
      setCols((r.collections || []).map((c) => ({ id: c.id, name: c.name })));
      setErr("");
    } catch (e) {
      setErr(errText(e));
    }
  }, [instance]);
  useEffect(() => {
    void load();
  }, [load]);
  useEffect(() => setLimit(120), [q, type, chip]);

  const shown = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return (titles || []).filter((t) => {
      if (type !== "all" && t.type !== type) return false;
      if (chip === "none" && (t.collections || []).length) return false;
      if (chip === "noPoster" && t.has_poster) return false;
      if (chip === "several" && (t.collections || []).length < 2) return false;
      return !needle || t.name.toLowerCase().includes(needle);
    });
  }, [titles, q, type, chip]);

  const current = (titles || []).find((t) => t.id === open) || null;

  async function removeFrom(t: TitleRow, cid: string) {
    setBusy(true);
    try {
      await jpost(instance, "/api/titles/remove", { ids: [t.id], collections: [cid] });
      setMsg({ ok: true, text: "Removed from collection" });
      await load();
      onChanged();
    } catch (e) {
      setMsg({ ok: false, text: errText(e) });
    } finally {
      setBusy(false);
    }
  }

  if (err && !titles) return <div className="jcm-empty">⚠ {err}</div>;
  if (!titles) return <div className="jcm-empty">Loading titles…</div>;

  return (
    <div className="jcm-split-view">
      <div className="jcm-split-main">
        <div className="jcm-toolbar">
          <input className="jcm-search" placeholder="Search titles…" value={q} onChange={(e) => setQ(e.target.value)} />
          <select value={type} onChange={(e) => setType(e.target.value as typeof type)}>
            <option value="all">Movies &amp; Series</option>
            <option value="Movie">Movies</option>
            <option value="Series">Series</option>
          </select>
          <div className="jcm-chips">
            {(
              [
                ["none", "In no collection"],
                ["several", "In several"],
                ["noPoster", "No poster"],
              ] as const
            ).map(([k, label]) => (
              <button key={k} type="button" className={`jcm-chip${chip === k ? " is-on" : ""}`} onClick={() => setChip(chip === k ? "" : k)}>
                {label}
              </button>
            ))}
          </div>
          <span className="jcm-count">{shown.length} titles</span>
        </div>
        {sel.length ? (
          <div className="jcm-bar">
            <span>{sel.length} selected</span>
            <AddToBar
              instance={instance}
              ids={sel}
              cols={cols}
              onDone={async (m) => {
                setMsg(m);
                if (m.ok) {
                  setSel([]);
                  await load();
                  onChanged();
                }
              }}
            />
            <button type="button" className="jcm-btn" onClick={() => setSel([])}>
              Clear
            </button>
          </div>
        ) : null}
        <Flash msg={msg} />
        <div
          className="jcm-scroll"
          onScroll={(e) => {
            const el = e.currentTarget;
            if (el.scrollTop + el.clientHeight > el.scrollHeight - 500) setLimit((l) => l + 120);
          }}
        >
          <div className="jcm-grid">
            {shown.slice(0, limit).map((t) => {
              const on = sel.includes(t.id);
              const n = (t.collections || []).length;
              return (
                <div key={t.id} className={`jcm-card${on ? " is-sel" : ""}${open === t.id ? " is-open" : ""}`} onClick={() => setOpen(t.id)} title={t.name}>
                  <Poster instance={instance} id={t.has_poster === false ? undefined : t.id} name={t.name} />
                  <span className={`jcm-badge${n === 0 ? " jcm-badge--warn" : ""}`}>{n === 0 ? "none" : n}</span>
                  <span
                    className={`jcm-check${on ? " is-on" : ""}`}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSel(toggleIn(sel, t.id));
                    }}
                  >
                    {on ? "✓" : ""}
                  </span>
                  <div className="jcm-card__name">{t.name}</div>
                  <div className="jcm-card__sub">
                    {t.year || ""} {t.type === "Series" ? "· Series" : ""}
                  </div>
                </div>
              );
            })}
          </div>
          {shown.length > limit ? <div className="jcm-empty">Scroll for more…</div> : null}
          {shown.length === 0 ? <div className="jcm-empty">No titles match.</div> : null}
        </div>
      </div>

      {current ? (
        <aside className="jcm-drawer">
          <button type="button" className="jcm-btn jcm-drawer__close" onClick={() => setOpen("")}>
            ✕
          </button>
          <div className="jcm-drawer__poster">
            <Poster instance={instance} id={current.has_poster === false ? undefined : current.id} name={current.name} />
          </div>
          <h3>{current.name}</h3>
          <div className="jcm-card__sub">
            {current.year || ""} · {current.type}
          </div>
          <div className="jcm-section-title">In collections</div>
          {(current.collections || []).length ? (
            <div className="jcm-tags">
              {(current.collections || []).map((c) => (
                <span key={c.id} className="jcm-tag">
                  {c.name}
                  <button type="button" disabled={busy} title="Remove from this collection" onClick={() => removeFrom(current, c.id)}>
                    ✕
                  </button>
                </span>
              ))}
            </div>
          ) : (
            <div className="jcm-hint">Not in any collection.</div>
          )}
          <div className="jcm-section-title">Add to a collection</div>
          <AddToBar
            instance={instance}
            ids={[current.id]}
            cols={cols.filter((c) => !(current.collections || []).some((x) => x.id === c.id))}
            onDone={async (m) => {
              setMsg(m);
              if (m.ok) {
                await load();
                onChanged();
              }
            }}
          />
        </aside>
      ) : null}
    </div>
  );
}

type SuggestionCard = {
  key: string;
  kind?: string;
  name?: string;
  target?: { id?: string; name?: string } | null;
  new_count?: number;
  skipped?: boolean;
  titles?: Array<{ id: string; name: string; year?: number | null; existing?: boolean; ticked?: boolean }>;
};
type AttentionItem = { id: string; name: string; type?: string; year?: number | null; reason?: string; fix?: string; ignored?: boolean };

function SuggestionsView({
  instance,
  mode,
  onChanged,
}: {
  instance: string;
  mode: "suggestions" | "attention";
  onChanged: () => void;
}) {
  const [view, setView] = useState<{ suggestions?: SuggestionCard[]; needs_attention?: AttentionItem[] } | null>(null);
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState<Msg | null>(null);
  const [busy, setBusy] = useState("");
  const [confirm, setConfirm] = useState("");

  const load = useCallback(async () => {
    try {
      setView(await jget(instance, "/api/suggestions"));
      setErr("");
    } catch (e) {
      setErr(errText(e));
    }
  }, [instance]);
  useEffect(() => {
    void load();
  }, [load]);

  async function act(path: string, key: string, done: string) {
    setBusy(key + path);
    setConfirm("");
    try {
      await jpost(instance, path, { key });
      setMsg({ ok: true, text: done });
      await load();
      onChanged();
    } catch (e) {
      setMsg({ ok: false, text: errText(e) });
    } finally {
      setBusy("");
    }
  }

  if (err && !view) return <div className="jcm-empty">⚠ {err}</div>;
  if (!view) return <div className="jcm-empty">Loading…</div>;

  if (mode === "attention") {
    const list = view.needs_attention || [];
    return (
      <>
        <Flash msg={msg} />
        {list.length === 0 ? <div className="jcm-empty">Nothing needs attention.</div> : null}
        <div className="jcm-list">
          {list.map((a) => (
            <div key={a.id + (a.reason || "")} className="jcm-row">
              <div className="jcm-row__poster">
                <Poster instance={instance} id={a.id} name={a.name} />
              </div>
              <div className="jcm-row__main">
                <strong>
                  {a.name} {a.year ? `(${a.year})` : ""}
                </strong>
                <div className="jcm-warn">{a.reason}</div>
                {a.fix ? <div className="jcm-hint">{a.fix}</div> : null}
              </div>
              <button
                type="button"
                className="jcm-btn"
                disabled={!!busy}
                onClick={() => act(a.ignored ? "/api/suggestions/attn_unignore" : "/api/suggestions/attn_ignore", a.id, a.ignored ? "Un-ignored" : "Ignored")}
              >
                {a.ignored ? "Stop ignoring" : "Ignore"}
              </button>
            </div>
          ))}
        </div>
      </>
    );
  }

  const cards = view.suggestions || [];
  return (
    <>
      <Flash msg={msg} />
      {cards.length === 0 ? <div className="jcm-empty">No suggestions right now. Run a scan to look for more.</div> : null}
      <div className="jcm-list">
        {cards.map((c) => {
          const titles = c.titles || [];
          const fresh = titles.filter((t) => !t.existing);
          return (
            <div key={c.key} className="jcm-suggest">
              <div className="jcm-suggest__head">
                <div>
                  <strong>{c.name || c.target?.name || c.key}</strong>
                  <div className="jcm-hint">
                    {c.kind === "new" ? "New collection" : `Add to ${c.target?.name || "existing collection"}`} ·{" "}
                    {c.new_count ?? fresh.length} new title{(c.new_count ?? fresh.length) === 1 ? "" : "s"}
                    {c.skipped ? " · skipped" : ""}
                  </div>
                </div>
                <div className="jcm-suggest__actions">
                  {confirm === c.key ? (
                    <>
                      <span className="jcm-hint">Apply this suggestion?</span>
                      <button type="button" className="jcm-btn jcm-btn--go" disabled={!!busy} onClick={() => act("/api/suggestions/approve", c.key, "Approved")}>
                        {busy === c.key + "/api/suggestions/approve" ? "Applying…" : "Yes, approve"}
                      </button>
                      <button type="button" className="jcm-btn" onClick={() => setConfirm("")}>
                        Cancel
                      </button>
                    </>
                  ) : (
                    <>
                      <button type="button" className="jcm-btn jcm-btn--go" disabled={!!busy} onClick={() => setConfirm(c.key)}>
                        Approve
                      </button>
                      <button
                        type="button"
                        className="jcm-btn"
                        disabled={!!busy}
                        onClick={() => act(c.skipped ? "/api/suggestions/unskip" : "/api/suggestions/skip", c.key, c.skipped ? "Restored" : "Skipped")}
                      >
                        {c.skipped ? "Unskip" : "Skip"}
                      </button>
                    </>
                  )}
                </div>
              </div>
              <div className="jcm-strip">
                {titles.slice(0, 14).map((t) => (
                  <div key={t.id} className={`jcm-mini${t.existing ? " is-dim" : ""}`} title={`${t.name}${t.year ? ` (${t.year})` : ""}`}>
                    <Poster instance={instance} id={t.id} name={t.name} />
                  </div>
                ))}
                {titles.length > 14 ? <span className="jcm-hint">+{titles.length - 14} more</span> : null}
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
}

type MissingFilm = {
  id: string;
  title: string;
  year: string;
  released: boolean;
  poster: string;
  seer: string;
  app: { result: string; detail: string } | null;
};
type MissingData = {
  running: boolean;
  progress: { phase: string; done: number; total: number };
  error: string;
  checked: boolean;
  finished: string;
  seerConfigured: boolean;
  seerError: string;
  hasTmdb: boolean;
  libraries: Array<{ id: string; name: string }>;
  franchises: Array<{
    id: string;
    name: string;
    inCollections: string[];
    libs: string[];
    have: Array<{ id: string; title: string; year: string }>;
    missing: MissingFilm[];
  }>;
  missing: number;
  unreleased: number;
};

function MissingView({ instance, onChanged }: { instance: string; onChanged: () => void }) {
  const [data, setData] = useState<MissingData | null>(null);
  const [err, setErr] = useState("");
  const [q, setQ] = useState("");
  const [lib, setLib] = useState("");
  const [showUnreleased, setShowUnreleased] = useState(false);
  const [sel, setSel] = useState<string[]>([]);
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState("");
  const [msg, setMsg] = useState<Msg | null>(null);

  const load = useCallback(
    async (fresh: boolean) => {
      try {
        const res = await fetch(`${BASE}?instance=${encodeURIComponent(instance)}&missing=1${fresh ? "&fresh=1" : ""}`);
        const json = await res.json();
        if (!res.ok) throw new Error(json.error || `Request failed (${res.status})`);
        setData(json as MissingData);
        setErr("");
      } catch (e) {
        setErr(errText(e));
      }
    },
    [instance],
  );

  useEffect(() => {
    void load(false);
  }, [load]);

  const running = Boolean(data?.running);
  useEffect(() => {
    if (!running) return;
    const timer = setInterval(() => void load(false), 3000);
    return () => clearInterval(timer);
  }, [running, load]);

  const wasRunning = useRunning(running);
  useEffect(() => {
    if (wasRunning) onChanged();
  }, [wasRunning, onChanged]);

  async function check() {
    setBusy("check");
    setMsg(null);
    try {
      const r = await jpost<{ started?: boolean; reason?: string }>(instance, "/api/missing/check", {});
      setMsg(r.started === false ? { ok: false, text: r.reason || "A check is already running." } : { ok: true, text: "Check started" });
      await load(false);
    } catch (e) {
      setMsg({ ok: false, text: errText(e) });
    } finally {
      setBusy("");
    }
  }

  async function requestSel() {
    setBusy("request");
    setConfirm(false);
    try {
      const r = await jpost<{ message?: string; requested?: number; failed?: number }>(instance, "/api/missing/request", { ids: sel });
      setMsg({ ok: !r.failed || Boolean(r.requested), text: r.message || "Done" });
      setSel([]);
      await load(true);
    } catch (e) {
      setMsg({ ok: false, text: errText(e) });
    } finally {
      setBusy("");
    }
  }

  const needle = q.trim().toLowerCase();
  const groups = useMemo(() => {
    if (!data) return [];
    return data.franchises
      .filter((f) => !lib || f.libs.includes(lib))
      .map((f) => {
        const nameHit = needle && f.name.toLowerCase().includes(needle);
        const missing = f.missing.filter(
          (m) => (showUnreleased || m.released) && (!needle || nameHit || m.title.toLowerCase().includes(needle)),
        );
        return { ...f, missing };
      })
      .filter((f) => f.missing.length);
  }, [data, needle, lib, showUnreleased]);

  if (err && !data) return <div className="jcm-empty">⚠ {err}</div>;
  if (!data) return <div className="jcm-empty">Loading missing movies…</div>;

  const requestable = (m: MissingFilm) => m.released && (!m.seer || /declined|failed/i.test(m.seer));
  const pct = data.progress.total ? Math.round((data.progress.done / data.progress.total) * 100) : 0;

  return (
    <>
      <div className="jcm-toolbar">
        <input className="jcm-search" placeholder="Search franchises or movies…" value={q} onChange={(e) => setQ(e.target.value)} />
        <span className="jcm-count">{data.missing} missing</span>
        <button type="button" className="jcm-btn jcm-btn--go" disabled={!!busy || running} onClick={check}>
          {running ? "Checking…" : "Check my collections"}
        </button>
        <button type="button" className="jcm-btn" onClick={() => load(true)}>
          Refresh Seer status
        </button>
      </div>
      <div className="jcm-chips">
        {data.libraries.length > 1
          ? data.libraries.map((l) => (
              <button key={l.id} type="button" className={`jcm-chip${lib === l.id ? " is-on" : ""}`} onClick={() => setLib(lib === l.id ? "" : l.id)}>
                {l.name}
              </button>
            ))
          : null}
        {data.unreleased ? (
          <button type="button" className={`jcm-chip${showUnreleased ? " is-on" : ""}`} onClick={() => setShowUnreleased(!showUnreleased)}>
            Show unreleased ({data.unreleased})
          </button>
        ) : null}
      </div>
      {running ? (
        <div className="jcm-flash jcm-flash--ok">
          {data.progress.phase || "Checking…"} {data.progress.total ? `${data.progress.done} / ${data.progress.total} (${pct}%)` : ""}
        </div>
      ) : null}
      {data.error ? <div className="jcm-flash jcm-flash--bad">{data.error}</div> : null}
      {!data.seerConfigured ? <div className="jcm-hint">Seer is not connected in the Collection Manager, so requesting is unavailable.</div> : null}
      {data.seerError ? <div className="jcm-hint">Seer: {data.seerError}</div> : null}
      <Flash msg={msg} />
      {sel.length ? (
        <div className="jcm-bar">
          <span>{sel.length} selected</span>
          {confirm ? (
            <>
              <span className="jcm-hint">Request {sel.length} movie(s) in Seer?</span>
              <button type="button" className="jcm-btn jcm-btn--go" disabled={!!busy} onClick={requestSel}>
                {busy === "request" ? "Requesting…" : "Yes, request"}
              </button>
              <button type="button" className="jcm-btn" onClick={() => setConfirm(false)}>
                Cancel
              </button>
            </>
          ) : (
            <>
              <button type="button" className="jcm-btn jcm-btn--go" disabled={!data.seerConfigured} onClick={() => setConfirm(true)}>
                Request in Seer
              </button>
              <button type="button" className="jcm-btn" onClick={() => setSel([])}>
                Clear
              </button>
            </>
          )}
        </div>
      ) : null}
      {!data.checked && !running ? (
        <div className="jcm-empty">
          {data.hasTmdb
            ? "Nothing checked yet. Press “Check my collections” to look for missing movies in your franchises."
            : "Add a TMDB key in the Collection Manager first: the franchise lists come from TMDB."}
        </div>
      ) : groups.length === 0 && data.checked ? (
        <div className="jcm-empty">{data.missing === 0 ? "Nothing is missing." : "No movies match."}</div>
      ) : (
        groups.map((f) => {
          const ids = f.missing.filter(requestable).map((m) => m.id);
          const all = ids.length > 0 && ids.every((i) => sel.includes(i));
          return (
            <section key={f.id || f.name} className="jcm-franchise">
              <div className="jcm-franchise__head">
                <h3>{f.name}</h3>
                <span className="jcm-count">
                  {f.missing.length} missing · you have {f.have.length}
                  {f.inCollections.length ? ` · in ${f.inCollections.join(", ")}` : ""}
                </span>
                {ids.length ? (
                  <button
                    type="button"
                    className="jcm-btn"
                    onClick={() => setSel(all ? sel.filter((i) => !ids.includes(i)) : Array.from(new Set([...sel, ...ids])))}
                  >
                    {all ? "Unselect all" : "Select all"}
                  </button>
                ) : null}
              </div>
              <div className="jcm-grid jcm-grid--small">
                {f.have.map((h) => (
                  <div key={`have-${h.id}`} className="jcm-card is-dim" title={`${h.title} (in library)`}>
                    <Poster instance={instance} id={h.id} name={h.title} />
                    <span className="jcm-badge">in library</span>
                    <div className="jcm-card__name">{h.title}</div>
                    <div className="jcm-card__sub">{h.year}</div>
                  </div>
                ))}
                {f.missing.map((m) => {
                  const can = requestable(m);
                  const on = sel.includes(m.id);
                  const status = m.app?.result === "failed" ? "failed" : m.seer || (m.app?.result === "sent" ? "requested" : "");
                  return (
                    <div
                      key={`${f.id}-${m.id}`}
                      className={`jcm-card${on ? " is-sel" : ""}`}
                      onClick={() => can && setSel(toggleIn(sel, m.id))}
                      style={{ cursor: can ? "pointer" : "default" }}
                      title={m.app?.detail ? `${m.title} — ${m.app.detail}` : m.title}
                    >
                      {m.poster ? (
                        <div className="jcm-poster">
                          {/* eslint-disable-next-line @next/next/no-img-element */}
                          <img loading="lazy" alt="" src={m.poster} />
                        </div>
                      ) : (
                        <Poster instance={instance} name={m.title} />
                      )}
                      {status ? <span className="jcm-badge jcm-badge--warn">{status}</span> : !m.released ? <span className="jcm-badge">unreleased</span> : null}
                      {can ? <span className={`jcm-check${on ? " is-on" : ""}`}>{on ? "✓" : ""}</span> : null}
                      <div className="jcm-card__name">{m.title}</div>
                      <div className="jcm-card__sub">{m.year}</div>
                    </div>
                  );
                })}
              </div>
            </section>
          );
        })
      )}
    </>
  );
}

function useRunning(running: boolean) {
  // true for one render after a running → idle change, so the card numbers refresh when a check finishes
  const [prev, setPrev] = useState(running);
  const finished = prev && !running;
  useEffect(() => {
    setPrev(running);
  }, [running]);
  return finished;
}

function ManagerModal({
  instance,
  view,
  setView,
  onClose,
  onChanged,
}: {
  instance: string;
  view: View;
  setView: (v: View) => void;
  onClose: () => void;
  onChanged: () => void;
}) {
  const titleFor: Record<string, string> = {
    collections: "Collections",
    collection: view.kind === "collection" ? view.name : "",
    titles: "Titles",
    suggestions: "Suggestions",
    attention: "Needs attention",
    missing: "Missing movies",
  };
  return (
    <Modal title={titleFor[view.kind]} onClose={onClose} onBack={view.kind === "collection" ? () => setView(view.back) : undefined}>
      {view.kind === "collections" ? (
        <CollectionsView
          key={view.filter || "all"}
          instance={instance}
          filter0={view.filter || "all"}
          onOpen={(c) => setView({ kind: "collection", id: c.id, name: c.name, back: view })}
          onChanged={onChanged}
        />
      ) : null}
      {view.kind === "collection" ? (
        <CollectionDetail key={view.id} instance={instance} id={view.id} allCols={[]} onChanged={onChanged} />
      ) : null}
      {view.kind === "titles" ? <TitlesView instance={instance} onChanged={onChanged} /> : null}
      {view.kind === "suggestions" ? <SuggestionsView instance={instance} mode="suggestions" onChanged={onChanged} /> : null}
      {view.kind === "missing" ? <MissingView instance={instance} onChanged={onChanged} /> : null}
      {view.kind === "attention" ? <SuggestionsView instance={instance} mode="attention" onChanged={onChanged} /> : null}
    </Modal>
  );
}
