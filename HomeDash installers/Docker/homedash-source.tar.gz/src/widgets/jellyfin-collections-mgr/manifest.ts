import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "jellyfin-collections-mgr",
  name: "Jellyfin Collections Manager",
  description: "Status, counts and quick actions for your Jellyfin Collection Manager panel",
  version: "0.5.3",
  category: "Media",
  defaultSize: { w: 4, h: 4, minW: 2, minH: 3 },
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "http://10.0.0.1:8090",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      placeholder: "https://collections.example.com",
    },
    {
      key: "publicUrl",
      label: "OPEN - Private URL",
      type: "url",
      placeholder: "http://10.0.0.1:8090",
    },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    { key: "pin", label: "Panel PIN (leave empty if none)", type: "password" },
  ],
};
