"use client";
import "@/styles/widgets/jellyfin.slider.widget.css";


import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type ReactNode,
  type RefObject,
} from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";

type Section = {
  key: string;
  title: string;
  itemTypes?: string;
  parentId?: string;
};

type Item = {
  Id: string;
  Name?: string;
  Type?: string;
  ProductionYear?: number;
  OfficialRating?: string;
  RunTimeTicks?: number;
  Overview?: string;
  Genres?: string[];
  AlbumArtist?: string;
  Artists?: string[];
  ChildCount?: number;
  ParentId?: string;
  ImageTags?: { Primary?: string };
  BackdropImageTags?: string[];
  AlbumPrimaryImageTag?: string;
  IndexNumber?: number;
  ParentIndexNumber?: number;
};

type ServerEntry = { label: string; publicUrl: string; openFallbackUrl?: string };
type PopupKind = "media" | "music" | "collection";
type DlMode = "episode" | "season" | "all";
type Trailer = { kind: "local" | "remote"; itemId?: string; name: string; url?: string };

function formatRuntime(ticks?: number) {
  if (!ticks || ticks <= 0) return "";
  const totalMinutes = Math.round(ticks / 10_000_000 / 60);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  return hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`;
}

function formatTrackDuration(ticks?: number) {
  if (!ticks || ticks <= 0) return "—";
  const totalSeconds = Math.round(ticks / 10_000_000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${String(seconds).padStart(2, "0")}`;
}

function primaryUrl(baseUrl: string, item: Item, maxWidth = 280) {
  const tag = item.ImageTags?.Primary || item.AlbumPrimaryImageTag;
  if (!tag || !item.Id) return "";
  return `${baseUrl.replace(/\/$/, "")}/Items/${item.Id}/Images/Primary?tag=${encodeURIComponent(tag)}&maxWidth=${maxWidth}&quality=85`;
}

function backdropUrl(baseUrl: string, item: Item) {
  const tag = item.BackdropImageTags?.[0];
  if (!tag || !item.Id) return "";
  return `${baseUrl.replace(/\/$/, "")}/Items/${item.Id}/Images/Backdrop/0?tag=${encodeURIComponent(tag)}&maxHeight=720&quality=80`;
}

function detailsHref(publicUrl: string, id: string) {
  return `${publicUrl.replace(/\/$/, "")}/web/index.html#!/details?id=${encodeURIComponent(id)}`;
}

function popupKindFor(item: Item, section?: Section): PopupKind {
  const type = item.Type || "";
  const sectionTypes = section?.itemTypes || "";
  if (type === "BoxSet" || sectionTypes === "BoxSet") return "collection";
  if (
    type === "MusicAlbum" ||
    type === "Audio" ||
    sectionTypes === "MusicAlbum" ||
    (section?.key || "").toLowerCase().includes("music")
  ) {
    return "music";
  }
  return "media";
}

function isMusicItem(item: Item, section?: Section) {
  const type = item.Type || "";
  const sectionTypes = section?.itemTypes || "";
  return (
    type === "MusicAlbum" ||
    type === "Audio" ||
    sectionTypes === "MusicAlbum" ||
    (section?.key || "").toLowerCase().includes("music")
  );
}

function apiUrl(
  path: string,
  params: Record<string, string | number | undefined>,
) {
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== "") search.set(key, String(value));
  }
  return `/api/widgets/jellyfin-slider/${path}?${search}`;
}

function trailerEmbedUrl(value?: string) {
  if (!value) return "";
  try {
    const url = new URL(value);
    const host = url.hostname.replace(/^www\./, "").toLowerCase();
    if (host === "youtu.be") {
      const id = url.pathname.split("/").filter(Boolean)[0];
      return id
        ? `https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}?autoplay=1&fs=0`
        : "";
    }
    if (host === "youtube.com" || host === "m.youtube.com") {
      const parts = url.pathname.split("/").filter(Boolean);
      const id =
        url.searchParams.get("v") ||
        (["embed", "shorts", "live"].includes(parts[0] || "") ? parts[1] : "");
      return id
        ? `https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}?autoplay=1&fs=0`
        : "";
    }
    if (host === "vimeo.com" || host === "player.vimeo.com") {
      const id = url.pathname.split("/").filter(Boolean).find((part) => /^\d+$/.test(part));
      return id ? `https://player.vimeo.com/video/${id}?autoplay=1` : "";
    }
  } catch {
    return "";
  }
  return "";
}

// ── Download manager ─────────────────────────────────────────────
// Downloads used to be a plain anchor-click save (see git history):
// the browser owned the save and streamed straight to disk, but that
// meant JS could never see byte progress, only fire-and-forget.
//
// To show real progress we now fetch() the file ourselves, read it as
// a stream, and save the assembled Blob once it's complete. The
// trade-off (accepted deliberately): the whole file is held in memory
// until it's done, which is fine for episodes/tracks but can spike
// memory on very large 4K movies. We still parse the real filename
// out of Content-Disposition ourselves (same reasoning as the old
// anchor-based approach) so saved files keep the correct extension.
type DownloadTask = {
  id: string;
  label: string;
  loaded: number;
  total: number; // 0 = unknown (no Content-Length)
  status: "downloading" | "done" | "error" | "canceled";
  // Which widget instance kicked this off — lets each slider's own
  // progress indicator show only its own downloads instead of every
  // download happening across every jellyfin-slider on the dashboard.
  instanceId: string;
  // Kept out of the rendered UI, used only so the Cancel button can
  // stop an in-flight fetch for this task.
  controller: AbortController;
};

const downloadTasks = new Map<string, DownloadTask>();
const downloadSubscribers = new Set<() => void>();
let downloadTaskSeq = 0;

// Task ids the user has already dismissed via the DownloadBlockNotice
// "Got it" button. This lives at module scope (like downloadTasks
// itself) rather than in DownloadBlockNotice's own component state,
// because a host dashboard can remount a widget instance when its tab
// regains focus/visibility — plain component state would reset on that
// remount and the notice would reappear for a download the user already
// acknowledged. Entries are cleaned up as their task finishes (see
// startDownload's finally block) so this can't grow unbounded.
const dismissedDownloadIds = new Set<string>();

// DownloadBlockNotice and DownloadCloseGuard both watch every download
// across every jellyfin-slider instance on the dashboard (see
// useDownloadTasks below), but each instance mounts its own copy of
// those components. Without dedup, having 2+ sliders on a dashboard
// means 2+ identical overlays stack on top of each other for the same
// download — visually duplicated, and each needs its own click to
// dismiss. createSingletonOwner lets a set of mounted instances agree
// on exactly one "owner" that's allowed to actually render; the others
// stay silent but keep listening, so if the owner unmounts (e.g. that
// widget is removed from the dashboard) another instance seamlessly
// takes over.
function createSingletonOwner() {
  const liveIds = new Set<number>();
  const subscribers = new Set<() => void>();
  let nextId = 1;

  function notify() {
    subscribers.forEach((listener) => listener());
  }

  return function useSingletonOwner(): boolean {
    const idRef = useRef<number | undefined>(undefined);
    if (idRef.current === undefined) idRef.current = nextId++;
    const [, forceRender] = useState(0);

    useEffect(() => {
      liveIds.add(idRef.current!);
      notify();
      const listener = () => forceRender((n) => n + 1);
      subscribers.add(listener);
      return () => {
        liveIds.delete(idRef.current!);
        subscribers.delete(listener);
        notify();
      };
    }, []);

    return liveIds.values().next().value === idRef.current;
  };
}

const useDownloadNoticeOwner = createSingletonOwner();
const useDownloadGuardOwner = createSingletonOwner();

function emitDownloadChange() {
  downloadSubscribers.forEach((listener) => listener());
  broadcastDownloadBridge();
}

// Best-effort hook for a host shell (e.g. a desktop app wrapping this
// dashboard) to notice active downloads on its own, without this
// widget knowing anything about that app. Nothing here assumes a
// listener exists — if nothing is listening this is a no-op.
//
// Contract for a host that wants to warn before closing:
//  - window.hdWidgetDownloads["jellyfin-slider"] = { active, count, tasks }
//    is kept up to date on every change and can be polled.
//  - a "hd-widget-downloads-changed" CustomEvent fires on every change
//    with the same shape in event.detail.
//  - before closing, the host can dispatch a "hd-widget-close-request"
//    CustomEvent with detail.widgetId === "jellyfin-slider" and a
//    detail.respond(proceed: boolean) callback; this widget answers by
//    calling it (true = ok to close, false = user chose to keep the
//    download going) after showing its own confirmation dialog.
function broadcastDownloadBridge() {
  try {
    const active = Array.from(downloadTasks.values()).filter((t) => t.status === "downloading");
    const info = {
      active: active.length > 0,
      count: active.length,
      tasks: active.map((t) => ({
        id: t.id,
        label: t.label,
        progress: t.total > 0 ? t.loaded / t.total : null,
      })),
    };
    const host = window as unknown as { hdWidgetDownloads?: Record<string, unknown> };
    host.hdWidgetDownloads = host.hdWidgetDownloads || {};
    host.hdWidgetDownloads["jellyfin-slider"] = info;
    window.dispatchEvent(
      new CustomEvent("hd-widget-downloads-changed", {
        detail: { widgetId: "jellyfin-slider", ...info },
      }),
    );
  } catch {
    // The bridge is a bonus, never let it break an actual download.
  }
}

// Pass an instanceId to get only the downloads that slider itself
// started; omit it (e.g. for the app-wide close guard) to see every
// download across every jellyfin-slider instance on the dashboard.
function useDownloadTasks(instanceId?: string): DownloadTask[] {
  const [, forceRender] = useState(0);
  useEffect(() => {
    const listener = () => forceRender((n) => n + 1);
    downloadSubscribers.add(listener);
    return () => {
      downloadSubscribers.delete(listener);
    };
  }, []);
  const all = Array.from(downloadTasks.values());
  return instanceId ? all.filter((t) => t.instanceId === instanceId) : all;
}

// Stops an in-flight download early. Aborting the fetch causes the read
// loop in startDownload to throw, which is caught there and turned into
// the "canceled" status (as opposed to "error", which is reserved for
// genuine failures).
function cancelDownload(id: string) {
  const task = downloadTasks.get(id);
  if (!task || task.status !== "downloading") return;
  task.controller.abort();
}

function parseFilenameFromDisposition(header: string | null, fallback: string) {
  if (!header) return fallback;
  const utf8Match = /filename\*\s*=\s*UTF-8''([^;]+)/i.exec(header);
  if (utf8Match) {
    try {
      return decodeURIComponent(utf8Match[1]);
    } catch {
      /* fall through to the plain form below */
    }
  }
  const plainMatch = /filename\s*=\s*"([^"]+)"|filename\s*=\s*([^;]+)/i.exec(header);
  const raw = (plainMatch?.[1] || plainMatch?.[2] || "").trim();
  return raw || fallback;
}

async function startDownload(
  instanceId: string,
  server: number,
  itemId: string,
  filenameHint: string,
) {
  const id = `dl-${Date.now()}-${downloadTaskSeq++}`;
  const controller = new AbortController();
  const task: DownloadTask = {
    id,
    label: filenameHint,
    loaded: 0,
    total: 0,
    status: "downloading",
    instanceId,
    controller,
  };
  downloadTasks.set(id, task);
  emitDownloadChange();

  let lastEmit = 0;
  const maybeEmit = (force = false) => {
    const now = Date.now();
    if (force || now - lastEmit > 150) {
      lastEmit = now;
      emitDownloadChange();
    }
  };

  try {
    const url = apiUrl("download", { instance: instanceId, itemId, server, filename: filenameHint });
    const response = await fetch(url, { signal: controller.signal });
    if (!response.ok || !response.body) {
      throw new Error(`Download failed (${response.status})`);
    }
    const total = Number(response.headers.get("content-length") || 0);
    task.total = Number.isFinite(total) ? total : 0;
    const finalName = parseFilenameFromDisposition(
      response.headers.get("content-disposition"),
      filenameHint,
    );
    const contentType = response.headers.get("content-type") || "application/octet-stream";

    const reader = response.body.getReader();
    const chunks: BlobPart[] = [];
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      if (value) {
        chunks.push(value);
        task.loaded += value.byteLength;
        maybeEmit();
      }
    }
    maybeEmit(true);

    const blob = new Blob(chunks, { type: contentType });
    const objectUrl = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = objectUrl;
    anchor.download = finalName;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(objectUrl), 30_000);

    task.status = "done";
  } catch (err) {
    const wasAborted = err instanceof DOMException && err.name === "AbortError";
    task.status = wasAborted ? "canceled" : "error";
  } finally {
    emitDownloadChange();
    setTimeout(() => {
      downloadTasks.delete(id);
      dismissedDownloadIds.delete(id);
      emitDownloadChange();
    }, task.status === "error" ? 3500 : 1800);
  }
}

// Bulk operations (season/series/collection "download everything") queue
// through here with a small concurrency cap, instead of firing every file
// at once, since each one now buffers fully in memory until it's saved.
function createDownloadQueue(concurrency: number) {
  const pending: Array<() => Promise<void>> = [];
  let active = 0;
  const runNext = () => {
    if (active >= concurrency) return;
    const job = pending.shift();
    if (!job) return;
    active++;
    job().finally(() => {
      active--;
      runNext();
    });
  };
  return {
    add(job: () => Promise<void>) {
      pending.push(job);
      runNext();
    },
  };
}

const bulkDownloadQueue = createDownloadQueue(3);

// ── Sync status: module-level, keyed by instanceId ──────────────────────
// Lives outside component state for the same reason downloadTasks does
// (see the comment on dismissedDownloadIds above): a host dashboard can
// remount a widget instance when its tab loses and regains focus/
// visibility. Plain useState-based sync progress would reset on that
// remount and, worse, the in-flight refresh/poll loop would be orphaned
// by its own cleanup effect clearing the interval — so a sync kicked off
// right before switching tabs would appear to silently "stop" and never
// finish. Keeping the loop and its progress here means it keeps running
// (and finishes, and refreshes the shelf) regardless of which component
// instance is mounted to observe it.
type SyncState = { syncing: boolean; progress: number; library: string };
const syncStates = new Map<string, SyncState>();
const syncSubscribers = new Set<() => void>();
const syncPollTimers = new Map<string, ReturnType<typeof setInterval>>();
const idleSyncState: SyncState = { syncing: false, progress: 0, library: "" };

function emitSyncChange() {
  syncSubscribers.forEach((listener) => listener());
}

function getSyncState(instanceId: string): SyncState {
  return syncStates.get(instanceId) || idleSyncState;
}

function patchSyncState(instanceId: string, patch: Partial<SyncState>) {
  syncStates.set(instanceId, { ...getSyncState(instanceId), ...patch });
  emitSyncChange();
}

// Subscribes the calling component to sync-progress updates for one
// widget instance, re-rendering it whenever that state changes —
// including a component that just mounted mid-sync (e.g. after the tab
// switch described above), which picks up the already-in-progress state
// immediately instead of showing a stale "not syncing" view.
function useSyncState(instanceId: string): SyncState {
  const [, forceRender] = useState(0);
  useEffect(() => {
    const listener = () => forceRender((n) => n + 1);
    syncSubscribers.add(listener);
    return () => {
      syncSubscribers.delete(listener);
    };
  }, []);
  return getSyncState(instanceId);
}

function stopSyncPollFor(instanceId: string) {
  const timer = syncPollTimers.get(instanceId);
  if (timer) {
    clearInterval(timer);
    syncPollTimers.delete(instanceId);
  }
}

// See the original inline comment this was lifted from: Jellyfin's
// /Items/{id}/Refresh only queues a scan; the library isn't actually
// updated until the "Scan Media Library" scheduled task finishes
// running, so this polls sync-status and drives the progress bar in the
// meantime instead of the sync appearing to do nothing (or reloading too
// early and showing stale items).
function pollSyncStatusFor(
  instanceId: string,
  server: number,
  rangeStart = 8,
  rangeEnd = 96,
): Promise<void> {
  return new Promise((resolve) => {
    stopSyncPollFor(instanceId);
    const startedAt = Date.now();
    const maxWaitMs = 90_000;
    let settled = false;
    const finish = () => {
      if (settled) return;
      settled = true;
      stopSyncPollFor(instanceId);
      resolve();
    };
    const tick = async () => {
      try {
        const response = await fetch(
          apiUrl("sync-status", { instance: instanceId, server }),
          { cache: "no-store" },
        );
        const data = await response.json();
        if (response.ok) {
          const progress = Number(data.progress);
          const fraction = Math.max(
            0.08,
            Math.min(1, Number.isFinite(progress) ? progress / 100 : 0.08),
          );
          const mapped = rangeStart + fraction * (rangeEnd - rangeStart);
          patchSyncState(instanceId, {
            progress: Math.max(getSyncState(instanceId).progress, Math.min(rangeEnd, mapped)),
          });
          if (!data.running) {
            patchSyncState(instanceId, { progress: Math.max(getSyncState(instanceId).progress, rangeEnd) });
            finish();
            return;
          }
        }
      } catch {
        /* transient status-check failure; keep polling until timeout */
      }
      if (Date.now() - startedAt > maxWaitMs) finish();
    };
    void tick();
    syncPollTimers.set(instanceId, setInterval(tick, 1200));
  });
}

// Runs entirely at module scope so it survives the initiating component
// unmounting (tab switch) and remounting (tab switch back) partway
// through. `targets` is the list of libraries to sync — pass every
// section for "Sync All", or a single-item array for one library.
async function runSync(instanceId: string, server: number, targets: Section[]) {
  if (getSyncState(instanceId).syncing || !targets.length) return;
  patchSyncState(instanceId, { syncing: true, progress: 2, library: "" });
  const total = targets.length;
  // Some tabs (e.g. "Kids" and "Kids TV") can resolve to the very same
  // Jellyfin library — track which library ids this pass already
  // triggered so we don't re-scan (and re-poll) the same library twice.
  const syncedLibraryIds = new Set<string>();
  try {
    for (let index = 0; index < total; index++) {
      const section = targets[index];
      const rangeStart = (index / total) * 100;
      const rangeEnd = ((index + 1) / total) * 100;
      patchSyncState(instanceId, {
        library: section.title,
        progress: Math.max(getSyncState(instanceId).progress, rangeStart),
      });
      try {
        const refreshResponse = await fetch(
          apiUrl("refresh", { instance: instanceId, section: section.key, server }),
          { method: "POST", cache: "no-store" },
        );
        const refreshData = await refreshResponse.json().catch(() => null);
        if (refreshData?.library) patchSyncState(instanceId, { library: refreshData.library });
        const libraryId: string | undefined = refreshData?.libraryId;
        if (libraryId && syncedLibraryIds.has(libraryId)) {
          patchSyncState(instanceId, { progress: Math.max(getSyncState(instanceId).progress, rangeEnd) });
          continue;
        }
        if (libraryId) syncedLibraryIds.add(libraryId);
        await pollSyncStatusFor(instanceId, server, rangeStart, rangeEnd);
      } catch {
        /* one library's scan trigger/poll failing shouldn't stop the rest */
      }
      patchSyncState(instanceId, { progress: Math.max(getSyncState(instanceId).progress, rangeEnd) });
    }
  } finally {
    stopSyncPollFor(instanceId);
    patchSyncState(instanceId, { syncing: false, progress: 0, library: "" });
  }
}

function clamp(value: number, min: number, max: number) {
  return Math.min(Math.max(value, min), max);
}

function cardSubtitle(item: Item, section?: Section) {
  if (isMusicItem(item, section)) return item.AlbumArtist || item.Artists?.[0] || "Album";
  const itemType = item.Type || section?.itemTypes;
  if (itemType === "BoxSet") {
    const count =
      item.ChildCount != null
        ? `${item.ChildCount} item${item.ChildCount !== 1 ? "s" : ""}`
        : "Collection";
    return item.ProductionYear ? `${item.ProductionYear} · ${count}` : count;
  }
  if (item.ProductionYear) return String(item.ProductionYear);
  if (itemType === "Series") return "TV Show";
  if (itemType === "Movie") return "Movie";
  return "Recently added";
}

function DlIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
      <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" />
      <polyline points="7 10 12 15 17 10" />
      <line x1="12" y1="15" x2="12" y2="3" />
    </svg>
  );
}

function SpinIcon({ size = 16 }: { size?: number }) {
  return (
    <svg
      className="jf-dl-spin"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
    >
      <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" />
    </svg>
  );
}

// Compact status pill for the toolbar: hidden entirely when nothing is
// downloading, otherwise shows an aggregate percentage (bytes-weighted
// across every active file) plus a thin progress bar. Falls back to an
// indeterminate animation when none of the active downloads have a
// known Content-Length yet.
function DownloadStatusIndicator({ instanceId }: { instanceId: string }) {
  // Scoped to this slider's own instanceId — with multiple jellyfin-slider
  // widgets on a dashboard, each one now only shows its own downloads
  // instead of every download happening anywhere on the page.
  const tasks = useDownloadTasks(instanceId);
  const active = tasks.filter((t) => t.status === "downloading");
  if (!active.length) return null;

  const known = active.filter((t) => t.total > 0);
  const loadedSum = known.reduce((sum, t) => sum + t.loaded, 0);
  const totalSum = known.reduce((sum, t) => sum + t.total, 0);
  const hasKnownProgress = known.length > 0 && totalSum > 0;
  const percent = hasKnownProgress ? Math.min(100, Math.round((loadedSum / totalSum) * 100)) : null;

  const label =
    active.length === 1
      ? active[0].label
      : `${active.length} downloads`;

  return (
    <div
      className="jf-dl-indicator"
      title={active.map((t) => t.label).join("\n")}
      role="status"
      aria-label={`Downloading: ${label}${percent != null ? `, ${percent}%` : ""}`}
    >
      <span className="jf-dl-indicator__icon">
        <DlIcon />
      </span>
      <span className="jf-dl-indicator__text">
        {active.length > 1 ? `${active.length} downloading` : "Downloading"}
        {percent != null ? ` · ${percent}%` : ""}
      </span>
      <span className="jf-dl-indicator__track">
        <span
          className={`jf-dl-indicator__fill${percent == null ? " jf-dl-indicator__fill--indeterminate" : ""}`}
          style={percent != null ? { width: `${percent}%` } : undefined}
        />
      </span>
      <button
        className="jf-dl-indicator__cancel"
        type="button"
        title={active.length > 1 ? "Cancel all downloads" : "Cancel download"}
        aria-label={active.length > 1 ? "Cancel all downloads" : "Cancel download"}
        onClick={() => active.forEach((t) => cancelDownload(t.id))}
      >
        Cancel
      </button>
    </div>
  );
}

// Informational toast shown whenever a fresh batch of downloads starts.
// Unlike DownloadCloseGuard below (which depends on a host app actually
// asking before it closes — something we can't guarantee from inside the
// widget alone), this doesn't wait on any external hook: it fires purely
// off this widget's own download tracking, so it's guaranteed to appear.
// It dismisses itself once every active download in the batch finishes,
// and can also be dismissed early with "Got it" (dismissing just hides
// the notice — it never cancels the download) or "Cancel" (cancels the
// in-flight download(s) and hides the notice).
function DownloadBlockNotice() {
  const tasks = useDownloadTasks();
  const active = tasks.filter((t) => t.status === "downloading");
  const hasActive = active.length > 0;
  const isOwner = useDownloadNoticeOwner();

  // A batch counts as dismissed once every currently-active task id is in
  // dismissedDownloadIds. Reading the module-level set directly (rather
  // than mirroring it into local state) is what makes the dismissal
  // survive a remount: if this component unmounts and remounts while the
  // same download is still running, its id is still in the set, so the
  // notice stays hidden. A genuinely new download (a fresh, not-yet-seen
  // task id) is never in the set, so it still surfaces normally.
  const [, forceRender] = useState(0);
  const allDismissed = hasActive && active.every((t) => dismissedDownloadIds.has(t.id));

  if (!hasActive || allDismissed || !isOwner) return null;

  const dismiss = () => {
    active.forEach((t) => dismissedDownloadIds.add(t.id));
    forceRender((n) => n + 1);
  };

  return createPortal(
    <>
      <div className="jf-dl-notice-backdrop" onClick={dismiss} />
      <div className="jf-dl-notice" role="status">
        <span className="jf-dl-notice__icon">
          <DlIcon />
        </span>
        <span className="jf-dl-notice__text">
          Downloading media — this app won&apos;t close until the download is complete.
        </span>
        <div className="jf-dl-notice__actions">
          <button
            className="jf-dl-notice__dismiss"
            type="button"
            onClick={dismiss}
          >
            Got it
          </button>
          <button
            className="jf-dl-notice__cancel"
            type="button"
            onClick={() => {
              active.forEach((t) => cancelDownload(t.id));
              dismiss();
            }}
          >
            Cancel
          </button>
        </div>
      </div>
    </>,
    document.body,
  );
}

// Best-effort guard against losing an in-flight download when the page
// (or the app hosting it) goes away:
//  1. A standard `beforeunload` handler, which covers a plain tab/window
//     close or refresh — the browser shows its own native "leave site?"
//     prompt (its wording can't be customized, that's a browser
//     restriction, not something this widget controls).
//  2. A friendlier, fully custom dialog for a host app that wants to
//     ask first instead of relying on step 1. It listens for a
//     "hd-widget-close-request" CustomEvent (see the bridge contract
//     above the download manager) and shows this widget's own
//     confirmation UI, then reports the user's choice back through
//     detail.respond(proceed).
//  Note: neither of these fires unless the host app actually triggers a
//  page unload or calls into the bridge — see DownloadBlockNotice above
//  for the guaranteed-to-show notice.
function DownloadCloseGuard() {
  const tasks = useDownloadTasks();
  const active = tasks.filter((t) => t.status === "downloading");
  const activeCountRef = useRef(0);
  activeCountRef.current = active.length;
  const isOwner = useDownloadGuardOwner();

  const [pendingRespond, setPendingRespond] = useState<((proceed: boolean) => void) | null>(null);

  useEffect(() => {
    if (!isOwner) return;
    const onBeforeUnload = (event: BeforeUnloadEvent) => {
      if (activeCountRef.current > 0) {
        event.preventDefault();
        event.returnValue = "";
      }
    };
    const onCloseRequest = (event: Event) => {
      const detail = (event as CustomEvent<{ widgetId?: string; respond?: (proceed: boolean) => void }>)
        .detail;
      if (!detail || detail.widgetId !== "jellyfin-slider" || typeof detail.respond !== "function") return;
      if (activeCountRef.current === 0) {
        detail.respond(true);
        return;
      }
      setPendingRespond(() => detail.respond);
    };
    window.addEventListener("beforeunload", onBeforeUnload);
    window.addEventListener("hd-widget-close-request", onCloseRequest);
    return () => {
      window.removeEventListener("beforeunload", onBeforeUnload);
      window.removeEventListener("hd-widget-close-request", onCloseRequest);
    };
  }, [isOwner]);

  if (!pendingRespond) return null;

  const respond = (proceed: boolean) => {
    pendingRespond(proceed);
    setPendingRespond(null);
  };

  return createPortal(
    <>
      <div className="jf-close-modal-backdrop" />
      <div className="jf-close-modal" role="alertdialog" aria-modal="true" aria-label="Download in progress">
        <div className="jf-close-modal__title">Download still in progress</div>
        <div className="jf-close-modal__msg">
          {active.length === 1
            ? `"${active[0].label}" is still downloading.`
            : `${active.length} downloads are still in progress.`}{" "}
          Closing now will stop {active.length === 1 ? "it" : "them"} partway through.
        </div>
        <div className="jf-close-modal__actions">
          <button
            className="jf-close-modal__btn jf-close-modal__btn--primary"
            type="button"
            onClick={() => respond(false)}
          >
            Keep downloading
          </button>
          <button
            className="jf-close-modal__btn jf-close-modal__btn--danger"
            type="button"
            onClick={() => respond(true)}
          >
            Cancel download &amp; close
          </button>
        </div>
      </div>
    </>,
    document.body,
  );
}

function SyncMenu({
  sections,
  onClose,
  onPick,
}: {
  sections: Section[];
  onClose: () => void;
  onPick: (keys?: string[]) => void;
}) {
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return createPortal(
    <>
      <div className="jf-sync-modal-backdrop" onClick={onClose} />
      <div className="jf-sync-modal" role="dialog" aria-modal="true" aria-label="Sync Jellyfin libraries">
        <button className="jf-sync-modal__close" type="button" aria-label="Close" onClick={onClose}>
          ×
        </button>
        <div className="jf-sync-modal__title">Sync Jellyfin</div>
        <button
          className="jf-sync-modal__all"
          type="button"
          onClick={() => onPick(undefined)}
        >
          Sync All Libraries
        </button>
        {sections.length ? (
          <>
            <div className="jf-sync-modal__divider">or sync one library</div>
            <div className="jf-sync-modal__list">
              {sections.map((section) => (
                <button
                  key={section.key}
                  className="jf-sync-modal__item"
                  type="button"
                  onClick={() => onPick([section.key])}
                >
                  {section.title}
                </button>
              ))}
            </div>
          </>
        ) : null}
      </div>
    </>,
    document.body,
  );
}

function SeriesDownloadPanel({
  item,
  instanceId,
  server,
  onBack,
}: {
  item: Item;
  instanceId: string;
  server: number;
  onBack: () => void;
}) {
  const [mode, setMode] = useState<DlMode>("episode");
  const [seasons, setSeasons] = useState<Item[] | null>(null);
  const [episodes, setEpisodes] = useState<Item[] | null>(null);
  const [selectedSeason, setSelectedSeason] = useState<Item | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState("");

  useEffect(() => {
    let alive = true;
    setLoading(true);
    setError("");
    setSeasons(null);
    setEpisodes(null);
    setSelectedSeason(null);
    fetch(apiUrl("seasons", { instance: instanceId, seriesId: item.Id, server }))
      .then(async (response) => {
        const json = await response.json();
        if (!response.ok) throw new Error(json.error || "Failed to load seasons");
        if (alive) setSeasons(json.items || []);
      })
      .catch((err) => {
        if (alive) setError(err instanceof Error ? err.message : "Failed to load seasons");
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [instanceId, item.Id, server]);

  const loadEpisodes = useCallback(
    async (season: Item) => {
      setSelectedSeason(season);
      setEpisodes(null);
      setLoading(true);
      try {
        const response = await fetch(
          apiUrl("seasons", {
            instance: instanceId,
            seriesId: item.Id,
            seasonId: season.Id,
            server,
          }),
        );
        const json = await response.json();
        if (!response.ok) throw new Error(json.error || "Failed to load episodes");
        setEpisodes(json.items || []);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to load episodes");
      } finally {
        setLoading(false);
      }
    },
    [instanceId, item.Id, server],
  );

  const downloadEpisodes = useCallback(
    (list: Item[], seasonName: string) => {
      list.forEach((ep) => {
        const num = String(ep.IndexNumber || "?").padStart(2, "0");
        bulkDownloadQueue.add(() =>
          startDownload(
            instanceId,
            server,
            ep.Id,
            `${item.Name} - ${seasonName} - E${num} ${ep.Name || "Episode"}`,
          ),
        );
      });
    },
    [instanceId, item.Name, server],
  );

  const downloadAllSeasons = useCallback(async () => {
    if (!seasons?.length) return;
    setBusy("Preparing…");
    try {
      const all = await Promise.all(
        seasons.map(async (season) => {
          const response = await fetch(
            apiUrl("seasons", {
              instance: instanceId,
              seriesId: item.Id,
              seasonId: season.Id,
              server,
            }),
          );
          const json = await response.json();
          return { season, eps: json.items || [] };
        }),
      );
      let count = 0;
      all.forEach(({ season, eps }) => {
        downloadEpisodes(eps, season.Name || "Season");
        count += eps.length;
      });
      setBusy(`✓ ${count} episode${count !== 1 ? "s" : ""} downloading`);
    } catch {
      setBusy("Error — try again");
    }
  }, [downloadEpisodes, instanceId, item.Id, seasons, server]);

  let picker: ReactNode;
  if (loading && !seasons) {
    picker = (
      <div className="jf-dl-loading">
        <SpinIcon /> Loading…
      </div>
    );
  } else if (error && !seasons?.length) {
    picker = <div className="jf-dl-empty">{error}</div>;
  } else if (!seasons?.length) {
    picker = <div className="jf-dl-empty">No seasons found</div>;
  } else if (mode === "all") {
    picker = (
      <div className="jf-dl-confirm">
        <div className="jf-dl-confirm-msg">
          Download all {seasons.length} season{seasons.length !== 1 ? "s" : ""}?
          <br />
          <span style={{ fontSize: "0.65rem", opacity: 0.55 }}>
            Each episode downloads separately.
          </span>
        </div>
        <button
          className="jf-dl-confirm-btn"
          type="button"
          disabled={!!busy}
          onClick={downloadAllSeasons}
        >
          {busy ? (
            <>
              <SpinIcon size={13} /> {busy}
            </>
          ) : (
            <>
              <DlIcon /> Download Everything
            </>
          )}
        </button>
      </div>
    );
  } else if (mode === "season" && selectedSeason && episodes) {
    picker = (
      <div className="jf-dl-confirm">
        <div className="jf-dl-confirm-msg">
          {selectedSeason.Name}
          <br />
          <span style={{ fontSize: "0.65rem", opacity: 0.55 }}>
            {episodes.length} episode{episodes.length !== 1 ? "s" : ""} · each downloads separately
          </span>
        </div>
        <button
          className="jf-dl-confirm-btn"
          type="button"
          disabled={!!busy}
          onClick={() => {
            setBusy("Starting…");
            downloadEpisodes(episodes, selectedSeason.Name || "Season");
            setTimeout(
              () => setBusy(`✓ ${episodes.length} episode${episodes.length !== 1 ? "s" : ""} downloading`),
              800,
            );
          }}
        >
          {busy ? (
            <>
              <SpinIcon size={13} /> {busy}
            </>
          ) : (
            <>
              <DlIcon /> Download Season
            </>
          )}
        </button>
        <button
          className="jf-dl-back-inline"
          type="button"
          onClick={() => {
            setSelectedSeason(null);
            setEpisodes(null);
            setBusy("");
          }}
        >
          ← Back to seasons
        </button>
      </div>
    );
  } else if (mode === "episode" && selectedSeason && episodes) {
    picker = (
      <>
        <button
          className="jf-dl-back-inline"
          type="button"
          onClick={() => {
            setSelectedSeason(null);
            setEpisodes(null);
          }}
        >
          ← Back to seasons
        </button>
        <div className="jf-dl-list jf-dl-list--episodes">
          {episodes.map((ep) => (
            <button
              key={ep.Id}
              className="jf-dl-list-item jf-dl-list-item--episode"
              type="button"
              onClick={(event) => {
                const btn = event.currentTarget;
                if (btn.disabled) return;
                btn.disabled = true;
                const num = String(ep.IndexNumber || "?").padStart(2, "0");
                startDownload(
                  instanceId,
                  server,
                  ep.Id,
                  `${item.Name} - ${selectedSeason.Name} - E${num} ${ep.Name || "Episode"}`,
                );
                setTimeout(() => {
                  btn.disabled = false;
                }, 1800);
              }}
            >
              <DlIcon />
              <span className="jf-dl-ep-num">E{String(ep.IndexNumber || "?").padStart(2, "0")}</span>
              <span className="jf-dl-ep-name">{ep.Name || "Episode"}</span>
            </button>
          ))}
        </div>
      </>
    );
  } else {
    picker = (
      <>
        {mode === "episode" ? <div className="jf-dl-hint">Select a season</div> : null}
        <div className="jf-dl-list">
          {seasons.map((season) => (
            <button
              key={season.Id}
              className="jf-dl-list-item"
              type="button"
              onClick={() => loadEpisodes(season)}
            >
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="2" y="3" width="20" height="14" rx="2" />
                <line x1="8" y1="21" x2="16" y2="21" />
                <line x1="12" y1="17" x2="12" y2="21" />
              </svg>
              {season.Name}
            </button>
          ))}
        </div>
      </>
    );
  }

  return (
    <>
      <div className="jf-dl-header">
        <button className="jf-dl-back" type="button" aria-label="Back" onClick={onBack}>
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <path d="M15 18l-6-6 6-6" />
          </svg>
          Back
        </button>
        <span className="jf-dl-title">Download</span>
      </div>
      <div className="jf-dl-body">
        <div className="jf-dl-mode-row">
          {(["episode", "season", "all"] as DlMode[]).map((entry) => (
            <button
              key={entry}
              className={`jf-dl-mode-btn${mode === entry ? " jf-dl-mode-btn--active" : ""}`}
              type="button"
              onClick={() => {
                setMode(entry);
                setSelectedSeason(null);
                setEpisodes(null);
                setBusy("");
              }}
            >
              {entry === "episode" ? "Episode" : entry === "season" ? "Season" : "All Seasons"}
            </button>
          ))}
        </div>
        <div className="jf-dl-picker" data-view={mode}>
          {picker}
        </div>
      </div>
    </>
  );
}

function ItemPopup({
  item,
  kind,
  sectionTitle,
  baseUrl,
  publicUrl,
  instanceId,
  server,
  onClose,
  onOpenItem,
}: {
  item: Item;
  kind: PopupKind;
  sectionTitle: string;
  baseUrl: string;
  publicUrl: string;
  instanceId: string;
  server: number;
  onClose: () => void;
  onOpenItem: (next: Item) => void;
}) {
  const [tracks, setTracks] = useState<Item[] | null>(null);
  const [children, setChildren] = useState<Item[] | null>(null);
  const [childError, setChildError] = useState("");
  const [showDownloadPanel, setShowDownloadPanel] = useState(false);
  const [dlAllBusy, setDlAllBusy] = useState("");
  const [trailer, setTrailer] = useState<Trailer | null>(null);
  const [trailerBusy, setTrailerBusy] = useState(false);
  const [trailerError, setTrailerError] = useState("");
  const [trailerExpanded, setTrailerExpanded] = useState(false);
  const trailerCardRef = useRef<HTMLDivElement | null>(null);
  const [demoTrack, setDemoTrack] = useState<Item | null>(null);
  const [selectedTrack, setSelectedTrack] = useState<Item | null>(null);

  const isSeries = item.Type === "Series";
  const canShowTrailer = kind === "media" && (item.Type === "Movie" || isSeries);
  const title = item.Name || "Untitled";
  const year = item.ProductionYear ? String(item.ProductionYear) : "";
  const image = primaryUrl(baseUrl, item, kind === "music" ? 360 : 320);
  const backdrop = backdropUrl(baseUrl, item) || (kind === "music" ? image : "");
  const openHref = detailsHref(publicUrl, item.Id);

  const closeTrailer = useCallback(() => {
    if (typeof document !== "undefined" && document.fullscreenElement) {
      document.exitFullscreen?.().catch(() => {});
    }
    setTrailerExpanded(false);
    setTrailer(null);
  }, []);

  // The packaged desktop (.exe) build wraps pages in a webview that often
  // rejects or silently ignores the Fullscreen API, so the button can't
  // rely on requestFullscreen() alone. It's attempted as an enhancement,
  // but the CSS "expanded" state below is what actually guarantees the
  // trailer grows to fill the window in every environment.
  const toggleTrailerExpand = useCallback(() => {
    setTrailerExpanded((prev) => {
      const next = !prev;
      const node = trailerCardRef.current;
      if (typeof document !== "undefined" && node) {
        if (next) {
          const request =
            node.requestFullscreen?.bind(node) ||
            (node as unknown as { webkitRequestFullscreen?: () => Promise<void> })
              .webkitRequestFullscreen;
          try {
            const result = request?.call(node);
            if (result && typeof (result as Promise<void>).catch === "function") {
              (result as Promise<void>).catch(() => {});
            }
          } catch {
            // Fullscreen API unavailable or blocked (common in the .exe
            // build) — the CSS expanded state below still applies.
          }
        } else if (document.fullscreenElement) {
          document.exitFullscreen?.().catch(() => {});
        }
      }
      return next;
    });
  }, []);

  useEffect(() => {
    if (typeof document === "undefined") return;
    const onFullscreenChange = () => {
      if (!document.fullscreenElement) setTrailerExpanded(false);
    };
    document.addEventListener("fullscreenchange", onFullscreenChange);
    return () => document.removeEventListener("fullscreenchange", onFullscreenChange);
  }, []);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      if (trailer) closeTrailer();
      else if (demoTrack) setDemoTrack(null);
      else onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [closeTrailer, demoTrack, onClose, trailer]);

  useEffect(() => {
    let alive = true;
    setShowDownloadPanel(false);
    setDemoTrack(null);
    setSelectedTrack(null);
    if (kind === "music") {
      setTracks(null);
      fetch(apiUrl("tracks", { instance: instanceId, albumId: item.Id, server }))
        .then(async (response) => {
          const json = await response.json();
          if (!response.ok) throw new Error(json.error || "Failed to load tracks");
          if (alive) {
            const nextTracks = (json.items || []) as Item[];
            setTracks(nextTracks);
            setSelectedTrack(nextTracks[0] || null);
          }
        })
        .catch((error) => {
          if (alive) {
            setTracks([]);
            setChildError(error instanceof Error ? error.message : "Failed to load tracks");
          }
        });
    }
    if (kind === "collection") {
      setChildren(null);
      fetch(apiUrl("collection", { instance: instanceId, id: item.Id, server }))
        .then(async (response) => {
          const json = await response.json();
          if (!response.ok) throw new Error(json.error || "Failed to load collection");
          if (alive) setChildren(json.items || []);
        })
        .catch((error) => {
          if (alive) {
            setChildren([]);
            setChildError(error instanceof Error ? error.message : "Failed to load collection");
          }
        });
    }
    return () => {
      alive = false;
    };
  }, [kind, item.Id, instanceId, server]);

  let kicker = "";
  let meta = "";
  if (kind === "music") {
    const artist =
      selectedTrack?.Artists?.[0] ||
      item.AlbumArtist ||
      item.Artists?.[0] ||
      "Unknown Artist";
    const genres = (item.Genres || []).slice(0, 3).join(" · ");
    kicker = selectedTrack
      ? [
          sectionTitle || "Music",
          selectedTrack.IndexNumber != null ? `Track ${selectedTrack.IndexNumber}` : "Track",
          title,
        ].filter(Boolean).join(" · ")
      : [sectionTitle || "Music", "Album", year].filter(Boolean).join(" · ");
    meta = selectedTrack
      ? [artist, formatTrackDuration(selectedTrack.RunTimeTicks), year].filter(Boolean).join(" · ")
      : [artist, year, genres].filter(Boolean).join(" · ");
  } else if (kind === "collection") {
    const count =
      item.ChildCount != null ? `${item.ChildCount} item${item.ChildCount !== 1 ? "s" : ""}` : "";
    kicker = [sectionTitle || "Collections", "Collection", year].filter(Boolean).join(" · ");
    meta = [count, year].filter(Boolean).join(" · ");
  } else {
    const typeLabel = isSeries ? "Series" : item.Type === "Movie" ? "Movie" : item.Type || "Media";
    kicker = [sectionTitle || (isSeries ? "TV" : "Movies"), typeLabel, year]
      .filter(Boolean)
      .join(" · ");
    meta = [formatRuntime(item.RunTimeTicks), item.OfficialRating, year].filter(Boolean).join(" · ");
  }

  const downloadCollectionAll = async () => {
    if (!children?.length) return;
    setDlAllBusy("Preparing…");
    let offset = 0;
    try {
      for (const child of children) {
        if (child.Type === "Series") {
          const seasonsRes = await fetch(
            apiUrl("seasons", { instance: instanceId, seriesId: child.Id, server }),
          );
          const seasonsJson = await seasonsRes.json();
          const seasons = seasonsJson.items || [];
          for (const season of seasons) {
            const epsRes = await fetch(
              apiUrl("seasons", {
                instance: instanceId,
                seriesId: child.Id,
                seasonId: season.Id,
                server,
              }),
            );
            const epsJson = await epsRes.json();
            for (const ep of epsJson.items || []) {
              const num = String(ep.IndexNumber || "?").padStart(2, "0");
              offset++;
              bulkDownloadQueue.add(() =>
                startDownload(
                  instanceId,
                  server,
                  ep.Id,
                  `${child.Name} - ${season.Name} - E${num} ${ep.Name || "Episode"}`,
                ),
              );
            }
          }
        } else {
          offset++;
          bulkDownloadQueue.add(() =>
            startDownload(instanceId, server, child.Id, child.Name || "Download"),
          );
        }
      }
      setDlAllBusy(offset ? `✓ ${offset} downloading` : "Nothing to download");
      setTimeout(() => setDlAllBusy(""), 2200);
    } catch {
      setDlAllBusy("Error — try again");
    }
  };

  const openTrailer = async () => {
    setTrailerBusy(true);
    setTrailerError("");
    try {
      const response = await fetch(
        apiUrl("trailer", { instance: instanceId, itemId: item.Id, server }),
        { cache: "no-store" },
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load trailer");
      if (!json.trailer) {
        setTrailerError("No trailer is available for this title.");
        return;
      }
      setTrailerExpanded(false);
      setTrailer(json.trailer as Trailer);
    } catch (error) {
      setTrailerError(error instanceof Error ? error.message : "Failed to load trailer");
    } finally {
      setTrailerBusy(false);
    }
  };

  const trailerEmbed = trailer ? trailerEmbedUrl(trailer.url) : undefined;
  // YouTube embeds are requested with fs=0 (see trailerEmbedUrl), which
  // removes YouTube's own fullscreen button, so our control can safely sit
  // in the normal bottom-right spot. Vimeo has no equivalent flag, so its
  // embed keeps its native fullscreen button — ours moves out of the way
  // to the opposite corner instead of stacking on top of theirs.
  const isUncontrolledEmbed = !!trailerEmbed && !trailerEmbed.includes("youtube-nocookie.com");

  return createPortal(
    <>
      <div className="jf-popup-backdrop jf-popup-backdrop--dim" onClick={onClose} />
      <div
        className={`jf-popup jf-popup--${kind}`}
        role="dialog"
        aria-modal="true"
        aria-label={title}
      >
        <button className="jf-popup__close" type="button" aria-label="Close" onClick={onClose}>
          ×
        </button>
        {backdrop ? (
          <div className="jf-popup__bg" style={{ backgroundImage: `url('${backdrop}')` }} />
        ) : null}
        <div className={`jf-popup__body jf-popup__body--${kind}`}>
          <div className={kind === "music" ? "jf-popup__cover-wrap" : "jf-popup__poster-wrap"}>
            {image ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                className={kind === "music" ? "jf-popup__cover" : "jf-popup__poster-lg"}
                src={image}
                alt={title}
              />
            ) : (
              <div
                className={
                  kind === "music"
                    ? "jf-popup__cover-placeholder"
                    : "jf-popup__poster-placeholder jf-popup__poster-placeholder--lg"
                }
              >
                {title.charAt(0)}
              </div>
            )}
          </div>

          <div className={`jf-popup__info jf-popup__info--${kind}`}>
            <div className="jf-popup__kicker">{kicker}</div>
            <div className="jf-popup__title jf-popup__title--media">
              {kind === "music" && selectedTrack ? selectedTrack.Name || "Track" : title}
            </div>
            {meta ? <div className="jf-popup__meta">{meta}</div> : null}
            {kind === "music" && selectedTrack ? (
              <div className="jf-popup__summary">From the album {title}</div>
            ) : (item.Overview || kind !== "music") && (
              <div className="jf-popup__summary">{item.Overview || "No summary available."}</div>
            )}

            <div className="jf-popup__actions jf-popup__actions--media">
              {showDownloadPanel && isSeries ? (
                <SeriesDownloadPanel
                  item={item}
                  instanceId={instanceId}
                  server={server}
                  onBack={() => setShowDownloadPanel(false)}
                />
              ) : (
                <>
                  <a
                    className="jf-popup__open-btn"
                    href={openHref}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Open in Jellyfin
                  </a>
                  {canShowTrailer ? (
                    <button
                      className="jf-popup__trailer-btn"
                      type="button"
                      disabled={trailerBusy}
                      onClick={openTrailer}
                    >
                      {trailerBusy ? (
                        <SpinIcon size={13} />
                      ) : (
                        <svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true">
                          <path fill="currentColor" d="M8 5v14l11-7z" />
                        </svg>
                      )}
                      {trailerBusy ? "Loading…" : "Trailer"}
                    </button>
                  ) : null}
                  {kind === "music" ? (
                    <button
                      className="jf-popup__demo-btn"
                      type="button"
                      disabled={!selectedTrack}
                      onClick={() => {
                        if (selectedTrack) setDemoTrack(selectedTrack);
                      }}
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true">
                        <path fill="currentColor" d="M8 5v14l11-7z" />
                      </svg>
                      {tracks === null ? "Loading demo…" : "Demo"}
                    </button>
                  ) : null}
                  {kind !== "collection" ? (
                    <button
                      className="jf-popup__download-btn"
                      type="button"
                      onClick={() => {
                        if (isSeries) {
                          setShowDownloadPanel(true);
                        } else {
                          startDownload(instanceId, server, item.Id, item.Name || "Download");
                          onClose();
                        }
                      }}
                    >
                      <DlIcon />
                      {isSeries ? "Download Episodes" : kind === "music" ? "Download Album" : "Download"}
                    </button>
                  ) : (
                    <button
                      className="jf-popup__download-btn jf-popup__download-all-btn"
                      type="button"
                      disabled={!children?.length || !!dlAllBusy}
                      onClick={downloadCollectionAll}
                    >
                      {dlAllBusy ? (
                        <>
                          <SpinIcon size={13} /> {dlAllBusy}
                        </>
                      ) : (
                        <>
                          <DlIcon /> Download All
                        </>
                      )}
                    </button>
                  )}
                </>
              )}
            </div>
            {trailerError ? <div className="jf-popup__trailer-error">{trailerError}</div> : null}

            {kind === "music" ? (
              <div className="jf-popup__track-section">
                <div className="jf-popup__section-label">
                  {tracks ? `${tracks.length} Track${tracks.length !== 1 ? "s" : ""}` : "Tracks"}
                </div>
                <div className="jf-popup__track-list">
                  {!tracks ? (
                    <div className="jf-dl-loading">
                      <SpinIcon /> Loading tracks…
                    </div>
                  ) : tracks.length ? (
                    tracks.map((track) => (
                      <div
                        className={`jf-popup__track${selectedTrack?.Id === track.Id ? " is-selected" : ""}`}
                        key={track.Id}
                        role="button"
                        tabIndex={0}
                        aria-current={selectedTrack?.Id === track.Id ? "true" : undefined}
                        onClick={() => setSelectedTrack(track)}
                        onKeyDown={(event) => {
                          if (event.key === "Enter" || event.key === " ") {
                            event.preventDefault();
                            setSelectedTrack(track);
                          }
                        }}
                      >
                        <span className="jf-popup__track-num">
                          {track.IndexNumber != null ? track.IndexNumber : "–"}
                        </span>
                        <span className="jf-popup__track-meta">
                          <span className="jf-popup__track-name">{track.Name || "Track"}</span>
                          <span className="jf-popup__track-artist">
                            {track.Artists?.[0] || item.AlbumArtist || "Unknown Artist"}
                          </span>
                        </span>
                        <span className="jf-popup__track-dur">
                          {formatTrackDuration(track.RunTimeTicks)}
                        </span>
                        <button
                          className="jf-popup__track-dl"
                          type="button"
                          aria-label="Download track"
                          title="Download"
                          onClick={(event) => {
                            event.stopPropagation();
                            startDownload(
                              instanceId,
                              server,
                              track.Id,
                              track.Name || "Track",
                            );
                            event.currentTarget.classList.add("is-done");
                            setTimeout(() => event.currentTarget.classList.remove("is-done"), 1600);
                          }}
                        >
                          <svg
                            width="12"
                            height="12"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2.2"
                          >
                            <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" />
                            <polyline points="7 10 12 15 17 10" />
                            <line x1="12" y1="15" x2="12" y2="3" />
                          </svg>
                        </button>
                      </div>
                    ))
                  ) : (
                    <div className="jf-dl-empty">{childError || "No tracks found"}</div>
                  )}
                </div>
              </div>
            ) : null}
          </div>

          {kind === "collection" ? (
            <div className="jf-popup__collection-section">
              <div className="jf-popup__section-label">
                {children
                  ? `${children.length} Item${children.length !== 1 ? "s" : ""}`
                  : "In this collection"}
              </div>
              <div className="jf-popup__items-grid">
                {!children ? (
                  <div className="jf-dl-loading">
                    <SpinIcon /> Loading items…
                  </div>
                ) : children.length ? (
                  children.map((child, index) => {
                    const childImage = primaryUrl(baseUrl, child, 180);
                    const childTitle = child.Name || "Untitled";
                    return (
                      <button
                        className="jf-collection-card-wrap"
                        type="button"
                        key={child.Id}
                        aria-label={childTitle}
                        style={{ ["--jf-coll-i" as string]: String(Math.min(index, 16)) }}
                        onClick={() => onOpenItem(child)}
                      >
                        <div className="jf-collection-poster">
                          <div className="jf-collection-poster__art">
                            {childImage ? (
                              // eslint-disable-next-line @next/next/no-img-element
                              <img
                                src={childImage}
                                alt={childTitle}
                                loading="lazy"
                                decoding="async"
                                ref={(el) => {
                                  if (el && el.complete && el.naturalWidth > 0) {
                                    el.classList.add("is-loaded");
                                  }
                                }}
                                onLoad={(event) => {
                                  event.currentTarget.classList.add("is-loaded");
                                }}
                                onError={(event) => {
                                  event.currentTarget.classList.add("is-loaded");
                                }}
                              />
                            ) : (
                              <div className="jf-collection-poster__placeholder">
                                <span>{childTitle.charAt(0)}</span>
                              </div>
                            )}
                          </div>
                          <div className="jf-collection-poster__title">{childTitle}</div>
                          <div className="jf-collection-poster__meta">
                            {child.ProductionYear ||
                              (child.Type === "Series" ? "TV Show" : child.Type || "Movie")}
                          </div>
                        </div>
                      </button>
                    );
                  })
                ) : (
                  <div className="jf-dl-empty">{childError || "No items in this collection"}</div>
                )}
              </div>
            </div>
          ) : null}
        </div>
      </div>
      {trailer ? (
        <>
          <div className="jf-trailer-backdrop" onClick={closeTrailer} />
          <div
            className={`jf-trailer-modal${trailerExpanded ? " jf-trailer-modal--expanded" : ""}`}
            role="dialog"
            aria-modal="true"
            aria-label={`${title} trailer`}
          >
            <div className="jf-trailer-modal__card" ref={trailerCardRef}>
              <div className="jf-trailer-modal__head">
                <div>
                  <span>Trailer</span>
                  <strong>{title}</strong>
                </div>
                <button type="button" aria-label="Close trailer" onClick={closeTrailer}>
                  ×
                </button>
              </div>
              <div className="jf-trailer-modal__player">
                {trailer.kind === "local" && trailer.itemId ? (
                  <video
                    src={apiUrl("trailer/stream", {
                      instance: instanceId,
                      itemId: trailer.itemId,
                      server,
                    })}
                    controls
                    controlsList="nofullscreen"
                    autoPlay
                    playsInline
                  />
                ) : trailerEmbed ? (
                  <iframe
                    src={trailerEmbed}
                    title={`${title} trailer`}
                    allow="autoplay; encrypted-media; picture-in-picture; fullscreen"
                    allowFullScreen
                  />
                ) : (
                  <video src={trailer.url} controls controlsList="nofullscreen" autoPlay playsInline />
                )}
                <button
                  type="button"
                  aria-label={trailerExpanded ? "Collapse trailer" : "Expand trailer"}
                  aria-pressed={trailerExpanded}
                  className={`jf-trailer-modal__expand-btn${
                    isUncontrolledEmbed
                      ? " jf-trailer-modal__expand-btn--corner"
                      : trailerEmbed
                        ? " jf-trailer-modal__expand-btn--youtube"
                        : ""
                  }`}
                  onClick={toggleTrailerExpand}
                >
                  {trailerExpanded ? (
                    <svg width="15" height="15" viewBox="0 0 24 24" aria-hidden="true">
                      <path
                        fill="currentColor"
                        d="M9 3v6H3v2h8V3H9zm6 0v8h8V9h-6V3h-2zm-6 12H3v2h6v6h2v-8H5zm10 0v8h2v-6h6v-2h-8z"
                      />
                    </svg>
                  ) : (
                    <svg width="15" height="15" viewBox="0 0 24 24" aria-hidden="true">
                      <path
                        fill="currentColor"
                        d="M3 9V3h6v2H5v4H3zm12-6h6v6h-2V5h-4V3zM3 15h2v4h4v2H3v-6zm16 4v-4h2v6h-6v-2h4z"
                      />
                    </svg>
                  )}
                </button>
              </div>
              {trailer.kind === "remote" && trailer.url ? (
                <div className="jf-trailer-modal__remote-actions">
                  <span>If the owner blocks embedded playback, open the trailer at its source.</span>
                  <a href={trailer.url} target="_blank" rel="noopener noreferrer">
                    <svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true">
                      <path fill="currentColor" d="M8 5v14l11-7z" />
                    </svg>
                    Watch at source
                  </a>
                </div>
              ) : null}
            </div>
          </div>
        </>
      ) : null}
      {demoTrack ? (
        <>
          <div className="jf-demo-backdrop" onClick={() => setDemoTrack(null)} />
          <div
            className="jf-demo-modal"
            role="dialog"
            aria-modal="true"
            aria-label={`${title} music demo`}
          >
            <button
              className="jf-demo-modal__close"
              type="button"
              aria-label="Close music demo"
              onClick={() => setDemoTrack(null)}
            >
              ×
            </button>
            <div className="jf-demo-modal__art">
              {image ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={image} alt="" />
              ) : (
                <span>{title.charAt(0)}</span>
              )}
            </div>
            <div className="jf-demo-modal__info">
              <span className="jf-demo-modal__eyebrow">30-second demo</span>
              <strong>{demoTrack.Name || "Track preview"}</strong>
              <small>{item.AlbumArtist || item.Artists?.[0] || title}</small>
              <audio
                src={apiUrl("demo/stream", {
                  instance: instanceId,
                  itemId: demoTrack.Id,
                  server,
                })}
                controls
                autoPlay
                preload="auto"
                onTimeUpdate={(event) => {
                  if (event.currentTarget.currentTime >= 30) {
                    event.currentTarget.pause();
                    event.currentTarget.currentTime = 30;
                  }
                }}
              />
            </div>
          </div>
        </>
      ) : null}
    </>,
    document.body,
  );
}

function MediaCard({
  item,
  section,
  baseUrl,
  index = 0,
  caseView = false,
  trackRef,
  onSelect,
}: {
  item: Item;
  section?: Section;
  baseUrl: string;
  index?: number;
  caseView?: boolean;
  trackRef?: RefObject<HTMLDivElement | null>;
  onSelect: (item: Item) => void;
}) {
  const isMusic = isMusicItem(item, section);
  const image = primaryUrl(baseUrl, item);
  const title = item.Name || "Untitled";
  const subtitle = cardSubtitle(item, section);
  const [loaded, setLoaded] = useState(false);
  const [openLeft, setOpenLeft] = useState(false);
  const imgRef = useRef<HTMLImageElement>(null);
  const cardRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    setLoaded(false);
    const img = imgRef.current;
    if (img?.complete && img.naturalWidth > 0) setLoaded(true);
  }, [image]);

  // In case view, the cover swings open out of the card's left edge. Near
  // the right wall of the shelf there isn't room for it to open rightward,
  // so flip it to open toward the left instead. Recomputed on hover/focus
  // since it depends on live scroll position, not just layout.
  const checkOpenDirection = useCallback(() => {
    if (!caseView) return;
    const card = cardRef.current;
    const track = trackRef?.current;
    if (!card || !track) return;
    const cardRect = card.getBoundingClientRect();
    const trackRect = track.getBoundingClientRect();
    // The opened cover is roughly 2/3 of the card's height wide (poster
    // aspect ratio 2:3), plus a little breathing room for the pull-out
    // animation and shadow.
    const artWidth = cardRect.height * (2 / 3) + 24;
    const spaceRight = trackRect.right - cardRect.left;
    setOpenLeft(spaceRight < artWidth);
  }, [caseView, trackRef]);

  return (
    <button
      ref={cardRef}
      className={`jf-card${isMusic ? " jf-card--music" : ""}${caseView ? " jf-card--case" : ""}${caseView && openLeft ? " jf-card--open-left" : ""}${loaded || !image ? " is-ready" : ""}`}
      type="button"
      style={{ ["--jf-card-i" as string]: String(Math.min(index, 12)) }}
      onClick={() => onSelect(item)}
      onMouseEnter={checkOpenDirection}
      onFocus={checkOpenDirection}
    >
      {caseView ? (
        <span className={`jf-case-spine${isMusic ? " jf-case-spine--cd" : " jf-case-spine--dvd"}`} aria-hidden="true">
          {image ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img className="jf-case-spine__art" src={image} alt="" loading="lazy" decoding="async" />
          ) : null}
          <span className="jf-case-spine__rail jf-case-spine__rail--top" />
          <span className="jf-case-spine__title">{title}</span>
          <small>{isMusic ? "COMPACT DISC" : item.Type === "Series" ? "TV • DVD" : "DVD"}</small>
          <span className="jf-case-spine__rail jf-case-spine__rail--bottom" />
        </span>
      ) : null}
      <div className={`jf-card__art${loaded ? " is-loaded" : ""}`}>
        {image ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            ref={imgRef}
            className={loaded ? "is-loaded" : ""}
            src={image}
            alt=""
            loading="lazy"
            decoding="async"
            onLoad={() => setLoaded(true)}
            onError={() => setLoaded(true)}
          />
        ) : (
          <div className="jf-card__art-placeholder">{title.charAt(0)}</div>
        )}
        <div className="jf-card__overlay">
          <div className="jf-card__overlay-title">{title}</div>
          <div className="jf-card__overlay-sub">{subtitle}</div>
        </div>
      </div>
      <div className="jf-card__meta">
        <div className="jf-card__title">{title}</div>
        <div className="jf-card__subtitle">{subtitle}</div>
      </div>
    </button>
  );
}

function SliderPanel({
  items,
  section,
  baseUrl,
  loading,
  emptyMessage,
  caseView = false,
  caseViewSpeed = 520,
  musicShelf = false,
  onSelect,
}: {
  items: Item[];
  section?: Section;
  baseUrl: string;
  loading?: boolean;
  emptyMessage?: string;
  caseView?: boolean;
  caseViewSpeed?: number;
  musicShelf?: boolean;
  onSelect: (item: Item) => void;
}) {
  const panelRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const railRef = useRef<HTMLDivElement>(null);
  const thumbRef = useRef<HTMLDivElement>(null);
  const fillRef = useRef<HTMLDivElement>(null);
  const leftBtnRef = useRef<HTMLButtonElement>(null);
  const rightBtnRef = useRef<HTMLButtonElement>(null);
  const sliderRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef(false);
  const rafRef = useRef<number | null>(null);
  const targetScrollRef = useRef(0);

  const updateSlider = useCallback(() => {
    const track = trackRef.current;
    const rail = railRef.current;
    const thumb = thumbRef.current;
    const fill = fillRef.current;
    const leftBtn = leftBtnRef.current;
    const rightBtn = rightBtnRef.current;
    const slider = sliderRef.current;
    if (!track || !rail || !thumb || !fill || !leftBtn || !rightBtn) return;

    const maxScroll = Math.max(0, track.scrollWidth - track.clientWidth);
    const ratio = maxScroll > 0 ? track.scrollLeft / maxScroll : 0;
    const thumbWidth = thumb.offsetWidth || 18;
    const usable = Math.max(0, rail.clientWidth - thumbWidth);
    const leftPx = usable * ratio;
    thumb.style.left = `${leftPx}px`;
    fill.style.width = `${leftPx + thumbWidth / 2}px`;

    const disabled = maxScroll <= 2;
    slider?.classList.toggle("is-disabled", disabled);
    leftBtn.disabled = disabled || track.scrollLeft <= 2;
    rightBtn.disabled = disabled || track.scrollLeft >= maxScroll - 2;
  }, []);

  const stopAnim = useCallback(() => {
    if (rafRef.current) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
  }, []);

  const setTarget = useCallback(
    (value: number, immediate = false) => {
      const track = trackRef.current;
      if (!track) return;
      const maxScroll = Math.max(0, track.scrollWidth - track.clientWidth);
      targetScrollRef.current = clamp(value, 0, maxScroll);
      if (immediate) {
        stopAnim();
        track.scrollLeft = targetScrollRef.current;
        updateSlider();
        return;
      }
      if (!rafRef.current) {
        // Same native "scroll-behavior: smooth" interception as the thumb
        // drag above: without disabling it here, this rAF-driven easing
        // fights the track's own smooth-scroll animation on every frame,
        // producing a jerky, overshooting motion instead of one smooth glide.
        track.classList.add("jf-track--dragging");
        const anim = () => {
          const current = trackRef.current;
          if (!current) {
            rafRef.current = null;
            return;
          }
          const diff = targetScrollRef.current - current.scrollLeft;
          if (Math.abs(diff) < 0.5) {
            current.scrollLeft = targetScrollRef.current;
            updateSlider();
            rafRef.current = null;
            if (!dragRef.current) current.classList.remove("jf-track--dragging");
            return;
          }
          current.scrollLeft += diff * 0.18;
          updateSlider();
          rafRef.current = requestAnimationFrame(anim);
        };
        rafRef.current = requestAnimationFrame(anim);
      }
    },
    [stopAnim, updateSlider],
  );

  const scrollBy = useCallback(
    (delta: number) => {
      const track = trackRef.current;
      if (!track) return;
      setTarget(track.scrollLeft + delta);
    },
    [setTarget],
  );

  useEffect(() => {
    const track = trackRef.current;
    const rail = railRef.current;
    const thumb = thumbRef.current;
    const panel = panelRef.current;
    if (!track || !rail || !thumb || !panel) return;
    let trackPointerId: number | null = null;
    let trackStartX = 0;
    let trackStartY = 0;
    let trackStartScroll = 0;
    let trackMoved = false;
    let suppressClick = false;

    const onScroll = (event: Event) => {
      if ((event.target as HTMLElement)?.classList?.contains("jf-track")) updateSlider();
    };
    const getStep = () => Math.max(220, Math.floor((track.clientWidth || 0) * 0.82));

    const onRailClick = (event: MouseEvent) => {
      if (event.target === thumb) return;
      const rect = rail.getBoundingClientRect();
      const thumbWidth = thumb.offsetWidth || 18;
      const usable = Math.max(0, rect.width - thumbWidth);
      const x = clamp(event.clientX - rect.left - thumbWidth / 2, 0, usable);
      const maxScroll = Math.max(0, track.scrollWidth - track.clientWidth);
      setTarget((usable > 0 ? x / usable : 0) * maxScroll);
    };

    const moveThumb = (clientX: number) => {
      const rect = rail.getBoundingClientRect();
      const thumbWidth = thumb.offsetWidth || 18;
      const usable = Math.max(0, rect.width - thumbWidth);
      const x = clamp(clientX - rect.left - thumbWidth / 2, 0, usable);
      const maxScroll = Math.max(0, track.scrollWidth - track.clientWidth);
      setTarget((usable > 0 ? x / usable : 0) * maxScroll, true);
    };

    const stopDrag = () => {
      dragRef.current = false;
      panel.classList.remove("jf-slider--dragging");
      track.classList.remove("jf-track--dragging");
    };

    const onPointerDown = (event: PointerEvent) => {
      event.preventDefault();
      event.stopPropagation();
      dragRef.current = true;
      stopAnim();
      panel.classList.add("jf-slider--dragging");
      // The track has `scroll-behavior: smooth` for wheel/keyboard scrolling,
      // which otherwise intercepts our direct scrollLeft writes below and
      // animates them with its own easing — fighting the pointer and making
      // the thumb lag/jump instead of tracking the cursor 1:1. Reuse the
      // track's existing "no native smoothing/snap" class while dragging.
      track.classList.add("jf-track--dragging");
      try {
        thumb.setPointerCapture(event.pointerId);
      } catch {
        /* ignore */
      }
    };
    const onPointerMove = (event: PointerEvent) => {
      if (dragRef.current) moveThumb(event.clientX);
    };
    const onPointerUp = (event: PointerEvent) => {
      stopDrag();
      try {
        thumb.releasePointerCapture(event.pointerId);
      } catch {
        /* ignore */
      }
    };
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "ArrowLeft") {
        event.preventDefault();
        scrollBy(-getStep());
      }
      if (event.key === "ArrowRight") {
        event.preventDefault();
        scrollBy(getStep());
      }
    };
    const onTrackPointerDown = (event: PointerEvent) => {
      if (event.pointerType === "mouse" && event.button !== 0) return;
      trackPointerId = event.pointerId;
      trackStartX = event.clientX;
      trackStartY = event.clientY;
      trackStartScroll = track.scrollLeft;
      trackMoved = false;
      suppressClick = false;
      stopAnim();
    };
    const onTrackPointerMove = (event: PointerEvent) => {
      if (trackPointerId !== event.pointerId) return;
      const deltaX = event.clientX - trackStartX;
      const deltaY = event.clientY - trackStartY;
      if (!trackMoved) {
        if (Math.abs(deltaX) < 6) return;
        if (Math.abs(deltaY) > Math.abs(deltaX)) {
          trackPointerId = null;
          return;
        }
        trackMoved = true;
        suppressClick = true;
        track.classList.add("jf-track--dragging");
        try {
          track.setPointerCapture(event.pointerId);
        } catch {
          /* ignore */
        }
      }
      if (!trackMoved) return;
      if (event.cancelable) event.preventDefault();
      event.stopPropagation();
      track.scrollLeft = trackStartScroll - deltaX;
      targetScrollRef.current = track.scrollLeft;
      updateSlider();
    };
    const stopTrackPointer = (event?: PointerEvent) => {
      if (event && trackPointerId !== event.pointerId) return;
      if (event && track.hasPointerCapture(event.pointerId)) {
        try {
          track.releasePointerCapture(event.pointerId);
        } catch {
          /* ignore */
        }
      }
      trackPointerId = null;
      trackMoved = false;
      track.classList.remove("jf-track--dragging");
    };
    const onTrackClick = (event: MouseEvent) => {
      if (!suppressClick) return;
      event.preventDefault();
      event.stopPropagation();
      suppressClick = false;
    };
    const onTrackWheel = (event: WheelEvent) => {
      if (event.ctrlKey) return;
      const maxScroll = Math.max(0, track.scrollWidth - track.clientWidth);
      if (maxScroll <= 2) return;
      const delta =
        Math.abs(event.deltaX) > Math.abs(event.deltaY)
          ? event.deltaX
          : event.deltaY;
      if (!delta) return;
      const atStart = track.scrollLeft <= 1;
      const atEnd = track.scrollLeft >= maxScroll - 1;
      if ((delta < 0 && atStart) || (delta > 0 && atEnd)) return;
      event.preventDefault();
      stopAnim();
      track.scrollLeft = clamp(track.scrollLeft + delta, 0, maxScroll);
      targetScrollRef.current = track.scrollLeft;
      updateSlider();
    };

    panel.addEventListener("scroll", onScroll, { passive: true, capture: true });
    track.addEventListener("pointerdown", onTrackPointerDown);
    track.addEventListener("pointermove", onTrackPointerMove);
    track.addEventListener("pointerup", stopTrackPointer);
    track.addEventListener("pointercancel", stopTrackPointer);
    track.addEventListener("click", onTrackClick, true);
    track.addEventListener("wheel", onTrackWheel, { passive: false });
    rail.addEventListener("click", onRailClick);
    thumb.addEventListener("pointerdown", onPointerDown);
    thumb.addEventListener("pointermove", onPointerMove);
    thumb.addEventListener("pointerup", onPointerUp);
    thumb.addEventListener("pointercancel", stopDrag);
    thumb.addEventListener("keydown", onKeyDown);

    updateSlider();
    return () => {
      panel.removeEventListener("scroll", onScroll, { capture: true });
      track.removeEventListener("pointerdown", onTrackPointerDown);
      track.removeEventListener("pointermove", onTrackPointerMove);
      track.removeEventListener("pointerup", stopTrackPointer);
      track.removeEventListener("pointercancel", stopTrackPointer);
      track.removeEventListener("click", onTrackClick, true);
      track.removeEventListener("wheel", onTrackWheel);
      rail.removeEventListener("click", onRailClick);
      thumb.removeEventListener("pointerdown", onPointerDown);
      thumb.removeEventListener("pointermove", onPointerMove);
      thumb.removeEventListener("pointerup", onPointerUp);
      thumb.removeEventListener("pointercancel", stopDrag);
      thumb.removeEventListener("keydown", onKeyDown);
      stopAnim();
    };
  }, [scrollBy, setTarget, stopAnim, updateSlider, items.length, loading]);

  useEffect(() => {
    updateSlider();
  }, [items, loading, updateSlider]);

  const isMusic =
    section?.itemTypes === "MusicAlbum" || (section?.key || "").toLowerCase().includes("music");

  return (
    <div className="jf-panel-inner" ref={panelRef}>
      <div
        className={`jf-track${caseView ? ` jf-track--case${isMusic ? " jf-track--case-music" : ""}${isMusic && musicShelf ? " jf-track--music-shelves" : ""}` : ""}`}
        ref={trackRef}
        style={caseView ? {
          ["--jf-case-speed" as string]: `${Math.max(150, Math.min(1200, caseViewSpeed))}ms`,
        } : undefined}
      >
        {loading && !items.length
          ? Array.from({ length: 8 }, (_, index) => (
              <div className={`jf-card jf-card--skeleton${isMusic ? " jf-card--music" : ""}`} key={index} />
            ))
          : null}
        {!loading && !items.length ? (
          <div className="jf-empty">{emptyMessage || "No items"}</div>
        ) : null}
        {items.map((item, index) => (
          <MediaCard
            key={item.Id}
            item={item}
            section={section}
            baseUrl={baseUrl}
            index={index}
            caseView={caseView}
            trackRef={trackRef}
            onSelect={onSelect}
          />
        ))}
      </div>
      <div className="jf-slider-wrap">
        <button
          ref={leftBtnRef}
          className="jf-slider__btn jf-slider__btn--left"
          type="button"
          aria-label="Scroll left"
          onClick={() => scrollBy(-Math.max(220, Math.floor((trackRef.current?.clientWidth || 0) * 0.82)))}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M15 18l-6-6 6-6" />
          </svg>
        </button>
        <div className="jf-slider" ref={sliderRef}>
          <div className="jf-slider__rail" ref={railRef}>
            <div className="jf-slider__fill" ref={fillRef} />
            <div
              className="jf-slider__thumb"
              ref={thumbRef}
              tabIndex={0}
              role="slider"
              aria-label="Jellyfin slider"
            />
          </div>
        </div>
        <button
          ref={rightBtnRef}
          className="jf-slider__btn jf-slider__btn--right"
          type="button"
          aria-label="Scroll right"
          onClick={() => scrollBy(Math.max(220, Math.floor((trackRef.current?.clientWidth || 0) * 0.82)))}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M9 18l6-6-6-6" />
          </svg>
        </button>
      </div>
    </div>
  );
}

export default function JellyfinSliderWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "jellyfin-slider";

  const [sections, setSections] = useState<Section[]>([]);
  const [servers, setServers] = useState<ServerEntry[]>([]);
  const [serverIndex, setServerIndex] = useState(0);
  const [active, setActive] = useState("");
  const [items, setItems] = useState<Item[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<Item[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchActive, setSearchActive] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [baseUrl, setBaseUrl] = useState("");
  const [publicUrl, setPublicUrl] = useState("");
  const [openFallbackUrl, setOpenFallbackUrl] = useState("");
  const [selected, setSelected] = useState<Item | null>(null);
  const [caseView, setCaseView] = useState(false);
  const [caseViewSpeed, setCaseViewSpeed] = useState(520);
  const [musicShelf, setMusicShelf] = useState(false);
  const [showSyncMenu, setShowSyncMenu] = useState(false);
  const [refreshToken, setRefreshToken] = useState(0);

  const searchDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastSearchRef = useRef("");
  const syncState = useSyncState(instanceId);
  const wasSyncingRef = useRef(syncState.syncing);

  const activeSection = sections.find((section) => section.key === active);
  const openUrl = useOpenHref(
    servers[serverIndex]?.publicUrl || publicUrl || baseUrl,
    servers[serverIndex]?.openFallbackUrl || openFallbackUrl,
  );
  const mediaBaseUrl = useOpenHref(baseUrl, openFallbackUrl);

  const loadSections = useCallback(
    async (server = serverIndex) => {
      setLoading(true);
      setError("");
      try {
        const response = await fetch(apiUrl("sections", {
          instance: instanceId,
          server,
          caseViewRefresh: Date.now(),
        }), { cache: "no-store" });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Failed to load Jellyfin");
        setSections(data.sections || []);
        setServers(data.servers || []);
        setServerIndex(data.serverIndex ?? server);
        setBaseUrl(data.baseUrl || "");
        setPublicUrl(data.publicUrl || data.baseUrl || "");
        setOpenFallbackUrl(data.openFallbackUrl || "");
        setActive((current) => {
          const keys = (data.sections || []).map((section: Section) => section.key);
          return current && keys.includes(current) ? current : keys[0] || "";
        });
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to load Jellyfin");
      } finally {
        setLoading(false);
      }
    },
    [instanceId, serverIndex],
  );

  useEffect(() => {
    loadSections(0);
  }, [instanceId]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    let alive = true;
    const loadAppearance = () =>
      fetch(`/api/widgets/jellyfin-slider/appearance?instance=${encodeURIComponent(instanceId)}&t=${Date.now()}`, {
        cache: "no-store",
      })
        .then((response) => response.json())
        .then((data) => {
          if (!alive) return;
          if (typeof data.caseView === "boolean") setCaseView(data.caseView);
          if (Number.isFinite(Number(data.caseViewSpeed))) {
            setCaseViewSpeed(Math.max(150, Math.min(1200, Number(data.caseViewSpeed))));
          }
          if (typeof data.musicShelf === "boolean") setMusicShelf(data.musicShelf);
        })
        .catch(() => undefined);
    void loadAppearance();
    const reload = (event: Event) => {
      const detail = (event as CustomEvent<{
        instanceId?: string;
        caseView?: boolean;
        caseViewSpeed?: number;
        musicShelf?: boolean;
      }>).detail;
      if (detail?.instanceId !== instanceId) return;
      if (typeof detail.caseView === "boolean") setCaseView(detail.caseView);
      if (Number.isFinite(Number(detail.caseViewSpeed))) {
        setCaseViewSpeed(Math.max(150, Math.min(1200, Number(detail.caseViewSpeed))));
      }
      if (typeof detail.musicShelf === "boolean") setMusicShelf(detail.musicShelf);
      void loadAppearance();
    };
    window.addEventListener("homedash:widget-config-saved", reload);
    return () => {
      alive = false;
      window.removeEventListener("homedash:widget-config-saved", reload);
    };
  }, [instanceId]);

  useEffect(() => {
    if (!active || searchActive) return;
    let alive = true;
    // Never render one library's items using the newly selected section's
    // layout while its request is still in flight (notably posters as CDs).
    setItems([]);
    setError("");
    setLoading(true);
    fetch(apiUrl("items", { instance: instanceId, section: active, server: serverIndex }))
      .then(async (response) => {
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Failed to load items");
        if (!alive) return;
        setItems(data.items || []);
        setBaseUrl(data.baseUrl || baseUrl);
        setPublicUrl(data.publicUrl || data.baseUrl || publicUrl);
        setOpenFallbackUrl(data.openFallbackUrl || openFallbackUrl);
        setError("");
      })
      .catch((err) => {
        if (alive) setError(err instanceof Error ? err.message : "Failed to load items");
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [active, instanceId, searchActive, serverIndex, refreshToken]); // eslint-disable-line react-hooks/exhaustive-deps

  const runSearch = useCallback(
    async (query: string) => {
      if (!query.trim()) {
        setSearchActive(false);
        setSearchResults([]);
        setSearchLoading(false);
        return;
      }
      setSearchActive(true);
      setSearchLoading(true);
      try {
        const response = await fetch(
          apiUrl("search", { instance: instanceId, q: query.trim(), server: serverIndex }),
        );
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Search failed");
        if (lastSearchRef.current === query.trim()) {
          setSearchResults(data.items || []);
          setBaseUrl(data.baseUrl || baseUrl);
          setPublicUrl(data.publicUrl || data.baseUrl || publicUrl);
          setOpenFallbackUrl(data.openFallbackUrl || openFallbackUrl);
        }
      } catch (err) {
        if (lastSearchRef.current === query.trim()) {
          setSearchResults([]);
          setError(err instanceof Error ? err.message : "Search failed");
        }
      } finally {
        if (lastSearchRef.current === query.trim()) setSearchLoading(false);
      }
    },
    [baseUrl, instanceId, publicUrl, openFallbackUrl, serverIndex],
  );

  const handleSearchChange = (value: string) => {
    setSearchQuery(value);
    if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);
    if (!value.trim()) {
      lastSearchRef.current = "";
      setSearchActive(false);
      setSearchResults([]);
      setSearchLoading(false);
      return;
    }
    searchDebounceRef.current = setTimeout(() => {
      if (value.trim() === lastSearchRef.current) return;
      lastSearchRef.current = value.trim();
      runSearch(value.trim());
    }, 380);
  };

  const clearSearch = () => {
    setSearchQuery("");
    lastSearchRef.current = "";
    setSearchActive(false);
    setSearchResults([]);
    setSearchLoading(false);
    if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);
  };

  // Sync actually runs at module scope (see runSync above) so it isn't
  // interrupted by this component unmounting/remounting when a host
  // dashboard swaps tabs. This effect just watches for a syncing→idle
  // transition on our own instanceId and refreshes the shelf then —
  // whichever component instance happens to be mounted when that
  // happens picks it up, including a freshly remounted one.
  useEffect(() => {
    if (wasSyncingRef.current && !syncState.syncing) {
      void (async () => {
        await loadSections(serverIndex);
        if (searchActive && searchQuery.trim()) {
          await runSearch(searchQuery.trim());
        } else {
          setRefreshToken((token) => token + 1);
        }
      })();
    }
    wasSyncingRef.current = syncState.syncing;
  }, [syncState.syncing, loadSections, serverIndex, searchActive, searchQuery, runSearch]);

  const handleSync = useCallback(
    (onlyKeys?: string[]) => {
      const targets = onlyKeys?.length ? sections.filter((s) => onlyKeys.includes(s.key)) : sections;
      void runSync(instanceId, serverIndex, targets);
    },
    [instanceId, sections, serverIndex],
  );

  const switchServer = async (index: number) => {
    if (index === serverIndex) return;
    setSelected(null);
    clearSearch();
    await loadSections(index);
  };

  if (error && !sections.length) {
    return (
      <div className="hd-widget-body jf-body">
        <div className="jf-error">
          <div className="jf-error__title">Jellyfin Slider</div>
          <div className="jf-error__msg">{error}</div>
          <button className="jf-tab" type="button" onClick={() => loadSections(serverIndex)}>
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <>
    <div className="hd-widget-body jf-body">
      <div
        className="jf-sync-progress"
        data-active={syncState.syncing ? "true" : "false"}
        role="progressbar"
        aria-hidden={!syncState.syncing}
        aria-label={syncState.library ? `Syncing ${syncState.library}` : "Jellyfin sync progress"}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={syncState.syncing ? Math.round(syncState.progress) : undefined}
      >
        <div className="jf-sync-progress__fill" style={{ width: `${syncState.syncing ? syncState.progress : 0}%` }} />
        {syncState.syncing && syncState.library ? (
          <div className="jf-sync-progress__label">Syncing {syncState.library}…</div>
        ) : null}
      </div>

      <div className="jf-toolbar">
        <div className="jf-tabs" role="tablist" aria-label="Jellyfin sections">
          {sections.map((section) => (
            <button
              key={section.key}
              type="button"
              role="tab"
              aria-selected={!searchActive && active === section.key}
              className={`jf-tab${!searchActive && active === section.key ? " jf-tab--active" : ""}`}
              onClick={() => {
                clearSearch();
                setActive(section.key);
              }}
            >
              {section.title}
            </button>
          ))}
        </div>
        <div className="jf-toolbar-right">
          <DownloadStatusIndicator instanceId={instanceId} />
          {servers.length > 1 ? (
            <div className="jf-server-switch">
              {servers.map((entry, index) => (
                <button
                  key={`${entry.label}-${index}`}
                  className={`jf-server-btn${serverIndex === index ? " jf-server-btn--active" : ""}`}
                  type="button"
                  title={`Switch to ${entry.label}`}
                  onClick={() => switchServer(index)}
                >
                  {entry.label}
                </button>
              ))}
            </div>
          ) : null}
          <div className="jf-search-wrap jf-search-wrap--compact">
            <span className="jf-search-icon" aria-hidden="true">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
                <circle cx="11" cy="11" r="8" />
                <path d="M21 21l-4.35-4.35" />
              </svg>
            </span>
            <input
              className={`jf-search-input${searchQuery ? " has-value" : ""}${searchQuery ? " is-open" : ""}`}
              type="search"
              placeholder="Search…"
              autoComplete="off"
              autoCorrect="off"
              spellCheck={false}
              aria-label="Search all media"
              value={searchQuery}
              onChange={(event) => handleSearchChange(event.target.value)}
              onFocus={() => {
                if (searchQuery) return;
              }}
              onKeyDown={(event) => {
                if (event.key === "Escape") {
                  clearSearch();
                  (event.target as HTMLInputElement).blur();
                }
              }}
            />
            <button
              className="jf-search-clear"
              type="button"
              aria-label="Clear search"
              onClick={() => clearSearch()}
            >
              ✕
            </button>
          </div>
          <button
            type="button"
            className="jf-sync-btn"
            onClick={() => setShowSyncMenu(true)}
            disabled={syncState.syncing}
            aria-busy={syncState.syncing}
            aria-haspopup="dialog"
            aria-expanded={showSyncMenu}
            aria-label="Sync libraries"
            title="Sync libraries"
          >
            {syncState.syncing ? (
              <SpinIcon size={13} />
            ) : (
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" aria-hidden="true">
                <line x1="4" y1="6" x2="20" y2="6" />
                <line x1="4" y1="12" x2="20" y2="12" />
                <line x1="4" y1="18" x2="20" y2="18" />
              </svg>
            )}
            Sync
          </button>
          {showSyncMenu ? (
            <SyncMenu
              sections={sections}
              onClose={() => setShowSyncMenu(false)}
              onPick={(keys) => {
                setShowSyncMenu(false);
                void handleSync(keys);
              }}
            />
          ) : null}
          {openUrl ? (
            <a className="jf-open-btn" href={openUrl} target="_blank" rel="noopener noreferrer">
              Open
            </a>
          ) : null}
        </div>
      </div>

      <div className="jf-panels">
        {!searchActive && activeSection ? (
          <div className="jf-panel jf-panel--active" data-panel={activeSection.key}>
            <SliderPanel
              items={items}
              section={activeSection}
              baseUrl={mediaBaseUrl || baseUrl}
              loading={loading}
              emptyMessage={error || "No items in this section"}
              caseView={caseView}
              caseViewSpeed={caseViewSpeed}
              musicShelf={musicShelf}
              onSelect={setSelected}
            />
          </div>
        ) : null}

        {searchActive ? (
          <div className="jf-search-panel jf-search-panel--active">
            {searchLoading ? (
              <div className="jf-track">
                <div className="jf-search-status">
                  <SpinIcon size={14} /> Searching for &quot;{searchQuery}&quot;…
                </div>
              </div>
            ) : (
              <SliderPanel
                items={searchResults}
                baseUrl={mediaBaseUrl || baseUrl}
                loading={searchLoading}
                emptyMessage={searchQuery ? "No results found" : "Search all media"}
                caseView={caseView}
                caseViewSpeed={caseViewSpeed}
                musicShelf={musicShelf}
                onSelect={setSelected}
              />
            )}
          </div>
        ) : null}
      </div>

      {selected ? (
        <ItemPopup
          item={selected}
          kind={popupKindFor(selected, searchActive ? undefined : activeSection)}
          sectionTitle={activeSection?.title || ""}
          baseUrl={mediaBaseUrl || baseUrl}
          publicUrl={openUrl || publicUrl || baseUrl}
          instanceId={instanceId}
          server={serverIndex}
          onClose={() => setSelected(null)}
          onOpenItem={(next) => setSelected(next)}
        />
      ) : null}
    </div>
    <DownloadBlockNotice />
    <DownloadCloseGuard />
    </>
  );
}
