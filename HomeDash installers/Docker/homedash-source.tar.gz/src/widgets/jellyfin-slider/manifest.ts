import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "jellyfin-slider",
  name: "Jellyfin Slider",
  description: "Recently added media carousel with detail popups",
  version: "0.6.7",
  category: "Media",
  hostClass: "jf-slider-host",
  defaultSize: { w: 8, h: 5, minW: 4, minH: 3 },
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "http://10.0.0.1:8096",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      placeholder: "https://jellyfin.example.com",
    },
    {
      key: "publicUrl",
      label: "OPEN - Private URL",
      type: "url",
      placeholder: "http://10.0.0.1:8096",
    },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    { key: "apiKey", label: "API Key", type: "password", required: true },
    {
      key: "userId",
      label: "User ID or Username",
      type: "text",
      placeholder: "Jellyfin username or 32-character user ID",
      required: true,
    },
    { key: "caseView", label: "Case View", type: "checkbox" },
    { key: "musicShelf", label: "Shelf", type: "checkbox" },
  ],
};
