"use client";
import "@/styles/widgets/jellyfin.widget.css";


import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type Library = {
  id: string;
  name: string;
  collectionType: string;
};

type Session = {
  id: string;
  title: string;
  user: string;
  client: string;
  device: string;
  paused: boolean;
  positionTicks: number;
  runTimeTicks: number;
  artUrl: string;
  type: string;
  canMessage?: boolean;
  canControl?: boolean;
};

type Data = {
  href: string;
  openFallbackUrl?: string;
  baseUrl: string;
  sessions: Session[];
  movies: number;
  series: number;
  episodes: number;
  songs: number;
  albums: number;
  libraries: Library[];
  connectionSource?: ConnectionSource;
};

type ConnectionSource = "private" | "public" | "unknown";

const CONNECTION_SOURCE_LABEL: Record<ConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

function ConnectionCorner({ source }: { source: ConnectionSource }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const mark = (
    <div
      className={`jf-corner-source jf-corner-source--${source}`}
      title={CONNECTION_SOURCE_LABEL[source]}
      aria-label={CONNECTION_SOURCE_LABEL[source]}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}

type SyncState = "idle" | "syncing" | "ok" | "err";
type ActionState = { state: "busy" | "ok" | "err"; label: string } | null;
type SyncProgress = { running: boolean; progress: number | null };

function fmtTicks(ticks: number) {
  if (!ticks || ticks < 0) return "0:00";
  const totalSec = Math.floor(ticks / 1e7);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}

function progressPct(pos: number, total: number) {
  if (!total || total <= 0) return 0;
  return Math.min(100, Math.round((pos / total) * 100));
}

function LibGlyph({ type }: { type: string }) {
  const t = (type || "").toLowerCase();
  const common = {
    width: 16,
    height: 16,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.8,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true as const,
  };

  if (t === "movies") {
    return (
      <svg {...common}>
        <rect x="3" y="5" width="18" height="14" rx="2" />
        <path d="M7 5v14M17 5v14M3 9.5h18M3 14.5h18" />
      </svg>
    );
  }
  if (t === "tvshows") {
    return (
      <svg {...common}>
        <rect x="2" y="5" width="20" height="13" rx="2" />
        <path d="M8 21h8M12 18v3" />
      </svg>
    );
  }
  if (t === "music") {
    return (
      <svg {...common}>
        <path d="M9 18V5l12-2v13" />
        <circle cx="6" cy="18" r="3" />
        <circle cx="18" cy="16" r="3" />
      </svg>
    );
  }
  if (t === "books") {
    return (
      <svg {...common}>
        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
      </svg>
    );
  }
  if (t === "photos") {
    return (
      <svg {...common}>
        <rect x="3" y="5" width="18" height="14" rx="2" />
        <circle cx="9" cy="10" r="1.6" />
        <path d="M21 15l-5-5-8 8" />
      </svg>
    );
  }
  return (
    <svg {...common}>
      <path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
    </svg>
  );
}

function syncIcon(state: SyncState) {
  if (state === "syncing") return <span className="jf-sync-spin">↻</span>;
  if (state === "ok") return "✓";
  if (state === "err") return "✗";
  return "↻";
}

function syncBtnClass(state: SyncState) {
  if (state === "syncing") return "jf-sync-btn jf-sync-btn--busy";
  if (state === "ok") return "jf-sync-btn jf-sync-btn--ok";
  if (state === "err") return "jf-sync-btn jf-sync-btn--err";
  return "jf-sync-btn";
}

function SessionArt({
  artUrl,
  title,
  user,
}: {
  artUrl: string;
  title: string;
  user: string;
}) {
  const [broken, setBroken] = useState(false);
  if (!artUrl || broken) {
    return (
      <div className="jf-avatar-placeholder">{(user || "?").charAt(0).toUpperCase()}</div>
    );
  }
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      className="jf-avatar jf-avatar--art"
      src={artUrl}
      alt={title}
      onError={() => setBroken(true)}
    />
  );
}

export default function JfMonitorWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "jf-monitor";
  const [data, setData] = useState<Data | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);
  const [groupOpen, setGroupOpen] = useState(false);
  const [groupDraft, setGroupDraft] = useState("");
  const [groupState, setGroupState] = useState<ActionState>(null);
  const [syncState, setSyncState] = useState<Record<string, SyncState>>({});
  const [syncProgress, setSyncProgress] = useState<SyncProgress | null>(null);
  const [syncMenuOpen, setSyncMenuOpen] = useState(false);
  const [messageOpen, setMessageOpen] = useState<Record<string, boolean>>({});
  const [messageDrafts, setMessageDrafts] = useState<Record<string, string>>({});
  const [actionState, setActionState] = useState<Record<string, ActionState>>({});
  const [pausedOverride, setPausedOverride] = useState<Record<string, boolean>>({});

  const load = useCallback(async () => {
    try {
      const response = await fetch(
        `/api/widgets/jf-monitor/status?instance=${encodeURIComponent(instanceId)}`,
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load Jellyfin");
      setData(json);
      setError("");
      setPausedOverride({});
    } catch (err) {
      setError(err instanceof Error ? err.message : "Jellyfin unavailable");
    } finally {
      setLoading(false);
    }
  }, [instanceId]);

  const pollMs = error ? 8_000 : (data?.sessions.length || 0) > 0 ? 10_000 : 30_000;
  const { rootRef } = useWidgetPoll(load, { intervalMs: pollMs });

  async function postAction(body: Record<string, unknown>) {
    const response = await fetch("/api/widgets/jf-monitor/action", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ instance: instanceId, ...body }),
    });
    const json = await response.json();
    if (!response.ok) throw new Error(json.error || "Action failed");
    return json;
  }

  function clearActionLater(sessionId: string, delay = 2500) {
    window.setTimeout(() => {
      setActionState((prev) => {
        const next = { ...prev };
        delete next[sessionId];
        return next;
      });
    }, delay);
  }

  async function runSyncAll() {
    setSyncProgress(null);
    setSyncState((prev) => {
      const next: Record<string, SyncState> = { ...prev, __all__: "syncing" };
      for (const lib of data?.libraries || []) next[lib.id] = "syncing";
      return next;
    });
    try {
      await postAction({ action: "sync-all" });
      setSyncState((prev) => {
        const next: Record<string, SyncState> = { ...prev, __all__: "ok" };
        for (const lib of data?.libraries || []) next[lib.id] = "ok";
        return next;
      });
      await load();
    } catch {
      setSyncState((prev) => {
        const next: Record<string, SyncState> = { ...prev, __all__: "err" };
        for (const lib of data?.libraries || []) next[lib.id] = "err";
        return next;
      });
    }
    window.setTimeout(() => {
      setSyncState((prev) => {
        const next: Record<string, SyncState> = { ...prev, __all__: "idle" };
        for (const lib of data?.libraries || []) next[lib.id] = "idle";
        return next;
      });
      setSyncProgress(null);
    }, 4000);
  }

  async function runSyncLibrary(libraryId: string) {
    setSyncProgress(null);
    setSyncState((prev) => ({ ...prev, [libraryId]: "syncing" }));
    try {
      await postAction({ action: "sync-library", libraryId });
      setSyncState((prev) => ({ ...prev, [libraryId]: "ok" }));
      await load();
    } catch {
      setSyncState((prev) => ({ ...prev, [libraryId]: "err" }));
    }
    window.setTimeout(() => {
      setSyncState((prev) => ({ ...prev, [libraryId]: "idle" }));
      setSyncProgress(null);
    }, 4000);
  }

  async function runSessionCommand(sessionId: string, command: "pause" | "unpause" | "stop") {
    if (command === "pause") setPausedOverride((prev) => ({ ...prev, [sessionId]: true }));
    if (command === "unpause") setPausedOverride((prev) => ({ ...prev, [sessionId]: false }));

    setActionState((prev) => ({
      ...prev,
      [sessionId]: {
        state: "busy",
        label: command === "pause" ? "Pausing…" : command === "unpause" ? "Resuming…" : "Stopping…",
      },
    }));

    try {
      await postAction({ action: "session-command", sessionId, command });
      setActionState((prev) => ({
        ...prev,
        [sessionId]: {
          state: "ok",
          label: command === "pause" ? "Paused" : command === "unpause" ? "Resumed" : "Stopped",
        },
      }));
      clearActionLater(sessionId);
      await load();
      setPausedOverride((prev) => {
        const next = { ...prev };
        delete next[sessionId];
        return next;
      });
    } catch (err) {
      setPausedOverride((prev) => {
        const next = { ...prev };
        delete next[sessionId];
        return next;
      });
      setActionState((prev) => ({
        ...prev,
        [sessionId]: {
          state: "err",
          label: err instanceof Error ? err.message : "Failed",
        },
      }));
      clearActionLater(sessionId, 4000);
    }
  }

  async function sendSessionMessage(sessionId: string) {
    const text = (messageDrafts[sessionId] || "").trim();
    if (!text) {
      setActionState((prev) => ({
        ...prev,
        [sessionId]: { state: "err", label: "Message required" },
      }));
      clearActionLater(sessionId);
      return;
    }
    setActionState((prev) => ({ ...prev, [sessionId]: { state: "busy", label: "Sending…" } }));
    try {
      await postAction({ action: "session-message", sessionId, text });
      setMessageDrafts((prev) => ({ ...prev, [sessionId]: "" }));
      setMessageOpen((prev) => ({ ...prev, [sessionId]: false }));
      setActionState((prev) => ({
        ...prev,
        [sessionId]: { state: "ok", label: "Message sent" },
      }));
      clearActionLater(sessionId);
    } catch (err) {
      setActionState((prev) => ({
        ...prev,
        [sessionId]: {
          state: "err",
          label: err instanceof Error ? err.message : "Send failed",
        },
      }));
      clearActionLater(sessionId, 4000);
    }
  }

  async function sendGroupMessage() {
    const text = groupDraft.trim();
    if (!text) {
      setGroupState({ state: "err", label: "Message required" });
      window.setTimeout(() => setGroupState(null), 2500);
      return;
    }
    const messageable = (data?.sessions || []).filter((session) => session.canMessage);
    const skipped = (data?.sessions || []).length - messageable.length;
    if (!data?.sessions.length) {
      setGroupState({ state: "err", label: "No active sessions" });
      window.setTimeout(() => setGroupState(null), 2500);
      return;
    }
    if (!messageable.length) {
      setGroupState({
        state: "err",
        label: "No clients support on-screen messages",
      });
      window.setTimeout(() => setGroupState(null), 4000);
      return;
    }
    setGroupState({
      state: "busy",
      label: skipped
        ? `Sending to ${messageable.length} (skip ${skipped})…`
        : `Sending to ${messageable.length}…`,
    });
    try {
      const result = await postAction({ action: "group-message", text });
      const skipN = Array.isArray(result.skipped) ? result.skipped.length : skipped;
      if (result.ok) {
        setGroupDraft("");
        setGroupOpen(false);
        setGroupState({
          state: "ok",
          label: skipN
            ? `Sent ${result.sent}/${result.total} · skipped ${skipN}`
            : `Sent to ${result.sent}/${result.total}`,
        });
      } else {
        setGroupState({
          state: "err",
          label: skipN
            ? `${result.sent}/${result.total} sent · skipped ${skipN}`
            : `${result.sent}/${result.total} sent`,
        });
      }
    } catch (err) {
      setGroupState({
        state: "err",
        label: err instanceof Error ? err.message : "Send failed",
      });
    }
    window.setTimeout(() => setGroupState(null), 4500);
  }

  const pills = useMemo(() => {
    if (!data) return [];
    return [
      { label: "Movies", value: data.movies },
      { label: "Series", value: data.series },
      { label: "Episodes", value: data.episodes },
      { label: "Songs", value: data.songs },
      { label: "Albums", value: data.albums },
      { label: "Libraries", value: data.libraries.length },
    ].filter((pill) => pill.value > 0);
  }, [data]);

  const sessions = data?.sessions || [];
  const messageableSessions = sessions.filter((session) => session.canMessage);
  const allSync = syncState.__all__ || "idle";
  const groupBusy = groupState?.state === "busy";

  // Whichever sync is currently active (Sync All or a single library) drives
  // the toolbar progress bar — prefer Sync All's state, otherwise fall back
  // to any individual library still mid-sync/settling.
  const syncBarState: SyncState =
    allSync !== "idle"
      ? allSync
      : ((Object.values(syncState).find((state) => state && state !== "idle") as
          | SyncState
          | undefined) ?? "idle");

  useEffect(() => {
    if (syncBarState !== "syncing") return;
    let cancelled = false;
    const poll = async () => {
      try {
        const response = await fetch(
          `/api/widgets/jf-monitor/sync-progress?instance=${encodeURIComponent(instanceId)}`,
        );
        const json = await response.json();
        if (!cancelled && response.ok) setSyncProgress(json);
      } catch {
        // Ignore transient poll failures — the sync buttons' own busy/ok/err
        // state (set from the action call itself) still reflects the outcome.
      }
    };
    poll();
    const id = window.setInterval(poll, 1500);
    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
  }, [syncBarState, instanceId]);

  if (loading && !data) {
    return (
      <div className="hd-widget-body jf-body" ref={rootRef}>
        <div className="jf-toolbar">
          <span className="jf-status-pill jf-status-pill--loading">
            <span className="jf-status-dot" />
            Loading
          </span>
        </div>
        <div className="jf-skeleton-row" />
        <div className="jf-skeleton-row" style={{ animationDelay: "0.1s" }} />
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="hd-widget-body jf-body" ref={rootRef}>
        <div className="jf-toolbar">
          <span className="jf-status-pill jf-status-pill--offline">
            <span className="jf-status-dot" />
            Offline
          </span>
        </div>
        <div className="jf-error">⚠ {error}</div>
        <button className="jf-action-btn jf-action-btn--ghost" type="button" onClick={load}>
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="hd-widget-body jf-body" ref={rootRef}>
      <ConnectionCorner source={data?.connectionSource || "unknown"} />
      <div className="jf-toolbar">
        <div className="jf-toolbar-left">
          <span className="jf-status-pill jf-status-pill--online">
            <span className="jf-status-dot" />
            Online
          </span>
          {sessions.length > 0 ? (
            <span className="jf-stat-pill jf-stat-pill--compact">
              <span className="jf-stat-value">{sessions.length}</span>
              {sessions.length === 1 ? "stream" : "streams"}
            </span>
          ) : null}
        </div>
        <div className="jf-toolbar-right">
          <button
            className={`jf-sync-menu-toggle${syncMenuOpen ? " jf-sync-menu-toggle--open" : ""}`}
            type="button"
            aria-expanded={syncMenuOpen}
            aria-controls={`jf-sync-menu-${instanceId}`}
            title="Library sync"
            onClick={() => setSyncMenuOpen((open) => !open)}
          >
            <span className="jf-sync-menu-toggle__icon" aria-hidden>☰</span>
            <span className="jf-sync-menu-toggle__label">Sync</span>
          </button>

          {syncMenuOpen ? (
            <button
              type="button"
              className="jf-sync-popup-backdrop"
              aria-label="Close library sync menu"
              onClick={() => setSyncMenuOpen(false)}
            />
          ) : null}

          <div
            className={`jf-mobile-sync-panel${syncMenuOpen ? " jf-mobile-sync-panel--open" : ""}`}
            id={`jf-sync-menu-${instanceId}`}
            aria-hidden={!syncMenuOpen}
          >
            <div className="jf-mobile-sync-panel__head">
              <div>
                <span className="jf-mobile-sync-panel__eyebrow">Library controls</span>
                <strong>Sync libraries</strong>
              </div>
              <div className="jf-mobile-sync-panel__actions">
                <button
                  className={`${syncBtnClass(allSync)} jf-sync-all-btn`}
                  type="button"
                  disabled={allSync === "syncing"}
                  onClick={runSyncAll}
                >
                  {syncIcon(allSync)} Sync All
                </button>
                <button
                  className="jf-mobile-sync-panel__close"
                  type="button"
                  aria-label="Close library sync menu"
                  onClick={() => setSyncMenuOpen(false)}
                >
                  ×
                </button>
              </div>
            </div>
            <div className="jf-mobile-sync-panel__list">
              {(data?.libraries || []).map((lib) => {
                const state = syncState[lib.id] || "idle";
                return (
                  <div className="jf-lib-row" key={`popup-${lib.id || lib.name}`}>
                    <span className="jf-lib-row-icon" aria-hidden>
                      <LibGlyph type={lib.collectionType} />
                    </span>
                    <span className="jf-lib-row-name" title={lib.name}>
                      {lib.name}
                    </span>
                    <button
                      className={`${syncBtnClass(state)} jf-lib-row-sync`}
                      type="button"
                      disabled={!lib.id || state === "syncing"}
                      title={`Scan ${lib.name}`}
                      aria-label={`Sync ${lib.name}`}
                      onClick={() => lib.id && runSyncLibrary(lib.id)}
                    >
                      {syncIcon(state)}
                    </button>
                  </div>
                );
              })}
              {!data?.libraries?.length ? (
                <div className="jf-idle jf-idle--compact">No libraries</div>
              ) : null}
            </div>
          </div>

          {syncBarState !== "idle" ? (
            <div
              className={`jf-sync-progress jf-sync-progress--${syncBarState}${
                syncBarState === "syncing" && syncProgress?.progress == null
                  ? " jf-sync-progress--indeterminate"
                  : ""
              }`}
              role="status"
              aria-live="polite"
            >
              <span className="jf-sync-progress-track">
                <span
                  className="jf-sync-progress-fill"
                  style={
                    syncBarState === "syncing" && syncProgress?.progress != null
                      ? { width: `${syncProgress.progress}%` }
                      : undefined
                  }
                />
              </span>
              <span className="jf-sync-progress-label">
                {syncBarState === "syncing"
                  ? syncProgress?.progress != null
                    ? `Syncing ${syncProgress.progress}%`
                    : "Syncing…"
                  : syncBarState === "ok"
                    ? "Synced"
                    : "Sync failed"}
              </span>
            </div>
          ) : null}
          {sessions.length > 0 ? (
            <button
              className={`jf-group-toggle${groupOpen ? " jf-group-toggle--open" : ""}`}
              type="button"
              disabled={groupBusy || messageableSessions.length === 0}
              title={
                messageableSessions.length === 0
                  ? "No active clients support on-screen messages (Roku and some TV apps cannot show them)"
                  : messageableSessions.length < sessions.length
                    ? `Message ${messageableSessions.length} of ${sessions.length} sessions that support DisplayMessage`
                    : "Message all active sessions"
              }
              onClick={() => setGroupOpen((open) => !open)}
            >
              Group Message
            </button>
          ) : null}
          {openHref ? (
            <a className="jf-open-link" href={openHref} target="_blank" rel="noopener noreferrer">
              Open
            </a>
          ) : null}
        </div>
      </div>

      {pills.length ? (
        <div className="jf-stats">
          {pills.map((pill) => (
            <span className="jf-stat-pill" key={pill.label}>
              <span className="jf-stat-value">{pill.value.toLocaleString()}</span>
              {pill.label}
            </span>
          ))}
        </div>
      ) : null}

      {groupOpen && messageableSessions.length > 0 ? (
        <div className="jf-group-message">
          <div className="jf-group-message-top">
            <span className="jf-section-label" style={{ padding: 0 }}>
              Group Message
            </span>
            <span className="jf-group-message-target">
              {messageableSessions.length < sessions.length
                ? `Send to ${messageableSessions.length} of ${sessions.length} sessions · Roku/unsupported TV apps are skipped`
                : `Send to ${messageableSessions.length} active ${messageableSessions.length === 1 ? "session" : "sessions"}`}
            </span>
          </div>
          <div className="jf-message-box">
            <textarea
              className="jf-message-input"
              rows={2}
              maxLength={300}
              placeholder="Broadcast a message to all active Jellyfin sessions..."
              value={groupDraft}
              onChange={(event) => setGroupDraft(event.target.value)}
            />
            <div className="jf-message-actions">
              <div className="jf-message-actions-left">
                <span className="jf-message-count">{groupDraft.length}/300</span>
                {groupState ? (
                  <span className={`jf-action-status jf-action-status--${groupState.state}`}>
                    {groupState.label}
                  </span>
                ) : null}
              </div>
              <div className="jf-message-actions-right">
                <button
                  className="jf-action-btn jf-action-btn--ghost"
                  type="button"
                  disabled={groupBusy}
                  onClick={() => setGroupOpen(false)}
                >
                  Cancel
                </button>
                <button
                  className="jf-action-btn jf-action-btn--send"
                  type="button"
                  disabled={groupBusy}
                  onClick={sendGroupMessage}
                >
                  Send to All
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : null}

      <div className="jf-main-split">
        <section className="jf-main-col jf-main-col--sessions" aria-label="Now playing">
          <div className="jf-section-label">Now Playing</div>
          {sessions.length ? (
            <div className="jf-sessions">
              {sessions.map((session) => {
                const paused =
                  typeof pausedOverride[session.id] === "boolean"
                    ? pausedOverride[session.id]
                    : session.paused;
                const busy = actionState[session.id]?.state === "busy";
                const msgOpen = !!messageOpen[session.id];
                const draft = messageDrafts[session.id] || "";
                const action = actionState[session.id];
                const pct = progressPct(session.positionTicks, session.runTimeTicks);
                const canMessage = !!session.canMessage;

                return (
                  <div className="jf-session" key={session.id}>
                    <SessionArt artUrl={session.artUrl} title={session.title} user={session.user} />
                    <div className="jf-session-body">
                      <div className="jf-session-top">
                        <span className="jf-session-title" title={session.title}>
                          {session.title}
                        </span>
                        <span
                          className={`jf-state-badge ${paused ? "jf-state--paused" : "jf-state--playing"}`}
                        >
                          {paused ? "PAUSED" : "PLAYING"}
                        </span>
                      </div>
                      <div className="jf-session-meta">
                        <span className="jf-session-user">{session.user}</span>
                        {[session.client, session.device].filter(Boolean).length
                          ? ` · ${[session.client, session.device].filter(Boolean).join(" · ")}`
                          : ""}
                        {!canMessage ? (
                          <span className="jf-session-msg-hint" title="This client cannot show server messages">
                            {" "}
                            · no messages
                          </span>
                        ) : null}
                      </div>
                      {session.runTimeTicks > 0 ? (
                        <div className="jf-progress-wrap">
                          <div className="jf-progress-bar">
                            <div className="jf-progress-fill" style={{ width: `${pct}%` }} />
                          </div>
                          <span className="jf-progress-time">
                            {fmtTicks(session.positionTicks)} / {fmtTicks(session.runTimeTicks)}
                          </span>
                        </div>
                      ) : null}
                      <div className="jf-session-actions">
                        <div className="jf-session-actions-row">
                          {paused ? (
                            <button
                              className="jf-action-btn jf-action-btn--resume"
                              type="button"
                              disabled={busy}
                              onClick={() => runSessionCommand(session.id, "unpause")}
                            >
                              Resume
                            </button>
                          ) : (
                            <button
                              className="jf-action-btn jf-action-btn--pause"
                              type="button"
                              disabled={busy}
                              onClick={() => runSessionCommand(session.id, "pause")}
                            >
                              Pause
                            </button>
                          )}
                          <button
                            className="jf-action-btn jf-action-btn--stop"
                            type="button"
                            disabled={busy}
                            onClick={() => runSessionCommand(session.id, "stop")}
                          >
                            Stop
                          </button>
                          <button
                            className="jf-action-btn jf-action-btn--message"
                            type="button"
                            disabled={busy || !canMessage}
                            title={
                              canMessage
                                ? `Send a message to ${session.user}`
                                : `${session.client || "This client"} does not support on-screen messages`
                            }
                            onClick={() =>
                              setMessageOpen((prev) => ({
                                ...prev,
                                [session.id]: !prev[session.id],
                              }))
                            }
                          >
                            {msgOpen ? "Close Message" : "Message"}
                          </button>
                          {action ? (
                            <span className={`jf-action-status jf-action-status--${action.state}`}>
                              {action.label}
                            </span>
                          ) : null}
                        </div>
                        {msgOpen ? (
                          <div className="jf-message-box">
                            <textarea
                              className="jf-message-input"
                              rows={2}
                              maxLength={300}
                              placeholder={`Send a message to ${session.user}...`}
                              value={draft}
                              onChange={(event) =>
                                setMessageDrafts((prev) => ({
                                  ...prev,
                                  [session.id]: event.target.value,
                                }))
                              }
                            />
                            <div className="jf-message-actions">
                              <span className="jf-message-count">{draft.length}/300</span>
                              <button
                                className="jf-action-btn jf-action-btn--send"
                                type="button"
                                disabled={busy}
                                onClick={() => sendSessionMessage(session.id)}
                              >
                                Send
                              </button>
                            </div>
                          </div>
                        ) : null}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="jf-idle">No active streams</div>
          )}
        </section>

        <aside className="jf-main-col jf-main-col--libs" aria-label="Library sync">
          <div className="jf-libs-header">
            <span className="jf-section-label" style={{ padding: 0 }}>
              Libraries
            </span>
            <button
              className={`${syncBtnClass(allSync)} jf-sync-all-btn`}
              type="button"
              disabled={allSync === "syncing"}
              onClick={runSyncAll}
            >
              {syncIcon(allSync)} Sync All
            </button>
          </div>
          <div className="jf-lib-list">
            {(data?.libraries || []).map((lib) => {
              const state = syncState[lib.id] || "idle";
              return (
                <div className="jf-lib-row" key={lib.id || lib.name}>
                  <span className="jf-lib-row-icon" aria-hidden>
                    <LibGlyph type={lib.collectionType} />
                  </span>
                  <span className="jf-lib-row-name" title={lib.name}>
                    {lib.name}
                  </span>
                  <button
                    className={`${syncBtnClass(state)} jf-lib-row-sync`}
                    type="button"
                    disabled={!lib.id || state === "syncing"}
                    title={`Scan ${lib.name}`}
                    aria-label={`Sync ${lib.name}`}
                    onClick={() => lib.id && runSyncLibrary(lib.id)}
                  >
                    {syncIcon(state)}
                  </button>
                </div>
              );
            })}
            {!data?.libraries?.length ? (
              <div className="jf-idle jf-idle--compact">No libraries</div>
            ) : null}
          </div>
        </aside>
      </div>
    </div>
  );
}
