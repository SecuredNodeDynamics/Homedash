import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "jf-monitor",
  name: "Jellyfin",
  description: "Active sessions, library counts, live sync progress, and messaging",
  version: "0.3.0",
  category: "Media",
  hostClass: "jf-monitor-host",
  defaultSize: { w: 5, h: 4, minW: 3, minH: 3 },
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "http://10.0.0.1:8096",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      placeholder: "https://jellyfin.example.com",
    },
    {
      key: "publicUrl",
      label: "OPEN - Private URL",
      type: "url",
      placeholder: "http://10.0.0.1:8096",
    },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    { key: "apiKey", label: "API Key", type: "password", required: true },
    {
      key: "messageSender",
      label: "Message Sender Name",
      type: "text",
      placeholder: "Leave blank to auto-use the Jellyfin admin username",
    },
  ],
};
