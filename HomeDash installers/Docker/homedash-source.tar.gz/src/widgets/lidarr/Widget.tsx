"use client";
import "@/styles/widgets/lidarr.widget.css";
import "@/styles/widgets/arr.widgets.css";


import ArrOverviewWidget from "@/widgets/_shared/ArrOverviewWidget";

export default function LidarrWidget() {
  return (
    <ArrOverviewWidget
      apiId="lidarr"
      fallbackId="lidarr"
      accentClass="arr-widget--lidarr"
      mapData={(data) => ({
        href: String(data.href || ""),
        stats: [
          { label: "Artists", value: Number(data.artists || 0) },
          { label: "Albums", value: Number(data.albums || 0) },
          { label: "Tracks", value: Number(data.tracks || 0) },
          { label: "Queued", value: Number(data.queued || 0), tone: "active" },
        ],
        summary: Array.isArray(data.upcoming)
          ? (data.upcoming as Array<{ title?: string; artist?: string }>)
              .slice(0, 3)
              .map((item) => [item.artist, item.title].filter(Boolean).join(" — "))
              .filter(Boolean)
          : [],
      })}
    />
  );
}
