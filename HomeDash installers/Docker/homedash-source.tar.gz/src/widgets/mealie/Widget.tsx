"use client";
import "@/styles/widgets/mealie.widget.css";


import { useCallback, useState, useLayoutEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type Recipe = {
  id: string;
  name: string;
  description: string;
  slug: string;
  imageUrl: string;
  href: string;
  openFallbackUrl?: string;
};

type Plan = {
  id: string;
  name: string;
  type: string;
  date: string;
  imageUrl: string;
};

type ShoppingList = {
  name: string;
  itemCount: number;
};

type MlConnectionSource = "private" | "public" | "unknown";

const CONNECTION_SOURCE_LABEL: Record<MlConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

function ConnectionCorner({ source }: { source: MlConnectionSource }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const mark = (
    <div
      className={`ml-corner-source ml-corner-source--${source}`}
      title={CONNECTION_SOURCE_LABEL[source]}
      aria-label={CONNECTION_SOURCE_LABEL[source]}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}


type Data = {
  href: string;
  openFallbackUrl?: string;
  connectionSource?: MlConnectionSource;
  about: { version: string };
  recipeTotal: number;
  todayCount?: number;
  plannedCount?: number;
  recipes: Recipe[];
  todayPlans: Plan[];
  upcomingPlans: Plan[];
  shoppingLists: ShoppingList[];
};

type TabKey = "overview" | "recipes" | "plan" | "shopping";

const POLL_MS = 5 * 60 * 1000;

const TABS: { key: TabKey; label: string }[] = [
  { key: "overview", label: "Overview" },
  { key: "recipes", label: "Recipes" },
  { key: "plan", label: "Meal Plan" },
  { key: "shopping", label: "Shopping" },
];

function fmtInt(value: number) {
  return Number(value || 0).toLocaleString();
}

function shortDate(value?: string) {
  if (!value) return "";
  const d = new Date(`${String(value).slice(0, 10)}T12:00:00`);
  if (Number.isNaN(d.getTime())) return String(value).slice(0, 10);
  return d.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
}

function RecipeImage({
  src,
  className,
  fallbackClassName,
  fallback,
}: {
  src?: string;
  className: string;
  fallbackClassName: string;
  fallback: string;
}) {
  const [broken, setBroken] = useState(false);
  if (!src || broken) return <div className={fallbackClassName}>{fallback}</div>;
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img className={className} src={src} alt="" loading="lazy" decoding="async" onError={() => setBroken(true)} />
  );
}

function StatsStrip({
  recipes,
  today,
  planned,
  lists,
}: {
  recipes: number;
  today: number;
  planned: number;
  lists: number;
}) {
  return (
    <div className="ml-stats ml-stats--strip">
      <div className="ml-stat">
        <span>{fmtInt(recipes)}</span>
        <small>Recipes</small>
      </div>
      <div className="ml-stat">
        <span>{fmtInt(today)}</span>
        <small>Today</small>
      </div>
      <div className="ml-stat">
        <span>{fmtInt(planned)}</span>
        <small>Planned</small>
      </div>
      <div className="ml-stat">
        <span>{fmtInt(lists)}</span>
        <small>Lists</small>
      </div>
    </div>
  );
}

function TodayCard({ plan }: { plan: Plan }) {
  return (
    <div className="ml-today-card">
      <RecipeImage
        src={plan.imageUrl}
        className="ml-meal-image"
        fallbackClassName="ml-meal-icon"
        fallback="🍽"
      />
      <div className="ml-today-main">
        <div className="ml-meal-name">{plan.name}</div>
        <div className="ml-meal-meta">{plan.type}</div>
      </div>
    </div>
  );
}

function RecipeCard({ recipe, href }: { recipe: Recipe; href: string }) {
  const openHref = useOpenHref(recipe.href || href, recipe.openFallbackUrl);
  return (
    <a
      className="ml-recipe"
      href={openHref}
      target="_blank"
      rel="noopener noreferrer"
    >
      <RecipeImage
        src={recipe.imageUrl}
        className="ml-recipe-image"
        fallbackClassName="ml-recipe-fallback"
        fallback="🍲"
      />
      <span>{recipe.name}</span>
      <small>Open recipe</small>
    </a>
  );
}

export default function MealieWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "mealie";
  const [data, setData] = useState<Data | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<TabKey>("overview");
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);

  const load = useCallback(
    async (opts?: { soft?: boolean }) => {
      if (!opts?.soft) setLoading(true);
      try {
        const response = await fetch(
          `/api/widgets/mealie/status?instance=${encodeURIComponent(instanceId)}`,
        );
        const json = await response.json();
        if (!response.ok) throw new Error(json.error || "Failed to load Mealie");
        setData(json);
        setError("");
      } catch (cause) {
        if (!opts?.soft) {
          setError(cause instanceof Error ? cause.message : "Failed to load Mealie");
        }
      } finally {
        if (!opts?.soft) setLoading(false);
      }
    },
    [instanceId],
  );

  const { rootRef } = useWidgetPoll(load, { intervalMs: POLL_MS });

  if (loading && !data) {
    return (
      <div className="hd-widget-body ml-body-flat" ref={rootRef}>
        <div className="ml-shell">
          <div className="ml-empty">Loading Mealie…</div>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="hd-widget-body ml-body-flat" ref={rootRef}>
        <div className="ml-shell">
          <div className="ml-toolbar">
            <div className="ml-toolbar-left">
              <span className="ml-status-pill ml-status-pill--warn">
                <span className="ml-status-dot" aria-hidden="true" />
                Offline
              </span>
            </div>
            <div className="ml-toolbar-right">
              <button className="ml-open-link" type="button" onClick={() => void load()}>
                Retry
              </button>
            </div>
          </div>
          <div className="ml-empty ml-empty--error">{error || "Failed to load Mealie"}</div>
        </div>
      </div>
    );
  }

  const live = data;
  const isOnline =
    Boolean(live.href || live.recipes.length || live.shoppingLists.length || live.upcomingPlans.length) &&
    !error;

  function renderPanel() {
    if (tab === "overview") {
      return (
        <div className="ml-overview">
          <StatsStrip
            recipes={live.recipeTotal}
            today={live.todayCount ?? live.todayPlans.length}
            planned={live.plannedCount ?? live.upcomingPlans.length}
            lists={live.shoppingLists.length}
          />
          <div className="ml-overview-block">
            <div className="ml-block-label">Today</div>
            {live.todayPlans.length ? (
              <div className="ml-today-list ml-list-flat">
                {live.todayPlans.slice(0, 2).map((plan, index) => (
                  <TodayCard key={`${plan.id}-${index}`} plan={plan} />
                ))}
              </div>
            ) : (
              <div className="ml-empty ml-empty--soft">No meals planned today</div>
            )}
          </div>
          <div className="ml-overview-block">
            <div className="ml-block-label">Recipes</div>
            {live.recipes.length ? (
              <div className="ml-recipes">
                {live.recipes.slice(0, 3).map((recipe) => (
                  <RecipeCard key={recipe.id || recipe.slug} recipe={recipe} href={live.href} />
                ))}
              </div>
            ) : (
              <div className="ml-empty ml-empty--soft">No recipe data</div>
            )}
          </div>
        </div>
      );
    }

    if (tab === "recipes") {
      if (!live.recipes.length) {
        return <div className="ml-empty">No recipe data</div>;
      }
      return (
        <div className="ml-recipes">
          {live.recipes.map((recipe) => (
            <RecipeCard key={recipe.id || recipe.slug} recipe={recipe} href={live.href} />
          ))}
        </div>
      );
    }

    if (tab === "plan") {
      return (
        <div className="ml-plan">
          <div className="ml-overview-block">
            <div className="ml-block-label">Today</div>
            {live.todayPlans.length ? (
              <div className="ml-today-list ml-list-flat">
                {live.todayPlans.map((plan, index) => (
                  <TodayCard key={`${plan.id}-${index}`} plan={plan} />
                ))}
              </div>
            ) : (
              <div className="ml-empty ml-empty--soft">No meals planned today</div>
            )}
          </div>
          <div className="ml-overview-block">
            <div className="ml-block-label">Upcoming</div>
            {live.upcomingPlans.length ? (
              <div className="ml-upcoming ml-list-flat">
                {live.upcomingPlans.map((plan, index) => (
                  <div className="ml-upcoming-row" key={`${plan.id}-up-${index}`}>
                    <div>
                      <div className="ml-row-title">{plan.name}</div>
                      <div className="ml-row-sub">
                        {[shortDate(plan.date), plan.type].filter(Boolean).join(" · ")}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="ml-empty ml-empty--soft">No upcoming meal plan entries</div>
            )}
          </div>
        </div>
      );
    }

    if (!live.shoppingLists.length) {
      return <div className="ml-empty">No shopping lists</div>;
    }
    return (
      <div className="ml-shopping ml-list-flat">
        {live.shoppingLists.map((list, index) => (
          <div className="ml-shopping-row" key={`${list.name}-${index}`}>
            <span>🛒</span>
            <div>
              <div className="ml-row-title">{list.name}</div>
              <div className="ml-row-sub">{fmtInt(list.itemCount)} items</div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="hd-widget-body ml-body-flat" ref={rootRef}>
      <ConnectionCorner source={live.connectionSource || "unknown"} />
      <div className="ml-shell">
        <div className="ml-toolbar">
          <div className="ml-toolbar-left">
            <span className={`ml-status-pill${isOnline ? " ml-status-pill--ok" : " ml-status-pill--warn"}`}>
              <span className="ml-status-dot" aria-hidden="true" />
              {isOnline ? "Online" : "Offline"}
            </span>
          </div>
          <div className="ml-toolbar-right">
            {openHref ? (
              <a className="ml-open-link" href={openHref} target="_blank" rel="noopener noreferrer">
                Open
              </a>
            ) : null}
          </div>
        </div>

        <div className="ml-controls">
          <div className="ml-tabs" role="tablist" aria-label="Mealie sections">
            {TABS.map((item) => (
              <button
                key={item.key}
                className={`ml-tab${tab === item.key ? " ml-tab--active" : ""}`}
                type="button"
                role="tab"
                aria-selected={tab === item.key}
                onClick={() => setTab(item.key)}
              >
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="ml-panel">{renderPanel()}</div>
      </div>
    </div>
  );
}
