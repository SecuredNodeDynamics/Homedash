import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "mealie",
  name: "Mealie",
  description: "Recipes, meal plans, and shopping lists with Overview / Recipes / Meal Plan / Shopping tabs",
  version: "0.3.3",
  category: "General",
  defaultSize: { w: 5, h: 5, minW: 3, minH: 3 },
  hostClass: "ml-kitchen-host",
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "http://10.0.0.1:9000",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      placeholder: "https://mealie.example.com",
    },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url", placeholder: "http://10.0.0.1:9000" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    {
      key: "apiKey",
      label: "API Token",
      type: "password",
      required: true,
    },
  ],
};
