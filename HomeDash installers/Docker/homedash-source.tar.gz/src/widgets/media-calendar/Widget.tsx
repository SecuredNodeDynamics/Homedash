"use client";
import "@/styles/widgets/calendar.widget.css";


import { useCallback, useEffect, useMemo, useState } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";
import type { CalendarEvent } from "@/lib/widgets/calendar";

type Data = {
  href: string;
  openFallbackUrl?: string;
  events: CalendarEvent[];
  sources: Array<{ label: string; color: string }>;
  degraded?: boolean;
};

type View = "agenda" | "month";

const TYPE_ICON: Record<CalendarEvent["type"], string> = {
  movie: "🎬",
  episode: "📺",
  album: "🎵",
  request: "•",
};

const DOW = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"] as const;

function dayKey(iso: string | Date) {
  const date = typeof iso === "string" ? new Date(iso) : iso;
  if (Number.isNaN(date.getTime())) return String(iso).slice(0, 10);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function sameDay(a: Date, b: Date) {
  return (
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  );
}

function startOfDay(date: Date) {
  const next = new Date(date);
  next.setHours(0, 0, 0, 0);
  return next;
}

function addDays(date: Date, n: number) {
  const next = new Date(date);
  next.setDate(next.getDate() + n);
  return next;
}

function fmtAgendaDate(iso: string) {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso.slice(0, 10);
  const today = new Date();
  if (sameDay(date, today)) return "Today";
  if (sameDay(date, addDays(today, 1))) return "Tomorrow";
  return date.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
}

function statusBadge(status: number) {
  if (status >= 5) return { label: "✓ Available", cls: "mcal-status--available" };
  if (status === 4) return { label: "⬡ Partial", cls: "mcal-status--partial" };
  if (status === 3) return { label: "⟳ Processing", cls: "mcal-status--processing" };
  if (status === 2) return { label: "⏳ Pending", cls: "mcal-status--pending" };
  return { label: "✕ Missing", cls: "mcal-status--missing" };
}

function isMissingStatus(status: number) {
  return status === 1;
}

function Poster({
  event,
  list,
}: {
  event: CalendarEvent;
  list?: boolean;
}) {
  const [broken, setBroken] = useState(false);
  const missing = isMissingStatus(event.status);

  return (
    <div className={`mcal-today-poster-wrap${list ? " mcal-today-poster-wrap--list" : ""}`}>
      {event.poster && !broken ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          className="mcal-today-poster"
          src={event.poster}
          alt=""
          loading="lazy"
          onError={() => setBroken(true)}
        />
      ) : (
        <div className="mcal-today-poster mcal-today-poster--fallback">
          {(event.title || "?").charAt(0)}
        </div>
      )}
      <span
        className={`mcal-today-dot mcal-today-dot--poster${missing ? " mcal-status-dot--missing" : ""}`}
        style={
          missing
            ? { ["--mcal-src-color" as string]: event.color }
            : { background: event.color }
        }
      />
    </div>
  );
}

function MediaBody({
  event,
  bodyClass = "mcal-today-card-body",
  titleClass = "mcal-today-title",
  subClass = "mcal-today-sub",
  srcClass = "mcal-today-src",
  showInlineArrow = true,
}: {
  event: CalendarEvent;
  bodyClass?: string;
  titleClass?: string;
  subClass?: string;
  srcClass?: string;
  showInlineArrow?: boolean;
}) {
  const status = statusBadge(event.status);
  return (
    <div className={bodyClass}>
      <div className="mcal-today-item-top">
        <span className="mcal-today-type">{TYPE_ICON[event.type] || "•"}</span>
        <span className={titleClass}>{event.title}</span>
        {event.href && showInlineArrow ? <span className="mcal-today-arrow">↗</span> : null}
      </div>
      {event.subtitle ? <div className={subClass}>{event.subtitle}</div> : null}
      <div className="mcal-src-row">
        <span className={srcClass} style={{ color: event.color, opacity: 0.85 }}>
          {event.source}
        </span>
        <span className={`mcal-status ${status.cls}`}>{status.label}</span>
      </div>
    </div>
  );
}

function MediaCard({ event }: { event: CalendarEvent }) {
  const body = (
    <>
      <Poster event={event} />
      <MediaBody event={event} />
    </>
  );

  if (event.href) {
    return (
      <a
        className="mcal-today-card mcal-today-card--link"
        href={event.href}
        target="_blank"
        rel="noopener noreferrer"
        title={event.title}
      >
        {body}
      </a>
    );
  }

  return <div className="mcal-today-card">{body}</div>;
}

function MediaListRow({ event }: { event: CalendarEvent }) {
  const body = (
    <>
      <Poster event={event} list />
      <MediaBody
        event={event}
        bodyClass="mcal-agenda-text"
        titleClass="mcal-agenda-title"
        subClass="mcal-agenda-sub"
        srcClass="mcal-agenda-src"
        showInlineArrow={false}
      />
      {event.href ? <span className="mcal-agenda-arrow">↗</span> : null}
    </>
  );

  if (event.href) {
    return (
      <a
        className="mcal-agenda-item mcal-agenda-item--link mcal-media-list-row"
        href={event.href}
        target="_blank"
        rel="noopener noreferrer"
        title={event.title}
      >
        {body}
      </a>
    );
  }

  return <div className="mcal-agenda-item mcal-media-list-row">{body}</div>;
}

function DayPanel({
  events,
  itemsView,
  onItemsView,
  selectedDate,
  isToday,
}: {
  events: CalendarEvent[];
  itemsView: "list" | "grid";
  onItemsView: (view: "list" | "grid") => void;
  selectedDate: Date;
  isToday: boolean;
}) {
  const dateText = selectedDate.toLocaleDateString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
  });
  const dateTextShort = selectedDate.toLocaleDateString("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
  });

  return (
    <div className="mcal-today-panel">
      <div className="mcal-today-hdr">
        <div className="mcal-today-hdr-main">
          <span className="mcal-today-label">{isToday ? "Today" : dateTextShort}</span>
          {isToday ? (
            <>
              <span className="mcal-today-date mcal-today-date--full">{dateText}</span>
              <span className="mcal-today-date mcal-today-date--short">{dateTextShort}</span>
            </>
          ) : null}
          <span className="mcal-today-count">
            {events.length} release{events.length === 1 ? "" : "s"}
          </span>
        </div>
        <div className="mcal-items-view-tabs" aria-label="Day items view">
          <button
            type="button"
            className={`mcal-items-view-tab${itemsView === "list" ? " mcal-items-view-tab--active" : ""}`}
            onClick={() => onItemsView("list")}
          >
            List
          </button>
          <button
            type="button"
            className={`mcal-items-view-tab${itemsView === "grid" ? " mcal-items-view-tab--active" : ""}`}
            onClick={() => onItemsView("grid")}
          >
            Grid
          </button>
        </div>
      </div>
      <div
        className={`mcal-today-items ${itemsView === "grid" ? "mcal-today-items--grid" : "mcal-today-items--list"}`}
      >
        {events.length ? (
          events.map((event, index) =>
            itemsView === "grid" ? (
              <MediaCard key={`${event.id}#${index}`} event={event} />
            ) : (
              <MediaListRow key={`${event.id}#${index}`} event={event} />
            ),
          )
        ) : (
          <div className="mcal-today-empty">
            {isToday ? "Nothing scheduled for today" : "Nothing scheduled for this day"}
          </div>
        )}
      </div>
    </div>
  );
}

function SeerrToggle({
  checked,
  onChange,
}: {
  checked: boolean;
  onChange: () => void;
}) {
  return (
    <label
      className={`mcal-seerr-toggle${checked ? " mcal-seerr-toggle--on" : ""}`}
      title={checked ? "Hide Seerr requests" : "Show Seerr requests"}
    >
      <input
        type="checkbox"
        className="mcal-seerr-toggle-input"
        checked={checked}
        onChange={onChange}
      />
      <span className="mcal-seerr-toggle-track">
        <span className="mcal-seerr-toggle-thumb" />
      </span>
      <span className="mcal-seerr-toggle-label">Show All</span>
    </label>
  );
}

export default function MediaCalendarWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "media-calendar";
  const [data, setData] = useState<Data | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<View>("month");
  const [cursor, setCursor] = useState(() => new Date());
  const [itemsView, setItemsView] = useState<"list" | "grid">("grid");
  const [selectedDate, setSelectedDate] = useState(() => startOfDay(new Date()));
  const [showSeerr, setShowSeerr] = useState(true);

  const seerrStorageKey = `mcal-show-seerr:${instanceId}`;

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(seerrStorageKey);
      if (stored !== null) setShowSeerr(stored !== "0");
    } catch {
      // localStorage unavailable (private mode, etc.) — fall back to default
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [seerrStorageKey]);

  const toggleSeerr = useCallback(() => {
    setShowSeerr((prev) => {
      const next = !prev;
      try {
        window.localStorage.setItem(seerrStorageKey, next ? "1" : "0");
      } catch {
        // ignore persistence failures
      }
      return next;
    });
  }, [seerrStorageKey]);

  const load = useCallback(async () => {
    try {
      const response = await fetch(
        `/api/widgets/media-calendar/status?instance=${encodeURIComponent(instanceId)}`,
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load calendar");
      setData(json);
      setError(json.degraded ? "Some sources failed" : "");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Failed to load calendar");
    } finally {
      setLoading(false);
    }
  }, [instanceId]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: 300_000 });

  const rawEvents = data?.events || [];
  const hasSeerr = useMemo(
    () => rawEvents.some((event) => event.source.startsWith("Seerr")),
    [rawEvents],
  );
  const events = useMemo(
    () => (showSeerr ? rawEvents : rawEvents.filter((event) => !event.source.startsWith("Seerr"))),
    [rawEvents, showSeerr],
  );
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);
  const today = useMemo(() => startOfDay(new Date()), []);
  const selectedIsToday = sameDay(selectedDate, today);

  const selectedEvents = useMemo(
    () =>
      events
        .filter((event) => sameDay(new Date(event.date), selectedDate))
        .sort((a, b) => a.date.localeCompare(b.date)),
    [events, selectedDate],
  );

  const agendaGroups = useMemo(() => {
    const future = events
      .filter((event) => {
        const date = startOfDay(new Date(event.date));
        return !Number.isNaN(date.getTime()) && date >= today;
      })
      .sort((a, b) => a.date.localeCompare(b.date))
      .slice(0, 30);

    const map = new Map<string, CalendarEvent[]>();
    for (const event of future) {
      const key = dayKey(event.date);
      const list = map.get(key) || [];
      list.push(event);
      map.set(key, list);
    }
    return Array.from(map.entries()).map(([key, items]) => ({
      key,
      date: items[0]?.date || key,
      items,
    }));
  }, [events, today]);

  const monthLabel = cursor.toLocaleDateString("en-US", { month: "long", year: "numeric" });
  const monthLabelShort = cursor.toLocaleDateString("en-US", { month: "short", year: "numeric" });

  const monthCells = useMemo(() => {
    const year = cursor.getFullYear();
    const month = cursor.getMonth();
    const first = new Date(year, month, 1);
    const startPad = first.getDay(); // Sunday-first
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const byDay = new Map<string, CalendarEvent[]>();
    for (const event of events) {
      const date = new Date(event.date);
      if (date.getFullYear() !== year || date.getMonth() !== month) continue;
      const key = dayKey(event.date);
      const list = byDay.get(key) || [];
      list.push(event);
      byDay.set(key, list);
    }

    const cells: Array<{
      day: number | null;
      key: string;
      events: CalendarEvent[];
      isToday: boolean;
      isSelected: boolean;
      isPast: boolean;
    }> = [];

    for (let i = 0; i < startPad; i += 1) {
      cells.push({
        day: null,
        key: `pad-${i}`,
        events: [],
        isToday: false,
        isSelected: false,
        isPast: false,
      });
    }
    for (let day = 1; day <= daysInMonth; day += 1) {
      const date = new Date(year, month, day);
      const key = dayKey(date);
      cells.push({
        day,
        key,
        events: byDay.get(key) || [],
        isToday: sameDay(date, today),
        isSelected: sameDay(date, selectedDate),
        isPast: date < today,
      });
    }
    return cells;
  }, [cursor, events, today, selectedDate]);

  if (loading && !data) {
    return (
      <div className="hd-widget-body mcal-body-flat" ref={rootRef}>
        <div className="mcal-toolbar">
          <div className="mcal-toolbar-left">
            <span className="mcal-conn mcal-conn--idle">Connecting</span>
          </div>
        </div>
        <div className="mcal-loading">
          <span className="mcal-spin" /> Loading calendar…
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="hd-widget-body mcal-body-flat" ref={rootRef}>
        <div className="mcal-toolbar">
          <div className="mcal-toolbar-left">
            <span className="mcal-conn mcal-conn--warn">Offline</span>
          </div>
          <div className="mcal-toolbar-right">
            <button className="mcal-tool-btn" type="button" onClick={load}>
              Retry
            </button>
          </div>
        </div>
        <div className="mcal-inline-error">{error || "Calendar unavailable"}</div>
      </div>
    );
  }

  return (
    <div className="hd-widget-body mcal-body-flat" ref={rootRef}>
      <div className="mcal-toolbar">
        <div className="mcal-toolbar-left">
          <span
            className={`mcal-conn ${error || data.degraded ? "mcal-conn--warn" : "mcal-conn--active"}`}
          >
            {error || data.degraded ? "Degraded" : "Online"}
          </span>
          {hasSeerr ? <SeerrToggle checked={showSeerr} onChange={toggleSeerr} /> : null}
        </div>
        <div className="mcal-month-nav">
          <button
            className="mcal-nav"
            type="button"
            aria-label="Previous month"
            onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))}
          >
            ‹
          </button>
          <span className="mcal-month-label">
            <span className="mcal-month-label__full">{monthLabel}</span>
            <span className="mcal-month-label__short">{monthLabelShort}</span>
          </span>
          <button
            className="mcal-nav"
            type="button"
            aria-label="Next month"
            onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))}
          >
            ›
          </button>
        </div>
        <div className="mcal-toolbar-right">
          <div className="mcal-view-tabs">
            <button
              type="button"
              className={`mcal-view-tab${view === "month" ? " mcal-view-tab--active" : ""}`}
              onClick={() => setView("month")}
            >
              Month
            </button>
            <button
              type="button"
              className={`mcal-view-tab${view === "agenda" ? " mcal-view-tab--active" : ""}`}
              onClick={() => setView("agenda")}
            >
              Agenda
            </button>
          </div>
          {openHref ? (
            <a className="mcal-tool-btn mcal-tool-btn--open" href={openHref} target="_blank" rel="noopener noreferrer">
              Open
            </a>
          ) : null}
        </div>
      </div>

      {error ? <div className="mcal-inline-error">{error}</div> : null}

      {data.sources?.length ? (
        <div className="mcal-legend">
          {data.sources.map((source) => (
            <span className="mcal-legend-item" key={source.label}>
              <span className="mcal-legend-dot" style={{ background: source.color }} />
              <span className="mcal-legend-label">{source.label}</span>
            </span>
          ))}
        </div>
      ) : null}

      <div className={`mcal-main mcal-main--${view}`}>
        {view === "month" ? (
          <div className="mcal-month-wrap">
            <div className="mcal-grid-header">
              {DOW.map((day) => (
                <div className="mcal-dow" key={day}>
                  <span className="mcal-dow__full">{day}</span>
                  <span className="mcal-dow__short" aria-hidden="true">
                    {day.charAt(0)}
                  </span>
                </div>
              ))}
            </div>
            <div className="mcal-grid">
              {monthCells.map((cell) =>
                cell.day == null ? (
                  <div className="mcal-cell mcal-cell--empty" key={cell.key} />
                ) : (
                  <button
                    type="button"
                    key={cell.key}
                    className={`mcal-cell${cell.isToday ? " mcal-cell--today" : ""}${cell.isSelected ? " mcal-cell--selected" : ""}${cell.isPast ? " mcal-cell--past" : ""}`}
                    onClick={() => {
                      const [y, m, d] = cell.key.split("-").map(Number);
                      setSelectedDate(startOfDay(new Date(y, (m || 1) - 1, d || 1)));
                    }}
                  >
                    <div className="mcal-day-num">{cell.day}</div>
                    <div className="mcal-dots">
                      {cell.events.slice(0, 4).map((event, index) => {
                        const missing = isMissingStatus(event.status);
                        return (
                          <span
                            key={`${event.id}#${index}`}
                            className={`mcal-dot${missing ? " mcal-status-dot--missing" : ""}`}
                            style={
                              missing
                                ? { ["--mcal-src-color" as string]: event.color }
                                : { background: event.color }
                            }
                            title={event.title}
                          />
                        );
                      })}
                      {cell.events.length > 4 ? (
                        <span className="mcal-dot-more">+{cell.events.length - 4}</span>
                      ) : null}
                    </div>
                  </button>
                ),
              )}
            </div>
          </div>
        ) : (
          <div className="mcal-agenda-wrap">
            <div className="mcal-agenda-scroll">
              {agendaGroups.length ? (
                agendaGroups.map((group) => (
                  <div
                    className={`mcal-agenda-group${sameDay(new Date(group.date), today) ? " mcal-agenda-group--today" : ""}`}
                    key={group.key}
                  >
                    <div className="mcal-agenda-date">{fmtAgendaDate(group.date)}</div>
                    <div className="mcal-agenda-items">
                      {group.items.map((event, index) => (
                        <MediaListRow key={`${event.id}#${index}`} event={event} />
                      ))}
                    </div>
                  </div>
                ))
              ) : (
                <div className="mcal-agenda-empty">No upcoming releases</div>
              )}
            </div>
          </div>
        )}
      </div>

      {view === "month" ? (
        <DayPanel
          events={selectedEvents}
          itemsView={itemsView}
          onItemsView={setItemsView}
          selectedDate={selectedDate}
          isToday={selectedIsToday}
        />
      ) : null}
    </div>
  );
}
