import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "media-calendar",
  name: "Media Calendar",
  description: "Upcoming Radarr/Sonarr/Seerr releases",
  version: "0.4.3",
  category: "Media",
  defaultSize: { w: 6, h: 5, minW: 3, minH: 3 },
  hostClass: "mcal-host",
  // Connection sources are edited via MediaCalendarSourcesEditor in Settings.
  configFields: [],
};
