"use client";
import "@/styles/widgets/n8n.widget.css";

import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type ExecutionStatus = "success" | "error" | "running" | "waiting" | "canceled" | "unknown";

type Workflow = {
  id: string;
  name: string;
  active: boolean;
  isArchived: boolean;
  nodeCount: number;
  tags: string[];
  createdAt: string | null;
  updatedAt: string | null;
};

type Execution = {
  id: string;
  workflowId: string;
  workflowName: string;
  status: ExecutionStatus;
  mode: string;
  startedAt: string | null;
  stoppedAt: string | null;
  durationMs: number | null;
};

type ConnectionSource = "private" | "public" | "unknown";

type StatusPayload = {
  workflows: Workflow[];
  executions: Execution[];
  workflowsHref: string;
  executionsHref: string;
  openFallbackUrl?: string;
  connectionSource?: ConnectionSource;
};

type View = "workflows" | "executions" | "archived";

const CONNECTION_SOURCE_LABEL: Record<ConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

function ConnectionCorner({ source }: { source: ConnectionSource }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const mark = (
    <div
      className={`n8n-corner-source n8n-corner-source--${source}`}
      title={CONNECTION_SOURCE_LABEL[source]}
      aria-label={CONNECTION_SOURCE_LABEL[source]}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}


const EXEC_STATUS_INFO: Record<ExecutionStatus, { label: string; className: string; dot: string; color: string }> = {
  success: { label: "SUCCESS", className: "n8n-status--success", dot: "n8n-dot--success", color: "#4ade80" },
  error: { label: "ERROR", className: "n8n-status--error", dot: "n8n-dot--error", color: "#f87171" },
  running: { label: "RUNNING", className: "n8n-status--running", dot: "n8n-dot--running", color: "#60a5fa" },
  waiting: { label: "WAITING", className: "n8n-status--waiting", dot: "n8n-dot--waiting", color: "#fbbf24" },
  canceled: { label: "CANCELED", className: "n8n-status--canceled", dot: "n8n-dot--canceled", color: "rgba(255,255,255,0.4)" },
  unknown: { label: "—", className: "n8n-status--unknown", dot: "n8n-dot--unknown", color: "rgba(255,255,255,0.25)" },
};

function workflowStatus(workflow: Pick<Workflow, "active" | "isArchived">) {
  if (workflow.isArchived) {
    return { label: "ARCHIVED", className: "n8n-status--archived", dot: "n8n-dot--archived", color: "rgba(255,255,255,0.4)" };
  }
  return workflow.active
    ? { label: "ACTIVE", className: "n8n-status--active", dot: "n8n-dot--active", color: "#4ade80" }
    : { label: "INACTIVE", className: "n8n-status--inactive", dot: "n8n-dot--inactive", color: "rgba(255,255,255,0.4)" };
}

function formatTime(value: string | null | undefined) {
  if (!value) return null;
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime())
    ? null
    : parsed.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function formatDate(value: string | null | undefined) {
  if (!value) return null;
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed.toLocaleString([], { dateStyle: "medium", timeStyle: "short" });
}

function formatDuration(ms: number | null) {
  if (ms === null) return null;
  if (ms < 1000) return `${ms}ms`;
  const seconds = ms / 1000;
  if (seconds < 60) return `${seconds.toFixed(1)}s`;
  const minutes = Math.floor(seconds / 60);
  const remSeconds = Math.round(seconds % 60);
  return `${minutes}m ${remSeconds}s`;
}

function ToggleSwitch({
  checked,
  pending,
  onToggle,
  ariaLabel,
}: {
  checked: boolean;
  pending: boolean;
  onToggle: () => void;
  ariaLabel: string;
}) {
  return (
    <button
      type="button"
      className={`n8n-toggle${checked ? " n8n-toggle--on" : ""}${pending ? " n8n-toggle--pending" : ""}`}
      role="switch"
      aria-checked={checked}
      aria-label={ariaLabel}
      disabled={pending}
      onClick={(event) => {
        event.stopPropagation();
        onToggle();
      }}
    >
      <span className="n8n-toggle__thumb" />
    </button>
  );
}

function RowActionButton({
  label,
  title,
  pending,
  variant,
  onClick,
}: {
  label: string;
  title: string;
  pending: boolean;
  variant: "retry" | "stop";
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      className={`n8n-row-action-btn n8n-row-action-btn--${variant}`}
      title={title}
      aria-label={title}
      disabled={pending}
      onClick={(event) => {
        event.stopPropagation();
        onClick();
      }}
    >
      {pending ? "…" : label}
    </button>
  );
}

type DetailRow = [string, string];

function WorkflowCard({
  workflow,
  pending,
  onOpen,
  onToggle,
}: {
  workflow: Workflow;
  pending: boolean;
  onOpen: (rect: DOMRect) => void;
  onToggle?: () => void;
}) {
  const status = workflowStatus(workflow);
  const cardVariant = workflow.isArchived ? "archived" : workflow.active ? "on" : "off";
  return (
    <div
      className={`n8n-card n8n-card--${cardVariant}`}
      role="button"
      tabIndex={0}
      onClick={(event) => onOpen(event.currentTarget.getBoundingClientRect())}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          onOpen(event.currentTarget.getBoundingClientRect());
        }
      }}
    >
      <div className="n8n-card__accent" style={{ background: status.color }} />
      <div className="n8n-card__top">
        <span className={`n8n-status-dot ${status.dot}`} />
        <span className={`n8n-status-badge ${status.className}`}>{status.label}</span>
        {onToggle ? (
          <ToggleSwitch
            checked={workflow.active}
            pending={pending}
            ariaLabel={workflow.active ? `Deactivate ${workflow.name}` : `Activate ${workflow.name}`}
            onToggle={onToggle}
          />
        ) : null}
      </div>
      <div className="n8n-card__name" title={workflow.name}>
        {workflow.name}
      </div>
      <div className="n8n-card__footer">
        <span className="n8n-meta">{workflow.nodeCount} nodes</span>
        {workflow.tags.length ? <span className="n8n-card__tag">{workflow.tags[0]}</span> : null}
      </div>
    </div>
  );
}

function ExecutionCard({
  execution,
  pending,
  onOpen,
  onAction,
}: {
  execution: Execution;
  pending: boolean;
  onOpen: (rect: DOMRect) => void;
  onAction: (kind: "retry-execution" | "stop-execution") => void;
}) {
  const status = EXEC_STATUS_INFO[execution.status];
  return (
    <div
      className={`n8n-card n8n-card--exec n8n-card--exec-${execution.status}`}
      role="button"
      tabIndex={0}
      onClick={(event) => onOpen(event.currentTarget.getBoundingClientRect())}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          onOpen(event.currentTarget.getBoundingClientRect());
        }
      }}
    >
      <div className="n8n-card__accent" style={{ background: status.color }} />
      <div className="n8n-card__top">
        <span className={`n8n-status-dot ${status.dot}`} />
        <span className={`n8n-status-badge ${status.className}`}>{status.label}</span>
      </div>
      <div className="n8n-card__name" title={execution.workflowName}>
        {execution.workflowName}
      </div>
      <div className="n8n-card__footer">
        {formatTime(execution.startedAt) ? <span className="n8n-meta">{formatTime(execution.startedAt)}</span> : <span />}
        {execution.status === "error" ? (
          <RowActionButton
            label="Retry"
            title="Retry this execution"
            variant="retry"
            pending={pending}
            onClick={() => onAction("retry-execution")}
          />
        ) : execution.status === "running" ? (
          <RowActionButton
            label="Stop"
            title="Stop this execution"
            variant="stop"
            pending={pending}
            onClick={() => onAction("stop-execution")}
          />
        ) : null}
      </div>
    </div>
  );
}

type PopupAction = {
  label: string;
  pendingLabel?: string;
  onClick: () => void;
  pending?: boolean;
  variant?: "primary" | "danger";
};

function DetailPopup({
  title,
  eyebrow,
  badgeLabel,
  badgeClassName,
  dotColor,
  rows,
  note,
  openHref,
  openLabel,
  anchorRect,
  onClose,
  actions,
  actionError,
}: {
  title: string;
  eyebrow: string;
  badgeLabel: string;
  badgeClassName: string;
  dotColor: string;
  rows: DetailRow[];
  note?: string | null;
  openHref: string;
  openLabel: string;
  anchorRect: DOMRect | null;
  onClose: () => void;
  actions?: PopupAction[];
  actionError?: string | null;
}) {
  const popupRef = useRef<HTMLDivElement>(null);
  const [style, setStyle] = useState<React.CSSProperties>({ visibility: "hidden" });

  useLayoutEffect(() => {
    const popup = popupRef.current;
    if (!popup) return;

    const place = () => {
      const margin = 12;
      const gap = 8;
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const width = popup.offsetWidth;
      const height = popup.offsetHeight;

      let top: number;
      let left: number;

      if (anchorRect) {
        top = anchorRect.bottom + gap;
        left = anchorRect.left;
        if (top + height > vh - margin) {
          top = anchorRect.top - height - gap;
        }
        top = Math.max(margin, Math.min(top, vh - height - margin));
        left = Math.max(margin, Math.min(left, vw - width - margin));
      } else {
        top = (vh - height) / 2;
        left = (vw - width) / 2;
      }

      setStyle({ top, left, visibility: "visible" });
    };

    place();
    window.addEventListener("resize", place);
    window.addEventListener("scroll", place, true);
    return () => {
      window.removeEventListener("resize", place);
      window.removeEventListener("scroll", place, true);
    };
  }, [anchorRect, title]);

  return createPortal(
    (
      <>
        <button className="n8n-popup-backdrop" type="button" aria-label="Close details" onClick={onClose} />
        <div ref={popupRef} className="n8n-popup" role="dialog" aria-modal="true" aria-label={`${title} details`} style={style}>
          <div className="n8n-popup__accent" style={{ background: `linear-gradient(90deg, ${dotColor}, transparent)` }} />
          <button className="n8n-popup__close" type="button" aria-label="Close" onClick={onClose}>
            ✕
          </button>
          <div className="n8n-popup__body">
            <div className="n8n-popup__eyebrow">{eyebrow}</div>
            <div className="n8n-popup__header">
              <span className="n8n-popup__dot" style={{ background: dotColor, boxShadow: `0 0 10px ${dotColor}99` }} />
              <span className="n8n-popup__name" title={title}>
                {title}
              </span>
              <span className={`n8n-popup__badge ${badgeClassName}`}>{badgeLabel}</span>
            </div>
            <div className="n8n-popup__rows">
              {rows.map(([label, value]) => (
                <div className="n8n-popup__row" key={label}>
                  <span className="n8n-popup__label">{label}</span>
                  <span className="n8n-popup__value">{value}</span>
                </div>
              ))}
            </div>
            {note ? (
              <>
                <div className="n8n-popup__divider" />
                <div className="n8n-popup__value" style={{ textAlign: "left", fontSize: "0.65rem", wordBreak: "break-word" }}>
                  {note}
                </div>
              </>
            ) : null}
            {actionError ? <div className="n8n-popup__error">⚠ {actionError}</div> : null}
            {actions && actions.length ? (
              <div className="n8n-popup__actions">
                {actions.map((action) => (
                  <button
                    key={action.label}
                    type="button"
                    className={`n8n-popup__action-btn${action.variant === "danger" ? " n8n-popup__action-btn--danger" : ""}`}
                    disabled={action.pending}
                    onClick={action.onClick}
                  >
                    {action.pending ? action.pendingLabel || "Working…" : action.label}
                  </button>
                ))}
              </div>
            ) : null}
            <a className="n8n-popup__open-btn" href={openHref} target="_blank" rel="noopener noreferrer">
              {openLabel} ↗
            </a>
          </div>
        </div>
      </>
    ),
    document.body,
  );
}

export default function N8nMonitorWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "n8n-monitor";

  const [view, setView] = useState<View>("workflows");
  const [data, setData] = useState<StatusPayload | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [selectedWorkflowId, setSelectedWorkflowId] = useState<string | null>(null);
  const [selectedExecutionId, setSelectedExecutionId] = useState<string | null>(null);
  const [anchorRect, setAnchorRect] = useState<DOMRect | null>(null);
  const [pendingActions, setPendingActions] = useState<Record<string, boolean>>({});
  const [actionError, setActionError] = useState("");

  const load = useCallback(
    async () => {
      setError("");
      try {
        const response = await fetch(
          `/api/widgets/n8n-monitor/status?instance=${encodeURIComponent(instanceId)}`,
          { cache: "no-store", signal: AbortSignal.timeout(22_000) },
        );
        const json = await response.json();
        if (!response.ok) throw new Error(json.error || "Failed to load n8n");
        setData(json as StatusPayload);
      } catch (reason) {
        setError(reason instanceof Error ? reason.message : "Failed to load n8n");
      } finally {
        setLoading(false);
      }
    },
    [instanceId],
  );

  const { rootRef } = useWidgetPoll(load, { intervalMs: 60_000 });

  const runAction = useCallback(
    async (actionId: string, kind: string, id: string) => {
      setActionError("");
      setPendingActions((prev) => ({ ...prev, [actionId]: true }));
      try {
        const response = await fetch("/api/widgets/n8n-monitor/action", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ instance: instanceId, action: kind, id }),
          signal: AbortSignal.timeout(20_000),
        });
        const json = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(json.error || "Action failed");
        await load();
      } catch (reason) {
        setActionError(reason instanceof Error ? reason.message : "Action failed");
      } finally {
        setPendingActions((prev) => {
          const next = { ...prev };
          delete next[actionId];
          return next;
        });
      }
    },
    [instanceId, load],
  );

  useEffect(() => {
    setActionError("");
  }, [selectedWorkflowId, selectedExecutionId]);

  useEffect(() => {
    if (selectedWorkflowId === null && selectedExecutionId === null) return;
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setSelectedWorkflowId(null);
        setSelectedExecutionId(null);
      }
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [selectedWorkflowId, selectedExecutionId]);

  const workflows = data?.workflows || [];
  const executions = data?.executions || [];
  const connectionSource = data?.connectionSource;
  const openHref = useOpenHref(
    view === "executions" ? data?.executionsHref : data?.workflowsHref,
    data?.openFallbackUrl,
  );

  const liveWorkflows = workflows.filter((workflow) => !workflow.isArchived);
  const archivedWorkflows = workflows.filter((workflow) => workflow.isArchived);

  const workflowCounts = liveWorkflows.reduce(
    (total, workflow) => ({
      active: total.active + Number(workflow.active),
      inactive: total.inactive + Number(!workflow.active),
    }),
    { active: 0, inactive: 0 },
  );
  const execCounts = executions.reduce(
    (total, execution) => ({
      success: total.success + Number(execution.status === "success"),
      error: total.error + Number(execution.status === "error"),
      running: total.running + Number(execution.status === "running"),
      waiting: total.waiting + Number(execution.status === "waiting"),
    }),
    { success: 0, error: 0, running: 0, waiting: 0 },
  );
  const allHealthy = executions.length > 0 ? execCounts.error === 0 : true;

  const sortedWorkflows = [...liveWorkflows].sort((a, b) => a.name.localeCompare(b.name));
  const sortedArchivedWorkflows = [...archivedWorkflows].sort((a, b) => {
    const aTime = a.updatedAt ? new Date(a.updatedAt).getTime() : 0;
    const bTime = b.updatedAt ? new Date(b.updatedAt).getTime() : 0;
    return bTime - aTime;
  });
  const sortedExecutions = [...executions].sort((a, b) => {
    const aTime = a.startedAt ? new Date(a.startedAt).getTime() : 0;
    const bTime = b.startedAt ? new Date(b.startedAt).getTime() : 0;
    return bTime - aTime;
  });

  const selectedWorkflow = workflows.find((workflow) => workflow.id === selectedWorkflowId) || null;
  const selectedExecution = executions.find((execution) => execution.id === selectedExecutionId) || null;

  if (loading && !data) {
    return (
      <div className="hd-widget-body n8n-body-flat" ref={rootRef}>
        <div className="n8n-toolbar">
          <div className="n8n-status-badge n8n-status-badge--unknown">
            <span className="n8n-status-dot-pill" />
            Loading
          </div>
        </div>
        {Array.from({ length: 4 }, (_, index) => (
          <div className="n8n-skeleton-row" style={{ animationDelay: `${index * 0.1}s` }} key={index} />
        ))}
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="hd-widget-body n8n-body-flat" ref={rootRef}>
        <div className="n8n-toolbar">
          <div className="n8n-status-badge n8n-status-badge--unhealthy">
            <span className="n8n-status-dot-pill" />
            Unhealthy
          </div>
          <button className="n8n-refresh-btn" type="button" onClick={() => load()}>
            Retry
          </button>
        </div>
        <div className="n8n-error">⚠ {error}</div>
      </div>
    );
  }

  return (
    <div className="hd-widget-body n8n-body-flat" ref={rootRef}>
      <ConnectionCorner source={connectionSource || "unknown"} />
      <div className="n8n-toolbar">
        <div className="n8n-toolbar-left">
          <div className={`n8n-status-badge ${allHealthy ? "n8n-status-badge--healthy" : "n8n-status-badge--unhealthy"}`}>
            <span className="n8n-status-dot-pill" />
            {allHealthy ? "Healthy" : "Unhealthy"}
          </div>
        </div>
        <div className="n8n-toolbar-right">
          <div className="n8n-tabs">
            <button
              className={`n8n-tab${view === "workflows" ? " n8n-tab--active" : ""}`}
              type="button"
              onClick={() => {
                setSelectedWorkflowId(null);
                setSelectedExecutionId(null);
                setView("workflows");
              }}
            >
              <span className="n8n-tab-icon">⚙</span>
              Workflows
            </button>
            <button
              className={`n8n-tab${view === "executions" ? " n8n-tab--active" : ""}`}
              type="button"
              onClick={() => {
                setSelectedWorkflowId(null);
                setSelectedExecutionId(null);
                setView("executions");
              }}
            >
              <span className="n8n-tab-icon">▶</span>
              Executions
            </button>
            <button
              className={`n8n-tab${view === "archived" ? " n8n-tab--active" : ""}`}
              type="button"
              onClick={() => {
                setSelectedWorkflowId(null);
                setSelectedExecutionId(null);
                setView("archived");
              }}
            >
              <span className="n8n-tab-icon">🗄</span>
              Archived
            </button>
          </div>
          <a className="n8n-open-link" href={openHref} target="_blank" rel="noopener noreferrer">
            Open
          </a>
        </div>
      </div>

      {view === "workflows" ? (
        <>
          <div className={`n8n-summary-bar${workflowCounts.inactive === 0 && liveWorkflows.length ? " n8n-summary-bar--ok" : ""}`}>
            <span className="n8n-summary-chip n8n-summary-chip--up">
              <span className="n8n-dot n8n-dot--active" />
              {workflowCounts.active} active
            </span>
            {workflowCounts.inactive ? (
              <span className="n8n-summary-chip n8n-summary-chip--inactive">
                <span className="n8n-dot n8n-dot--inactive" />
                {workflowCounts.inactive} inactive
              </span>
            ) : null}
            <span className="n8n-summary-total">{liveWorkflows.length} total</span>
          </div>

          <div className="n8n-scroll">
            {!sortedWorkflows.length ? (
              <div className="n8n-empty">No workflows found</div>
            ) : (
              <div className="n8n-card-grid">
                {sortedWorkflows.map((workflow) => {
                  const actionId = `workflow:${workflow.id}`;
                  return (
                    <WorkflowCard
                      key={workflow.id}
                      workflow={workflow}
                      pending={Boolean(pendingActions[actionId])}
                      onOpen={(rect) => {
                        setAnchorRect(rect);
                        setSelectedWorkflowId(workflow.id);
                      }}
                      onToggle={() =>
                        runAction(
                          actionId,
                          workflow.active ? "deactivate-workflow" : "activate-workflow",
                          workflow.id,
                        )
                      }
                    />
                  );
                })}
              </div>
            )}
          </div>
        </>
      ) : view === "executions" ? (
        <>
          <div className={`n8n-summary-bar${execCounts.error === 0 && executions.length ? " n8n-summary-bar--ok" : ""}`}>
            <span className="n8n-summary-chip n8n-summary-chip--up">
              <span className="n8n-dot n8n-dot--success" />
              {execCounts.success} success
            </span>
            {execCounts.error ? (
              <span className="n8n-summary-chip n8n-summary-chip--down">
                <span className="n8n-dot n8n-dot--error" />
                {execCounts.error} error
              </span>
            ) : null}
            {execCounts.running ? (
              <span className="n8n-summary-chip n8n-summary-chip--running">
                <span className="n8n-dot n8n-dot--running" />
                {execCounts.running} running
              </span>
            ) : null}
            {execCounts.waiting ? (
              <span className="n8n-summary-chip n8n-summary-chip--waiting">
                <span className="n8n-dot n8n-dot--waiting" />
                {execCounts.waiting} waiting
              </span>
            ) : null}
            <span className="n8n-summary-total">{executions.length} recent</span>
          </div>

          <div className="n8n-scroll">
            {!sortedExecutions.length ? (
              <div className="n8n-empty">No recent executions</div>
            ) : (
              <div className="n8n-card-grid">
                {sortedExecutions.map((execution) => {
                  const actionId = `execution:${execution.id}`;
                  return (
                    <ExecutionCard
                      key={execution.id}
                      execution={execution}
                      pending={Boolean(pendingActions[actionId])}
                      onOpen={(rect) => {
                        setAnchorRect(rect);
                        setSelectedExecutionId(execution.id);
                      }}
                      onAction={(kind) => runAction(actionId, kind, execution.id)}
                    />
                  );
                })}
              </div>
            )}
          </div>
        </>
      ) : (
        <>
          <div className="n8n-summary-bar">
            <span className="n8n-summary-chip n8n-summary-chip--inactive">
              <span className="n8n-dot n8n-dot--inactive" />
              {sortedArchivedWorkflows.length} archived
            </span>
          </div>

          <div className="n8n-scroll">
            {!sortedArchivedWorkflows.length ? (
              <div className="n8n-empty">No archived workflows</div>
            ) : (
              <div className="n8n-card-grid">
                {sortedArchivedWorkflows.map((workflow) => (
                  <WorkflowCard
                    key={workflow.id}
                    workflow={workflow}
                    pending={Boolean(pendingActions[`workflow:${workflow.id}`])}
                    onOpen={(rect) => {
                      setAnchorRect(rect);
                      setSelectedWorkflowId(workflow.id);
                    }}
                  />
                ))}
              </div>
            )}
          </div>
        </>
      )}

      {selectedWorkflow ? (
        <DetailPopup
          title={selectedWorkflow.name}
          eyebrow={selectedWorkflow.isArchived ? "Archived Workflow" : "Workflow"}
          badgeLabel={workflowStatus(selectedWorkflow).label}
          badgeClassName={workflowStatus(selectedWorkflow).className}
          dotColor={workflowStatus(selectedWorkflow).color}
          rows={[
            ["ID", selectedWorkflow.id],
            ["Nodes", String(selectedWorkflow.nodeCount)],
            ["Tags", selectedWorkflow.tags.length ? selectedWorkflow.tags.join(", ") : "—"],
            ...(formatDate(selectedWorkflow.createdAt) ? ([["Created", formatDate(selectedWorkflow.createdAt)!]] as DetailRow[]) : []),
            ...(formatDate(selectedWorkflow.updatedAt) ? ([["Updated", formatDate(selectedWorkflow.updatedAt)!]] as DetailRow[]) : []),
          ]}
          openHref={openHref}
          openLabel="Open Workflow"
          anchorRect={anchorRect}
          onClose={() => setSelectedWorkflowId(null)}
          actionError={actionError}
          actions={
            selectedWorkflow.isArchived
              ? [
                  {
                    label: "Unarchive",
                    pendingLabel: "Unarchiving…",
                    pending: Boolean(pendingActions[`workflow:${selectedWorkflow.id}`]),
                    onClick: () => runAction(`workflow:${selectedWorkflow.id}`, "unarchive-workflow", selectedWorkflow.id),
                  },
                  {
                    label: "Delete forever",
                    pendingLabel: "Deleting…",
                    pending: Boolean(pendingActions[`workflow:${selectedWorkflow.id}`]),
                    variant: "danger",
                    onClick: () => {
                      if (window.confirm(`Permanently delete "${selectedWorkflow.name}"? This can't be undone.`)) {
                        runAction(`workflow:${selectedWorkflow.id}`, "delete-workflow", selectedWorkflow.id);
                      }
                    },
                  },
                ]
              : [
                  {
                    label: selectedWorkflow.active ? "Deactivate" : "Activate",
                    pendingLabel: selectedWorkflow.active ? "Deactivating…" : "Activating…",
                    pending: Boolean(pendingActions[`workflow:${selectedWorkflow.id}`]),
                    onClick: () =>
                      runAction(
                        `workflow:${selectedWorkflow.id}`,
                        selectedWorkflow.active ? "deactivate-workflow" : "activate-workflow",
                        selectedWorkflow.id,
                      ),
                  },
                  {
                    label: "Archive",
                    pendingLabel: "Archiving…",
                    pending: Boolean(pendingActions[`workflow:${selectedWorkflow.id}`]),
                    onClick: () => runAction(`workflow:${selectedWorkflow.id}`, "archive-workflow", selectedWorkflow.id),
                  },
                ]
          }
        />
      ) : null}

      {selectedExecution ? (
        <DetailPopup
          title={selectedExecution.workflowName}
          eyebrow="Execution"
          badgeLabel={EXEC_STATUS_INFO[selectedExecution.status].label}
          badgeClassName={EXEC_STATUS_INFO[selectedExecution.status].className}
          dotColor={EXEC_STATUS_INFO[selectedExecution.status].color}
          rows={[
            ["ID", selectedExecution.id],
            ["Mode", selectedExecution.mode || "—"],
            ...(formatDate(selectedExecution.startedAt) ? ([["Started", formatDate(selectedExecution.startedAt)!]] as DetailRow[]) : []),
            ...(formatDate(selectedExecution.stoppedAt) ? ([["Stopped", formatDate(selectedExecution.stoppedAt)!]] as DetailRow[]) : []),
            ...(formatDuration(selectedExecution.durationMs) ? ([["Duration", formatDuration(selectedExecution.durationMs)!]] as DetailRow[]) : []),
          ]}
          openHref={openHref}
          openLabel="Open Execution"
          anchorRect={anchorRect}
          onClose={() => setSelectedExecutionId(null)}
          actionError={actionError}
          actions={[
            ...(selectedExecution.status === "error"
              ? [
                  {
                    label: "Retry execution",
                    pendingLabel: "Retrying…",
                    pending: Boolean(pendingActions[`execution:${selectedExecution.id}`]),
                    onClick: () => runAction(`execution:${selectedExecution.id}`, "retry-execution", selectedExecution.id),
                  } as PopupAction,
                ]
              : []),
            ...(selectedExecution.status === "running"
              ? [
                  {
                    label: "Stop execution",
                    pendingLabel: "Stopping…",
                    pending: Boolean(pendingActions[`execution:${selectedExecution.id}`]),
                    variant: "danger" as const,
                    onClick: () => runAction(`execution:${selectedExecution.id}`, "stop-execution", selectedExecution.id),
                  } as PopupAction,
                ]
              : []),
            {
              label: "Delete execution",
              pendingLabel: "Deleting…",
              pending: Boolean(pendingActions[`execution:${selectedExecution.id}`]),
              variant: "danger",
              onClick: () => {
                if (window.confirm("Delete this execution record? This can't be undone.")) {
                  runAction(`execution:${selectedExecution.id}`, "delete-execution", selectedExecution.id);
                }
              },
            },
          ]}
        />
      ) : null}
    </div>
  );
}
