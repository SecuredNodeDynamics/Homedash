import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "n8n-monitor",
  name: "n8n",
  description: "Workflow and execution status, with activate/deactivate, archive/unarchive, retry, and stop controls",
  version: "0.3.2",
  category: "Automation",
  defaultSize: { w: 8, h: 6, minW: 4, minH: 4 },
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "http://10.0.0.1:5678",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      placeholder: "https://n8n.example.com",
    },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url", placeholder: "http://10.0.0.1:5678" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    {
      key: "apiKey",
      label: "API Key (needs workflow:update, workflow:delete + execution:update scopes for controls)",
      type: "password",
      placeholder: "n8n_api_…",
    },
  ],
};
