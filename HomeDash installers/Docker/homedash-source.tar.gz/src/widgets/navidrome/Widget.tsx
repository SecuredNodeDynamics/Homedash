"use client";
import "@/styles/widgets/navidrome.widget.css";


import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";
import type { NdAlbum, NdPlaylist, NdSong, NdTab } from "@/lib/widgets/navidrome";

type TabDef = { key: NdTab; label: string; icon: ReactNode };

type StatusPayload = {
  href: string;
  openFallbackUrl?: string;
  tab: NdTab;
  artists?: number | null;
  albums?: number | null;
  tracks?: number | null;
  scanning?: boolean;
  lastScan?: string | null;
  recentAlbums?: NdAlbum[];
  albumList?: NdAlbum[];
  entries?: NdSong[];
  starredAlbums?: NdAlbum[];
  starredSongs?: NdSong[];
  playlists?: NdPlaylist[];
  error?: string;
};

function coverUrl(instanceId: string, id?: string | null, size = 200) {
  if (!id) return "";
  const params = new URLSearchParams({
    instance: instanceId,
    id,
    size: String(size),
  });
  return `/api/widgets/navidrome/cover?${params}`;
}

const TABS: TabDef[] = [
  {
    key: "stats",
    label: "Library",
    icon: (
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
        <line x1="18" y1="20" x2="18" y2="10" />
        <line x1="12" y1="20" x2="12" y2="4" />
        <line x1="6" y1="20" x2="6" y2="14" />
      </svg>
    ),
  },
  {
    key: "newest",
    label: "Newest",
    icon: (
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
        <circle cx="12" cy="12" r="10" />
        <line x1="12" y1="8" x2="12" y2="16" />
        <line x1="8" y1="12" x2="16" y2="12" />
      </svg>
    ),
  },
  {
    key: "nowplaying",
    label: "Now Playing",
    icon: (
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
        <polygon points="5 3 19 12 5 21 5 3" />
      </svg>
    ),
  },
  {
    key: "recent",
    label: "Recent",
    icon: (
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
        <circle cx="12" cy="12" r="10" />
        <polyline points="12 6 12 12 16 14" />
      </svg>
    ),
  },
  {
    key: "frequent",
    label: "Top Played",
    icon: (
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
        <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
        <polyline points="17 6 23 6 23 12" />
      </svg>
    ),
  },
  {
    key: "starred",
    label: "Starred",
    icon: (
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
      </svg>
    ),
  },
  {
    key: "playlists",
    label: "Playlists",
    icon: (
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
        <line x1="8" y1="6" x2="21" y2="6" />
        <line x1="8" y1="12" x2="21" y2="12" />
        <line x1="8" y1="18" x2="21" y2="18" />
        <line x1="3" y1="6" x2="3.01" y2="6" />
        <line x1="3" y1="12" x2="3.01" y2="12" />
        <line x1="3" y1="18" x2="3.01" y2="18" />
      </svg>
    ),
  },
];

function fmtDuration(secs?: number) {
  if (!secs) return "";
  const m = Math.floor(secs / 60);
  const s = Math.floor(secs % 60);
  return `${m}:${String(s).padStart(2, "0")}`;
}

function fmtDate(str?: string | null) {
  if (!str) return "";
  try {
    return new Date(str).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  } catch {
    return "";
  }
}

function fmtNum(value: number | null | undefined) {
  if (value == null || Number.isNaN(value)) return "—";
  return value.toLocaleString();
}

function albumName(item: NdAlbum) {
  return item.name || item.album || item.title || "Unknown";
}

function DiscIcon({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden>
      <circle cx="12" cy="12" r="9" />
      <circle cx="12" cy="12" r="3" />
      <line x1="12" y1="3" x2="12" y2="9" />
    </svg>
  );
}

function CoverArt({
  src,
  alt,
  placeholderClass,
  size = 28,
  children,
}: {
  src: string;
  alt: string;
  placeholderClass: string;
  size?: number;
  children?: ReactNode;
}) {
  const [missing, setMissing] = useState(!src);
  useEffect(() => {
    setMissing(!src);
  }, [src]);
  return (
    <>
      {src && !missing ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={src} alt={alt} loading="lazy" decoding="async" onError={() => setMissing(true)} />
      ) : (
        <div className={placeholderClass}>
          <DiscIcon size={size} />
        </div>
      )}
      {children}
    </>
  );
}

function Skeleton() {
  return (
    <div className="nd-skeleton-wrap">
      {Array.from({ length: 5 }, (_, i) => (
        <div key={i} className="nd-skeleton-row" />
      ))}
    </div>
  );
}

function Empty({ children }: { children: ReactNode }) {
  return <div className="nd-empty">{children}</div>;
}

function AlbumCard({
  item,
  index,
  href,
  instanceId,
  coverSize = 200,
  playlist = false,
}: {
  item: NdAlbum | NdPlaylist;
  index: number;
  href: string;
  instanceId: string;
  coverSize?: number;
  playlist?: boolean;
}) {
  const name = playlist
    ? (item as NdPlaylist).name || "Untitled"
    : albumName(item as NdAlbum);
  const album = item as NdAlbum;
  const pl = item as NdPlaylist;
  const artist = album.artist || album.albumArtist || "";
  const year = album.year ? `${album.year}` : "";
  const plays = album.playCount ? `${album.playCount.toLocaleString()} plays` : "";
  const count = pl.songCount ? `${pl.songCount} tracks` : "";
  const dur = pl.duration ? fmtDuration(pl.duration) : "";
  const sub = playlist
    ? [count, dur].filter(Boolean).join(" · ")
    : [artist, year, plays].filter(Boolean).join(" · ");
  const link = playlist
    ? `${href}/app/#/playlist/${item.id}`
    : `${href}/app/#/album/${item.id}`;
  const cover = coverUrl(instanceId, item.coverArt, coverSize);

  return (
    <a
      className={`nd-card${playlist ? " nd-playlist-card" : ""}`}
      href={link}
      target="_blank"
      rel="noopener noreferrer"
      style={{ animationDelay: `${index * 35}ms` }}
      title={name}
    >
      <div className={`nd-card-art${playlist ? " nd-card-art--square" : ""}`}>
        <CoverArt src={cover} alt={name} placeholderClass="nd-card-placeholder" />
      </div>
      <div className="nd-card-meta">
        <div className="nd-card-title">{name}</div>
        {sub ? <div className="nd-card-sub">{sub}</div> : null}
      </div>
    </a>
  );
}

function SongRow({
  item,
  index,
  href,
  instanceId,
  nowPlaying = false,
}: {
  item: NdSong;
  index: number;
  href: string;
  instanceId: string;
  nowPlaying?: boolean;
}) {
  const title = item.title || "Unknown";
  const artist = item.artist || "";
  const album = item.album || "";
  const dur = fmtDuration(item.duration);
  const plays = item.playCount ? `${item.playCount.toLocaleString()}×` : "";
  const user = item.username || "";
  const link = item.albumId ? `${href}/app/#/album/${item.albumId}` : href;
  const cover = coverUrl(instanceId, item.coverArt || item.albumId, 80);

  return (
    <a
      className={`nd-song-row${nowPlaying ? " nd-now-playing-row" : ""}`}
      href={link}
      target="_blank"
      rel="noopener noreferrer"
      style={{ animationDelay: `${index * 25}ms` }}
    >
      <div className="nd-song-art">
        <CoverArt src={cover} alt={title} placeholderClass="nd-song-placeholder" size={16}>
          {nowPlaying ? <div className="nd-playing-dot" /> : null}
        </CoverArt>
      </div>
      <div className="nd-song-body">
        <div className="nd-song-title">{title}</div>
        <div className="nd-song-meta">{[artist, album].filter(Boolean).join(" — ")}</div>
      </div>
      <div className="nd-song-right">
        {nowPlaying && user ? <span className="nd-song-user">{user}</span> : null}
        {nowPlaying ? (
          <div className="nd-equalizer" aria-label="Now playing">
            <span />
            <span />
            <span />
          </div>
        ) : (
          <>
            {plays ? <span className="nd-song-plays">{plays}</span> : null}
            {dur ? <span className="nd-song-dur">{dur}</span> : null}
          </>
        )}
      </div>
    </a>
  );
}

export default function NavidromeWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "navidrome";
  const [tab, setTab] = useState<NdTab>("stats");
  const [cache, setCache] = useState<Partial<Record<NdTab, StatusPayload>>>({});
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const tabRef = useRef(tab);
  const cacheRef = useRef(cache);
  tabRef.current = tab;
  cacheRef.current = cache;

  const data = cache[tab] || null;
  const rawHref = data?.href || Object.values(cache).find((v) => v?.href)?.href || "";
  const rawOpenFallbackUrl =
    data?.openFallbackUrl || Object.values(cache).find((v) => v?.openFallbackUrl)?.openFallbackUrl || "";
  const href = useOpenHref(rawHref, rawOpenFallbackUrl);

  const load = useCallback(
    async (nextTab: NdTab = tabRef.current, opts?: { force?: boolean; soft?: boolean }) => {
      if (!opts?.force && !opts?.soft && cacheRef.current[nextTab]) {
        setLoading(false);
        setError("");
        return;
      }
      if (!opts?.soft) setLoading(true);
      try {
        const response = await fetch(
          `/api/widgets/navidrome/status?instance=${encodeURIComponent(instanceId)}&tab=${encodeURIComponent(nextTab)}`,
        );
        const json = (await response.json()) as StatusPayload;
        if (!response.ok) throw new Error(json.error || "Failed to load Navidrome");
        setCache((prev) => {
          const next = { ...prev, [nextTab]: json };
          cacheRef.current = next;
          return next;
        });
        setError("");
      } catch (cause) {
        if (!opts?.soft) {
          setError(cause instanceof Error ? cause.message : "Failed to load Navidrome");
        }
      } finally {
        if (!opts?.soft) setLoading(false);
      }
    },
    [instanceId],
  );

  useEffect(() => {
    void load(tab);
  }, [tab, load]);

  const softPoll = useCallback(() => {
    void load(tabRef.current, { soft: true, force: true });
  }, [load]);
  const { rootRef } = useWidgetPoll(softPoll, { intervalMs: 120_000 });

  function switchTab(next: NdTab) {
    setTab(next);
  }

  const online = Boolean(href) || Boolean(data);

  function renderPanel() {
    if (loading && !data) return <Skeleton />;
    if (error && !data) {
      return (
        <div className="nd-error">
          <div className="nd-error-title">Failed to load</div>
          <div className="nd-error-msg">{error}</div>
        </div>
      );
    }
    if (!data) return <Skeleton />;

    if (tab === "stats") {
      return (
        <>
          <div className="nd-stats-grid">
            <div className="nd-stat-card">
              <div className="nd-stat-icon">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden>
                  <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                  <circle cx="9" cy="7" r="4" />
                  <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                  <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                </svg>
              </div>
              <div className="nd-stat-num">{fmtNum(data.artists)}</div>
              <div className="nd-stat-label">Artists</div>
            </div>
            <div className="nd-stat-card">
              <div className="nd-stat-icon">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden>
                  <rect x="3" y="3" width="18" height="18" rx="2" />
                  <circle cx="12" cy="12" r="4" />
                  <circle cx="12" cy="12" r="1" />
                </svg>
              </div>
              <div className="nd-stat-num">{fmtNum(data.albums)}</div>
              <div className="nd-stat-label">Albums</div>
            </div>
            <div className="nd-stat-card">
              <div className="nd-stat-icon">
                <DiscIcon size={22} />
              </div>
              <div className="nd-stat-num">{fmtNum(data.tracks)}</div>
              <div className="nd-stat-label">Tracks</div>
            </div>
            <div className={`nd-stat-card${data.scanning ? " nd-stat-card--scanning" : ""}`}>
              <div className="nd-stat-icon">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden>
                  <polyline points="23 4 23 10 17 10" />
                  <polyline points="1 20 1 14 7 14" />
                  <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
                </svg>
              </div>
              <div className="nd-stat-num" style={{ fontSize: "0.78rem" }}>
                {data.scanning ? "Scanning…" : fmtDate(data.lastScan) || "—"}
              </div>
              <div className="nd-stat-label">Library scan</div>
            </div>
          </div>
          {(data.recentAlbums || []).length ? (
            <>
              <div className="nd-section-label" style={{ marginTop: 16 }}>
                Recently Added
              </div>
              <div className="nd-card-grid nd-card-grid--compact">
                {(data.recentAlbums || []).map((album, index) => (
                  <AlbumCard
                    key={album.id || index}
                    item={album}
                    index={index}
                    href={href}
                    instanceId={instanceId}
                    coverSize={96}
                  />
                ))}
              </div>
            </>
          ) : null}
        </>
      );
    }

    if (tab === "nowplaying") {
      const entries = data.entries || [];
      if (!entries.length) {
        return (
          <Empty>
            <DiscIcon size={32} />
            <div>Nothing playing right now</div>
          </Empty>
        );
      }
      return (
        <div className="nd-song-list">
          {entries.map((song, index) => (
            <SongRow
              key={song.id || index}
              item={song}
              index={index}
              href={href}
              instanceId={instanceId}
              nowPlaying
            />
          ))}
        </div>
      );
    }

    if (tab === "starred") {
      const albums = data.starredAlbums || [];
      const songs = data.starredSongs || [];
      if (!albums.length && !songs.length) {
        return (
          <Empty>
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2" aria-hidden>
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
            </svg>
            <div>No starred items yet</div>
          </Empty>
        );
      }
      return (
        <>
          {albums.length ? (
            <>
              <div className="nd-section-label">Starred Albums</div>
              <div className="nd-card-grid">
                {albums.map((album, index) => (
                  <AlbumCard
                    key={album.id || index}
                    item={album}
                    index={index}
                    href={href}
                    instanceId={instanceId}
                  />
                ))}
              </div>
            </>
          ) : null}
          {songs.length ? (
            <>
              <div className="nd-section-label" style={{ marginTop: albums.length ? 16 : 0 }}>
                Starred Tracks
              </div>
              <div className="nd-song-list">
                {songs.map((song, index) => (
                  <SongRow
                    key={song.id || index}
                    item={song}
                    index={index}
                    href={href}
                    instanceId={instanceId}
                  />
                ))}
              </div>
            </>
          ) : null}
        </>
      );
    }

    if (tab === "playlists") {
      const playlists = data.playlists || [];
      if (!playlists.length) return <Empty>No playlists found</Empty>;
      return (
        <div className="nd-card-grid">
          {playlists.map((playlist, index) => (
            <AlbumCard
              key={playlist.id || index}
              item={playlist}
              index={index}
              href={href}
              instanceId={instanceId}
              playlist
            />
          ))}
        </div>
      );
    }

    const albums = data.albumList || [];
    if (!albums.length) {
      if (tab === "recent") return <Empty>No recently played albums</Empty>;
      if (tab === "frequent") return <Empty>No play history yet</Empty>;
      return <Empty>No albums found</Empty>;
    }
    return (
      <div className="nd-card-grid">
        {albums.map((album, index) => (
          <AlbumCard
            key={album.id || index}
            item={album}
            index={index}
            href={href}
            instanceId={instanceId}
          />
        ))}
      </div>
    );
  }

  return (
    <div className="hd-widget-body nd-body-flat" ref={rootRef}>
      <div className="nd-shell">
        <div className="nd-toolbar">
          <div className="nd-toolbar-left">
            <span className={`nd-status-pill${online ? " nd-status-pill--ok" : " nd-status-pill--warn"}`}>
              <span className="nd-status-dot" aria-hidden="true" />
              {online ? "Online" : "Offline"}
            </span>
          </div>
          <div className="nd-toolbar-right">
            {href ? (
              <a className="nd-open-btn" href={href} target="_blank" rel="noopener noreferrer">
                Open
              </a>
            ) : null}
          </div>
        </div>

        <div className="nd-tabs" role="tablist">
          {TABS.map((item) => (
            <button
              key={item.key}
              type="button"
              role="tab"
              aria-selected={tab === item.key}
              className={`nd-tab${tab === item.key ? " nd-tab--active" : ""}`}
              onClick={() => switchTab(item.key)}
            >
              {item.icon}
              <span>{item.label}</span>
            </button>
          ))}
        </div>

        <div className="nd-panel">{renderPanel()}</div>
      </div>
    </div>
  );
}
