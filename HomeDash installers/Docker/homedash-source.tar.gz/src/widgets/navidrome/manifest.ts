import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "navidrome",
  name: "Navidrome",
  description: "Music library browser with Library / Newest / Now Playing / Recent / Top Played / Starred / Playlists tabs",
  version: "0.3.0",
  category: "Media",
  defaultSize: { w: 6, h: 4, minW: 3, minH: 3 },
  hostClass: "nd-widget-host",
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "http://10.0.0.1:4533",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      required: false,
      placeholder: "https://navidrome.example.com",
    },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url", placeholder: "http://10.0.0.1:4533" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    {
      key: "user",
      label: "Username",
      type: "text",
      required: true,
    },
    {
      key: "token",
      label: "Token",
      type: "password",
      required: true,
    },
    {
      key: "salt",
      label: "Salt",
      type: "text",
      required: true,
    },
  ],
};
