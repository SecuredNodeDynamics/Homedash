"use client";
import "@/styles/widgets/glances.widget.css";


import {
  useCallback,
  useEffect,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type CSSProperties,
} from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type Alarm = { name: string; chart: string; value: string; info: string };
type Disk = { mount: string; percent: number; used: number; size: number };
type ConnectionSource = "private" | "public" | "unknown";
type Status = {
  href: string;
  openFallbackUrl?: string;
  name: string;
  iface: string;
  online: boolean;
  hostname: string;
  platform: string;
  uptime: string;
  cpu: { percent: number; cores: number } | null;
  mem: { percent: number; used: number; total: number; available: number } | null;
  swap: { percent: number; used: number; total: number } | null;
  load: { min1: number; min5: number; min15: number; cores: number } | null;
  disks: Disk[];
  network: { rx: number; tx: number; history: { rx: number[]; tx: number[] } | null };
  alarms: { critical: Alarm[]; warning: Alarm[] } | null;
  connectionSource?: ConnectionSource;
};
type Interval = { label: string; seconds: number };

const CONNECTION_SOURCE_LABEL: Record<ConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

function ConnectionCorner({ source }: { source: ConnectionSource }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const mark = (
    <div
      className={`nf-corner-source nf-corner-source--${source}`}
      title={CONNECTION_SOURCE_LABEL[source]}
      aria-label={CONNECTION_SOURCE_LABEL[source]}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}

const INTERVALS: Interval[] = [
  { label: "15m", seconds: 900 },
  { label: "1h", seconds: 3600 },
  { label: "6h", seconds: 21600 },
  { label: "24h", seconds: 86400 },
];

function ClockIcon({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      width="14"
      height="14"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <circle cx="12" cy="12" r="9" />
      <polyline points="12 7 12 12 15.5 14" />
    </svg>
  );
}

function ChevronDownIcon({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      width="10"
      height="10"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}

function IntervalDropdown({
  value,
  onChange,
}: {
  value: Interval;
  onChange: (interval: Interval) => void;
}) {
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    function handlePointerDown(event: MouseEvent) {
      if (rootRef.current && !rootRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    }
    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") setOpen(false);
    }
    document.addEventListener("mousedown", handlePointerDown);
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("mousedown", handlePointerDown);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [open]);

  return (
    <div className="nf-interval-dropdown" ref={rootRef}>
      <button
        type="button"
        className="nf-interval-dropdown__trigger"
        onClick={() => setOpen((prev) => !prev)}
        aria-haspopup="listbox"
        aria-expanded={open}
      >
        <ClockIcon className="nf-interval-dropdown__icon" />
        <span>{value.label}</span>
        <ChevronDownIcon
          className={`nf-interval-dropdown__chevron${open ? " nf-interval-dropdown__chevron--open" : ""}`}
        />
      </button>
      {open ? (
        <div className="nf-interval-dropdown__menu" role="listbox">
          {INTERVALS.map((item) => (
            <button
              type="button"
              key={item.label}
              role="option"
              aria-selected={item.seconds === value.seconds}
              className={`nf-interval-dropdown__option${
                item.seconds === value.seconds ? " nf-interval-dropdown__option--active" : ""
              }`}
              onClick={() => {
                onChange(item);
                setOpen(false);
              }}
            >
              {item.label}
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}

function speed(bytes: number) {
  const bps = Math.max(0, Number(bytes) || 0) * 8;
  if (bps >= 1e9) return [(bps / 1e9).toFixed(2), "Gbps"] as const;
  if (bps >= 1e6) return [(bps / 1e6).toFixed(1), "Mbps"] as const;
  if (bps >= 1e3) return [(bps / 1e3).toFixed(0), "Kbps"] as const;
  return [bps.toFixed(0), "bps"] as const;
}

function fmtBytes(bytes: number) {
  const n = Math.max(0, Number(bytes) || 0);
  if (n >= 1e12) return `${(n / 1e12).toFixed(1)} TB`;
  if (n >= 1e9) return `${(n / 1e9).toFixed(1)} GB`;
  if (n >= 1e6) return `${(n / 1e6).toFixed(0)} MB`;
  if (n >= 1e3) return `${(n / 1e3).toFixed(0)} KB`;
  return `${Math.round(n)} B`;
}

function fmtLoad(value: number) {
  return (Number(value) || 0).toFixed(2);
}

function toneForPercent(pct: number) {
  if (pct >= 90) return { color: "#f87171", bg: "rgba(248,113,113,0.14)" };
  if (pct >= 75) return { color: "#fb923c", bg: "rgba(251,146,60,0.14)" };
  if (pct >= 50) return { color: "#fbbf24", bg: "rgba(251,191,36,0.12)" };
  return { color: "#6ee7b7", bg: "rgba(110,231,183,0.12)" };
}

function toneForLoad(min1: number, cores: number) {
  if (!cores) return toneForPercent(min1 * 25);
  return toneForPercent((min1 / cores) * 100);
}

function Sparkline({ values, color }: { values: number[]; color: string }) {
  const id = useId().replace(/:/g, "");
  if (values.length < 2) return null;
  const max = Math.max(...values, 1);
  const points = values
    .map((value, index) => {
      const x = (index / (values.length - 1)) * 100;
      const y = 38 - (Math.max(0, value) / max) * 34;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
  return (
    <svg className="nf-sparkline-svg" viewBox="0 0 100 38" preserveAspectRatio="none">
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop stopColor={color} stopOpacity=".28" />
          <stop offset="1" stopColor={color} stopOpacity=".02" />
        </linearGradient>
      </defs>
      <path d={`M ${points} L 100,38 L 0,38 Z`} fill={`url(#${id})`} />
      <polyline
        points={points}
        fill="none"
        stroke={color}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        opacity=".88"
      />
    </svg>
  );
}

function Meter({
  label,
  value,
  detail,
  percent,
}: {
  label: string;
  value: string;
  detail?: string;
  percent: number;
}) {
  const tone = toneForPercent(percent);
  const width = Math.max(0, Math.min(100, percent));
  return (
    <div className="nf-meter">
      <div className="nf-meter__top">
        <span className="nf-meter__label">{label}</span>
        <span className="nf-meter__value" style={{ color: tone.color }}>
          {value}
        </span>
      </div>
      <div className="nf-meter__track">
        <div
          className="nf-meter__fill"
          style={{ width: `${width}%`, background: tone.color } as CSSProperties}
        />
      </div>
      {detail ? <div className="nf-meter__detail">{detail}</div> : null}
    </div>
  );
}

export default function NetGlancesWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "net-glances";
  const [interval, setIntervalValue] = useState(INTERVALS[1]);
  const [data, setData] = useState<Status | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [updatedAt, setUpdatedAt] = useState("");
  const [selected, setSelected] = useState<"critical" | "warning" | null>(null);
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);

  const load = useCallback(async () => {
    try {
      const response = await fetch(
        `/api/widgets/net-glances/status?instance=${encodeURIComponent(instanceId)}&interval=${interval.seconds}`,
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load Glances");
      setData(json);
      setError("");
      setUpdatedAt(
        new Date().toLocaleTimeString("en-US", {
          hour: "numeric",
          minute: "2-digit",
          second: "2-digit",
          hour12: true,
        }),
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load Glances");
    } finally {
      setLoading(false);
    }
  }, [instanceId, interval.seconds]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: 60_000 });

  if (loading && !data) {
    return (
      <div className="hd-widget-body nf-body" ref={rootRef}>
        <div className="nf-toolbar">
          <span className="nf-status-pill nf-status-pill--loading">
            <span className="nf-status-dot" />
            Loading
          </span>
        </div>
        <div className="nf-skeleton" style={{ height: 72 }} />
        <div className="nf-skeleton" style={{ height: 120 }} />
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="hd-widget-body nf-body" ref={rootRef}>
        <div className="nf-toolbar">
          <span className="nf-status-pill nf-status-pill--offline">
            <span className="nf-status-dot" />
            Offline
          </span>
          <button className="nf-open-link" type="button" onClick={load}>
            Retry
          </button>
        </div>
        <div className="nf-node-offline">{error}</div>
      </div>
    );
  }

  if (!data) return <div className="hd-widget-body nf-body" ref={rootRef} />;

  const [rx, rxUnit] = speed(data.network.rx);
  const [tx, txUnit] = speed(data.network.tx);
  const history = data.network.history;
  const alarms = data.alarms;
  const critCount = alarms?.critical.length || 0;
  const warnCount = alarms?.warning.length || 0;
  const loadTone = data.load
    ? toneForLoad(data.load.min1, data.load.cores)
    : { color: "#6ee7b7", bg: "rgba(110,231,183,0.12)" };
  const connectionSource: ConnectionSource = data.connectionSource || "unknown";

  return (
    <div className="hd-widget-body nf-body" ref={rootRef}>
      <ConnectionCorner source={connectionSource} />
      <div className="nf-toolbar nf-toolbar--static">
        <span
          className={`nf-status-pill ${data.online ? "nf-status-pill--online" : "nf-status-pill--offline"}`}
        >
          <span className="nf-status-dot" />
          {data.online ? "Online" : "Offline"}
        </span>
        <div className="nf-toolbar-right">
          <IntervalDropdown value={interval} onChange={setIntervalValue} />
          {openHref ? (
            <a className="nf-open-link" href={openHref} target="_blank" rel="noopener noreferrer">
              Open
            </a>
          ) : null}
        </div>
      </div>

      <div className="nf-scroll-content">
        {error ? <div className="nf-node-offline">{error}</div> : null}

        <div className="nf-meters">
          {data.cpu ? (
            <Meter
              label="CPU"
              value={`${Math.round(data.cpu.percent)}%`}
              detail={data.cpu.cores ? `${data.cpu.cores} cores` : undefined}
              percent={data.cpu.percent}
            />
          ) : null}
          {data.mem ? (
            <Meter
              label="Memory"
              value={`${Math.round(data.mem.percent)}%`}
              detail={`${fmtBytes(data.mem.used)} / ${fmtBytes(data.mem.total)}`}
              percent={data.mem.percent}
            />
          ) : null}
          {data.swap && data.swap.total > 0 ? (
            <Meter
              label="Swap"
              value={`${Math.round(data.swap.percent)}%`}
              detail={`${fmtBytes(data.swap.used)} / ${fmtBytes(data.swap.total)}`}
              percent={data.swap.percent}
            />
          ) : null}
          {data.load ? (
            <div className="nf-meter">
              <div className="nf-meter__top">
                <span className="nf-meter__label">Load</span>
                <span className="nf-meter__value" style={{ color: loadTone.color }}>
                  {fmtLoad(data.load.min1)}
                </span>
              </div>
              <div className="nf-load-row">
                <span>1m {fmtLoad(data.load.min1)}</span>
                <span>5m {fmtLoad(data.load.min5)}</span>
                <span>15m {fmtLoad(data.load.min15)}</span>
              </div>
              {data.load.cores ? (
                <div className="nf-meter__detail">{data.load.cores} cores</div>
              ) : null}
            </div>
          ) : null}
        </div>

        {data.disks.length ? (
          <div className="nf-disks">
            <div className="nf-section-label">Storage</div>
            {data.disks.map((disk) => {
              const tone = toneForPercent(disk.percent);
              return (
                <div className="nf-disk" key={disk.mount}>
                  <div className="nf-disk__top">
                    <span className="nf-disk__mount" title={disk.mount}>
                      {disk.mount}
                    </span>
                    <span className="nf-disk__pct" style={{ color: tone.color }}>
                      {Math.round(disk.percent)}%
                    </span>
                  </div>
                  <div className="nf-meter__track">
                    <div
                      className="nf-meter__fill"
                      style={{
                        width: `${Math.max(0, Math.min(100, disk.percent))}%`,
                        background: tone.color,
                      }}
                    />
                  </div>
                  <div className="nf-meter__detail">
                    {fmtBytes(disk.used)} used · {fmtBytes(disk.size)} total
                  </div>
                </div>
              );
            })}
          </div>
        ) : null}

        <div className="nf-net">
          <div className="nf-section-label">
            Network
            <span className="nf-section-meta">{data.iface} · {interval.label}</span>
          </div>
          <div className="nf-net-live">
            <div className="nf-net-tile">
              <div className="nf-net-tile__value nf-speed--rx">{rx}</div>
              <div className="nf-net-tile__unit">↓ {rxUnit}</div>
            </div>
            <div className="nf-net-tile">
              <div className="nf-net-tile__value nf-speed--tx">{tx}</div>
              <div className="nf-net-tile__unit">↑ {txUnit}</div>
            </div>
          </div>

          {history ? (
            <div className="nf-sparkline-wrap">
              <div className="nf-sparkline-row">
                <span className="nf-sparkline-label nf-sparkline-label--rx">RX</span>
                <Sparkline values={history.rx} color="#6ee7b7" />
                <span className="nf-sparkline-peak">
                  peak {speed(Math.max(...history.rx, 0))[0]} {speed(Math.max(...history.rx, 0))[1]}
                </span>
              </div>
              <div className="nf-sparkline-row">
                <span className="nf-sparkline-label nf-sparkline-label--tx">TX</span>
                <Sparkline values={history.tx} color="#60a5fa" />
                <span className="nf-sparkline-peak">
                  peak {speed(Math.max(...history.tx, 0))[0]} {speed(Math.max(...history.tx, 0))[1]}
                </span>
              </div>
            </div>
          ) : (
            <div className="nf-history-empty">
              {data.online
                ? "History unavailable — add a Netdata URL for charts"
                : "Node unreachable"}
            </div>
          )}
        </div>

        {alarms && (critCount > 0 || warnCount > 0) ? (
          <div className="nf-alarm-row">
            {alarms.critical.slice(0, 4).map((alarm) => (
              <button
                className="nf-alarm-badge nf-alarm-badge--critical"
                type="button"
                key={`c-${alarm.name}`}
                onClick={() => setSelected("critical")}
              >
                {alarm.name}
              </button>
            ))}
            {alarms.warning.slice(0, 4).map((alarm) => (
              <button
                className="nf-alarm-badge nf-alarm-badge--warning"
                type="button"
                key={`w-${alarm.name}`}
                onClick={() => setSelected("warning")}
              >
                {alarm.name}
              </button>
            ))}
            {critCount + warnCount > 8 ? (
              <button
                className="nf-alarm-badge nf-alarm-badge--warning"
                type="button"
                onClick={() => setSelected(warnCount ? "warning" : "critical")}
              >
                +{critCount + warnCount - 8} more
              </button>
            ) : null}
          </div>
        ) : null}

        <div className="nf-footer">
          {[data.hostname || data.name, data.uptime ? `up ${data.uptime}` : "", updatedAt]
            .filter(Boolean)
            .join(" · ")}
        </div>
      </div>

      {selected && alarms ? (
        <>
          <div id="nf-alarm-popup-backdrop" onClick={() => setSelected(null)} />
          <div className="nf-alarm-popup" role="dialog" aria-modal="true">
            <div className="nf-alarm-popup__header">
              <span className="nf-alarm-popup__node">
                {data.name} — {selected}
              </span>
              <button className="nf-interval-tab" type="button" onClick={() => setSelected(null)}>
                Close
              </button>
            </div>
            <div className="nf-alarm-popup__body">
              {alarms[selected].map((alarm) => (
                <div
                  className={`nf-alarm-popup__row nf-alarm-popup__row--${selected}`}
                  key={alarm.name}
                >
                  <div className="nf-alarm-popup__alarm-name">{alarm.name}</div>
                  <div className="nf-alarm-popup__alarm-chart">{alarm.chart}</div>
                  {alarm.info ? (
                    <div className="nf-alarm-popup__alarm-chart">{alarm.info}</div>
                  ) : null}
                  <div className="nf-alarm-popup__alarm-value">{alarm.value}</div>
                </div>
              ))}
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}
