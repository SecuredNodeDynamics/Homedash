import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "net-glances",
  name: "Glances",
  description: "Throughput / host metrics",
  version: "0.1.6",
  category: "Network",
  defaultSize: { w: 6, h: 6, minW: 4, minH: 4 },
  configFields: [
    { key: "baseUrl", label: "Private - IP", type: "url", placeholder: "http://10.0.0.1:61208" },
    { key: "fallbackUrl", label: "Fallback Public URL", type: "url" , placeholder: "https://glances.example.com" },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url", placeholder: "http://10.0.0.1:61208" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    { key: "netdataBaseUrl", label: "Netdata Private - IP", type: "url" , placeholder: "http://10.0.0.1:19999" },
    { key: "netdataFallbackUrl", label: "Netdata Fallback Public URL", type: "url" , placeholder: "https://netdata.example.com" },
    { key: "interface", label: "Network interface", placeholder: "https://net-glances.example.com" },
    { key: "nodeName", label: "PVE ID", placeholder: "PVE1", required: true },
    { key: "apiKey", label: "API Key / Token", type: "password" },
  ],
};
