"use client";
import "@/styles/widgets/servicemap.widget.css";

import { useCallback, useEffect, useRef, useState, type ChangeEvent, type CSSProperties } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type Host = {
  name: string;
  role?: string;
  ip?: string;
  mac?: string;
  icon?: string;
  localUrl?: string;
  tunnelUrl?: string;
  source?: "scan" | "manual";
  // True when `name` is a saved in-widget edit rather than the scan's
  // resolved hostname or a "hosts" JSON override — see the status route.
  nameEdited?: boolean;
};

type SubnetSource = "override" | "saved-override" | "env" | "detected" | "detected-docker-range" | "fallback";

type TopoData = {
  subnet: string;
  subnetSource?: SubnetSource;
  subnetWarning?: string;
  hosts: Host[];
  scannedAt?: string;
};

// Short label for the subnet badge's tooltip — lets you see at a glance
// whether your widget-settings override actually reached the server
// ("Manual override") or whether the server had to guess ("Auto-detected"),
// without opening devtools.
function subnetSourceLabel(source?: SubnetSource): string {
  switch (source) {
    case "override":
      return "Manual override (query param)";
    case "saved-override":
      return "Saved in widget settings";
    case "env":
      return "Server environment variable";
    case "detected":
      return "Auto-detected from network interface";
    case "detected-docker-range":
      return "Auto-detected (Docker bridge network — may not be your LAN)";
    case "fallback":
      return "Hardcoded fallback — no interface detected";
    default:
      return "";
  }
}

// The identity a saved name is keyed against server-side: MAC when known
// (survives a DHCP lease change), otherwise IP. A host with neither can't
// have its name edited — there's nothing stable to key the edit to.
function hostKeyOf(host: Host): string | null {
  return host.mac || host.ip || null;
}

// The API routes return { error: string } on failure — read it instead of
// throwing away the body and surfacing just the bare status code, which is
// all the old code did and is why every failed save just said "HTTP 400"
// no matter what actually went wrong server-side.
async function extractErrorMessage(response: Response): Promise<string> {
  try {
    const body = (await response.json()) as { error?: unknown };
    if (typeof body?.error === "string" && body.error) return body.error;
  } catch {
    // response wasn't JSON (or had no body) — fall through to status text
  }
  return `HTTP ${response.status}`;
}

// Deterministic accent per host, in the same palette used elsewhere in
// Homedash (green/blue/purple/amber/red), so the color-mix border on each
// card and its status dot actually resolve to something instead of the
// unset --hc-color the previous version relied on.
const ACCENTS = ["#60a5fa", "#4ade80", "#c084fc", "#fbbf24", "#f87171", "#22d3ee"];

// Standard upload/download glyphs (Feather/Lucide-style paths) for the
// import/export buttons, rendered inline so they inherit the toolbar
// button's currentColor instead of relying on a font's arrow glyphs,
// which render inconsistently across platforms and read ambiguously at
// 26x26px next to the rescan button's own icon.
function UploadIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
      <polyline points="17 8 12 3 7 8" />
      <line x1="12" y1="3" x2="12" y2="15" />
    </svg>
  );
}

function DownloadIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
      <polyline points="7 10 12 15 17 10" />
      <line x1="12" y1="15" x2="12" y2="3" />
    </svg>
  );
}

// Standard "settings" gear glyph (Feather/Lucide-style path), matching the
// upload/download icons above: inline SVG so it inherits currentColor
// instead of relying on a font glyph.
function GearIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
    </svg>
  );
}

function accentFor(key: string) {
  let hash = 0;
  for (let i = 0; i < key.length; i++) hash = (hash * 31 + key.charCodeAt(i)) >>> 0;
  return ACCENTS[hash % ACCENTS.length];
}

function timeAgo(iso?: string) {
  if (!iso) return "";
  const seconds = Math.max(0, Math.floor((Date.now() - Date.parse(iso)) / 1000));
  if (seconds < 60) return "just now";
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  return `${hours}h ago`;
}

function HostPopup({
  host,
  onClose,
  editing,
  nameDraft,
  onNameDraftChange,
  onStartEdit,
  onCancelEdit,
  onSaveName,
  onResetName,
  savingName,
  nameError,
}: {
  host: Host;
  onClose: () => void;
  editing: boolean;
  nameDraft: string;
  onNameDraftChange: (value: string) => void;
  onStartEdit: () => void;
  onCancelEdit: () => void;
  onSaveName: () => void;
  onResetName: () => void;
  savingName: boolean;
  nameError: string;
}) {
  const accent = accentFor(host.mac || host.ip || host.name);
  const canEditName = Boolean(hostKeyOf(host));
  const details = [
    host.ip && (["IP", host.ip] as [string, string]),
    host.mac && (["MAC", host.mac] as [string, string]),
    host.role && (["Role", host.role] as [string, string]),
    host.source && ([
      "Source",
      `${host.source === "manual" ? "Manual override" : "Auto-discovered"}${
        host.nameEdited && host.source !== "manual" ? " · name edited" : ""
      }`,
    ] as [string, string]),
  ].filter((detail): detail is [string, string] => Boolean(detail));

  return createPortal(
    (
      <>
        <button
          className="topo-popup-backdrop"
          type="button"
          aria-label="Close device details"
          onClick={onClose}
        />
        <div className="topo-popup" role="dialog" aria-modal="true" aria-label={`${host.name} details`}>
          <div className="topo-popup__body">
            <div className="topo-popup__header">
              <span
                className="topo-popup__icon"
                style={{ boxShadow: `0 0 0 1px ${accent}66, 0 0 10px ${accent}30` }}
              >
                {host.icon ? <img src={host.icon} alt="" /> : <span style={{ color: accent }}>◉</span>}
              </span>
              <span className="topo-popup__title">
                {editing ? (
                  <span className="topo-popup__edit-row">
                    <input
                      className="topo-popup__name-input"
                      type="text"
                      value={nameDraft}
                      maxLength={64}
                      autoFocus
                      disabled={savingName}
                      placeholder="Device name"
                      aria-label="Device name"
                      onChange={(event) => onNameDraftChange(event.target.value)}
                      onKeyDown={(event) => {
                        if (event.key === "Enter") onSaveName();
                      }}
                    />
                    <button
                      className="topo-popup__btn-icon topo-popup__btn-icon--save"
                      type="button"
                      onClick={onSaveName}
                      disabled={savingName || !nameDraft.trim()}
                      title="Save name"
                      aria-label="Save name"
                    >
                      ✓
                    </button>
                    <button
                      className="topo-popup__btn-icon"
                      type="button"
                      onClick={onCancelEdit}
                      disabled={savingName}
                      title="Cancel"
                      aria-label="Cancel edit"
                    >
                      ✕
                    </button>
                  </span>
                ) : (
                  <span className="topo-popup__name-static">
                    <span className="topo-popup__name" title={host.name}>
                      {host.name}
                    </span>
                    {canEditName ? (
                      <button
                        className="topo-popup__edit-btn"
                        type="button"
                        onClick={onStartEdit}
                        title="Edit device name"
                        aria-label="Edit device name"
                      >
                        ✎
                      </button>
                    ) : null}
                  </span>
                )}
                {host.role ? <span className="topo-popup__role">{host.role}</span> : null}
              </span>
              {host.tunnelUrl ? <span className="topo-popup__badge">☁ Tunnel</span> : null}
            </div>
            {editing || nameError ? (
              <div className="topo-popup__edit-meta">
                {nameError ? <span className="topo-popup__edit-error">{nameError}</span> : <span />}
                {host.nameEdited ? (
                  <button
                    className="topo-popup__edit-reset"
                    type="button"
                    onClick={onResetName}
                    disabled={savingName}
                  >
                    Reset to detected name
                  </button>
                ) : null}
              </div>
            ) : null}
            {details.length ? (
              <>
                <div className="topo-popup__divider" />
                <div className="topo-popup__rows">
                  {details.map(([label, value]) => (
                    <div className="topo-popup__row" key={label}>
                      <span className="topo-popup__label">{label}</span>
                      <span className="topo-popup__value">{value}</span>
                    </div>
                  ))}
                </div>
              </>
            ) : null}
            <div className="topo-popup__btns">
              {host.localUrl ? (
                <a
                  className="topo-popup__btn topo-popup__btn--local"
                  href={host.localUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Open Local
                </a>
              ) : null}
              {host.tunnelUrl ? (
                <a
                  className="topo-popup__btn topo-popup__btn--tunnel"
                  href={host.tunnelUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Open Tunnel
                </a>
              ) : null}
            </div>
          </div>
        </div>
      </>
    ),
    document.body,
  );
}

function SubnetSettingsPopup({
  onClose,
  loading,
  currentSubnet,
  currentSource,
  draft,
  onDraftChange,
  onSave,
  onClear,
  saving,
  error,
  hasSavedOverride,
}: {
  onClose: () => void;
  loading: boolean;
  currentSubnet?: string;
  currentSource?: SubnetSource;
  draft: string;
  onDraftChange: (value: string) => void;
  onSave: () => void;
  onClear: () => void;
  saving: boolean;
  error: string;
  hasSavedOverride: boolean;
}) {
  return createPortal(
    (
      <>
        <button
          className="topo-popup-backdrop"
          type="button"
          aria-label="Close subnet settings"
          onClick={onClose}
        />
        <div className="topo-popup" role="dialog" aria-modal="true" aria-label="Subnet settings">
          <div className="topo-popup__body">
            <div className="topo-popup__header">
              <span className="topo-popup__title">
                <span className="topo-popup__name-static">
                  <span className="topo-popup__name">Subnet settings</span>
                </span>
              </span>
            </div>
            <p className="topo-popup__hint">
              Set the CIDR block this widget scans. Saved here, for this widget only — no Docker rebuild or
              platform config needed.
            </p>
            <div className="topo-popup__divider" />
            <div className="topo-popup__rows">
              <div className="topo-popup__row">
                <span className="topo-popup__label">Currently scanning</span>
                <span className="topo-popup__value">{loading ? "…" : currentSubnet || "—"}</span>
              </div>
              <div className="topo-popup__row">
                <span className="topo-popup__label">Source</span>
                <span className="topo-popup__value">
                  {loading ? "…" : subnetSourceLabel(currentSource) || "—"}
                </span>
              </div>
            </div>
            <div className="topo-popup__divider" />
            <div className="topo-popup__edit-row">
              <input
                className="topo-popup__name-input"
                type="text"
                value={draft}
                disabled={saving || loading}
                autoFocus
                placeholder="e.g. 10.0.0.0/24"
                aria-label="Subnet override (CIDR)"
                onChange={(event) => onDraftChange(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter") onSave();
                }}
              />
            </div>
            {error ? <div className="topo-popup__edit-error">{error}</div> : <p className="topo-popup__hint">Leave blank and clear to go back to auto-detection.</p>}
            <div className="topo-popup__btns">
              <button
                className="topo-popup__btn topo-popup__btn--local"
                type="button"
                onClick={onSave}
                disabled={saving || loading || !draft.trim()}
              >
                Save
              </button>
              <button
                className="topo-popup__btn topo-popup__btn--tunnel"
                type="button"
                onClick={onClear}
                disabled={saving || loading || !hasSavedOverride}
                title={hasSavedOverride ? "Clear the saved override" : "No saved override to clear"}
              >
                Clear
              </button>
            </div>
          </div>
        </div>
      </>
    ),
    document.body,
  );
}

// Digs through the instance object for a config value by key, without
// assuming one exact shape. We've seen the settings UI group fields under
// a "Connection" section and the platform update independently of this
// widget, so `instance.config.subnet` isn't guaranteed to be where the
// saved value actually lives (it could be `instance.settings.subnet`,
// `instance.config.connection.subnet`, spread directly onto `instance`,
// etc). This walks the object breadth-first, a few levels deep, and
// returns the first non-empty string found under the given key —
// guarding against cycles and non-plain objects along the way.
function findConfigValue(root: unknown, key: string, maxDepth = 4): string | undefined {
  if (!root || typeof root !== "object") return undefined;
  const seen = new Set<unknown>();
  let frontier: unknown[] = [root];
  for (let depth = 0; depth <= maxDepth && frontier.length; depth++) {
    const next: unknown[] = [];
    for (const node of frontier) {
      if (!node || typeof node !== "object" || seen.has(node)) continue;
      seen.add(node);
      const obj = node as Record<string, unknown>;
      if (typeof obj[key] === "string" && obj[key]) return obj[key] as string;
      for (const value of Object.values(obj)) {
        if (value && typeof value === "object") next.push(value);
      }
    }
    frontier = next;
  }
  return undefined;
}

export default function Widget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "net-topology";
  const [data, setData] = useState<TopoData>({ subnet: "", hosts: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [scanning, setScanning] = useState(false);
  const [selected, setSelected] = useState<Host | null>(null);
  const [isEditingName, setIsEditingName] = useState(false);
  const [nameDraft, setNameDraft] = useState("");
  const [savingName, setSavingName] = useState(false);
  const [nameError, setNameError] = useState("");

  // Export/import of the whole saved-names store (independent of the
  // per-device edit above) — a way to get names back after the store's
  // data directory doesn't survive a restart (see name-overrides.ts) or
  // just to move them to a fresh instance.
  const [namesBusy, setNamesBusy] = useState(false);
  const [namesActionError, setNamesActionError] = useState("");
  const namesFileInputRef = useRef<HTMLInputElement | null>(null);

  // Dismissing the subnet-resolution warning banner (see subnetWarning
  // above) only hides it for the currently-displayed subnet/source — if a
  // rescan or a settings change resolves to a *different* one, the banner
  // should be able to reappear rather than staying suppressed forever.
  const [subnetWarningDismissed, setSubnetWarningDismissed] = useState(false);

  // In-widget subnet settings popup (the gear icon). savedSubnetOverride
  // tracks whether a saved override currently exists at all (so "Clear"
  // can be disabled when there's nothing to clear); subnetDraft is the
  // text field's live value, independent of what's actually saved until
  // Save is pressed.
  const [subnetSettingsOpen, setSubnetSettingsOpen] = useState(false);
  const [subnetSettingsLoading, setSubnetSettingsLoading] = useState(false);
  const [savedSubnetOverride, setSavedSubnetOverride] = useState<string | undefined>(undefined);
  const [subnetDraft, setSubnetDraft] = useState("");
  const [savingSubnet, setSavingSubnet] = useState(false);
  const [subnetSettingsError, setSubnetSettingsError] = useState("");

  // Read from the instance object on a best-effort basis (findConfigValue
  // does a recursive search rather than trusting the platform's
  // "official" configFields passthrough, which isn't reliable on this
  // Homedash build). A missing value just means "no manual host
  // overrides" rather than a broken scan. The subnet override no longer
  // goes through this path at all as of 0.5.8 — it's set from the
  // widget's own settings popup and saved server-side per instance (see
  // openSubnetSettings/saveSubnetSetting below and
  // lib/net-scan/subnet-config.ts). See scan.ts for the subnet's full
  // fallback order (query param → saved widget setting →
  // NET_TOPOLOGY_SUBNET → auto-detected from the container's own network
  // interfaces).
  const hostsValue = findConfigValue(instance, "hosts");

  const statusUrl = useCallback(() => {
    const params = new URLSearchParams({ instance: instanceId });
    if (hostsValue) params.set("hosts", hostsValue);
    return `/api/widgets/net-topology/status?${params.toString()}`;
  }, [instanceId, hostsValue]);

  const load = useCallback(async () => {
    setError("");
    try {
      const response = await fetch(statusUrl(), {
        cache: "no-store",
        signal: AbortSignal.timeout(22_000),
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      setData((await response.json()) as TopoData);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Failed to load network scan");
    } finally {
      setLoading(false);
    }
  }, [statusUrl]);

  const rescan = useCallback(async () => {
    setScanning(true);
    try {
      await fetch(statusUrl(), { method: "POST" });
      await load();
    } finally {
      setScanning(false);
    }
  }, [statusUrl, load]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: 120_000 });

  // Opens the subnet settings popup and loads whatever's currently saved
  // for this instance (independent of `data.subnet`, since the displayed
  // subnet could be coming from a ?subnet= query param or auto-detection
  // instead of a saved override — the popup should reflect the actual
  // saved value, not just whatever's on screen).
  const openSubnetSettings = useCallback(async () => {
    setSubnetSettingsOpen(true);
    setSubnetSettingsError("");
    setSubnetSettingsLoading(true);
    try {
      const params = new URLSearchParams({ instance: instanceId });
      const response = await fetch(`/api/widgets/net-topology/subnet?${params.toString()}`);
      if (!response.ok) throw new Error(await extractErrorMessage(response));
      const body = (await response.json()) as { subnet?: string | null };
      const current = body.subnet ?? undefined;
      setSavedSubnetOverride(current);
      setSubnetDraft(current ?? "");
    } catch (reason) {
      setSubnetSettingsError(reason instanceof Error ? reason.message : "Could not load subnet setting");
    } finally {
      setSubnetSettingsLoading(false);
    }
  }, [instanceId]);

  const closeSubnetSettings = useCallback(() => {
    setSubnetSettingsOpen(false);
    setSubnetSettingsError("");
  }, []);

  const saveSubnetSetting = useCallback(async () => {
    const trimmed = subnetDraft.trim();
    if (!trimmed) {
      setSubnetSettingsError("Enter a subnet in CIDR form, e.g. 10.0.0.0/24.");
      return;
    }
    setSavingSubnet(true);
    setSubnetSettingsError("");
    try {
      const response = await fetch("/api/widgets/net-topology/subnet", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instanceId, subnet: trimmed }),
      });
      if (!response.ok) throw new Error(await extractErrorMessage(response));
      const body = (await response.json()) as { subnet?: string };
      setSavedSubnetOverride(body.subnet ?? trimmed);
      await load();
      closeSubnetSettings();
    } catch (reason) {
      setSubnetSettingsError(reason instanceof Error ? reason.message : "Could not save subnet setting");
    } finally {
      setSavingSubnet(false);
    }
  }, [subnetDraft, instanceId, load, closeSubnetSettings]);

  const clearSubnetSetting = useCallback(async () => {
    setSavingSubnet(true);
    setSubnetSettingsError("");
    try {
      const params = new URLSearchParams({ instance: instanceId });
      const response = await fetch(`/api/widgets/net-topology/subnet?${params.toString()}`, {
        method: "DELETE",
      });
      if (!response.ok) throw new Error(await extractErrorMessage(response));
      setSavedSubnetOverride(undefined);
      setSubnetDraft("");
      await load();
    } catch (reason) {
      setSubnetSettingsError(reason instanceof Error ? reason.message : "Could not clear subnet setting");
    } finally {
      setSavingSubnet(false);
    }
  }, [instanceId, load]);

  const openHost = useCallback((host: Host) => {
    setSelected(host);
    setIsEditingName(false);
    setNameError("");
  }, []);

  const closePopup = useCallback(() => {
    setSelected(null);
    setIsEditingName(false);
    setNameError("");
  }, []);

  const startEdit = useCallback(() => {
    if (!selected) return;
    setNameDraft(selected.name);
    setNameError("");
    setIsEditingName(true);
  }, [selected]);

  const cancelEdit = useCallback(() => {
    setIsEditingName(false);
    setNameError("");
  }, []);

  const saveName = useCallback(async () => {
    if (!selected) return;
    const key = hostKeyOf(selected);
    const trimmed = nameDraft.trim();
    if (!key) {
      setNameError("This device has no IP or MAC to save a name against.");
      return;
    }
    if (!trimmed) {
      setNameError("Name can't be empty.");
      return;
    }
    setSavingName(true);
    setNameError("");
    try {
      const response = await fetch("/api/widgets/net-topology/names", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instanceId, key, name: trimmed }),
      });
      if (!response.ok) throw new Error(await extractErrorMessage(response));
      await load();
      setIsEditingName(false);
    } catch (reason) {
      setNameError(reason instanceof Error ? reason.message : "Could not save name");
    } finally {
      setSavingName(false);
    }
  }, [selected, nameDraft, instanceId, load]);

  const resetName = useCallback(async () => {
    if (!selected) return;
    const key = hostKeyOf(selected);
    if (!key) return;
    setSavingName(true);
    setNameError("");
    try {
      const params = new URLSearchParams({ instance: instanceId, key });
      const response = await fetch(`/api/widgets/net-topology/names?${params.toString()}`, {
        method: "DELETE",
      });
      if (!response.ok) throw new Error(await extractErrorMessage(response));
      await load();
      setIsEditingName(false);
    } catch (reason) {
      setNameError(reason instanceof Error ? reason.message : "Could not reset name");
    } finally {
      setSavingName(false);
    }
  }, [selected, instanceId, load]);

  // Downloads every saved name for this instance as a JSON file, so it can
  // be restored later if the server's data directory gets wiped (or moved
  // to a different instance/deployment) instead of being retyped by hand.
  const exportNames = useCallback(async () => {
    setNamesActionError("");
    setNamesBusy(true);
    try {
      const params = new URLSearchParams({ instance: instanceId });
      const response = await fetch(`/api/widgets/net-topology/names?${params.toString()}`);
      if (!response.ok) throw new Error(await extractErrorMessage(response));
      const payload = (await response.json()) as { overrides?: Record<string, string> };
      const blob = new Blob([JSON.stringify(payload.overrides ?? {}, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `net-topology-names-${instanceId}.json`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
    } catch (reason) {
      setNamesActionError(reason instanceof Error ? reason.message : "Could not export names");
    } finally {
      setNamesBusy(false);
    }
  }, [instanceId]);

  // Restores names from a file produced by exportNames() above. Merges
  // into whatever is already saved rather than replacing it, so importing
  // an older backup can't wipe out names added since it was taken.
  const importNamesFile = useCallback(
    async (file: File) => {
      setNamesActionError("");
      setNamesBusy(true);
      try {
        const text = await file.text();
        let parsed: unknown;
        try {
          parsed = JSON.parse(text);
        } catch {
          throw new Error("That file isn't valid JSON.");
        }
        // Accept either the bare { key: name } map exportNames() writes,
        // or the full { instanceId, overrides } envelope the GET /names
        // response uses — so re-importing an exported file works either
        // way someone might have saved or re-saved it.
        const overrides =
          parsed && typeof parsed === "object" && !Array.isArray(parsed) && "overrides" in (parsed as Record<string, unknown>)
            ? (parsed as { overrides?: unknown }).overrides
            : parsed;
        if (!overrides || typeof overrides !== "object" || Array.isArray(overrides)) {
          throw new Error("Expected a JSON object mapping device key to name.");
        }
        const response = await fetch("/api/widgets/net-topology/names", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ instanceId, overrides, mode: "merge" }),
        });
        if (!response.ok) throw new Error(await extractErrorMessage(response));
        await load();
      } catch (reason) {
        setNamesActionError(reason instanceof Error ? reason.message : "Could not import names");
      } finally {
        setNamesBusy(false);
      }
    },
    [instanceId, load],
  );

  const onNamesFileChosen = useCallback(
    (event: ChangeEvent<HTMLInputElement>) => {
      const file = event.target.files?.[0];
      event.target.value = ""; // allow re-selecting the same file next time
      if (file) void importNamesFile(file);
    },
    [importNamesFile],
  );

  // Keeps the open popup showing the current data after a scan/poll or a
  // name save/reset refreshes `data.hosts` — otherwise it would keep
  // displaying the stale host object it was opened with until closed.
  useEffect(() => {
    setSelected((current) => {
      if (!current) return current;
      const key = hostKeyOf(current);
      if (!key) return current;
      const updated = data.hosts.find((host) => hostKeyOf(host) === key);
      return updated ?? current;
    });
  }, [data.hosts]);

  useEffect(() => {
    setSubnetWarningDismissed(false);
  }, [data.subnet, data.subnetSource]);

  useEffect(() => {
    if (!selected) return;
    const handleKey = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      if (isEditingName) {
        cancelEdit();
      } else {
        closePopup();
      }
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [selected, isEditingName, cancelEdit, closePopup]);

  useEffect(() => {
    if (!subnetSettingsOpen) return;
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") closeSubnetSettings();
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [subnetSettingsOpen, closeSubnetSettings]);

  const hasHosts = data.hosts.length > 0;
  const tunnelled = data.hosts.filter((host) => host.tunnelUrl).length;
  const manual = data.hosts.filter((host) => host.source === "manual").length;

  if (loading && !hasHosts) {
    return (
      <div className="hd-widget-body topo-body-flat" ref={rootRef}>
        <div className="topo-toolbar">
          <div className="topo-status-badge topo-status-badge--unknown">
            <span className="topo-status-dot-pill" />
            Scanning
          </div>
        </div>
        <div className="topo-skeleton-grid">
          {Array.from({ length: 6 }, (_, index) => (
            <div className="topo-skeleton-card" style={{ animationDelay: `${index * 0.1}s` }} key={index} />
          ))}
        </div>
      </div>
    );
  }

  if (error && !hasHosts) {
    return (
      <div className="hd-widget-body topo-body-flat" ref={rootRef}>
        <div className="topo-toolbar">
          <div className="topo-status-badge topo-status-badge--unhealthy">
            <span className="topo-status-dot-pill" />
            Unhealthy
          </div>
          <button className="topo-refresh-btn" type="button" onClick={() => load()}>
            Retry
          </button>
        </div>
        <div className="topo-error">⚠ {error}</div>
      </div>
    );
  }

  return (
    <div className="hd-widget-body topo-body-flat" ref={rootRef}>
      <div className="topo-toolbar">
        <div className="topo-toolbar-left">
          <div
            className={`topo-status-badge ${
              hasHosts ? "topo-status-badge--healthy" : "topo-status-badge--unknown"
            }`}
          >
            <span className="topo-status-dot-pill" />
            {hasHosts ? "Online" : "No devices"}
          </div>
        </div>
        <div className="topo-toolbar-right">
          <span
            className={`topo-subnet${data.subnetWarning ? " topo-subnet--warning" : ""}`}
            title={
              data.subnet
                ? [subnetSourceLabel(data.subnetSource), data.subnetWarning].filter(Boolean).join(" — ")
                : undefined
            }
          >
            {data.subnetWarning ? "⚠ " : ""}
            {data.subnet || "Loading subnet…"}
          </span>
          <input
            ref={namesFileInputRef}
            type="file"
            accept="application/json"
            className="topo-names-file-input"
            onChange={onNamesFileChosen}
          />
          <button
            className="topo-refresh-btn"
            type="button"
            onClick={() => namesFileInputRef.current?.click()}
            disabled={namesBusy}
            title="Import saved device names from a JSON file"
            aria-label="Import saved device names"
          >
            <UploadIcon />
          </button>
          <button
            className="topo-refresh-btn"
            type="button"
            onClick={exportNames}
            disabled={namesBusy}
            title="Export saved device names to a JSON file"
            aria-label="Export saved device names"
          >
            <DownloadIcon />
          </button>
          <button
            className="topo-refresh-btn"
            type="button"
            onClick={openSubnetSettings}
            title="Subnet settings"
            aria-label="Subnet settings"
          >
            <GearIcon />
          </button>
          <button
            className={`topo-refresh-btn${scanning ? " topo-refresh-btn--spinning" : ""}`}
            type="button"
            onClick={rescan}
            disabled={scanning}
            title="Rescan network"
            aria-label="Rescan network"
          >
            ↻
          </button>
        </div>
      </div>

      {namesActionError ? (
        <div className="topo-names-banner" role="alert">
          ⚠ {namesActionError}
          <button
            className="topo-names-banner__dismiss"
            type="button"
            onClick={() => setNamesActionError("")}
            aria-label="Dismiss"
          >
            ✕
          </button>
        </div>
      ) : null}

      {data.subnetWarning && !subnetWarningDismissed ? (
        <div className="topo-names-banner" role="alert">
          ⚠ {data.subnetWarning}
          <button
            className="topo-names-banner__dismiss"
            type="button"
            onClick={() => setSubnetWarningDismissed(true)}
            aria-label="Dismiss"
          >
            ✕
          </button>
        </div>
      ) : null}

      <div className="topo-summary-bar">
        <span className="topo-summary-chip topo-summary-chip--devices">
          <span className="topo-dot topo-dot--devices" />
          {data.hosts.length} device{data.hosts.length === 1 ? "" : "s"}
        </span>
        {tunnelled ? (
          <span className="topo-summary-chip topo-summary-chip--tunnel">
            <span className="topo-dot topo-dot--tunnel" />
            {tunnelled} tunnelled
          </span>
        ) : null}
        {manual ? (
          <span className="topo-summary-chip topo-summary-chip--manual">
            <span className="topo-dot topo-dot--manual" />
            {manual} manual
          </span>
        ) : null}
        <span className="topo-summary-total">
          {data.scannedAt ? `Scanned ${timeAgo(data.scannedAt)}` : "Not yet scanned"}
        </span>
      </div>

      <div className="topo-scroll">
        {!hasHosts ? (
          <div className="topo-empty">No devices found</div>
        ) : (
          <div className="topo-host-grid">
            {data.hosts.map((host) => {
              const accent = accentFor(host.mac || host.ip || host.name);
              return (
                <button
                  className="topo-host-card"
                  type="button"
                  key={`${host.name}-${host.ip}`}
                  style={{ "--hc-color": accent } as CSSProperties}
                  onClick={() => openHost(host)}
                >
                  <span className="topo-host-icon">
                    {host.icon ? <img src={host.icon} alt="" /> : <span style={{ color: accent }}>◉</span>}
                  </span>
                  <span className="topo-host-name-row">
                    <span className="topo-host-name">{host.name}</span>
                    {host.nameEdited ? (
                      <span className="topo-host-edited-dot" title="Name edited" aria-hidden="true" />
                    ) : null}
                  </span>
                  {host.ip ? <span className="topo-host-ip">{host.ip}</span> : null}
                  {host.role ? <span className="topo-host-role">{host.role}</span> : null}
                  {host.tunnelUrl ? (
                    <span className="topo-host-cf" title="Cloudflare tunnel available">
                      ☁
                    </span>
                  ) : null}
                  <span
                    className="topo-host-dot"
                    style={{ background: accent, boxShadow: `0 0 5px ${accent}80` }}
                  />
                </button>
              );
            })}
          </div>
        )}
      </div>

      {selected ? (
        <HostPopup
          host={selected}
          onClose={closePopup}
          editing={isEditingName}
          nameDraft={nameDraft}
          onNameDraftChange={setNameDraft}
          onStartEdit={startEdit}
          onCancelEdit={cancelEdit}
          onSaveName={saveName}
          onResetName={resetName}
          savingName={savingName}
          nameError={nameError}
        />
      ) : null}

      {subnetSettingsOpen ? (
        <SubnetSettingsPopup
          onClose={closeSubnetSettings}
          loading={subnetSettingsLoading}
          currentSubnet={data.subnet}
          currentSource={data.subnetSource}
          draft={subnetDraft}
          onDraftChange={setSubnetDraft}
          onSave={saveSubnetSetting}
          onClear={clearSubnetSetting}
          saving={savingSubnet}
          error={subnetSettingsError}
          hasSavedOverride={Boolean(savedSubnetOverride)}
        />
      ) : null}
    </div>
  );
}
