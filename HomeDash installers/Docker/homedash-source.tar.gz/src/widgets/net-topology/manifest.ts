import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "net-topology",
  name: "Network Topology",
  description:
    "LAN device scanner — auto-detects its local subnet, or set one from the gear icon inside the widget",
  version: "0.5.10",
  category: "Network",
  defaultSize: { w: 6, h: 5, minW: 3, minH: 3 },
  configFields: [
    // No "subnet" field here on purpose. This Homedash build's
    // useWidgetInstance() doesn't reliably pass configFields values
    // through the "official" instance-settings path, so as of 0.5.8 the
    // subnet override is set entirely from the widget's own settings
    // popup (the gear icon in its toolbar) and saved server-side per
    // instance — see lib/net-scan/subnet-config.ts and the
    // /api/widgets/net-topology/subnet route. No platform config
    // plumbing, Docker rebuild, or docker-compose edit is needed to
    // change it. If nothing is saved there, the server falls back to
    // NET_TOPOLOGY_SUBNET, then to auto-detecting the subnet from the
    // container's own network interfaces (see lib/net-scan/scan.ts).

    // Per-device friendly names don't need this JSON field at all as of
    // 0.5.5 — each device card's popup has its own "edit name" control that
    // persists straight to the server (see lib/net-scan/name-overrides.ts).
    // "hosts" JSON overrides still work for anything besides the name
    // (role/icon/localUrl/tunnelUrl) and for adding devices the scan can't
    // see on its own.
    {
      key: "hosts",
      label: "Host overrides JSON (optional)",
      placeholder:
        '[{"ip":"10.0.0.1","name":"Router","role":"Gateway","localUrl":"http://10.0.0.1"}]',
    },
  ],
};
