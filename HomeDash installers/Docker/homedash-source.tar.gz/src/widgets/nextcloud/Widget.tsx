"use client";
import "@/styles/widgets/nextcloud.widget.css";


import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type NcTab = "overview" | "files" | "talk" | "calendar" | "contacts" | "shares" | "activity" | "alerts";
type FilesMode = "browse" | "favorites" | "recent" | "trash";

type Storage = {
  used: number;
  free: number | null;
  total: number | null;
  pct: number | null;
  source?: string;
};

type DavFile = {
  name: string;
  path: string;
  href?: string;
  isDir: boolean;
  size: number | null;
  modified: string | null;
  fileId: string | null;
  trashName?: string;
  originalLocation?: string;
  deletedAt?: string | null;
};

type ContactItem = {
  id: string;
  name: string;
  email: string;
  phone: string;
  source: string;
  link: string | null;
};

type CalendarEvent = {
  summary: string;
  start: string | null;
  end: string | null;
  location: string;
  uid: string;
  allDay: boolean;
  calendarName?: string;
};

type TaskItem = {
  uid: string;
  summary: string;
  completed: boolean;
  due: string | null;
  priority: number;
  listName: string;
  calendarPath?: string;
  status: string;
};

type NcConnectionSource = "private" | "public" | "unknown";

const CONNECTION_SOURCE_LABEL: Record<NcConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

function ConnectionCorner({ source }: { source: NcConnectionSource }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const mark = (
    <div
      className={`nc-corner-source nc-corner-source--${source}`}
      title={CONNECTION_SOURCE_LABEL[source]}
      aria-label={CONNECTION_SOURCE_LABEL[source]}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}

type OverviewMeta = {
  href: string;
  openFallbackUrl?: string;
  connectionSource?: NcConnectionSource;
  version: string | null;
  storage: Storage;
  info: Record<string, unknown>;
  health: Record<string, unknown>;
  users: unknown[];
  shares: Array<Record<string, unknown>>;
  activity: Array<Record<string, unknown>>;
  notifications: Array<Record<string, unknown>>;
  rooms: Array<Record<string, unknown>>;
  mounts: Array<Record<string, unknown>>;
  calendar: CalendarEvent[];
  talkMissing?: boolean;
  user?: Record<string, unknown>;
  status?: Record<string, unknown>;
};

type TabData = Record<string, unknown> & {
  href?: string;
  openFallbackUrl?: string;
  connectionSource?: NcConnectionSource;
  tab?: string;
  error?: string | null;
};

const TABS: { key: NcTab; label: string }[] = [
  { key: "overview", label: "Overview" },
  { key: "files", label: "Files" },
  { key: "talk", label: "Talk" },
  { key: "calendar", label: "Calendar" },
  { key: "contacts", label: "Contacts" },
  { key: "shares", label: "Shares" },
  { key: "activity", label: "Activity" },
  { key: "alerts", label: "Alerts" },
];

const POLL_MS = 60_000;
const TALK_POLL_MS = 4_000;

function fmtBytes(n: number | null | undefined) {
  const v = Number(n);
  if (!Number.isFinite(v) || v < 0) return "—";
  if (v < 1000) return `${Math.round(v)} B`;
  if (v < 1e6) return `${(v / 1e3).toFixed(1)} KB`;
  if (v < 1e9) return `${(v / 1e6).toFixed(1)} MB`;
  if (v < 1e12) return `${(v / 1e9).toFixed(v / 1e9 < 10 ? 2 : 1)} GB`;
  return `${(v / 1e12).toFixed(2)} TB`;
}

function fmtInt(n: unknown) {
  const v = Number(n);
  return Number.isFinite(v) ? v.toLocaleString() : "—";
}

function fmtRelative(raw: unknown) {
  if (raw == null || raw === "") return "";
  let ms: number;
  if (typeof raw === "number") ms = raw < 1e12 ? raw * 1000 : raw;
  else {
    const t = Date.parse(String(raw));
    if (!Number.isFinite(t)) return String(raw);
    ms = t;
  }
  const diff = Math.max(0, Math.floor((Date.now() - ms) / 1000));
  if (diff < 60) return `${diff}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  if (diff < 86400 * 14) return `${Math.floor(diff / 86400)}d ago`;
  return new Date(ms).toLocaleDateString();
}

function cleanDisplay(value: unknown) {
  return String(value ?? "")
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCharCode(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)))
    .replace(/\r\n/g, " ")
    .replace(/[\r\n]+/g, " ")
    .trim();
}

function formatTalkMessageText(msg: Record<string, unknown>) {
  let text = String(msg.message || "");
  const params = (msg.messageParameters || {}) as Record<string, Record<string, unknown>>;
  for (const key of Object.keys(params)) {
    const p = params[key] || {};
    const label = String(p.name || p.id || key);
    text = text.replace(new RegExp(`\\{${key}\\}`, "g"), `@${label}`);
  }
  return cleanDisplay(text);
}

function talkRoomHref(base: string, room: Record<string, unknown> | undefined, token: string) {
  const root = base.replace(/\/$/, "");
  const t = String(room?.token || token || "");
  if (!t) return `${root}/index.php/apps/spreed/`;
  return `${root}/index.php/call/${encodeURIComponent(t)}`;
}

function fileExt(name: string) {
  const m = String(name || "").match(/\.([a-z0-9]+)$/i);
  return m ? m[1].toLowerCase() : "";
}

function isOfficeExt(ext: string) {
  return ["doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "odp"].includes(ext);
}

function fileTone(ext: string) {
  if (["png", "jpg", "jpeg", "gif", "webp", "svg", "heic"].includes(ext)) return "media";
  if (["mp3", "flac", "wav", "m4a", "aac", "ogg"].includes(ext)) return "audio";
  if (["mp4", "mkv", "mov", "webm", "avi"].includes(ext)) return "video";
  if (ext === "pdf") return "pdf";
  if (["doc", "docx", "odt", "txt", "md", "rtf"].includes(ext)) return "doc";
  if (["xls", "xlsx", "csv", "ods"].includes(ext)) return "sheet";
  if (["zip", "rar", "7z", "tar", "gz"].includes(ext)) return "archive";
  if (["js", "ts", "json", "xml", "yml", "yaml", "py", "sh", "css", "html"].includes(ext)) return "code";
  return "file";
}

function FolderGlyph({ large = false }: { large?: boolean }) {
  return (
    <svg className={large ? "nc-folder-glyph" : "nc-file-icon"} viewBox="0 0 24 24" aria-hidden="true">
      <path fill="currentColor" d="M10 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-8l-2-2z" opacity="0.92" />
      <path fill="currentColor" d="M2 10h20v8a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-8z" opacity="0.55" />
    </svg>
  );
}

function onlyOfficeHref(base: string, fileId: string | null) {
  if (!fileId) return null;
  return `${base.replace(/\/$/, "")}/index.php/apps/onlyoffice/${encodeURIComponent(fileId)}`;
}

function filesBrowseHref(base: string, item: DavFile) {
  const root = base.replace(/\/$/, "");
  if (item.fileId) return `${root}/index.php/f/${encodeURIComponent(item.fileId)}`;
  if (item.isDir) return `${root}/index.php/apps/files/?dir=${encodeURIComponent(item.path)}`;
  const parent = item.path.split("/").slice(0, -1).join("/") || "/";
  return `${root}/index.php/apps/files/?dir=${encodeURIComponent(parent)}&openfile=${encodeURIComponent(item.name)}`;
}

function shareTypeLabel(type: unknown) {
  const t = Number(type);
  if (t === 0) return "User";
  if (t === 1) return "Group";
  if (t === 3) return "Public link";
  if (t === 4) return "Email";
  if (t === 6) return "Federated";
  if (t === 7) return "Circle";
  if (t === 10) return "Room";
  return "Share";
}

function sharePublicUrl(share: Record<string, unknown>, base: string) {
  const url = String(share.url || share.share_url || "");
  if (url) return url;
  const token = String(share.token || "");
  if (token) return `${base.replace(/\/$/, "")}/index.php/s/${encodeURIComponent(token)}`;
  return "";
}

function dayKey(iso: string | null) {
  if (!iso) return "";
  const d = new Date(iso);
  if (!Number.isFinite(d.getTime())) return String(iso).slice(0, 10);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export default function Widget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "nextcloud";

  const [tab, setTab] = useState<NcTab>("overview");
  const [meta, setMeta] = useState<OverviewMeta | null>(null);
  const [data, setData] = useState<TabData | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState("");

  const [filesMode, setFilesMode] = useState<FilesMode>("browse");
  const [filesPath, setFilesPath] = useState("/");
  const [talkRoom, setTalkRoom] = useState("");
  const [talkDraft, setTalkDraft] = useState("");
  const [contactsQuery, setContactsQuery] = useState("");
  const [contactModal, setContactModal] = useState(false);
  const [contactForm, setContactForm] = useState({ name: "", email: "", phone: "", bookPath: "" });
  const [calMonth, setCalMonth] = useState(() => {
    const n = new Date();
    return new Date(n.getFullYear(), n.getMonth(), 1);
  });
  const [calDay, setCalDay] = useState(() => dayKey(new Date().toISOString()));
  const [taskTitle, setTaskTitle] = useState("");
  const [taskListPath, setTaskListPath] = useState("");
  const [newListName, setNewListName] = useState("");
  const [showNewList, setShowNewList] = useState(false);
  const talkMessagesRef = useRef<HTMLDivElement | null>(null);

  const loadTab = useCallback(
    async (nextTab: NcTab, opts?: { soft?: boolean }) => {
      if (!opts?.soft) setLoading(true);
      try {
        const q = new URLSearchParams({
          instance: instanceId,
          tab: nextTab,
        });
        if (nextTab === "files") {
          q.set("filesMode", filesMode);
          q.set("filesPath", filesPath);
        }
        if (nextTab === "talk" && talkRoom) q.set("talkRoom", talkRoom);
        if (nextTab === "contacts" && contactsQuery) q.set("contactsQuery", contactsQuery);
        const r = await fetch(`/api/widgets/nextcloud/status?${q.toString()}`);
        const j = await r.json();
        if (!r.ok) throw new Error(j.error || "Failed to load Nextcloud");
        setData(j);
        setError("");
        if (nextTab === "overview") {
          setMeta({
            href: j.href,
            openFallbackUrl: j.openFallbackUrl,
            connectionSource: j.connectionSource,
            version: j.version || null,
            storage: j.storage,
            info: j.info || {},
            health: j.health || {},
            users: j.users || [],
            shares: j.shares || [],
            activity: j.activity || [],
            notifications: j.notifications || [],
            rooms: j.rooms || [],
            mounts: j.mounts || [],
            calendar: j.calendar || [],
            talkMissing: j.talkMissing,
            user: j.user,
            status: j.status,
          });
        } else if (j.href) {
          setMeta((prev) =>
            prev?.href
              ? prev
              : {
                  href: j.href,
                  openFallbackUrl: j.openFallbackUrl,
                  connectionSource: j.connectionSource,
                  version: null,
                  storage: { used: 0, free: null, total: null, pct: null },
                  info: {},
                  health: {},
                  users: [],
                  shares: [],
                  activity: [],
                  notifications: [],
                  rooms: [],
                  mounts: [],
                  calendar: [],
                },
          );
        }
      } catch (e) {
        setError(e instanceof Error ? e.message : "Nextcloud unavailable");
      } finally {
        setLoading(false);
      }
    },
    [instanceId, filesMode, filesPath, talkRoom, contactsQuery],
  );

  useEffect(() => {
    void loadTab(tab);
  }, [tab, filesMode, filesPath, talkRoom]); // eslint-disable-line react-hooks/exhaustive-deps

  const pollMs = tab === "talk" && talkRoom ? TALK_POLL_MS : POLL_MS;
  const softPoll = useCallback(() => {
    void loadTab(tab, { soft: true });
  }, [loadTab, tab]);
  const { rootRef } = useWidgetPoll(softPoll, { intervalMs: pollMs });

  useEffect(() => {
    if (tab !== "talk" || !talkRoom) return;
    const el = talkMessagesRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [tab, talkRoom, data?.messages]);

  async function runAction(op: string, payload: Record<string, unknown> = {}) {
    setBusy(op);
    try {
      const r = await fetch("/api/widgets/nextcloud/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, op, payload }),
      });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "Action failed");
      if (op === "talk-send" && Array.isArray(j.messages)) {
        setData((prev) => (prev ? { ...prev, messages: j.messages } : prev));
        setTalkDraft("");
      } else {
        await loadTab(tab, { soft: true });
      }
      return j;
    } finally {
      setBusy("");
    }
  }

  const rawHref = meta?.href || String(data?.href || "");
  const rawOpenFallbackUrl = meta?.openFallbackUrl || String(data?.openFallbackUrl || "");
  const href = useOpenHref(rawHref, rawOpenFallbackUrl);
  const isOnline = Boolean(meta || data) && !error;
  const statusLabel = !isOnline
    ? "Offline"
    : meta?.status?.maintenance
      ? "Maintenance"
      : "Online";
  const statusClass = !isOnline
    ? "nc-stat-pill--offline"
    : meta?.status?.maintenance
      ? "nc-stat-pill--warn"
      : "nc-stat-pill--ok";
  const talkUnread = useMemo(
    () => (meta?.rooms || []).reduce((n, r) => n + Number(r.unreadMessages || 0), 0),
    [meta?.rooms],
  );
  const alertCount = meta?.notifications?.length || 0;

  const crumbs = useMemo(() => {
    const parts = filesPath.split("/").filter(Boolean);
    const out: { label: string; path: string }[] = [{ label: "Home", path: "/" }];
    let acc = "";
    for (const p of parts) {
      acc += `/${p}`;
      out.push({ label: p, path: acc });
    }
    return out;
  }, [filesPath]);

  const calendarEvents = (Array.isArray(data?.calendar) ? data?.calendar : meta?.calendar || []) as CalendarEvent[];
  const tasks = (Array.isArray(data?.tasks) ? data.tasks : []) as TaskItem[];
  const taskLists = (Array.isArray(data?.taskLists) ? data.taskLists : []) as Array<{ path: string; name: string }>;

  const monthCells = useMemo(() => {
    const year = calMonth.getFullYear();
    const month = calMonth.getMonth();
    const firstDow = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const todayKey = dayKey(new Date().toISOString());
    const cells: { key: string; day: number; pad?: boolean; count: number; today?: boolean }[] = [];
    for (let i = 0; i < firstDow; i++) cells.push({ key: `pad-${i}`, day: 0, pad: true, count: 0 });
    for (let d = 1; d <= daysInMonth; d++) {
      const key = `${year}-${String(month + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
      const count = calendarEvents.filter((e) => dayKey(e.start) === key).length;
      cells.push({ key, day: d, count, today: key === todayKey });
    }
    return cells;
  }, [calMonth, calendarEvents]);

  const dayEvents = calendarEvents.filter((e) => dayKey(e.start) === calDay);
  const dayLabel = (() => {
    const d = new Date(`${calDay}T12:00:00`);
    if (!Number.isFinite(d.getTime())) return calDay;
    return d.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
  })();

  function renderOverview() {
    const storage = meta?.storage;
    if (!storage) return <div className="nc-empty">{error || "Loading…"}</div>;
    const hasTotal = storage.total != null && storage.total > 0;
    const pct = hasTotal && storage.pct != null ? storage.pct : 0;
    const pctLabel =
      hasTotal && storage.pct != null ? `${storage.pct.toFixed(storage.pct < 10 ? 1 : 0)}%` : "—";
    const user = meta?.user || {};
    const display = cleanDisplay(user["display-name"] || user.displayname || user.id || "Account");
    const info = meta?.info || {};
    const health = meta?.health || {};
    const lastLogin = fmtRelative(user.lastLogin || user.lastLoginTimestamp);
    const activity = meta?.activity || [];

    return (
      <div className="nc-overview">
        <div className="nc-quota">
          <div className="nc-quota-top">
            <div>
              <div className="nc-quota-label">Storage used</div>
              <div className="nc-quota-value">
                {fmtBytes(storage.used)}
                {hasTotal ? <span className="nc-quota-of">of {fmtBytes(storage.total)}</span> : null}
              </div>
            </div>
            <div className={`nc-quota-pct${!hasTotal ? " nc-quota-pct--unlimited" : ""}`}>{pctLabel}</div>
          </div>
          <div className={`nc-bar-track${!hasTotal ? " nc-bar-track--unlimited" : ""}`}>
            <div className="nc-bar-fill" style={{ width: `${hasTotal ? pct : 0}%` }} />
          </div>
          <div className="nc-quota-sub">
            {hasTotal ? `${fmtBytes(storage.free)} free · ${display}` : `${display} · disk size unavailable`}
            {lastLogin ? ` · last login ${lastLogin}` : ""}
          </div>
        </div>

        <div className="nc-stats-grid">
          <div className="nc-stat-card">
            <div className="nc-stat-num">{fmtInt(info.users ?? meta?.users?.length)}</div>
            <div className="nc-stat-label">Users</div>
          </div>
          <div className="nc-stat-card">
            <div className="nc-stat-num">{fmtInt(info.shareCount ?? meta?.shares?.length)}</div>
            <div className="nc-stat-label">Shares</div>
          </div>
          <div className="nc-stat-card">
            <div className="nc-stat-num">{fmtInt(activity.length)}</div>
            <div className="nc-stat-label">Activity</div>
          </div>
          <div className="nc-stat-card">
            <div className="nc-stat-num">{fmtInt(meta?.notifications?.length)}</div>
            <div className="nc-stat-label">Alerts</div>
          </div>
        </div>

        {info.hasServerinfo && info.files != null ? (
          <div className="nc-meta-row nc-meta-row--secondary">
            <span>{fmtInt(info.files)} files on server</span>
            <span>{info.active24h != null ? `${fmtInt(info.active24h)} active 24h` : ""}</span>
          </div>
        ) : null}

        {talkUnread > 0 ? (
          <div className="nc-meta-row">
            <span className="nc-badge nc-badge--info">{talkUnread} talk unread</span>
          </div>
        ) : null}

        {(meta?.calendar || []).length ? (
          <div className="nc-section">
            <div className="nc-section-label">Upcoming</div>
            <div className="nc-chip-row">
              {(meta?.calendar || []).slice(0, 5).map((ev) => (
                <div className="nc-pill" key={ev.uid || `${ev.summary}-${ev.start}`}>
                  <span className="nc-pill-title">{cleanDisplay(ev.summary) || "Event"}</span>
                  <span className="nc-pill-sub">{fmtRelative(ev.start) || dayKey(ev.start)}</span>
                </div>
              ))}
            </div>
          </div>
        ) : null}

        {health.hasServerinfo ? (
          <div className="nc-section">
            <div className="nc-section-label">Admin health</div>
            <div className="nc-list">
              <div className="nc-row nc-row--compact">
                <div className="nc-row-body">
                  <div className="nc-row-title">Version {String(health.version || "—")}</div>
                  <div className="nc-row-sub">
                    {[health.php ? `PHP ${health.php}` : "", health.db ? `DB ${health.db}` : ""]
                      .filter(Boolean)
                      .join(" · ") || "Serverinfo"}
                  </div>
                </div>
              </div>
              {Number(health.appUpdates) > 0 ? (
                <div className="nc-row nc-row--compact">
                  <div className="nc-row-body">
                    <div className="nc-row-title">{fmtInt(health.appUpdates)} app updates</div>
                  </div>
                </div>
              ) : null}
              {Array.isArray(health.warnings)
                ? (health.warnings as string[]).map((w) => (
                    <div className="nc-row nc-row--compact" key={w}>
                      <div className="nc-row-body">
                        <div className="nc-row-title">{w}</div>
                      </div>
                    </div>
                  ))
                : null}
            </div>
          </div>
        ) : null}

        {(meta?.mounts || []).length ? (
          <div className="nc-section">
            <div className="nc-section-label">External storage</div>
            <div className="nc-list">
              {(meta?.mounts || []).slice(0, 8).map((m, i) => (
                <div className="nc-row nc-row--compact" key={String(m.id || m.mount_id || i)}>
                  <div className="nc-row-body">
                    <div className="nc-row-title">{String(m.name || m.mount_point || "Mount")}</div>
                    <div className="nc-row-sub">{String(m.type || m.storage || m.backend || "")}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : null}

        <div className="nc-section">
          <div className="nc-section-label">Recent activity</div>
          <div className="nc-list">
            {activity.slice(0, 8).map((item, index) => (
              <div className="nc-row nc-row--compact" key={String(item.activity_id || index)}>
                <div className="nc-row-body">
                  <div className="nc-row-title">{cleanDisplay(item.subject || item.message || "Activity")}</div>
                  <div className="nc-row-sub">
                    {[item.app, fmtRelative(item.datetime || item.timestamp)].filter(Boolean).join(" · ")}
                  </div>
                </div>
              </div>
            ))}
            {!activity.length ? <div className="nc-muted">No recent activity</div> : null}
          </div>
        </div>
      </div>
    );
  }

  function renderFiles() {
    const files = (Array.isArray(data?.files) ? data.files : []) as DavFile[];
    const dirs = files.filter((f) => f.isDir);
    const rest = files.filter((f) => !f.isDir);
    const modes: { key: FilesMode; label: string }[] = [
      { key: "browse", label: "Browse" },
      { key: "favorites", label: "Favorites" },
      { key: "recent", label: "Recent" },
      { key: "trash", label: "Trash" },
    ];
    const listItems = filesMode === "browse" ? rest : files;
    return (
      <div className="nc-files">
        <div className="nc-files-modes">
          {modes.map((m) => (
            <button
              key={m.key}
              type="button"
              className={`nc-mode${filesMode === m.key ? " nc-mode--active" : ""}`}
              onClick={() => {
                setFilesMode(m.key);
                if (m.key !== "browse") setFilesPath("/");
              }}
            >
              {m.label}
            </button>
          ))}
        </div>
        {filesMode === "browse" ? (
          <div className="nc-files-breadcrumb">
            {crumbs.map((c, i) => (
              <button key={c.path} type="button" className="nc-crumb" onClick={() => setFilesPath(c.path)}>
                {i > 0 ? <span className="nc-crumb-sep"> / </span> : null}
                {c.label}
              </button>
            ))}
          </div>
        ) : null}
        {data?.error ? <div className="nc-empty">{String(data.error)}</div> : null}
        {!data?.error && !files.length ? (
          <div className="nc-files-empty">
            <FolderGlyph large />
            <div className="nc-files-empty-title">{filesMode === "browse" ? "Empty folder" : "Nothing here"}</div>
            <div className="nc-files-empty-sub">Nothing here yet</div>
          </div>
        ) : null}
        {!data?.error && files.length ? (
          <>
            <div className="nc-files-meta">
              {filesMode === "browse" ? (
                <>
                  <span>
                    {dirs.length} folder{dirs.length === 1 ? "" : "s"}
                  </span>
                  <span className="nc-files-dot">·</span>
                  <span>
                    {rest.length} file{rest.length === 1 ? "" : "s"}
                  </span>
                </>
              ) : (
                <span>
                  {files.length} item{files.length === 1 ? "" : "s"}
                </span>
              )}
            </div>
            <div className="nc-files-scroll">
              {filesMode === "browse" && dirs.length ? (
                <div className="nc-folder-grid">
                  {dirs.map((item, i) => (
                    <button
                      key={item.path}
                      type="button"
                      className="nc-folder-tile"
                      style={{ ["--nc-i" as string]: i }}
                      onClick={() => {
                        setFilesMode("browse");
                        setFilesPath(item.path);
                      }}
                    >
                      <div className="nc-folder-tile-art">
                        <FolderGlyph large />
                      </div>
                      <div className="nc-folder-tile-body">
                        <div className="nc-folder-tile-name">{item.name}</div>
                        <div className="nc-folder-tile-meta">
                          {item.size != null ? <span>{fmtBytes(item.size)}</span> : null}
                          {item.modified ? <span>{fmtRelative(item.modified)}</span> : null}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              ) : null}
              {listItems.length ? (
                <div className="nc-files-section">
                  {filesMode === "browse" ? <div className="nc-files-section-label">Files</div> : null}
                  <div className="nc-file-list">
                    {listItems.map((item, i) => {
                      const ext = fileExt(item.name);
                      const oo = !item.isDir && isOfficeExt(ext) ? onlyOfficeHref(href, item.fileId) : null;
                      const openHref = oo || filesBrowseHref(href, item);
                      return (
                        <div
                          className={`nc-file-item${item.isDir ? " nc-file-item--dir" : ""}`}
                          key={`${item.path}-${item.name}`}
                          style={{ ["--nc-i" as string]: i }}
                        >
                          {item.isDir ? (
                            <FolderGlyph />
                          ) : (
                            <span className={`nc-file-badge nc-file-badge--${fileTone(ext)}`}>
                              {(ext || "FILE").slice(0, 4).toUpperCase()}
                            </span>
                          )}
                          <a
                            className="nc-row-body nc-row-body--link"
                            href={item.isDir ? undefined : openHref}
                            onClick={
                              item.isDir
                                ? (e) => {
                                    e.preventDefault();
                                    setFilesMode("browse");
                                    setFilesPath(item.path);
                                  }
                                : undefined
                            }
                            target={item.isDir ? undefined : "_blank"}
                            rel={item.isDir ? undefined : "noopener noreferrer"}
                          >
                            <div className="nc-row-title">{item.name}</div>
                            <div className="nc-row-sub">
                              {filesMode === "trash"
                                ? [item.originalLocation || "Trash", fmtRelative(item.deletedAt || item.modified)]
                                    .filter(Boolean)
                                    .join(" · ")
                                : [
                                    item.isDir ? "Folder" : ext ? ext.toUpperCase() : "",
                                    item.size != null ? fmtBytes(item.size) : "",
                                    fmtRelative(item.modified),
                                  ]
                                    .filter(Boolean)
                                    .join(" · ")}
                            </div>
                          </a>
                          <div className="nc-file-actions">
                            {filesMode === "trash" ? (
                              <button
                                type="button"
                                className="nc-file-action"
                                disabled={busy === "restore-trash"}
                                onClick={() =>
                                  void runAction("restore-trash", {
                                    href: item.href,
                                    path: item.path,
                                    trashName: item.trashName || item.name,
                                    name: item.name,
                                  })
                                }
                              >
                                Restore
                              </button>
                            ) : null}
                            {oo ? (
                              <a className="nc-file-action" href={oo} target="_blank" rel="noopener noreferrer">
                                OO
                              </a>
                            ) : !item.isDir ? (
                              <a className="nc-file-open" href={openHref} target="_blank" rel="noopener noreferrer">
                                →
                              </a>
                            ) : null}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : null}
            </div>
          </>
        ) : null}
      </div>
    );
  }

  function renderTalk() {
    if (data?.talkMissing) {
      return (
        <div className="nc-empty nc-empty--soft">
          <div className="nc-files-empty-title">Talk is not enabled</div>
          <a className="nc-mini-link" href={`${href}/index.php/settings/apps`} target="_blank" rel="noopener noreferrer">
            Open Apps
          </a>
        </div>
      );
    }
    if (data?.talkError) return <div className="nc-empty">{String(data.talkError)}</div>;
    const rooms = (Array.isArray(data?.rooms) ? data.rooms : meta?.rooms || []) as Array<Record<string, unknown>>;
    if (!talkRoom) {
      if (!rooms.length) return <div className="nc-empty">No Talk conversations yet</div>;
      const unreadN = rooms.filter(
        (r) => Number(r.unreadMessages || 0) > 0 || r.unreadMention || r.unreadMentionDirect,
      ).length;
      return (
        <div className="nc-talk">
          <div className="nc-files-meta">
            {unreadN} with unread · {rooms.length} chat{rooms.length === 1 ? "" : "s"}
          </div>
          <div className="nc-files-scroll">
            <div className="nc-list">
              {rooms.map((room) => {
                const token = String(room.token || "");
                const unread = Number(room.unreadMessages || 0);
                const mention = Boolean(room.unreadMentionDirect || room.unreadMention);
                const lastMsg =
                  room.lastMessage && typeof room.lastMessage === "object"
                    ? (room.lastMessage as Record<string, unknown>)
                    : null;
                const lastText = cleanDisplay(lastMsg?.message || "").slice(0, 70);
                const when = fmtRelative(room.lastActivity || lastMsg?.timestamp);
                const badges = [unread ? `${unread} unread` : "", mention ? "mention" : "", room.hasCall ? "in call" : ""]
                  .filter(Boolean)
                  .join(" · ");
                return (
                  <button
                    key={token}
                    type="button"
                    className="nc-row nc-row--btn"
                    onClick={() => setTalkRoom(token)}
                  >
                    <span className={`nc-dot ${mention ? "nc-dot--warn" : unread ? "nc-dot--info" : "nc-dot--ok"}`} />
                    <div className="nc-row-body">
                      <div className="nc-row-title">{String(room.displayName || room.name || "Room")}</div>
                      <div className="nc-row-sub">
                        {[badges || when || "Open chat", lastText].filter(Boolean).join(" · ")}
                      </div>
                    </div>
                    <span className="nc-file-open">→</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      );
    }
    const messages = (Array.isArray(data?.messages) ? data.messages : []) as Array<Record<string, unknown>>;
    const room = rooms.find((r) => String(r.token) === talkRoom);
    const myId = String(data?.userId || meta?.user?.id || "").toLowerCase();
    const roomName = String(room?.displayName || room?.name || "Conversation");
    const external = talkRoomHref(href, room, talkRoom);

    return (
      <div className="nc-talk-chat">
        <div className="nc-talk-chat-hdr">
          <button type="button" className="nc-talk-back" onClick={() => setTalkRoom("")} title="Back to chats">
            ←
          </button>
          <div className="nc-talk-chat-title">
            <div className="nc-row-title">{roomName}</div>
            <div className="nc-row-sub">In-widget chat</div>
          </div>
          {href ? (
            <a className="nc-mini-link" href={external} target="_blank" rel="noopener noreferrer">
              Open
            </a>
          ) : null}
        </div>

        {data?.chatError && !messages.length ? (
          <div className="nc-empty">{String(data.chatError)}</div>
        ) : (
          <div className="nc-talk-wall">
            <div className="nc-talk-messages" ref={talkMessagesRef}>
              {messages.map((m) => {
                const system = m.messageType === "system" || Boolean(m.systemMessage);
                const text = formatTalkMessageText(m) || cleanDisplay(m.systemMessage) || "Message";
                const when = fmtRelative(m.timestamp);
                const who = String(m.actorDisplayName || m.actorId || "Someone");
                const mine =
                  String(m.actorId || "").toLowerCase() === myId && String(m.actorType || "") === "users";
                if (system) {
                  return (
                    <div className="nc-talk-system" key={String(m.id)}>
                      <span>{text}</span>
                      {when ? <span className="nc-talk-system-when">{when}</span> : null}
                    </div>
                  );
                }
                return (
                  <div className={`nc-talk-bubble${mine ? " nc-talk-bubble--mine" : ""}`} key={String(m.id)}>
                    {!mine ? <div className="nc-talk-author">{who}</div> : null}
                    <div className="nc-talk-text">{text}</div>
                    {when ? <div className="nc-talk-meta">{when}</div> : null}
                  </div>
                );
              })}
              {!messages.length ? <div className="nc-empty">No messages yet — say hello</div> : null}
            </div>

            <form
              className="nc-talk-composer"
              onSubmit={(e: FormEvent) => {
                e.preventDefault();
                if (!talkDraft.trim()) return;
                void runAction("talk-send", { token: talkRoom, message: talkDraft.trim() });
              }}
            >
              <input
                className="nc-talk-input"
                value={talkDraft}
                onChange={(e) => setTalkDraft(e.target.value)}
                placeholder="Write a message…"
                maxLength={32000}
                autoComplete="off"
                disabled={busy === "talk-send"}
              />
              <button className="nc-talk-send" type="submit" disabled={busy === "talk-send" || !talkDraft.trim()}>
                {busy === "talk-send" ? "…" : "Send"}
              </button>
            </form>
            {data?.chatError && messages.length ? (
              <div className="nc-talk-send-error">{String(data.chatError)}</div>
            ) : null}
          </div>
        )}
      </div>
    );
  }

  function renderCalendar() {
    if (data?.calendarError && data?.tasksError) {
      return <div className="nc-empty">{String(data.calendarError || data.tasksError)}</div>;
    }
    const openTasks = tasks.filter((t) => !t.completed);
    const doneN = tasks.filter((t) => t.completed).length;
    return (
      <div className="nc-cal-split">
        <div className="nc-cal-pane nc-cal-pane--tasks">
          <div className="nc-cal-pane-hdr">
            <div className="nc-section-label">Tasks</div>
            {href ? (
              <a className="nc-mini-link" href={`${href}/index.php/apps/calendar/`} target="_blank" rel="noopener noreferrer">
                Calendar
              </a>
            ) : null}
          </div>
          <form
            className="nc-task-create"
            onSubmit={(e: FormEvent) => {
              e.preventDefault();
              if (!taskTitle.trim()) return;
              void runAction("create-task", {
                summary: taskTitle.trim(),
                listPath: taskListPath || taskLists[0]?.path,
                dueKey: calDay,
              }).then(() => setTaskTitle(""));
            }}
          >
            <input
              className="nc-task-input"
              value={taskTitle}
              onChange={(e) => setTaskTitle(e.target.value)}
              placeholder="New task…"
              maxLength={500}
            />
            <button className="nc-task-add" type="submit" disabled={busy === "create-task"} title="Add task">
              +
            </button>
          </form>
          <div className="nc-task-create-row">
            <select
              className="nc-task-select"
              value={taskListPath || taskLists[0]?.path || ""}
              onChange={(e) => setTaskListPath(e.target.value)}
            >
              {taskLists.length ? (
                taskLists.map((l) => (
                  <option key={l.path} value={l.path}>
                    {l.name}
                  </option>
                ))
              ) : (
                <option value="">New list on first task</option>
              )}
            </select>
            <button type="button" className="nc-task-list-toggle" onClick={() => setShowNewList((v) => !v)}>
              + List
            </button>
          </div>
          {showNewList ? (
            <form
              className="nc-task-create nc-task-create--list"
              onSubmit={(e: FormEvent) => {
                e.preventDefault();
                if (!newListName.trim()) return;
                void runAction("create-task-list", { name: newListName.trim() }).then(() => {
                  setNewListName("");
                  setShowNewList(false);
                });
              }}
            >
              <input
                className="nc-task-input"
                value={newListName}
                onChange={(e) => setNewListName(e.target.value)}
                placeholder="List name…"
                maxLength={120}
              />
              <button className="nc-task-add" type="submit" disabled={busy === "create-task-list"}>
                Add
              </button>
            </form>
          ) : null}
          <div className="nc-files-meta">
            {openTasks.length} open
            {doneN ? ` · ${doneN} done` : ""}
            {taskLists.length ? ` · ${taskLists.length} list${taskLists.length === 1 ? "" : "s"}` : ""}
          </div>
          <div className="nc-cal-pane-scroll">
            {openTasks.length ? (
              <div className="nc-task-list">
                {openTasks.slice(0, 40).map((t) => {
                  const overdue = t.due ? Date.parse(t.due) < Date.now() : false;
                  return (
                    <div className={`nc-task-item${overdue ? " nc-task-item--overdue" : ""}`} key={t.uid}>
                      <span className="nc-task-check" aria-hidden="true" />
                      <div className="nc-task-body">
                        <div className="nc-task-title">{cleanDisplay(t.summary)}</div>
                        <div className="nc-task-sub">
                          {[t.listName, t.due ? dayKey(t.due) : ""].filter(Boolean).join(" · ") || "Task"}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="nc-muted">No open tasks yet</div>
            )}
          </div>
        </div>

        <div className="nc-cal-pane">
          <div className="nc-month">
            <div className="nc-month-hdr">
              <button
                type="button"
                className="nc-month-nav"
                aria-label="Previous month"
                onClick={() => setCalMonth(new Date(calMonth.getFullYear(), calMonth.getMonth() - 1, 1))}
              >
                ‹
              </button>
              <div className="nc-month-label">
                {calMonth.toLocaleString("en-US", { month: "long", year: "numeric" })}
              </div>
              <button
                type="button"
                className="nc-month-nav"
                aria-label="Next month"
                onClick={() => setCalMonth(new Date(calMonth.getFullYear(), calMonth.getMonth() + 1, 1))}
              >
                ›
              </button>
            </div>
            <div className="nc-month-dows">
              {["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"].map((w) => (
                <div className="nc-cal-dow" key={w}>
                  {w}
                </div>
              ))}
            </div>
            <div className="nc-month-grid">
              {monthCells.map((c) =>
                c.pad ? (
                  <div className="nc-cal-day nc-cal-day--pad" key={c.key} />
                ) : (
                  <button
                    key={c.key}
                    type="button"
                    className={`nc-cal-day${c.today ? " nc-cal-day--today" : ""}${c.key === calDay ? " nc-cal-day--selected" : ""}${c.count ? " nc-cal-day--busy" : ""}`}
                    onClick={() => setCalDay(c.key)}
                  >
                    <span className="nc-cal-day-num">{c.day}</span>
                    {c.count ? (
                      <span className="nc-cal-day-dots" title={`${c.count} event${c.count === 1 ? "" : "s"}`}>
                        {"•".repeat(Math.min(c.count, 3))}
                      </span>
                    ) : null}
                  </button>
                ),
              )}
            </div>
          </div>

          <div className="nc-day-events">
            <div className="nc-section-label">
              {dayLabel}
              {dayEvents.length ? ` · ${dayEvents.length}` : ""}
            </div>
            {dayEvents.length ? (
              <div className="nc-cal-list nc-cal-list--compact">
                {dayEvents.map((ev, i) => {
                  const when = ev.allDay
                    ? "All day"
                    : ev.start
                      ? new Date(ev.start).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })
                      : "";
                  return (
                    <a
                      className="nc-cal-row"
                      style={{ ["--nc-i" as string]: i }}
                      key={ev.uid || `${ev.summary}-${ev.start}`}
                      href={href ? `${href}/index.php/apps/calendar/` : undefined}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <div className="nc-cal-when">{when}</div>
                      <div className="nc-cal-body">
                        <div className="nc-row-title">{cleanDisplay(ev.summary) || "Event"}</div>
                        <div className="nc-row-sub">{cleanDisplay(ev.location || ev.calendarName || "Event")}</div>
                      </div>
                    </a>
                  );
                })}
              </div>
            ) : (
              <div className="nc-muted">No events this day</div>
            )}
          </div>
        </div>
      </div>
    );
  }

  function renderContacts() {
    const contacts = (Array.isArray(data?.contacts) ? data.contacts : []) as ContactItem[];
    const books = (Array.isArray(data?.addressbooks) ? data.addressbooks : []) as Array<{ path: string; name: string }>;
    return (
      <div className="nc-contacts">
        <div className="nc-contacts-toolbar">
          <input
            className="nc-search"
            value={contactsQuery}
            onChange={(e) => setContactsQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") void loadTab("contacts");
            }}
            placeholder="Search contacts…"
          />
          <button type="button" className="nc-contact-toggle" onClick={() => void loadTab("contacts")}>
            Search
          </button>
          <button
            type="button"
            className="nc-contact-toggle"
            onClick={() => {
              setContactForm({ name: "", email: "", phone: "", bookPath: books[0]?.path || "" });
              setContactModal(true);
            }}
          >
            + New contact
          </button>
        </div>
        {data?.error ? <div className="nc-empty">{String(data.error)}</div> : null}
        <div className="nc-list">
          {contacts.map((c) => {
            const name = cleanDisplay(c.name);
            const email = cleanDisplay(c.email);
            const phone = cleanDisplay(c.phone);
            const source = cleanDisplay(c.source);
            return (
              <a
                key={c.id}
                className="nc-row nc-row--link"
                href={c.link || `${href}/index.php/apps/contacts/`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <div className="nc-row-body">
                  <div className="nc-row-title">{name}</div>
                  <div className="nc-row-sub">{[email, phone, source].filter(Boolean).join(" · ")}</div>
                </div>
              </a>
            );
          })}
          {!contacts.length && !data?.error ? <div className="nc-empty">No contacts</div> : null}
        </div>
      </div>
    );
  }

  function renderShares() {
    const shares = (Array.isArray(data?.shares) ? data.shares : meta?.shares || []) as Array<Record<string, unknown>>;
    if (!shares.length) return <div className="nc-empty">No shares found for this account</div>;
    return (
      <div className="nc-list">
        {shares.map((share, i) => {
          const path = String(share.path || share.file_target || share.fileTarget || "Shared item");
          const name = String(share.label || path.split("/").filter(Boolean).pop() || path);
          const link = sharePublicUrl(share, href);
          const withWhom = String(
            share.share_with_displayname ||
              share.share_with ||
              share.shareWith ||
              (Number(share.share_type) === 3 ? "Anyone with the link" : ""),
          );
          const sub = [
            shareTypeLabel(share.share_type ?? share.shareType),
            share.item_type || share.itemType || "file",
            share.item_size != null ? fmtBytes(Number(share.item_size)) : "",
            withWhom,
            fmtRelative(share.stime || share.item_mtime),
          ]
            .filter(Boolean)
            .join(" · ");
          const inner = (
            <>
              <span className={`nc-dot ${Number(share.share_type) === 3 ? "nc-dot--info" : "nc-dot--ok"}`} />
              <div className="nc-row-body">
                <div className="nc-row-title">{name}</div>
                <div className="nc-row-sub">{sub}</div>
                {path !== name ? <div className="nc-row-path">{path}</div> : null}
              </div>
            </>
          );
          return link ? (
            <a className="nc-row nc-row--link" href={link} target="_blank" rel="noopener noreferrer" key={String(share.id || i)}>
              {inner}
            </a>
          ) : (
            <div className="nc-row" key={String(share.id || i)}>
              {inner}
            </div>
          );
        })}
      </div>
    );
  }

  function renderActivity() {
    const activity = (Array.isArray(data?.activity) ? data.activity : meta?.activity || []) as Array<
      Record<string, unknown>
    >;
    if (!activity.length) return <div className="nc-empty">No recent activity</div>;
    return (
      <div className="nc-list">
        {activity.map((item, index) => {
          const link = String(item.link || "");
          const inner = (
            <div className="nc-row-body">
              <div className="nc-row-title">{cleanDisplay(item.subject || item.message || "Activity")}</div>
              <div className="nc-row-sub">
                {[item.app, fmtRelative(item.datetime || item.timestamp)].filter(Boolean).join(" · ")}
              </div>
            </div>
          );
          return link ? (
            <a
              className="nc-row nc-row--link"
              href={link.startsWith("http") ? link : `${href}${link}`}
              target="_blank"
              rel="noopener noreferrer"
              key={String(item.activity_id || index)}
            >
              {inner}
            </a>
          ) : (
            <div className="nc-row" key={String(item.activity_id || index)}>
              {inner}
            </div>
          );
        })}
      </div>
    );
  }

  function renderAlerts() {
    const notifications = (Array.isArray(data?.notifications) ? data.notifications : meta?.notifications || []) as Array<
      Record<string, unknown>
    >;
    if (!notifications.length) return <div className="nc-empty">No alerts</div>;
    return (
      <div className="nc-list">
        {notifications.map((n, i) => (
          <div className="nc-row" key={String(n.notification_id || n.id || i)}>
            <div className="nc-row-body">
              <div className="nc-row-title">{cleanDisplay(n.subject || n.app || "Notification")}</div>
              <div className="nc-row-sub">
                {[cleanDisplay(n.message), fmtRelative(n.datetime || n.timestamp)].filter(Boolean).join(" · ")}
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  function renderBody() {
    if (loading && !data && tab !== "overview") {
      return (
        <div className="nc-loading">
          <div className="nc-spinner" />
          <span>Loading…</span>
        </div>
      );
    }
    if (error && !data && !meta) return <div className="nc-empty">{error}</div>;
    if (tab === "overview") return renderOverview();
    if (tab === "files") return renderFiles();
    if (tab === "talk") return renderTalk();
    if (tab === "calendar") return renderCalendar();
    if (tab === "contacts") return renderContacts();
    if (tab === "shares") return renderShares();
    if (tab === "activity") return renderActivity();
    if (tab === "alerts") return renderAlerts();
    return null;
  }

  const contactModalNode =
    contactModal && typeof document !== "undefined"
      ? createPortal(
          <div
            className="nc-modal-layer"
            onClick={(e) => {
              if (e.target === e.currentTarget) setContactModal(false);
            }}
          >
            <div className="nc-modal" role="dialog" aria-modal="true" aria-label="New contact">
              <button type="button" className="nc-modal-close" onClick={() => setContactModal(false)} aria-label="Close">
                ✕
              </button>
              <div className="nc-modal-title">New contact</div>
              <form
                className="nc-contact-form"
                onSubmit={(e: FormEvent) => {
                  e.preventDefault();
                  void runAction("create-contact", contactForm).then(() => {
                    setContactModal(false);
                    void loadTab("contacts", { soft: true });
                  });
                }}
              >
                <label className="nc-contact-field">
                  <span>Name</span>
                  <input
                    className="nc-search-input"
                    required
                    value={contactForm.name}
                    onChange={(e) => setContactForm((f) => ({ ...f, name: e.target.value }))}
                  />
                </label>
                <label className="nc-contact-field">
                  <span>Email</span>
                  <input
                    className="nc-search-input"
                    type="email"
                    value={contactForm.email}
                    onChange={(e) => setContactForm((f) => ({ ...f, email: e.target.value }))}
                  />
                </label>
                <label className="nc-contact-field">
                  <span>Phone</span>
                  <input
                    className="nc-search-input"
                    value={contactForm.phone}
                    onChange={(e) => setContactForm((f) => ({ ...f, phone: e.target.value }))}
                  />
                </label>
                {Array.isArray(data?.addressbooks) && (data.addressbooks as Array<{ path: string; name: string }>).length ? (
                  <label className="nc-contact-field">
                    <span>Address book</span>
                    <select
                      className="nc-search-input"
                      value={contactForm.bookPath}
                      onChange={(e) => setContactForm((f) => ({ ...f, bookPath: e.target.value }))}
                    >
                      {(data.addressbooks as Array<{ path: string; name: string }>).map((b) => (
                        <option key={b.path} value={b.path}>
                          {b.name}
                        </option>
                      ))}
                    </select>
                  </label>
                ) : null}
                <div className="nc-modal-actions">
                  <button type="button" className="nc-file-action nc-file-action--ghost" onClick={() => setContactModal(false)}>
                    Cancel
                  </button>
                  <button type="submit" className="nc-file-action" disabled={busy === "create-contact"}>
                    Create
                  </button>
                </div>
              </form>
            </div>
          </div>,
          document.body,
        )
      : null;

  return (
    <div className="hd-widget-body nc-body-flat" ref={rootRef}>
      <ConnectionCorner source={meta?.connectionSource || "unknown"} />
      <div className={`nc-shell${contactModal ? " nc-shell--modal" : ""}`}>
        <div className="nc-shell-main">
          <div className="nc-toolbar">
            <div className="nc-toolbar-left">
              <span className={`nc-stat-pill ${statusClass}`}>
                <span className="nc-stat-pill-dot" aria-hidden="true" />
                {statusLabel}
              </span>
            </div>
            <div className="nc-toolbar-right">
              {href ? (
                <a className="nc-open-link" href={href} target="_blank" rel="noopener noreferrer">
                  Open
                </a>
              ) : null}
            </div>
          </div>

          <div className="nc-tabs">
            {TABS.map((t) => {
              let label = t.label;
              if (t.key === "talk" && talkUnread) label = `Talk (${talkUnread})`;
              if (t.key === "alerts" && alertCount) label = `Alerts (${alertCount})`;
              return (
                <button
                  key={t.key}
                  type="button"
                  className={`nc-tab${tab === t.key ? " nc-tab--active" : ""}`}
                  onClick={() => {
                    setTab(t.key);
                    if (t.key !== "talk") setTalkRoom("");
                  }}
                >
                  {label}
                </button>
              );
            })}
          </div>

          <div className="nc-body">
            {loading && tab === "overview" && !meta ? (
              <div className="nc-loading">
                <div className="nc-spinner" />
                <span>Connecting to Nextcloud…</span>
              </div>
            ) : (
              renderBody()
            )}
            {error && meta ? <div className="nc-empty">{error}</div> : null}
          </div>
        </div>
      </div>
      {contactModalNode}
    </div>
  );
}
