import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "nextcloud",
  name: "Nextcloud",
  description: "Files, Talk, calendar, contacts, shares, and activity",
  version: "0.2.6",
  category: "Cloud",
  defaultSize: { w: 5, h: 5, minW: 3, minH: 3 },
  hostClass: "nc-host",
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "http://10.0.0.1",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      placeholder: "https://nextcloud.example.com",
    },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url", placeholder: "http://10.0.0.1" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    {
      key: "username",
      label: "Username",
      type: "text",
      required: true,
    },
    {
      key: "password",
      label: "App password",
      type: "password",
      required: true,
    },
    {
      key: "storageTotalGb",
      label: "Storage total (GB, optional)",
      type: "text",
      placeholder: "When quota is unlimited",
    },
  ],
};
