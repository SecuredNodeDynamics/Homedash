"use client";

import { useEffect, useState } from "react";

const KEY = "homedash.notes";

export default function NotesWidget() {
  const [value, setValue] = useState("");

  useEffect(() => {
    try {
      setValue(localStorage.getItem(KEY) || "");
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(KEY, value);
    } catch {
      /* ignore */
    }
  }, [value]);

  return (
    <div className="hd-widget-body">
      <textarea
        className="hd-notes"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="Jot something down…"
        aria-label="Notes"
      />
    </div>
  );
}
