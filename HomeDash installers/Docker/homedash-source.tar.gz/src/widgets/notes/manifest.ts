import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "notes",
  name: "Notes",
  description: "Quick scratch pad stored in the browser",
  version: "0.1.0",
  category: "Productivity",
  hostClass: "hd-system-host",
  defaultSize: { w: 4, h: 4, minW: 2, minH: 2 },
  configFields: [],
};
