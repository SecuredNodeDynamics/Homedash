"use client";
import "@/styles/widgets/pagespeed.widget.css";

import { useCallback, useState } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type Strategy = "mobile" | "desktop";

type Metric = {
  key: string;
  label: string;
  displayValue: string;
  score: number | null;
};

type Result = {
  requestedUrl: string;
  finalUrl: string;
  strategy: Strategy;
  fetchedAt: string;
  scores: {
    performance: number | null;
    accessibility: number | null;
    bestPractices: number | null;
    seo: number | null;
  };
  metrics: Metric[];
  reportUrl: string;
};

const RING_RADIUS = 24;
const RING_CIRCUMFERENCE = 2 * Math.PI * RING_RADIUS;

function scoreBand(score: number | null): "good" | "ok" | "poor" {
  if (score == null) return "poor";
  if (score >= 90) return "good";
  if (score >= 50) return "ok";
  return "poor";
}

function metricBand(score: number | null): "good" | "ok" | "poor" | "neutral" {
  if (score == null) return "neutral";
  if (score >= 0.9) return "good";
  if (score >= 0.5) return "ok";
  return "poor";
}

function fmtTime(iso: string) {
  try {
    return new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  } catch {
    return "";
  }
}

function ScoreRing({ label, score }: { label: string; score: number | null }) {
  const band = scoreBand(score);
  const pct = score == null ? 0 : Math.max(0, Math.min(100, score));
  const dash = (pct / 100) * RING_CIRCUMFERENCE;

  return (
    <div className="ps-score-card">
      <div className={`ps-score-ring ps-score-ring--${band}`}>
        <svg viewBox="0 0 56 56">
          <circle className="ps-score-ring-track" cx="28" cy="28" r={RING_RADIUS} />
          <circle
            className="ps-score-ring-fill"
            cx="28"
            cy="28"
            r={RING_RADIUS}
            strokeDasharray={`${dash} ${RING_CIRCUMFERENCE}`}
          />
        </svg>
        <span className="ps-score-value">{score == null ? "—" : score}</span>
      </div>
      <span className="ps-score-label">{label}</span>
    </div>
  );
}

export default function PagespeedWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "pagespeed";

  const [url, setUrl] = useState("");
  const [strategy, setStrategy] = useState<Strategy>("mobile");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<Result | null>(null);
  const [primed, setPrimed] = useState(false);

  const loadDefaults = useCallback(async () => {
    if (primed) return;
    try {
      const response = await fetch(
        `/api/widgets/pagespeed/status?instance=${encodeURIComponent(instanceId)}`,
      );
      const json = await response.json();
      if (response.ok && json.defaultUrl) setUrl((current) => current || json.defaultUrl);
    } catch {
      // Defaults are a convenience only — a failed lookup shouldn't block the widget.
    } finally {
      setPrimed(true);
    }
  }, [instanceId, primed]);

  // Runs once on mount to prefill the default URL; not a live poll.
  const { rootRef } = useWidgetPoll(loadDefaults, { intervalMs: 3_600_000 });

  async function runTest() {
    if (!url.trim() || loading) return;
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/widgets/pagespeed/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, action: "run-test", url, strategy }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "PageSpeed test failed");
      setResult(json);
    } catch (err) {
      setError(err instanceof Error ? err.message : "PageSpeed test failed");
    } finally {
      setLoading(false);
    }
  }

  const statusLabel = loading ? "Testing" : error ? "Error" : result ? "Done" : "Idle";
  const statusClass = loading
    ? "ps-status-pill--running"
    : error
      ? "ps-status-pill--error"
      : result
        ? "ps-status-pill--done"
        : "ps-status-pill--idle";

  return (
    <div className="hd-widget-body ps-body" ref={rootRef}>
      <div className="ps-toolbar">
        <div className="ps-toolbar-left">
          <span className={`ps-status-pill ${statusClass}`}>
            <span className={`ps-status-dot${loading ? " ps-spin" : ""}`} />
            {statusLabel}
          </span>
        </div>
        <div className="ps-toolbar-right">
          <div className="ps-strategy-toggle" role="group" aria-label="Device strategy">
            <button
              type="button"
              className={`ps-strategy-btn${strategy === "mobile" ? " ps-strategy-btn--active" : ""}`}
              disabled={loading}
              onClick={() => setStrategy("mobile")}
            >
              Mobile
            </button>
            <button
              type="button"
              className={`ps-strategy-btn${strategy === "desktop" ? " ps-strategy-btn--active" : ""}`}
              disabled={loading}
              onClick={() => setStrategy("desktop")}
            >
              Desktop
            </button>
          </div>
          {result ? (
            <a
              className="ps-open-link"
              href={result.reportUrl}
              target="_blank"
              rel="noopener noreferrer"
            >
              Open Report
            </a>
          ) : null}
        </div>
      </div>

      <div className="ps-input-row">
        <input
          className="ps-url-input"
          type="text"
          inputMode="url"
          placeholder="https://example.com"
          value={url}
          disabled={loading}
          onChange={(event) => setUrl(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === "Enter") runTest();
          }}
        />
        <button
          type="button"
          className="ps-btn ps-btn--primary"
          disabled={loading || !url.trim()}
          onClick={runTest}
        >
          {loading ? "Running…" : "Run Test"}
        </button>
      </div>

      {error ? <div className="ps-error">⚠ {error}</div> : null}

      <div className="ps-results">
        {loading && !result ? (
          <>
            <div className="ps-skeleton-row" />
            <div className="ps-running-note">Running a Lighthouse audit — this can take up to a minute…</div>
          </>
        ) : null}

        {!loading && !result && !error ? (
          <div className="ps-idle">Enter a website address and run a PageSpeed test</div>
        ) : null}

        {result ? (
          <>
            <div className="ps-section-label">Scores</div>
            <div className="ps-scores-grid">
              <ScoreRing label="Performance" score={result.scores.performance} />
              <ScoreRing label="Accessibility" score={result.scores.accessibility} />
              <ScoreRing label="Best Practices" score={result.scores.bestPractices} />
              <ScoreRing label="SEO" score={result.scores.seo} />
            </div>

            <div className="ps-section-label">Core Metrics</div>
            <div className="ps-metrics">
              {result.metrics.map((metric) => (
                <div className="ps-metric-row" key={metric.key}>
                  <span className={`ps-metric-dot ps-metric-dot--${metricBand(metric.score)}`} />
                  <span className="ps-metric-label">{metric.label}</span>
                  <span className="ps-metric-value">{metric.displayValue}</span>
                </div>
              ))}
            </div>

            <div className="ps-meta">
              <span className="ps-meta-url" title={result.finalUrl}>
                {result.finalUrl}
              </span>
              <span>
                {result.strategy === "desktop" ? "Desktop" : "Mobile"} · {fmtTime(result.fetchedAt)}
              </span>
            </div>
          </>
        ) : null}
      </div>
    </div>
  );
}
