import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "pagespeed",
  name: "PageSpeed",
  description: "Run a Google PageSpeed Insights test on any website",
  version: "0.1.2",
  category: "Dev Tools",
  hostClass: "ps-host",
  defaultSize: { w: 5, h: 4, minW: 4, minH: 3 },
  configFields: [
    {
      key: "defaultUrl",
      label: "Default URL",
      type: "url",
      placeholder: "https://example.com",
    },
  ],
};
