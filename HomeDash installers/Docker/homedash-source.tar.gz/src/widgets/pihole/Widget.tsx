"use client";
import "@/styles/widgets/pihole.widget.css";


import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";
import { useAuthPermission } from "@/lib/use-auth-permission";

type TopItem = { name: string; count: number };
type ConnectionSource = "private" | "public" | "unknown";
type Status = {
  enabled: boolean;
  href: string;
  openFallbackUrl?: string;
  queries: number;
  blocked: number;
  pctBlocked: number;
  domains: number;
  clients: number;
  topBlocked: TopItem[];
  topClients: TopItem[];
  connectionSource?: ConnectionSource;
};

const CONNECTION_SOURCE_LABEL: Record<ConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

const PAUSE_DURATIONS = [
  { label: "30s", seconds: 30 },
  { label: "1m", seconds: 60 },
  { label: "5m", seconds: 5 * 60 },
  { label: "15m", seconds: 15 * 60 },
  { label: "30m", seconds: 30 * 60 },
  { label: "1h", seconds: 60 * 60 },
  { label: "Until on", seconds: 0 },
];

function fmtInt(v: number) {
  return Number(v || 0).toLocaleString();
}

function fmtPct(v: number) {
  return `${Number(v || 0).toFixed(1)}%`;
}

function fmtRemaining(ms: number) {
  if (ms <= 0) return "00:00";
  const s = Math.ceil(ms / 1000);
  const m = Math.floor(s / 60);
  const sec = s % 60;
  return `${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}

function ConnectionCorner({ source }: { source: ConnectionSource }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const mark = (
    <div
      className={`ph-corner-source ph-corner-source--${source}`}
      title={CONNECTION_SOURCE_LABEL[source]}
      aria-label={CONNECTION_SOURCE_LABEL[source]}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}

function MiniList({ title, items }: { title: string; items: TopItem[] }) {
  if (!items.length) {
    return (
      <div className="ph-mini-list">
        <div className="ph-mini-title">{title}</div>
        <div className="ph-mini-empty">No data</div>
      </div>
    );
  }
  const max = Math.max(...items.map((i) => i.count), 1);
  return (
    <div className="ph-mini-list">
      <div className="ph-mini-title">{title}</div>
      {items.map((item) => (
        <div className="ph-mini-row" title={item.name} key={`${title}-${item.name}`}>
          <span className="ph-mini-name">{item.name}</span>
          <span className="ph-mini-count">{fmtInt(item.count)}</span>
          <span className="ph-mini-bar">
            <span style={{ width: `${Math.max(8, (item.count / max) * 100)}%` }} />
          </span>
        </div>
      ))}
    </div>
  );
}

export default function PiholeWidget() {
  const canControlServices = useAuthPermission("widgets.control");
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "pihole";
  const [data, setData] = useState<Status | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [pauseIdx, setPauseIdx] = useState(2);
  const [pauseEndsAt, setPauseEndsAt] = useState(0);
  const [now, setNow] = useState(Date.now());
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch(
        `/api/widgets/pihole/status?instance=${encodeURIComponent(instanceId)}`,
      );
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to load Pi-hole");
      setData(json);
      if (json.enabled) setPauseEndsAt(0);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load Pi-hole");
      setData(null);
    } finally {
      setLoading(false);
    }
  }, [instanceId]);

  const paused = Boolean(data && !data.enabled);
  const intervalMs = paused ? 15_000 : 120_000;
  const { rootRef } = useWidgetPoll(load, { intervalMs });

  useEffect(() => {
    if (!pauseEndsAt) return;
    const t = window.setInterval(() => {
      setNow(Date.now());
      if (Date.now() >= pauseEndsAt) {
        setPauseEndsAt(0);
        load();
      }
    }, 1000);
    return () => window.clearInterval(t);
  }, [pauseEndsAt, load]);

  async function setBlocking(enabled: boolean, seconds = 0) {
    setBusy(true);
    setError("");
    try {
      const res = await fetch("/api/widgets/pihole/blocking", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, enabled, seconds }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to update blocking");
      if (!enabled && seconds > 0) setPauseEndsAt(Date.now() + seconds * 1000);
      else setPauseEndsAt(0);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to update blocking");
    } finally {
      setBusy(false);
    }
  }

  if (loading && !data) {
    return (
      <div className="hd-widget-body ph-body" ref={rootRef}>
        <div className="ph-toolbar">
          <span className="ph-status-pill ph-status-pill--loading">
            <span className="ph-status-dot" />
            Loading
          </span>
        </div>
        <div className="ph-skeleton-card" />
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="hd-widget-body ph-body" ref={rootRef}>
        <div className="ph-toolbar">
          <span className="ph-status-pill ph-status-pill--offline">
            <span className="ph-status-dot" />
            Offline
          </span>
          <button className="ph-open-link" type="button" onClick={load}>
            Retry
          </button>
        </div>
        <div className="ph-inst-error">{error}</div>
      </div>
    );
  }

  if (!data) return <div className="hd-widget-body ph-body" ref={rootRef} />;

  const remaining = pauseEndsAt - now;
  const timedPause = paused && remaining > 0;
  const statusLabel = error ? "Degraded" : paused ? "Paused" : "Protected";
  const statusClass = error
    ? "ph-status-pill--warn"
    : paused
      ? "ph-status-pill--paused"
      : "ph-status-pill--online";
  const protectionLine = timedPause
    ? `Paused · resumes in ${fmtRemaining(remaining)}`
    : paused
      ? "Filtering disabled"
      : "Filtering enabled";

  const connectionSource: ConnectionSource = data.connectionSource || "unknown";

  return (
    <div className={`hd-widget-body ph-body${paused ? " is-paused" : ""}${canControlServices ? "" : " is-readonly"}`} ref={rootRef}>
      <ConnectionCorner source={connectionSource} />
      <div className="ph-toolbar">
        <span className={`ph-status-pill ${statusClass}`}>
          <span className="ph-status-dot" />
          {timedPause ? `Paused · ${fmtRemaining(remaining)}` : statusLabel}
        </span>
        <div className="ph-toolbar-right">
          {openHref ? (
            <a className="ph-open-link" href={openHref} target="_blank" rel="noopener noreferrer">
              Open
            </a>
          ) : null}
        </div>
      </div>

      <div className="ph-stats-row">
        <div className="ph-stat">
          <div className="ph-stat-val">{fmtInt(data.queries)}</div>
          <div className="ph-stat-lbl">Queries</div>
        </div>
        <div className="ph-stat">
          <div className="ph-stat-val ph-stat-val--blocked">{fmtInt(data.blocked)}</div>
          <div className="ph-stat-lbl">Blocked</div>
        </div>
        <div className="ph-stat">
          <div className="ph-stat-val ph-stat-val--rate">{fmtPct(data.pctBlocked)}</div>
          <div className="ph-stat-lbl">Block rate</div>
        </div>
        <div className="ph-stat">
          <div className="ph-stat-val ph-stat-val--list">{fmtInt(data.domains)}</div>
          <div className="ph-stat-lbl">Blocklist</div>
        </div>
      </div>

      <div className={`ph-protection${paused ? " is-paused" : ""}`}>
        <div className="ph-protection__head">
          <div>
            <div className="ph-protection__title">DNS filtering</div>
            <div className={`ph-protection__state${paused ? " is-paused" : ""}`}>
              {protectionLine}
              <span className="ph-protection__meta"> · {fmtInt(data.clients)} clients</span>
            </div>
          </div>
          {paused ? (
            <button
              className="ph-protection__action ph-protection__action--resume"
              type="button"
              disabled={busy}
              onClick={() => setBlocking(true)}
            >
              {busy ? "Enabling…" : "Re-enable now"}
            </button>
          ) : (
            <button
              className="ph-protection__action ph-protection__action--pause"
              type="button"
              disabled={busy}
              onClick={() => setBlocking(false, PAUSE_DURATIONS[pauseIdx]?.seconds || 0)}
            >
              {busy ? "Pausing…" : "Pause"}
            </button>
          )}
        </div>

        {!paused ? (
          <div className="ph-chips" role="group" aria-label="Pause duration">
            {PAUSE_DURATIONS.map((duration, index) => (
              <button
                key={duration.label}
                type="button"
                className={`ph-chip${pauseIdx === index ? " is-active" : ""}`}
                disabled={busy}
                aria-pressed={pauseIdx === index}
                onClick={() => setPauseIdx(index)}
              >
                {duration.label}
              </button>
            ))}
          </div>
        ) : null}
      </div>

      <div className="ph-lists-grid">
        <MiniList title="Top Blocked" items={data.topBlocked} />
        <MiniList title="Top Clients" items={data.topClients} />
      </div>

      {error ? <div className="ph-inst-error">{error}</div> : null}
    </div>
  );
}
