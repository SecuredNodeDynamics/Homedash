import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "pihole",
  name: "Pi-hole",
  description: "DNS ad blocking stats",
  version: "0.1.2",
  category: "Network",
  defaultSize: { w: 4, h: 7, minW: 3, minH: 5 },
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "http://10.0.0.1",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      placeholder: "https://pihole.example.com",
    },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url", placeholder: "http://10.0.0.1" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    {
      key: "apiKey",
      label: "API Key / Password",
      type: "password",
      placeholder: "Optional — app password if Pi-hole login is enabled",
    },
  ],
};
