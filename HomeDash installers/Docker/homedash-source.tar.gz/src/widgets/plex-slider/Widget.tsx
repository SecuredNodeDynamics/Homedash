"use client";
import "@/styles/widgets/plex.slider.widget.css";


import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type Section = {
  key: string;
  title: string;
  type: string;
};

type Item = {
  key: string;
  ratingKey: string;
  type: string;
  title: string;
  subtitle: string;
  year: string | number;
  summary: string;
  thumb: string;
  art: string;
  duration: number;
  sectionTitle: string;
  sectionType: string;
  addedAt: number;
};

const ALL_SECTION: Section = { key: "__all__", title: "Recent", type: "mixed" };

function apiUrl(path: string, params: Record<string, string | number | undefined>) {
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== "") search.set(key, String(value));
  }
  return `/api/widgets/plex-slider/${path}?${search}`;
}

function imageSrc(
  instanceId: string,
  path: string,
  w: number,
  h: number,
  direct = false,
) {
  if (!path) return "";
  return apiUrl("image", {
    instance: instanceId,
    path,
    w,
    h,
    direct: direct ? 1 : undefined,
  });
}

function clamp(value: number, min: number, max: number) {
  return Math.min(Math.max(value, min), max);
}

function formatRuntime(ms?: number) {
  if (!ms) return "";
  const minutes = Math.round(Number(ms) / 60000);
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  const rem = minutes % 60;
  return rem ? `${hours}h ${rem}m` : `${hours}h`;
}

function sectionIcon(type: string) {
  if (type === "movie") return "🎬";
  if (type === "show") return "📺";
  if (type === "artist") return "🎵";
  if (type === "photo") return "🖼";
  return "📁";
}

function cardShape(item: Item) {
  const type = String(item.type || "").toLowerCase();
  const sectionType = String(item.sectionType || "").toLowerCase();
  if (type === "artist" || type === "album" || sectionType === "artist") return "square";
  return "poster";
}

function detailsHref(publicUrl: string, baseUrl: string, ratingKey: string) {
  if (!ratingKey) return publicUrl || baseUrl || "#";
  const href = (publicUrl || baseUrl).replace(/\/$/, "");
  const web = href.endsWith("/web") ? href : `${href}/web`;
  return `${web}#!/server/${encodeURIComponent(baseUrl)}/details?key=${encodeURIComponent(`/library/metadata/${ratingKey}`)}`;
}

function PosterImg({
  src,
  fallbackSrc,
  fallbackLabel,
  className,
}: {
  src: string;
  fallbackSrc?: string;
  fallbackLabel: string;
  className?: string;
}) {
  const [currentSrc, setCurrentSrc] = useState(src);
  const [failed, setFailed] = useState(false);
  const [usedFallback, setUsedFallback] = useState(false);

  useEffect(() => {
    setCurrentSrc(src);
    setFailed(false);
    setUsedFallback(false);
  }, [src]);

  if (!currentSrc || failed) {
    return <span>{fallbackLabel}</span>;
  }

  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      className={className}
      src={currentSrc}
      alt=""
      loading="lazy"
      decoding="async"
      onError={() => {
        if (fallbackSrc && !usedFallback && fallbackSrc !== currentSrc) {
          setUsedFallback(true);
          setCurrentSrc(fallbackSrc);
          return;
        }
        setFailed(true);
      }}
    />
  );
}

function ItemPopup({
  item,
  instanceId,
  baseUrl,
  publicUrl,
  onClose,
}: {
  item: Item;
  instanceId: string;
  baseUrl: string;
  publicUrl: string;
  onClose: () => void;
}) {
  const shape = cardShape(item);
  const poster = imageSrc(instanceId, item.thumb, 420, 630);
  const directPoster = imageSrc(instanceId, item.thumb, 420, 630, true);
  const backdrop = imageSrc(instanceId, item.art, 1280, 720, true);
  const openHref = detailsHref(publicUrl, baseUrl, item.ratingKey);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return createPortal(
    <>
      <div className="pls-popup-backdrop" onClick={onClose} />
      <div className="pls-popup" role="dialog" aria-modal="true">
        <button className="pls-popup-close" type="button" aria-label="Close" onClick={onClose}>
          ×
        </button>
        {backdrop ? (
          <div className="pls-popup-bg" style={{ backgroundImage: `url('${backdrop}')` }} />
        ) : null}
        <div className="pls-popup-body">
          <div className={`pls-popup-poster pls-popup-poster--${shape}`}>
            <PosterImg
              src={poster}
              fallbackSrc={directPoster}
              fallbackLabel={sectionIcon(item.type)}
            />
          </div>
          <div className="pls-popup-info">
            <div className="pls-popup-kicker">
              {[item.sectionTitle, item.type, item.year].filter(Boolean).join(" · ")}
            </div>
            <div className="pls-popup-title">{item.title}</div>
            <div className="pls-popup-meta">
              {[formatRuntime(item.duration), item.subtitle].filter(Boolean).join(" · ")}
            </div>
            <div className="pls-popup-summary">{item.summary || "No summary available."}</div>
            <div className="pls-popup-actions">
              <a
                className="pls-popup-play"
                href={openHref}
                target="_blank"
                rel="noopener noreferrer"
              >
                Open in Plex
              </a>
            </div>
          </div>
        </div>
      </div>
    </>,
    document.body,
  );
}

function SliderRail({
  items,
  instanceId,
  loading,
  emptyMessage,
  onSelect,
}: {
  items: Item[];
  instanceId: string;
  loading?: boolean;
  emptyMessage?: string;
  onSelect: (item: Item) => void;
}) {
  const hostRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const railRef = useRef<HTMLDivElement>(null);
  const thumbRef = useRef<HTMLDivElement>(null);
  const fillRef = useRef<HTMLDivElement>(null);
  const barRef = useRef<HTMLDivElement>(null);
  const leftBtnRef = useRef<HTMLButtonElement>(null);
  const rightBtnRef = useRef<HTMLButtonElement>(null);
  const dragRef = useRef(false);
  const rafRef = useRef<number | null>(null);
  const targetScrollRef = useRef(0);

  const updateSlider = useCallback(() => {
    const track = trackRef.current;
    const bar = barRef.current;
    const fill = fillRef.current;
    const thumb = thumbRef.current;
    const leftBtn = leftBtnRef.current;
    const rightBtn = rightBtnRef.current;
    if (!track || !bar || !fill || !thumb) return;

    const maxScroll = Math.max(0, track.scrollWidth - track.clientWidth);
    const ratio = maxScroll > 0 ? track.scrollLeft / maxScroll : 0;
    const disabled = maxScroll <= 2;
    bar.classList.toggle("is-disabled", disabled);
    fill.style.width = `${ratio * 100}%`;
    thumb.style.left = `calc(${ratio * 100}% - ${ratio * 18}px)`;
    thumb.setAttribute("aria-valuenow", String(Math.round(ratio * 100)));
    if (leftBtn) leftBtn.disabled = disabled || track.scrollLeft <= 2;
    if (rightBtn) rightBtn.disabled = disabled || track.scrollLeft >= maxScroll - 2;
  }, []);

  const stopAnim = useCallback(() => {
    if (rafRef.current) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
  }, []);

  const setTarget = useCallback(
    (value: number, immediate = false) => {
      const track = trackRef.current;
      if (!track) return;
      const maxScroll = Math.max(0, track.scrollWidth - track.clientWidth);
      targetScrollRef.current = clamp(value, 0, maxScroll);
      if (immediate) {
        stopAnim();
        track.scrollLeft = targetScrollRef.current;
        updateSlider();
        return;
      }
      if (!rafRef.current) {
        const anim = () => {
          const current = trackRef.current;
          if (!current) {
            rafRef.current = null;
            return;
          }
          const diff = targetScrollRef.current - current.scrollLeft;
          if (Math.abs(diff) < 0.5) {
            current.scrollLeft = targetScrollRef.current;
            updateSlider();
            rafRef.current = null;
            return;
          }
          current.scrollLeft += diff * 0.18;
          updateSlider();
          rafRef.current = requestAnimationFrame(anim);
        };
        rafRef.current = requestAnimationFrame(anim);
      }
    },
    [stopAnim, updateSlider],
  );

  const scrollByPage = useCallback(
    (dir: number) => {
      const track = trackRef.current;
      if (!track) return;
      setTarget(track.scrollLeft + dir * Math.max(280, track.clientWidth * 0.82));
    },
    [setTarget],
  );

  useEffect(() => {
    const host = hostRef.current;
    const track = trackRef.current;
    const rail = railRef.current;
    const thumb = thumbRef.current;
    if (!host || !track || !rail || !thumb) return;

    const onScroll = (event: Event) => {
      if ((event.target as HTMLElement)?.classList?.contains("pls-slider")) updateSlider();
    };

    const onRailClick = (event: MouseEvent) => {
      if ((event.target as HTMLElement)?.closest?.(".pls-slider__thumb")) return;
      const rect = rail.getBoundingClientRect();
      const ratio = clamp((event.clientX - rect.left) / rect.width, 0, 1);
      setTarget(ratio * Math.max(0, track.scrollWidth - track.clientWidth));
    };

    const moveThumb = (clientX: number) => {
      const rect = rail.getBoundingClientRect();
      const ratio = clamp((clientX - rect.left) / rect.width, 0, 1);
      track.scrollLeft = ratio * Math.max(0, track.scrollWidth - track.clientWidth);
      updateSlider();
    };

    const stopDrag = () => {
      dragRef.current = false;
      host.classList.remove("pls-slider--dragging");
    };

    const onPointerDown = (event: PointerEvent) => {
      event.preventDefault();
      dragRef.current = true;
      stopAnim();
      host.classList.add("pls-slider--dragging");
    };
    const onPointerMove = (event: PointerEvent) => {
      if (dragRef.current) moveThumb(event.clientX);
    };

    host.addEventListener("scroll", onScroll, { passive: true, capture: true });
    rail.addEventListener("click", onRailClick);
    thumb.addEventListener("pointerdown", onPointerDown);
    window.addEventListener("pointermove", onPointerMove);
    window.addEventListener("pointerup", stopDrag);
    window.addEventListener("pointercancel", stopDrag);

    updateSlider();
    return () => {
      host.removeEventListener("scroll", onScroll, { capture: true });
      rail.removeEventListener("click", onRailClick);
      thumb.removeEventListener("pointerdown", onPointerDown);
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerup", stopDrag);
      window.removeEventListener("pointercancel", stopDrag);
      stopAnim();
    };
  }, [items.length, loading, setTarget, stopAnim, updateSlider]);

  useEffect(() => {
    updateSlider();
  }, [items, loading, updateSlider]);

  return (
    <div className="pls-slider-wrap" ref={hostRef}>
      <div className="pls-slider" ref={trackRef}>
        {loading && !items.length
          ? Array.from({ length: 8 }, (_, index) => (
              <div className="pls-card pls-card--poster" key={`skel-${index}`} aria-hidden>
                <div className="pls-poster" />
                <div className="pls-card-title">…</div>
                <div className="pls-card-sub"> </div>
              </div>
            ))
          : null}
        {!loading && !items.length ? (
          <div className="pls-empty">{emptyMessage || "No recent media found"}</div>
        ) : null}
        {items.map((item) => {
          const shape = cardShape(item);
          const poster = imageSrc(instanceId, item.thumb, 320, 480);
          const direct = imageSrc(instanceId, item.thumb, 320, 480, true);
          return (
            <button
              key={item.key}
              className={`pls-card pls-card--${shape}`}
              type="button"
              title={item.title}
              onClick={() => onSelect(item)}
            >
              <div className="pls-poster">
                <PosterImg
                  src={poster}
                  fallbackSrc={direct}
                  fallbackLabel={sectionIcon(item.type)}
                />
              </div>
              <div className="pls-card-title">{item.title}</div>
              <div className="pls-card-sub">{item.subtitle || item.type}</div>
            </button>
          );
        })}
      </div>
      <div className="pls-slider-control">
        <button
          ref={leftBtnRef}
          className="pls-slider__btn pls-slider__btn--left"
          type="button"
          aria-label="Scroll left"
          onClick={() => scrollByPage(-1)}
        >
          ‹
        </button>
        <div className="pls-slider__bar" ref={barRef}>
          <div className="pls-slider__rail" ref={railRef}>
            <div className="pls-slider__fill" ref={fillRef} />
            <div
              className="pls-slider__thumb"
              ref={thumbRef}
              tabIndex={0}
              role="slider"
              aria-label="Plex slider"
            />
          </div>
        </div>
        <button
          ref={rightBtnRef}
          className="pls-slider__btn pls-slider__btn--right"
          type="button"
          aria-label="Scroll right"
          onClick={() => scrollByPage(1)}
        >
          ›
        </button>
      </div>
    </div>
  );
}

export default function PlexSliderWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "plex-slider";

  const [sections, setSections] = useState<Section[]>([]);
  const [active, setActive] = useState(ALL_SECTION.key);
  const [items, setItems] = useState<Item[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<Item[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchActive, setSearchActive] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [baseUrl, setBaseUrl] = useState("");
  const [publicUrl, setPublicUrl] = useState("");
  const [openFallbackUrl, setOpenFallbackUrl] = useState("");
  const [selected, setSelected] = useState<Item | null>(null);

  const searchDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastSearchRef = useRef("");

  const tabs = [ALL_SECTION, ...sections];
  const openUrl = useOpenHref(publicUrl || baseUrl, openFallbackUrl);

  const loadSections = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const response = await fetch(apiUrl("sections", { instance: instanceId }));
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Failed to load Plex");
      setSections(data.sections || []);
      setBaseUrl(data.baseUrl || "");
      setPublicUrl(data.publicUrl || data.href || data.baseUrl || "");
      setOpenFallbackUrl(data.openFallbackUrl || "");
      setActive((current) => {
        const keys = [ALL_SECTION.key, ...(data.sections || []).map((section: Section) => section.key)];
        return current && keys.includes(current) ? current : ALL_SECTION.key;
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load Plex");
    } finally {
      setLoading(false);
    }
  }, [instanceId]);

  useEffect(() => {
    loadSections();
  }, [instanceId]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (searchActive) return;
    let alive = true;
    setLoading(true);
    fetch(apiUrl("items", { instance: instanceId, section: active }))
      .then(async (response) => {
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Failed to load items");
        if (!alive) return;
        setItems(data.items || []);
        setBaseUrl(data.baseUrl || baseUrl);
        setPublicUrl(data.publicUrl || data.baseUrl || publicUrl);
        setOpenFallbackUrl(data.openFallbackUrl || openFallbackUrl);
        setError("");
      })
      .catch((err) => {
        if (alive) setError(err instanceof Error ? err.message : "Failed to load items");
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [active, instanceId, searchActive]); // eslint-disable-line react-hooks/exhaustive-deps

  const runSearch = useCallback(
    async (query: string) => {
      if (!query.trim()) {
        setSearchActive(false);
        setSearchResults([]);
        setSearchLoading(false);
        return;
      }
      setSearchActive(true);
      setSearchLoading(true);
      try {
        const response = await fetch(apiUrl("search", { instance: instanceId, q: query.trim() }));
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Search failed");
        if (lastSearchRef.current === query.trim()) {
          setSearchResults(data.items || []);
          setBaseUrl(data.baseUrl || baseUrl);
          setPublicUrl(data.publicUrl || data.baseUrl || publicUrl);
          setOpenFallbackUrl(data.openFallbackUrl || openFallbackUrl);
        }
      } catch (err) {
        if (lastSearchRef.current === query.trim()) {
          setSearchResults([]);
          setError(err instanceof Error ? err.message : "Search failed");
        }
      } finally {
        if (lastSearchRef.current === query.trim()) setSearchLoading(false);
      }
    },
    [baseUrl, instanceId, publicUrl, openFallbackUrl],
  );

  const handleSearchChange = (value: string) => {
    setSearchQuery(value);
    if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);
    if (!value.trim()) {
      lastSearchRef.current = "";
      setSearchActive(false);
      setSearchResults([]);
      setSearchLoading(false);
      return;
    }
    searchDebounceRef.current = setTimeout(() => {
      if (value.trim() === lastSearchRef.current) return;
      lastSearchRef.current = value.trim();
      runSearch(value.trim());
    }, 350);
  };

  const clearSearch = () => {
    setSearchQuery("");
    lastSearchRef.current = "";
    setSearchActive(false);
    setSearchResults([]);
    setSearchLoading(false);
    if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);
  };

  const softPoll = useCallback(() => {
    if (searchActive) return;
    void fetch(apiUrl("sections", { instance: instanceId }))
      .then(async (response) => {
        const data = await response.json();
        if (!response.ok) return;
        setSections(data.sections || []);
        if (data.baseUrl) setBaseUrl(data.baseUrl);
        if (data.publicUrl || data.href || data.baseUrl) {
          setPublicUrl(data.publicUrl || data.href || data.baseUrl || "");
        }
        if (data.openFallbackUrl) setOpenFallbackUrl(data.openFallbackUrl);
      })
      .catch(() => {
        /* keep current sections on soft poll failure */
      });
    void fetch(apiUrl("items", { instance: instanceId, section: active }))
      .then(async (response) => {
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Failed to load items");
        setItems(data.items || []);
        if (data.baseUrl) setBaseUrl(data.baseUrl);
        if (data.publicUrl || data.baseUrl) {
          setPublicUrl((prev) => data.publicUrl || data.baseUrl || prev);
        }
        if (data.openFallbackUrl) setOpenFallbackUrl(data.openFallbackUrl);
        setError("");
      })
      .catch(() => {
        /* keep current items on soft poll failure */
      });
  }, [active, instanceId, searchActive]);
  const { rootRef } = useWidgetPoll(softPoll, { intervalMs: 60_000 });

  const isOnline = Boolean(openUrl || sections.length || items.length) && !(error && !items.length);

  if (error && !sections.length && !items.length) {
    return (
      <div className="hd-widget-body pls-body-flat" ref={rootRef}>
        <div className="pls-shelf">
          <div className="pls-empty pls-empty--error">{error}</div>
          <button className="pls-open-btn" type="button" onClick={() => loadSections()}>
            Retry
          </button>
        </div>
      </div>
    );
  }

  const railItems = searchActive ? searchResults : items;
  const railLoading = searchActive ? searchLoading : loading;
  const emptyMessage = searchActive
    ? searchQuery
      ? "No Plex results"
      : "Search all media"
    : error || "No recent media found";

  return (
    <div className="hd-widget-body pls-body-flat" ref={rootRef}>
      <div className="pls-shelf">
        <div className="pls-header">
          <div className="pls-toolbar">
            <div className="pls-toolbar-left">
              <span className={`pls-status-pill${isOnline ? " pls-status-pill--ok" : " pls-status-pill--warn"}`}>
                <span className="pls-status-dot" aria-hidden="true" />
                {isOnline ? "Online" : "Offline"}
              </span>
            </div>
            <div className="pls-toolbar-right">
              {openUrl ? (
                <a
                  className="pls-open-btn"
                  href={openUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  title="Open Plex"
                  aria-label="Open Plex in new tab"
                >
                  Open
                </a>
              ) : null}
            </div>
          </div>
          <div className="pls-search-wrap">
            <span className="pls-search-icon" aria-hidden="true">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
                <circle cx="11" cy="11" r="8" />
                <path d="M21 21l-4.35-4.35" />
              </svg>
            </span>
            <input
              className={`pls-search-input${searchQuery ? " has-value" : ""}`}
              type="search"
              placeholder="Search…"
              autoComplete="off"
              autoCorrect="off"
              spellCheck={false}
              aria-label="Search all media"
              value={searchQuery}
              onChange={(event) => handleSearchChange(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Escape") {
                  clearSearch();
                  (event.target as HTMLInputElement).blur();
                }
              }}
            />
            <button
              className={`pls-search-clear${searchQuery ? " is-visible" : ""}`}
              type="button"
              aria-label="Clear search"
              onClick={() => clearSearch()}
            >
              ✕
            </button>
          </div>
        </div>

        <div className="pls-controls">
          <div className="pls-tabs" role="tablist" aria-label="Plex libraries">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                type="button"
                role="tab"
                aria-selected={!searchActive && active === tab.key}
                className={`pls-tab${!searchActive && active === tab.key ? " pls-tab--active" : ""}`}
                onClick={() => {
                  clearSearch();
                  setActive(tab.key);
                }}
              >
                <span>{sectionIcon(tab.type)}</span>
                {tab.title}
              </button>
            ))}
          </div>
        </div>

        <SliderRail
          items={railItems}
          instanceId={instanceId}
          loading={railLoading}
          emptyMessage={emptyMessage}
          onSelect={setSelected}
        />
      </div>

      {selected ? (
        <ItemPopup
          item={selected}
          instanceId={instanceId}
          baseUrl={baseUrl}
          publicUrl={openUrl || baseUrl}
          onClose={() => setSelected(null)}
        />
      ) : null}
    </div>
  );
}
