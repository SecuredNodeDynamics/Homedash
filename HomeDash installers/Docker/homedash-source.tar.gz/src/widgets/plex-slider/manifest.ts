import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "plex-slider",
  name: "Plex Slider",
  description: "Plex recently added slider with library tabs, search, and detail popups",
  version: "0.4.0",
  category: "Media",
  hostClass: "plex-slider-host",
  defaultSize: { w: 8, h: 5, minW: 4, minH: 3 },
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "http://10.0.0.1:32400",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      placeholder: "https://plex.example.com",
    },
    {
      key: "publicUrl",
      label: "OPEN - Private URL",
      type: "url",
      placeholder: "http://10.0.0.1:32400",
    },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    { key: "apiKey", label: "Plex Token", type: "password", required: true },
  ],
};
