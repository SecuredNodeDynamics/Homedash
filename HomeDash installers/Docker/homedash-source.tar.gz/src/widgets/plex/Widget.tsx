"use client";
import "@/styles/widgets/plex.widget.css";


import { useCallback, useRef, useState } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type Session = {
  id: string;
  title: string;
  subtitle: string;
  user: string;
  player: string;
  state: string;
  viewOffset: number;
  duration: number;
  progress: number;
  transcode: boolean;
  type: string;
  artUrl: string;
};

type Library = {
  key: string;
  title: string;
  type: string;
  count: number;
};

type Data = {
  href: string;
  openFallbackUrl?: string;
  serverName: string;
  streams: number;
  totalItems: number;
  sessions: Session[];
  libraries: Library[];
};

type ScanState = "idle" | "scanning" | "ok" | "err";
type TabKey = "overview" | "playing" | "libraries";

const TABS: { key: TabKey; label: string }[] = [
  { key: "overview", label: "Overview" },
  { key: "playing", label: "Now Playing" },
  { key: "libraries", label: "Libraries" },
];

function fmtMs(ms: number) {
  if (!ms || ms < 0) return "0:00";
  const total = Math.floor(Number(ms) / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}

function sectionIcon(type: string) {
  if (type === "movie") return "🎬";
  if (type === "show") return "📺";
  if (type === "artist") return "🎵";
  if (type === "photo") return "🖼";
  return "📁";
}

function scanLabel(state: ScanState, idle: string) {
  if (state === "scanning") return "Scanning";
  if (state === "ok") return "Done";
  if (state === "err") return "Failed";
  return idle;
}

function SessionArt({ artUrl, type }: { artUrl: string; type: string }) {
  const [broken, setBroken] = useState(false);
  if (!artUrl || broken) {
    return <span>{sectionIcon(type)}</span>;
  }
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img src={artUrl} alt="" loading="lazy" onError={() => setBroken(true)} />
  );
}

function SessionCard({ session }: { session: Session }) {
  const status =
    session.state === "paused"
      ? "Paused"
      : session.state === "playing"
        ? "Playing"
        : session.state || "Active";
  return (
    <div className="plex-session">
      <div className="plex-session-art">
        <SessionArt artUrl={session.artUrl} type={session.type} />
      </div>
      <div className="plex-session-main">
        <div className="plex-session-top">
          <span className="plex-session-title">{session.title}</span>
          <span
            className={`plex-badge ${
              session.state === "paused" ? "plex-badge--paused" : "plex-badge--playing"
            }`}
          >
            {status}
          </span>
        </div>
        <div className="plex-session-sub">
          {[session.subtitle || session.type, session.user, session.player].filter(Boolean).join(" · ")}
        </div>
        <div className="plex-progress">
          <span style={{ width: `${session.progress}%` }} />
        </div>
        <div className="plex-session-meta">
          <span>
            {fmtMs(session.viewOffset)} / {fmtMs(session.duration)}
          </span>
          <span>{session.transcode ? "Transcoding" : "Direct"}</span>
        </div>
      </div>
    </div>
  );
}

function LibraryRow({
  lib,
  state,
  onScan,
}: {
  lib: Library;
  state: ScanState;
  onScan: (key: string) => void;
}) {
  return (
    <div className="plex-library">
      <div className="plex-library-left">
        <span className="plex-library-icon">{sectionIcon(lib.type)}</span>
        <div>
          <div className="plex-library-title">{lib.title}</div>
          <div className="plex-library-sub">
            {lib.type || "library"} · {Number(lib.count || 0).toLocaleString()} items
          </div>
        </div>
      </div>
      <button
        className="plex-scan-btn"
        type="button"
        disabled={!lib.key || state === "scanning"}
        onClick={() => lib.key && onScan(lib.key)}
      >
        {scanLabel(state, "Scan")}
      </button>
    </div>
  );
}

function StatsStrip({
  streams,
  libraries,
  items,
}: {
  streams: number;
  libraries: number;
  items: number;
}) {
  return (
    <div className="plex-stats plex-stats--strip">
      <div className="plex-stat">
        <span>{streams}</span>
        <small>Streams</small>
      </div>
      <div className="plex-stat">
        <span>{libraries}</span>
        <small>Libraries</small>
      </div>
      <div className="plex-stat">
        <span>{items.toLocaleString()}</span>
        <small>Items</small>
      </div>
    </div>
  );
}

export default function PlexWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "plex";
  const [data, setData] = useState<Data | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<TabKey>("overview");
  const [scanState, setScanState] = useState<Record<string, ScanState>>({});
  const hasLoadedRef = useRef(false);
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);

  const load = useCallback(
    async (opts?: { soft?: boolean }) => {
      if (!opts?.soft) setLoading(true);
      try {
        const response = await fetch(
          `/api/widgets/plex/status?instance=${encodeURIComponent(instanceId)}`,
        );
        const json = await response.json();
        if (!response.ok) throw new Error(json.error || "Failed to load Plex");
        setData(json);
        setError("");
      } catch (err) {
        if (!opts?.soft) {
          setError(err instanceof Error ? err.message : "Plex unavailable");
        }
      } finally {
        if (!opts?.soft) setLoading(false);
      }
    },
    [instanceId],
  );

  const managedLoad = useCallback(async () => {
    await load({ soft: hasLoadedRef.current });
    hasLoadedRef.current = true;
  }, [load]);
  const pollMs = error && !data ? 8_000 : (data?.sessions.length || 0) > 0 ? 15_000 : 30_000;
  const { rootRef } = useWidgetPoll(managedLoad, { intervalMs: pollMs });

  async function postAction(body: Record<string, unknown>) {
    const response = await fetch("/api/widgets/plex/action", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ instance: instanceId, ...body }),
    });
    const json = await response.json();
    if (!response.ok) throw new Error(json.error || "Action failed");
    return json;
  }

  async function scanSection(key: string) {
    setScanState((prev) => ({ ...prev, [key]: "scanning" }));
    try {
      await postAction({ action: "refresh-section", sectionKey: key });
      setScanState((prev) => ({ ...prev, [key]: "ok" }));
    } catch {
      setScanState((prev) => ({ ...prev, [key]: "err" }));
    }
    window.setTimeout(() => {
      setScanState((prev) => ({ ...prev, [key]: "idle" }));
    }, 4000);
  }

  async function scanAll() {
    const keys = (data?.libraries || []).map((lib) => lib.key).filter(Boolean);
    setScanState((prev) => {
      const next: Record<string, ScanState> = { ...prev, __all__: "scanning" };
      for (const key of keys) next[key] = "scanning";
      return next;
    });
    try {
      await postAction({ action: "refresh-all" });
      setScanState((prev) => {
        const next: Record<string, ScanState> = { ...prev, __all__: "ok" };
        for (const key of keys) next[key] = "ok";
        return next;
      });
    } catch {
      setScanState((prev) => {
        const next: Record<string, ScanState> = { ...prev, __all__: "err" };
        for (const key of keys) next[key] = "err";
        return next;
      });
    }
    window.setTimeout(() => {
      setScanState((prev) => {
        const next: Record<string, ScanState> = { ...prev, __all__: "idle" };
        for (const key of keys) next[key] = "idle";
        return next;
      });
    }, 4000);
  }

  if (loading && !data) {
    return (
      <div className="hd-widget-body plex-body-flat" ref={rootRef}>
        <div className="plex-shell">
          <div className="plex-empty">Loading Plex…</div>
        </div>
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="hd-widget-body plex-body-flat" ref={rootRef}>
        <div className="plex-shell">
          <div className="plex-toolbar">
            <div className="plex-toolbar-left">
              <span className="plex-status-pill plex-status-pill--warn">
                <span className="plex-status-dot" aria-hidden="true" />
                Offline
              </span>
            </div>
            <div className="plex-toolbar-right">
              <button className="plex-action-btn" type="button" onClick={() => void load()}>
                Retry
              </button>
            </div>
          </div>
          <div className="plex-empty plex-empty--error">{error}</div>
        </div>
      </div>
    );
  }

  const live = data!;
  const sessions = live.sessions || [];
  const libraries = live.libraries || [];
  const allState = scanState.__all__ || "idle";
  const allLabel = scanLabel(allState, "Scan All");
  const isOnline = Boolean(live.href || libraries.length || sessions.length) && !(error && !sessions.length);

  function renderLibraries(limit?: number) {
    const rows = typeof limit === "number" ? libraries.slice(0, limit) : libraries;
    if (!rows.length) {
      return <div className="plex-empty plex-empty--soft">No libraries found</div>;
    }
    return (
      <div className="plex-libraries">
        {rows.map((lib) => (
          <LibraryRow
            key={lib.key || lib.title}
            lib={lib}
            state={scanState[lib.key] || "idle"}
            onScan={(key) => void scanSection(key)}
          />
        ))}
      </div>
    );
  }

  function renderPanel() {
    if (tab === "overview") {
      return (
        <div className="plex-overview">
          <StatsStrip
            streams={sessions.length}
            libraries={libraries.length}
            items={live.totalItems || 0}
          />
          <div className="plex-overview-block">
            <div className="plex-block-label">Now Playing</div>
            {sessions.length ? (
              <div className="plex-sessions">
                {sessions.slice(0, 2).map((session) => (
                  <SessionCard key={session.id} session={session} />
                ))}
              </div>
            ) : (
              <div className="plex-empty plex-empty--soft">No active streams</div>
            )}
          </div>
          <div className="plex-overview-block">
            <div className="plex-block-head">
              <div className="plex-block-label">Libraries</div>
              <button
                className="plex-action-btn plex-scan-all"
                type="button"
                disabled={allState === "scanning" || !libraries.length}
                onClick={() => void scanAll()}
              >
                {allLabel}
              </button>
            </div>
            {renderLibraries(4)}
          </div>
        </div>
      );
    }

    if (tab === "playing") {
      if (!sessions.length) {
        return <div className="plex-empty">No active streams</div>;
      }
      return (
        <div className="plex-sessions">
          {sessions.map((session) => (
            <SessionCard key={session.id} session={session} />
          ))}
        </div>
      );
    }

    return (
      <div className="plex-libraries-panel">
        <div className="plex-block-head">
          <div className="plex-block-label">Libraries</div>
          <button
            className="plex-action-btn plex-scan-all"
            type="button"
            disabled={allState === "scanning" || !libraries.length}
            onClick={() => void scanAll()}
          >
            {allLabel}
          </button>
        </div>
        {renderLibraries()}
      </div>
    );
  }

  return (
    <div className="hd-widget-body plex-body-flat" ref={rootRef}>
      <div className="plex-shell">
        <div className="plex-toolbar">
          <div className="plex-toolbar-left">
            <span className={`plex-status-pill${isOnline ? " plex-status-pill--ok" : " plex-status-pill--warn"}`}>
              <span className="plex-status-dot" aria-hidden="true" />
              {isOnline ? "Online" : "Offline"}
            </span>
          </div>
          <div className="plex-toolbar-right">
            {openHref ? (
              <a className="plex-open-link" href={openHref} target="_blank" rel="noopener noreferrer">
                Open
              </a>
            ) : null}
          </div>
        </div>

        <div className="plex-controls">
          <div className="plex-tabs" role="tablist" aria-label="Plex sections">
            {TABS.map((item) => (
              <button
                key={item.key}
                className={`plex-tab${tab === item.key ? " plex-tab--active" : ""}`}
                type="button"
                role="tab"
                aria-selected={tab === item.key}
                onClick={() => setTab(item.key)}
              >
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="plex-panel">{renderPanel()}</div>
      </div>
    </div>
  );
}
