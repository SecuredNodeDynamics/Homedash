import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "plex",
  name: "Plex",
  description: "Live sessions, library stats, and scan controls with Overview / Now Playing / Libraries tabs",
  version: "0.3.0",
  category: "Media",
  defaultSize: { w: 6, h: 5, minW: 4, minH: 4 },
  hostClass: "plex-widget-host plex-monitor-host",
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "http://10.0.0.1:32400",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      required: false,
      placeholder: "https://plex.example.com",
    },
    {
      key: "publicUrl",
      label: "OPEN - Private URL",
      type: "url",
      required: false,
      placeholder: "http://10.0.0.1:32400",
    },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    {
      key: "apiKey",
      label: "Token",
      type: "password",
      required: true,
    },
  ],
};
