"use client";

import { useEffect, useState } from "react";
import { createPortal } from "react-dom";

export type IndexerDefinition = {
  definitionName: string;
  name: string;
  implementationName: string;
  protocol: string;
  privacy: string;
  language: string;
  description: string;
  categories: string[];
  supportsSearch: boolean;
  supportsRss: boolean;
};

type SelectOption = { value?: number | string; name?: string };
type IndexerField = {
  name?: string;
  label?: string;
  helpText?: string;
  type?: string;
  value?: unknown;
  advanced?: boolean;
  privacy?: string;
  selectOptions?: SelectOption[];
  selectOptionsProviderAction?: string;
  homedashSelectOptions?: SelectOption[];
};
type IndexerConfig = Record<string, unknown> & {
  name?: string;
  enable?: boolean;
  priority?: number;
  fields?: IndexerField[];
};
type Action = "test" | "create";

export function AddIndexerModal({
  instanceId,
  definition,
  onClose,
  onAdded,
}: {
  instanceId: string;
  definition: IndexerDefinition;
  onClose: () => void;
  onAdded: () => void;
}) {
  const [config, setConfig] = useState<IndexerConfig | null>(null);
  const [loading, setLoading] = useState(true);
  const [working, setWorking] = useState<Action | "">("");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [customFields, setCustomFields] = useState<Record<number, boolean>>({});

  useEffect(() => {
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => event.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = overflow;
      document.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  useEffect(() => {
    let active = true;
    void (async () => {
      try {
        const response = await fetch(
          `/api/widgets/prowlarr/schema?instance=${encodeURIComponent(instanceId)}&definitionName=${encodeURIComponent(definition.definitionName)}`,
        );
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Failed to load indexer definition");
        if (active) {
          setConfig({
            ...data,
            name: data.name || definition.name,
            enable: true,
            priority: 25,
          });
        }
      } catch (reason) {
        if (active) setError(reason instanceof Error ? reason.message : "Failed to load indexer definition");
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, [instanceId, definition.definitionName, definition.name]);

  function updateRoot(key: string, value: unknown) {
    setConfig((current) => current ? { ...current, [key]: value } : current);
  }

  function updateField(index: number, value: unknown) {
    setConfig((current) => {
      if (!current) return current;
      const fields = [...(current.fields || [])];
      fields[index] = { ...fields[index], value };
      return { ...current, fields };
    });
  }

  async function run(action: Action) {
    if (!config) return;
    setWorking(action);
    setError("");
    setMessage("");
    try {
      const cleanConfig = {
        ...config,
        fields: config.fields?.map(({ homedashSelectOptions: _options, ...field }) => field),
      };
      const response = await fetch("/api/widgets/prowlarr/schema", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          instance: instanceId,
          action,
          indexer: cleanConfig,
        }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || `${action} failed`);
      if (action === "create") {
        onAdded();
        onClose();
        return;
      }
      setMessage("Indexer test passed successfully.");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : `${action} failed`);
    } finally {
      setWorking("");
    }
  }

  const fields = config?.fields || [];

  return createPortal(
    <div className="pwr-indexer-scrim" role="presentation" onMouseDown={onClose}>
      <section
        className="pwr-indexer-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="pwr-add-indexer-title"
        onMouseDown={(event) => event.stopPropagation()}
      >
        <header className="pwr-indexer-modal__head">
          <div className="pwr-indexer-modal__mark">+</div>
          <div>
            <span>{definition.implementationName || "New indexer"}</span>
            <h2 id="pwr-add-indexer-title">{definition.name}</h2>
            <p>
              {[definition.protocol, definition.privacy].filter(Boolean).join(" · ") || "Configure and add this indexer"}
            </p>
          </div>
          <button type="button" className="pwr-indexer-close" onClick={onClose} aria-label="Close">×</button>
        </header>

        {loading ? <div className="pwr-indexer-loading">Loading indexer definition…</div> : null}
        {error ? <div className="pwr-indexer-notice is-error">{error}</div> : null}
        {message ? <div className="pwr-indexer-notice is-success">{message}</div> : null}

        {config ? (
          <>
            <div className="pwr-indexer-form">
              <label className="pwr-indexer-field">
                <span>Name</span>
                <input value={String(config.name || "")} onChange={(event) => updateRoot("name", event.target.value)} />
              </label>
              <label className="pwr-indexer-field">
                <span>Priority</span>
                <input type="number" min="1" max="50" value={Number(config.priority || 25)} onChange={(event) => updateRoot("priority", Number(event.target.value))} />
              </label>
              <label className="pwr-indexer-toggle">
                <input type="checkbox" checked={config.enable !== false} onChange={(event) => updateRoot("enable", event.target.checked)} />
                <span>Enable this indexer</span>
              </label>

              {fields.map((field, index) => {
                if (!field.name || (field.advanced && !showAdvanced) || field.type?.toLowerCase() === "hidden") return null;
                const label = field.label || field.name;
                const type = (field.type || "").toLowerCase();
                const selectOptions = field.homedashSelectOptions || field.selectOptions;
                const isBaseUrl = field.name.toLowerCase() === "baseurl";
                const currentValue = String(field.value ?? "");
                const hasCurrentOption = selectOptions?.some(
                  (option) => String(option.value ?? "") === currentValue,
                );
                const isCustom = Boolean(customFields[index]) || (Boolean(currentValue) && !hasCurrentOption);
                if (type === "checkbox") {
                  return (
                    <label className="pwr-indexer-toggle" key={`${field.name}-${index}`}>
                      <input type="checkbox" checked={Boolean(field.value)} onChange={(event) => updateField(index, event.target.checked)} />
                      <span>{label}</span>
                    </label>
                  );
                }
                if (isBaseUrl && selectOptions?.length) {
                  return (
                    <label className="pwr-indexer-field pwr-indexer-field--base-url" key={`${field.name}-${index}`}>
                      <span>{label}</span>
                      <select
                        value={isCustom ? "__custom__" : currentValue}
                        onChange={(event) => {
                          if (event.target.value === "__custom__") {
                            setCustomFields((current) => ({ ...current, [index]: true }));
                            if (hasCurrentOption) updateField(index, "");
                            return;
                          }
                          setCustomFields((current) => ({ ...current, [index]: false }));
                          updateField(index, event.target.value);
                        }}
                      >
                        {!currentValue ? <option value="">Select a Prowlarr base URL…</option> : null}
                        {selectOptions.map((option) => (
                          <option value={String(option.value ?? "")} key={String(option.value ?? option.name)}>
                            {option.name ?? option.value}
                          </option>
                        ))}
                        <option value="__custom__">Custom URL…</option>
                      </select>
                      {isCustom ? (
                        <input
                          type="url"
                          placeholder="https://indexer.example.com/"
                          value={currentValue}
                          onChange={(event) => updateField(index, event.target.value)}
                          autoFocus
                        />
                      ) : null}
                      {field.helpText ? <small>{field.helpText}</small> : null}
                    </label>
                  );
                }
                if (selectOptions?.length) {
                  return (
                    <label className="pwr-indexer-field" key={`${field.name}-${index}`}>
                      <span>{label}</span>
                      <select
                        value={String(field.value ?? "")}
                        onChange={(event) => {
                          const selected = selectOptions?.find(
                            (option) => String(option.value ?? "") === event.target.value,
                          );
                          updateField(index, selected?.value ?? event.target.value);
                        }}
                      >
                        {selectOptions.map((option) => (
                          <option value={String(option.value ?? "")} key={String(option.value ?? option.name)}>
                            {option.name ?? option.value}
                          </option>
                        ))}
                      </select>
                      {field.helpText ? <small>{field.helpText}</small> : null}
                    </label>
                  );
                }
                return (
                  <label className="pwr-indexer-field" key={`${field.name}-${index}`}>
                    <span>{label}</span>
                    <input
                      type={
                        type === "password" || (field.privacy && field.privacy !== "normal")
                          ? "password"
                          : type === "number" ? "number" : "text"
                      }
                      value={String(field.value ?? "")}
                      onChange={(event) => updateField(index, type === "number" ? Number(event.target.value) : event.target.value)}
                      autoComplete="off"
                    />
                    {field.helpText ? <small>{field.helpText}</small> : null}
                  </label>
                );
              })}
            </div>

            {fields.some((field) => field.advanced) ? (
              <button className="pwr-indexer-advanced" type="button" onClick={() => setShowAdvanced((value) => !value)}>
                {showAdvanced ? "Hide advanced settings" : "Show advanced settings"}
              </button>
            ) : null}

            <footer className="pwr-indexer-actions">
              <button type="button" disabled={Boolean(working)} onClick={() => void run("test")}>
                {working === "test" ? "Testing…" : "Test indexer"}
              </button>
              <button className="is-primary" type="button" disabled={Boolean(working)} onClick={() => void run("create")}>
                {working === "create" ? "Adding…" : "Add indexer"}
              </button>
            </footer>
          </>
        ) : null}
      </section>
    </div>,
    document.body,
  );
}
