"use client";

import { useEffect, useState } from "react";
import { createPortal } from "react-dom";

type IndexerSummary = {
  id: number;
  name: string;
  enable: boolean;
  protocol: string;
  definitionName: string;
  failing: boolean;
};

type SelectOption = { value?: number | string; name?: string };
type IndexerField = {
  name?: string;
  label?: string;
  helpText?: string;
  type?: string;
  value?: unknown;
  advanced?: boolean;
  privacy?: string;
  selectOptions?: SelectOption[];
  selectOptionsProviderAction?: string;
  homedashSelectOptions?: SelectOption[];
};
type IndexerConfig = Record<string, unknown> & {
  id?: number;
  name?: string;
  enable?: boolean;
  priority?: number;
  fields?: IndexerField[];
};
type Action = "test" | "update" | "delete";

export function IndexerManagerModal({
  instanceId,
  summary,
  onClose,
  onChanged,
}: {
  instanceId: string;
  summary: IndexerSummary;
  onClose: () => void;
  onChanged: () => void;
}) {
  const [config, setConfig] = useState<IndexerConfig | null>(null);
  const [loading, setLoading] = useState(true);
  const [working, setWorking] = useState<Action | "">("");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [customFields, setCustomFields] = useState<Record<number, boolean>>({});

  useEffect(() => {
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => event.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = overflow;
      document.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  useEffect(() => {
    let active = true;
    void (async () => {
      try {
        const response = await fetch(
          `/api/widgets/prowlarr/indexer?instance=${encodeURIComponent(instanceId)}&indexerId=${summary.id}`,
        );
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Failed to load indexer");
        if (active) setConfig(data);
      } catch (reason) {
        if (active) setError(reason instanceof Error ? reason.message : "Failed to load indexer");
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, [instanceId, summary.id]);

  function updateRoot(key: string, value: unknown) {
    setConfig((current) => current ? { ...current, [key]: value } : current);
  }

  function updateField(index: number, value: unknown) {
    setConfig((current) => {
      if (!current) return current;
      const fields = [...(current.fields || [])];
      fields[index] = { ...fields[index], value };
      return { ...current, fields };
    });
  }

  async function run(action: Action) {
    if (!config && action !== "delete") return;
    if (
      action === "delete" &&
      !window.confirm(`Remove “${summary.name}” from Prowlarr? This cannot be undone.`)
    ) return;
    setWorking(action);
    setError("");
    setMessage("");
    try {
      const cleanConfig = config
        ? {
            ...config,
            fields: config.fields?.map(({ homedashSelectOptions: _options, ...field }) => field),
          }
        : config;
      const response = await fetch("/api/widgets/prowlarr/indexer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          instance: instanceId,
          indexerId: summary.id,
          action,
          indexer: action === "delete" ? undefined : cleanConfig,
        }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || `${action} failed`);
      if (action === "delete") {
        onChanged();
        onClose();
        return;
      }
      setMessage(action === "test" ? "Indexer test passed successfully." : "Indexer settings updated.");
      if (action === "update") onChanged();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : `${action} failed`);
    } finally {
      setWorking("");
    }
  }

  const fields = config?.fields || [];

  return createPortal(
    <div className="pwr-indexer-scrim" role="presentation" onMouseDown={onClose}>
      <section
        className="pwr-indexer-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="pwr-indexer-title"
        onMouseDown={(event) => event.stopPropagation()}
      >
        <header className="pwr-indexer-modal__head">
          <div className={`pwr-indexer-modal__mark${summary.failing ? " is-failing" : ""}`}>P</div>
          <div>
            <span>{summary.definitionName || "Prowlarr indexer"}</span>
            <h2 id="pwr-indexer-title">{summary.name}</h2>
            <p>{summary.protocol || "Indexer"} configuration and diagnostics</p>
          </div>
          <button type="button" className="pwr-indexer-close" onClick={onClose} aria-label="Close">×</button>
        </header>

        {loading ? <div className="pwr-indexer-loading">Loading indexer configuration…</div> : null}
        {error ? <div className="pwr-indexer-notice is-error">{error}</div> : null}
        {message ? <div className="pwr-indexer-notice is-success">{message}</div> : null}

        {config ? (
          <>
            <div className="pwr-indexer-form">
              <label className="pwr-indexer-field">
                <span>Name</span>
                <input value={String(config.name || "")} onChange={(event) => updateRoot("name", event.target.value)} />
              </label>
              <label className="pwr-indexer-field">
                <span>Priority</span>
                <input type="number" min="1" max="50" value={Number(config.priority || 25)} onChange={(event) => updateRoot("priority", Number(event.target.value))} />
              </label>
              <label className="pwr-indexer-toggle">
                <input type="checkbox" checked={config.enable !== false} onChange={(event) => updateRoot("enable", event.target.checked)} />
                <span>Enable this indexer</span>
              </label>

              {fields.map((field, index) => {
                if (!field.name || (field.advanced && !showAdvanced) || field.type?.toLowerCase() === "hidden") return null;
                const label = field.label || field.name;
                const type = (field.type || "").toLowerCase();
                const selectOptions = field.homedashSelectOptions || field.selectOptions;
                const isBaseUrl = field.name.toLowerCase() === "baseurl";
                const currentValue = String(field.value ?? "");
                const hasCurrentOption = selectOptions?.some(
                  (option) => String(option.value ?? "") === currentValue,
                );
                const isCustom = Boolean(customFields[index]) || (Boolean(currentValue) && !hasCurrentOption);
                if (type === "checkbox") {
                  return (
                    <label className="pwr-indexer-toggle" key={`${field.name}-${index}`}>
                      <input type="checkbox" checked={Boolean(field.value)} onChange={(event) => updateField(index, event.target.checked)} />
                      <span>{label}</span>
                    </label>
                  );
                }
                if (isBaseUrl && selectOptions?.length) {
                  return (
                    <label className="pwr-indexer-field pwr-indexer-field--base-url" key={`${field.name}-${index}`}>
                      <span>{label}</span>
                      <select
                        value={isCustom ? "__custom__" : currentValue}
                        onChange={(event) => {
                          if (event.target.value === "__custom__") {
                            setCustomFields((current) => ({ ...current, [index]: true }));
                            if (hasCurrentOption) updateField(index, "");
                            return;
                          }
                          setCustomFields((current) => ({ ...current, [index]: false }));
                          updateField(index, event.target.value);
                        }}
                      >
                        {!currentValue ? <option value="">Select a Prowlarr base URL…</option> : null}
                        {selectOptions.map((option) => (
                          <option value={String(option.value ?? "")} key={String(option.value ?? option.name)}>
                            {option.name ?? option.value}
                          </option>
                        ))}
                        <option value="__custom__">Custom URL…</option>
                      </select>
                      {isCustom ? (
                        <input
                          type="url"
                          placeholder="https://indexer.example.com/"
                          value={currentValue}
                          onChange={(event) => updateField(index, event.target.value)}
                          autoFocus
                        />
                      ) : null}
                      {field.helpText ? <small>{field.helpText}</small> : null}
                    </label>
                  );
                }
                if (selectOptions?.length) {
                  return (
                    <label className="pwr-indexer-field" key={`${field.name}-${index}`}>
                      <span>{label}</span>
                      <select
                        value={String(field.value ?? "")}
                        onChange={(event) => {
                          const selected = selectOptions?.find(
                            (option) => String(option.value ?? "") === event.target.value,
                          );
                          updateField(index, selected?.value ?? event.target.value);
                        }}
                      >
                        {selectOptions.map((option) => (
                          <option value={String(option.value ?? "")} key={String(option.value ?? option.name)}>
                            {option.name ?? option.value}
                          </option>
                        ))}
                      </select>
                      {field.helpText ? <small>{field.helpText}</small> : null}
                    </label>
                  );
                }
                return (
                  <label className="pwr-indexer-field" key={`${field.name}-${index}`}>
                    <span>{label}</span>
                    <input
                      type={
                        type === "password" || (field.privacy && field.privacy !== "normal")
                          ? "password"
                          : type === "number" ? "number" : "text"
                      }
                      value={String(field.value ?? "")}
                      onChange={(event) => updateField(index, type === "number" ? Number(event.target.value) : event.target.value)}
                      autoComplete="off"
                    />
                    {field.helpText ? <small>{field.helpText}</small> : null}
                  </label>
                );
              })}
            </div>

            {fields.some((field) => field.advanced) ? (
              <button className="pwr-indexer-advanced" type="button" onClick={() => setShowAdvanced((value) => !value)}>
                {showAdvanced ? "Hide advanced settings" : "Show advanced settings"}
              </button>
            ) : null}

            <footer className="pwr-indexer-actions">
              <button type="button" disabled={Boolean(working)} onClick={() => void run("test")}>
                {working === "test" ? "Testing…" : "Test indexer"}
              </button>
              <button className="is-primary" type="button" disabled={Boolean(working)} onClick={() => void run("update")}>
                {working === "update" ? "Saving…" : "Save changes"}
              </button>
              <button className="is-danger" type="button" disabled={Boolean(working)} onClick={() => void run("delete")}>
                {working === "delete" ? "Removing…" : "Remove indexer"}
              </button>
            </footer>
          </>
        ) : null}
      </section>
    </div>,
    document.body,
  );
}
