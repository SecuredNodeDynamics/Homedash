"use client";
import "@/styles/widgets/prowlarr.widget.css";


import { useCallback, useEffect, useMemo, useRef, useState, useLayoutEffect } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";
import { IndexerManagerModal } from "./IndexerManagerModal";
import { AddIndexerModal, type IndexerDefinition } from "./AddIndexerModal";

type Tab = "overview" | "indexers" | "add" | "history" | "stats";
type HistoryFilter = "all" | "query" | "rss" | "grab" | "auth" | "failed";

type ConnectionSource = "private" | "public" | "unknown";

const CONNECTION_SOURCE_LABEL: Record<ConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

function ConnectionCorner({ source }: { source: ConnectionSource }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const mark = (
    <div
      className={`pwr-corner-source pwr-corner-source--${source}`}
      title={CONNECTION_SOURCE_LABEL[source]}
      aria-label={CONNECTION_SOURCE_LABEL[source]}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}


type Indexer = {
  id: number;
  name: string;
  enable: boolean;
  protocol: string;
  privacy: string;
  definitionName: string;
  disabledTill: string;
  failing: boolean;
};

type HistoryItem = {
  id: number;
  indexerId: number;
  date: string;
  eventType: string;
  successful: boolean;
  downloadId: string;
  query: string;
  queryType: string;
  source: string;
  queryResults: number | string | null;
};

type IndexerStat = {
  indexerId: number;
  indexerName: string;
  averageResponseTime: number;
  averageGrabResponseTime: number;
  numberOfQueries: number;
  numberOfGrabs: number;
  numberOfRssQueries: number;
  numberOfAuthQueries: number;
  numberOfFailedQueries: number;
  numberOfFailedGrabs: number;
  numberOfFailedRssQueries: number;
  numberOfFailedAuthQueries: number;
};

type Data = {
  href: string;
  openFallbackUrl?: string;
  connectionSource?: ConnectionSource;
  statsPending?: boolean;
  indexers: Indexer[];
  history: HistoryItem[];
  indexerStats: IndexerStat[];
  totals: {
    indexers: number;
    enabled: number;
    disabled: number;
    torrent: number;
    failing: number;
    grabs: number;
    queries: number;
    failedGrabs: number;
    failedQueries: number;
    rssQueries: number;
    authQueries: number;
    averageResponseTime: number;
  };
};

const TABS: Array<{ key: Tab; label: string }> = [
  { key: "overview", label: "Overview" },
  { key: "indexers", label: "Indexers" },
  { key: "add", label: "Add" },
  { key: "history", label: "History" },
  { key: "stats", label: "Stats" },
];

function fmtNum(n: number) {
  return n.toLocaleString();
}

function fmtDuration(ms: number) {
  if (!ms) return "—";
  return ms < 1000 ? `${Math.round(ms)} ms` : `${(ms / 1000).toFixed(ms < 10_000 ? 1 : 0)} s`;
}

function fmtTime(iso?: string) {
  if (!iso) return "—";
  const date = new Date(iso);
  return Number.isNaN(date.getTime())
    ? "—"
    : date.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
}

function fmtTill(iso?: string) {
  if (!iso) return "";
  const date = new Date(iso);
  return Number.isNaN(date.getTime())
    ? ""
    : date.toLocaleString("en-US", {
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
      });
}

function fmtDateTime(iso?: string) {
  if (!iso) return "Unknown time";
  const date = new Date(iso);
  return Number.isNaN(date.getTime())
    ? "Unknown time"
    : date.toLocaleString("en-US", {
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
      });
}

function historyEventLabel(eventType: string) {
  const labels: Record<string, string> = {
    indexerQuery: "Search",
    indexerRss: "RSS",
    indexerAuth: "Authentication",
    indexerInfo: "Info",
    releaseGrabbed: "Grab",
  };
  return labels[eventType] || eventType.replace(/([a-z])([A-Z])/g, "$1 $2") || "Activity";
}

function SyncIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <polyline points="23 4 23 10 17 10" />
      <polyline points="1 20 1 14 7 14" />
      <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
    </svg>
  );
}

function SpinIcon({ size = 12 }: { size?: number }) {
  return (
    <svg className="pwr-spin" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" aria-hidden>
      <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" />
    </svg>
  );
}

export default function ProwlarrWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "prowlarr";
  const [data, setData] = useState<Data | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<Tab>("overview");
  const [syncState, setSyncState] = useState<"idle" | "busy" | "ok" | "err">("idle");
  const [selectedIndexer, setSelectedIndexer] = useState<Indexer | null>(null);
  const [historyFilter, setHistoryFilter] = useState<HistoryFilter>("all");
  const [historySearch, setHistorySearch] = useState("");
  const [catalog, setCatalog] = useState<IndexerDefinition[] | null>(null);
  const [catalogLoading, setCatalogLoading] = useState(false);
  const [catalogError, setCatalogError] = useState("");
  const [addSearch, setAddSearch] = useState("");
  const [addProtocolFilter, setAddProtocolFilter] = useState("");
  const [addLanguageFilter, setAddLanguageFilter] = useState("");
  const [addPrivacyFilter, setAddPrivacyFilter] = useState("");
  const [indexersPrivacyFilter, setIndexersPrivacyFilter] = useState("");
  const [addCategoryFilter, setAddCategoryFilter] = useState("");
  const [selectedDefinition, setSelectedDefinition] = useState<IndexerDefinition | null>(null);
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);
  const statsRetryRef = useRef(false);
  const connectionSource: ConnectionSource = data?.connectionSource || "unknown";

  const loadCatalog = useCallback(async () => {
    setCatalogLoading(true);
    setCatalogError("");
    try {
      const response = await fetch(
        `/api/widgets/prowlarr/schema?instance=${encodeURIComponent(instanceId)}`,
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load indexer catalog");
      setCatalog(json);
    } catch (cause) {
      setCatalogError(cause instanceof Error ? cause.message : "Failed to load indexer catalog");
    } finally {
      setCatalogLoading(false);
    }
  }, [instanceId]);

  useEffect(() => {
    if (tab === "add" && catalog === null && !catalogLoading) {
      void loadCatalog();
    }
  }, [tab, catalog, catalogLoading, loadCatalog]);

  const load = useCallback(async () => {
    try {
      const response = await fetch(
        `/api/widgets/prowlarr/status?instance=${encodeURIComponent(instanceId)}`,
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load Prowlarr");
      setData(json);
      setError("");
      // Stats arrive on a soft-timeout path — one catch-up once the 5m cache fills.
      if (json.statsPending && !statsRetryRef.current) {
        statsRetryRef.current = true;
        window.setTimeout(() => {
          void load();
        }, 1200);
      } else if (!json.statsPending) {
        statsRetryRef.current = false;
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Failed to load Prowlarr");
    } finally {
      setLoading(false);
    }
  }, [instanceId]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: 120_000 });

  const status = useMemo(() => {
    if (!data && loading) return { cls: "pwr-status--idle", txt: "Connecting" };
    if (!data) return { cls: "pwr-status--warn", txt: "Offline" };
    if (data.totals.failing > 0) {
      return { cls: "pwr-status--warn", txt: `${data.totals.failing} Failing` };
    }
    return { cls: "pwr-status--active", txt: "Online" };
  }, [data, loading]);

  async function runSync() {
    if (syncState === "busy") return;
    setSyncState("busy");
    try {
      const response = await fetch("/api/widgets/prowlarr/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Sync failed");
      await load();
      setSyncState("ok");
      window.setTimeout(() => setSyncState("idle"), 1800);
    } catch {
      setSyncState("err");
      window.setTimeout(() => setSyncState("idle"), 2000);
    }
  }

  if (loading && !data) {
    return (
      <div className="hd-widget-body pwr-body-flat" ref={rootRef}>
        <div className="pwr-shell">
          <div className="pwr-loading">
            <SpinIcon size={16} /> Loading…
          </div>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="hd-widget-body pwr-body-flat" ref={rootRef}>
        <div className="pwr-shell">
          <div className="pwr-toolbar">
            <span className={`pwr-status ${status.cls}`}>{status.txt}</span>
            <button className="pwr-open-link" type="button" onClick={load}>
              Retry
            </button>
          </div>
          <div className="pwr-empty" style={{ color: "#f87171" }}>
            {error || "Failed to load Prowlarr data"}
          </div>
        </div>
      </div>
    );
  }

  const indexerName = (id: number) =>
    data.indexers.find((indexer) => indexer.id === id)?.name || `Indexer ${id}`;

  const healthyCount = Math.max(
    0,
    data.totals.enabled - data.totals.failing,
  );
  const fleetTotal = Math.max(data.totals.indexers, 1);
  const healthyPct = Math.round((healthyCount / fleetTotal) * 100);
  const disabledPct = Math.round((data.totals.disabled / fleetTotal) * 100);
  const failingPct = Math.round((data.totals.failing / fleetTotal) * 100);
  const grabSuccessPct =
    data.totals.grabs > 0
      ? Math.round(((data.totals.grabs - data.totals.failedGrabs) / data.totals.grabs) * 100)
      : 100;
  const querySuccessPct =
    data.totals.queries > 0
      ? Math.round(((data.totals.queries - data.totals.failedQueries) / data.totals.queries) * 100)
      : 100;
  const usenetCount = data.indexers.filter((indexer) => indexer.protocol === "usenet").length;
  const indexersPrivacyOptions = [
    ...new Set(data.indexers.map((indexer) => indexer.privacy).filter(Boolean)),
  ].sort();
  const filteredIndexers = data.indexers.filter(
    (indexer) => !indexersPrivacyFilter || indexer.privacy === indexersPrivacyFilter,
  );
  const topByGrabs = [...data.indexerStats]
    .sort((a, b) => b.numberOfGrabs - a.numberOfGrabs)
    .slice(0, 5);
  const maxTopGrabs = Math.max(...topByGrabs.map((stat) => stat.numberOfGrabs), 1);
  const recentHistory = data.history.slice(0, 12);
  const normalizedHistorySearch = historySearch.trim().toLowerCase();
  const filteredHistory = data.history.filter((item) => {
    const matchesFilter =
      historyFilter === "all" ||
      (historyFilter === "failed" && !item.successful) ||
      (historyFilter === "query" && item.eventType === "indexerQuery") ||
      (historyFilter === "rss" && item.eventType === "indexerRss") ||
      (historyFilter === "grab" && item.eventType === "releaseGrabbed") ||
      (historyFilter === "auth" && item.eventType === "indexerAuth");
    if (!matchesFilter) return false;
    if (!normalizedHistorySearch) return true;
    return [
      item.query,
      item.queryType,
      item.source,
      indexerName(item.indexerId),
      item.eventType,
    ].some((value) => value.toLowerCase().includes(normalizedHistorySearch));
  });
  const failedHistoryCount = data.history.filter((item) => !item.successful).length;
  const grabbedHistoryCount = data.history.filter(
    (item) => item.eventType === "releaseGrabbed",
  ).length;
  const addedDefinitionNames = new Set(
    data.indexers.map((indexer) => indexer.definitionName).filter(Boolean),
  );
  const normalizedAddSearch = addSearch.trim().toLowerCase();
  const protocolOptions = [...new Set((catalog || []).map((entry) => entry.protocol).filter(Boolean))].sort();
  const languageOptions = [...new Set((catalog || []).map((entry) => entry.language).filter(Boolean))].sort();
  const privacyOptions = [...new Set((catalog || []).map((entry) => entry.privacy).filter(Boolean))].sort();
  const categoryOptions = [...new Set((catalog || []).flatMap((entry) => entry.categories))].sort();
  const filteredCatalog = (catalog || []).filter((entry) => {
    if (addProtocolFilter && entry.protocol !== addProtocolFilter) return false;
    if (addLanguageFilter && entry.language !== addLanguageFilter) return false;
    if (addPrivacyFilter && entry.privacy !== addPrivacyFilter) return false;
    if (addCategoryFilter && !entry.categories.includes(addCategoryFilter)) return false;
    if (!normalizedAddSearch) return true;
    return [entry.name, entry.definitionName, entry.implementationName, entry.protocol, entry.privacy, entry.description]
      .some((value) => value.toLowerCase().includes(normalizedAddSearch));
  });

  return (
    <div className="hd-widget-body pwr-body-flat" ref={rootRef}>
      <div className="pwr-shell">
        <div className="pwr-toolbar">
          <div className="pwr-toolbar-left">
            <span className={`pwr-status ${status.cls}`}>{status.txt}</span>
          </div>
          <div className="pwr-toolbar-right">
            {openHref ? (
              <a className="pwr-open-link" href={openHref} target="_blank" rel="noopener noreferrer">
                Open
              </a>
            ) : null}
          </div>
        </div>

        <div className="pwr-controls">
          <div className="pwr-tabs">
            {TABS.map((item) => (
              <button
                key={item.key}
                type="button"
                className={`pwr-tab${tab === item.key ? " pwr-tab--active" : ""}`}
                onClick={() => setTab(item.key)}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>

        <div className="pwr-body">
          <div className={`pwr-scroll${tab === "overview" ? " pwr-scroll--overview" : ""}${tab === "add" ? " pwr-scroll--add" : ""}`}>
            <div className="pwr-scroll-inner">
              {tab === "overview" ? (
                <div className="pwr-overview">
                  <div className="pwr-stat-grid">
                    <div className="pwr-stat">
                      <div className="pwr-stat-value">{fmtNum(data.totals.indexers)}</div>
                      <div className="pwr-stat-label">Indexers</div>
                    </div>
                    <div className="pwr-stat pwr-stat--good">
                      <div className="pwr-stat-value">{fmtNum(data.totals.enabled)}</div>
                      <div className="pwr-stat-label">Enabled</div>
                    </div>
                    <div className="pwr-stat pwr-stat--warn">
                      <div className="pwr-stat-value">{fmtNum(data.totals.disabled)}</div>
                      <div className="pwr-stat-label">Disabled</div>
                    </div>
                    <div className="pwr-stat">
                      <div className="pwr-stat-value">{fmtNum(data.totals.torrent)}</div>
                      <div className="pwr-stat-label">Torrent</div>
                    </div>
                    <div className={`pwr-stat${data.totals.failing ? " pwr-stat--warn" : ""}`}>
                      <div className="pwr-stat-value">{fmtNum(data.totals.failing)}</div>
                      <div className="pwr-stat-label">Failing Now</div>
                    </div>
                    <div className="pwr-stat pwr-stat--active">
                      <div className="pwr-stat-value">{fmtNum(data.totals.grabs)}</div>
                      <div className="pwr-stat-label">Total Grabs</div>
                    </div>
                    <div className="pwr-stat">
                      <div className="pwr-stat-value">{fmtNum(data.totals.queries)}</div>
                      <div className="pwr-stat-label">Queries</div>
                    </div>
                    <div className="pwr-stat pwr-stat--warn">
                      <div className="pwr-stat-value">{fmtNum(data.totals.failedGrabs)}</div>
                      <div className="pwr-stat-label">Failed Grabs</div>
                    </div>
                  </div>

                  <div className="pwr-overview-panels">
                    <div className="pwr-panel">
                      <div className="pwr-panel-hdr">Fleet health</div>
                      <div className="pwr-stack-bar" aria-hidden>
                        {healthyPct > 0 ? (
                          <span className="pwr-stack-seg pwr-stack-seg--good" style={{ width: `${healthyPct}%` }} />
                        ) : null}
                        {disabledPct > 0 ? (
                          <span className="pwr-stack-seg pwr-stack-seg--warn" style={{ width: `${disabledPct}%` }} />
                        ) : null}
                        {failingPct > 0 ? (
                          <span className="pwr-stack-seg pwr-stack-seg--bad" style={{ width: `${failingPct}%` }} />
                        ) : null}
                      </div>
                      <div className="pwr-legend-row">
                        <span className="pwr-legend-item">
                          <i className="pwr-legend-swatch pwr-legend-swatch--good" />
                          {healthyCount} healthy
                        </span>
                        <span className="pwr-legend-item">
                          <i className="pwr-legend-swatch pwr-legend-swatch--warn" />
                          {data.totals.disabled} disabled
                        </span>
                        <span className="pwr-legend-item">
                          <i className="pwr-legend-swatch pwr-legend-swatch--bad" />
                          {data.totals.failing} failing
                        </span>
                      </div>
                      <div className="pwr-kpi-row">
                        <div className="pwr-kpi">
                          <div className="pwr-kpi-value pwr-kpi-value--active">{grabSuccessPct}%</div>
                          <div className="pwr-kpi-label">Grab success</div>
                        </div>
                        <div className="pwr-kpi">
                          <div className="pwr-kpi-value">{fmtNum(usenetCount)}</div>
                          <div className="pwr-kpi-label">Usenet</div>
                        </div>
                        <div className="pwr-kpi">
                          <div className="pwr-kpi-value">{fmtNum(data.totals.torrent)}</div>
                          <div className="pwr-kpi-label">Torrent</div>
                        </div>
                        <div className="pwr-kpi">
                          <div className="pwr-kpi-value">
                            {data.totals.queries
                              ? (data.totals.grabs / data.totals.queries).toFixed(2)
                              : "—"}
                          </div>
                          <div className="pwr-kpi-label">Grabs / query</div>
                        </div>
                      </div>
                    </div>

                    <div className="pwr-panel">
                      <div className="pwr-panel-hdr">Top indexers by grabs</div>
                      {topByGrabs.length ? (
                        <div className="pwr-chart-list">
                          {topByGrabs.map((stat) => {
                            const pct = Math.round((stat.numberOfGrabs / maxTopGrabs) * 100);
                            return (
                              <div className="pwr-chart-row" key={`${stat.indexerId}-${stat.indexerName}`}>
                                <div className="pwr-chart-name" title={stat.indexerName}>
                                  {stat.indexerName}
                                </div>
                                <div className="pwr-chart-bar-wrap">
                                  <div className="pwr-bar-track">
                                    <div className="pwr-bar-fill" style={{ width: `${pct}%` }} />
                                  </div>
                                  <span className="pwr-stat-row-count">{fmtNum(stat.numberOfGrabs)}</span>
                                </div>
                                <div className="pwr-chart-meta">
                                  {fmtNum(stat.numberOfQueries)} q · {fmtNum(stat.numberOfFailedGrabs)} failed
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      ) : (
                        <div className="pwr-empty pwr-empty--compact">No grab stats yet</div>
                      )}
                    </div>

                    <div className="pwr-panel pwr-panel--wide">
                      <div className="pwr-panel-hdr">Recent activity</div>
                      {recentHistory.length ? (
                        <div className="pwr-list pwr-list--compact">
                          {recentHistory.map((item, index) => {
                            const title = item.query
                              ? `${item.query}${item.queryType ? ` (${item.queryType})` : ""}`
                              : item.queryType
                                ? item.queryType.replace(/([a-z])([A-Z])/g, "$1 $2")
                                : "RSS Fetch";
                            return (
                              <div
                                className="pwr-row pwr-row--compact"
                                key={`${item.date}-${item.indexerId}-${index}`}
                              >
                                <span
                                  className={`pwr-dot ${item.successful ? "pwr-dot--enabled" : "pwr-dot--disabled"}`}
                                />
                                <div className="pwr-row-body">
                                  <div className="pwr-row-title">{title}</div>
                                  <div className="pwr-row-sub">
                                    {indexerName(item.indexerId)}
                                    {item.source ? ` · ${item.source}` : ""}
                                    {item.queryResults != null ? ` · ${item.queryResults} results` : ""}
                                  </div>
                                </div>
                                <div className="pwr-row-meta">
                                  <span className="pwr-time">{fmtTime(item.date)}</span>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      ) : (
                        <div className="pwr-empty pwr-empty--compact">No recent history</div>
                      )}
                    </div>
                  </div>
                </div>
              ) : null}

              {tab === "indexers" ? (
                data.indexers.length ? (
                  <>
                    {indexersPrivacyOptions.length ? (
                      <div className="pwr-add-filters">
                        <label className="pwr-add-filter">
                          <span>Privacy</span>
                          <select
                            value={indexersPrivacyFilter}
                            onChange={(event) => setIndexersPrivacyFilter(event.target.value)}
                          >
                            <option value="">All privacy</option>
                            {indexersPrivacyOptions.map((option) => (
                              <option value={option} key={option}>{option}</option>
                            ))}
                          </select>
                        </label>
                        {indexersPrivacyFilter ? (
                          <button
                            className="pwr-add-filter-clear"
                            type="button"
                            onClick={() => setIndexersPrivacyFilter("")}
                          >
                            Clear filter
                          </button>
                        ) : null}
                      </div>
                    ) : null}
                    {filteredIndexers.length ? (
                      <div className="pwr-list">
                        {filteredIndexers.map((indexer) => {
                          const protoCls =
                            indexer.protocol === "torrent" ? "pwr-proto--torrent" : "pwr-proto--usenet";
                          const statusCls = indexer.failing
                            ? "pwr-dot--error"
                            : indexer.enable
                              ? "pwr-dot--enabled"
                              : "pwr-dot--disabled";
                          const tillStr = fmtTill(indexer.disabledTill);
                          const sub = indexer.failing
                            ? tillStr
                              ? `Disabled till ${tillStr}`
                              : "Currently failing"
                            : indexer.definitionName || "";
                          return (
                            <button
                              className="pwr-row pwr-row--interactive"
                              type="button"
                              key={indexer.id}
                              onClick={() => setSelectedIndexer(indexer)}
                            >
                              <span className={`pwr-dot ${statusCls}`} />
                              <div className="pwr-row-body">
                                <div className="pwr-row-title">{indexer.name}</div>
                                {sub ? <div className="pwr-row-sub">{sub}</div> : null}
                              </div>
                              <div className="pwr-row-meta">
                                {indexer.privacy ? (
                                  <span className={`pwr-privacy pwr-privacy--${indexer.privacy}`}>
                                    {indexer.privacy}
                                  </span>
                                ) : null}
                                <span className={`pwr-proto ${protoCls}`}>{indexer.protocol || "—"}</span>
                                <span className="pwr-row-chevron">›</span>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="pwr-empty">No indexers match the selected filter</div>
                    )}
                  </>
                ) : (
                  <div className="pwr-empty">No indexers found</div>
                )
              ) : null}

              {tab === "add" ? (
                <div className="pwr-add-dashboard">
                  <div className="pwr-history-tools">
                    <label>
                      <span aria-hidden="true">⌕</span>
                      <input
                        type="search"
                        value={addSearch}
                        placeholder="Search indexer name, protocol, or language…"
                        onChange={(event) => setAddSearch(event.target.value)}
                      />
                    </label>
                    <button
                      className="pwr-open-link"
                      type="button"
                      onClick={loadCatalog}
                      disabled={catalogLoading}
                    >
                      {catalogLoading ? <SpinIcon /> : <SyncIcon />}
                      {catalogLoading ? " Loading…" : " Refresh"}
                    </button>
                  </div>

                  {catalog ? (
                    <div className="pwr-add-filters">
                      <label className="pwr-add-filter">
                        <span>Protocol</span>
                        <select value={addProtocolFilter} onChange={(event) => setAddProtocolFilter(event.target.value)}>
                          <option value="">All protocols</option>
                          {protocolOptions.map((option) => (
                            <option value={option} key={option}>{option}</option>
                          ))}
                        </select>
                      </label>
                      <label className="pwr-add-filter">
                        <span>Language</span>
                        <select value={addLanguageFilter} onChange={(event) => setAddLanguageFilter(event.target.value)}>
                          <option value="">All languages</option>
                          {languageOptions.map((option) => (
                            <option value={option} key={option}>{option}</option>
                          ))}
                        </select>
                      </label>
                      <label className="pwr-add-filter">
                        <span>Privacy</span>
                        <select value={addPrivacyFilter} onChange={(event) => setAddPrivacyFilter(event.target.value)}>
                          <option value="">All privacy</option>
                          {privacyOptions.map((option) => (
                            <option value={option} key={option}>{option}</option>
                          ))}
                        </select>
                      </label>
                      <label className="pwr-add-filter">
                        <span>Categories</span>
                        <select value={addCategoryFilter} onChange={(event) => setAddCategoryFilter(event.target.value)}>
                          <option value="">All categories</option>
                          {categoryOptions.map((option) => (
                            <option value={option} key={option}>{option}</option>
                          ))}
                        </select>
                      </label>
                      {addProtocolFilter || addLanguageFilter || addPrivacyFilter || addCategoryFilter ? (
                        <button
                          className="pwr-add-filter-clear"
                          type="button"
                          onClick={() => {
                            setAddProtocolFilter("");
                            setAddLanguageFilter("");
                            setAddPrivacyFilter("");
                            setAddCategoryFilter("");
                          }}
                        >
                          Clear filters
                        </button>
                      ) : null}
                    </div>
                  ) : null}

                  <div className="pwr-add-results">
                    {catalogLoading && !catalog ? (
                      <div className="pwr-loading">
                        <SpinIcon size={16} /> Loading indexer catalog…
                      </div>
                    ) : catalogError && !catalog ? (
                      <div className="pwr-empty" style={{ color: "#f87171" }}>{catalogError}</div>
                    ) : catalog ? (
                      filteredCatalog.length ? (
                        <>
                          <div className="pwr-history-result-head">
                            <span>{fmtNum(filteredCatalog.length)} of {fmtNum(catalog.length)} indexers</span>
                            <span>Tap to configure &amp; add</span>
                          </div>
                          <div className="pwr-list">
                            {filteredCatalog.map((entry, entryIndex) => {
                              const protoCls =
                                entry.protocol === "torrent" ? "pwr-proto--torrent" : "pwr-proto--usenet";
                              const isAdded = addedDefinitionNames.has(entry.definitionName);
                              return (
                                <button
                                  className="pwr-row pwr-row--interactive"
                                  type="button"
                                  key={`${entry.definitionName}-${entry.protocol}-${entry.privacy}-${entryIndex}`}
                                  onClick={() => setSelectedDefinition(entry)}
                                >
                                  <span className={`pwr-dot pwr-dot--privacy-${entry.privacy || "unknown"}`} />
                                  <div className="pwr-row-body">
                                    <div className="pwr-row-title">{entry.name}</div>
                                    <div className="pwr-row-sub">
                                      {entry.description || entry.implementationName || "Indexer definition"}
                                    </div>
                                  </div>
                                  <div className="pwr-row-meta">
                                    {isAdded ? <span className="pwr-added-badge">Added</span> : null}
                                    {entry.privacy ? <span className={`pwr-privacy pwr-privacy--${entry.privacy}`}>{entry.privacy}</span> : null}
                                    {entry.protocol ? <span className={`pwr-proto ${protoCls}`}>{entry.protocol}</span> : null}
                                    <span className="pwr-row-chevron">›</span>
                                  </div>
                                </button>
                              );
                            })}
                          </div>
                        </>
                      ) : (
                        <div className="pwr-empty">
                          {addSearch ? `No indexers match "${addSearch}"` : "No indexers match the selected filters"}
                        </div>
                      )
                    ) : null}
                  </div>
                </div>
              ) : null}

              {tab === "history" ? (
                data.history.length ? (
                  <div className="pwr-history-dashboard">
                    <div className="pwr-history-summary">
                      <div><strong>{fmtNum(data.history.length)}</strong><span>Recent events</span></div>
                      <div><strong>{fmtNum(data.history.length - failedHistoryCount)}</strong><span>Successful</span></div>
                      <div className={failedHistoryCount ? "has-warning" : ""}><strong>{fmtNum(failedHistoryCount)}</strong><span>Failed</span></div>
                      <div><strong>{fmtNum(grabbedHistoryCount)}</strong><span>Grabs</span></div>
                    </div>

                    <div className="pwr-history-tools">
                      <label>
                        <span aria-hidden="true">⌕</span>
                        <input
                          type="search"
                          value={historySearch}
                          placeholder="Search query, indexer, or app…"
                          onChange={(event) => setHistorySearch(event.target.value)}
                        />
                      </label>
                      <div className="pwr-history-filters">
                        {([
                          ["all", "All"],
                          ["query", "Searches"],
                          ["rss", "RSS"],
                          ["grab", "Grabs"],
                          ["auth", "Auth"],
                          ["failed", "Failed"],
                        ] as Array<[HistoryFilter, string]>).map(([key, label]) => (
                          <button
                            className={historyFilter === key ? "is-active" : ""}
                            type="button"
                            key={key}
                            onClick={() => setHistoryFilter(key)}
                          >
                            {label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="pwr-history-result-head">
                      <span>{fmtNum(filteredHistory.length)} matching events</span>
                      <span>Newest first</span>
                    </div>

                    {filteredHistory.length ? (
                      <div className="pwr-history-list">
                    {filteredHistory.map((item, index) => {
                      const indexer = data.indexers.find((entry) => entry.id === item.indexerId);
                      const title = item.query || historyEventLabel(item.eventType);
                      const queryType = item.queryType
                        ? item.queryType.replace(/([a-z])([A-Z])/g, "$1 $2")
                        : "";
                      return (
                        <button
                          className={`pwr-history-event${item.successful ? "" : " is-failed"}`}
                          type="button"
                          key={item.id || `${item.date}-${item.indexerId}-${index}`}
                          onClick={() => indexer && setSelectedIndexer(indexer)}
                        >
                          <span className={`pwr-history-event__icon is-${item.eventType.toLowerCase()}`}>
                            {item.successful ? "✓" : "!"}
                          </span>
                          <div className="pwr-history-event__body">
                            <div className="pwr-history-event__title">
                              <strong>{title}</strong>
                              <span>{historyEventLabel(item.eventType)}</span>
                            </div>
                            <div className="pwr-history-event__details">
                              <span>{indexerName(item.indexerId)}</span>
                              {indexer?.protocol ? <span>{indexer.protocol}</span> : null}
                              {item.source ? <span>{item.source}</span> : null}
                              {queryType ? <span>{queryType}</span> : null}
                              {item.queryResults != null ? (
                                <span>{fmtNum(Number(item.queryResults) || 0)} results</span>
                              ) : null}
                              {item.downloadId ? <span>Download recorded</span> : null}
                            </div>
                          </div>
                          <div className="pwr-history-event__time">
                            <strong>{fmtTime(item.date)}</strong>
                            <span>{fmtDateTime(item.date)}</span>
                          </div>
                        </button>
                      );
                    })}
                      </div>
                    ) : (
                      <div className="pwr-empty">No history matches these filters</div>
                    )}
                  </div>
                ) : (
                  <div className="pwr-empty">No history found</div>
                )
              ) : null}

              {tab === "stats" ? (
                data.indexerStats.length ? (
                  <div className="pwr-stats-dashboard">
                    <div className="pwr-stats-summary">
                      <div className="pwr-stats-kpi">
                        <span>Total queries</span>
                        <strong>{fmtNum(data.totals.queries)}</strong>
                        <small>{fmtNum(data.totals.rssQueries)} RSS · {fmtNum(data.totals.authQueries)} auth</small>
                      </div>
                      <div className="pwr-stats-kpi">
                        <span>Successful grabs</span>
                        <strong>{fmtNum(Math.max(0, data.totals.grabs - data.totals.failedGrabs))}</strong>
                        <small>{grabSuccessPct}% grab success</small>
                      </div>
                      <div className={`pwr-stats-kpi${data.totals.failedQueries + data.totals.failedGrabs ? " has-warning" : ""}`}>
                        <span>Total failures</span>
                        <strong>{fmtNum(data.totals.failedQueries + data.totals.failedGrabs)}</strong>
                        <small>{fmtNum(data.totals.failedQueries)} searches · {fmtNum(data.totals.failedGrabs)} grabs</small>
                      </div>
                      <div className="pwr-stats-kpi">
                        <span>Average response</span>
                        <strong>{fmtDuration(data.totals.averageResponseTime)}</strong>
                        <small>{querySuccessPct}% query success</small>
                      </div>
                    </div>

                    <div className="pwr-stats-section-head">
                      <div>
                        <strong>Indexer performance</strong>
                        <span>Queries, grabs, reliability and response time</span>
                      </div>
                      <span>{data.indexerStats.length} indexers</span>
                    </div>

                    <div className="pwr-stats-grid">
                    {[...data.indexerStats]
                      .sort((a, b) => b.numberOfGrabs - a.numberOfGrabs)
                      .map((stat) => {
                        const indexer = data.indexers.find((item) => item.id === stat.indexerId);
                        const successPct = stat.numberOfQueries
                          ? Math.round(
                              ((stat.numberOfQueries - stat.numberOfFailedQueries) /
                                stat.numberOfQueries) *
                                100,
                            )
                          : 100;
                        const grabPct = stat.numberOfGrabs
                          ? Math.round(
                              ((stat.numberOfGrabs - stat.numberOfFailedGrabs) /
                                stat.numberOfGrabs) *
                                100,
                            )
                          : 100;
                        const failureTotal = stat.numberOfFailedQueries + stat.numberOfFailedGrabs;
                        return (
                          <button
                            className={`pwr-performance-card${failureTotal ? " has-failures" : ""}`}
                            type="button"
                            key={`${stat.indexerId}-${stat.indexerName}`}
                            onClick={() => indexer && setSelectedIndexer(indexer)}
                          >
                            <div className="pwr-performance-card__head">
                              <div>
                                <span className={`pwr-dot ${
                                  indexer?.failing
                                    ? "pwr-dot--error"
                                    : indexer?.enable === false
                                      ? "pwr-dot--disabled"
                                      : "pwr-dot--enabled"
                                }`} />
                                <strong>{stat.indexerName}</strong>
                              </div>
                              <span>{indexer?.protocol || "indexer"} · Manage ›</span>
                            </div>
                            <div className="pwr-performance-card__metrics">
                              <div><strong>{fmtNum(stat.numberOfQueries)}</strong><span>queries</span></div>
                              <div><strong>{fmtNum(stat.numberOfGrabs)}</strong><span>grabs</span></div>
                              <div><strong>{fmtDuration(stat.averageResponseTime)}</strong><span>response</span></div>
                              <div><strong>{successPct}%</strong><span>reliable</span></div>
                            </div>
                            <div className="pwr-performance-card__bar" aria-label={`${successPct}% query success`}>
                              <span style={{ width: `${successPct}%` }} />
                            </div>
                            <div className="pwr-performance-card__foot">
                              <span>{fmtNum(stat.numberOfRssQueries)} RSS</span>
                              <span>{fmtNum(stat.numberOfAuthQueries)} auth</span>
                              <span>{grabPct}% grab success</span>
                              <span className={failureTotal ? "is-failure" : ""}>
                                {fmtNum(failureTotal)} failed
                              </span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ) : (
                  <div className="pwr-empty">No stats available</div>
                )
              ) : null}
            </div>
          </div>
        </div>

        <div className="pwr-footer">
          <span className="pwr-footer-meta">Prowlarr</span>
          <button
            className={`pwr-sync-btn${syncState === "busy" ? " pwr-sync-btn--busy" : ""}${syncState === "ok" ? " pwr-sync-btn--ok" : ""}${syncState === "err" ? " pwr-sync-btn--err" : ""}`}
            type="button"
            disabled={syncState === "busy" || syncState === "ok"}
            title="Sync indexers to connected apps"
            onClick={runSync}
          >
            {syncState === "busy" ? (
              <>
                <SpinIcon /> Syncing…
              </>
            ) : syncState === "ok" ? (
              <>Synced</>
            ) : syncState === "err" ? (
              <>Failed</>
            ) : (
              <>
                <SyncIcon /> Sync
              </>
            )}
          </button>
        </div>
      </div>
      {selectedIndexer ? (
        <IndexerManagerModal
          instanceId={instanceId}
          summary={selectedIndexer}
          onClose={() => setSelectedIndexer(null)}
          onChanged={() => void load()}
        />
      ) : null}
      {selectedDefinition ? (
        <AddIndexerModal
          instanceId={instanceId}
          definition={selectedDefinition}
          onClose={() => setSelectedDefinition(null)}
          onAdded={() => void load()}
        />
      ) : null}
      <ConnectionCorner source={connectionSource} />
    </div>
  );
}
