import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "prowlarr",
  name: "Prowlarr",
  description: "Indexer manager with overview, history, and sync",
  version: "0.3.2",
  category: "Media",
  defaultSize: { w: 6, h: 5, minW: 3, minH: 3 },
  hostClass: "pwr-host",
  configFields: [
    { key: "baseUrl", label: "Private - IP", type: "url", placeholder: "http://10.0.0.1:9696" },
    { key: "fallbackUrl", label: "Fallback Public URL", type: "url", placeholder: "https://prowlarr.example.com" },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url", placeholder: "http://10.0.0.1:9696" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    { key: "apiKey", label: "API Key", type: "password", required: true },
  ],
};
