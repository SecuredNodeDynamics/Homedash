"use client";
import "@/styles/widgets/proxmox.widget.css";


import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";
import dynamic from "next/dynamic";
import { useAuthPermission } from "@/lib/use-auth-permission";
import { OverviewTab } from "./components/OverviewTab";
import { GuestsTab } from "./components/GuestsTab";
import { NetworkTab } from "./components/NetworkTab";
import { StorageTab } from "./components/StorageTab";
import { HardwareTab } from "./components/HardwareTab";
import { BackupsTab } from "./components/BackupsTab";
import { SecurityTab } from "./components/SecurityTab";
import { BackupJobModal } from "./components/modals/BackupJobModal";
import { TabErrorBoundary } from "./components/TabErrorBoundary";
import { GuestModal } from "./components/modals/GuestModal";
import { BulkUpdateModal } from "./components/modals/BulkUpdateModal";
import { DiskModal, GpuDetailModal, IfaceModal, PciDetailModal } from "./components/modals/DiskModal";
import { ScriptRunnerModal } from "./components/modals/ScriptRunnerModal";
import { PrxGuideModal } from "./components/modals/PrxGuideModal";
import { mergeDegraded } from "./merge";
import { readProxmoxCache, hydrateProxmoxCache, writeProxmoxCache, writeProxmoxTab } from "./cache";
import {
  applyLiveOverridesToStatus,
  liveRecheckRunningLxcs,
  markGuestsCleared,
  setLiveUpdateOverride,
} from "./live-updates";
import type { Guest, StatusPayload, TabKey, BackupSchedule } from "./types";
import type { TermAutoRun } from "./components/modals/TermModal";

const TermModal = dynamic(
  () => import("./components/modals/TermModal").then((mod) => mod.TermModal),
  { ssr: false },
);

const TABS: Array<{ key: TabKey; label: string }> = [
  { key: "overview", label: "Overview" },
  { key: "network", label: "Network" },
  { key: "guests", label: "VMs & LXCs" },
  { key: "storage", label: "Storage" },
  { key: "hardware", label: "Hardware" },
  { key: "backups", label: "Backups" },
  { key: "security", label: "Security" },
];

const EMPTY_HISTORY = { cpu: [] as number[], mem: [] as number[], rx: [] as number[] };

const CONNECTION_SOURCE_LABEL: Record<"private" | "public", string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Fallback Public URL (Cloudflare)",
};

function ConnectionCorner({ source }: { source: "private" | "public" | "unknown" }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const mark = (
    <div
      className={`pve-corner-source pve-corner-source--${source}`}
      title={CONNECTION_SOURCE_LABEL[source]}
      aria-label={CONNECTION_SOURCE_LABEL[source]}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}

export default function ProxmoxNodesWidget() {
  const canUseTerminal = useAuthPermission("terminals.use");
  const canControlPower = useAuthPermission("proxmox.control");
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "proxmox-nodes";
  const label = instance?.label || "Proxmox";
  const showIcon = instance?.showIcon !== false;
  const showTitle = instance?.showTitle !== false;
  const iconUrl =
    instance?.iconUrl?.trim() ||
    "https://cdn.jsdelivr.net/gh/homarr-labs/dashboard-icons/webp/proxmox.webp";
  // Module Map only here (SSR-safe). sessionStorage restored in useLayoutEffect.
  const cached = readProxmoxCache(instanceId);
  const [data, setData] = useState<StatusPayload | null>(cached?.data ?? null);
  const [error, setError] = useState("");
  const [tab, setTab] = useState<TabKey>(cached?.tab ?? "overview");
  const [history, setHistory] = useState<{ cpu: number[]; mem: number[]; rx: number[] }>(
    cached?.history ?? EMPTY_HISTORY,
  );
  const [guest, setGuest] = useState<Guest | null>(null);
  const [term, setTerm] = useState<
    { mode: "host" | "guest"; guest?: Guest | null; autoRun?: TermAutoRun } | null
  >(null);
  const [updatingVmid, setUpdatingVmid] = useState<number | null>(null);
  const [disk, setDisk] = useState<Record<string, unknown> | null>(null);
  const [iface, setIface] = useState<Record<string, unknown> | null>(null);
  const [gpu, setGpu] = useState<Record<string, unknown> | null>(null);
  const [pci, setPci] = useState<Record<string, unknown> | null>(null);
  const [script, setScript] = useState<{ title: string; scriptPath: string; params?: Record<string, string> } | null>(null);
  const [prxGuide, setPrxGuide] = useState<{ rejected?: boolean } | null>(null);
  const [bulkBusy, setBulkBusy] = useState(false);
  const [bulkRecheckLabel, setBulkRecheckLabel] = useState("");
  const [bulkUpdateGuests, setBulkUpdateGuests] = useState<Guest[] | null>(null);
  const [editingBackupJob, setEditingBackupJob] = useState<BackupSchedule | null | undefined>(undefined);

  useLayoutEffect(() => {
    const warm = hydrateProxmoxCache(instanceId);
    if (!warm?.data) return;
    setData((current) => current || applyLiveOverridesToStatus(instanceId, warm.data!));
    setTab(warm.tab);
    setHistory((current) =>
      current.cpu.length || current.mem.length || current.rx.length ? current : warm.history,
    );
  }, [instanceId]);

  // Latest data for the poll callback (so it never merges against a stale closure).
  const dataRef = useRef<StatusPayload | null>(data);
  dataRef.current = data;
  const offlineStrikes = useRef(0);

  const load = useCallback(async () => {
    try {
      const response = await fetch(`/api/widgets/proxmox-nodes/status?instance=${encodeURIComponent(instanceId)}`);
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load Proxmox");
      const incoming = json as StatusPayload;
      // One flaky poll reporting the node offline shouldn't blank a working widget:
      // keep what we have for up to two consecutive offline answers.
      if (incoming.pveOnline === false && dataRef.current?.pveOnline && offlineStrikes.current < 2) {
        offlineStrikes.current += 1;
        return;
      }
      offlineStrikes.current = 0;
      const merged = applyLiveOverridesToStatus(instanceId, mergeDegraded(dataRef.current, incoming));
      setData(merged);
      setError("");
      setHistory((prev) => {
        const next = {
          cpu: [...prev.cpu, Number(merged.overview?.liveCpuPct || 0)].slice(-40),
          mem: [...prev.mem, Number(merged.overview?.liveMemPct || 0)].slice(-40),
          rx: [...prev.rx, Number(merged.overview?.rxBytes || 0)].slice(-40),
        };
        writeProxmoxCache(instanceId, { data: merged, history: next });
        return next;
      });
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Failed to load Proxmox");
    }
  }, [instanceId]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: 30_000 });

  useEffect(() => {
    writeProxmoxTab(instanceId, tab);
  }, [instanceId, tab]);

  const vmRunning = useMemo(() => data?.vms.filter((v) => v.status === "running").length || 0, [data]);
  const lxcRunning = useMemo(() => data?.lxcs.filter((v) => v.status === "running").length || 0, [data]);
  const serverOpenHref = useOpenHref(data?.href, data?.openFallbackUrl);
  const monitorOpenHref = useOpenHref(data?.prxHref, data?.prxOpenFallbackUrl);

  function requirePrx(next?: () => void) {
    if (data?.prxConfigured) {
      next?.();
      return true;
    }
    setPrxGuide({ rejected: false });
    return false;
  }

  async function bulkRecheck() {
    if (!requirePrx()) return;
    setBulkBusy(true);
    setBulkRecheckLabel("Rechecking…");
    try {
      // Best-effort MONITOR refresh (often stale); live apt scan is the source of truth.
      try {
        await fetch("/api/widgets/proxmox-nodes/proxmenux", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ instance: instanceId, path: "/api/vms", body: {} }),
        });
      } catch {
        // ignore
      }
      const items = Array.isArray(data?.guests?.items) ? data!.guests!.items : [];
      await liveRecheckRunningLxcs(instanceId, items, {
        onProgress: ({ label: progress }) => setBulkRecheckLabel(`Rechecking ${progress}`),
      });
      await load();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Recheck failed");
    } finally {
      setBulkBusy(false);
      setBulkRecheckLabel("");
    }
  }

  function openBulkUpdate() {
    if (!requirePrx()) return;
    const items = Array.isArray(data?.guests?.items) ? data!.guests!.items : [];
    setBulkUpdateGuests(items);
  }

  /**
   * Open a single LXC's terminal and auto-run its update sequence, then refresh
   * its pending-update count. Most containers support `apt-get update && apt-get
   * full-upgrade`; some (e.g. app-specific containers like Immich) don't support
   * that directly and instead ship a dedicated `update` command — fall back to
   * that when `apt-get` isn't available.
   */
  function openGuestUpdate(g: Guest) {
    if (!requirePrx()) return;
    setUpdatingVmid(g.id);
    // Close the guest detail modal first so stacked backdrops can't eat the open gesture.
    setGuest(null);
    window.setTimeout(() => {
      setTerm({
        mode: "guest",
        guest: g,
        autoRun: {
          steps: [
            {
              label: `Updating ${g.name || `#${g.id}`}…`,
              cmd:
                "if command -v apt-get >/dev/null 2>&1; then " +
                "export DEBIAN_FRONTEND=noninteractive; apt-get update && apt-get full-upgrade -y; " +
                "else update; fi",
              timeoutMs: 20 * 60 * 1000,
            },
            {
              label: "Refreshing package list…",
              cmd:
                'if command -v apt >/dev/null 2>&1; then ' +
                'apt list --upgradable 2>/dev/null | grep -v "^Listing" || true; fi',
              timeoutMs: 60_000,
              parse: "aptUpgradable",
            },
          ],
          onDone: (result) => {
            if (result.ok) {
              setLiveUpdateOverride(
                instanceId,
                g.id,
                result.updateCheck || {
                  available: false,
                  count: 0,
                  security_count: 0,
                  last_check: new Date().toISOString(),
                  packages: [],
                },
              );
            }
            setUpdatingVmid(null);
            void load();
          },
        },
      });
    }, 120);
  }

  async function afterBulkUpdate(okVmids: number[] = []) {
    if (okVmids.length) markGuestsCleared(instanceId, okVmids);
    try {
      await fetch("/api/widgets/proxmox-nodes/proxmenux", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, path: "/api/vms", body: {} }),
      });
    } catch {
      // ignore
    }
    // Live-confirm anything still showing a badge (failed guests / MONITOR lag).
    try {
      const items = Array.isArray(data?.guests?.items) ? data!.guests!.items : [];
      const patched = items.map((g) =>
        okVmids.includes(g.id)
          ? {
              ...g,
              updateCheck: {
                available: false,
                count: 0,
                security_count: 0,
                last_check: new Date().toISOString(),
                packages: [],
              },
            }
          : g,
      );
      await liveRecheckRunningLxcs(instanceId, patched, { onlyPending: true });
    } catch {
      // overrides from markGuestsCleared still apply via load()
    }
    await load();
  }

  if (!data) {
    return (
      <div className="hd-widget-body" ref={rootRef}>
        <div className="pve-shell pve-scifi">
          <div className="pve-offline-msg">{error || "Loading Proxmox…"}</div>
        </div>
      </div>
    );
  }

  const online = data.pveOnline;

  return (
    <div className="hd-widget-body" ref={rootRef}>
      <ConnectionCorner source={data.connectionSource || "unknown"} />
      <div className="pve-shell pve-scifi" data-pve-group={instanceId}>
          <div className="pve-header">
            <div className="pve-header-top">
              {showIcon || showTitle ? (
                <div className="pve-header-left">
                  {showIcon ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img className="pve-node-icon" src={iconUrl} alt="" />
                  ) : null}
                  {showTitle ? (
                    <div className="pve-node-title" style={{ color: data.color }}>
                      {label}
                    </div>
                  ) : null}
                </div>
              ) : null}
              <div className="pve-header-right">
                {data.vms.length > 0 ? (
                  <span className="pve-guest-pill pve-guest-pill--vm">
                    <span className="dot" />
                    {vmRunning}/{data.vms.length} VMs
                  </span>
                ) : null}
                <span className="pve-guest-pill pve-guest-pill--lxc">
                  <span className="dot" />
                  {lxcRunning}/{data.lxcs.length} LXC
                </span>
                <span className={`pve-status-badge ${online ? "pve-status-badge--online" : "pve-status-badge--offline"}`}>
                  <span className="pve-status-dot" />{online ? "ONLINE" : "OFFLINE"}
                </span>
                {canUseTerminal ? (
                  <button
                    type="button"
                    className="pve-open-link pve-open-link--term"
                    onClick={(e) => {
                      e.stopPropagation();
                      if (!requirePrx()) return;
                      window.setTimeout(() => setTerm({ mode: "host" }), 120);
                    }}
                    onPointerUp={(e) => e.stopPropagation()}
                  >
                    Terminal
                  </button>
                ) : null}
                <a className="pve-open-link pve-open-link--pve" href={serverOpenHref} target="_blank" rel="noopener noreferrer">SERVER ↗</a>
                {data.prxHref ? (
                  data.prxConfigured ? (
                    <a className="prx-open-link prx-open-link--prx" href={monitorOpenHref} target="_blank" rel="noopener noreferrer">MONITOR ↗</a>
                  ) : (
                    <button type="button" className="prx-open-link prx-open-link--prx" onClick={() => setPrxGuide({})}>
                      MONITOR ↗
                    </button>
                  )
                ) : (
                  <button type="button" className="prx-open-link prx-open-link--prx" onClick={() => setPrxGuide({})}>
                    MONITOR ↗
                  </button>
                )}
              </div>
            </div>
            <div className="pve-tabs" role="tablist" aria-label="Node views">
              {TABS.map((item) => (
                <button
                  key={item.key}
                  type="button"
                  className={`pve-tab${tab === item.key ? " pve-tab--active" : ""}`}
                  onClick={() => setTab(item.key)}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          <div className="pve-body">
            {!online ? (
              <div className="pve-offline-msg">{error || "Node unreachable"}</div>
            ) : (
              <TabErrorBoundary name={tab} key={tab}>
                {tab === "overview" ? <OverviewTab data={data} history={history} /> : null}
                {tab === "network" ? (
                  <NetworkTab
                    data={data}
                    onOpenIface={setIface}
                    onOpenGuest={(g) => setGuest({
                      id: g.id,
                      name: g.name,
                      type: g.type,
                      kind: g.kind,
                      status: g.status || "running",
                      cpu: 0,
                      cpus: 1,
                      mem: 0,
                      maxmem: 0,
                      disk: 0,
                      maxdisk: 0,
                      diskread: 0,
                      diskwrite: 0,
                      netin: g.netin,
                      netout: g.netout,
                      uptime: 0,
                    })}
                  />
                ) : null}
                {tab === "guests" ? (
                  <GuestsTab
                    data={data}
                    onOpenGuest={setGuest}
                    onBulkRecheck={bulkRecheck}
                    onBulkUpdate={openBulkUpdate}
                    onUpdateGuest={openGuestUpdate}
                    bulkBusy={bulkBusy}
                    bulkRecheckLabel={bulkRecheckLabel}
                    updateBusy={Boolean(bulkUpdateGuests)}
                    updatingVmid={updatingVmid}
                  />
                ) : null}
                {tab === "storage" ? <StorageTab data={data} onOpenDisk={setDisk} /> : null}
                {tab === "hardware" ? (
                  <HardwareTab
                    hardware={data.hardware}
                    prxConfigured={data.prxConfigured}
                    onOpenGpu={setGpu}
                    onOpenPci={setPci}
                    onConfigurePrx={() => setPrxGuide({})}
                    onRunGpuSwitch={() => {
                      if (!requirePrx()) return;
                      setScript({
                        title: "GPU mode switch",
                        scriptPath: "switch_gpu_mode_direct.sh",
                        params: { EXECUTION_MODE: "web" },
                      });
                    }}
                  />
                ) : null}
                {tab === "backups" ? (
                  <BackupsTab
                    data={data}
                    instanceId={instanceId}
                    onRefresh={load}
                    onEditJob={setEditingBackupJob}
                  />
                ) : null}
                {tab === "security" ? (
                  <SecurityTab
                    security={data.security}
                    prxConfigured={data.prxConfigured}
                    instanceId={instanceId}
                    nodeName={data.node}
                    iconUrl={iconUrl}
                    onRefresh={load}
                    onConfigurePrx={() => setPrxGuide({})}
                    onInstallLynis={() => {
                      if (!requirePrx()) return;
                      setScript({
                        title: "Install Lynis",
                        scriptPath: "lynis_installer.sh",
                        params: { EXECUTION_MODE: "web" },
                      });
                    }}
                  />
                ) : null}
              </TabErrorBoundary>
            )}
            {error && online ? <div className="pve-node-subtitle">{error}</div> : null}
          </div>

          <footer className="pve-footer">
            <span className="pve-footer-text">
              Proxmox + Glances{data.prxConfigured ? " + ProxMenux" : ""} · Updated {new Date(data.updatedAt).toLocaleTimeString()}
            </span>
          </footer>
        </div>

      {guest ? (
        <GuestModal
          instanceId={instanceId}
          guest={guest}
          canOpenTerminal={canUseTerminal}
          canControlPower={canControlPower}
          onClose={() => setGuest(null)}
          onOpenTerminal={(g) => {
            if (!requirePrx()) return;
            // Close guest first so stacked backdrops can't eat the open gesture.
            setGuest(null);
            window.setTimeout(() => setTerm({ mode: "guest", guest: g }), 120);
          }}
          onChanged={load}
        />
      ) : null}
      {term ? (
        <TermModal
          instanceId={instanceId}
          label={label}
          mode={term.mode}
          guest={term.guest}
          autoRun={term.autoRun}
          onClose={() => {
            setTerm(null);
            // Closing mid-update: stop showing the row as busy, but leave any
            // already-applied override (from onDone) in place.
            setUpdatingVmid(null);
          }}
        />
      ) : null}
      {disk ? <DiskModal instanceId={instanceId} disk={disk} onClose={() => setDisk(null)} /> : null}
      {iface ? <IfaceModal iface={iface} rrd={data.network?.rrd || []} onClose={() => setIface(null)} /> : null}
      {gpu ? <GpuDetailModal instanceId={instanceId} gpu={gpu} onClose={() => setGpu(null)} /> : null}
      {pci ? <PciDetailModal pci={pci} onClose={() => setPci(null)} /> : null}
      {script ? (
        <ScriptRunnerModal
          instanceId={instanceId}
          title={script.title}
          scriptPath={script.scriptPath}
          params={script.params}
          onClose={() => setScript(null)}
        />
      ) : null}
      {bulkUpdateGuests ? (
        <BulkUpdateModal
          instanceId={instanceId}
          guests={bulkUpdateGuests}
          onClose={() => setBulkUpdateGuests(null)}
          onFinished={(result) => {
            void afterBulkUpdate(result?.okVmids || []);
          }}
        />
      ) : null}
      {prxGuide ? (
        <PrxGuideModal
          instanceId={instanceId}
          label={label}
          prxHref={monitorOpenHref || data.prxHref}
          rejected={prxGuide.rejected}
          onClose={() => setPrxGuide(null)}
          onSaved={load}
        />
      ) : null}
      {editingBackupJob !== undefined ? (
        <BackupJobModal
          instanceId={instanceId}
          data={data}
          job={editingBackupJob}
          onClose={() => setEditingBackupJob(undefined)}
          onSaved={load}
        />
      ) : null}
    </div>
  );
}
