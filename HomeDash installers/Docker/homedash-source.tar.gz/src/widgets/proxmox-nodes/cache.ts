import type { StatusPayload, TabKey } from "./types";

type CachedNode = {
  data: StatusPayload;
  history: { cpu: number[]; mem: number[]; rx: number[] };
  tab: TabKey;
  at: number;
};

const store = new Map<string, CachedNode>();
const STORAGE_PREFIX = "hd:pve-cache:";

function storageKey(instanceId: string) {
  return `${STORAGE_PREFIX}${instanceId}`;
}

function readSession(instanceId: string): CachedNode | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = sessionStorage.getItem(storageKey(instanceId));
    if (!raw) return null;
    const parsed = JSON.parse(raw) as CachedNode;
    if (!parsed?.data) return null;
    return {
      data: parsed.data,
      history: parsed.history || { cpu: [], mem: [], rx: [] },
      tab: parsed.tab || "overview",
      at: parsed.at || Date.now(),
    };
  } catch {
    return null;
  }
}

function writeSession(instanceId: string, entry: CachedNode) {
  if (typeof window === "undefined") return;
  try {
    sessionStorage.setItem(storageKey(instanceId), JSON.stringify(entry));
  } catch {
    /* quota / private mode */
  }
}

function removeSession(instanceId: string) {
  if (typeof window === "undefined") return;
  try {
    sessionStorage.removeItem(storageKey(instanceId));
  } catch {
    /* ignore */
  }
}

/** In-memory only — safe for SSR / useState init (no sessionStorage). */
export function readProxmoxCache(instanceId: string): CachedNode | null {
  return store.get(instanceId) || null;
}

/**
 * Pull sessionStorage into the module Map (call from useLayoutEffect).
 * Survives hard refresh in the same tab until site data / session is cleared.
 */
export function hydrateProxmoxCache(instanceId: string): CachedNode | null {
  const hit = store.get(instanceId);
  if (hit) return hit;
  const fromSession = readSession(instanceId);
  if (fromSession) {
    store.set(instanceId, fromSession);
    return fromSession;
  }
  return null;
}

export function writeProxmoxCache(
  instanceId: string,
  patch: Partial<CachedNode> & { data?: StatusPayload },
) {
  const prev = store.get(instanceId);
  if (!patch.data && !prev?.data) return;
  const next: CachedNode = {
    data: patch.data || prev!.data,
    history: patch.history || prev?.history || { cpu: [], mem: [], rx: [] },
    tab: patch.tab || prev?.tab || "overview",
    at: Date.now(),
  };
  store.set(instanceId, next);
  writeSession(instanceId, next);
}

export function writeProxmoxTab(instanceId: string, tab: TabKey) {
  const prev = store.get(instanceId);
  if (!prev) return;
  const next = { ...prev, tab, at: Date.now() };
  store.set(instanceId, next);
  writeSession(instanceId, next);
}

/** Drop warm cache — call when intentionally clearing page cache. */
export function clearProxmoxCache(instanceId?: string) {
  if (instanceId) {
    store.delete(instanceId);
    removeSession(instanceId);
    return;
  }
  store.clear();
  if (typeof window === "undefined") return;
  try {
    const keys: string[] = [];
    for (let i = 0; i < sessionStorage.length; i += 1) {
      const key = sessionStorage.key(i);
      if (key?.startsWith(STORAGE_PREFIX)) keys.push(key);
    }
    for (const key of keys) sessionStorage.removeItem(key);
  } catch {
    /* ignore */
  }
}
