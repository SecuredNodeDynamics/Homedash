"use client";

import { useState } from "react";
import { fmtBytes, type StatusPayload, type BackupItem, type BackupSchedule } from "../types";
import { formatScheduleLabel } from "../scheduleFormat";

function IconBackup() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <ellipse cx="12" cy="5" rx="8" ry="3" />
      <path d="M4 5v6c0 1.66 3.58 3 8 3s8-1.34 8-3V5" />
      <path d="M4 11v6c0 1.66 3.58 3 8 3s8-1.34 8-3v-6" />
    </svg>
  );
}

function IconClock() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 3" />
    </svg>
  );
}

function IconCalendarCheck() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <rect x="3" y="4" width="18" height="18" rx="2" />
      <path d="M3 10h18M8 2v4M16 2v4" />
      <path d="M9 15l2 2 4-4" />
    </svg>
  );
}

function IconTrash() {
  return (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0-1 14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2L4 6" />
    </svg>
  );
}

function IconEdit() {
  return (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M12 20h9" />
      <path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z" />
    </svg>
  );
}

function IconPlus() {
  return (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M12 5v14M5 12h14" />
    </svg>
  );
}

function IconPlay() {
  return (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M8 5v14l11-7z" />
    </svg>
  );
}

export function BackupsTab({
  data,
  instanceId,
  onRefresh,
  onEditJob,
}: {
  data: StatusPayload;
  instanceId: string;
  onRefresh: () => void;
  onEditJob: (job?: BackupSchedule | null) => void;
}) {
  const [sub, setSub] = useState<"backups" | "schedules">("backups");
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const backups = data.backups?.items || [];
  const schedules = data.backups?.schedules || [];

  async function runBackup(vmid: number, storage: string) {
    setBusy(`backup-${vmid}`);
    setError(null);
    try {
      const response = await fetch("/api/widgets/proxmox-nodes/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          instance: instanceId,
          action: "backup",
          vmid,
          storage,
        }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Backup failed");
      onRefresh();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Backup failed");
    } finally {
      setBusy(null);
    }
  }

  async function deleteBackup(volid: string) {
    if (!confirm(`Are you sure you want to delete backup ${volid}?`)) return;
    setBusy(`delete-${volid}`);
    setError(null);
    try {
      const response = await fetch("/api/widgets/proxmox-nodes/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          instance: instanceId,
          action: "delete-backup",
          volid,
        }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Delete failed");
      onRefresh();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Delete failed");
    } finally {
      setBusy(null);
    }
  }

  const sortedBackups = [...backups].sort((a, b) => (b.ctime || 0) - (a.ctime || 0));
  const totalSize = backups.reduce((acc, b) => acc + (b.size || 0), 0);

  return (
    <div className="pve-bk-tab">
      <div className="pve-bk-summary">
        <div className="pve-bk-card">
          <div className="pve-bk-card-icon"><IconBackup /></div>
          <div className="pve-bk-card-body">
            <div className="pve-bk-card-hdr">Total Backups</div>
            <div className="pve-bk-card-big">{backups.length}</div>
            <div className="pve-bk-card-sub">{fmtBytes(totalSize)} total size</div>
          </div>
        </div>
        <div className="pve-bk-card">
          <div className="pve-bk-card-icon"><IconCalendarCheck /></div>
          <div className="pve-bk-card-body">
            <div className="pve-bk-card-hdr">Backup Schedules</div>
            <div className="pve-bk-card-big">{schedules.length}</div>
            <div className="pve-bk-card-sub">{schedules.filter((s) => s.enabled).length} enabled</div>
          </div>
        </div>
        <div className="pve-bk-card">
          <div className="pve-bk-card-icon"><IconClock /></div>
          <div className="pve-bk-card-body">
            <div className="pve-bk-card-hdr">Recent Backup</div>
            <div className="pve-bk-card-big pve-bk-card-big--date">
              {sortedBackups[0] ? new Date(sortedBackups[0].ctime * 1000).toLocaleDateString() : "None"}
            </div>
            <div className="pve-bk-card-sub">{sortedBackups[0] ? fmtBytes(sortedBackups[0].size) : "No backups found"}</div>
          </div>
        </div>
      </div>

      <div className="pve-bk-panel">
        <div className="pve-bk-subtabs" role="tablist">
          <button
            type="button"
            className={`pve-bk-subtab${sub === "backups" ? " pve-bk-subtab--active" : ""}`}
            onClick={() => setSub("backups")}
          >
            Backup Files
            <span className="pve-bk-subtab-count">{backups.length}</span>
          </button>
          <button
            type="button"
            className={`pve-bk-subtab${sub === "schedules" ? " pve-bk-subtab--active" : ""}`}
            onClick={() => setSub("schedules")}
          >
            Schedules
            <span className="pve-bk-subtab-count">{schedules.length}</span>
          </button>
        </div>

        <div className="pve-bk-subpane">
          {error && <div className="pve-bk-error">{error}</div>}

          {sub === "backups" ? (
            <div className="pve-bk-list">
              {sortedBackups.map((b) => (
                <div className="pve-bk-row" key={b.volid}>
                  <div className={`pve-bk-row-icon pve-bk-row-icon--${b.type}`}>{b.type === "vm" ? "VM" : "CT"}</div>
                  <div className="pve-bk-row-main">
                    <div className="pve-bk-row-top">
                      <span className="pve-bk-name" title={b.volid}>{b.volid.split("/").pop()}</span>
                      <span className="pve-bk-vmid">#{b.vmid}</span>
                    </div>
                    <div className="pve-bk-row-meta">
                      <span className="pve-bk-chip">{fmtBytes(b.size)}</span>
                      <span className="pve-bk-chip">{b.format}</span>
                      <span className="pve-bk-chip">{b.storage}</span>
                      <span className="pve-bk-date">{new Date(b.ctime * 1000).toLocaleString()}</span>
                    </div>
                  </div>
                  <button
                    className="pve-bk-btn pve-bk-btn--danger"
                    onClick={() => deleteBackup(b.volid)}
                    disabled={busy === `delete-${b.volid}`}
                    title="Delete backup"
                  >
                    <IconTrash />
                    {busy === `delete-${b.volid}` ? "…" : "Delete"}
                  </button>
                </div>
              ))}
              {backups.length === 0 && (
                <div className="pve-bk-empty">
                  <IconBackup />
                  <span>No backups found on this node</span>
                </div>
              )}
            </div>
          ) : (
            <div className="pve-bk-list">
              {schedules.map((s) => (
                <div className="pve-bk-row pve-bk-row--job" key={s.id}>
                  <div className={`pve-bk-status-dot ${s.enabled ? "is-on" : "is-off"}`} title={s.enabled ? "Enabled" : "Disabled"} />
                  <div className="pve-bk-row-main">
                    <div className="pve-bk-row-top">
                      <span className="pve-bk-name">{s.comment || `Job ${s.id}`}</span>
                      <span className="pve-bk-schedule-chip"><IconClock />{formatScheduleLabel(s.schedule)}</span>
                    </div>
                    <div className="pve-bk-row-meta">
                      <span className="pve-bk-kv"><i>Storage</i>{s.storage || "Any"}</span>
                      <span className="pve-bk-kv"><i>Node</i>{s.node || "All"}</span>
                      <span className="pve-bk-kv pve-bk-kv--targets" title={s.vmid || "All"}>
                        <i>Targets</i>{s.vmid || "All"}
                      </span>
                    </div>
                  </div>
                  <button className="pve-bk-btn" onClick={() => onEditJob(s)}>
                    <IconEdit />
                    Edit
                  </button>
                </div>
              ))}
              {schedules.length === 0 && (
                <div className="pve-bk-empty">
                  <IconCalendarCheck />
                  <span>No backup schedules found</span>
                </div>
              )}
            </div>
          )}

          <div className="pve-bk-actions">
            {sub === "schedules" ? (
              <button className="pve-bk-btn pve-bk-btn--primary" onClick={() => onEditJob(null)}>
                <IconPlus />
                New Schedule
              </button>
            ) : null}
            <button
              className="pve-bk-btn pve-bk-btn--accent"
              onClick={() => {
                const vmid = prompt("Enter VMID to backup:");
                if (vmid) runBackup(Number(vmid), data.backupMount || "local");
              }}
              disabled={!!busy}
            >
              <IconPlay />
              Backup VM/LXC Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
