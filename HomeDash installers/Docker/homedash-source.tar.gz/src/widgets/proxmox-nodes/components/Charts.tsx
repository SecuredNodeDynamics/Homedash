"use client";

export function Sparkline({
  values,
  color,
  width = 200,
  height = 36,
}: {
  values: number[];
  color: string;
  width?: number;
  height?: number;
}) {
  if (!values.length) {
    return (
      <div className="pve-spark-wrap">
        <svg
          className="pve-spark"
          viewBox={`0 0 ${width} ${height}`}
          preserveAspectRatio="none"
          aria-hidden="true"
        />
      </div>
    );
  }
  const max = Math.max(...values, 1);
  const min = Math.min(...values, 0);
  const span = Math.max(max - min, 1);
  const pts = values
    .map((v, i) => {
      const x = (i / Math.max(values.length - 1, 1)) * (width - 4) + 2;
      const y = height - 4 - ((v - min) / span) * (height - 8);
      return `${x},${y}`;
    })
    .join(" ");
  return (
    <div className="pve-spark-wrap">
      <svg
        className="pve-spark"
        viewBox={`0 0 ${width} ${height}`}
        preserveAspectRatio="none"
        aria-hidden="true"
      >
        <polyline
          fill="none"
          stroke={color}
          strokeWidth="1.8"
          strokeLinejoin="round"
          strokeLinecap="round"
          vectorEffect="non-scaling-stroke"
          points={pts}
        />
      </svg>
    </div>
  );
}

export function MiniBar({ pct, color }: { pct: number; color: string }) {
  return (
    <div className="pve-g-disk-track" style={{ marginTop: 6 }}>
      <div className="pve-ov-track">
        <div
          className="pve-ov-track-fill"
          style={{ width: `${Math.max(0, Math.min(100, pct))}%`, background: color }}
        />
      </div>
    </div>
  );
}

export function RingGauge({
  pct,
  color,
  size = 64,
  showLabel = true,
}: {
  pct: number;
  color: string;
  size?: number;
  /** Draw the built-in "NN%" text in the middle. Turn off when overlaying your own label. */
  showLabel?: boolean;
}) {
  const r = (size - 8) / 2;
  const c = 2 * Math.PI * r;
  const clamped = Math.max(0, Math.min(100, pct));
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="pve-g-ring">
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="6" />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={r}
        fill="none"
        stroke={color}
        strokeWidth="6"
        strokeDasharray={`${(clamped / 100) * c} ${c}`}
        strokeLinecap="round"
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
      />
      {showLabel ? (
        <text x="50%" y="50%" textAnchor="middle" dominantBaseline="central" fill={color} fontSize="12" fontWeight="700">
          {Math.round(clamped)}%
        </text>
      ) : null}
    </svg>
  );
}
