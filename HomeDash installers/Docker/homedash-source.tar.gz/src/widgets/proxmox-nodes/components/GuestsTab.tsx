"use client";

import { MiniBar, RingGauge } from "./Charts";
import { fmtBytes, fmtUptimeFull, pctColor, type Guest, type StatusPayload } from "../types";

export function GuestsTab({
  data,
  onOpenGuest,
  onBulkRecheck,
  onBulkUpdate,
  onUpdateGuest,
  bulkBusy,
  bulkRecheckLabel,
  updateBusy,
  updatingVmid,
}: {
  data: StatusPayload;
  onOpenGuest: (guest: Guest) => void;
  onBulkRecheck: () => void;
  onBulkUpdate: () => void;
  onUpdateGuest?: (guest: Guest) => void;
  bulkBusy?: boolean;
  bulkRecheckLabel?: string;
  updateBusy?: boolean;
  /** vmid of the LXC currently running its per-guest terminal update, if any. */
  updatingVmid?: number | null;
}) {
  const g = data.guests;
  if (!g) {
    return <div className="pve-g-empty">Guest summary unavailable</div>;
  }
  // Always list guests in ascending VMID order (VMs and LXCs together).
  const items = (Array.isArray(g.items) ? [...g.items] : []).sort(
    (a, b) => Number(a.id) - Number(b.id),
  );
  const pendingUpdateCount = items.filter(
    (guest) =>
      (guest.type === "lxc" || guest.kind === "lxc") &&
      guest.status === "running" &&
      Number(guest.updateCheck?.count || 0) > 0,
  ).length;
  const cpuPct = g.cpuAllocSum > 0 ? (g.cpuUsedSum / g.cpuAllocSum) * 100 : 0;
  const memPct = g.memAllocSum > 0 ? (g.memUsedSum / g.memAllocSum) * 100 : 0;
  const diskPct = g.diskAllocSum > 0 ? (g.diskUsedSum / g.diskAllocSum) * 100 : 0;
  const waste = Math.max(0, (g.cpuAllocSum || 0) - (g.cpuUsedSum || 0));

  return (
    <div className="pve-guests-tab">
      <div className="pve-g-summary">
        <div className="pve-g-summary-main">
          <div className="pve-g-card pve-g-card--guests">
            <div className="pve-g-card-hdr"><span>Total VMs &amp; LXCs</span></div>
            <div className="pve-g-card-big">{g.running ?? 0}<span> / {g.total ?? 0}</span></div>
            <div className="pve-g-card-badges">
              <span className="pve-g-pill pve-g-pill--run">{g.running ?? 0} running</span>
              <span className="pve-g-pill pve-g-pill--lxc">{g.lxcCount ?? 0} LXC</span>
              {g.vmCount ? <span className="pve-g-pill pve-g-pill--vm">{g.vmCount} VM</span> : null}
            </div>
          </div>

          <div className="pve-g-card pve-g-card--metric">
            <div className="pve-g-card-hdr"><span>Total CPU Allocated</span></div>
            <div className="pve-g-card-body">
              <RingGauge pct={cpuPct} color={pctColor(cpuPct)} size={52} />
              <div className="pve-g-card-stats">
                <div className="pve-g-stat">
                  <div className="pve-g-stat-line"><span>Used</span><b>{Number(g.cpuUsedSum || 0).toFixed(2)} vCPU</b></div>
                  <MiniBar pct={cpuPct} color={pctColor(cpuPct)} />
                </div>
                <div className="pve-g-stat">
                  <div className="pve-g-stat-line"><span>Configured</span><b>{g.cpuAllocSum ?? 0} / {g.hostCpus || "—"}</b></div>
                </div>
                <div className="pve-g-stat">
                  <div className="pve-g-stat-line"><span>Waste</span><b>{waste.toFixed(2)} vCPU</b></div>
                </div>
              </div>
            </div>
          </div>

          <div className="pve-g-card pve-g-card--metric">
            <div className="pve-g-card-hdr"><span>Total Memory</span></div>
            <div className="pve-g-card-body">
              <RingGauge pct={memPct} color={pctColor(memPct)} size={52} />
              <div className="pve-g-card-stats">
                <div className="pve-g-stat">
                  <div className="pve-g-stat-line"><span>Used</span><b>{fmtBytes(g.memUsedSum || 0)}</b></div>
                  <MiniBar pct={memPct} color="#38bdf8" />
                </div>
                <div className="pve-g-stat">
                  <div className="pve-g-stat-line"><span>Alloc</span><b>{fmtBytes(g.memAllocSum || 0)}</b></div>
                </div>
                <div className="pve-g-stat">
                  <div className="pve-g-stat-line"><span>Total</span><b>{g.hostMemTotal ? fmtBytes(g.hostMemTotal) : "—"}</b></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="pve-g-card pve-g-card--disk">
          <div className="pve-g-disk-main">
            <div className="pve-g-card-hdr"><span>Total Disk</span></div>
            <div className="pve-g-card-big pve-g-card-big--sm">
              {fmtBytes(g.diskUsedSum || 0)} <span>used</span>
            </div>
          </div>
          <div className="pve-g-disk-side">
            <div className="pve-g-disk-row">
              <MiniBar pct={diskPct} color={pctColor(diskPct)} />
              <span
                className="pve-g-pill"
                style={{
                  color: pctColor(diskPct),
                  borderColor: `${pctColor(diskPct)}55`,
                  background: `${pctColor(diskPct)}18`,
                }}
              >
                {Math.round(diskPct)}% util
              </span>
            </div>
            <div className="pve-g-disk-sub">
              {fmtBytes(g.diskUsedSum || 0)} vs {fmtBytes(g.diskAllocSum || 0)} allocated
            </div>
          </div>
        </div>
      </div>

      <section className="pve-g-list-card">
        <div className="pve-g-list-hdr">
          <div className="pve-g-list-hdr-title">Virtual Machines &amp; Containers</div>
          <div className="pve-g-list-hdr-actions">
            <button type="button" className="pve-g-bulk-recheck" onClick={onBulkRecheck} disabled={bulkBusy || updateBusy}>
              <span>{bulkBusy ? bulkRecheckLabel || "Rechecking…" : "Recheck updates"}</span>
            </button>
            <button
              type="button"
              className="pve-g-bulk-update"
              onClick={onBulkUpdate}
              disabled={bulkBusy || updateBusy || pendingUpdateCount === 0}
              title={
                pendingUpdateCount
                  ? `Upgrade ${pendingUpdateCount} running LXC${pendingUpdateCount === 1 ? "" : "s"} with pending updates`
                  : "No running LXCs with pending updates"
              }
            >
              <span>
                {updateBusy
                  ? "Updating…"
                  : pendingUpdateCount
                    ? `Update (${pendingUpdateCount})`
                    : "Update"}
              </span>
            </button>
          </div>
        </div>
        <div className="pve-g-list">
          {items.length ? items.map((guest) => {
            const running = guest.status === "running";
            const cpuPctG = Math.round(Number(guest.cpu || 0) * 1000) / 10;
            const memPctG = guest.maxmem > 0 ? (guest.mem / guest.maxmem) * 100 : 0;
            const diskPctG = guest.maxdisk > 0 ? (guest.disk / guest.maxdisk) * 100 : 0;
            const ips = Array.isArray(guest.ips)
              ? guest.ips.filter((ip) => /^\d{1,3}(\.\d{1,3}){3}$/.test(String(ip).split("/")[0].trim()))
              : [];
            const updateCount = Number(guest.updateCheck?.count || 0);
            return (
              <div
                className={`pve-g-row${running ? " pve-g-row--run" : " pve-g-row--stop"}`}
                role="button"
                tabIndex={0}
                key={`${guest.kind}-${guest.id}`}
                onClick={() => onOpenGuest(guest)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") onOpenGuest(guest);
                }}
              >
                <div className="pve-g-row-head">
                  <div className="pve-g-row-identity">
                    <span
                      className={`pve-g-status-dot${running ? " pve-g-status-dot--run" : " pve-g-status-dot--stop"}`}
                      aria-hidden
                    />
                    <div className="pve-g-row-titles">
                      <div className="pve-g-row-titleline">
                        <span className="pve-g-name">{guest.name}</span>
                        <span className={`pve-g-pill ${guest.type === "lxc" ? "pve-g-pill--lxc" : "pve-g-pill--vm"}`}>
                          {guest.type === "lxc" ? "LXC" : "VM"}
                        </span>
                        <span className="pve-g-vmid">#{guest.id}</span>
                      </div>
                      <div className="pve-g-row-sub">
                        {ips.length ? (
                          ips.slice(0, 2).map((ip) => (
                            <span className="pve-g-ip" key={ip}>{ip}</span>
                          ))
                        ) : (
                          <span className="pve-g-ip pve-g-ip--empty">No IP</span>
                        )}
                        {updateCount > 0 ? (
                          <span
                            className="pve-g-updates"
                            title={`${updateCount} update${updateCount === 1 ? "" : "s"} available`}
                          >
                            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
                              <path d="M22 7.7c0-.6-.4-1.2-.8-1.5l-6.3-3.9a1.72 1.72 0 0 0-1.7 0l-10.3 6c-.5.2-.9.8-.9 1.4v6.6c0 .5.4 1.2.8 1.5l6.3 3.9a1.72 1.72 0 0 0 1.7 0l10.3-6c.5-.3.9-1 .9-1.5Z" />
                            </svg>
                            <span>{updateCount}</span>
                          </span>
                        ) : null}
                      </div>
                    </div>
                  </div>
                  <div className="pve-g-row-aside">
                    <span className={`pve-g-pill ${running ? "pve-g-pill--run" : "pve-g-pill--stop"}`}>
                      {running ? "RUNNING" : String(guest.status || "STOPPED").toUpperCase()}
                    </span>
                    <span className="pve-g-uptime" title="Uptime">{fmtUptimeFull(guest.uptime)}</span>
                    {(guest.type === "lxc" || guest.kind === "lxc") &&
                    running &&
                    (updateCount > 0 || updatingVmid === guest.id) ? (
                      <button
                        type="button"
                        className={`pve-g-row-update-btn${
                          updatingVmid === guest.id ? " pve-g-row-update-btn--busy" : ""
                        }`}
                        disabled={Boolean(bulkBusy || updateBusy || updatingVmid != null)}
                        onPointerUp={(e) => e.stopPropagation()}
                        onClick={(e) => {
                          e.stopPropagation();
                          onUpdateGuest?.(guest);
                        }}
                        title={
                          updatingVmid === guest.id
                            ? "Update running in terminal…"
                            : `Open this container's terminal and run its update command (${updateCount} pending)`
                        }
                      >
                        <svg
                          className={updatingVmid === guest.id ? "pve-gc-spin" : undefined}
                          width="11"
                          height="11"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2.2"
                          aria-hidden
                        >
                          <path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
                          <path d="M3 3v5h5" />
                          <path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16" />
                          <path d="M16 16h5v5" />
                        </svg>
                        <span>{updatingVmid === guest.id ? "Updating…" : `Update (${updateCount})`}</span>
                      </button>
                    ) : null}
                  </div>
                </div>

                <div className="pve-g-res">
                  <div className="pve-g-res-item">
                    <div className="pve-g-res-top">
                      <span>CPU</span>
                      <b style={{ color: pctColor(cpuPctG) }}>{cpuPctG.toFixed(1)}%</b>
                    </div>
                    <MiniBar pct={cpuPctG} color={pctColor(cpuPctG)} />
                  </div>
                  <div className="pve-g-res-item">
                    <div className="pve-g-res-top">
                      <span>Mem</span>
                      <b style={{ color: pctColor(memPctG) }}>{fmtBytes(guest.mem)}</b>
                    </div>
                    <MiniBar pct={memPctG} color="#38bdf8" />
                    <div className="pve-g-res-sub">of {fmtBytes(guest.maxmem)}</div>
                  </div>
                  <div className="pve-g-res-item">
                    <div className="pve-g-res-top">
                      <span>Disk</span>
                      <b style={{ color: pctColor(diskPctG) }}>
                        {guest.maxdisk ? fmtBytes(guest.disk) : "—"}
                      </b>
                    </div>
                    <MiniBar pct={diskPctG} color="#38bdf8" />
                    <div className="pve-g-res-sub">
                      {guest.maxdisk ? `of ${fmtBytes(guest.maxdisk)}` : "n/a"}
                    </div>
                  </div>
                </div>

                <div className="pve-g-chips">
                  <span className="pve-g-chip" title="Disk I/O">
                    <span className="pve-g-chip-label">Disk</span>
                    <span className="pve-g-io pve-g-io--r">↓ {fmtBytes(guest.diskread)}</span>
                    <span className="pve-g-io pve-g-io--w">↑ {fmtBytes(guest.diskwrite)}</span>
                  </span>
                  <span className="pve-g-chip" title="Network I/O">
                    <span className="pve-g-chip-label">Net</span>
                    <span className="pve-g-io pve-g-io--rx">↓ {fmtBytes(guest.netin)}</span>
                    <span className="pve-g-io pve-g-io--tx">↑ {fmtBytes(guest.netout)}</span>
                  </span>
                </div>
              </div>
            );
          }) : <div className="pve-g-empty">No VMs or LXCs found on this node</div>}
        </div>
      </section>
    </div>
  );
}
