"use client";

import { useState } from "react";
import type { HardwareBlock } from "../types";

export function HardwareTab({
  hardware,
  prxConfigured,
  onOpenGpu,
  onOpenPci,
  onRunGpuSwitch,
  onConfigurePrx,
}: {
  hardware: HardwareBlock | null;
  prxConfigured: boolean;
  onOpenGpu: (gpu: Record<string, unknown>) => void;
  onOpenPci: (pci: Record<string, unknown>) => void;
  onRunGpuSwitch: () => void;
  onConfigurePrx: () => void;
}) {
  const [sub, setSub] = useState<"thermal" | "graphics" | "pci">("thermal");

  if (!prxConfigured) {
    return (
      <div className="pve-hw-tab">
        <div className="pve-hw-empty pve-hw-empty--block">
          Configure ProxMenux URL and API key to load hardware inventory.
          <div style={{ marginTop: 10 }}>
            <button type="button" className="prx-open-link prx-open-link--prx" onClick={onConfigurePrx}>
              Add MONITOR token
            </button>
          </div>
        </div>
      </div>
    );
  }
  if (!hardware) {
    return (
      <div className="pve-hw-tab">
        <div className="pve-hw-empty pve-hw-empty--block">
          Hardware inventory unavailable — check ProxMenux MONITOR connectivity.
        </div>
      </div>
    );
  }

  const cpu = hardware.cpu || {};
  const board = hardware.motherboard || {};
  const bios = (board.bios as Record<string, unknown> | undefined) || hardware.bios || {};
  const modules = Array.isArray(hardware.memory_modules) ? hardware.memory_modules : [];
  const temps = Array.isArray(hardware.temperatures) ? hardware.temperatures : [];
  const gpus = Array.isArray(hardware.gpus) ? hardware.gpus : [];
  const pci = Array.isArray(hardware.pci_devices) ? hardware.pci_devices : [];

  const sockets = Number(cpu.sockets) || 1;
  const cps = Number(cpu.cores_per_socket) || 0;
  const totalCores = sockets * cps || Number(cpu.cores) || 0;
  const threads = cpu.total_threads != null ? Number(cpu.total_threads) : null;
  const virt = String(cpu.virtualization || "—");
  const cpuModel = String(cpu.model || "Unknown processor");
  const boardMfr = String(board.manufacturer || "—");
  const boardModel = String(board.model || "—");
  const biosVendor = String(bios.vendor || board.manufacturer || "—");
  const biosVersion = String(bios.version || "—");
  const biosDate = String(bios.date || "—");
  const coresSub = cps ? `${sockets}×${cps}` : "—";

  return (
    <div className="pve-hw-tab">
      <section className="pve-hw-card pve-hw-card--sys pve-hw-sys">
        <div className="pve-hw-sys-hud">
          <div className="pve-hw-sys-hud-fx" aria-hidden>
            <i className="pve-hw-sys-hud-grid" />
            <i className="pve-hw-sys-hud-scan" />
            <i className="pve-hw-sys-hud-glow" />
          </div>

          <div className="pve-hw-sys-hud-hdr">
            <div className="pve-hw-sys-hud-brand">
              <span className="pve-hw-sys-hud-pulse" aria-hidden />
              <span className="pve-hw-sys-hud-title">SYSTEM // INFO</span>
            </div>
            <span className="pve-hw-sys-hud-status">LINK OK</span>
          </div>

          <div className="pve-hw-sys-hud-hero">
            <div className="pve-hw-sys-hud-k">PROCESSOR</div>
            <div className="pve-hw-sys-hud-model" title={cpuModel}>{cpuModel}</div>
            <div className="pve-hw-sys-hud-stats">
              <div className="pve-hw-sys-stat">
                <span className="pve-hw-sys-stat-val">{totalCores || "—"}</span>
                <span className="pve-hw-sys-stat-lbl">CORES</span>
                <span className="pve-hw-sys-stat-sub">{coresSub}</span>
              </div>
              <div className="pve-hw-sys-stat">
                <span className="pve-hw-sys-stat-val">{Number.isFinite(threads as number) ? threads : "—"}</span>
                <span className="pve-hw-sys-stat-lbl">THREADS</span>
                <span className="pve-hw-sys-stat-sub">SMT</span>
              </div>
              <div className="pve-hw-sys-stat pve-hw-sys-stat--virt">
                <span className="pve-hw-sys-stat-val pve-hw-sys-stat-val--sm">{virt}</span>
                <span className="pve-hw-sys-stat-lbl">VIRT</span>
                <span className="pve-hw-sys-stat-sub">HV</span>
              </div>
            </div>
          </div>

          <div className="pve-hw-sys-hud-panels">
            <div className="pve-hw-sys-panel">
              <div className="pve-hw-sys-panel-hdr">
                <span>// CPU TELEMETRY</span>
                <span className="pve-hw-sys-panel-tag">NODE</span>
              </div>
              <div className="pve-hw-sys-rows">
                <div className="pve-hw-sys-row">
                  <span className="pve-hw-sys-row-k">MODEL</span>
                  <span className="pve-hw-sys-row-v" title={cpuModel}>{cpuModel}</span>
                </div>
                <div className="pve-hw-sys-row">
                  <span className="pve-hw-sys-row-k">TOPOLOGY</span>
                  <span className="pve-hw-sys-row-v">
                    {cps ? `${sockets} × ${cps} = ${totalCores} cores` : "—"}
                  </span>
                </div>
                <div className="pve-hw-sys-row">
                  <span className="pve-hw-sys-row-k">THREADS</span>
                  <span className="pve-hw-sys-row-v">{Number.isFinite(threads as number) ? String(threads) : "—"}</span>
                </div>
                <div className="pve-hw-sys-row">
                  <span className="pve-hw-sys-row-k">VIRTUALIZATION</span>
                  <span className="pve-hw-sys-row-v pve-hw-sys-row-v--ok">{virt}</span>
                </div>
              </div>
            </div>

            <div className="pve-hw-sys-panel">
              <div className="pve-hw-sys-panel-hdr">
                <span>// BOARD / BIOS</span>
                <span className="pve-hw-sys-panel-tag">MB</span>
              </div>
              <div className="pve-hw-sys-rows">
                <div className="pve-hw-sys-row">
                  <span className="pve-hw-sys-row-k">MANUFACTURER</span>
                  <span className="pve-hw-sys-row-v">{boardMfr}</span>
                </div>
                <div className="pve-hw-sys-row">
                  <span className="pve-hw-sys-row-k">MODEL</span>
                  <span className="pve-hw-sys-row-v">{boardModel}</span>
                </div>
                <div className="pve-hw-sys-row">
                  <span className="pve-hw-sys-row-k">BIOS</span>
                  <span className="pve-hw-sys-row-v">{biosVendor}</span>
                </div>
                <div className="pve-hw-sys-row">
                  <span className="pve-hw-sys-row-k">VERSION</span>
                  <span className="pve-hw-sys-row-v pve-hw-sys-row-v--mono">{biosVersion}</span>
                </div>
                <div className="pve-hw-sys-row">
                  <span className="pve-hw-sys-row-k">DATE</span>
                  <span className="pve-hw-sys-row-v pve-hw-sys-row-v--mono">{biosDate}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="pve-hw-card pve-hw-card--mem">
        <div className="pve-hw-card-hdr">
          <div className="pve-hw-card-title"><span>Memory Modules</span></div>
          <span className="pve-hw-count-badge">{modules.length} installed</span>
        </div>
        <div className="pve-hw-dimm-grid">
          {modules.length ? modules.map((m, i) => {
            const slot = String(m.slot || `DIMM ${i + 1}`);
            const size = fmtMemModuleSize(m.size);
            const type = String(m.type || "—");
            const speed = fmtMemSpeed(m.configured_speed || m.max_speed);
            const mfr = String(m.manufacturer || "—");
            return (
              <div className="pve-hw-dimm" key={`${slot}-${i}`}>
                <div className="pve-hw-dimm-top">
                  <span className="pve-hw-dimm-slot">{slot}</span>
                  {type !== "—" ? <span className="pve-hw-dimm-type">{type}</span> : null}
                </div>
                <div className="pve-hw-dimm-size">{size}</div>
                <div className="pve-hw-dimm-chips">
                  <span className="pve-hw-dimm-chip">
                    <span className="pve-hw-dimm-chip-k">Speed</span>
                    <span className="pve-hw-dimm-chip-v">{speed}</span>
                  </span>
                  <span className="pve-hw-dimm-chip">
                    <span className="pve-hw-dimm-chip-k">Mfr</span>
                    <span className="pve-hw-dimm-chip-v">{mfr}</span>
                  </span>
                </div>
              </div>
            );
          }) : <div className="pve-hw-empty">No memory modules reported.</div>}
        </div>
      </section>

      <div className="pve-hw-subtabs" role="tablist" aria-label="Hardware details">
        {(["thermal", "graphics", "pci"] as const).map((key) => (
          <button
            key={key}
            type="button"
            role="tab"
            aria-selected={sub === key}
            className={`pve-hw-subtab${sub === key ? " pve-hw-subtab--active" : ""}`}
            onClick={() => setSub(key)}
          >
            {key === "thermal" ? "Thermal" : key === "graphics" ? "Graphics" : "PCI Devices"}
          </button>
        ))}
      </div>

      {/* Scroll only the detail pane — Memory Modules + subtabs stay pinned above. */}
      <div className="pve-hw-scroll">
        <div className="pve-hw-subpane">
          {sub === "thermal" ? (
            <section className="pve-hw-card pve-hw-card--thermal">
              <div className="pve-hw-card-hdr">
                <div className="pve-hw-card-title"><span>Thermal Monitoring</span></div>
                <span className="pve-hw-count-badge">{temps.length} sensor{temps.length === 1 ? "" : "s"}</span>
              </div>
              {temps.length ? (
                <div className="pve-hw-therm-sensors">
                  {flattenTemps(temps).map((t, i) => {
                    const cur = Number(t.current);
                    const pct = thermalBarPct(t);
                    const tone = thermalTone(cur);
                    const adapter = shortenAdapter(String(t.adapter || ""));
                    const cat = thermalCategory(t);
                    return (
                      <div className={`pve-hw-therm-card pve-hw-therm-card--${tone}`} key={`${cat}-${String(t.name || i)}-${i}`}>
                        <div className="pve-hw-therm-card-top">
                          <span className={`pve-hw-therm-cat pve-hw-therm-cat--${cat.toLowerCase()}`}>{cat}</span>
                          <span className="pve-hw-therm-temp">
                            {Number.isFinite(cur) ? `${cur.toFixed(1)}°C` : "—"}
                          </span>
                        </div>
                        <div className="pve-hw-therm-name" title={String(t.name || "Sensor")}>
                          {String(t.name || "Sensor")}
                        </div>
                        <div className="pve-hw-therm-bar" aria-hidden>
                          <i style={{ width: `${pct}%` }} />
                        </div>
                        {adapter ? <div className="pve-hw-therm-adapter">{adapter}</div> : null}
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="pve-hw-empty">No temperature sensors found.</div>
              )}
            </section>
          ) : null}

          {sub === "graphics" ? (
            <section className="pve-hw-card pve-hw-card--graphics">
              <div className="pve-hw-card-hdr">
                <div className="pve-hw-card-title"><span>Graphics Cards</span></div>
                <div className="pve-hw-gpu-hdr-actions">
                  <span className="pve-hw-count-badge">{gpus.length} GPU{gpus.length === 1 ? "" : "s"}</span>
                  <button type="button" className="pve-hw-gpu-mode-btn" onClick={onRunGpuSwitch}>
                    GPU mode switch
                  </button>
                </div>
              </div>
              <div className="pve-hw-gpu-list">
                {gpus.length ? gpus.map((gpu, i) => {
                  const fullName = String(gpu.name || "Graphics device");
                  const shortName = shortGpuName(fullName);
                  const vendor = String(gpu.vendor || "GPU");
                  const vendorKey = gpuVendorKey(vendor, fullName);
                  const slot = String(gpu.slot || "—");
                  const driver = String(gpu.pci_driver || "—");
                  const module = String(gpu.pci_kernel_module || "—");
                  const type = String(gpu.type || "").trim();
                  const showType = type && !/^pci$/i.test(type);
                  return (
                    <button
                      type="button"
                      className={`pve-hw-gpu-card pve-hw-gpu-card--${vendorKey}`}
                      key={`${slot}-${i}`}
                      onClick={() => onOpenGpu(gpu)}
                      title={fullName}
                    >
                      <div className="pve-hw-gpu-card-top">
                        <span className={`pve-hw-vendor-pill pve-hw-vendor-pill--${vendorKey}`}>
                          {vendor.toUpperCase()}
                        </span>
                        {showType ? <span className="pve-hw-gpu-type">{type}</span> : null}
                      </div>
                      <div className="pve-hw-gpu-name">{shortName}</div>
                      {shortName !== fullName ? (
                        <div className="pve-hw-gpu-fullname" title={fullName}>{fullName}</div>
                      ) : null}
                      <div className="pve-hw-gpu-chips">
                        <span className="pve-hw-gpu-chip">
                          <span className="pve-hw-gpu-chip-k">Slot</span>
                          <span className="pve-hw-gpu-chip-v">{slot}</span>
                        </span>
                        <span className="pve-hw-gpu-chip pve-hw-gpu-chip--ok">
                          <span className="pve-hw-gpu-chip-k">Driver</span>
                          <span className="pve-hw-gpu-chip-v">{driver}</span>
                        </span>
                        <span className="pve-hw-gpu-chip">
                          <span className="pve-hw-gpu-chip-k">Module</span>
                          <span className="pve-hw-gpu-chip-v">{module}</span>
                        </span>
                      </div>
                    </button>
                  );
                }) : <div className="pve-hw-empty">No graphics cards detected.</div>}
              </div>
            </section>
          ) : null}

          {sub === "pci" ? (
            <section className="pve-hw-card pve-hw-card--pci">
              <div className="pve-hw-card-hdr">
                <div className="pve-hw-card-title"><span>PCI Devices</span></div>
                <span className="pve-hw-count-badge">{pci.length} device{pci.length === 1 ? "" : "s"}</span>
              </div>
              <div className="pve-hw-pci-grid">
                {pci.length ? sortPciDevices(pci).map((dev, i) => {
                  const type = String(dev.type || "PCI");
                  const badge = pciBadgeClass(type);
                  const accent = badge.replace("pve-hw-pci-badge", "pve-hw-pci-card");
                  const fullName = String(dev.device || dev.sdevice || "PCI Device");
                  const name = shortPciName(fullName);
                  const vendor = shortPciVendor(String(dev.vendor || ""));
                  const slot = String(dev.slot || "—");
                  const driver = String(dev.driver || "—");
                  return (
                    <button
                      key={`${slot}-${i}`}
                      type="button"
                      className={`pve-hw-pci-card ${accent}`}
                      onClick={() => onOpenPci(dev)}
                      title={fullName}
                    >
                      <div className="pve-hw-pci-top">
                        <span className={`pve-hw-pci-badge ${badge}`}>{shortPciType(type)}</span>
                      </div>
                      <div className="pve-hw-pci-name">{name}</div>
                      {vendor ? <div className="pve-hw-pci-vendor">{vendor}</div> : null}
                      <div className="pve-hw-pci-chips">
                        <span className="pve-hw-pci-chip">
                          <span className="pve-hw-pci-chip-k">Slot</span>
                          <span className="pve-hw-pci-chip-v">{slot}</span>
                        </span>
                        <span className="pve-hw-pci-chip pve-hw-pci-chip--ok">
                          <span className="pve-hw-pci-chip-k">Driver</span>
                          <span className="pve-hw-pci-chip-v">{driver}</span>
                        </span>
                      </div>
                    </button>
                  );
                }) : <div className="pve-hw-empty">No PCI devices found.</div>}
              </div>
            </section>
          ) : null}
        </div>
      </div>
    </div>
  );
}

/** ProxMenux reports DIMM size in KiB (e.g. 33554432 → 32.0 GB). */
function fmtMemModuleSize(raw: unknown) {
  const n = Number(raw);
  if (!Number.isFinite(n) || n <= 0) return "—";
  const gb = n / (1024 * 1024);
  if (gb >= 1) return `${gb.toFixed(1)} GB`;
  const mb = n / 1024;
  if (mb >= 1) return `${mb.toFixed(0)} MB`;
  return `${Math.round(n)} KiB`;
}

function fmtMemSpeed(raw: unknown) {
  if (raw == null || raw === "") return "—";
  const s = String(raw).trim();
  if (!s || s === "—") return "—";
  if (/mt\/?s|mhz|gt\/?s/i.test(s)) return s;
  if (/^\d+(\.\d+)?$/.test(s)) return `${s} MT/s`;
  return s;
}

function thermalCategory(t: Record<string, unknown>) {
  const name = String(t?.name || "");
  const adapter = String(t?.adapter || "");
  const blob = `${name} ${adapter}`.toLowerCase();
  if (/\bgpu\b|amdgpu|radeon|nvidia|edge/i.test(blob)) return "GPU";
  if (/nvme/i.test(blob)) return "NVME";
  if (/cpu|coretemp|package|tctl|tdie|k10temp/i.test(blob)) return "CPU";
  if (/dimm|ddr|memory|dram/i.test(blob)) return "MEMORY";
  if (/pci\s*device|^sensor\s*\d/i.test(name) || blob.startsWith("pci")) return "PCI";
  return "OTHER";
}

function thermalBarPct(t: Record<string, unknown>) {
  const cur = Number(t?.current);
  if (!Number.isFinite(cur) || cur < 0) return 0;
  // Shared visual scale so equal temps look equal across sensors.
  return Math.max(0, Math.min(100, Math.round((cur / 100) * 100)));
}

function thermalTone(cur: number) {
  if (!Number.isFinite(cur)) return "cool";
  if (cur >= 85) return "hot";
  if (cur >= 70) return "warm";
  return "cool";
}

function shortenAdapter(adapter: string) {
  const trimmed = adapter.trim();
  if (!trimmed) return "";
  // Hide noisy generic labels that repeat on almost every sensor.
  if (/^pci\s*adapter$/i.test(trimmed)) return "";
  if (/^virtual\s*device$/i.test(trimmed)) return "";
  // Compact long SMBus strings.
  if (/smbus/i.test(trimmed)) {
    const port = trimmed.match(/port\s+\d+/i)?.[0];
    return port ? `SMBus ${port}` : "SMBus";
  }
  return trimmed.length > 42 ? `${trimmed.slice(0, 40)}…` : trimmed;
}

function flattenTemps(temps: Array<Record<string, unknown>>) {
  const rank: Record<string, number> = { GPU: 0, CPU: 1, NVME: 2, MEMORY: 3, PCI: 4, OTHER: 5 };
  return [...temps].sort((a, b) => {
    const ca = thermalCategory(a);
    const cb = thermalCategory(b);
    if (rank[ca] !== rank[cb]) return (rank[ca] ?? 9) - (rank[cb] ?? 9);
    const ta = Number(a.current);
    const tb = Number(b.current);
    if (Number.isFinite(ta) && Number.isFinite(tb) && ta !== tb) return tb - ta;
    return String(a.name || "").localeCompare(String(b.name || ""), undefined, { sensitivity: "base" });
  });
}

function shortGpuName(raw: string) {
  const brackets = [...raw.matchAll(/\[([^\]]+)\]/g)].map((m) => m[1].trim()).filter(Boolean);
  const product = brackets.find((b) =>
    /radeon|geforce|quadro|tesla|rtx|gtx|uhd|iris|arc|vega|navi|wani|matisse|renoir|raphael|phoenix|strix/i.test(b),
  );
  if (product) return product;
  if (brackets.length) return brackets[brackets.length - 1];
  return raw.replace(/\s*\(rev\s+[0-9a-f]+\)\s*$/i, "").trim() || raw;
}

function gpuVendorKey(vendor: string, name = "") {
  const blob = `${vendor} ${name}`.toLowerCase();
  if (/nvidia|geforce|quadro|tesla/.test(blob)) return "nvidia";
  if (/intel|uhd|iris|arc/.test(blob)) return "intel";
  if (/amd|ati|radeon|amdgpu/.test(blob)) return "amd";
  return "other";
}

function pciBadgeClass(type: string) {
  const t = type.toLowerCase();
  if (t.includes("graphics") || t.includes("vga") || t.includes("display")) return "pve-hw-pci-badge--gfx";
  if (t.includes("audio")) return "pve-hw-pci-badge--audio";
  if (t.includes("usb")) return "pve-hw-pci-badge--usb";
  if (t.includes("storage") || t.includes("sata") || t.includes("nvme") || t.includes("raid")) return "pve-hw-pci-badge--storage";
  if (t.includes("network") || t.includes("ethernet") || t.includes("wireless")) return "pve-hw-pci-badge--net";
  return "pve-hw-pci-badge--other";
}

function shortPciType(type: string) {
  const t = type.toLowerCase();
  if (t.includes("graphics") || t.includes("vga") || t.includes("display")) return "Graphics";
  if (t.includes("audio")) return "Audio";
  if (t.includes("usb")) return "USB";
  if (t.includes("storage") || t.includes("sata") || t.includes("nvme") || t.includes("raid")) return "Storage";
  if (t.includes("wireless")) return "Wi‑Fi";
  if (t.includes("network") || t.includes("ethernet")) return "Network";
  if (t.includes("bridge")) return "Bridge";
  if (t.includes("serial") || t.includes("smbus")) return "Bus";
  const cleaned = type.replace(/\s+Controller$/i, "").trim();
  return cleaned || "PCI";
}

function shortPciName(raw: string) {
  const cleaned = raw.replace(/\s*\(rev\s+[0-9a-f]+\)\s*$/i, "").trim();
  const gpuish = shortGpuName(cleaned);
  if (gpuish !== cleaned && /radeon|geforce|quadro|uhd|iris|arc|vega/i.test(gpuish)) return gpuish;

  const m = cleaned.match(/^(.+?)\s*\[([^\]]+)\]\s*$/);
  if (m) {
    const base = m[1].trim();
    const inner = m[2].trim();
    if (/mode$/i.test(inner)) return `${base} (${inner})`;
    if (inner.length >= 10 && inner.length >= base.length) return inner;
  }

  return cleaned.length > 52 ? `${cleaned.slice(0, 50)}…` : cleaned;
}

function shortPciVendor(vendor: string) {
  const trimmed = vendor.trim();
  if (!trimmed) return "";
  if (/samsung/i.test(trimmed)) return "Samsung";
  if (/realtek/i.test(trimmed)) return "Realtek";
  if (/broadcom/i.test(trimmed)) return "Broadcom";
  if (/nvidia/i.test(trimmed)) return "NVIDIA";
  if (/intel/i.test(trimmed)) return "Intel";
  if (/amd|advanced\s+micro|ati/i.test(trimmed)) return "AMD";
  if (/qualcomm|atheros/i.test(trimmed)) return "Qualcomm";
  if (/marvell/i.test(trimmed)) return "Marvell";
  if (/asmedia/i.test(trimmed)) return "ASMedia";

  const brackets = [...trimmed.matchAll(/\[([^\]]+)\]/g)].map((m) => m[1].trim()).filter(Boolean);
  if (brackets.length) {
    const last = brackets[brackets.length - 1];
    if (/amd/i.test(last)) return "AMD";
    return last.length > 18 ? `${last.slice(0, 16)}…` : last;
  }

  const stripped = trimmed
    .replace(/,?\s*(inc\.?|ltd\.?|co\.?\s*ltd\.?|corporation|corp\.?|co\.?)\s*/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
  const words = stripped.split(" ").filter(Boolean).slice(0, 2).join(" ");
  return words.length > 20 ? `${words.slice(0, 18)}…` : words || trimmed;
}

function sortPciDevices(devices: Array<Record<string, unknown>>) {
  const rank = (type: string) => {
    const t = type.toLowerCase();
    if (t.includes("graphics") || t.includes("vga") || t.includes("display")) return 0;
    if (t.includes("storage") || t.includes("sata") || t.includes("nvme") || t.includes("raid")) return 1;
    if (t.includes("network") || t.includes("ethernet") || t.includes("wireless")) return 2;
    if (t.includes("usb")) return 3;
    if (t.includes("audio")) return 4;
    return 5;
  };
  return [...devices].sort((a, b) => {
    const ra = rank(String(a.type || ""));
    const rb = rank(String(b.type || ""));
    if (ra !== rb) return ra - rb;
    return String(a.slot || "").localeCompare(String(b.slot || ""), undefined, { numeric: true });
  });
}
