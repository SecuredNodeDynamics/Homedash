"use client";

import { useMemo, type CSSProperties } from "react";
import { fmtBytes } from "../types";

type FlowGuest = {
  id: number;
  name: string;
  type: "vm" | "lxc";
  kind: "qemu" | "lxc";
  status?: string;
  netin: number;
  netout: number;
  rate?: number;
  rx?: number;
  tx?: number;
};

type PhysNic = {
  name: string;
  rx: number;
  tx: number;
  rate: number;
  label: string;
  active: boolean;
};

type FlowNodeModel = {
  name: string;
  x: number;
  y: number;
  r: number;
  label: string;
  kind: "nic" | "host" | "bridge" | "guest";
  rate: number;
  rx: number;
  tx: number;
  active: boolean;
  hot: boolean;
  iface?: string;
  busY?: number;
  id?: number;
  type?: "vm" | "lxc";
  gkind?: "qemu" | "lxc";
};

type Beam = { d: string; dir: "rx" | "tx"; sec: number; pathLen: number; bps: number };

const PVE_NF_ANIM = {
  density: true,
  splitBranches: true,
  softComet: true,
  nodePulse: true,
  dirOnly: true,
  cornerEase: true,
} as const;

const ICONS = {
  nic: (
    <g className="pve-nf-icon" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
      <path d="m15 20 3-3h2a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h2l3 3z" />
      <path d="M6 8v1" /><path d="M10 8v1" /><path d="M14 8v1" /><path d="M18 8v1" />
    </g>
  ),
  host: (
    <g className="pve-nf-icon" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
      <rect x="4" y="4" width="16" height="16" rx="2" />
      <rect x="9" y="9" width="6" height="6" rx="1" />
      <path d="M15 2v2" /><path d="M15 20v2" /><path d="M2 15h2" /><path d="M2 9h2" />
      <path d="M20 15h2" /><path d="M20 9h2" /><path d="M9 2v2" /><path d="M9 20v2" />
    </g>
  ),
  bridge: (
    <g className="pve-nf-icon" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
      <rect x="16" y="16" width="6" height="6" rx="1" />
      <rect x="2" y="16" width="6" height="6" rx="1" />
      <rect x="9" y="2" width="6" height="6" rx="1" />
      <path d="M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3" />
      <path d="M12 12V8" />
    </g>
  ),
  guest: (
    <g className="pve-nf-icon" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 7.7c0-.6-.4-1.2-.8-1.5l-6.3-3.9a1.72 1.72 0 0 0-1.7 0l-10.3 6c-.5.2-.9.8-.9 1.4v6.6c0 .5.4 1.2.8 1.5l6.3 3.9a1.72 1.72 0 0 0 1.7 0l10.3-6c.5-.3.9-1 .9-1.5Z" />
      <path d="M10 21.9V14L2.1 9.1" />
      <path d="m10 14 11.9-6.9" />
      <path d="M14 19.8v-8.1" />
      <path d="M18 17.5V9.4" />
    </g>
  ),
};

export function NetworkFlow({
  iface,
  ifaces,
  guests,
  onOpenIface,
  onOpenGuest,
}: {
  iface: string;
  ifaces: Array<Record<string, unknown>>;
  guests: FlowGuest[];
  onOpenIface: (iface: Record<string, unknown>) => void;
  onOpenGuest?: (guest: FlowGuest) => void;
}) {
  const model = useMemo(() => buildFlowModel(iface, ifaces, guests), [iface, ifaces, guests]);

  function resolveIface(name: string, kind: string): Record<string, unknown> {
    const hit = ifaces.find((i) => String(i.name || "") === name)
      || ifaces.find((i) => String(i.name || "").toLowerCase() === name.toLowerCase());
    return hit ? { ...hit, kind: hit.kind || kind } : { name, kind };
  }

  function onNodeClick(n: FlowNodeModel) {
    if (n.kind === "guest") {
      if (onOpenGuest && n.id) {
        onOpenGuest({
          id: n.id,
          name: n.name,
          type: n.type || "lxc",
          kind: n.gkind || "lxc",
          netin: n.rx,
          netout: n.tx,
          rate: n.rate,
          rx: n.rx,
          tx: n.tx,
        });
        return;
      }
      onOpenIface({
        name: n.name,
        kind: "guest",
        type: "virtual",
        vm_name: n.name,
        vmid: n.id,
        vm_type: n.gkind || "lxc",
        status: "up",
      });
      return;
    }
    if (n.kind === "host" || n.kind === "bridge") {
      onOpenIface(resolveIface(n.iface || iface, "bridge"));
      return;
    }
    onOpenIface(resolveIface(n.name, "nic"));
  }

  return (
    <div className="pve-nf-panel">
      <div
        className="pve-nf-wrap"
        style={{ aspectRatio: `${Math.max(1, model.W)} / ${Math.max(1, model.H)}` }}
      >
        <svg
          className="pve-flow-svg pve-nf-svg"
          viewBox={`0 0 ${model.W} ${model.H}`}
          preserveAspectRatio="xMidYMid meet"
          role="img"
          aria-label="Network flow diagram"
        >
          <g className="pve-nf-links">
            {model.links.map((link, i) => (
              <path key={i} className="pve-nf-link" d={link.d} strokeWidth={link.sw} fill="none" />
            ))}
          </g>
          {model.nodes.map((n) => (
            <FlowNode key={`${n.kind}-${n.id ?? n.name}-${n.x}-${n.y}`} node={n} onClick={() => onNodeClick(n)} />
          ))}
        </svg>
        <svg
          className="pve-nf-beams"
          viewBox={`0 0 ${model.W} ${model.H}`}
          preserveAspectRatio="xMidYMid meet"
          aria-hidden
        >
          {model.beams.map((b, i) => (
            <BeamGroup key={`${b.dir}-${i}`} beam={b} lite={model.liteBeams} />
          ))}
        </svg>
      </div>
      <div className="pve-flow-note">
        ProxMenux-style flow · {model.guestCount} running guests
      </div>
    </div>
  );
}

function FlowNode({ node, onClick }: { node: FlowNodeModel; onClick: () => void }) {
  const stroke = node.kind === "nic"
    ? (node.active ? "var(--pve-nf-amber, #f59e0b)" : "#525252")
    : node.kind === "host"
      ? "var(--pve-nf-amber, #f59e0b)"
      : "var(--pve-nf-cyan, #06b6d4)";
  const opacity = node.kind === "nic" && !node.active ? 0.45 : 1;
  const sw = node.kind === "host" ? 3 : 2.2;
  const scale = node.kind === "host" ? 1.15 : node.kind === "nic" ? 0.9 : node.kind === "bridge" ? 0.82 : 0.74;
  const iconOff = 12 * scale;
  const icon = ICONS[node.kind === "guest" ? "guest" : node.kind];
  const nameMax = node.kind === "guest" ? 17 : node.kind === "host" ? 10 : 14;
  const aboveBus = node.kind === "guest" && node.busY != null && node.y < node.busY;
  const nameY = aboveBus ? node.y - node.r - 18 : node.y + node.r + 17;
  const subY = aboveBus ? node.y - node.r - 32 : node.y + node.r + 32;

  return (
    <g
      className={`pve-nf-node pve-nf-node--${node.kind} pve-nf-node--clickable${node.hot ? " pve-nf-node--hot" : ""}`}
      opacity={opacity}
      style={{ color: stroke } as CSSProperties}
      role="button"
      tabIndex={0}
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        onClick();
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onClick();
        }
      }}
    >
      <circle className="pve-nf-hit" cx={node.x} cy={node.y} r={node.r + 12} fill="transparent" />
      {node.hot ? (
        <circle className="pve-nf-pulse" cx={node.x} cy={node.y} r={node.r + 4} stroke={stroke} fill="none" pointerEvents="none" />
      ) : null}
      <circle
        className="pve-nf-circle"
        cx={node.x}
        cy={node.y}
        r={node.r}
        stroke={stroke}
        strokeWidth={sw}
        fill="rgba(10,14,20,0.92)"
      />
      <g transform={`translate(${node.x - iconOff}, ${node.y - iconOff}) scale(${scale})`} pointerEvents="none">
        {icon}
      </g>
      <text className="pve-nf-label" x={node.x} y={nameY} textAnchor="middle" pointerEvents="none">
        {shortName(node.name, nameMax)}
      </text>
      <text className="pve-nf-sub" x={node.x} y={subY} textAnchor="middle" pointerEvents="none">
        {node.label}
      </text>
    </g>
  );
}

function BeamGroup({ beam, lite }: { beam: Beam; lite?: boolean }) {
  const { d, dir, sec, pathLen, bps } = beam;
  if (!sec || sec <= 0) return null;
  const softComet = PVE_NF_ANIM.softComet && !lite;
  const soft = softComet ? " pve-nf-beam--soft" : "";
  const ease = PVE_NF_ANIM.cornerEase ? "cubic-bezier(0.45, 0.05, 0.55, 0.95)" : "linear";
  const base = dir === "tx" ? "pve-nf-beam-base-tx" : "pve-nf-beam-base-rx";
  const mid = `${dir === "tx" ? "pve-nf-beam-tx" : "pve-nf-beam-rx"}${soft}`;
  const head = `${dir === "tx" ? "pve-nf-beam-head-tx" : "pve-nf-beam-head-rx"}${soft}`;
  const dur = `${sec.toFixed(2)}s`;
  const packets = beamPacketCount(bps, pathLen);
  const dash = softComet ? (packets > 2 ? 5.5 : 7) : (packets > 2 ? 4.5 : 6);
  const gap = Math.max(12, 100 / packets - dash);
  const headDash = softComet ? Math.max(3, dash * 0.7) : Math.max(2.5, dash * 0.55);
  const headGap = Math.max(12, 100 / packets - headDash);
  const dashStyle = `stroke-dasharray:${dash} ${gap}`;
  const headStyle = `stroke-dasharray:${headDash} ${headGap}`;
  const span = sec / packets;
  // High-traffic boards: one trail + head. Low traffic: richer softComet trails.
  const trail = softComet
    ? [
        { delay: span * 0.22, op: 0.22, sw: 2.8 },
        { delay: span * 0.08, op: 0.55, sw: 2.4 },
      ]
    : [{ delay: span * 0.12, op: 0.5, sw: 2.5 }];

  return (
    <g>
      <path className={base} d={d} strokeWidth={2.5} pathLength={100} />
      {trail.map((t, i) => (
        <path
          key={i}
          className={mid}
          d={d}
          strokeWidth={t.sw}
          pathLength={100}
          style={{
            animationDuration: dur,
            animationDelay: `${t.delay.toFixed(2)}s`,
            animationTimingFunction: ease,
            opacity: t.op,
            ...(parseDash(dashStyle) as CSSProperties),
          }}
        />
      ))}
      <path
        className={head}
        d={d}
        strokeWidth={softComet ? 3.2 : 2.5}
        pathLength={100}
        style={{
          animationDuration: dur,
          animationTimingFunction: ease,
          ...(parseDash(headStyle) as CSSProperties),
        }}
      />
    </g>
  );
}

function parseDash(style: string): { strokeDasharray?: string } {
  const m = /stroke-dasharray:([^;]+)/.exec(style);
  return m ? { strokeDasharray: m[1].trim() } : {};
}

function buildFlowModel(iface: string, ifaces: Array<Record<string, unknown>>, guests: FlowGuest[]) {
  const bridgeName = iface || "vmbr0";

  const physical: PhysNic[] = ifaces
    .filter((i) => {
      const kind = String(i.kind || "");
      const name = String(i.name || "");
      if (!name || isVirtualIface(name)) return false;
      if (kind === "bridge" || isBridgeIface(name)) return false;
      return kind === "nic" || kind === "physical" || !kind;
    })
    .map((i) => {
      const rx = Number(i.rx ?? i.rx_Bps ?? i.bytes_recv_rate_per_sec ?? 0);
      const tx = Number(i.tx ?? i.tx_Bps ?? i.bytes_sent_rate_per_sec ?? 0);
      const speed = glancesSpeedToMbps(i.speed ?? i.max_speed);
      const up = Boolean(i.up ?? /up/i.test(String(i.status || "")));
      const rate = rx + tx;
      const active = up || rate > 64 || speed > 0;
      return {
        name: String(i.name || "nic"),
        rx,
        tx,
        rate,
        label: speed > 0
          ? (speed >= 1000 ? `${(speed / 1000).toFixed(1)} Gbps` : `${Math.round(speed)} Mbps`)
          : (active ? fmtRate(rate) : "N/A"),
        active,
      };
    })
    .sort((a, b) => Number(b.active) - Number(a.active) || b.rate - a.rate);

  if (!physical.length) {
    physical.push({ name: "nic0", rx: 0, tx: 0, rate: 0, label: "N/A", active: true });
  } else if (!physical.some((p) => p.active)) {
    physical[0].active = true;
  }

  const bridge = ifaces.find((i) => String(i.name) === bridgeName)
    || ifaces.find((i) => String(i.kind) === "bridge" || isBridgeIface(String(i.name || "")));
  const bridgeRx = Number(bridge?.rx ?? bridge?.rx_Bps ?? bridge?.bytes_recv_rate_per_sec ?? 0);
  const bridgeTx = Number(bridge?.tx ?? bridge?.tx_Bps ?? bridge?.bytes_sent_rate_per_sec ?? 0);
  const bridgeRate = bridgeRx + bridgeTx;
  const hostRx = physical.filter((p) => p.active).reduce((s, p) => s + p.rx, 0) || bridgeRx;
  const hostTx = physical.filter((p) => p.active).reduce((s, p) => s + p.tx, 0) || bridgeTx;
  const hostRate = hostRx + hostTx || bridgeRate;

  const shown = [...guests]
    .map((g) => ({
      ...g,
      rx: Number(g.rx || 0),
      tx: Number(g.tx || 0),
      rate: Number(g.rate ?? 0) || Number(g.rx || 0) + Number(g.tx || 0),
    }))
    .sort((a, b) => b.rate - a.rate || a.name.localeCompare(b.name))
    .slice(0, 24);

  const R_NIC = 22;
  const R_HOST = 32;
  const R_BR = 20;
  const R_GUEST = 18;
  const nicX = 64;
  const hostX = 220;
  const brX = 350;
  const cols = 4;
  const colGap = 118;
  const gridX0 = 470;
  const pairGap = 160;
  const bandGap = 56;
  const bands = Math.max(1, Math.ceil(Math.max(shown.length, 1) / (cols * 2)));
  const bandH = pairGap + 100;
  const gridH = bands * bandH + (bands - 1) * bandGap;
  const leftH = Math.max(Math.min(physical.length, 3), 1) * 88;
  const H = Math.max(320, 64 + Math.max(leftH, gridH));
  const midY = H / 2;
  const W = gridX0 + (cols - 1) * colGap + 90;
  const CORNER = 16;
  const STUB_GAP = 8;

  const leftCount = Math.min(physical.length, 3);
  const stackY = (i: number, n: number) => {
    if (n <= 1) return midY - 24;
    const span = (n - 1) * 88;
    return midY - 24 - span / 2 + i * 88;
  };

  const physNodes: FlowNodeModel[] = physical.slice(0, leftCount).map((p, i) => ({
    ...p,
    x: nicX,
    y: stackY(i, leftCount),
    r: R_NIC,
    kind: "nic" as const,
    hot: hotNode(p.rate, p.rx, p.tx, p.active),
  }));

  const hostNode: FlowNodeModel = {
    name: "PROXMOX",
    x: hostX,
    y: midY,
    r: R_HOST,
    rate: hostRate,
    rx: hostRx,
    tx: hostTx,
    label: fmtRate(hostRate),
    kind: "host",
    iface: bridgeName,
    active: true,
    hot: hotNode(hostRate, hostRx, hostTx, true),
  };

  const brNode: FlowNodeModel = {
    name: bridgeName,
    x: brX,
    y: midY,
    r: R_BR,
    rate: bridgeRate,
    rx: bridgeRx,
    tx: bridgeTx,
    label: fmtRate(bridgeRate),
    kind: "bridge",
    iface: bridgeName,
    active: true,
    hot: hotNode(bridgeRate, bridgeRx, bridgeTx, true),
  };

  const guestNodes: FlowNodeModel[] = [];
  const bandBuses: number[] = [];
  const list = shown.length
    ? shown
    : [{ id: 0, name: "idle", type: "lxc" as const, kind: "lxc" as const, netin: 0, netout: 0, rate: 0, rx: 0, tx: 0 }];

  for (let b = 0; b < bands; b++) {
    const bandTop = (H - gridH) / 2 + b * (bandH + bandGap);
    const busY = bandTop + bandH / 2;
    bandBuses.push(busY);
    for (let slot = 0; slot < cols * 2; slot++) {
      const idx = b * cols * 2 + slot;
      if (idx >= list.length) break;
      const c = Math.floor(slot / 2);
      const above = slot % 2 === 0;
      const g = list[idx];
      const rate = Number(g.rate || 0);
      guestNodes.push({
        name: g.name,
        id: g.id,
        type: g.type,
        gkind: g.kind,
        x: gridX0 + c * colGap,
        y: above ? busY - pairGap / 2 : busY + pairGap / 2,
        r: R_GUEST,
        busY,
        rate,
        rx: Number(g.rx || 0),
        tx: Number(g.tx || 0),
        label: isZeroFlowLabel(rate) ? "—" : fmtRate(rate),
        kind: "guest",
        active: true,
        hot: hotNode(rate, Number(g.rx || 0), Number(g.tx || 0), true),
      });
    }
  }

  const links: Array<{ d: string; sw: number }> = [];
  const beams: Beam[] = [];

  const pushBeam = (d: string, dir: "rx" | "tx", bps: number) => {
    const rate = Number(bps) || 0;
    if (PVE_NF_ANIM.dirOnly && rate < 512) return;
    const pathLen = approxPathLen(d);
    const sec = beamTravelSec(rate, pathLen);
    if (sec > 0) beams.push({ d, dir, sec, pathLen, bps: rate });
  };

  for (const p of physNodes) {
    if (!p.active) continue;
    const x0 = p.x + p.r;
    const y0 = p.y;
    const x1 = hostNode.x - hostNode.r;
    const y1 = hostNode.y;
    const elbowX = Math.round((x0 + x1) / 2);
    const dy = Math.sign(y1 - y0);
    let d = `M ${x0} ${y0}`;
    if (Math.abs(y1 - y0) < 2) {
      d += ` L ${x1} ${y1}`;
    } else {
      const r = Math.min(CORNER, Math.abs(x1 - x0) / 4, Math.abs(y1 - y0) / 2);
      d += ` L ${elbowX - r} ${y0}`;
      d += ` Q ${elbowX} ${y0} ${elbowX} ${y0 + dy * r}`;
      d += ` L ${elbowX} ${y1 - dy * r}`;
      d += ` Q ${elbowX} ${y1} ${elbowX + r} ${y1}`;
      d += ` L ${x1} ${y1}`;
    }
    links.push({ d, sw: 4 });
    const uplinkRx = Math.max(p.rx || 0, bridgeRx || 0, hostRx || 0);
    const uplinkTx = Math.max(p.tx || 0, bridgeTx || 0, hostTx || 0);
    pushBeam(d, "rx", uplinkRx);
    pushBeam(d, "tx", uplinkTx);
  }

  {
    const d = `M ${hostNode.x + hostNode.r} ${hostNode.y} L ${brNode.x - brNode.r} ${brNode.y}`;
    links.push({ d, sw: 4 });
    pushBeam(d, "rx", bridgeRx || hostRx);
    pushBeam(d, "tx", bridgeTx || hostTx);
  }

  const hubX = brNode.x + 44;
  const guestRxSum = guestNodes.reduce((s, g) => s + (g.rx || 0), 0);
  const guestTxSum = guestNodes.reduce((s, g) => s + (g.tx || 0), 0);
  const trunkRx = bridgeRx || hostRx || guestRxSum;
  const trunkTx = bridgeTx || hostTx || guestTxSum;
  const busJoinX = hubX + CORNER;

  const pathBridgeToBusJoin = (busY: number) => {
    const dy = Math.sign(busY - brNode.y);
    let d = `M ${brNode.x + brNode.r} ${brNode.y}`;
    if (dy !== 0 && Math.abs(busY - brNode.y) > CORNER * 2) {
      d += ` L ${hubX - CORNER} ${brNode.y}`;
      d += ` Q ${hubX} ${brNode.y} ${hubX} ${brNode.y + dy * CORNER}`;
      d += ` L ${hubX} ${busY - dy * CORNER}`;
      d += ` Q ${hubX} ${busY} ${busJoinX} ${busY}`;
    } else {
      d += ` L ${busJoinX} ${busY}`;
    }
    return d;
  };

  const guestStubEndY = (g: FlowNodeModel) => (
    (g.busY != null && g.y < g.busY) ? g.y + g.r + STUB_GAP : g.y - g.r - STUB_GAP
  );

  const pathGuestStub = (g: FlowNodeModel) => {
    const busY = g.busY || g.y;
    const dropY = guestStubEndY(g);
    const dy = Math.sign(dropY - busY) || 1;
    const r = Math.min(CORNER, Math.abs(dropY - busY) / 2);
    return `M ${g.x - r} ${busY} Q ${g.x} ${busY} ${g.x} ${busY + dy * r} L ${g.x} ${dropY}`;
  };

  const pathBranchToGuest = (g: FlowNodeModel) => {
    const busY = g.busY || g.y;
    let d = pathBridgeToBusJoin(busY);
    const stubStart = g.x - CORNER;
    if (stubStart > busJoinX + 0.5) d += ` L ${stubStart} ${busY}`;
    const dropY = guestStubEndY(g);
    const dy = Math.sign(dropY - busY) || 1;
    const r = Math.min(CORNER, Math.abs(dropY - busY) / 2);
    d += ` L ${g.x - r} ${busY}`;
    d += ` Q ${g.x} ${busY} ${g.x} ${busY + dy * r}`;
    d += ` L ${g.x} ${dropY}`;
    return d;
  };

  for (const busY of bandBuses) {
    const bandGuests = guestNodes.filter((g) => g.busY === busY);
    const colXs = [...new Set(bandGuests.map((g) => g.x))].sort((a, b) => a - b);
    let d = pathBridgeToBusJoin(busY);
    let x = busJoinX;
    for (const cx of colXs) {
      const stubStart = cx - CORNER;
      if (stubStart > x + 0.5) d += ` L ${stubStart} ${busY}`;
      x = Math.max(x, stubStart);
    }
    links.push({ d, sw: 3 });
    if (!PVE_NF_ANIM.splitBranches) {
      pushBeam(d, "rx", trunkRx);
      pushBeam(d, "tx", trunkTx);
    }
  }

  for (const g of guestNodes) {
    const d = pathGuestStub(g);
    links.push({ d, sw: 3 });
    if (!PVE_NF_ANIM.splitBranches && !isZeroFlowLabel(g.rate)) {
      pushBeam(d, "rx", g.rx);
      pushBeam(d, "tx", g.tx);
    }
  }

  if (PVE_NF_ANIM.splitBranches) {
    for (const g of guestNodes) {
      if (isZeroFlowLabel(g.rate)) continue;
      const d = pathBranchToGuest(g);
      pushBeam(d, "rx", g.rx);
      pushBeam(d, "tx", g.tx);
    }
  }

  // Cap animated beams so busy hosts (high throughput) stay snappy.
  const MAX_BEAMS = 20;
  const sortedBeams = [...beams].sort((a, b) => b.bps - a.bps);
  const cappedBeams = sortedBeams.slice(0, MAX_BEAMS);
  const liteBeams = cappedBeams.length >= 12 || hostRate >= 200_000;

  return {
    W,
    H,
    links,
    beams: cappedBeams,
    liteBeams,
    nodes: [...physNodes, hostNode, brNode, ...guestNodes],
    guestCount: shown.length,
  };
}

function hotNode(rate: number, rx: number, tx: number, active: boolean) {
  return PVE_NF_ANIM.nodePulse && active && !isZeroFlowLabel(rate)
    && ((Number(rate) || 0) >= 2048 || (Number(rx) || 0) >= 1024 || (Number(tx) || 0) >= 1024);
}

function shortName(name: string, max = 16) {
  const s = String(name || "");
  return s.length > max ? `${s.slice(0, max - 1)}…` : s;
}

function fmtRate(bps: number) {
  if (!Number.isFinite(bps) || bps <= 0) return "0 B/s";
  return `${fmtBytes(bps)}/s`;
}

function isZeroFlowLabel(bps: number) {
  const n = Number(bps) || 0;
  if (n <= 0) return true;
  if (n < 1e3) return Math.round(n) === 0;
  return false;
}

function isVirtualIface(name: string) {
  return /^(lo|veth|fwbr|fwpr|fwln|tap|tun|docker|br-|virbr|vnet|cni|flannel|cali|tailscale|wg|zt)/i.test(name || "");
}

function isBridgeIface(name: string) {
  return /^vmbr/i.test(name || "");
}

function glancesSpeedToMbps(speed: unknown) {
  const n = Number(speed);
  if (!Number.isFinite(n) || n <= 0) return 0;
  if (n >= 1e6) return Math.round(n / 1e6);
  return n;
}

function beamSec(bps: number) {
  const B = Number(bps) || 0;
  if (B < 512) return 0;
  const kb = B / 1024;
  return Math.max(0.85, Math.min(3.6, 3.8 - Math.log10(kb + 1) * 0.95));
}

function approxPathLen(d: string) {
  const tokens = String(d || "").match(/[MLQ]|[-+]?(?:\d*\.\d+|\d+)/gi) || [];
  let i = 0;
  let x = 0;
  let y = 0;
  let len = 0;
  let started = false;
  while (i < tokens.length) {
    const t = tokens[i++];
    if (t === "M" || t === "L") {
      const nx = Number(tokens[i++]);
      const ny = Number(tokens[i++]);
      if (!Number.isFinite(nx) || !Number.isFinite(ny)) break;
      if (t === "L" && started) len += Math.hypot(nx - x, ny - y);
      x = nx;
      y = ny;
      started = true;
    } else if (t === "Q") {
      const cx = Number(tokens[i++]);
      const cy = Number(tokens[i++]);
      const nx = Number(tokens[i++]);
      const ny = Number(tokens[i++]);
      if (![cx, cy, nx, ny].every(Number.isFinite)) break;
      if (started) {
        const chord = Math.hypot(nx - x, ny - y);
        const via = Math.hypot(cx - x, cy - y) + Math.hypot(nx - cx, ny - cy);
        len += (chord + via) / 2;
      }
      x = nx;
      y = ny;
      started = true;
    }
  }
  return Math.max(len, 1);
}

function beamTravelSec(bps: number, pathLen: number) {
  const base = beamSec(bps);
  if (!base) return 0;
  const REF = 88;
  const len = Math.max(Number(pathLen) || REF, REF * 0.5);
  return Math.min(14, Math.max(0.9, base * (len / REF)));
}

function beamPacketCount(bps: number, pathLen: number) {
  const lenPack = Math.max(1, Math.min(4, Math.round((Number(pathLen) || 88) / 120)));
  if (!PVE_NF_ANIM.density) return lenPack;
  const kb = (Number(bps) || 0) / 1024;
  const rateExtra = kb < 80 ? 0 : kb < 400 ? 1 : kb < 2048 ? 2 : 3;
  return Math.max(1, Math.min(6, lenPack + rateExtra));
}
