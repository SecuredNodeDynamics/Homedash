"use client";

import { useMemo, useRef, useState } from "react";
import { fmtBytes, type StatusPayload } from "../types";
import { TrafficChart } from "./TrafficChart";
import { NetworkFlow } from "./NetworkFlow";

type FlowGuestClick = {
  id: number;
  name: string;
  type: "vm" | "lxc";
  kind: "qemu" | "lxc";
  status?: string;
  netin: number;
  netout: number;
  rate?: number;
  rx?: number;
  tx?: number;
};

export function NetworkTab({
  data,
  onOpenIface,
  onOpenGuest,
}: {
  data: StatusPayload;
  onOpenIface: (iface: Record<string, unknown>) => void;
  onOpenGuest?: (guest: FlowGuestClick) => void;
}) {
  const [sub, setSub] = useState<"flow" | "ifaces">("flow");
  const network = data.network || { rrd: [], ifaces: [], flowGuests: [] };
  const ifaces = Array.isArray(network.ifaces) ? network.ifaces : [];
  const flowGuests = Array.isArray(network.flowGuests) ? network.flowGuests : [];
  const ratesRef = useRef<Map<string, { nin: number; nout: number; at: number; rx: number; tx: number }>>(new Map());

  const guestsWithRates = useMemo(() => {
    const now = Date.now();
    return flowGuests.map((g) => {
      const key = `${g.kind}-${g.id}`;
      const prev = ratesRef.current.get(key);
      let rx = prev?.rx || 0;
      let tx = prev?.tx || 0;
      if (prev && now - prev.at > 500) {
        const dt = Math.max(1, (now - prev.at) / 1000);
        rx = Math.max(0, (Number(g.netin) - prev.nin) / dt);
        tx = Math.max(0, (Number(g.netout) - prev.nout) / dt);
      }
      ratesRef.current.set(key, {
        nin: Number(g.netin) || 0,
        nout: Number(g.netout) || 0,
        at: now,
        rx,
        tx,
      });
      return { ...g, rate: rx + tx, rx, tx };
    });
  }, [flowGuests, data.updatedAt]);

  const { physical, bridges, virtual } = useMemo(() => partitionIfaces(ifaces), [ifaces]);
  const physActive = physical.filter((p) => isUp(p)).length;
  const brActive = bridges.filter((b) => isUp(b)).length;
  const virtActive = virtual.filter((v) => isUp(v)).length;

  const liveRx = Number(data.overview?.rxBytes || 0);
  const liveTx = Number(data.overview?.txBytes || 0);

  return (
    <div className="pve-network-tab">
      <section className="pve-net-card">
        <div className="pve-net-card-hdr">
          <div className="pve-net-card-title">Network Traffic</div>
          <div className="pve-net-legend">
            <span className="pve-net-legend-item"><i className="pve-net-swatch pve-net-swatch--rx" />Received</span>
            <span className="pve-net-legend-item"><i className="pve-net-swatch pve-net-swatch--tx" />Sent</span>
          </div>
          <div className="pve-net-live">
            <span className="pve-net-chip pve-net-chip--rx">↓ {fmtBps(liveRx)}</span>
            <span className="pve-net-chip pve-net-chip--tx">↑ {fmtBps(liveTx)}</span>
          </div>
        </div>
        <div className="pve-net-card-body">
          <TrafficChart rrd={network.rrd || []} />
        </div>
      </section>

      <section className="pve-net-card pve-net-card--flow-ifaces">
        <div className="pve-net-subtabs" role="tablist">
          <button type="button" className={`pve-net-subtab${sub === "flow" ? " pve-net-subtab--active" : ""}`} onClick={() => setSub("flow")}>
            Network Flow
          </button>
          <button type="button" className={`pve-net-subtab${sub === "ifaces" ? " pve-net-subtab--active" : ""}`} onClick={() => setSub("ifaces")}>
            Interfaces
          </button>
        </div>
        {/* Keep both panes mounted so Network Flow SVG/beams are not rebuilt on every tab switch. */}
        <div
          className={`pve-net-card-body pve-net-card-body--flow${sub === "flow" ? "" : " is-hidden"}`}
          hidden={sub !== "flow"}
          aria-hidden={sub !== "flow"}
        >
          <NetworkFlow
            iface={data.iface || "vmbr0"}
            ifaces={ifaces}
            guests={guestsWithRates}
            onOpenIface={onOpenIface}
            onOpenGuest={onOpenGuest}
          />
        </div>
        <div
          className={`pve-net-card-body pve-net-card-body--ifaces${sub === "ifaces" ? "" : " is-hidden"}`}
          hidden={sub !== "ifaces"}
          aria-hidden={sub !== "ifaces"}
        >
          <div className="pve-ni-wrap">
            <section className="pve-ni-section">
              <div className="pve-ni-section-hdr">
                <div className="pve-ni-section-title"><span>Physical Interfaces</span></div>
                <span className="pve-ni-count-badge pve-ni-count-badge--blue">{physActive}/{physical.length} Active</span>
              </div>
              <div className="pve-ni-grid">
                {physical.length ? physical.map((iface, i) => (
                  <IfaceCard
                    key={String(iface.name || i)}
                    iface={iface}
                    variant="physical"
                    allIfaces={ifaces}
                    onOpen={onOpenIface}
                  />
                )) : <div className="pve-net-empty">No physical interfaces found.</div>}
              </div>
            </section>
            <section className="pve-ni-section">
              <div className="pve-ni-section-hdr">
                <div className="pve-ni-section-title"><span>Bridge Interfaces</span></div>
                <span className="pve-ni-count-badge pve-ni-count-badge--green">{brActive}/{bridges.length} Active</span>
              </div>
              <div className="pve-ni-bridge-list">
                {bridges.length ? bridges.map((iface, i) => (
                  <IfaceCard
                    key={String(iface.name || i)}
                    iface={iface}
                    variant="bridge"
                    allIfaces={ifaces}
                    onOpen={onOpenIface}
                  />
                )) : <div className="pve-net-empty">No bridge interfaces found.</div>}
              </div>
            </section>
            {virtual.length ? (
              <section className="pve-ni-section">
                <div className="pve-ni-section-hdr">
                  <div className="pve-ni-section-title"><span>Virtual / Overlay</span></div>
                  <span className="pve-ni-count-badge">{virtActive}/{virtual.length} Active</span>
                </div>
                <div className="pve-ni-grid">
                  {virtual.map((iface, i) => (
                    <IfaceCard
                      key={String(iface.name || i)}
                      iface={iface}
                      variant="virtual"
                      allIfaces={ifaces}
                      onOpen={onOpenIface}
                    />
                  ))}
                </div>
              </section>
            ) : null}
          </div>
        </div>
      </section>
    </div>
  );
}

function IfaceCard({
  iface,
  variant,
  allIfaces,
  onOpen,
}: {
  iface: Record<string, unknown>;
  variant: "physical" | "bridge" | "virtual";
  allIfaces: Array<Record<string, unknown>>;
  onOpen: (iface: Record<string, unknown>) => void;
}) {
  const name = String(iface.name || "iface");
  const up = isUp(iface);
  const status = String(iface.status || (up ? "UP" : "DOWN")).toUpperCase();
  const duplex = String(iface.duplex || "—");
  const speed = formatSpeed(Number(iface.speed ?? iface.max_speed ?? 0));
  const mtu = iface.mtu != null && String(iface.mtu) !== "" ? String(iface.mtu) : "—";
  const rx = Number(iface.rx ?? iface.rx_Bps ?? iface.bytes_recv_rate_per_sec ?? 0);
  const tx = Number(iface.tx ?? iface.tx_Bps ?? iface.bytes_sent_rate_per_sec ?? 0);
  const drops = Number(iface.drops_in || 0) + Number(iface.drops_out || 0);
  const mac = String(iface.mac_address || iface.mac || "");
  const bridgeOwner = String(iface.bridge_owner || "");
  const physMembers = bridgePhysicalMembers(iface, allIfaces);
  const guestMembers = bridgeGuestMembers(iface);
  const ip = primaryIp(iface);
  const badgeTone = variant === "bridge" ? "green" : variant === "virtual" ? "purple" : "blue";
  const badgeLabel = variant === "bridge" ? "Bridge" : variant === "virtual" ? "Virtual" : "Physical";

  return (
    <button
      type="button"
      className={`pve-ni-card pve-ni-card--${variant}${up ? "" : " pve-ni-card--down"}`}
      onClick={() => onOpen(iface)}
    >
      <div className="pve-ni-card-top">
        <div className="pve-ni-card-id">
          <span className="pve-ni-name">{name}</span>
          <span className={`pve-if-badge pve-if-badge--${badgeTone}`}>{badgeLabel}</span>
        </div>
        <div className="pve-ni-card-status">
          <span className={`pve-ni-status ${up ? "is-up" : "is-down"}`}><i className="pve-ni-dot" />{status}</span>
          {variant === "physical" && duplex && duplex !== "—" && duplex.toLowerCase() !== "unknown" ? (
            <span className="pve-ni-duplex">{duplex}</span>
          ) : null}
        </div>
      </div>

      {variant === "bridge" ? (
        <div className="pve-ni-card-row">
          <div className="pve-ni-stat"><span className="pve-ni-stat-k">IP Address</span><span className="pve-ni-stat-v pve-ni-stat-v--mono">{ip}</span></div>
          <div className="pve-ni-stat"><span className="pve-ni-stat-k">Speed</span><span className="pve-ni-stat-v pve-ni-stat-v--speed">{speed}</span></div>
          <div className="pve-ni-stat"><span className="pve-ni-stat-k">Received</span><span className="pve-ni-stat-v is-rx">{fmtBytes(rx)}/s</span></div>
          <div className="pve-ni-stat"><span className="pve-ni-stat-k">Sent</span><span className="pve-ni-stat-v is-tx">{fmtBytes(tx)}/s</span></div>
        </div>
      ) : (
        <div className="pve-ni-card-grid">
          <div className="pve-ni-stat"><span className="pve-ni-stat-k">Speed</span><span className="pve-ni-stat-v pve-ni-stat-v--speed">{speed}</span></div>
          <div className="pve-ni-stat"><span className="pve-ni-stat-k">MTU</span><span className="pve-ni-stat-v">{mtu}</span></div>
          <div className="pve-ni-stat"><span className="pve-ni-stat-k">Received</span><span className="pve-ni-stat-v is-rx">{fmtBytes(rx)}/s</span></div>
          <div className="pve-ni-stat"><span className="pve-ni-stat-k">Sent</span><span className="pve-ni-stat-v is-tx">{fmtBytes(tx)}/s</span></div>
          {drops > 0 ? (
            <div className="pve-ni-stat pve-ni-stat--drops">
              <span className="pve-ni-stat-k">Drops</span>
              <span className="pve-ni-stat-v"><i className="pve-ni-dot pve-ni-dot--red" />{drops.toLocaleString()}</span>
            </div>
          ) : null}
        </div>
      )}

      {variant === "physical" && bridgeOwner ? (
        <div className="pve-ni-link-row">
          <span className="pve-ni-link-k">Linked bridge</span>
          <span className="pve-ni-link-v">{bridgeOwner}</span>
        </div>
      ) : null}

      {variant === "bridge" ? (
        <div className="pve-ni-link-row pve-ni-link-row--wrap">
          <span className="pve-ni-link-k">Members</span>
          <span className="pve-ni-members">
            {physMembers.length
              ? physMembers.map((m) => <span className="pve-ni-member" key={m}>{m}</span>)
              : <span className="pve-ni-member pve-ni-member--muted">No physical members</span>}
            {guestMembers > 0 ? (
              <span className="pve-ni-member pve-ni-member--muted">+{guestMembers} guest</span>
            ) : null}
          </span>
        </div>
      ) : null}

      <div className="pve-ni-card-foot">
        <span className="pve-ni-mac">{mac || (variant === "bridge" ? `MTU ${mtu}` : "—")}</span>
        <span className="pve-ni-card-arrow" aria-hidden>→</span>
      </div>
    </button>
  );
}

function partitionIfaces(ifaces: Array<Record<string, unknown>>) {
  const physical: Array<Record<string, unknown>> = [];
  const bridges: Array<Record<string, unknown>> = [];
  const virtual: Array<Record<string, unknown>> = [];

  for (const iface of ifaces) {
    const name = String(iface.name || "");
    const kind = String(iface.kind || iface.type || "").toLowerCase();
    if (!name) continue;
    if (kind === "bridge" || /^vmbr/i.test(name)) {
      bridges.push(iface);
      continue;
    }
    if (kind === "virtual" || isVirtualIfaceName(name)) {
      virtual.push(iface);
      continue;
    }
    if (kind === "vm_lxc" || /^veth/i.test(name)) continue;
    physical.push(iface);
  }

  physical.sort((a, b) => Number(isUp(b)) - Number(isUp(a)) || String(a.name).localeCompare(String(b.name)));
  bridges.sort((a, b) => String(a.name).localeCompare(String(b.name)));
  virtual.sort((a, b) => String(a.name).localeCompare(String(b.name)));
  return { physical, bridges, virtual };
}

function bridgePhysicalMembers(iface: Record<string, unknown>, allIfaces: Array<Record<string, unknown>>) {
  const members = Array.isArray(iface.bridge_members) ? iface.bridge_members : [];
  const names = members
    .map((m) => (typeof m === "string" ? m : String((m as { name?: string })?.name || "")))
    .filter(Boolean);
  const physNames = new Set(
    allIfaces
      .filter((i) => String(i.kind || i.type || "") === "nic" || String(i.kind || i.type || "") === "physical")
      .map((i) => String(i.name || "")),
  );
  const linked = names.filter((n) => physNames.has(n) || (!isVirtualIfaceName(n) && !/^veth/i.test(n) && !/^vmbr/i.test(n)));
  const ownerLinks = allIfaces
    .filter((i) => String(i.bridge_owner || "") === String(iface.name || "") && (String(i.kind) === "nic" || String(i.type) === "physical"))
    .map((i) => String(i.name || ""));
  return [...new Set([...linked, ...ownerLinks])].filter(Boolean);
}

function bridgeGuestMembers(iface: Record<string, unknown>) {
  const members = Array.isArray(iface.bridge_members) ? iface.bridge_members : [];
  return members.filter((m) => {
    const name = typeof m === "string" ? m : String((m as { name?: string })?.name || "");
    return /^veth/i.test(name);
  }).length;
}

function primaryIp(iface: Record<string, unknown>) {
  let ip = String(iface.ip || "—");
  const addrs = Array.isArray(iface.addresses) ? iface.addresses : [];
  if ((!iface.ip || ip === "—") && addrs.length) {
    const first = addrs[0];
    if (first && typeof first === "object" && ("address" in first || "ip" in first)) {
      ip = String((first as { address?: string; ip?: string }).ip || (first as { address?: string }).address || "—");
    } else {
      ip = String(first || "—");
    }
  }
  return ip;
}

function isVirtualIfaceName(name: string) {
  return /^(lo|veth|fwbr|fwpr|fwln|tap|tun|docker|br-|virbr|vnet|cni|flannel|cali|tailscale|wg|zt)/i.test(name || "");
}

function isUp(iface: Record<string, unknown>) {
  if (typeof iface.up === "boolean") return iface.up;
  if (typeof iface.isup === "boolean") return iface.isup;
  const status = String(iface.status || "").toLowerCase();
  if (status === "up") return true;
  if (status === "down") return false;
  const rx = Number(iface.rx ?? iface.rx_Bps ?? 0);
  const tx = Number(iface.tx ?? iface.tx_Bps ?? 0);
  return rx + tx > 64;
}

/** Accept Mbps already, or Glances-style bits/s. */
function formatSpeed(raw: number) {
  if (!Number.isFinite(raw) || raw <= 0) return "N/A";
  const mbps = raw >= 1e6 ? Math.round(raw / 1e6) : Math.round(raw);
  if (mbps <= 0) return "N/A";
  if (mbps >= 1000) return `${(mbps / 1000).toFixed(mbps % 1000 === 0 ? 0 : 1)} Gb/s`;
  return `${mbps} Mb/s`;
}

function fmtBps(bps: number) {
  if (!Number.isFinite(bps) || bps <= 0) return "0 B/s";
  return `${fmtBytes(bps)}/s`;
}
