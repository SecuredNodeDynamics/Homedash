"use client";

import { Sparkline } from "./Charts";
import type { Overview, StatusPayload } from "../types";

export function OverviewTab({ data, history }: { data: StatusPayload; history: { cpu: number[]; mem: number[]; rx: number[] } }) {
  const ov: Overview | undefined = data.overview;
  if (!ov) {
    return <div className="pve-g-empty">Overview metrics unavailable</div>;
  }
  const updates = Array.isArray(ov.updates) ? ov.updates : [];
  const topProcs = Array.isArray(ov.topProcs) ? ov.topProcs : [];
  return (
    <div className="pve-overview-tab">
      <div className="pve-ov-summary">
        <Kpi label="CPU" value={`${ov.liveCpuPct ?? 0}%`} color={ov.liveCpuColor || "#6ee7b7"} />
        <Kpi label="Memory" value={`${ov.liveMemPct ?? 0}%`} color={ov.liveMemColor || "#6ee7b7"} />
        <Kpi label="Disk" value={`${ov.diskPct ?? 0}%`} color={ov.diskColor || "#6ee7b7"} />
        {ov.cpuTemp != null ? <Kpi label="CPU Temp" value={`${Math.round(ov.cpuTemp)}°C`} color={tempColor(ov.cpuTemp)} /> : null}
        <Kpi label="Load Avg" value={ov.loadDisplay || "—"} color={ov.loadBarColor || "#6ee7b7"} sub={ov.loadSub} />
        <Kpi label="Swap" value={ov.swapDisplay || "—"} color={ov.swapColor || "#6ee7b7"} sub={ov.swapSub} />
        <Kpi label="Processes" value={ov.procDisplay || "—"} color={ov.procColor || "#6ee7b7"} sub={ov.procSub} />
        <div className="pve-ov-kpi">
          <div className="pve-ov-kpi-val">
            <div className="pve-ov-kpi-net">
              <span className="is-rx">↓ {ov.rxLabel || "0 B/s"}</span>
              <span className="is-tx">↑ {ov.txLabel || "0 B/s"}</span>
            </div>
          </div>
          <div className="pve-ov-kpi-label">Network</div>
        </div>
        {ov.ioWaitPct != null ? <Kpi label="IO Wait" value={`${ov.ioWaitPct}%`} color={ov.ioWaitColor || "#6ee7b7"} /> : null}
        <Kpi label="Uptime" value={data.uptimeLabel || "—"} color="#a5b4fc" />
      </div>

      <div className="pve-ov-scroll">
        <section className="pve-ov-list-card">
          <div className="pve-ov-pane-hdr">Live Metrics — Glances</div>
          <div className="pve-ov-metrics">
            <div className="pve-ov-metric">
              <div className="pve-ov-metric-hdr"><span>CPU</span><b style={{ color: ov.liveCpuColor }}>{ov.liveCpuPct}%</b></div>
              <Sparkline values={history.cpu} color={ov.liveCpuColor} />
              <div className="pve-ov-track"><div className="pve-ov-track-fill" style={{ width: `${ov.liveCpuPct}%`, background: ov.liveCpuColor }} /></div>
            </div>
            <div className="pve-ov-metric">
              <div className="pve-ov-metric-hdr"><span>Memory</span><b style={{ color: ov.liveMemColor }}>{ov.liveMemPct}%</b></div>
              <Sparkline values={history.mem} color={ov.liveMemColor} />
              <div className="pve-ov-track"><div className="pve-ov-track-fill" style={{ width: `${ov.liveMemPct}%`, background: ov.liveMemColor }} /></div>
              <div className="pve-ov-metric-sub">{ov.liveMemUsed} / {ov.liveMemTotal}</div>
            </div>
            <div className="pve-ov-metric pve-ov-metric--wide">
              <div className="pve-ov-metric-hdr"><span>Network ({data.iface})</span></div>
              <Sparkline values={history.rx} color="#6ee7b7" />
              <div className="pve-ov-net-chips">
                <span className="pve-ov-chip is-rx">↓ {ov.rxLabel}</span>
                <span className="pve-ov-chip is-tx">↑ {ov.txLabel}</span>
              </div>
            </div>
            <div className="pve-ov-metric">
              <div className="pve-ov-metric-hdr"><span>Disk (/)</span><b style={{ color: ov.diskColor }}>{ov.diskPct}%</b></div>
              <div className="pve-ov-track" style={{ marginTop: 10 }}><div className="pve-ov-track-fill" style={{ width: `${ov.diskPct}%`, background: ov.diskColor }} /></div>
              <div className="pve-ov-metric-sub">{ov.diskUsed} / {ov.diskTotal}</div>
            </div>
            <div className="pve-ov-metric">
              <div className="pve-ov-metric-hdr">
                <span>Backup ({ov.bupLabel || data.backupMount || "—"})</span>
                <b style={{ color: ov.bupColor }}>{ov.bupPct != null ? `${ov.bupPct}%` : "—"}</b>
              </div>
              {ov.bupPct != null ? (
                <>
                  <div className="pve-ov-track" style={{ marginTop: 10 }}><div className="pve-ov-track-fill" style={{ width: `${ov.bupPct}%`, background: ov.bupColor }} /></div>
                  <div className="pve-ov-metric-sub">{ov.bupUsed} / {ov.bupTotal}</div>
                </>
              ) : (
                <div className="pve-ov-metric-sub" style={{ marginTop: 10 }}>{ov.bupNote || "Drive not mounted"}</div>
              )}
            </div>
            <div className="pve-ov-metric pve-ov-metric--system">
              <div className="pve-ov-metric-hdr">
                <span>System</span>
                <span className="pve-ov-update-badge" style={{ background: `${ov.updateColor}18`, borderColor: `${ov.updateColor}40`, color: ov.updateColor }}>
                  {ov.updateLabel}
                </span>
              </div>
              <div className="pve-ov-system-body">
                <div className="pve-ov-system-kv">
                  <span>Kernel</span>
                  <b>
                    {ov.kernelVersion}
                    {ov.hasKernelUpdate ? <i className="pve-ov-kernel-tag"> kernel update</i> : null}
                  </b>
                </div>
                {ov.updateCount > 0 ? (
                  <div className="pve-ov-pkg-col">
                    <span>Pending packages</span>
                    <div className="pve-ov-pkg-list">
                      {updates.slice(0, 8).map((u, i) => {
                        const pkg = u.Package || u.name || "unknown";
                        const ver = u.Version || u.NewVersion || "";
                        return (
                          <div className="pve-ov-pkg-row" key={`${pkg}-${i}`}>
                            <span title={pkg}>{pkg}</span>
                            {ver ? <b>{ver}</b> : null}
                          </div>
                        );
                      })}
                      {ov.updateCount > 8 ? <div className="pve-ov-pkg-more">+{ov.updateCount - 8} more</div> : null}
                    </div>
                  </div>
                ) : null}
              </div>
            </div>
          </div>
        </section>

        {topProcs.length ? (
          <section className="pve-ov-list-card pve-ov-list-card--fill">
            <div className="pve-ov-pane-hdr">Top Processes</div>
            <div className="pve-ov-procs">
              <div className="pve-ov-proc-head"><span>Process</span><span>CPU</span><span>Mem</span></div>
              {topProcs.map((p, i) => (
                <div className="pve-ov-proc-row" key={`${p.name}-${i}`}>
                  <span className="pve-ov-proc-name" title={p.cmdline || p.name}>{p.name || "?"}</span>
                  <span className="pve-ov-proc-cpu">{(p.cpu_percent || 0).toFixed(1)}%</span>
                  <span className="pve-ov-proc-mem">{(p.memory_percent || 0).toFixed(1)}%</span>
                </div>
              ))}
            </div>
          </section>
        ) : null}
      </div>
    </div>
  );
}

function Kpi({ label, value, color, sub }: { label: string; value: string; color: string; sub?: string }) {
  return (
    <div className="pve-ov-kpi">
      <div className="pve-ov-kpi-val"><span style={{ color }}>{value}</span></div>
      <div className="pve-ov-kpi-label">{label}</div>
      {sub ? <div className="pve-ov-kpi-sub">{sub}</div> : null}
    </div>
  );
}

function tempColor(deg: number) {
  if (deg >= 85) return "#f87171";
  if (deg >= 70) return "#fbbf24";
  return "#6ee7b7";
}
