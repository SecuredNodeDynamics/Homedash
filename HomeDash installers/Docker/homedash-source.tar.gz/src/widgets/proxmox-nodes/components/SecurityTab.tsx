"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import type { SecurityBlock } from "../types";
import { RingGauge } from "./Charts";
import { buildSecurityPdf, downloadPdf, pdfFileName, type PdfFinding } from "@/lib/widgets/proxmox/pdf-report";

type Rec = Record<string, unknown>;
type Pane = "overview" | "checks" | "warnings" | "suggestions";
type Filter = "all" | "action" | "expected";

const LOCAL_PREFIX = "hd:pve-lynis:";
const SCAN_POLL_MS = 5_000;
const SCAN_MAX_MS = 5 * 60_000;

function unwrapReport(raw: unknown): Rec | undefined {
  if (!raw || typeof raw !== "object") return undefined;
  const wrap = raw as Rec;
  const inner = "report" in wrap ? wrap.report : wrap;
  return inner && typeof inner === "object" ? (inner as Rec) : undefined;
}

function firstNum(r: Rec | undefined, keys: string[]): number | null {
  if (!r) return null;
  for (const k of keys) {
    const v = r[k];
    if (v != null && v !== "" && Number.isFinite(Number(v))) return Number(v);
  }
  return null;
}
const IDX_KEYS = ["hardening_index", "hardening", "lynis_hardening_index"];
const TEST_KEYS = ["tests_performed", "tests_executed", "lynis_tests_done", "tests_done", "total_tests"];

/** Finished audit: Lynis only writes the hardening index / test count at the end of a run. */
function complete(report: Rec | undefined): boolean {
  if (!report) return false;
  const tests = firstNum(report, TEST_KEYS);
  return firstNum(report, IDX_KEYS) != null || (tests != null && tests > 0);
}

/** Any audit content at all (possibly a half-written partial report). */
function usable(report: Rec | undefined): boolean {
  if (!report) return false;
  const n = (v: unknown) => (Array.isArray(v) ? v.length : 0);
  return complete(report) || n(report.sections) > 0 || n(report.warnings) > 0 || n(report.suggestions) > 0;
}

// eslint-disable-next-line no-control-regex
const ANSI_RE = /(?:\u001b)?\[[0-9;]*[A-Za-z]/g;
/** `lynis --version` can return colored warning text; pull out just the version number. */
function cleanVersion(v: unknown): string {
  const text = String(v ?? "").replace(ANSI_RE, "");
  const all = text.match(/\d+\.\d+(?:\.\d+)?/g);
  return all ? all[all.length - 1] : "—";
}
function pidWarning(v: unknown): boolean {
  return /PID file exists|another Lynis process/i.test(String(v ?? ""));
}
function plural(n: number, one: string, many = `${one}s`) {
  return `${n} ${n === 1 ? one : many}`;
}

function pickLynisTools(security: SecurityBlock | null | undefined): Rec | undefined {
  const t = security?.tools as { tools?: { lynis?: Rec }; lynis?: Rec } | null | undefined;
  return t?.tools?.lynis || t?.lynis;
}

function fmtStamp(val: unknown) {
  if (!val) return "Never";
  return String(val).replace("T", " ").substring(0, 16);
}

function ago(val: unknown) {
  const ms = typeof val === "number" ? val : Date.parse(String(val || "").replace(" ", "T"));
  if (!Number.isFinite(ms)) return "";
  const s = Math.max(0, (Date.now() - ms) / 1000);
  if (s < 90) return "just now";
  if (s < 3600) return `${Math.round(s / 60)} min ago`;
  if (s < 86400) return `${Math.round(s / 3600)} h ago`;
  return `${Math.round(s / 86400)} d ago`;
}

function toneFor(score: number | null) {
  if (score == null || !Number.isFinite(score)) return "muted" as const;
  return score >= 70 ? ("good" as const) : score >= 50 ? ("warn" as const) : ("bad" as const);
}
const TONE_COLOR = { good: "#22c55e", warn: "#eab308", bad: "#ef4444", muted: "#64748b" } as const;
const TONE_LABEL = { good: "Good", warn: "Moderate", bad: "Critical", muted: "No score" } as const;

function ShieldIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M12 3l8 3v6c0 4.5-3.2 8.2-8 9-4.8-.8-8-4.5-8-9V6l8-3z" />
      <path d="M8.5 12l2.5 2.5 4.5-5" />
    </svg>
  );
}

export function SecurityTab({
  security,
  prxConfigured,
  instanceId,
  nodeName,
  iconUrl,
  onRefresh,
  onInstallLynis,
  onConfigurePrx,
}: {
  security: SecurityBlock | null;
  prxConfigured: boolean;
  instanceId: string;
  /** Proxmox node this tab belongs to — used to label the exported PDF. */
  nodeName?: string;
  iconUrl?: string;
  onRefresh: () => void;
  onInstallLynis: () => void;
  onConfigurePrx: () => void;
}) {
  const [pane, setPane] = useState<Pane>("overview");
  const [filter, setFilter] = useState<Filter>("all");
  const [expanded, setExpanded] = useState(true);
  const [busy, setBusy] = useState("");
  const [message, setMessage] = useState<{ tone: "ok" | "err"; text: string } | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [imgOk, setImgOk] = useState(true);
  const [openSection, setOpenSection] = useState<number | null>(null);
  const [scanFrom, setScanFrom] = useState<{ stamp: string; at: number } | null>(null);
  const [local, setLocal] = useState<{ tools?: Rec; report?: Rec; at?: number } | null>(null);
  const refreshRef = useRef(onRefresh);
  refreshRef.current = onRefresh;

  // Browser-side backup copy (survives refresh/reboot even if the server file can't be written).
  useEffect(() => {
    try {
      const raw = localStorage.getItem(`${LOCAL_PREFIX}${instanceId}`);
      if (raw) setLocal(JSON.parse(raw));
    } catch {
      /* ignore */
    }
  }, [instanceId]);

  const liveTools = pickLynisTools(security);
  const serverReport = unwrapReport(security?.report);
  const serverComplete = complete(serverReport);
  const liveToolsOk = Boolean(liveTools?.installed);
  const freshComplete = serverComplete && !security?.stale;

  useEffect(() => {
    if (!freshComplete && !liveToolsOk) return;
    try {
      const next = {
        tools: liveToolsOk ? liveTools : local?.tools,
        report: freshComplete ? serverReport : local?.report,
        at: freshComplete ? Date.now() : local?.at,
      };
      localStorage.setItem(`${LOCAL_PREFIX}${instanceId}`, JSON.stringify(next));
    } catch {
      /* quota / private mode */
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [freshComplete, liveToolsOk, security?.report, security?.tools, instanceId]);

  const tools = liveToolsOk ? liveTools : local?.tools?.installed ? local.tools : liveTools;
  const localComplete = complete(local?.report);
  const report: Rec | undefined = serverComplete
    ? serverReport
    : localComplete
      ? local?.report
      : usable(serverReport)
        ? serverReport
        : undefined;
  const isPartial = Boolean(report) && !complete(report);
  const isSaved = Boolean(report) && !isPartial && !freshComplete;
  const savedAt = isSaved ? (serverComplete ? security?.savedAt : undefined) || local?.at : undefined;
  const lastScanRaw = tools?.last_scan || report?.datetime_start;
  const version = cleanVersion(tools?.version ?? report?.lynis_version);
  const pidBusy = pidWarning(tools?.version);

  // After "Run Audit": poll until Lynis reports a newer scan (or give up).
  useEffect(() => {
    if (!scanFrom) return;
    const timer = setInterval(() => {
      if (Date.now() - scanFrom.at > SCAN_MAX_MS) {
        setScanFrom(null);
        return;
      }
      refreshRef.current();
    }, SCAN_POLL_MS);
    return () => clearInterval(timer);
  }, [scanFrom]);
  useEffect(() => {
    if (scanFrom && String(lastScanRaw || "") !== scanFrom.stamp) {
      setScanFrom(null);
      setMessage(
        complete(report)
          ? { tone: "ok", text: "Audit finished" }
          : { tone: "err", text: "The scan finished but ProxMenux returned no score yet — try Run Audit again in a minute." },
      );
    }
  }, [lastScanRaw, report, scanFrom]);

  const warnings = useMemo(() => (report?.warnings as Rec[] | undefined) || [], [report]);
  const suggestions = useMemo(() => (report?.suggestions as Rec[] | undefined) || [], [report]);
  const sections = useMemo(() => (report?.sections as Rec[] | undefined) || [], [report]);

  if (!prxConfigured) {
    return (
      <div className="pve-sec-tab">
        <div className="pve-sec-empty-block">
          Configure ProxMenux URL and API key to use Lynis security scans.
          <div style={{ marginTop: 10 }}>
            <button type="button" className="prx-open-link prx-open-link--prx" onClick={onConfigurePrx}>
              Add MONITOR token
            </button>
          </div>
        </div>
      </div>
    );
  }

  async function run(kind: "lynis-run" | "lynis-report-delete") {
    setBusy(kind);
    setMessage(null);
    try {
      const response = await fetch("/api/widgets/proxmox-nodes/proxmenux", {
        method: kind === "lynis-report-delete" ? "DELETE" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          instance: instanceId,
          kind: kind === "lynis-report-delete" ? "lynis-report" : "lynis-run",
        }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Request failed");
      if (kind === "lynis-run") {
        setScanFrom({ stamp: String(lastScanRaw || ""), at: Date.now() });
      } else {
        try {
          const raw = localStorage.getItem(`${LOCAL_PREFIX}${instanceId}`);
          const prev = raw ? JSON.parse(raw) : {};
          localStorage.setItem(`${LOCAL_PREFIX}${instanceId}`, JSON.stringify({ ...prev, report: null }));
        } catch {
          /* ignore */
        }
        setLocal((p) => (p ? { ...p, report: undefined } : p));
        setConfirmDelete(false);
        setMessage({ tone: "ok", text: "Report deleted" });
      }
      onRefresh();
    } catch (error) {
      setMessage({ tone: "err", text: error instanceof Error ? error.message : "Security action failed" });
    } finally {
      setBusy("");
    }
  }

  const installed = Boolean(tools?.installed);
  const rawN = firstNum(report, IDX_KEYS) ?? (tools?.hardening_index != null && Number.isFinite(Number(tools.hardening_index)) ? Number(tools.hardening_index) : null);
  const adjN = report?.proxmox_adjusted_score != null && Number.isFinite(Number(report.proxmox_adjusted_score))
    ? Number(report.proxmox_adjusted_score) : rawN;
  const adj = adjN;
  const rawScore = rawN;
  const tone = toneFor(adj);
  const expW = Number(report?.proxmox_expected_warnings) || 0;
  const expS = Number(report?.proxmox_expected_suggestions) || 0;
  const warnAction = Math.max(0, warnings.length - expW);
  const sugAction = Math.max(0, suggestions.length - expS);
  const lastScan = fmtStamp(lastScanRaw);
  const sectionChecks = sections.reduce((n, sec) => n + (((sec.checks as Rec[] | undefined) || []).length), 0);
  const testsN = firstNum(report, TEST_KEYS);
  const testsShown = testsN != null && testsN > 0 ? String(testsN) : sectionChecks > 0 ? String(sectionChecks) : "—";
  const scanning = scanFrom != null || busy === "lynis-run";

  const header = (
    <div className="pve-sec-hdr">
      <div className="pve-sec-hdr-left">
        <div>
          <div className="pve-sec-title">Lynis Security Audit</div>
          <div className="pve-sec-sub">System security auditing tool that performs comprehensive security scans</div>
        </div>
      </div>
    </div>
  );

  const logo = (statusTone: keyof typeof TONE_COLOR) => (
    <div className="pve-sec2-logo" style={{ borderColor: `${TONE_COLOR[statusTone]}66` }}>
      {iconUrl && imgOk ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={iconUrl} alt="" onError={() => setImgOk(false)} />
      ) : (
        <ShieldIcon size={22} />
      )}
      <span className="pve-sec2-logo-badge" style={{ background: TONE_COLOR[statusTone] }}>
        <ShieldIcon size={10} />
      </span>
    </div>
  );

  if (!installed) {
    return (
      <div className="pve-sec-tab">
        {header}
        <div className="pve-sec-status">
          <div className="pve-sec-status-left">
            {logo("muted")}
            <div>
              <div className="pve-sec-status-title">Lynis Not Installed</div>
              <div className="pve-sec-status-sub">Comprehensive security auditing and hardening tool</div>
            </div>
          </div>
        </div>
        <div className="pve-sec-info">
          <div className="pve-sec-info-title">Lynis features:</div>
          <ul>
            <li>System hardening scoring (0–100)</li>
            <li>Vulnerability detection and suggestions</li>
            <li>Compliance checking (PCI-DSS, HIPAA, etc.)</li>
            <li>Installed from latest GitHub source via ProxMenux</li>
          </ul>
        </div>
        <button type="button" className="pve-sec-run" onClick={onInstallLynis}>Install Lynis</button>
      </div>
    );
  }

  const shownFindings = (pane === "warnings" ? warnings : suggestions).filter((f) =>
    filter === "all" ? true : filter === "expected" ? Boolean(f.proxmox_expected) : !f.proxmox_expected,
  );
  const topActions = warnings.filter((w) => !w.proxmox_expected).slice(0, 3);

  /** Build and download a PDF report for THIS node's audit (no print dialog, no other widgets). */
  function exportPdf() {
    if (!report) return;
    try {
      const toFinding = (f: Rec): PdfFinding => ({
        testId: String(f.test_id || ""),
        description: String(f.description || ""),
        context: f.proxmox_context ? String(f.proxmox_context) : undefined,
        solution: f.solution ? String(f.solution) : undefined,
        expected: Boolean(f.proxmox_expected),
      });
      const now = new Date();
      const node = String(nodeName || report.hostname || "").trim() || "proxmox-node";
      const bytes = buildSecurityPdf({
        node,
        hostname: String(report.hostname || ""),
        os: `${String(report.os_name || "")} ${String(report.os_version || "")}`.trim(),
        kernel: String(report.kernel_version || ""),
        lynisVersion: version === "—" ? "" : version,
        scanTime: fmtStamp(report.datetime_start || tools?.last_scan),
        generatedAt: now,
        score: adj,
        rawScore,
        tone,
        toneLabel: TONE_LABEL[tone],
        warnings: warnings.map(toFinding),
        suggestions: suggestions.map(toFinding),
        testsRun: testsShown,
        sections: sections.map((sec, i) => ({
          name: String(sec.name || `Section ${i + 1}`),
          checks: ((sec.checks as Rec[] | undefined) || []).map((c) => String(c.name || "")),
        })),
        firewallActive: Boolean(report.firewall_active),
        malwareScanner: Boolean(report.malware_scanner),
        savedCopy: isSaved,
        partial: isPartial,
      });
      const file = pdfFileName(node, now);
      downloadPdf(bytes, file);
      setMessage({ tone: "ok", text: `PDF saved: ${file}` });
    } catch (error) {
      setMessage({ tone: "err", text: error instanceof Error ? `PDF export failed: ${error.message}` : "PDF export failed" });
    }
  }

  const stat = (label: string, value: string, sub: string, t: keyof typeof TONE_COLOR) => (
    <div className="pve-sec2-stat">
      <span>{label}</span>
      <b style={{ color: TONE_COLOR[t] }}>{value}</b>
      <small>{sub}</small>
    </div>
  );

  return (
    <div className="pve-sec-tab">
      {header}

      <div className="pve-sec-status">
        <div className="pve-sec-status-left">
          {logo(report ? tone : "muted")}
          <div>
            <div className="pve-sec-status-title">Lynis Installed</div>
            <div className="pve-sec-status-sub">
              v{version} · Last scan: {lastScan}
              {ago(lastScanRaw) ? ` (${ago(lastScanRaw)})` : ""}
            </div>
          </div>
        </div>
        <div className="pve-sec-actions">
          <button type="button" className="pve-sec-run" disabled={scanning} onClick={() => run("lynis-run")}>
            {scanning ? "Scanning…" : "Run Audit"}
          </button>
        </div>
      </div>

      {scanning ? (
        <div className="pve-sec-progress">
          <span className="pve-sec-spinner" />
          <div>
            <div className="pve-sec-progress-title">Audit running</div>
            <div className="pve-sec-progress-sub">
              Lynis usually takes 1–3 minutes. The previous report stays visible until the new one is ready.
            </div>
          </div>
          <button type="button" className="pve-sec2-link" style={{ marginLeft: "auto" }} onClick={() => setScanFrom(null)}>
            Dismiss
          </button>
        </div>
      ) : null}

      {message ? (
        <div className={`pve-sec-banner pve-sec-banner--${message.tone === "ok" ? "ok" : "err"}`}>{message.text}</div>
      ) : null}

      {isSaved ? (
        <div className="pve-sec2-saved">
          Showing the saved report{savedAt ? ` from ${fmtStamp(new Date(savedAt).toISOString())}` : ""} — ProxMenux
          did not return a fresh one. It reloads automatically when it does.
        </div>
      ) : null}

      {pidBusy ? (
        <div className="pve-sec2-saved">
          Lynis says another scan is already running on this node (or left a stale PID file). Wait a few minutes before
          starting a new audit; if it never clears, delete the Lynis PID file on the node.
        </div>
      ) : null}

      {isPartial ? (
        <div className="pve-sec2-saved">
          Incomplete report — the audit is probably still running. The score, test count and final results fill in when it
          finishes{scanning ? "" : "; press Run Audit if no scan is running"}.
        </div>
      ) : null}

      {report ? (
        <>
          <div className="pve-sec2-hero">
            <div className="pve-sec2-ring">
              <RingGauge pct={adj ?? 0} color={TONE_COLOR[tone]} size={112} showLabel={false} />
              <div className="pve-sec2-ring-center">
                {adj != null ? (
                  <>
                    <b style={{ color: TONE_COLOR[tone] }}>{adj}</b>
                    <span>/100</span>
                  </>
                ) : (
                  <b style={{ color: TONE_COLOR.muted }}>—</b>
                )}
              </div>
            </div>
            <div className="pve-sec2-hero-main">
              <div className="pve-sec2-grade" style={{ color: TONE_COLOR[tone] }}>
                {adj != null ? TONE_LABEL[tone] : isPartial ? "Score pending" : "No score reported"}
              </div>
              <div className="pve-sec2-grade-sub">
                {adj == null
                  ? isPartial
                    ? "This report is incomplete — Lynis adds the score when the audit finishes."
                    : "ProxMenux did not include a hardening index in this report."
                  : "Security hardening score"}{rawScore != null && adj != null && rawScore !== adj ? ` (Proxmox adjusted — Lynis raw ${rawScore})` : ""}
              </div>
              <div className="pve-sec2-scale" aria-hidden>
                <i className="z-bad" /><i className="z-warn" /><i className="z-good" />
                {adj != null ? <em style={{ left: `${Math.max(1, Math.min(99, adj))}%` }} /> : null}
              </div>
              <div className="pve-sec-bar-legend">
                <span>Critical 0–49</span><span>Moderate 50–69</span><span>Good 70–100</span>
              </div>
            </div>
          </div>

          <div className="pve-sec2-stats">
            {stat("Warnings", String(warnAction), expW > 0 ? `${warnings.length} total · ${expW} PVE expected` : `${warnings.length} total`, warnAction > 0 ? "bad" : "good")}
            {stat("Suggestions", String(sugAction), expS > 0 ? `${suggestions.length} total · ${expS} PVE expected` : `${suggestions.length} total`, sugAction > 0 ? "warn" : "good")}
            {stat("Tests run", testsShown, plural(sections.length, "section"), "muted")}
            {stat("Firewall", report.firewall_active ? "Active" : "Inactive", report.malware_scanner ? "Malware scanner present" : "No malware scanner", report.firewall_active ? "good" : "bad")}
          </div>

          <div className="pve-sec-reports">
            <div className="pve-sec-reports-label">Audit Report</div>
            <div className="pve-sec-report">
              <div
                className="pve-sec-report-main"
                role="button"
                tabIndex={0}
                onClick={() => setExpanded((v) => !v)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") setExpanded((v) => !v);
                }}
              >
                <div className="pve-sec-report-left">
                  <div>
                    <div className="pve-sec-report-title">
                      Security Audit — {fmtStamp(report.datetime_start || tools?.last_scan)}
                    </div>
                    <div className="pve-sec-report-sub">
                      {String(report.hostname || "System")} · {testsShown === "—" ? "tests n/a" : plural(Number(testsShown), "test")} · {plural(warnAction, "actionable warning")} · {plural(sugAction, "suggestion")}
                    </div>
                  </div>
                </div>
                <div className="pve-sec-report-actions">
                  <button
                    type="button"
                    className="pve-sec-pdf"
                    title={`Download PDF report for ${String(nodeName || report.hostname || "this node")}`}
                    onClick={(e) => {
                      e.stopPropagation();
                      exportPdf();
                    }}
                  >
                    PDF
                  </button>
                  <span className={`pve-sec-chevron${expanded ? " is-open" : ""}`} aria-hidden>▾</span>
                  {confirmDelete ? (
                    <>
                      <button
                        type="button"
                        className="pve-sec-del pve-sec2-del-yes"
                        disabled={!!busy}
                        onClick={(e) => {
                          e.stopPropagation();
                          run("lynis-report-delete");
                        }}
                      >
                        Delete?
                      </button>
                      <button
                        type="button"
                        className="pve-sec-pdf"
                        onClick={(e) => {
                          e.stopPropagation();
                          setConfirmDelete(false);
                        }}
                      >
                        Keep
                      </button>
                    </>
                  ) : (
                    <button
                      type="button"
                      className="pve-sec-del"
                      title="Delete report"
                      disabled={!!busy}
                      onClick={(e) => {
                        e.stopPropagation();
                        setConfirmDelete(true);
                      }}
                    >
                      ✕
                    </button>
                  )}
                </div>
              </div>

              {expanded ? (
                <div className="pve-sec-expand">
                  <div className="pve-sec-rpanes" role="tablist">
                    {([
                      ["overview", "Overview", null],
                      ["checks", "Checks", sections.length],
                      ["warnings", "Warnings", warnings.length],
                      ["suggestions", "Suggestions", suggestions.length],
                    ] as const).map(([key, label, count]) => (
                      <button
                        key={key}
                        type="button"
                        role="tab"
                        aria-selected={pane === key}
                        className={`pve-sec-rpane${pane === key ? " pve-sec-rpane--active" : ""}`}
                        onClick={() => {
                          setPane(key);
                          setFilter("all");
                        }}
                      >
                        {label}
                        {count != null ? <span className="pve-sec2-count">{count}</span> : null}
                      </button>
                    ))}
                  </div>
                  <div className="pve-sec-rbody">
                    {pane === "overview" ? (
                      <>
                        {topActions.length ? (
                          <div className="pve-sec2-attn">
                            <div className="pve-sec2-h">Needs attention</div>
                            {topActions.map((w, i) => (
                              <div className="pve-sec2-attn-row" key={i}>
                                <span className="pve-sec-finding-id">{String(w.test_id || "")}</span>
                                <span>{String(w.description || "")}</span>
                              </div>
                            ))}
                            {warnAction > topActions.length ? (
                              <button type="button" className="pve-sec2-link" onClick={() => { setPane("warnings"); setFilter("action"); }}>
                                See all {warnAction} actionable warnings →
                              </button>
                            ) : null}
                          </div>
                        ) : (
                          <div className="pve-sec2-allgood"><ShieldIcon size={16} /> No actionable warnings in this audit.</div>
                        )}
                        <div className="pve-sec2-h">System</div>
                        <div className="pve-sec-ov-grid">
                          <div className="pve-sec-ov"><span>Host</span><b>{String(report.hostname || "—")}</b></div>
                          <div className="pve-sec-ov"><span>OS</span><b>{`${String(report.os_name || "")} ${String(report.os_version || "")}`.trim() || "—"}</b></div>
                          <div className="pve-sec-ov"><span>Kernel</span><b>{String(report.kernel_version || "—")}</b></div>
                          <div className="pve-sec-ov"><span>Lynis</span><b>v{version}</b></div>
                          <div className="pve-sec-ov"><span>Firewall</span><b className={report.firewall_active ? "pve-sec-score--good" : "pve-sec-score--bad"}>{report.firewall_active ? "Active" : "Inactive"}</b></div>
                          <div className="pve-sec-ov"><span>Malware scanner</span><b className={report.malware_scanner ? "pve-sec-score--good" : "pve-sec-score--warn"}>{report.malware_scanner ? "Present" : "Missing"}</b></div>
                        </div>
                      </>
                    ) : null}

                    {pane === "checks" ? (
                      <div className="pve-sec-list">
                        {sections.length ? sections.map((section, i) => {
                          const checks = (section.checks as Rec[] | undefined) || [];
                          const open = openSection === i;
                          return (
                            <div className="pve-sec-check" key={i}>
                              <button type="button" className="pve-sec2-sec-btn" onClick={() => setOpenSection(open ? null : i)}>
                                <span className="pve-sec-check-name">{String(section.name || `Section ${i + 1}`)}</span>
                                <span className="pve-sec-check-meta">{checks.length} checks <span className={`pve-sec-chevron${open ? " is-open" : ""}`}>▾</span></span>
                              </button>
                              {open ? (
                                <ul className="pve-sec2-checks">
                                  {checks.map((c, j) => <li key={j}>{String(c.name || "")}</li>)}
                                </ul>
                              ) : null}
                            </div>
                          );
                        }) : <div className="pve-sec-empty">No check sections available</div>}
                      </div>
                    ) : null}

                    {pane === "warnings" || pane === "suggestions" ? (
                      <>
                        <div className="pve-sec2-filter">
                          {([["all", "All"], ["action", "Actionable"], ["expected", "PVE expected"]] as const).map(([k, l]) => (
                            <button key={k} type="button" className={filter === k ? "is-on" : ""} onClick={() => setFilter(k)}>{l}</button>
                          ))}
                        </div>
                        <div className="pve-sec-list">
                          {shownFindings.map((item, i) => (
                            <div key={i} className={`pve-sec-finding ${item.proxmox_expected ? "is-expected" : "is-action"}`}>
                              <div className="pve-sec-finding-top">
                                <span className="pve-sec-finding-id">{String(item.test_id || "")}</span>
                                <span className={`pve-sec-tag${item.proxmox_expected ? "" : " pve-sec-tag--warn"}`}>
                                  {item.proxmox_expected ? "PVE expected" : "Actionable"}
                                </span>
                              </div>
                              <div className="pve-sec-finding-title">{String(item.description || "")}</div>
                              {item.proxmox_context ? <div className="pve-sec-finding-ctx">{String(item.proxmox_context)}</div> : null}
                              {item.solution ? <div className="pve-sec-finding-sol">Solution: {String(item.solution)}</div> : null}
                            </div>
                          ))}
                          {!shownFindings.length ? <div className="pve-sec-empty">None</div> : null}
                        </div>
                      </>
                    ) : null}
                  </div>
                </div>
              ) : null}
            </div>
          </div>
        </>
      ) : (
        <div className="pve-sec-empty-block">
          {lastScanRaw
            ? "The last scan didn't return any report data. Run the audit again to generate one."
            : "No audit report yet — run Lynis to generate one."}
        </div>
      )}
    </div>
  );
}
