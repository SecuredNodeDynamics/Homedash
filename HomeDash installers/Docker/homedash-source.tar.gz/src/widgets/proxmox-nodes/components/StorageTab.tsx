"use client";

import { useState } from "react";
import { RingGauge, MiniBar } from "./Charts";
import { fmtBytes, pctColor, type StatusPayload } from "../types";

const SF_LOCAL = "#22d3ee";
const SF_REMOTE = "#6ee7b7";

const KIND_COLOR: Record<string, string> = {
  nvme: "#67e8f9",
  usb: "#fbbf24",
  ssd: "#22d3ee",
  hdd: "#94a3b8",
  disk: "#64748b",
};

export function StorageTab({
  data,
  onOpenDisk,
}: {
  data: StatusPayload;
  onOpenDisk: (disk: Record<string, unknown>) => void;
}) {
  const [sub, setSub] = useState<"pve" | "remote" | "physical" | "external">("pve");
  const storage = data.storage || { stores: [], disks: [], remoteMounts: [] };
  const stores = Array.isArray(storage.stores) ? storage.stores : [];
  const disks = Array.isArray(storage.disks) ? storage.disks : [];
  const remotes = Array.isArray(storage.remoteMounts) ? storage.remoteMounts : [];
  const localStores = stores.filter((s) => !isRemote(s));
  const remoteStores = stores.filter((s) => isRemote(s));
  const external = disks.filter((d) => isUsbDisk(d));
  const physical = disks.filter((d) => !isUsbDisk(d));

  const sum = (list: Array<Record<string, unknown>>, key: string) =>
    list.reduce((acc, s) => acc + (Number(s[key]) || 0), 0);
  const localUsed = sum(localStores, "used");
  const localTotal = sum(localStores, "total");
  const localFree = Math.max(0, localTotal - localUsed) || sum(localStores, "avail");
  const remoteUsed = sum(remoteStores, "used");
  const remoteTotal = sum(remoteStores, "total");
  const allUsed = localUsed + remoteUsed;
  const allTotal = localTotal + remoteTotal;
  const allFree = Math.max(0, allTotal - allUsed);
  const localPct = localTotal > 0 ? (localUsed / localTotal) * 100 : 0;
  const usedShare = allTotal > 0 ? (localUsed / allTotal) * 100 : 0;
  const remoteShare = allTotal > 0 ? (remoteUsed / allTotal) * 100 : 0;
  const freeShare = allTotal > 0 ? (allFree / allTotal) * 100 : 0;

  const kindCounts: Record<string, number> = {};
  for (const d of disks) {
    const kind = classifyDisk(d);
    kindCounts[kind] = (kindCounts[kind] || 0) + 1;
  }
  const diskEntries = Object.entries(kindCounts);
  const diskTotal = diskEntries.reduce((a, [, n]) => a + n, 0) || disks.length;
  const unhealthy = disks.filter((d) => {
    const h = String(d?.health || "").toUpperCase();
    return h && h !== "PASSED" && h !== "OK" && h !== "UNKNOWN";
  }).length;

  return (
    <div className="pve-storage-tab">
      <div className="pve-st-summary">
        <div className="pve-st-card">
          <div className="pve-st-card-hdr">
            <span>Storage Used</span>
            <span className="pve-st-card-badge">{stores.length} store{stores.length === 1 ? "" : "s"}</span>
          </div>
          <div className="pve-st-card-big">{fmtBytes(allUsed)}</div>
          <div className="pve-st-stack">
            {allTotal > 0 ? (
              <>
                <div className="pve-st-seg pve-st-seg--local" style={{ width: `${usedShare}%` }} />
                <div className="pve-st-seg pve-st-seg--remote" style={{ width: `${remoteShare}%` }} />
                <div className="pve-st-seg pve-st-seg--free" style={{ width: `${freeShare}%` }} />
              </>
            ) : (
              <div className="pve-st-seg pve-st-seg--empty" style={{ width: "100%" }} />
            )}
          </div>
          <div className="pve-st-legend">
            <span className="pve-st-legend-item"><i className="pve-st-dot pve-st-dot--local" />Local {fmtBytes(localUsed)}</span>
            <span className="pve-st-legend-item"><i className="pve-st-dot pve-st-dot--remote" />Remote {fmtBytes(remoteUsed)}</span>
            <span className="pve-st-legend-item"><i className="pve-st-dot pve-st-dot--free" />Free {fmtBytes(allFree)}</span>
          </div>
        </div>

        <div className="pve-st-card pve-st-card--split">
          <div className="pve-st-card-hdr"><span>Local Used</span></div>
          <div className="pve-st-card-body">
            <RingGauge pct={localPct} color={pctColor(localPct)} />
            <div className="pve-st-card-stats">
              <div className="pve-st-mini"><span>Used</span><b className="pve-st-mini--used">{fmtBytes(localUsed)}</b><MiniBar pct={localPct} color={SF_REMOTE} /></div>
              <div className="pve-st-mini"><span>Free</span><b className="pve-st-mini--free">{fmtBytes(localFree)}</b><MiniBar pct={localTotal > 0 ? (localFree / localTotal) * 100 : 0} color={SF_LOCAL} /></div>
              <div className="pve-st-mini"><span>Total</span><b>{fmtBytes(localTotal)}</b></div>
            </div>
          </div>
        </div>

        <div className="pve-st-card">
          <div className="pve-st-card-hdr"><span>Remote Used</span></div>
          {remoteStores.length ? (
            <>
              <div className="pve-st-card-big">{fmtBytes(remoteUsed)}</div>
              <div className="pve-st-card-sub">{remoteStores.length} remote · {fmtBytes(remoteTotal)} total</div>
            </>
          ) : (
            <>
              <div className="pve-st-card-big pve-st-card-big--muted">None</div>
              <div className="pve-st-card-sub">No remote storage</div>
            </>
          )}
        </div>

        <div className="pve-st-card">
          <div className="pve-st-card-hdr">
            <span>Physical Disks</span>
            {diskTotal ? (
              unhealthy
                ? <span className="pve-st-health pve-st-health--warn">{unhealthy} issue{unhealthy === 1 ? "" : "s"}</span>
                : <span className="pve-st-health pve-st-health--ok">✔ all healthy</span>
            ) : null}
          </div>
          <div className="pve-st-card-big">{diskTotal} disk{diskTotal === 1 ? "" : "s"}</div>
          <div className="pve-st-stack">
            {diskEntries.length ? diskEntries.map(([k, n]) => (
              <div
                key={k}
                className="pve-st-seg"
                style={{
                  width: `${diskTotal > 0 ? (n / diskTotal) * 100 : 0}%`,
                  background: KIND_COLOR[k] || KIND_COLOR.disk,
                }}
              />
            )) : (
              <div className="pve-st-seg pve-st-seg--empty" style={{ width: "100%" }} />
            )}
          </div>
          <div className="pve-st-legend">
            {diskEntries.length ? diskEntries.map(([k, n]) => (
              <span className="pve-st-legend-item" key={k}>
                <i className="pve-st-dot" style={{ background: KIND_COLOR[k] || KIND_COLOR.disk }} />
                {n} {diskKindLabel(k)}
              </span>
            )) : <span className="pve-st-legend-item muted">No disks reported</span>}
          </div>
        </div>
      </div>

      <div className="pve-st-list-card">
        <div className="pve-st-subtabs" role="tablist">
          {([
            ["pve", "Proxmox Storage"],
            ["remote", "Remote Mounts"],
            ["physical", "Physical Disks"],
            ["external", "External Storage"],
          ] as const).map(([key, label]) => (
            <button
              key={key}
              type="button"
              className={`pve-st-subtab${sub === key ? " pve-st-subtab--active" : ""}`}
              onClick={() => setSub(key)}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="pve-st-subpane">
          {sub === "pve" || sub === "remote" ? (
            <>
              <div className="pve-st-pane-hdr">
                {sub === "pve" ? "Proxmox Storage" : "Remote Mounts"}
                <span className="pve-st-count">{sub === "pve" ? stores.length : remotes.length}</span>
              </div>
              <div className={sub === "remote" ? "pve-st-list pve-st-list--mounts" : "pve-st-list"}>
                {(sub === "pve" ? stores : remotes).map((store, i) => {
                  const name = String(store.storage || store.mnt_point || store.path || `store-${i}`);
                  const used = Number(store.used || 0);
                  const total = Number(store.total || store.size || 0);
                  const avail = Number(store.avail || Math.max(0, total - used));
                  const pct = total > 0 ? (used / total) * 100 : Number(store.used_fraction || 0) * 100;
                  const type = String(store.type || "dir");
                  const active = store.active === 1 || store.active === true || store.reachable === true;
                  if (sub === "remote") {
                    return (
                      <div className="pve-st-mount" key={`${name}-${i}`}>
                        <div className="pve-st-mount-main">
                          <i className="pve-st-dot" style={{ background: active || store.remote ? "#6ee7b7" : "#f87171" }} />
                          <div className="pve-st-mount-text">
                            <div className="pve-st-mount-path">
                              <span>{name}</span>
                              <span className="pve-st-type pve-st-type--remote">{type}</span>
                            </div>
                            <div className="pve-st-mount-src">
                              {store.device_name ? `Source: ${String(store.device_name)}` : `${fmtBytes(used)} / ${fmtBytes(total)}`}
                            </div>
                          </div>
                        </div>
                        <span className={`pve-st-active ${active ? "pve-st-active--on" : "pve-st-active--off"}`}>
                          {active ? "reachable" : "unreachable"}
                        </span>
                      </div>
                    );
                  }
                  return (
                    <div className="pve-st-row" key={`${name}-${i}`}>
                      <div className="pve-st-row-top">
                        <div className="pve-st-row-id">
                          <span className="pve-st-name">{name}</span>
                          <span className={`pve-st-type ${typeClass(type)}`}>{type}</span>
                        </div>
                        <div className="pve-st-row-meta">
                          <span className={`pve-st-active ${active ? "pve-st-active--on" : "pve-st-active--off"}`}>
                            {active ? "active" : "inactive"}
                          </span>
                          <span className="pve-st-pct" style={{ color: pctColor(pct) }}>{pct.toFixed(2)}%</span>
                        </div>
                      </div>
                      <div className="pve-st-track">
                        <div
                          className="pve-st-track-fill"
                          style={{ width: `${Math.min(100, pct)}%` }}
                        />
                      </div>
                      <div className="pve-st-stats">
                        <div className="pve-st-stat"><span>Total</span><b>{fmtBytes(total)}</b></div>
                        <div className="pve-st-stat"><span>Used</span><b className="pve-st-stat--used">{fmtBytes(used)}</b></div>
                        <div className="pve-st-stat"><span>Available</span><b className="pve-st-stat--free">{fmtBytes(avail)}</b></div>
                      </div>
                    </div>
                  );
                })}
                {!(sub === "pve" ? stores : remotes).length ? (
                  <div className="pve-st-empty">No {sub === "pve" ? "storage configured" : "remote mounts detected"}</div>
                ) : null}
              </div>
            </>
          ) : (
            <>
              <div className="pve-st-pane-hdr">
                {sub === "external" ? "External Storage (USB)" : "Physical Disks & SMART Status"}
                <span className="pve-st-count">{(sub === "external" ? external : physical).length}</span>
              </div>
              <div className="pve-st-disk-grid-wrap">
                {(sub === "external" ? external : physical).map((disk, i) => (
                  <DiskCard
                    key={String(disk.devpath || disk.name || i)}
                    disk={disk}
                    external={sub === "external"}
                    onOpen={onOpenDisk}
                  />
                ))}
                {!(sub === "external" ? external : physical).length ? (
                  <div className="pve-st-empty">
                    {sub === "external" ? "No USB storage detected" : "No physical disks reported"}
                  </div>
                ) : null}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function DiskCard({
  disk,
  external,
  onOpen,
}: {
  disk: Record<string, unknown>;
  external?: boolean;
  onOpen: (disk: Record<string, unknown>) => void;
}) {
  const kind = classifyDisk(disk);
  const info = diskSmartInfo(disk);
  const healthOk = /PASSED|OK|HEALTHY/i.test(info.health);
  const healthNa = !info.health || /UNKNOWN|N\/A|NONE/i.test(info.health);
  const wearPct = info.wear != null ? Math.max(0, Math.min(100, info.wear)) : null;
  const tempColor = info.temp == null ? undefined : (info.temp >= 60 ? "#f87171" : info.temp >= 50 ? "#fbbf24" : "#6ee7b7");
  const path = String(disk.devpath || disk.name || "—");
  const typeCls = kind === "nvme" ? "pve-st-type--zfs" : "pve-st-type--dir";

  return (
    <button type="button" className="pve-st-disk" title="Open disk details" onClick={() => onOpen(disk)}>
      <div className="pve-st-disk-top">
        <div className="pve-st-disk-id">
          <span className="pve-st-disk-path">{path}</span>
          {kind === "usb" || external ? (
            <span className="pve-st-type pve-st-type--remote">USB</span>
          ) : (
            <span className={`pve-st-type ${typeCls}`}>{diskKindLabel(kind)}</span>
          )}
          {info.isSystem ? (
            <span className="pve-st-type pve-st-type--remote">
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" aria-hidden>
                <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
                <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
              </svg>
              {" "}System
            </span>
          ) : null}
        </div>
        <div className={`pve-st-disk-health ${healthOk ? "is-ok" : healthNa ? "is-na" : "is-bad"}`}>
          <i className="pve-st-dot" style={{ background: healthOk ? "#6ee7b7" : healthNa ? "rgba(255,255,255,0.35)" : "#f87171" }} />
          {healthOk ? "PASSED" : healthNa ? "N/A" : info.health}
        </div>
      </div>
      <div className="pve-st-disk-sub">
        <span>{info.size}</span>
        {info.temp != null ? <span style={{ color: tempColor }}>{Math.round(info.temp)}°C</span> : null}
      </div>
      {info.alerts.map((a) => (
        <div className="pve-st-disk-alert" key={a}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
            <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z" />
            <path d="M12 9v4" /><path d="M12 17h.01" />
          </svg>
          {a}
        </div>
      ))}
      <div className="pve-st-disk-grid">
        <div className="pve-st-disk-kv"><span>MODEL</span><b title={info.model}>{info.model}</b></div>
        <div className="pve-st-disk-kv">
          <span>WEAR LEVEL</span>
          <b>{wearPct != null ? `${wearPct}%` : "—"}</b>
          {wearPct != null ? <div className="pve-st-wear"><div style={{ width: `${wearPct}%` }} /></div> : null}
        </div>
        <div className="pve-st-disk-kv"><span>POWER CYCLES</span><b>{info.cycles != null ? String(info.cycles) : "—"}</b></div>
        <div className="pve-st-disk-kv"><span>POWER ON</span><b>{info.powerOn}</b></div>
        <div className="pve-st-disk-kv">
          <span>CRC ERRORS</span>
          <b className={info.crc ? "is-bad" : "is-ok"}>
            <i className="pve-st-dot" style={{ background: info.crc ? "#f87171" : "#6ee7b7" }} /> {info.crc}
          </b>
        </div>
      </div>
      <div className="pve-st-disk-ftr">
        <span>{info.serial ? `S/N: ${info.serial}` : ""}</span>
        <span className="pve-st-disk-more" aria-hidden>→</span>
      </div>
    </button>
  );
}

function isRemote(store: Record<string, unknown>) {
  const type = String(store.type || "").toLowerCase();
  return /nfs|cifs|rbd|iscsi|pbs|cephfs|gluster/.test(type) || Boolean(store.shared) || Boolean(store.remote);
}

function typeClass(type: string) {
  const t = type.toLowerCase();
  if (t.includes("lvm")) return "pve-st-type--lvm";
  if (t.includes("zf")) return "pve-st-type--zfs";
  if (t.includes("dir")) return "pve-st-type--dir";
  if (/nfs|cifs|rbd|iscsi|pbs/.test(t)) return "pve-st-type--remote";
  return "pve-st-type--other";
}

function classifyDisk(d: Record<string, unknown>) {
  const prx = (d.__prx as Record<string, unknown> | undefined) || {};
  const path = String(d?.devpath || d?.name || prx.name || "").toLowerCase();
  const type = String(d?.type || prx.type || "").toLowerCase();
  const model = String(d?.model || prx.model || "").toLowerCase();
  const vendor = String(d?.vendor || prx.vendor || "").toLowerCase();
  const transport = String(
    d?.transport || d?.protocol || prx.connection_type || prx.transport || prx.protocol || "",
  ).toLowerCase();
  const blob = `${type} ${transport} ${model} ${vendor}`;

  // PVE uses type:"usb"; ProxMenux uses connection_type:"usb"
  if (/usb|uas/.test(blob) || /usb/.test(path) || transport === "usb" || type === "usb") return "usb";
  if (/\/nvme\d|nvme\d+n\d/.test(path)) return "nvme";

  const isSd = /\/sd[a-z]\d*$/.test(path) || /^sd[a-z]\d*$/.test(path.replace(/^\/dev\//, ""));
  if (isSd) {
    if (/ssd|solid|nvme/.test(model + type) || d?.rpm === 0 || d?.rota === 0) return "ssd";
    if ((Number(d?.rpm) > 0) || d?.rota === 1 || /hdd|rota/.test(blob)) return "hdd";
    return "ssd";
  }

  if (/nvme/.test(type)) return "nvme";
  if (/ssd|solid/.test(type + model)) return "ssd";
  if (/hdd|rota|sata|sas/.test(type + model) || Number(d?.rpm) > 0) return "hdd";
  return type || "disk";
}

function isUsbDisk(disk: Record<string, unknown>) {
  const prx = (disk.__prx as Record<string, unknown> | undefined) || {};
  if (/^usb$/i.test(String(disk.type || ""))) return true;
  if (/^usb$/i.test(String(prx.connection_type || prx.transport || prx.protocol || ""))) return true;
  if (/usb|uas/i.test(String(disk.transport || disk.protocol || ""))) return true;
  return classifyDisk(disk) === "usb";
}

function diskKindLabel(kind: string) {
  return ({ nvme: "NVMe", usb: "USB", ssd: "SSD", hdd: "HDD", disk: "Disk" } as Record<string, string>)[kind] || String(kind || "Disk").toUpperCase();
}

function diskSmartInfo(disk: Record<string, unknown>) {
  const prx = (disk.__prx as Record<string, unknown> | undefined) || {};
  const smart = (disk.smart as Record<string, unknown> | undefined) || {};
  const sd = ((disk.__prxSmart as { smart_data?: Record<string, unknown> } | undefined)?.smart_data)
    || ((prx.smart_data as Record<string, unknown> | undefined) || {});

  const health = String(
    disk.health || prx.smart_status || prx.health || sd.health || smart.health || "UNKNOWN",
  ).toUpperCase();

  const tempRaw = firstFinite(
    disk.temperature,
    prx.temperature,
    sd.temperature,
    smart.temperature,
    smart.temp,
  );
  const temp = tempRaw != null && tempRaw > 0 ? tempRaw : null;

  const wearRaw = firstFinite(
    prx.percentage_used,
    disk.percentage_used,
    prx.wearout != null && String(prx.wearout) !== "N/A" ? 100 - Number(prx.wearout) : null,
    disk.wearout != null && String(disk.wearout) !== "N/A" ? 100 - Number(disk.wearout) : null,
  );
  const wear = wearRaw != null ? Math.max(0, Math.min(100, wearRaw)) : null;

  const cyclesRaw = firstFinite(prx.power_cycles, disk.power_cycles, sd.power_cycles, smart.power_cycles);
  const cycles = cyclesRaw != null && cyclesRaw > 0 ? cyclesRaw : null;

  const pohRaw = firstFinite(prx.power_on_hours, disk.power_on_hours, sd.power_on_hours, smart.power_on_hours);
  const poh = pohRaw != null && pohRaw > 0 ? pohRaw : null;

  const crc = firstFinite(prx.crc_errors, disk.crc_errors) ?? 0;

  const alerts: string[] = [];
  if (health && !/PASSED|OK|UNKNOWN|HEALTHY|N\/A|NONE/.test(health)) alerts.push(`SMART ${health}`);
  if (temp != null && temp >= 60) alerts.push(`Hot ${Math.round(temp)}°C`);
  if (wear != null && wear >= 90) alerts.push(`High wear ${wear}%`);
  if (crc) alerts.push(`CRC errors ${crc}`);

  const sizeNum = Number(disk.size || prx.size || 0);
  const size = sizeNum > 0
    ? fmtBytes(sizeNum)
    : String(prx.size_formatted || "—");

  return {
    health,
    temp,
    wear,
    cycles,
    powerOn: poh != null ? fmtPowerOnHours(poh) : "—",
    crc,
    alerts,
    model: String(disk.model || prx.model || smart.model || "—"),
    serial: String(disk.serial || prx.serial || smart.serial || ""),
    size,
    isSystem: disk.used === 1 || disk.used === true || Number(disk.osdid) >= 0 || Boolean(prx.is_system_disk),
  };
}

function fmtPowerOnHours(hours: number) {
  const h = Number(hours);
  if (!Number.isFinite(h) || h < 0) return "—";
  const days = Math.floor(h / 24);
  const months = Math.floor(days / 30);
  if (months >= 12) {
    const years = months / 12;
    return `${h.toLocaleString()}h (~${years.toFixed(1)}y)`;
  }
  if (months >= 1) return `${h.toLocaleString()}h (~${months}mo)`;
  if (days >= 1) return `${h.toLocaleString()}h (~${days}d)`;
  return `${h.toLocaleString()}h`;
}

function firstFinite(...vals: unknown[]) {
  for (const v of vals) {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}
