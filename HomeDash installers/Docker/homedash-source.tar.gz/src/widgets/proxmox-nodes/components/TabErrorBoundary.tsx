"use client";

import { Component, type ReactNode } from "react";

type Props = { name: string; children: ReactNode };
type State = { error: string };

export class TabErrorBoundary extends Component<Props, State> {
  state: State = { error: "" };

  static getDerivedStateFromError(error: Error) {
    return { error: error?.message || "Tab failed to render" };
  }

  componentDidCatch(error: Error) {
    console.error(`[Proxmox ${this.props.name} tab]`, error);
  }

  componentDidUpdate(prevProps: Props) {
    if (prevProps.name !== this.props.name && this.state.error) {
      this.setState({ error: "" });
    }
  }

  render() {
    if (this.state.error) {
      return (
        <div className="pve-g-empty">
          {this.props.name} tab error: {this.state.error}
          <div style={{ marginTop: 8 }}>
            <button type="button" className="pve-open-link" onClick={() => this.setState({ error: "" })}>
              Retry
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
