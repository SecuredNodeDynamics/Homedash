"use client";

import { useEffect, useRef, useState } from "react";
import { formatTime12h } from "../scheduleFormat";

function IconClock() {
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 3" />
    </svg>
  );
}

function IconChevron() {
  return (
    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M6 9l6 6 6-6" />
    </svg>
  );
}

const HOURS_12 = Array.from({ length: 12 }, (_, i) => i + 1); // 1..12
const MINUTES = Array.from({ length: 60 }, (_, i) => i);
const MINUTE_PRESETS = [0, 15, 30, 45];

function pad(n: number): string {
  return String(n).padStart(2, "0");
}

function parseValue24(value: string): { h24: number; m: number } {
  const match = /^(\d{1,2}):(\d{1,2})$/.exec((value || "").trim());
  if (!match) return { h24: 3, m: 0 };
  const h24 = Math.min(23, Math.max(0, parseInt(match[1], 10) || 0));
  const m = Math.min(59, Math.max(0, parseInt(match[2], 10) || 0));
  return { h24, m };
}

function to12(h24: number): { h12: number; period: "AM" | "PM" } {
  const period: "AM" | "PM" = h24 < 12 ? "AM" : "PM";
  const h12 = h24 % 12 || 12;
  return { h12, period };
}

function to24(h12: number, period: "AM" | "PM"): number {
  const base = h12 % 12; // 12 -> 0
  return period === "PM" ? base + 12 : base;
}

export function TimePicker({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement | null>(null);
  const hourListRef = useRef<HTMLDivElement | null>(null);
  const minuteListRef = useRef<HTMLDivElement | null>(null);
  const { h24, m } = parseValue24(value);
  const { h12, period } = to12(h24);

  useEffect(() => {
    if (!open) return;
    function onDocDown(e: MouseEvent) {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) setOpen(false);
    }
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") setOpen(false);
    }
    document.addEventListener("mousedown", onDocDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDocDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const scroll = (el: HTMLDivElement | null, active: HTMLElement | null) => {
      if (!el || !active) return;
      const target = active.offsetTop - el.clientHeight / 2 + active.clientHeight / 2;
      el.scrollTop = Math.max(0, target);
    };
    requestAnimationFrame(() => {
      scroll(hourListRef.current, hourListRef.current?.querySelector<HTMLElement>('[data-active="true"]') || null);
      scroll(minuteListRef.current, minuteListRef.current?.querySelector<HTMLElement>('[data-active="true"]') || null);
    });
  }, [open]);

  function setHour12(nextH12: number) {
    onChange(`${pad(to24(nextH12, period))}:${pad(m)}`);
  }

  function setMinute(nextM: number) {
    onChange(`${pad(h24)}:${pad(nextM)}`);
  }

  function setPeriod(nextPeriod: "AM" | "PM") {
    onChange(`${pad(to24(h12, nextPeriod))}:${pad(m)}`);
  }

  return (
    <div className="pve-tp" ref={rootRef}>
      <button
        type="button"
        className={`pve-tp-trigger ${open ? "is-open" : ""}`}
        onClick={() => setOpen((v) => !v)}
        aria-haspopup="dialog"
        aria-expanded={open}
      >
        <IconClock />
        <span className="pve-tp-value">{formatTime12h(`${pad(h24)}:${pad(m)}`)}</span>
        <span className="pve-tp-chev"><IconChevron /></span>
      </button>

      {open && (
        <div className="pve-tp-pop" role="dialog" aria-label="Select time">
          <div className="pve-tp-cols">
            <div className="pve-tp-col">
              <div className="pve-tp-col-label">Hour</div>
              <div className="pve-tp-scroll" ref={hourListRef}>
                {HOURS_12.map((hr) => (
                  <button
                    type="button"
                    key={hr}
                    data-active={hr === h12 ? "true" : undefined}
                    className={`pve-tp-opt ${hr === h12 ? "is-active" : ""}`}
                    onClick={() => setHour12(hr)}
                  >
                    {hr}
                  </button>
                ))}
              </div>
            </div>
            <div className="pve-tp-sep">:</div>
            <div className="pve-tp-col">
              <div className="pve-tp-col-label">Min</div>
              <div className="pve-tp-scroll" ref={minuteListRef}>
                {MINUTES.map((mi) => (
                  <button
                    type="button"
                    key={mi}
                    data-active={mi === m ? "true" : undefined}
                    className={`pve-tp-opt ${mi === m ? "is-active" : ""}`}
                    onClick={() => setMinute(mi)}
                  >
                    {pad(mi)}
                  </button>
                ))}
              </div>
            </div>
            <div className="pve-tp-col pve-tp-col--period">
              <div className="pve-tp-col-label">&nbsp;</div>
              <div className="pve-tp-period">
                <button
                  type="button"
                  className={`pve-tp-period-opt ${period === "AM" ? "is-active" : ""}`}
                  onClick={() => setPeriod("AM")}
                >
                  AM
                </button>
                <button
                  type="button"
                  className={`pve-tp-period-opt ${period === "PM" ? "is-active" : ""}`}
                  onClick={() => setPeriod("PM")}
                >
                  PM
                </button>
              </div>
            </div>
          </div>
          <div className="pve-tp-presets">
            {MINUTE_PRESETS.map((mi) => (
              <button type="button" key={mi} className="pve-tp-preset" onClick={() => setMinute(mi)}>
                :{pad(mi)}
              </button>
            ))}
          </div>
          <div className="pve-tp-ftr">
            <button type="button" className="pve-tp-done" onClick={() => setOpen(false)}>Done</button>
          </div>
        </div>
      )}
    </div>
  );
}
