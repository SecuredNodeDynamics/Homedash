"use client";

/** ProxMenux-style RRD area chart (GB volume per sample). */
export function TrafficChart({
  rrd,
  timeframe = "day",
  width = 720,
  height = 220,
}: {
  rrd: Array<Record<string, unknown>>;
  timeframe?: string;
  width?: number;
  height?: number;
}) {
  const points = (rrd || []).filter((p) => p && p.time != null);
  if (points.length < 2) {
    return <div className="pve-net-empty">Waiting for RRD network history…</div>;
  }

  const pad = { t: 18, r: 14, b: 52, l: 44 };
  const plotW = width - pad.l - pad.r;
  const plotH = height - pad.t - pad.b;
  const plotBottom = pad.t + plotH;

  const vols = points.map((p, i) => {
    const prevT = i > 0 ? Number(points[i - 1].time) : Number(p.time) - 1800;
    const step = Math.max(60, Number(p.time) - prevT);
    const rx = Number(p.netin) || 0;
    const tx = Number(p.netout) || 0;
    return {
      t: Number(p.time),
      rxGb: (rx * step) / 1e9,
      txGb: (tx * step) / 1e9,
    };
  });

  const maxY = Math.max(0.01, ...vols.flatMap((v) => [v.rxGb, v.txGb]));
  const niceMax = (() => {
    const padded = maxY * 1.08;
    if (padded <= 1) return Math.ceil(padded * 4) / 4 || 0.25;
    if (padded <= 4) return Math.ceil(padded);
    return Math.ceil(padded / 2) * 2;
  })();

  const xAt = (i: number) => pad.l + (i / (vols.length - 1)) * plotW;
  const yAt = (v: number) => pad.t + plotH - (v / niceMax) * plotH;

  const series = (key: "rxGb" | "txGb") => {
    const line = vols.map((v, i) => `${i ? "L" : "M"}${xAt(i).toFixed(1)},${yAt(v[key]).toFixed(1)}`);
    const area = `${line.join(" ")} L${xAt(vols.length - 1).toFixed(1)},${plotBottom.toFixed(1)} L${xAt(0).toFixed(1)},${plotBottom.toFixed(1)} Z`;
    return { line: line.join(" "), area };
  };

  const rxPath = series("rxGb");
  const txPath = series("txGb");
  const yTicks = 4;
  const xCount = Math.min(8, vols.length);
  const midY = pad.t + plotH / 2;

  return (
    <svg
      className="pve-net-traffic-svg"
      viewBox={`0 0 ${width} ${height}`}
      preserveAspectRatio="xMidYMid meet"
      role="img"
      aria-label="Network traffic"
    >
      {Array.from({ length: yTicks + 1 }, (_, i) => {
        const val = (niceMax / yTicks) * i;
        const y = yAt(val);
        const label = val >= 10 ? val.toFixed(0) : val.toFixed(val < 1 ? 2 : Number.isInteger(val) ? 0 : 1);
        return (
          <g key={`y-${i}`}>
            <line x1={pad.l} y1={y} x2={width - pad.r} y2={y} className="pve-net-grid" />
            <text x={pad.l - 6} y={y + 3.5} textAnchor="end" className="pve-net-axis">{label}</text>
          </g>
        );
      })}
      {Array.from({ length: xCount }, (_, i) => {
        const idx = Math.round((i * (vols.length - 1)) / Math.max(1, xCount - 1));
        const x = xAt(idx);
        return <line key={`xv-${i}`} x1={x} y1={pad.t} x2={x} y2={plotBottom} className="pve-net-grid" />;
      })}
      <text
        x={10}
        y={midY}
        className="pve-net-axis pve-net-axis--unit"
        transform={`rotate(-90 10 ${midY})`}
      >
        GB
      </text>
      <line x1={pad.l} y1={pad.t} x2={pad.l} y2={plotBottom} className="pve-net-axis-line" />
      <line x1={pad.l} y1={plotBottom} x2={width - pad.r} y2={plotBottom} className="pve-net-axis-line" />
      <path d={rxPath.area} fill="#10b981" fillOpacity={0.3} />
      <path d={txPath.area} fill="#3b82f6" fillOpacity={0.3} />
      <path d={rxPath.line} fill="none" stroke="#10b981" strokeWidth={2} strokeLinejoin="round" strokeLinecap="round" />
      <path d={txPath.line} fill="none" stroke="#3b82f6" strokeWidth={2} strokeLinejoin="round" strokeLinecap="round" />
      {Array.from({ length: xCount }, (_, i) => {
        const idx = Math.round((i * (vols.length - 1)) / Math.max(1, xCount - 1));
        const x = xAt(idx);
        const y = plotBottom + 8;
        const label = formatRrdTick(vols[idx].t, timeframe);
        return (
          <g key={`xl-${i}`}>
            <line x1={x} y1={plotBottom} x2={x} y2={plotBottom + 5} className="pve-net-tick" />
            <text
              x={x}
              y={y}
              textAnchor="end"
              className="pve-net-axis"
              transform={`rotate(-45 ${x} ${y})`}
            >
              {label}
            </text>
          </g>
        );
      })}
    </svg>
  );
}

function formatRrdTick(unix: number, timeframe: string) {
  const d = new Date(unix * 1000);
  if (timeframe === "hour") {
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}
