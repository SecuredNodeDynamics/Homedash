"use client";

import { useState } from "react";
import type { BackupSchedule, StatusPayload } from "../../types";
import { ModalPortal, useEscapeClose } from "./ModalPortal";
import { TimePicker } from "../TimePicker";
import { DOW_ORDER, DOW_LABEL, parseSchedule, serializeSchedule } from "../../scheduleFormat";

export function BackupJobModal({
  instanceId,
  data,
  job,
  onClose,
  onSaved,
}: {
  instanceId: string;
  data: StatusPayload;
  job?: BackupSchedule | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const isNew = !job;
  const [formData, setFormData] = useState<Partial<BackupSchedule>>(
    job || {
      enabled: 1,
      schedule: "mon..fri 03:00",
      mode: "snapshot",
      compress: "zstd",
      all: 0,
      vmid: "",
      storage: (data.storage.stores.find((s) => String(s.content).includes("backup"))?.storage as string) || "local",
      node: data.node,
    }
  );
  const initialParsed = parseSchedule(formData.schedule);
  const [selectedDays, setSelectedDays] = useState<string[]>(initialParsed.days);
  const [time, setTime] = useState<string>(initialParsed.time);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEscapeClose(onClose);

  const allGuests = [...data.vms, ...data.lxcs].sort((a, b) => a.id - b.id);
  const selectedVmids = (formData.vmid || "").split(",").filter(Boolean).map((v) => v.trim());

  function toggleVmid(id: string) {
    const next = selectedVmids.includes(id)
      ? selectedVmids.filter((v) => v !== id)
      : [...selectedVmids, id];
    setFormData({ ...formData, vmid: next.join(","), all: 0 });
  }

  function toggleDay(day: string) {
    setSelectedDays((prev) => (prev.includes(day) ? prev.filter((d) => d !== day) : [...prev, day]));
  }

  function setAllDays() {
    setSelectedDays([...DOW_ORDER]);
  }

  function setWeekdays() {
    setSelectedDays(["mon", "tue", "wed", "thu", "fri"]);
  }

  function setWeekend() {
    setSelectedDays(["sat", "sun"]);
  }

  async function save() {
    setBusy(true);
    setError(null);
    try {
      if (selectedDays.length === 0) throw new Error("Select at least one day");
      if (!time) throw new Error("Set a time");
      const schedule = serializeSchedule(selectedDays, time);
      const action = isNew ? "create-backup-job" : "update-backup-job";
      const response = await fetch("/api/widgets/proxmox-nodes/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          instance: instanceId,
          action,
          id: job?.id,
          ...formData,
          schedule,
        }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Save failed");
      onSaved();
      onClose();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Save failed");
    } finally {
      setBusy(false);
    }
  }

  async function remove() {
    if (!job?.id || !confirm("Delete this backup schedule?")) return;
    setBusy(true);
    setError(null);
    try {
      const response = await fetch("/api/widgets/proxmox-nodes/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          instance: instanceId,
          action: "delete-backup-job",
          id: job.id,
        }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Delete failed");
      onSaved();
      onClose();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Delete failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <ModalPortal>
      <div className="pve-disk-backdrop" onClick={onClose} role="presentation">
        <div className="pve-disk-modal pve-bkm-modal" onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true">
          <div className="pve-disk-hdr pve-bkm-hdr">
            <div className="pve-disk-hdr-main">
              <div className="pve-disk-title-row">
                <span className="pve-bkm-title-icon">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                    <rect x="3" y="4" width="18" height="18" rx="2" />
                    <path d="M3 10h18M8 2v4M16 2v4" />
                  </svg>
                </span>
                <span className="pve-disk-title">{isNew ? "Create Backup Schedule" : "Edit Backup Schedule"}</span>
              </div>
              {!isNew && <div className="pve-disk-sub">Job ID: {job.id}</div>}
            </div>
            <button type="button" className="pve-disk-close" aria-label="Close" onClick={onClose}>×</button>
          </div>

          <div className="pve-disk-body pve-bkm-body">
            {error && <div className="pve-bk-error">{error}</div>}

            <div className="pve-bkm-form">
              <div className="pve-bkm-row">
                <div className="pve-bkm-field">
                  <label>Enabled</label>
                  <div className="pve-bkm-toggle-wrap">
                    <button
                      type="button"
                      className={`pve-bkm-toggle ${formData.enabled ? "is-active" : ""}`}
                      onClick={() => setFormData({ ...formData, enabled: 1 })}
                    >
                      Yes
                    </button>
                    <button
                      type="button"
                      className={`pve-bkm-toggle ${!formData.enabled ? "is-active" : ""}`}
                      onClick={() => setFormData({ ...formData, enabled: 0 })}
                    >
                      No
                    </button>
                  </div>
                </div>

                <div className="pve-bkm-field">
                  <label>Storage</label>
                  <select
                    value={formData.storage}
                    onChange={(e) => setFormData({ ...formData, storage: e.target.value })}
                  >
                    {data.storage.stores
                      .filter((s) => String(s.content).includes("backup"))
                      .map((s) => (
                        <option key={String(s.storage)} value={String(s.storage)}>
                          {String(s.storage)}
                        </option>
                      ))}
                  </select>
                </div>
              </div>

              <div className="pve-bkm-section">
                <label className="pve-bkm-section-label">Schedule</label>
                <div className="pve-bkm-schedule">
                  <div className="pve-bkm-days">
                    {DOW_ORDER.map((d) => (
                      <button
                        type="button"
                        key={d}
                        className={`pve-bkm-day ${selectedDays.includes(d) ? "is-active" : ""}`}
                        onClick={() => toggleDay(d)}
                      >
                        {DOW_LABEL[d]}
                      </button>
                    ))}
                  </div>
                  <div className="pve-bkm-schedule-row">
                    <div className="pve-bkm-day-presets">
                      <button type="button" className="pve-bkm-preset" onClick={setAllDays}>Every day</button>
                      <button type="button" className="pve-bkm-preset" onClick={setWeekdays}>Weekdays</button>
                      <button type="button" className="pve-bkm-preset" onClick={setWeekend}>Weekend</button>
                    </div>
                    <TimePicker value={time} onChange={setTime} />
                  </div>
                </div>
              </div>

              <div className="pve-bkm-row">
                <div className="pve-bkm-field">
                  <label>Mode</label>
                  <select
                    value={formData.mode}
                    onChange={(e) => setFormData({ ...formData, mode: e.target.value })}
                  >
                    <option value="snapshot">Snapshot</option>
                    <option value="suspend">Suspend</option>
                    <option value="stop">Stop</option>
                  </select>
                </div>

                <div className="pve-bkm-field">
                  <label>Compression</label>
                  <select
                    value={formData.compress}
                    onChange={(e) => setFormData({ ...formData, compress: e.target.value })}
                  >
                    <option value="0">None</option>
                    <option value="lzo">LZO</option>
                    <option value="gzip">GZIP</option>
                    <option value="zstd">ZSTD</option>
                  </select>
                </div>
              </div>

              <div className="pve-bkm-field">
                <label>Comment</label>
                <input
                  type="text"
                  value={formData.comment || ""}
                  placeholder="Optional description"
                  onChange={(e) => setFormData({ ...formData, comment: e.target.value })}
                />
              </div>

              <div className="pve-bkm-section">
                <div className="pve-bkm-targets-hdr">
                  <label className="pve-bkm-section-label">Backup Targets</label>
                  <button
                    type="button"
                    className={`pve-bkm-toggle ${formData.all ? "is-active" : ""}`}
                    onClick={() => setFormData({ ...formData, all: formData.all ? 0 : 1, vmid: "" })}
                  >
                    All VMs/LXCs
                  </button>
                </div>
                {!formData.all && (
                  <div className="pve-bkm-guest-grid">
                    {allGuests.map((g) => (
                      <button
                        type="button"
                        key={g.id}
                        className={`pve-bkm-guest-opt ${selectedVmids.includes(String(g.id)) ? "is-selected" : ""}`}
                        onClick={() => toggleVmid(String(g.id))}
                      >
                        <span className="id">{g.id}</span>
                        <span className="name">{g.name}</span>
                      </button>
                    ))}
                    {allGuests.length === 0 && <div className="pve-bkm-guest-empty">No VMs or LXCs found</div>}
                  </div>
                )}
              </div>
            </div>

            <div className="pve-bkm-ftr">
              {!isNew && (
                <button className="pve-bk-btn pve-bk-btn--danger" onClick={remove} disabled={busy}>
                  Delete Schedule
                </button>
              )}
              <div style={{ flex: 1 }} />
              <button className="pve-bk-btn" onClick={onClose} disabled={busy}>Cancel</button>
              <button className="pve-bk-btn pve-bk-btn--primary" onClick={save} disabled={busy}>
                {busy ? "Saving..." : "Save Job"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </ModalPortal>
  );
}
