"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { Guest } from "../../types";
import { ModalPortal } from "./ModalPortal";

const PER_GUEST_TIMEOUT_MS = 20 * 60 * 1000;

type Phase = "confirm" | "running" | "done" | "error";

type LogLine = { text: string; cls?: string };

type FailedGuest = { id: number; label: string; reason: string };

function guestLabel(g: Guest) {
  return `${g.name || "guest"} (${g.id})`;
}

function isPendingRunningLxc(g: Guest) {
  return (
    (g.type === "lxc" || g.kind === "lxc") &&
    g.status === "running" &&
    Number(g.updateCheck?.count || 0) > 0
  );
}

/** Upgrade running LXCs with pending updates via host terminal `pct exec`. */
export function BulkUpdateModal({
  instanceId,
  guests,
  onClose,
  onFinished,
}: {
  instanceId: string;
  guests: Guest[];
  onClose: () => void;
  onFinished?: (result: { okVmids: number[]; failedVmids: number[] }) => void;
}) {
  const targets = guests.filter(isPendingRunningLxc);
  const [phase, setPhase] = useState<Phase>("confirm");
  const [status, setStatus] = useState(
    targets.length
      ? `${targets.length} running LXC${targets.length === 1 ? "" : "s"} with pending updates`
      : "No eligible LXCs",
  );
  const [lines, setLines] = useState<LogLine[]>([]);
  const [error, setError] = useState("");
  const [progress, setProgress] = useState({ index: 0, total: targets.length });
  const [summary, setSummary] = useState({ ok: 0, failed: 0, skipped: 0 });
  const [failedGuests, setFailedGuests] = useState<FailedGuest[]>([]);

  const logRef = useRef<HTMLDivElement | null>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const cancelledRef = useRef(false);
  const bufferRef = useRef("");
  const waitersRef = useRef<Array<(chunk: string) => void>>([]);
  const finishedCalledRef = useRef(false);
  const wsClosedRef = useRef(false);
  const queueDoneRef = useRef(false);

  const append = useCallback((text: string, cls?: string) => {
    const chunks = String(text).replace(/\r\n/g, "\n").split("\n");
    setLines((prev) => {
      const next = [...prev];
      for (const chunk of chunks) {
        if (chunk === "" && next.length) continue;
        next.push({ text: chunk, cls });
      }
      return next.slice(-2000);
    });
  }, []);

  useEffect(() => {
    logRef.current?.scrollTo(0, logRef.current.scrollHeight);
  }, [lines]);

  function feedOutput(chunk: string) {
    bufferRef.current += chunk;
    append(chunk);
    const waiters = waitersRef.current.slice();
    for (const wait of waiters) wait(chunk);
  }

  /**
   * Wait for a completion line like `__HD_DONE_101_ts__0`.
   * Must require trailing digits so the shell's command echo (`…__$?`) does not
   * false-trigger before apt finishes.
   */
  function waitForDone(
    marker: string,
    timeoutMs: number,
  ): Promise<{ status: "ok"; code: number } | { status: "timeout" | "closed" }> {
    const doneRe = new RegExp(`${marker.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(\\d+)`);
    const tryMatch = (): number | null => {
      const m = bufferRef.current.match(doneRe);
      return m ? Number(m[1]) : null;
    };

    return new Promise((resolve) => {
      const immediate = tryMatch();
      if (immediate != null && Number.isFinite(immediate)) {
        resolve({ status: "ok", code: immediate });
        return;
      }

      let settled = false;
      const finish = (result: { status: "ok"; code: number } | { status: "timeout" | "closed" }) => {
        if (settled) return;
        settled = true;
        window.clearTimeout(timer);
        waitersRef.current = waitersRef.current.filter((w) => w !== onChunk);
        resolve(result);
      };

      const timer = window.setTimeout(() => finish({ status: "timeout" }), timeoutMs);

      const onChunk = () => {
        const code = tryMatch();
        if (code != null && Number.isFinite(code)) {
          finish({ status: "ok", code });
          return;
        }
        if (wsClosedRef.current) finish({ status: "closed" });
      };
      waitersRef.current.push(onChunk);

      const socket = socketRef.current;
      if (!socket || socket.readyState !== WebSocket.OPEN) {
        finish({ status: "closed" });
      }
    });
  }

  function sendRaw(cmd: string) {
    const socket = socketRef.current;
    if (!socket || socket.readyState !== WebSocket.OPEN) {
      throw new Error("Host terminal disconnected");
    }
    socket.send(cmd);
  }

  async function runQueue() {
    if (!targets.length) {
      setPhase("done");
      setStatus("Nothing to update");
      return;
    }

    cancelledRef.current = false;
    queueDoneRef.current = false;
    setPhase("running");
    setError("");
    setLines([]);
    setSummary({ ok: 0, failed: 0, skipped: 0 });
    setFailedGuests([]);
    setProgress({ index: 0, total: targets.length });
    setStatus("Connecting to host terminal…");

    let socket: WebSocket | null = null;
    let ok = 0;
    let failed = 0;
    let skipped = 0;
    let connLost = false;
    const okVmids: number[] = [];
    const failedVmids: number[] = [];
    const failedDetails: FailedGuest[] = [];

    try {
      const ticketRes = await fetch("/api/widgets/proxmox-nodes/terminal/ticket", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, mode: "host" }),
      });
      const ticketJson = await ticketRes.json();
      if (!ticketRes.ok) throw new Error(ticketJson.error || "Terminal ticket failed");
      if (cancelledRef.current) return;

      socket = new WebSocket(String(ticketJson.wsUrl));
      socketRef.current = socket;
      wsClosedRef.current = false;

      await new Promise<void>((resolve, reject) => {
        if (!socket) return reject(new Error("WebSocket missing"));
        socket.onopen = () => resolve();
        socket.onerror = () => reject(new Error("WebSocket error"));
        window.setTimeout(() => reject(new Error("WebSocket connect timeout")), 20_000);
      });

      socket.onmessage = (event) => {
        const raw = typeof event.data === "string" ? event.data : "";
        if (!raw) return;
        try {
          const parsed = JSON.parse(raw) as { type?: string; data?: string };
          if (parsed.type === "pong") return;
          if (parsed.data != null) {
            feedOutput(String(parsed.data));
            return;
          }
        } catch {
          // raw shell output
        }
        feedOutput(raw);
      };
      socket.onerror = () => {
        // Closing the socket after the queue finishes can itself raise a benign
        // error event in some browsers — ignore it once we've already reported a result.
        if (!cancelledRef.current && !queueDoneRef.current) {
          setError("Host terminal WebSocket error");
        }
      };
      socket.onclose = () => {
        wsClosedRef.current = true;
        waitersRef.current.forEach((w) => w(""));
      };

      // Give the shell a moment to settle, then clear any MOTD noise from our buffer watch.
      await new Promise((r) => window.setTimeout(r, 400));
      bufferRef.current = "";

      for (let i = 0; i < targets.length; i += 1) {
        if (cancelledRef.current) {
          skipped += targets.length - i;
          break;
        }
        if (!socketRef.current || socketRef.current.readyState !== WebSocket.OPEN) {
          skipped += targets.length - i;
          connLost = true;
          setError("Connection lost mid-queue; remaining guests skipped");
          break;
        }

        const guest = targets[i];
        const label = guestLabel(guest);
        setProgress({ index: i + 1, total: targets.length });
        setStatus(`${i + 1} / ${targets.length} — ${label}`);
        append(`===== ${label} =====`, "is-meta");

        // Host-level sentinel after pct exec so we wait for the real process end.
        // Echo text uses `$?` literally in the typed line; we only match when digits appear.
        const marker = `__HD_DONE_${guest.id}_${Date.now()}__`;
        const inner =
          "export DEBIAN_FRONTEND=noninteractive; apt-get update && apt-get upgrade -y";
        const escaped = inner.replace(/'/g, `'\\''`);
        const cmd = `pct exec ${guest.id} -- bash -lc '${escaped}'; echo ${marker}$?\n`;

        try {
          bufferRef.current = "";
          sendRaw(cmd);
          const result = await waitForDone(marker, PER_GUEST_TIMEOUT_MS);
          if (result.status === "closed") {
            failed += 1;
            failedVmids.push(guest.id);
            failedDetails.push({ id: guest.id, label, reason: "connection dropped" });
            skipped += targets.length - i - 1;
            connLost = true;
            append(`Connection dropped while updating ${label}`, "is-err");
            setError("Host terminal disconnected");
            break;
          }
          if (result.status === "timeout") {
            failed += 1;
            failedVmids.push(guest.id);
            failedDetails.push({ id: guest.id, label, reason: "timed out" });
            append(`Timed out waiting for ${label} (continuing)`, "is-err");
            continue;
          }

          const code = result.status === "ok" ? result.code : NaN;
          if (code === 0) {
            ok += 1;
            okVmids.push(guest.id);
            append(`OK — ${label} (exit 0)`, "is-ok");
          } else {
            failed += 1;
            failedVmids.push(guest.id);
            failedDetails.push({
              id: guest.id,
              label,
              reason: `exit ${Number.isFinite(code) ? code : "?"}`,
            });
            append(`Failed — ${label} (exit ${Number.isFinite(code) ? code : "?"})`, "is-err");
          }
        } catch (cause) {
          failed += 1;
          failedVmids.push(guest.id);
          const reason = cause instanceof Error ? cause.message : "failed";
          failedDetails.push({ id: guest.id, label, reason });
          append(`Error — ${label}: ${reason}`, "is-err");
        }
      }

      queueDoneRef.current = true;
      setSummary({ ok, failed, skipped });
      setFailedGuests(failedDetails);
      setPhase(connLost && ok === 0 && failed === 0 ? "error" : "done");
      setStatus(
        skipped
          ? `Done — ${ok} ok, ${failed} failed, ${skipped} skipped`
          : `Done — ${ok} ok, ${failed} failed`,
      );
      if (!finishedCalledRef.current) {
        finishedCalledRef.current = true;
        onFinished?.({ okVmids, failedVmids });
      }
    } catch (cause) {
      queueDoneRef.current = true;
      setPhase("error");
      setError(cause instanceof Error ? cause.message : "Bulk update failed");
      setStatus("Error");
      setSummary({ ok, failed, skipped: targets.length - ok - failed });
      if (!finishedCalledRef.current) {
        finishedCalledRef.current = true;
        onFinished?.({ okVmids, failedVmids });
      }
    } finally {
      try {
        socket?.close();
      } catch {
        // ignore
      }
      socketRef.current = null;
      waitersRef.current = [];
    }
  }

  function stopQueue() {
    cancelledRef.current = true;
    try {
      socketRef.current?.close();
    } catch {
      // ignore
    }
    setStatus((s) => (phase === "running" ? `${s} (stopping…)` : s));
  }

  function handleClose() {
    if (phase === "running") {
      stopQueue();
    }
    onClose();
  }

  const busy = phase === "running";

  const progressPct =
    progress.total > 0 ? Math.round((progress.index / progress.total) * 100) : 0;

  return (
    <ModalPortal>
      <div className="pve-scifi pve-hw-swrun-backdrop pve-bulk-upd-backdrop" role="presentation">
        <div className="pve-hw-swrun-modal pve-bulk-upd-modal" role="dialog" aria-modal="true" aria-label="Bulk LXC update">
          <div className="pve-bulk-upd-fx" aria-hidden="true">
            <i className="pve-bulk-upd-grid" />
            <i className="pve-bulk-upd-glow" />
          </div>
          <div className="pve-bulk-upd-corners" aria-hidden="true" />

          <div className="pve-hw-swrun-hdr pve-bulk-upd-hdr">
            <div className="pve-bulk-upd-brand">
              <span className={`pve-bulk-upd-pulse${busy ? "" : " is-idle"}`} aria-hidden="true" />
              <div>
                <div className="pve-hw-swrun-title pve-bulk-upd-title">
                  {phase === "confirm"
                    ? "Update LXCs"
                    : `Updating ${targets.length} LXC${targets.length === 1 ? "" : "s"}`}
                </div>
                <div className="pve-hw-swrun-sub pve-bulk-upd-sub">
                  Non-interactive apt-get upgrade via pct exec
                </div>
              </div>
            </div>
            <button
              type="button"
              className="pve-hw-gpu-close pve-bulk-upd-close"
              aria-label="Close"
              onClick={handleClose}
              disabled={busy}
            >
              ×
            </button>
          </div>

          {phase === "confirm" ? (
            <>
              <div className="pve-bulk-upd-confirm">
                Upgrade {targets.length} running LXC{targets.length === 1 ? "" : "s"} with{" "}
                <code>apt-get upgrade -y</code>?
              </div>
              {targets.length ? (
                <ul className="pve-bulk-upd-list">
                  {targets.map((g) => (
                    <li key={g.id}>
                      <span className="pve-bulk-upd-guest">{guestLabel(g)}</span>
                      <span className="pve-bulk-upd-count">
                        {g.updateCheck?.count} update{g.updateCheck?.count === 1 ? "" : "s"}
                      </span>
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="pve-hw-swrun-status pve-bulk-upd-err">
                  No running LXCs with pending updates.
                </div>
              )}
              <div className="pve-hw-swrun-ftr pve-bulk-upd-ftr">
                <button type="button" className="pve-hw-gpu-sw-btn pve-bulk-upd-btn" onClick={onClose}>
                  Cancel
                </button>
                <button
                  type="button"
                  className="pve-hw-gpu-sw-btn pve-bulk-upd-btn pve-bulk-upd-go"
                  onClick={() => void runQueue()}
                  disabled={!targets.length}
                >
                  Start upgrade
                </button>
              </div>
            </>
          ) : (
            <>
              <div className="pve-bulk-upd-status-row">
                <div className="pve-hw-swrun-status pve-bulk-upd-status">{status}</div>
                {progress.total > 0 ? (
                  <div className="pve-bulk-upd-progress-wrap">
                    <div className="pve-bulk-upd-progress-bar" role="progressbar" aria-valuenow={progressPct} aria-valuemin={0} aria-valuemax={100}>
                      <div
                        className="pve-bulk-upd-progress-fill"
                        style={{ width: `${progressPct}%` }}
                      />
                    </div>
                    <div className="pve-bulk-upd-progress">
                      {progress.index} / {progress.total}
                    </div>
                  </div>
                ) : null}
              </div>
              {error ? (
                <div className="pve-hw-swrun-status pve-bulk-upd-err">{error}</div>
              ) : null}
              <div className="pve-bulk-upd-log-wrap">
                <div className="pve-bulk-upd-log-fx" aria-hidden="true">
                  <i className="pve-bulk-upd-log-scan" />
                </div>
                <div className="pve-hw-swrun-log pve-bulk-upd-log" ref={logRef}>
                  {lines.length ? (
                    lines.map((line, i) => (
                      <div key={i} className={line.cls}>
                        {line.text}
                      </div>
                    ))
                  ) : (
                    <div className="is-meta">Waiting for output…</div>
                  )}
                </div>
              </div>
              {(phase === "done" || phase === "error") && (
                <div className="pve-bulk-upd-summary">
                  <span className="pve-bulk-upd-sum-ok">{summary.ok} ok</span>
                  <span className="pve-bulk-upd-sum-fail">{summary.failed} failed</span>
                  {summary.skipped ? (
                    <span className="pve-bulk-upd-sum-skip">{summary.skipped} skipped</span>
                  ) : null}
                </div>
              )}
              {(phase === "done" || phase === "error") && failedGuests.length ? (
                <ul className="pve-bulk-upd-fail-list">
                  {failedGuests.map((g) => (
                    <li key={g.id}>
                      <span className="pve-bulk-upd-fail-guest">{g.label}</span>
                      <span className="pve-bulk-upd-fail-reason">{g.reason}</span>
                    </li>
                  ))}
                </ul>
              ) : null}
              <div className="pve-hw-swrun-ftr pve-bulk-upd-ftr">
                {busy ? (
                  <button type="button" className="pve-hw-gpu-sw-btn pve-bulk-upd-btn pve-bulk-upd-stop" onClick={stopQueue}>
                    Stop queue
                  </button>
                ) : (
                  <button type="button" className="pve-hw-gpu-sw-btn pve-bulk-upd-btn" onClick={onClose}>
                    Close
                  </button>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </ModalPortal>
  );
}
