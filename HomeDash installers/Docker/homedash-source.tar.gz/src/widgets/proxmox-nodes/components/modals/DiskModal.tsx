"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { fmtBytes } from "../../types";
import { TrafficChart } from "../TrafficChart";
import { MiniBar, ModalPortal, RingGauge, useEscapeClose } from "./ModalPortal";
import { TempHistoryModal, TempSparkline } from "./TempHistoryModal";

export function DiskModal({
  instanceId,
  disk,
  onClose,
}: {
  instanceId: string;
  disk: Record<string, unknown>;
  onClose: () => void;
}) {
  const [pane, setPane] = useState<"overview" | "smart" | "history" | "schedule">("overview");
  const [smart, setSmart] = useState<Record<string, unknown> | null>(null);
  const [history, setHistory] = useState<unknown>(null);
  const [schedules, setSchedules] = useState<unknown>(null);
  const [temp, setTemp] = useState<unknown>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState("");
  const [toast, setToast] = useState("");
  const [tempOpen, setTempOpen] = useState(false);
  const name = String(disk.devpath || disk.name || "").replace(/^\/dev\//, "");
  const prx = (disk.__prx as Record<string, unknown> | undefined) || {};
  const close = useCallback(() => onClose(), [onClose]);
  useEscapeClose(close, !tempOpen);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!name) return;
      try {
        const [smartRes, histRes, tempRes, schedRes] = await Promise.all([
          fetch(`/api/widgets/proxmox-nodes/proxmenux?instance=${encodeURIComponent(instanceId)}&kind=smart&disk=${encodeURIComponent(name)}`),
          fetch(`/api/widgets/proxmox-nodes/proxmenux?instance=${encodeURIComponent(instanceId)}&path=${encodeURIComponent(`/api/storage/smart/${name}/history?limit=50`)}`),
          fetch(`/api/widgets/proxmox-nodes/proxmenux?instance=${encodeURIComponent(instanceId)}&kind=temp&disk=${encodeURIComponent(name)}&timeframe=hour`),
          fetch(`/api/widgets/proxmox-nodes/proxmenux?instance=${encodeURIComponent(instanceId)}&path=${encodeURIComponent("/api/storage/smart/schedules")}`),
        ]);
        const smartJson = await smartRes.json();
        const histJson = await histRes.json();
        const tempJson = await tempRes.json();
        const schedJson = await schedRes.json();
        if (!cancelled) {
          if (smartRes.ok) setSmart(smartJson);
          if (histRes.ok) setHistory(histJson);
          if (tempRes.ok) setTemp(tempJson);
          if (schedRes.ok) setSchedules(schedJson);
          if (!smartRes.ok && !histRes.ok) setError(smartJson.error || histJson.error || "ProxMenux disk details unavailable");
        }
      } catch (cause) {
        if (!cancelled) setError(cause instanceof Error ? cause.message : "Failed to load disk details");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [instanceId, name]);

  async function runTest(testType: "short" | "long") {
    setBusy(testType);
    setToast("");
    try {
      const response = await fetch("/api/widgets/proxmox-nodes/proxmenux", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, kind: "smart-test", disk: name, testType }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "SMART test failed");
      setToast(`${testType} SMART test started`);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "SMART test failed");
    } finally {
      setBusy("");
    }
  }

  const info = useMemo(() => diskSmartInfo(disk, prx, smart), [disk, prx, smart]);
  const healthOk = /PASSED|OK|HEALTHY/i.test(info.health);
  const tempOk = info.temp == null || info.temp < 60;
  const tempColor = info.temp == null ? "rgba(255,255,255,0.45)" : (tempOk ? "#22c55e" : "#f87171");
  const histList = Array.isArray(history)
    ? history
    : (((history as { history?: unknown[]; data?: unknown[] } | null)?.history)
      || ((history as { data?: unknown[] } | null)?.data)
      || []) as Array<Record<string, unknown>>;
  const schedList = Array.isArray(schedules)
    ? schedules
    : (((schedules as { schedules?: unknown[] } | null)?.schedules) || []) as Array<Record<string, unknown>>;
  const attrs = Array.isArray((smart as { smart_data?: { attributes?: unknown[] } } | null)?.smart_data?.attributes)
    ? ((smart as { smart_data: { attributes: Array<Record<string, unknown>> } }).smart_data.attributes)
    : Array.isArray((smart as { attributes?: unknown[] } | null)?.attributes)
      ? ((smart as { attributes: Array<Record<string, unknown>> }).attributes)
      : [];

  return (
    <ModalPortal>
      <div className="pve-disk-backdrop" onClick={close} role="presentation">
        <div className="pve-disk-modal" onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true">
          <div className="pve-disk-hdr">
            <div className="pve-disk-hdr-main">
              <div className="pve-disk-title-row">
                <span className="pve-disk-title">{String(disk.devpath || disk.name || "Disk")}</span>
                <span className={`pve-st-health ${healthOk ? "pve-st-health--ok" : "pve-st-health--warn"}`}>
                  {healthOk ? "Healthy" : info.health}
                </span>
              </div>
              <div className="pve-disk-sub">{info.model} · {info.size}</div>
            </div>
            <button type="button" className="pve-disk-close" aria-label="Close" onClick={close}>×</button>
          </div>

          <div className="pve-disk-tabs" role="tablist">
            {([
              ["overview", "Overview", "blue"],
              ["smart", "SMART", "green"],
              ["history", "History", "orange"],
              ["schedule", "Schedule", "purple"],
            ] as const).map(([key, label, tone]) => (
              <button
                key={key}
                type="button"
                className={`pve-disk-tab pve-disk-tab--${tone}${pane === key ? ` pve-disk-tab--active pve-disk-tab--${tone}` : ""}`}
                onClick={() => setPane(key)}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="pve-disk-body">
            {error ? <div className="pve-disk-toast" style={{ color: "#f87171" }}>{error}</div> : null}
            {toast ? <div className="pve-disk-toast">{toast}</div> : null}

            {pane === "overview" ? (
              <div className="pve-disk-pane">
                <div className="pve-disk-sec">
                  <div className="pve-disk-kv-grid">
                    <div className="pve-disk-kv2"><span>Model</span><b>{info.model}</b></div>
                    <div className="pve-disk-kv2"><span>Serial Number</span><b>{info.serial || "—"}</b></div>
                    <div className="pve-disk-kv2"><span>Capacity</span><b>{info.size}</b></div>
                    <div className="pve-disk-kv2">
                      <span>Health Status</span>
                      <b>
                        <span className={`pve-st-health ${healthOk ? "pve-st-health--ok" : "pve-st-health--warn"}`}>
                          {healthOk ? "Healthy" : info.health}
                        </span>
                      </b>
                    </div>
                  </div>
                </div>

                {info.wear != null ? (
                  <div className="pve-disk-sec">
                    <div className="pve-disk-sec-title">Wear &amp; Lifetime</div>
                    <div className="pve-disk-wear-row">
                      <div className="pve-disk-life">
                        {info.lifePct != null
                          ? <RingGauge pct={info.lifePct} color={info.lifePct >= 70 ? "#6ee7b7" : info.lifePct >= 40 ? "#fbbf24" : "#f87171"} />
                          : <div className="pve-disk-life-na">—</div>}
                        <div className="pve-disk-life-caption">life</div>
                      </div>
                      <div className="pve-disk-wear-meta">
                        <div className="pve-disk-wear-bar-hdr"><span>Wear</span><b>{info.wear}%</b></div>
                        <div className="pve-st-track"><div className="pve-st-track-fill" style={{ width: `${info.wear}%`, background: "#3b82f6" }} /></div>
                        <div className="pve-disk-wear-stats">
                          <div><span>Est. Life</span><b>{info.estLife}</b></div>
                          <div><span>Data Written</span><b>{info.dataWritten != null ? fmtBytes(info.dataWritten) : "—"}</b></div>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : null}

                <div className="pve-disk-sec">
                  <div className="pve-disk-sec-title">SMART Attributes</div>
                  <button
                    type="button"
                    className="pve-disk-temp-card"
                    title="Open temperature history"
                    onClick={() => setTempOpen(true)}
                  >
                    <div className="pve-disk-temp-top">
                      <div>
                        <span>Temperature</span>
                        <div className="pve-disk-temp-val" style={{ color: tempColor }}>
                          {info.temp != null ? `${Math.round(info.temp)}°C` : "—"}
                        </div>
                      </div>
                      <div className="pve-disk-temp-side">
                        <span className={`pve-disk-temp-badge ${tempOk ? "is-ok" : "is-bad"}`}>{tempOk ? "Normal" : "Hot"}</span>
                      </div>
                    </div>
                    <div className="pve-disk-temp-spark">
                      <TempSparkline payload={temp} color={tempColor} />
                    </div>
                  </button>
                  <div className="pve-disk-attr-grid">
                    <div className="pve-disk-attr"><span>Power On Hours</span><b>{info.powerOnHours != null ? `${Number(info.powerOnHours).toLocaleString()}h` : "—"}</b></div>
                    <div className="pve-disk-attr"><span>Rotation Rate</span><b>{info.rotation}</b></div>
                    <div className="pve-disk-attr"><span>Power Cycles</span><b>{info.cycles != null ? Number(info.cycles).toLocaleString() : "—"}</b></div>
                    <div className="pve-disk-attr">
                      <span>SMART Status</span>
                      <b className={healthOk ? "is-ok" : "is-bad"}>
                        <i className="pve-st-dot" style={{ background: healthOk ? "#6ee7b7" : "#f87171" }} /> {healthOk ? "passed" : String(info.health || "").toLowerCase()}
                      </b>
                    </div>
                  </div>
                </div>
              </div>
            ) : null}

            {pane === "smart" ? (
              <div className="pve-disk-pane">
                <div className="pve-disk-sec">
                  <div className="pve-gc-actions">
                    <button type="button" disabled={!!busy} onClick={() => runTest("short")}>{busy === "short" ? "Starting…" : "Short test"}</button>
                    <button type="button" disabled={!!busy} onClick={() => runTest("long")}>{busy === "long" ? "Starting…" : "Extended test"}</button>
                  </div>
                </div>
                <div className="pve-disk-sec">
                  <div className="pve-disk-sec-title">Attributes</div>
                  {attrs.length ? (
                    <div className="pve-disk-attr-grid">
                      {attrs.slice(0, 24).map((a, i) => (
                        <div className="pve-disk-attr" key={i}>
                          <span>{String(a.name || a.id || `attr-${i}`)}</span>
                          <b>{String(a.raw || a.value || a.worst || "—")}</b>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="pve-disk-empty">
                      <div className="pve-disk-empty-title">No SMART attributes</div>
                      <div className="pve-disk-empty-sub">Connect ProxMenux MONITOR for full SMART details.</div>
                    </div>
                  )}
                </div>
              </div>
            ) : null}

            {pane === "history" ? (
              <div className="pve-disk-pane">
                {histList.length ? histList.map((h, i) => (
                  <div className="pve-gc-row" key={i}>
                    <strong>{String(h.test_type || "test")}</strong>
                    <span>{String(h.date_readable || h.timestamp || "—")}</span>
                    <span>{String(h.filename || "")}</span>
                  </div>
                )) : (
                  <div className="pve-disk-empty">
                    <div className="pve-disk-empty-title">No SMART history</div>
                    <div className="pve-disk-empty-sub">Run a SMART test to create history entries.</div>
                  </div>
                )}
              </div>
            ) : null}

            {pane === "schedule" ? (
              <div className="pve-disk-pane">
                {schedList.length ? schedList.map((s, i) => (
                  <div className="pve-gc-row" key={i}>
                    <strong>{String(s.test_type || "schedule")}</strong>
                    <span>{String(s.frequency || "")}</span>
                    <span>{s.active === false ? "inactive" : "active"}</span>
                  </div>
                )) : (
                  <div className="pve-disk-empty">
                    <div className="pve-disk-empty-title">No schedules</div>
                    <div className="pve-disk-empty-sub">Manage automatic SMART schedules in ProxMenux MONITOR.</div>
                  </div>
                )}
              </div>
            ) : null}
          </div>
        </div>
      </div>
      {tempOpen ? (
        <TempHistoryModal
          instanceId={instanceId}
          disk={disk}
          liveTemp={info.temp}
          model={info.model}
          onClose={() => setTempOpen(false)}
        />
      ) : null}
    </ModalPortal>
  );
}

function diskSmartInfo(disk: Record<string, unknown>, prx: Record<string, unknown>, smart: Record<string, unknown> | null) {
  const wearRaw = disk.wearout ?? prx.percentage_used ?? prx.ssd_life_left;
  const wear = wearRaw != null && wearRaw !== "" ? Number(wearRaw) : null;
  const lifePct = wear != null
    ? (Number(prx.ssd_life_left) || Math.max(0, 100 - wear))
    : null;
  const temp = firstNum(disk.temperature, prx.temperature, (smart as { temperature?: number } | null)?.temperature);
  const rpm = Number(disk.rpm || prx.rpm || 0);
  return {
    model: String(disk.model || prx.model || "Disk"),
    serial: String(prx.serial || disk.serial || ""),
    size: fmtBytes(Number(disk.size || prx.size || 0)),
    health: String(disk.health || prx.smart_status || prx.health || "UNKNOWN"),
    temp,
    wear: Number.isFinite(wear as number) ? wear : null,
    lifePct: Number.isFinite(lifePct as number) ? lifePct : null,
    estLife: lifePct != null ? `${Math.round(lifePct)}%` : "—",
    dataWritten: firstNum(prx.data_written, prx.total_lbas_written),
    powerOnHours: firstNum(prx.power_on_hours, disk.power_on_hours),
    cycles: firstNum(prx.power_cycles, disk.power_cycles),
    rotation: rpm > 1 ? `${rpm} RPM` : "SSD / N/A",
  };
}

function firstNum(...vals: unknown[]) {
  for (const v of vals) {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}

const IFACE_RANGES = [
  { id: "hour", label: "Last hour" },
  { id: "day", label: "Last day" },
  { id: "week", label: "Last week" },
  { id: "month", label: "Last month" },
  { id: "year", label: "Last year" },
] as const;

export function IfaceModal({
  iface,
  onClose,
  rrd = [],
}: {
  iface: Record<string, unknown>;
  onClose: () => void;
  rrd?: Array<Record<string, unknown>>;
}) {
  const [rangeOpen, setRangeOpen] = useState(false);
  const [timeframe, setTimeframe] = useState<(typeof IFACE_RANGES)[number]["id"]>("day");
  const close = useCallback(() => onClose(), [onClose]);
  useEscapeClose(close);

  const name = String(iface.name || "interface");
  const kind = String(iface.kind || iface.type || "nic");
  const statusRaw = String(iface.status || (iface.up ? "UP" : "DOWN")).toUpperCase();
  const statusTone = /up/i.test(statusRaw) ? "green" : (/down/i.test(statusRaw) ? "red" : "muted");
  const addrs = Array.isArray(iface.addresses) ? iface.addresses : [];
  const members = Array.isArray(iface.bridge_members) ? iface.bridge_members : [];
  const range = IFACE_RANGES.find((r) => r.id === timeframe) || IFACE_RANGES[1];
  const useRrd = (rrd || []).length >= 2;
  const rxBytes = Number(iface.bytes_recv || 0);
  const txBytes = Number(iface.bytes_sent || 0);

  return (
    <ModalPortal>
      <div className="pve-if-backdrop" onClick={close} role="presentation">
        <div className="pve-if-modal" onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true">
          <button type="button" className="pve-if-close" aria-label="Close" onClick={close}>×</button>
          <div className="pve-if-hdr">
            <div>
              <h2 className="pve-if-title"><span>{name} - Interface Details</span></h2>
              <p className="pve-if-sub">View detailed information and network traffic statistics for this interface</p>
            </div>
            <div className="pve-if-range-wrap">
              <button
                type="button"
                className="pve-if-range"
                aria-haspopup="listbox"
                aria-expanded={rangeOpen}
                onClick={() => setRangeOpen((v) => !v)}
              >
                <span className="pve-if-range-label">{range.label}</span>
                ▾
              </button>
              {rangeOpen ? (
                <div className="pve-if-range-menu" role="listbox">
                  {IFACE_RANGES.map((r) => (
                    <button
                      key={r.id}
                      type="button"
                      className={`pve-if-range-opt${r.id === timeframe ? " is-active" : ""}`}
                      role="option"
                      aria-selected={r.id === timeframe}
                      onClick={() => {
                        setTimeframe(r.id);
                        setRangeOpen(false);
                      }}
                    >
                      <span>{r.label}</span>
                    </button>
                  ))}
                </div>
              ) : null}
            </div>
          </div>

          <div className="pve-if-body">
            <div className="pve-if-section">
              <h3 className="pve-if-section-title">Basic Information</h3>
              <div className="pve-if-grid">
                <div><div className="pve-if-label">Interface Name</div><div className="pve-if-val">{name}</div></div>
                <div><div className="pve-if-label">Type</div><div><span className={`pve-if-badge pve-if-badge--${kind === "bridge" ? "green" : "blue"}`}>{kind}</span></div></div>
                <div><div className="pve-if-label">Status</div><div><span className={`pve-if-badge pve-if-badge--${statusTone}`}>{statusRaw}</span></div></div>
                <div><div className="pve-if-label">Speed</div><div className="pve-if-val">{formatSpeed(Number(iface.speed ?? iface.max_speed ?? 0))}</div></div>
                <div><div className="pve-if-label">Duplex</div><div className="pve-if-val pve-if-val--cap">{String(iface.duplex || "—")}</div></div>
                <div><div className="pve-if-label">MTU</div><div className="pve-if-val">{iface.mtu != null ? String(iface.mtu) : "—"}</div></div>
                <div><div className="pve-if-label">MAC</div><div className="pve-if-val">{String(iface.mac_address || iface.mac || "—")}</div></div>
              </div>
            </div>

            {addrs.length ? (
              <div className="pve-if-section">
                <h3 className="pve-if-section-title">IP Addresses</h3>
                <div className="pve-if-ips">
                  {addrs.map((a, i) => {
                    const row = (typeof a === "object" && a ? a : { ip: a }) as Record<string, unknown>;
                    return (
                      <div className="pve-if-ip" key={i}>
                        <div className="pve-if-ip-addr">{String(row.ip || row.address || "—")}</div>
                        <div className="pve-if-ip-mask">Netmask: {String(row.netmask || row.mask || "—")}</div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : null}

            <div className="pve-if-section">
              <h3 className="pve-if-section-title">
                Network Traffic Statistics{useRrd ? ` (${range.label})` : ""}
              </h3>
              <div className="pve-if-grid" style={{ marginBottom: 12 }}>
                <div><div className="pve-if-label">Received</div><div className="pve-if-val">{fmtBytes(rxBytes)}</div></div>
                <div><div className="pve-if-label">Sent</div><div className="pve-if-val">{fmtBytes(txBytes)}</div></div>
                <div><div className="pve-if-label">Packets RX</div><div className="pve-if-val">{String(iface.packets_recv ?? "—")}</div></div>
                <div><div className="pve-if-label">Packets TX</div><div className="pve-if-val">{String(iface.packets_sent ?? "—")}</div></div>
                <div><div className="pve-if-label">Errors</div><div className="pve-if-val">{Number(iface.errors_in || 0) + Number(iface.errors_out || 0)}</div></div>
                <div><div className="pve-if-label">Drops</div><div className="pve-if-val">{Number(iface.drops_in || 0) + Number(iface.drops_out || 0)}</div></div>
              </div>
              {useRrd ? (
                <>
                  <div className="pve-if-chart-legend">
                    <span className="pve-net-legend-item"><i className="pve-net-swatch pve-net-swatch--rx" />Received</span>
                    <span className="pve-net-legend-item"><i className="pve-net-swatch pve-net-swatch--tx" />Sent</span>
                  </div>
                  <TrafficChart rrd={rrd} timeframe={timeframe} height={180} />
                </>
              ) : (
                <div className="pve-net-empty pve-if-chart-empty">Per-interface history isn’t available — showing lifetime counters above.</div>
              )}
            </div>

            {kind === "bridge" || String(iface.type || "").toLowerCase() === "bridge" ? (
              <div className="pve-if-section">
                <h3 className="pve-if-section-title">Bridge Configuration</h3>
                <div className="pve-if-muted" style={{ marginBottom: 8 }}>Virtual Member Interfaces</div>
                <div className="pve-if-members">
                  {members.length
                    ? members.map((m, i) => (
                      <span className="pve-if-badge pve-if-badge--green" key={i}>
                        {typeof m === "string" ? m : String((m as { name?: string }).name || m)}
                      </span>
                    ))
                    : <span className="pve-if-muted">No members reported</span>}
                </div>
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </ModalPortal>
  );
}

function formatSpeed(raw: number) {
  if (!Number.isFinite(raw) || raw <= 0) return "N/A";
  const mbps = raw >= 1e6 ? Math.round(raw / 1e6) : Math.round(raw);
  if (mbps <= 0) return "N/A";
  if (mbps >= 1000) return `${(mbps / 1000).toFixed(mbps % 1000 === 0 ? 0 : 1)} Gb/s`;
  return `${mbps} Mb/s`;
}

export function GpuDetailModal({
  gpu,
  onClose,
  instanceId,
}: {
  gpu: Record<string, unknown>;
  onClose: () => void;
  instanceId: string;
}) {
  const [live, setLive] = useState<Record<string, unknown> | null>(null);
  const close = useCallback(() => onClose(), [onClose]);
  useEscapeClose(close);
  const slot = String(gpu.slot || "");

  useEffect(() => {
    if (!slot) return;
    let cancelled = false;
    const load = async () => {
      try {
        const res = await fetch(
          `/api/widgets/proxmox-nodes/proxmenux?instance=${encodeURIComponent(instanceId)}&path=${encodeURIComponent(`/api/gpu/${encodeURIComponent(slot)}/realtime`)}`,
        );
        const json = await res.json();
        if (!cancelled && res.ok) setLive(json);
      } catch {
        /* ignore */
      }
    };
    load();
    const timer = window.setInterval(load, 3000);
    return () => {
      cancelled = true;
      window.clearInterval(timer);
    };
  }, [instanceId, slot]);

  const processes = Array.isArray(live?.processes) ? (live!.processes as Array<Record<string, unknown>>) : [];

  return (
    <ModalPortal>
      <div className="pve-hw-gpu-backdrop" onClick={close} role="presentation">
        <div className="pve-hw-gpu-modal" onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true">
          <button type="button" className="pve-hw-gpu-close" aria-label="Close" onClick={close}>×</button>
          <div className="pve-hw-gpu-modal-hdr">
            <div className="pve-hw-gpu-modal-title">{String(gpu.name || "GPU")}</div>
            <div className="pve-hw-gpu-modal-sub">{String(gpu.vendor || "")} · {slot || "—"}</div>
          </div>
          <div className="pve-hw-modal-body">
            <div className="pve-hw-modal-sec">
              <div className="pve-hw-gpu-props">
                <div className="pve-hw-gpu-prop"><span className="pve-hw-k">Vendor</span><span className="pve-hw-v">{String(gpu.vendor || "—")}</span></div>
                <div className="pve-hw-gpu-prop"><span className="pve-hw-k">Type</span><span className="pve-hw-v">{String(gpu.type || "—")}</span></div>
                <div className="pve-hw-gpu-prop"><span className="pve-hw-k">PCI Slot</span><span className="pve-hw-v pve-hw-mono">{slot || "—"}</span></div>
                <div className="pve-hw-gpu-prop"><span className="pve-hw-k">Driver</span><span className="pve-hw-v pve-hw-mono pve-hw-v--ok">{String(gpu.pci_driver || "—")}</span></div>
                <div className="pve-hw-gpu-prop"><span className="pve-hw-k">Kernel Module</span><span className="pve-hw-v pve-hw-mono">{String(gpu.pci_kernel_module || "—")}</span></div>
              </div>
            </div>

            {live ? (
              <div data-gpu-live>
                <div className="pve-hw-gpu-live-pill">Live</div>
                <div className="pve-hw-modal-sec">
                  <div className="pve-disk-sec-title">Real-Time Metrics</div>
                  <div className="pve-hw-gpu-props">
                    <div className="pve-hw-gpu-prop"><span className="pve-hw-k">Temp</span><span className="pve-hw-v">{live.temperature != null ? `${live.temperature}°C` : "—"}</span></div>
                    <div className="pve-hw-gpu-prop"><span className="pve-hw-k">Power</span><span className="pve-hw-v">{live.power_draw != null ? `${live.power_draw} W` : "—"}</span></div>
                    <div className="pve-hw-gpu-prop"><span className="pve-hw-k">Fan</span><span className="pve-hw-v">{live.fan_speed != null ? `${live.fan_speed}${live.fan_unit || "%"}` : "—"}</span></div>
                    <div className="pve-hw-gpu-prop"><span className="pve-hw-k">GFX Clock</span><span className="pve-hw-v">{String(live.clock_graphics ?? "—")}</span></div>
                    <div className="pve-hw-gpu-prop"><span className="pve-hw-k">Mem Clock</span><span className="pve-hw-v">{String(live.clock_memory ?? "—")}</span></div>
                  </div>
                </div>
                <div className="pve-hw-modal-sec">
                  <div className="pve-disk-sec-title">Memory</div>
                  <div className="pve-hw-gpu-props">
                    <div className="pve-hw-gpu-prop"><span className="pve-hw-k">Total</span><span className="pve-hw-v">{live.memory_total != null ? fmtBytes(Number(live.memory_total)) : "—"}</span></div>
                    <div className="pve-hw-gpu-prop"><span className="pve-hw-k">Used</span><span className="pve-hw-v">{live.memory_used != null ? fmtBytes(Number(live.memory_used)) : "—"}</span></div>
                    <div className="pve-hw-gpu-prop"><span className="pve-hw-k">Util</span><span className="pve-hw-v">{live.utilization_memory != null ? `${live.utilization_memory}%` : "—"}</span></div>
                  </div>
                  {live.utilization_memory != null ? <MiniBar pct={Number(live.utilization_memory)} color="#38bdf8" /> : null}
                </div>
                {processes.length ? (
                  <div className="pve-hw-modal-sec">
                    <div className="pve-disk-sec-title">Active Processes</div>
                    {processes.slice(0, 12).map((p, i) => (
                      <div className="pve-gc-row" key={i}>
                        <strong>{String(p.name || p.process || p.cmd || "proc")}</strong>
                        <span>PID {String(p.pid || "—")}</span>
                      </div>
                    ))}
                  </div>
                ) : null}
              </div>
            ) : (
              <div className="pve-g-empty">Waiting for live GPU metrics…</div>
            )}
          </div>
        </div>
      </div>
    </ModalPortal>
  );
}

export function PciDetailModal({
  pci,
  onClose,
}: {
  pci: Record<string, unknown>;
  onClose: () => void;
}) {
  const close = useCallback(() => onClose(), [onClose]);
  useEscapeClose(close);
  return (
    <ModalPortal>
      <div className="pve-hw-pci-backdrop" onClick={close} role="presentation">
        <div className="pve-hw-pci-modal" onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true">
          <button type="button" className="pve-hw-gpu-close" aria-label="Close" onClick={close}>×</button>
          <div className="pve-hw-pci-modal-hdr">
            <div className="pve-hw-pci-modal-title">{String(pci.device || pci.sdevice || "PCI Device")}</div>
            <div className="pve-hw-pci-modal-sub">{String(pci.slot || "")}</div>
          </div>
          <div className="pve-hw-pci-modal-body">
            <div className="pve-hw-gpu-prop"><span className="pve-hw-k">Type</span><span className="pve-hw-v">{String(pci.type || "—")}</span></div>
            <div className="pve-hw-gpu-prop"><span className="pve-hw-k">PCI Slot</span><span className="pve-hw-v pve-hw-mono">{String(pci.slot || "—")}</span></div>
            <div className="pve-hw-gpu-prop"><span className="pve-hw-k">Device</span><span className="pve-hw-v">{String(pci.device || "—")}</span></div>
            <div className="pve-hw-gpu-prop"><span className="pve-hw-k">Product</span><span className="pve-hw-v">{String(pci.sdevice || "—")}</span></div>
            <div className="pve-hw-gpu-prop"><span className="pve-hw-k">Vendor</span><span className="pve-hw-v">{String(pci.vendor || "—")}</span></div>
            <div className="pve-hw-gpu-prop"><span className="pve-hw-k">Class</span><span className="pve-hw-v">{String(pci.class || "—")}</span></div>
            <div className="pve-hw-gpu-prop"><span className="pve-hw-k">Driver</span><span className="pve-hw-v pve-hw-mono">{String(pci.driver || "—")}</span></div>
            <div className="pve-hw-gpu-prop"><span className="pve-hw-k">Kernel Module</span><span className="pve-hw-v pve-hw-mono">{String(pci.kernel_module || "—")}</span></div>
          </div>
        </div>
      </div>
    </ModalPortal>
  );
}

/** @deprecated use GpuDetailModal / PciDetailModal */
export function SimpleDetailModal({
  title,
  data,
  onClose,
  className = "pve-hw-gpu-backdrop",
}: {
  title: string;
  data: Record<string, unknown>;
  onClose: () => void;
  className?: string;
}) {
  if (className.includes("pci")) {
    return <PciDetailModal pci={{ ...data, device: data.device || title }} onClose={onClose} />;
  }
  return <GpuDetailModal gpu={{ ...data, name: data.name || title }} onClose={onClose} instanceId="" />;
}
