"use client";

import { useCallback, useEffect, useState, type ReactNode } from "react";
import { fmtBytes, fmtUptimeFull, pctColor, type Guest } from "../../types";
import { MiniBar, ModalPortal, useEscapeClose } from "./ModalPortal";

type GuestDetails = {
  status: Record<string, unknown>;
  config: Record<string, unknown>;
  firewall: { options: Record<string, unknown>; rules: Array<Record<string, unknown>> };
  backups: Array<Record<string, unknown>>;
  updateCheck: Record<string, unknown> | null;
};

type UpdatePkg = {
  name?: string;
  Package?: string;
  current?: string;
  current_version?: string;
  latest?: string;
  latest_version?: string;
  new_version?: string;
  security?: boolean;
};

export function GuestModal({
  instanceId,
  guest,
  onClose,
  onOpenTerminal,
  canOpenTerminal,
  canControlPower,
  onChanged,
}: {
  instanceId: string;
  guest: Guest;
  onClose: () => void;
  onOpenTerminal: (guest: Guest) => void;
  canOpenTerminal: boolean;
  canControlPower: boolean;
  onChanged: () => void;
}) {
  const [pane, setPane] = useState<"status" | "backups" | "updates" | "firewall">("status");
  const [details, setDetails] = useState<GuestDetails | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState("");
  const [toast, setToast] = useState("");
  const [showNotes, setShowNotes] = useState(false);
  const [showInfo, setShowInfo] = useState(false);
  const [recheckBusy, setRecheckBusy] = useState(false);
  const close = useCallback(() => {
    if (typeof document !== "undefined" && document.querySelector(".pve-term-backdrop")) return;
    onClose();
  }, [onClose]);
  useEscapeClose(close);

  const load = useCallback(async () => {
    const response = await fetch(
      `/api/widgets/proxmox-nodes/guests?instance=${encodeURIComponent(instanceId)}&type=${guest.kind}&vmid=${guest.id}`,
    );
    const json = await response.json();
    if (!response.ok) throw new Error(json.error || "Failed to load guest");
    setDetails(json);
    setError("");
  }, [instanceId, guest.id, guest.kind]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        await load();
      } catch (cause) {
        if (!cancelled) setError(cause instanceof Error ? cause.message : "Failed to load guest");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [load]);

  async function act(action: "start" | "shutdown" | "reboot" | "stop") {
    setBusy(action);
    setToast("");
    try {
      const response = await fetch("/api/widgets/proxmox-nodes/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, type: guest.kind, vmid: guest.id, action }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Action failed");
      setToast(`${action} sent`);
      onChanged();
      await load().catch(() => null);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Action failed");
    } finally {
      setBusy("");
    }
  }

  async function recheckUpdates() {
    setRecheckBusy(true);
    try {
      // ProxMenux update map is refreshed when guest details reload (/api/vms).
      await load();
      onChanged();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Recheck failed");
    } finally {
      setRecheckBusy(false);
    }
  }

  const status = details?.status || {};
  const config = details?.config || {};
  const running = String(status.status || guest.status) === "running";
  const isLxc = guest.type === "lxc" || guest.kind === "lxc";
  const cpus = Number(status.cpus || config.cores || config.cpulimit || guest.cpus || 1) || 1;
  const cpuPct = Math.round(Number(status.cpu ?? guest.cpu ?? 0) * 1000) / 10;
  const memUsed = Number(status.mem ?? guest.mem ?? 0);
  const memMax = Number(status.maxmem ?? guest.maxmem ?? (Number(config.memory) || 0) * 1024 * 1024) || 0;
  const memPct = memMax > 0 ? (memUsed / memMax) * 100 : 0;
  const diskUsed = Number(status.disk ?? guest.disk ?? 0);
  const diskMax = Number(status.maxdisk ?? guest.maxdisk ?? 0);
  const diskPct = diskMax > 0 ? (diskUsed / diskMax) * 100 : 0;
  const swapMb = config.swap != null ? Number(config.swap) : null;
  const notes = String(config.description || config.notes || "");
  const configIps = parseGuestIps(config);
  const ips = configIps.length ? configIps : (Array.isArray(guest.ips) ? guest.ips.filter(Boolean) : []);
  const uc = normalizeUpdateCheck(details?.updateCheck);
  const packages = uc?.packages || [];
  const updateCount = uc?.count || 0;
  const fwEnabled = details?.firewall.options?.enable == 1 || details?.firewall.options?.enable === true;
  const fwRules = details?.firewall.rules || [];
  const backups = details?.backups || [];
  const checkedLabel = uc?.last_check
    ? new Date(String(uc.last_check)).toLocaleString()
    : "—";

  return (
    <ModalPortal>
      <div className="pve-gc-backdrop" onClick={close} role="presentation">
        <div className="pve-gc-modal" onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true">
          <button type="button" className="pve-gc-close" aria-label="Close" onClick={close}>×</button>

          <div className={`pve-gc-hdr${running ? " pve-gc-hdr--run" : " pve-gc-hdr--stop"}`}>
            <div className="pve-gc-title">
              <span
                className={`pve-gc-status-dot${running ? " pve-gc-status-dot--run" : " pve-gc-status-dot--stop"}`}
                aria-hidden
              />
              <div className="pve-gc-title-text">
                <div className="pve-gc-name">{guest.name}</div>
                <div className="pve-gc-sub">
                  <span className="pve-gc-id">#{guest.id}</span>
                  <span className={`pve-g-pill ${isLxc ? "pve-g-pill--lxc" : "pve-g-pill--vm"}`}>{isLxc ? "LXC" : "VM"}</span>
                  <span className={`pve-g-pill ${running ? "pve-g-pill--run" : "pve-g-pill--stop"}`}>
                    {running ? "RUNNING" : String(status.status || guest.status || "STOPPED").toUpperCase()}
                  </span>
                  {updateCount > 0 ? (
                    <button type="button" className="pve-g-updates pve-g-updates--btn" onClick={() => setPane("updates")}>
                      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
                        <path d="M22 7.7c0-.6-.4-1.2-.8-1.5l-6.3-3.9a1.72 1.72 0 0 0-1.7 0l-10.3 6c-.5.2-.9.8-.9 1.4v6.6c0 .5.4 1.2.8 1.5l6.3 3.9a1.72 1.72 0 0 0 1.7 0l10.3-6c.5-.3.9-1 .9-1.5Z" />
                      </svg>
                      <span>{updateCount}</span>
                    </button>
                  ) : null}
                </div>
              </div>
            </div>
            <div className="pve-gc-hdr-meta">
              <span className="pve-gc-uptime" title="Uptime">{fmtUptimeFull(Number(status.uptime || guest.uptime || 0))}</span>
            </div>
          </div>

          <div className="pve-gc-tabs" role="tablist">
            <TabBtn active={pane === "status"} onClick={() => setPane("status")} icon="status">Status</TabBtn>
            <TabBtn active={pane === "backups"} onClick={() => setPane("backups")} icon="backups" badge={backups.length}>
              Backups
            </TabBtn>
            <TabBtn
              active={pane === "updates"}
              onClick={() => setPane("updates")}
              icon="updates"
              badge={updateCount > 0 ? updateCount : undefined}
              updates
            >
              Updates
            </TabBtn>
            <TabBtn active={pane === "firewall"} onClick={() => setPane("firewall")} icon="firewall">Firewall</TabBtn>
          </div>

          <div className="pve-gc-body">
            {error ? <div className="pve-gc-toast pve-gc-toast--err">{error}</div> : null}
            {!details && !error ? <div className="pve-gc-loading">Loading guest controller…</div> : null}

            {details && pane === "status" ? (
              <>
                <div className="pve-gc-usage">
                  <div className="pve-gc-usage-grid">
                    <div className="pve-gc-stat">
                      <div className="pve-gc-stat-top">
                        <span>CPU · {cpus}c</span>
                        <b style={{ color: pctColor(cpuPct) }}>{cpuPct.toFixed(1)}%</b>
                      </div>
                      <MiniBar pct={cpuPct} color={pctColor(cpuPct)} />
                    </div>
                    <div className="pve-gc-stat">
                      <div className="pve-gc-stat-top">
                        <span>Memory</span>
                        <b style={{ color: pctColor(memPct) }}>{fmtBytes(memUsed)}</b>
                      </div>
                      <MiniBar pct={memPct} color="#38bdf8" />
                      <div className="pve-gc-stat-sub">of {fmtBytes(memMax)}</div>
                    </div>
                    <div className="pve-gc-stat">
                      <div className="pve-gc-stat-top">
                        <span>Disk</span>
                        <b style={{ color: pctColor(diskPct) }}>{diskMax ? fmtBytes(diskUsed) : "—"}</b>
                      </div>
                      <MiniBar pct={diskPct} color="#38bdf8" />
                      <div className="pve-gc-stat-sub">{diskMax ? `of ${fmtBytes(diskMax)}` : "n/a"}</div>
                    </div>
                  </div>
                  <div className="pve-gc-usage-io">
                    <span className="pve-gc-chip" title="Disk I/O since boot">
                      <span className="pve-gc-chip-label">Disk I/O</span>
                      <span className="pve-g-io pve-g-io--r">↓ {fmtBytes(Number(status.diskread || guest.diskread || 0))}</span>
                      <span className="pve-g-io pve-g-io--w">↑ {fmtBytes(Number(status.diskwrite || guest.diskwrite || 0))}</span>
                    </span>
                    <span className="pve-gc-chip" title="Network I/O since boot">
                      <span className="pve-gc-chip-label">Net I/O</span>
                      <span className="pve-g-io pve-g-io--rx">↓ {fmtBytes(Number(status.netin || guest.netin || 0))}</span>
                      <span className="pve-g-io pve-g-io--tx">↑ {fmtBytes(Number(status.netout || guest.netout || 0))}</span>
                    </span>
                  </div>
                </div>

                <div className="pve-gc-section">
                  <div className="pve-gc-section-hdr">
                    <span>Resources</span>
                    <div className="pve-gc-section-actions">
                      <button
                        type="button"
                        className={`pve-gc-mini-btn${showNotes ? " pve-gc-mini-btn--active" : ""}`}
                        onClick={() => setShowNotes((v) => !v)}
                      >
                        {showNotes ? "Hide Notes" : "Notes"}
                      </button>
                      <button
                        type="button"
                        className={`pve-gc-mini-btn${showInfo ? " pve-gc-mini-btn--active" : ""}`}
                        onClick={() => setShowInfo((v) => !v)}
                      >
                        {showInfo ? "Less Info" : "Info"}
                      </button>
                    </div>
                  </div>
                  <div className="pve-gc-res-grid">
                    <div><span>CPU Cores</span><b>{cpus}</b></div>
                    <div><span>Memory</span><b>{memMax ? `${Math.round(memMax / 1024 / 1024)} MB` : "—"}</b></div>
                    <div><span>Swap</span><b>{swapMb != null ? `${swapMb} MB` : "—"}</b></div>
                  </div>
                  <div className="pve-gc-ips">
                    <div className="pve-gc-ips-label">IP Addresses</div>
                    <div className="pve-gc-ip-list">
                      {ips.length
                        ? ips.map((ip) => <span className="pve-gc-ip" key={ip}>{ip}</span>)
                        : <span className="pve-gc-ip pve-gc-ip--muted">No static IPs in config</span>}
                    </div>
                  </div>
                  {showNotes ? <GuestNotesPanel notes={notes} /> : null}
                  {showInfo ? <GuestInfoPanel config={config} isLxc={isLxc} /> : null}
                </div>
              </>
            ) : null}

            {details && pane === "backups" ? (
              <div className="pve-gc-section">
                <div className="pve-gc-section-hdr">
                  <span>Backups</span>
                  <span className="pve-g-pill">{backups.length}</span>
                </div>
                <div className="pve-gc-backup-list">
                  {backups.length ? backups.slice(0, 20).map((b, i) => {
                    const vol = String(b.volid || "").split("/").pop() || String(b.volid || "backup");
                    return (
                      <div className="pve-gc-backup-row" key={i}>
                        <div>
                          <div className="pve-gc-backup-name" title={String(b.volid || "")}>{vol}</div>
                          <div className="pve-gc-backup-meta">
                            {b.ctime ? new Date(Number(b.ctime) * 1000).toLocaleString() : "—"}
                            {" · "}
                            {String(b.storage || "")}
                          </div>
                        </div>
                        <div className="pve-gc-backup-size">{fmtBytes(Number(b.size || 0))}</div>
                      </div>
                    );
                  }) : <div className="pve-g-empty">No backups found for this guest</div>}
                </div>
              </div>
            ) : null}

            {details && pane === "updates" ? (
              <div className="pve-gc-section">
                <div className="pve-gc-updates-card">
                  <div className="pve-gc-updates-hdr">
                    <div className="pve-gc-updates-title">
                      <span className="pve-gc-updates-ico">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
                          <path d="M22 7.7c0-.6-.4-1.2-.8-1.5l-6.3-3.9a1.72 1.72 0 0 0-1.7 0l-10.3 6c-.5.2-.9.8-.9 1.4v6.6c0 .5.4 1.2.8 1.5l6.3 3.9a1.72 1.72 0 0 0 1.7 0l10.3-6c.5-.3.9-1 .9-1.5Z" />
                        </svg>
                      </span>
                      Pending package updates
                    </div>
                    <div className="pve-gc-updates-hdr-actions">
                      {updateCount > 0 ? <span className="pve-gc-updates-total">{updateCount} total</span> : null}
                      <button
                        type="button"
                        className={`pve-gc-updates-recheck${recheckBusy ? " pve-gc-updates-recheck--busy" : ""}`}
                        disabled={recheckBusy}
                        onClick={recheckUpdates}
                        title="Re-scan pending packages on this guest"
                      >
                        <svg className={recheckBusy ? "pve-gc-spin" : undefined} width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" aria-hidden>
                          <path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
                          <path d="M3 3v5h5" />
                          <path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16" />
                          <path d="M16 16h5v5" />
                        </svg>
                        Recheck
                      </button>
                    </div>
                  </div>
                  <div className="pve-gc-updates-meta">
                    Last checked: {checkedLabel} · Apply with <code>Open Terminal → apt update && apt upgrade</code> · status refreshes automatically
                  </div>
                  {packages.length && !(updateCount > packages.length) ? (
                    <div className="pve-gc-updates-list">
                      {packages.slice(0, 40).map((pkg, i) => {
                        const name = String(pkg.name || pkg.Package || "package");
                        const cur = String(pkg.current || pkg.current_version || "—");
                        const lat = String(pkg.latest || pkg.latest_version || pkg.new_version || "—");
                        return (
                          <div className="pve-gc-updates-row" key={`${name}-${i}`}>
                            <div className="pve-gc-updates-name">
                              {pkg.security ? (
                                <svg className="pve-gc-updates-sec" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-label="Security update">
                                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                                </svg>
                              ) : (
                                <svg className="pve-gc-updates-pkg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
                                  <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
                                </svg>
                              )}
                              <span>{name}</span>
                            </div>
                            <div className="pve-gc-updates-ver">
                              <span>{cur}</span>
                              <span className="pve-gc-updates-arrow">→</span>
                              <span className="pve-gc-updates-latest">{lat}</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : updateCount > 0 ? (
                    <div className="pve-gc-updates-summary">
                      <div><strong>{updateCount}</strong> package{updateCount === 1 ? "" : "s"} pending</div>
                      {(uc?.security_count || 0) > 0 ? (
                        <div className="pve-gc-updates-sec-line"><strong>{uc!.security_count}</strong> security</div>
                      ) : null}
                    </div>
                  ) : (
                    <div className="pve-gc-updates-empty">No pending package updates reported for this guest.</div>
                  )}
                </div>
              </div>
            ) : null}

            {details && pane === "firewall" ? (
              <div className="pve-gc-section">
                <div className="pve-gc-section-hdr">
                  <span>Firewall</span>
                  <span className={`pve-g-pill ${fwEnabled ? "pve-g-pill--run" : "pve-g-pill--stop"}`}>
                    {fwEnabled ? "ENABLED" : "DISABLED"}
                  </span>
                </div>
                <div className="pve-gc-fw-list">
                  {fwRules.length ? fwRules.map((r, i) => (
                    <div className="pve-gc-fw-row" key={i}>
                      <span className="pve-g-pill">{String(r.action || r.type || "RULE")}</span>
                      <span>{String(r.macro || r.proto || "any")}</span>
                      <span className="pve-gc-fw-detail">
                        {String(r.source || "anywhere")} → {String(r.dest || "anywhere")}
                        {r.dport ? ` :${r.dport}` : ""}
                      </span>
                      <span className="pve-gc-fw-enable">{r.enable === 0 ? "off" : "on"}</span>
                    </div>
                  )) : <div className="pve-g-empty">No guest firewall rules</div>}
                </div>
              </div>
            ) : null}
          </div>

          <div className="pve-gc-footer">
            {canOpenTerminal ? (
              <button
                type="button"
                className="pve-gc-terminal"
                onPointerUp={(e) => e.stopPropagation()}
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenTerminal(guest);
                }}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
                  <polyline points="4 17 10 11 4 5" />
                  <line x1="12" y1="19" x2="20" y2="19" />
                </svg>
                Open Terminal
              </button>
            ) : null}
            {canControlPower ? (
              <div className="pve-gc-actions">
                <button type="button" className="pve-gc-act pve-gc-act--start" disabled={!!busy || running} onClick={() => act("start")}>Start</button>
                <button type="button" className="pve-gc-act pve-gc-act--shutdown" disabled={!!busy || !running} onClick={() => act("shutdown")}>Shutdown</button>
                <button type="button" className="pve-gc-act pve-gc-act--reboot" disabled={!!busy || !running} onClick={() => act("reboot")}>Reboot</button>
                <button type="button" className="pve-gc-act pve-gc-act--stop" disabled={!!busy || !running} onClick={() => act("stop")}>Force Stop</button>
              </div>
            ) : null}
            {toast ? <div className="pve-gc-toast pve-gc-toast--ok">{toast}</div> : null}
          </div>
        </div>
      </div>
    </ModalPortal>
  );
}

function TabBtn({
  active,
  onClick,
  children,
  badge,
  updates,
  icon,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
  badge?: number;
  updates?: boolean;
  icon: "status" | "backups" | "updates" | "firewall";
}) {
  return (
    <button
      type="button"
      className={`pve-gc-tab${updates ? " pve-gc-tab--updates" : ""}${active ? " pve-gc-tab--active" : ""}${active && updates ? " pve-gc-tab--active-updates" : ""}`}
      onClick={onClick}
    >
      {icon === "status" ? (
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2" /></svg>
      ) : null}
      {icon === "backups" ? (
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" /></svg>
      ) : null}
      {icon === "updates" ? (
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" /><path d="M3 3v5h5" />
          <path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16" /><path d="M16 16h5v5" />
        </svg>
      ) : null}
      {icon === "firewall" ? (
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /></svg>
      ) : null}
      {children}
      {badge != null ? (
        <span className={`pve-gc-tab-badge${updates ? " pve-gc-tab-badge--updates" : ""}`}>{badge}</span>
      ) : null}
    </button>
  );
}

function normalizeUpdateCheck(uc: Record<string, unknown> | null | undefined) {
  if (!uc || typeof uc !== "object") return null;
  const packages = (Array.isArray(uc.packages) ? uc.packages : []) as UpdatePkg[];
  const count = Number(uc.count) || packages.length || 0;
  const available = uc.available === true || count > 0;
  if (!available && count <= 0) return null;
  return {
    available: true,
    count,
    security_count: Number(uc.security_count) || 0,
    last_check: uc.last_check || uc.last_checked || uc.last_checked_iso || null,
    packages,
  };
}

function parseGuestIps(config: Record<string, unknown>) {
  const ips: string[] = [];
  for (const [key, value] of Object.entries(config)) {
    if (!/^net\d+$/i.test(key)) continue;
    for (const part of String(value || "").split(",")) {
      const m = part.trim().match(/^(?:ip|ip6)=([^,/]+)/i);
      if (!m) continue;
      const ip = m[1].replace(/\/\d+$/, "");
      if (/^(dhcp|manual|auto)$/i.test(ip)) continue;
      if (ip && ip !== "127.0.0.1") ips.push(ip);
    }
  }
  return [...new Set(ips)];
}

function decodePveNotes(str: string) {
  try {
    return decodeURIComponent(String(str || "").replace(/%0A/gi, "\n"));
  } catch {
    return String(str || "");
  }
}

function escapeHtml(s: string) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function sanitizeNotesHtml(html: string) {
  if (typeof document === "undefined") return escapeHtml(html);
  const doc = new DOMParser().parseFromString(String(html || ""), "text/html");
  doc.querySelectorAll("script,iframe,object,embed,link,meta,form").forEach((el) => el.remove());
  doc.querySelectorAll("*").forEach((el) => {
    [...el.attributes].forEach((attr) => {
      const n = attr.name;
      const v = attr.value || "";
      if (/^on/i.test(n)) el.removeAttribute(n);
      if ((n === "href" || n === "src") && /^\s*javascript:/i.test(v)) el.removeAttribute(n);
    });
    const align = el.getAttribute("align");
    if (align && /^(center|left|right)$/i.test(align)) {
      (el as HTMLElement).style.textAlign = align.toLowerCase();
    }
    if (el.tagName === "A") {
      el.setAttribute("target", "_blank");
      el.setAttribute("rel", "noopener noreferrer");
    }
  });
  return doc.body.innerHTML;
}

function notesToHtml(raw: string) {
  const decoded = decodePveNotes(raw);
  if (!decoded.trim()) return "";
  if (/<\/?[a-z][\s\S]*?>/i.test(decoded)) return sanitizeNotesHtml(decoded);
  let s = escapeHtml(decoded);
  s = s.replace(/^### (.+)$/gm, "<h3>$1</h3>");
  s = s.replace(/^## (.+)$/gm, "<h2>$1</h2>");
  s = s.replace(/^# (.+)$/gm, "<h1>$1</h1>");
  s = s.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
  s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  s = s.replace(/(^|[\s>])(https?:\/\/[^\s<]+)/g, '$1<a href="$2" target="_blank" rel="noopener noreferrer">$2</a>');
  s = s.replace(/\n/g, "<br>");
  return s;
}

function GuestNotesPanel({ notes }: { notes: string }) {
  const html = notesToHtml(notes);
  return (
    <div className="pve-gc-notes-panel">
      <div className="pve-gc-notes-hdr"><span>NOTES</span></div>
      {html ? (
        <div className="pve-gc-notes-body pve-gc-notes" dangerouslySetInnerHTML={{ __html: html }} />
      ) : (
        <div className="pve-gc-notes-body pve-gc-notes-empty">No notes yet.</div>
      )}
    </div>
  );
}

function parseKvList(raw: string) {
  const out: Record<string, string> = {};
  String(raw || "").split(",").forEach((pair) => {
    const eq = pair.indexOf("=");
    if (eq > 0) out[pair.slice(0, eq).trim()] = pair.slice(eq + 1).trim();
    else if (pair.trim() && !out.model) out.model = pair.trim();
  });
  return out;
}

function parseDiskSpec(raw: string) {
  const s = String(raw || "");
  const comma = s.indexOf(",");
  const head = comma >= 0 ? s.slice(0, comma) : s;
  const options = parseKvList(comma >= 0 ? s.slice(comma + 1) : "");
  let storage = "";
  let volume = "";
  let path = "";
  if (head.includes(":")) {
    const i = head.indexOf(":");
    storage = head.slice(0, i);
    volume = head.slice(i + 1);
  } else if (head.startsWith("/")) {
    path = head;
  } else {
    volume = head;
  }
  return { storage, volume, path, options, raw: s };
}

function humanDiskSize(size: string | undefined) {
  if (!size) return "";
  const m = String(size).match(/^(\d+(?:\.\d+)?)([KMGTP]?)B?$/i);
  if (!m) return String(size);
  return `${m[1]} ${(m[2] || "").toUpperCase() || ""}B`.replace(" B", " B");
}

function GuestInfoPanel({ config, isLxc }: { config: Record<string, unknown>; isLxc: boolean }) {
  const unpriv = config.unprivileged == 1 || config.unprivileged === true;
  const privKnown = config.unprivileged != null;

  const diskKeys = Object.keys(config || {})
    .filter((k) =>
      k === "rootfs" || k === "efidisk0" || k === "tpmstate0" ||
      /^(scsi|sata|ide|virtio|mp)\d+$/i.test(k),
    )
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));

  const netKeys = Object.keys(config || {}).filter((k) => /^net\d+$/i.test(k)).sort();

  return (
    <div className="pve-gc-info-panel">
      {isLxc && privKnown ? (
        <div className="pve-gc-info-block">
          <div className="pve-gc-info-title">Container Configuration</div>
          <div className="pve-gc-info-label">Privilege Level</div>
          <span className={`pve-gc-info-pill ${unpriv ? "pve-gc-info-pill--ok" : "pve-gc-info-pill--warn"}`}>
            {unpriv ? "Unprivileged" : "Privileged"}
          </span>
        </div>
      ) : null}

      {diskKeys.length ? (
        <div className="pve-gc-info-block">
          <div className="pve-gc-info-title">Hardware &amp; Storage</div>
          <div className="pve-gc-info-stack">
            {diskKeys.map((key) => {
              const d = parseDiskSpec(String(config[key] || ""));
              const label = key === "rootfs"
                ? "Root Filesystem"
                : key.startsWith("mp")
                  ? `Mount Point ${key.replace("mp", "")}`
                  : key.toUpperCase().replace(/(\d+)/, " $1");
              const size = humanDiskSize(d.options.size);
              return (
                <div className="pve-gc-disk" key={key}>
                  <div className="pve-gc-disk-top">
                    <span className="pve-gc-disk-name">{label}</span>
                    {d.storage ? <span className="pve-gc-disk-store">{d.storage}</span> : null}
                    {size ? <span className="pve-gc-disk-size">{size}</span> : null}
                  </div>
                  <div className="pve-gc-disk-grid">
                    {d.volume ? <div><span>Volume</span><b>{d.volume}</b></div> : null}
                    {d.path ? <div><span>Path</span><b>{d.path}</b></div> : null}
                    {d.options.mp ? <div><span>Mount</span><b>{d.options.mp}</b></div> : null}
                  </div>
                  <details className="pve-gc-raw">
                    <summary>Raw config</summary>
                    <code>{d.raw}</code>
                  </details>
                </div>
              );
            })}
          </div>
        </div>
      ) : null}

      {netKeys.length ? (
        <div className="pve-gc-info-block">
          <div className="pve-gc-info-title">Network</div>
          <div className="pve-gc-info-stack">
            {netKeys.map((key) => {
              const raw = String(config[key] || "");
              const p = parseKvList(raw);
              const idx = key.replace(/net/i, "");
              const title = p.name ? `Network Interface ${idx} (${p.name})` : `Network Interface ${idx}`;
              return (
                <div className="pve-gc-disk" key={key}>
                  <div className="pve-gc-disk-top">
                    <span className="pve-gc-disk-name">{title}</span>
                  </div>
                  <div className="pve-gc-disk-grid">
                    {p.bridge ? <div><span>Bridge</span><b>{p.bridge}</b></div> : null}
                    {p.ip ? <div><span>IP</span><b>{p.ip}</b></div> : null}
                    {p.gw ? <div><span>Gateway</span><b>{p.gw}</b></div> : null}
                    {p.hwaddr || p.macaddr ? <div><span>MAC</span><b>{p.hwaddr || p.macaddr}</b></div> : null}
                    {p.type || p.model ? <div><span>Type</span><b>{p.type || p.model}</b></div> : null}
                    {p.mtu ? <div><span>MTU</span><b>{p.mtu}</b></div> : null}
                    {p.firewall != null ? <div><span>Firewall</span><b>{p.firewall}</b></div> : null}
                  </div>
                  <details className="pve-gc-raw">
                    <summary>Raw config</summary>
                    <code>{raw}</code>
                  </details>
                </div>
              );
            })}
          </div>
        </div>
      ) : null}

      {config.hostname || config.nameserver || config.searchdomain || config.ostype || config.arch || config.onboot != null || config.tags ? (
        <div className="pve-gc-info-block">
          <div className="pve-gc-info-title">System Info</div>
          <div className="pve-gc-disk-grid">
            {config.hostname ? <div><span>Hostname</span><b>{String(config.hostname)}</b></div> : null}
            {config.ostype ? <div><span>OS Type</span><b>{String(config.ostype)}</b></div> : null}
            {config.arch ? <div><span>Arch</span><b>{String(config.arch)}</b></div> : null}
            {config.onboot != null ? <div><span>On boot</span><b>{String(config.onboot)}</b></div> : null}
            {config.tags ? <div><span>Tags</span><b>{String(config.tags)}</b></div> : null}
            {config.nameserver ? <div><span>DNS Nameservers</span><b>{String(config.nameserver)}</b></div> : null}
            {config.searchdomain ? <div><span>Search Domain</span><b>{String(config.searchdomain)}</b></div> : null}
          </div>
        </div>
      ) : null}
    </div>
  );
}
