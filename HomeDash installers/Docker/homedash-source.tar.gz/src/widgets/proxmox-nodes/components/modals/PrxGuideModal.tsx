"use client";

import { useCallback, useState } from "react";
import { ModalPortal, useEscapeClose } from "./ModalPortal";

export function PrxGuideModal({
  instanceId,
  label,
  prxHref,
  rejected,
  onClose,
  onSaved,
}: {
  instanceId: string;
  label: string;
  prxHref: string | null;
  rejected?: boolean;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [token, setToken] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const shortLived = looksLikeSessionJwt(token);
  const close = useCallback(() => onClose(), [onClose]);
  useEscapeClose(close);

  async function save() {
    const value = token.trim().replace(/^["']|["']$/g, "");
    if (!value) {
      setError("Paste an API Access Token first");
      return;
    }
    if (shortLived && !window.confirm("This looks like a ~24h session JWT. Save anyway? Prefer a 365-day API Access Token.")) {
      return;
    }
    setBusy(true);
    setError("");
    try {
      const current = await fetch(`/api/widgets/${encodeURIComponent(instanceId)}/config`).then((r) => r.json());
      const response = await fetch(`/api/widgets/${encodeURIComponent(instanceId)}/config`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...(current || {}), prxToken: value }),
      });
      const json = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(json.error || "Failed to save ProxMenux token");
      onSaved();
      onClose();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Failed to save token");
    } finally {
      setBusy(false);
    }
  }

  return (
    <ModalPortal>
      <div className="pve-prx-guide-backdrop" onClick={close} role="presentation">
        <div
          className="pve-prx-guide"
          onClick={(e) => e.stopPropagation()}
          role="dialog"
          aria-modal="true"
          aria-labelledby="pve-prx-guide-title"
        >
          <div className="pve-prx-guide-hdr">
            <div>
              <div className="pve-prx-guide-kicker">ProxMenux Monitor · {label}</div>
              <h3 id="pve-prx-guide-title">{rejected ? `API token needed for ${label}` : `Add API token for ${label}`}</h3>
            </div>
            <button type="button" className="pve-prx-guide-x" onClick={close} aria-label="Close">×</button>
          </div>
          <p className="pve-prx-guide-lead">
            Each Proxmox node has its own MONITOR. Paste the <strong>365-day API Access Token</strong> generated
            on <strong>{label}</strong> only — stored per node and will not overwrite other servers.
          </p>
          <ol className="pve-prx-guide-steps">
            <li>
              <span className="pve-prx-guide-num">1</span>
              <div>
                <strong>Open MONITOR</strong>
                <div className="pve-prx-guide-sub">
                  {prxHref ? (
                    <a href={prxHref} target="_blank" rel="noopener noreferrer">
                      {prxHref.replace(/^https?:\/\//, "")} ↗
                    </a>
                  ) : (
                    "Use the MONITOR button on this node"
                  )}{" "}
                  and sign in.
                </div>
              </div>
            </li>
            <li>
              <span className="pve-prx-guide-num">2</span>
              <div>
                <strong>Settings → API Access Tokens</strong>
                <div className="pve-prx-guide-sub">
                  Enter your MONITOR password (and 2FA if enabled), name it e.g. <em>Homepage</em>, then click{" "}
                  <strong>Generate Token</strong>.
                </div>
              </div>
            </li>
            <li>
              <span className="pve-prx-guide-num">3</span>
              <div>
                <strong>Copy the token immediately</strong>
                <div className="pve-prx-guide-sub">
                  It is shown once. It should start with <code>eyJ…</code> and last about <strong>365 days</strong>.
                  Do not use a 24-hour login session JWT.
                </div>
              </div>
            </li>
            <li>
              <span className="pve-prx-guide-num">4</span>
              <div>
                <strong>Paste it below</strong>
                <textarea
                  className="pve-prx-guide-input"
                  rows={3}
                  spellCheck={false}
                  placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9… (API Access Token)"
                  value={token}
                  onChange={(e) => setToken(e.target.value)}
                  onKeyDown={(e) => {
                    if ((e.metaKey || e.ctrlKey) && e.key === "Enter") save();
                  }}
                />
                {shortLived ? (
                  <div className="pve-prx-guide-sub" data-prx-warn style={{ color: "#fb923c", marginTop: 8 }}>
                    This looks like a ~24h session JWT. Generate an API Access Token in Settings instead (365 days).
                  </div>
                ) : null}
                {error ? <div className="pve-prx-guide-sub" style={{ color: "#f87171", marginTop: 8 }}>{error}</div> : null}
              </div>
            </li>
          </ol>
          <div className="pve-prx-guide-ftr">
            <button type="button" className="pve-prx-guide-btn pve-prx-guide-btn--ghost" onClick={close}>Cancel</button>
            <button type="button" className="pve-prx-guide-btn pve-prx-guide-btn--ok" disabled={busy} onClick={save}>
              {busy ? "Saving…" : "Save & connect"}
            </button>
          </div>
        </div>
      </div>
    </ModalPortal>
  );
}

function looksLikeSessionJwt(raw: string) {
  const v = raw.trim().replace(/^["']|["']$/g, "");
  if (!v.startsWith("eyJ")) return false;
  try {
    const payload = JSON.parse(atob(v.split(".")[1] || ""));
    const exp = Number(payload.exp || 0);
    const iat = Number(payload.iat || 0);
    if (!exp || !iat) return false;
    return exp - iat < 60 * 60 * 48;
  } catch {
    return false;
  }
}
