"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ModalPortal } from "./ModalPortal";

/** ProxMenux WS script runner (GPU switch / Lynis install). */
export function ScriptRunnerModal({
  instanceId,
  title,
  scriptPath,
  params,
  onClose,
}: {
  instanceId: string;
  title: string;
  scriptPath: string;
  params?: Record<string, string>;
  onClose: () => void;
}) {
  const [error, setError] = useState("");
  const [status, setStatus] = useState("Connecting…");
  const [lines, setLines] = useState<Array<{ text: string; cls?: string }>>([]);
  const [prompt, setPrompt] = useState<{ id?: string; title?: string; message?: string; options?: Array<{ id?: string; label?: string; value?: string }> } | null>(null);
  const logRef = useRef<HTMLDivElement | null>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const paramsKey = JSON.stringify(params || {});
  const close = useCallback(() => onClose(), [onClose]);

  useEffect(() => {
    let cancelled = false;
    let socket: WebSocket | null = null;
    const runParams = JSON.parse(paramsKey) as Record<string, string>;
    (async () => {
      try {
        const ticketRes = await fetch("/api/widgets/proxmox-nodes/terminal/ticket", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ instance: instanceId, mode: "host" }),
        });
        const ticketJson = await ticketRes.json();
        if (!ticketRes.ok) throw new Error(ticketJson.error || "Ticket failed");
        if (cancelled) return;

        const sessionId = `hd-${Date.now()}`;
        const base = new URL(ticketJson.base || ticketJson.prxBase || "http://localhost");
        const scheme = base.protocol === "https:" ? "wss:" : "ws:";
        const ticket = ticketJson.scriptTicket || ticketJson.ticket;
        const wsUrl = `${scheme}//${base.host}/ws/script/${encodeURIComponent(sessionId)}?ticket=${encodeURIComponent(ticket)}`;
        socket = new WebSocket(wsUrl);
        socketRef.current = socket;
        socket.onopen = () => {
          setStatus("Running…");
          socket?.send(JSON.stringify({
            script_path: scriptPath.startsWith("/") ? scriptPath : `/usr/local/share/proxmenux/scripts/${scriptPath}`,
            params: Object.keys(runParams).length ? runParams : { EXECUTION_MODE: "web" },
          }));
        };
        socket.onmessage = (event) => {
          const raw = String(event.data || "");
          try {
            const msg = JSON.parse(raw) as {
              type?: string;
              data?: string;
              message?: string;
              interaction?: { id?: string; title?: string; message?: string; options?: Array<{ id?: string; label?: string; value?: string }> };
            };
            if (msg.type === "web_interaction" && msg.interaction) {
              setPrompt(msg.interaction);
              return;
            }
            const text = msg.data || msg.message || raw;
            if (text) setLines((prev) => [...prev, { text: String(text), cls: msg.type === "error" ? "is-err" : undefined }]);
          } catch {
            setLines((prev) => [...prev, { text: raw }]);
          }
        };
        socket.onerror = () => {
          setError("Script WebSocket error");
          setStatus("Error");
        };
        socket.onclose = () => setStatus((s) => (s === "Running…" ? "Finished" : s));
      } catch (cause) {
        if (!cancelled) {
          setError(cause instanceof Error ? cause.message : "Script runner failed");
          setStatus("Error");
        }
      }
    })();
    return () => {
      cancelled = true;
      socket?.close();
      socketRef.current = null;
    };
  }, [instanceId, scriptPath, paramsKey]);

  useEffect(() => {
    logRef.current?.scrollTo(0, logRef.current.scrollHeight);
  }, [lines]);

  function answer(value: string) {
    const socket = socketRef.current;
    if (socket?.readyState === WebSocket.OPEN && prompt?.id) {
      socket.send(JSON.stringify({ type: "interaction_response", id: prompt.id, value }));
    }
    setPrompt(null);
  }

  return (
    <ModalPortal>
      <div className="pve-hw-swrun-backdrop" role="presentation">
        <div className="pve-hw-swrun-modal" role="dialog" aria-modal="true">
          <div className="pve-hw-swrun-hdr">
            <div>
              <div className="pve-hw-swrun-title">{title}</div>
              <div className="pve-hw-swrun-sub">{scriptPath}</div>
            </div>
            <button type="button" className="pve-hw-gpu-close" aria-label="Close" onClick={close}>×</button>
          </div>
          <div className="pve-hw-swrun-status">{status}</div>
          {error ? <div className="pve-hw-swrun-status" style={{ color: "#fca5a5" }}>{error}</div> : null}
          <div className="pve-hw-swrun-log" ref={logRef}>
            {lines.length
              ? lines.map((line, i) => <div key={i} className={line.cls}>{line.text}</div>)
              : <div className="is-meta">Starting script…</div>}
          </div>
          {prompt ? (
            <div className="pve-hw-swrun-prompt">
              <div className="pve-hw-swrun-prompt-title">{prompt.title || "Confirm"}</div>
              <div className="pve-hw-swrun-prompt-msg">{prompt.message || ""}</div>
              <div className="pve-hw-swrun-prompt-actions">
                {(prompt.options || [{ label: "OK", value: "ok" }, { label: "Cancel", value: "cancel" }]).map((opt, i) => (
                  <button
                    key={i}
                    type="button"
                    className="pve-hw-gpu-sw-btn"
                    onClick={() => answer(String(opt.value || opt.label || "ok"))}
                  >
                    {opt.label || opt.value || "OK"}
                  </button>
                ))}
              </div>
            </div>
          ) : null}
          <div className="pve-hw-swrun-ftr">
            <button type="button" className="pve-hw-gpu-sw-btn" onClick={close}>Close</button>
          </div>
        </div>
      </div>
    </ModalPortal>
  );
}
