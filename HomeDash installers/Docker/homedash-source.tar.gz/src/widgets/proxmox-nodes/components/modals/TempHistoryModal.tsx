"use client";

import { useCallback, useEffect, useId, useMemo, useState } from "react";
import { ModalPortal, useEscapeClose } from "./ModalPortal";

type TempPoint = { temp: number; ts: unknown };

const RANGES = [
  { id: "hour", label: "1 Hour" },
  { id: "day", label: "24 Hours" },
  { id: "week", label: "7 Days" },
  { id: "month", label: "30 Days" },
] as const;

export function TempHistoryModal({
  instanceId,
  disk,
  liveTemp,
  model,
  onClose,
}: {
  instanceId: string;
  disk: Record<string, unknown>;
  liveTemp: number | null;
  model: string;
  onClose: () => void;
}) {
  const [tf, setTf] = useState<(typeof RANGES)[number]["id"]>("day");
  const [payload, setPayload] = useState<unknown>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const close = useCallback(() => onClose(), [onClose]);
  useEscapeClose(close);
  const name = String(disk.devpath || disk.name || "").replace(/^\/dev\//, "");
  const tempOk = liveTemp == null || liveTemp < 60;
  const color = liveTemp == null ? "#22c55e" : (tempOk ? "#22c55e" : "#f87171");

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      setError("");
      try {
        const res = await fetch(
          `/api/widgets/proxmox-nodes/proxmenux?instance=${encodeURIComponent(instanceId)}&kind=temp&disk=${encodeURIComponent(name)}&timeframe=${encodeURIComponent(tf)}`,
        );
        const json = await res.json();
        if (!cancelled) {
          if (!res.ok) throw new Error(json.error || "Temperature history unavailable");
          setPayload(json);
        }
      } catch (cause) {
        if (!cancelled) setError(cause instanceof Error ? cause.message : "Failed to load temperature history");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [instanceId, name, tf]);

  const points = useMemo(() => normalizeTempHistoryPoints(payload), [payload]);
  const stats = (payload as { stats?: { min?: number; avg?: number; max?: number } } | null)?.stats;

  return (
    <ModalPortal>
      <div className="pve-temp-backdrop" onClick={close} role="presentation">
        <div className="pve-temp-modal" onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true">
          <div className="pve-temp-hdr">
            <div>
              <div className="pve-temp-title">Temperature History</div>
              <div className="pve-temp-sub">{String(disk.devpath || name)} · {model}</div>
            </div>
            <button type="button" className="pve-disk-close" aria-label="Close" onClick={close}>×</button>
          </div>
          <div className="pve-temp-live" style={{ color: liveTemp == null ? undefined : color }}>
            {liveTemp != null ? `${Math.round(liveTemp)}°C` : "—"}
            <span>{liveTemp == null || tempOk ? "Normal" : "Hot"}</span>
          </div>
          <div className="pve-temp-ranges" role="tablist">
            {RANGES.map((r) => (
              <button
                key={r.id}
                type="button"
                className={`pve-temp-range${r.id === tf ? " is-active" : ""}`}
                onClick={() => setTf(r.id)}
              >
                {r.label}
              </button>
            ))}
          </div>
          <div className="pve-temp-body">
            {loading ? "Loading…" : null}
            {!loading && error ? <div className="pve-disk-temp-hist-empty">{error}</div> : null}
            {!loading && !error ? <TempHistoryChart points={points} color={color} stats={stats} /> : null}
          </div>
        </div>
      </div>
    </ModalPortal>
  );
}

export function TempSparkline({
  payload,
  color = "#22c55e",
  w = 320,
  h = 40,
}: {
  payload: unknown;
  color?: string;
  w?: number;
  h?: number;
}) {
  const gid = useId().replace(/:/g, "");
  const points = normalizeTempHistoryPoints(payload);
  if (points.length < 2) return <div className="pve-disk-temp-spark-empty" />;
  const temps = points.map((p) => p.temp);
  const minT = Math.min(...temps);
  const maxT = Math.max(...temps);
  const span = Math.max(1, maxT - minT);
  const padY = 3;
  const coords = temps.map((t, i) => {
    const x = (i / (temps.length - 1)) * w;
    const y = h - padY - ((t - minT) / span) * (h - padY * 2);
    return [x, y] as const;
  });
  const line = coords.map((c, i) => `${i ? "L" : "M"}${c[0].toFixed(2)},${c[1].toFixed(2)}`).join(" ");
  const area = `${line} L${w},${h} L0,${h} Z`;
  return (
    <svg className="pve-disk-temp-svg" viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" width="100%" height={h} aria-hidden>
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity={0.35} />
          <stop offset="100%" stopColor={color} stopOpacity={0.02} />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#${gid})`} stroke="none" />
      <path d={line} fill="none" stroke={color} strokeWidth="1.6" />
    </svg>
  );
}

function TempHistoryChart({
  points,
  color,
  stats,
}: {
  points: TempPoint[];
  color: string;
  stats?: { min?: number; avg?: number; max?: number };
}) {
  const gid = useId().replace(/:/g, "");
  if (points.length < 2) {
    return <div className="pve-disk-temp-hist-empty">No temperature samples for this range.</div>;
  }
  const w = 640;
  const h = 180;
  const temps = points.map((p) => p.temp);
  const minT = stats?.min != null ? Number(stats.min) : Math.min(...temps);
  const maxT = stats?.max != null ? Number(stats.max) : Math.max(...temps);
  const avgT = stats?.avg != null ? Number(stats.avg) : temps.reduce((a, b) => a + b, 0) / temps.length;
  const span = Math.max(1, maxT - minT);
  const pad = { t: 12, r: 8, b: 22, l: 36 };
  const iw = w - pad.l - pad.r;
  const ih = h - pad.t - pad.b;
  const coords = temps.map((t, i) => {
    const x = pad.l + (i / (temps.length - 1)) * iw;
    const y = pad.t + ih - ((t - minT) / span) * ih;
    return [x, y] as const;
  });
  const line = coords.map((c, i) => `${i ? "L" : "M"}${c[0].toFixed(2)},${c[1].toFixed(2)}`).join(" ");
  const area = `${line} L${pad.l + iw},${pad.t + ih} L${pad.l},${pad.t + ih} Z`;
  return (
    <>
      <div className="pve-disk-temp-hist-stats">
        <div><span>Min</span><b>{minT.toFixed(0)}°C</b></div>
        <div><span>Avg</span><b>{avgT.toFixed(1)}°C</b></div>
        <div><span>Max</span><b>{maxT.toFixed(0)}°C</b></div>
        <div><span>Samples</span><b>{temps.length}</b></div>
      </div>
      <svg viewBox={`0 0 ${w} ${h}`} width="100%" height={180} className="pve-disk-temp-hist-svg" aria-hidden>
        <defs>
          <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity={0.28} />
            <stop offset="100%" stopColor={color} stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <text x="4" y={pad.t + 4} fill="rgba(255,255,255,0.35)" fontSize="10">{maxT.toFixed(0)}°</text>
        <text x="4" y={pad.t + ih} fill="rgba(255,255,255,0.35)" fontSize="10">{minT.toFixed(0)}°</text>
        <path d={area} fill={`url(#${gid})`} />
        <path d={line} fill="none" stroke={color} strokeWidth="2" />
      </svg>
    </>
  );
}

export function normalizeTempHistoryPoints(payload: unknown): TempPoint[] {
  const obj = payload as { data?: unknown; points?: unknown; history?: unknown } | unknown[] | null;
  const raw = (obj && !Array.isArray(obj)
    ? (obj.data || obj.points || obj.history)
    : obj) || [];
  if (!Array.isArray(raw)) return [];
  return raw.map((p) => {
    if (typeof p === "number") return { temp: p, ts: null };
    if (!p || typeof p !== "object") return null;
    const row = p as Record<string, unknown>;
    const t = firstFinite(row.temp, row.temperature, row.value, row.y);
    const ts = row.ts ?? row.timestamp ?? row.time ?? row.t ?? null;
    return Number.isFinite(t as number) ? { temp: t as number, ts } : null;
  }).filter(Boolean) as TempPoint[];
}

function firstFinite(...vals: unknown[]) {
  for (const v of vals) {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return NaN;
}
