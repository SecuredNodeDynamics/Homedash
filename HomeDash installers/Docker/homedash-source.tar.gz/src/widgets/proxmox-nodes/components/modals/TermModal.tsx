"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { Guest, GuestUpdateCheck } from "../../types";
import { parseAptUpgradableList } from "../../live-updates";
import { ModalPortal, useEscapeClose } from "./ModalPortal";

/**
 * One command to auto-run inside the guest shell once the terminal connects
 * (guest mode only — runs after `pct enter <vmid>` has settled).
 */
export type TermAutoRunStep = {
  /** Shown in the status banner while this step runs. */
  label: string;
  /** Shell command, without a trailing newline — a sentinel + exit code is appended. */
  cmd: string;
  timeoutMs?: number;
  /** When "aptUpgradable", the step's output is parsed into a GuestUpdateCheck. */
  parse?: "aptUpgradable";
};

export type TermAutoRunResult =
  | { ok: true; updateCheck?: GuestUpdateCheck }
  | { ok: false; error: string };

export type TermAutoRun = {
  steps: TermAutoRunStep[];
  onDone?: (result: TermAutoRunResult) => void;
};

const TERM_THEME = {
  background: "#070b12",
  foreground: "#e8eef7",
  cursor: "#7dd3fc",
  cursorAccent: "#070b12",
  selectionBackground: "rgba(56, 189, 248, 0.35)",
  selectionForeground: "#ffffff",
  black: "#0f172a",
  red: "#f87171",
  green: "#4ade80",
  yellow: "#fbbf24",
  blue: "#60a5fa",
  magenta: "#c4b5fd",
  cyan: "#22d3ee",
  white: "#e2e8f0",
  brightBlack: "#64748b",
  brightRed: "#fca5a5",
  brightGreen: "#86efac",
  brightYellow: "#fde68a",
  brightBlue: "#93c5fd",
  brightMagenta: "#ddd6fe",
  brightCyan: "#67e8f9",
  brightWhite: "#f8fafc",
} as const;

/** Fullscreen + viewport pin for phones and tablets (match Docker console). */
const TERM_MOBILE_MQ = "(max-width: 900px)";
/** position:fixed body lock only on phones — tablets race the open gesture. */
const TERM_PHONE_MQ = "(max-width: 640px)";

type XtermLike = {
  clear: () => void;
  dispose: () => void;
  write: (s: string) => void;
  writeln: (s: string) => void;
  focus: () => void;
  cols: number;
  rows: number;
  onData: (cb: (d: string) => void) => { dispose: () => void };
};

export function TermModal({
  instanceId,
  label,
  mode,
  guest,
  autoRun,
  onClose,
}: {
  instanceId: string;
  label?: string;
  mode: "host" | "guest";
  guest?: Guest | null;
  /** Optional command sequence to run automatically once the guest shell is ready. */
  autoRun?: TermAutoRun;
  onClose: () => void;
}) {
  const [error, setError] = useState("");
  const [status, setStatus] = useState<"connecting" | "online" | "offline">("connecting");
  const [extUrl, setExtUrl] = useState("");
  const [autoStatus, setAutoStatus] = useState("");
  const autoRunRef = useRef<TermAutoRun | undefined>(autoRun);
  autoRunRef.current = autoRun;
  const mountRef = useRef<HTMLDivElement | null>(null);
  const modalRef = useRef<HTMLDivElement | null>(null);
  const backdropRef = useRef<HTMLDivElement | null>(null);
  const termRef = useRef<XtermLike | null>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const close = useCallback(() => onClose(), [onClose]);
  useEscapeClose(close);

  // Freeze background scroll on phones/tablets. position:fixed is phones-only —
  // on tablets it races the Open Terminal tap and the modal never appears.
  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia(TERM_MOBILE_MQ).matches) {
      return;
    }
    const isPhone = window.matchMedia(TERM_PHONE_MQ).matches;
    const scrollY = window.scrollY;
    const html = document.documentElement;
    const prev = {
      htmlOverflow: html.style.overflow,
      bodyOverflow: document.body.style.overflow,
      position: document.body.style.position,
      top: document.body.style.top,
      width: document.body.style.width,
      touchAction: document.body.style.touchAction,
    };
    const lock = () => {
      html.style.overflow = "hidden";
      document.body.style.overflow = "hidden";
      document.body.style.touchAction = "none";
      document.body.classList.add("hd-term-open");
      if (isPhone) {
        document.body.style.position = "fixed";
        document.body.style.top = `-${scrollY}px`;
        document.body.style.width = "100%";
      }
      if (modalRef.current) modalRef.current.style.height = "";
    };
    // Defer past the opening click/tap (tablets need a beat longer).
    const timer = window.setTimeout(lock, isPhone ? 0 : 50);
    return () => {
      window.clearTimeout(timer);
      html.style.overflow = prev.htmlOverflow;
      document.body.style.overflow = prev.bodyOverflow;
      document.body.style.position = prev.position;
      document.body.style.top = prev.top;
      document.body.style.width = prev.width;
      document.body.style.touchAction = prev.touchAction;
      document.body.classList.remove("hd-term-open");
      if (isPhone) window.scrollTo(0, scrollY);
    };
  }, []);

  // Pin backdrop to the *visual* viewport so it sits in the visible area above
  // the soft keyboard (and tracks iOS Safari address-bar chrome).
  useEffect(() => {
    const backdrop = backdropRef.current;
    if (!backdrop) return;
    if (typeof window === "undefined" || !window.matchMedia(TERM_MOBILE_MQ).matches) {
      return;
    }
    const vv = window.visualViewport;
    let lastFitH = 0;

    const applyBox = (top: number, left: number, width: number, height: number) => {
      backdrop.style.position = "fixed";
      backdrop.style.top = `${top}px`;
      backdrop.style.left = `${left}px`;
      backdrop.style.width = `${width}px`;
      backdrop.style.height = `${height}px`;
      backdrop.style.right = "auto";
      backdrop.style.bottom = "auto";
      backdrop.style.inset = "auto";
    };

    const sync = () => {
      const scale = vv?.scale ?? 1;
      // Don't chase focus-zoom — it shrinks the whole UI.
      if (scale < 0.99 || scale > 1.01) {
        applyBox(0, 0, window.innerWidth, window.innerHeight);
        return;
      }
      const top = vv?.offsetTop ?? 0;
      const height = Math.max(120, Math.round(vv?.height ?? window.innerHeight));
      applyBox(top, 0, window.innerWidth, height);
      if (Math.abs(height - lastFitH) > 12) {
        lastFitH = height;
        window.dispatchEvent(new Event("resize"));
      }
    };
    sync();
    vv?.addEventListener("resize", sync);
    vv?.addEventListener("scroll", sync);
    window.addEventListener("resize", sync);
    window.addEventListener("orientationchange", sync);
    return () => {
      vv?.removeEventListener("resize", sync);
      vv?.removeEventListener("scroll", sync);
      window.removeEventListener("resize", sync);
      window.removeEventListener("orientationchange", sync);
      backdrop.style.position = "";
      backdrop.style.top = "";
      backdrop.style.left = "";
      backdrop.style.width = "";
      backdrop.style.height = "";
      backdrop.style.right = "";
      backdrop.style.bottom = "";
      backdrop.style.inset = "";
    };
  }, []);

  useEffect(() => {
    if (!mountRef.current) return;
    let cancelled = false;
    let socket: WebSocket | null = null;
    let term: XtermLike | null = null;
    let onResize: (() => void) | null = null;
    let dataDisp: { dispose: () => void } | null = null;
    let fit: { fit: () => void } | null = null;
    // Auto-run bookkeeping (guest mode only) — mirrors the sentinel-marker
    // pattern used by BulkUpdateModal / liveRecheckRunningLxcs.
    let autoBuffer = "";
    let autoWsClosed = false;
    const autoWaiters: Array<() => void> = [];

    function waitForMarker(
      marker: string,
      timeoutMs: number,
    ): Promise<{ status: "ok"; code: number } | { status: "timeout" | "closed" }> {
      const re = new RegExp(`${marker.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(\\d+)`);
      const tryMatch = (): number | null => {
        const m = autoBuffer.match(re);
        return m ? Number(m[1]) : null;
      };
      return new Promise((resolve) => {
        const immediate = tryMatch();
        if (immediate != null && Number.isFinite(immediate)) {
          resolve({ status: "ok", code: immediate });
          return;
        }
        let settled = false;
        const finish = (result: { status: "ok"; code: number } | { status: "timeout" | "closed" }) => {
          if (settled) return;
          settled = true;
          window.clearTimeout(timer);
          const idx = autoWaiters.indexOf(onChunk);
          if (idx >= 0) autoWaiters.splice(idx, 1);
          resolve(result);
        };
        const timer = window.setTimeout(() => finish({ status: "timeout" }), timeoutMs);
        const onChunk = () => {
          const code = tryMatch();
          if (code != null && Number.isFinite(code)) {
            finish({ status: "ok", code });
            return;
          }
          if (autoWsClosed) finish({ status: "closed" });
        };
        autoWaiters.push(onChunk);
      });
    }

    async function waitForGuestShellReady(
      activeSocket: WebSocket,
      vmid: number | string | undefined,
    ): Promise<boolean> {
      // `pct enter` swaps the pty's backing process; commands sent before that
      // swap finishes get echoed (the display already received the bytes) but
      // are dropped rather than executed. Probe with a disposable echo and
      // retry until the *guest* shell actually answers instead of guessing a
      // fixed settle time.
      const attempts = 8;
      for (let attempt = 0; attempt < attempts; attempt += 1) {
        if (cancelled) return false;
        if (activeSocket.readyState !== WebSocket.OPEN) return false;
        const probe = `__HD_READY_${vmid ?? "x"}_${attempt}_${Date.now()}__`;
        autoBuffer = "";
        activeSocket.send(`echo ${probe}$?\r`);
        const result = await waitForMarker(probe, 1500);
        if (cancelled) return false;
        if (result.status === "ok") return true;
      }
      return false;
    }

    async function runAutoRun(activeSocket: WebSocket, vmid: number | string | undefined) {
      const spec = autoRunRef.current;
      if (!spec || !spec.steps.length) return;
      setAutoStatus("Waiting for container shell…");
      const ready = await waitForGuestShellReady(activeSocket, vmid);
      if (cancelled) return;
      if (!ready) {
        setAutoStatus("Failed — container shell did not respond");
        spec.onDone?.({ ok: false, error: "Container shell did not respond" });
        return;
      }
      autoBuffer = "";
      let lastBody = "";
      let failMsg = "";
      let lastStep: TermAutoRunStep | null = null;
      for (const step of spec.steps) {
        if (cancelled) return;
        lastStep = step;
        setAutoStatus(step.label);
        if (activeSocket.readyState !== WebSocket.OPEN) {
          failMsg = "Terminal disconnected";
          break;
        }
        const marker = `__HD_AUTORUN_${vmid ?? "x"}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}__`;
        autoBuffer = "";
        activeSocket.send(`${step.cmd}; echo ${marker}$?\r`);
        const result = await waitForMarker(marker, step.timeoutMs || 20 * 60 * 1000);
        if (cancelled) return;
        if (result.status !== "ok") {
          failMsg = result.status === "timeout" ? `${step.label} timed out` : "Terminal closed";
          break;
        }
        const idx = autoBuffer.search(
          new RegExp(`${marker.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\d+`),
        );
        lastBody = idx >= 0 ? autoBuffer.slice(0, idx) : autoBuffer;
        if (result.code !== 0) {
          failMsg = `${step.label} exited with code ${result.code}`;
          break;
        }
      }
      if (cancelled) return;
      if (failMsg) {
        setAutoStatus(`Failed — ${failMsg}`);
        spec.onDone?.({ ok: false, error: failMsg });
        return;
      }
      let updateCheck: GuestUpdateCheck | undefined;
      if (lastStep?.parse === "aptUpgradable") {
        const packages = parseAptUpgradableList(lastBody);
        updateCheck = {
          available: packages.length > 0,
          count: packages.length,
          security_count: packages.filter((p) => p.security).length,
          last_check: new Date().toISOString(),
          packages,
        };
      }
      setAutoStatus("Done");
      spec.onDone?.({ ok: true, updateCheck });
    }

    (async () => {
      try {
        const [{ Terminal }, { FitAddon }] = await Promise.all([
          import("@xterm/xterm"),
          import("@xterm/addon-fit"),
        ]);
        // @ts-expect-error xterm CSS has no type declarations
        await import("@xterm/xterm/css/xterm.css");
        if (cancelled || !mountRef.current) return;

        const mobile = window.matchMedia(TERM_MOBILE_MQ).matches;
        const fontSize = mobile ? 14 : 15;
        const terminal = new Terminal({
          convertEol: true,
          cursorBlink: true,
          fontSize,
          fontFamily: '"MesloLGS NF", "FiraCode Nerd Font", "JetBrainsMono Nerd Font", "Hack Nerd Font", ui-monospace, Menlo, Consolas, monospace',
          fontWeight: "500",
          fontWeightBold: "700",
          scrollback: 2000,
          theme: TERM_THEME,
        });
        const fitAddon = new FitAddon();
        fit = fitAddon;
        terminal.loadAddon(fitAddon);
        terminal.open(mountRef.current);
        const helper = mountRef.current.querySelector(".xterm-helper-textarea") as HTMLTextAreaElement | null;
        if (helper) helper.style.fontSize = "16px";
        fitAddon.fit();
        // Autofocus opens the soft keyboard; wait for a tap on phones/tablets.
        if (!mobile) terminal.focus();
        term = terminal as unknown as XtermLike;
        termRef.current = term;

        onResize = () => {
          const scale = window.visualViewport?.scale ?? 1;
          if (scale < 0.99 || scale > 1.01) return;
          fitAddon.fit();
          if (socket?.readyState === WebSocket.OPEN) {
            socket.send(JSON.stringify({ type: "resize", cols: terminal.cols, rows: terminal.rows }));
          }
        };
        window.addEventListener("resize", onResize);
        window.visualViewport?.addEventListener("resize", onResize);

        const response = await fetch("/api/widgets/proxmox-nodes/terminal/ticket", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            instance: instanceId,
            mode,
            type: guest?.kind,
            vmid: guest?.id,
          }),
        });
        const json = await response.json();
        if (!response.ok) throw new Error(json.error || "Terminal ticket failed");
        if (cancelled) return;
        if (json.consoleUrl) setExtUrl(String(json.consoleUrl));

        socket = new WebSocket(json.wsUrl);
        socketRef.current = socket;
        socket.onopen = () => {
          setStatus("online");
          fitAddon.fit();
          socket?.send(JSON.stringify({ type: "resize", cols: terminal.cols, rows: terminal.rows }));
          if (json.enterCmd) socket?.send(json.enterCmd);
          if (autoRunRef.current && mode === "guest" && socket) {
            void runAutoRun(socket, guest?.id);
          }
        };
        socket.onmessage = (event) => {
          const data = typeof event.data === "string" ? event.data : "";
          if (!data) return;
          let text = data;
          try {
            const parsed = JSON.parse(data) as { type?: string; data?: string };
            if (parsed.type === "pong") return;
            if (parsed.data != null) text = String(parsed.data);
          } catch {
            // raw
          }
          terminal.write(text);
          autoBuffer += text;
          autoWaiters.slice().forEach((w) => w());
        };
        socket.onerror = () => {
          setError("WebSocket error");
          setStatus("offline");
        };
        socket.onclose = () => {
          setStatus("offline");
          autoWsClosed = true;
          autoWaiters.slice().forEach((w) => w());
        };
        dataDisp = terminal.onData((chunk) => {
          if (socket?.readyState === WebSocket.OPEN) socket.send(chunk);
        });
      } catch (cause) {
        if (!cancelled) {
          const message = cause instanceof Error ? cause.message : "Terminal failed";
          setError(message);
          setStatus("offline");
          term?.writeln(`\r\n${message}`);
        }
      }
    })();

    return () => {
      cancelled = true;
      if (onResize) {
        window.removeEventListener("resize", onResize);
        window.visualViewport?.removeEventListener("resize", onResize);
      }
      dataDisp?.dispose();
      socket?.close();
      term?.dispose();
      termRef.current = null;
      socketRef.current = null;
      void fit;
    };
  }, [instanceId, mode, guest?.id, guest?.kind]);

  // Drag-to-resize from the grip (Homepage behavior) — desktop only.
  useEffect(() => {
    if (typeof window !== "undefined" && window.matchMedia(TERM_MOBILE_MQ).matches) {
      return;
    }
    const grip = modalRef.current?.querySelector("[data-term-grip]") as HTMLElement | null;
    const modal = modalRef.current;
    if (!grip || !modal) return;

    let startY = 0;
    let startH = 0;
    const onMove = (e: MouseEvent | TouchEvent) => {
      const y = "touches" in e ? e.touches[0].clientY : e.clientY;
      const next = Math.max(280, Math.min(window.innerHeight - 32, startH + (startY - y)));
      modal.style.height = `${next}px`;
      window.dispatchEvent(new Event("resize"));
    };
    const onUp = () => {
      document.removeEventListener("mousemove", onMove);
      document.removeEventListener("mouseup", onUp);
      document.removeEventListener("touchmove", onMove);
      document.removeEventListener("touchend", onUp);
    };
    const onDown = (e: MouseEvent | TouchEvent) => {
      e.preventDefault();
      startY = "touches" in e ? e.touches[0].clientY : e.clientY;
      startH = modal.getBoundingClientRect().height;
      document.addEventListener("mousemove", onMove);
      document.addEventListener("mouseup", onUp);
      document.addEventListener("touchmove", onMove, { passive: false });
      document.addEventListener("touchend", onUp);
    };
    grip.addEventListener("mousedown", onDown);
    grip.addEventListener("touchstart", onDown, { passive: false });
    return () => {
      grip.removeEventListener("mousedown", onDown);
      grip.removeEventListener("touchstart", onDown);
      onUp();
    };
  }, []);

  function injectCommand() {
    const q = window.prompt("Inject command:", mode === "host" ? "hostnamectl" : "ls -la");
    if (q == null) return;
    const payload = q.endsWith("\n") || q.endsWith("\r") ? q : `${q}\n`;
    const socket = socketRef.current;
    if (socket?.readyState === WebSocket.OPEN) {
      socket.send(payload);
    } else {
      termRef.current?.writeln(`\x1b[33m(not connected) ${q}\x1b[0m`);
    }
  }

  function clearTerminal() {
    const terminal = termRef.current;
    if (!terminal) return;
    // xterm.clear() primarily clears scrollback and can leave the current
    // viewport/prompt visible. Follow it with ANSI erase + cursor-home so the
    // button produces a genuinely clean terminal without restarting the PTY.
    terminal.clear();
    terminal.write("\x1b[2J\x1b[3J\x1b[H");
    window.requestAnimationFrame(() => terminal.focus());
  }

  const titleMain = mode === "host"
    ? (label || "Host")
    : (guest?.name || `Guest ${guest?.id || ""}`);
  const titleSub = mode === "host" ? "(host)" : `(${guest?.kind || "guest"} · ${guest?.id || ""})`;
  const online = status === "online";
  const offline = status === "offline";

  return (
    <ModalPortal>
      <div
        ref={backdropRef}
        className="pve-term-backdrop"
        // No backdrop click-to-dismiss — the opening click was racing this and
        // closing the terminal immediately. Use Close / Escape instead.
        role="presentation"
      >
        <div
          ref={modalRef}
          className="pve-term-modal"
          onClick={(e) => e.stopPropagation()}
          role="dialog"
          aria-modal="true"
        >
          <div className="pve-term-grip" title="Drag to resize" data-term-grip>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="9" r="1" /><circle cx="19" cy="9" r="1" /><circle cx="5" cy="9" r="1" />
              <circle cx="12" cy="15" r="1" /><circle cx="19" cy="15" r="1" /><circle cx="5" cy="15" r="1" />
            </svg>
          </div>

          <div className="pve-term-hdr">
            <div className="pve-term-title">
              <span className="pve-term-kicker">Terminal</span>
              <div className="pve-term-title-main">
                <span className="pve-term-name">{titleMain}</span>
                <span className="pve-term-sub">{titleSub}</span>
              </div>
            </div>
            <div className="pve-term-hdr-actions">
              <button type="button" className="pve-term-btn pve-term-btn--search" onClick={injectCommand} title="Search commands">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" />
                </svg>
                Search
              </button>
              <button type="button" className="pve-term-btn pve-term-btn--clear" onClick={clearTerminal} title="Clear terminal">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M3 6h18" /><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                  <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
                  <line x1="10" x2="10" y1="11" y2="17" /><line x1="14" x2="14" y1="11" y2="17" />
                </svg>
                Clear
              </button>
            </div>
          </div>

          {error ? <div className="pve-term-error">{error}</div> : null}
          {autoStatus ? (
            <div
              className={`pve-term-autorun${autoStatus.startsWith("Failed") ? " pve-term-autorun--err" : ""}${
                autoStatus === "Done" ? " pve-term-autorun--done" : ""
              }`}
            >
              {autoStatus !== "Done" && !autoStatus.startsWith("Failed") ? (
                <svg className="pve-gc-spin" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" aria-hidden>
                  <path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
                  <path d="M3 3v5h5" />
                  <path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16" />
                  <path d="M16 16h5v5" />
                </svg>
              ) : null}
              <span>{autoStatus}</span>
            </div>
          ) : null}

          <div className="pve-term-body" data-term-mount>
            <div className="pve-term-xterm" ref={mountRef} />
          </div>

          <div className="pve-term-ftr">
            <div
              className={`pve-term-status${online ? " pve-term-status--online" : ""}${offline ? " pve-term-status--offline" : ""}`}
              data-term-status
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" />
              </svg>
              <span className="pve-term-dot" data-term-dot />
              <span data-term-status-text>{status}</span>
            </div>
            <div className="pve-term-ftr-actions">
              {extUrl ? (
                <a className="pve-term-btn pve-term-btn--ext" href={extUrl} target="_blank" rel="noopener noreferrer">
                  Open in Proxmox
                </a>
              ) : null}
              <button type="button" className="pve-term-btn pve-term-btn--close" onClick={close}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M18 6 6 18" /><path d="m6 6 12 12" />
                </svg>
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </ModalPortal>
  );
}
