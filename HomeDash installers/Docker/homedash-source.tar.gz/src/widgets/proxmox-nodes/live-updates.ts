import type { Guest, GuestUpdateCheck, StatusPayload } from "./types";

const STORAGE_KEY = "hd-pve-live-update-overrides";
const TTL_MS = 6 * 60 * 60 * 1000;
const PER_GUEST_TIMEOUT_MS = 45_000;

type OverrideEntry = { at: number; uc: GuestUpdateCheck | null };
type OverrideStore = Record<string, Record<string, OverrideEntry>>;

function loadStore(): OverrideStore {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as OverrideStore;
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

function persistStore(store: OverrideStore) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
  } catch {
    // ignore quota / private mode
  }
}

function updateCheckTimeMs(uc: GuestUpdateCheck | null | undefined): number {
  const raw = uc?.last_check ?? 0;
  if (typeof raw === "string" && raw && Number.isNaN(Number(raw))) {
    const parsed = Date.parse(raw);
    return Number.isFinite(parsed) ? parsed : 0;
  }
  const n = Number(raw) || 0;
  if (!n) return 0;
  return n < 1e12 ? n * 1000 : n;
}

export function getLiveUpdateOverride(instanceId: string, vmid: number | string): OverrideEntry | null {
  const store = loadStore();
  const entry = store[instanceId]?.[String(vmid)];
  if (!entry || typeof entry.at !== "number") return null;
  if (Date.now() - entry.at > TTL_MS) {
    delete store[instanceId][String(vmid)];
    persistStore(store);
    return null;
  }
  return entry;
}

export function setLiveUpdateOverride(
  instanceId: string,
  vmid: number | string,
  uc: GuestUpdateCheck | null,
) {
  const store = loadStore();
  if (!store[instanceId]) store[instanceId] = {};
  store[instanceId][String(vmid)] = { at: Date.now(), uc };
  persistStore(store);
}

/** Prefer a recent live Recheck over stale ProxMenux MONITOR scanner counts. */
export function mergeLiveUpdateCheck(
  instanceId: string,
  vmid: number | string,
  incoming: GuestUpdateCheck | null | undefined,
): GuestUpdateCheck | null {
  const override = getLiveUpdateOverride(instanceId, vmid);
  if (!override) return incoming || null;
  const prxAt = updateCheckTimeMs(incoming);
  const liveCount = Number(override.uc?.count) || 0;
  const prxCount = Number(incoming?.count) || 0;
  // Only drop our live result when MONITOR rescanned AFTER us AND reports <= our count.
  if (prxAt > override.at && prxCount <= liveCount) {
    const store = loadStore();
    delete store[instanceId]?.[String(vmid)];
    persistStore(store);
    return incoming || null;
  }
  return override.uc;
}

export function applyLiveOverridesToStatus(
  instanceId: string,
  payload: StatusPayload,
): StatusPayload {
  const items = payload.guests?.items;
  if (!Array.isArray(items) || !items.length) return payload;
  let changed = false;
  const nextItems = items.map((guest) => {
    const merged = mergeLiveUpdateCheck(instanceId, guest.id, guest.updateCheck);
    if (merged === guest.updateCheck) return guest;
    changed = true;
    return { ...guest, updateCheck: merged };
  });
  if (!changed) return payload;
  return {
    ...payload,
    guests: payload.guests ? { ...payload.guests, items: nextItems } : payload.guests,
  };
}

export function parseAptUpgradableList(text: string): NonNullable<GuestUpdateCheck["packages"]> {
  const clean = String(text || "").replace(/\x1b\[[0-9;]*[a-zA-Z]/g, "");
  const packages: NonNullable<GuestUpdateCheck["packages"]> = [];
  const re = /^([a-z0-9][a-z0-9+._-]*)\/\S+\s+(\S+)\s+.*\[upgradable from:\s*([^\]]+)\]/gim;
  let m: RegExpExecArray | null;
  while ((m = re.exec(clean))) {
    packages.push({
      name: m[1],
      latest: m[2],
      current: String(m[3] || "").trim(),
      security: /security/i.test(m[0]),
    });
  }
  return packages;
}

function clearedCheck(): GuestUpdateCheck {
  return {
    available: false,
    count: 0,
    security_count: 0,
    last_check: new Date().toISOString(),
    packages: [],
  };
}

export function markGuestsCleared(instanceId: string, vmids: Array<number | string>) {
  for (const id of vmids) setLiveUpdateOverride(instanceId, id, clearedCheck());
}

function feedSocketText(raw: string): string {
  try {
    const parsed = JSON.parse(raw) as { type?: string; data?: string };
    if (parsed.type === "pong") return "";
    if (parsed.data != null) return String(parsed.data);
  } catch {
    // raw
  }
  return raw;
}

/**
 * Live-scan running LXCs via host terminal `pct exec` + `apt list --upgradable`.
 * One WebSocket session for the whole queue (same pattern as bulk upgrade).
 */
export async function liveRecheckRunningLxcs(
  instanceId: string,
  guests: Guest[],
  opts?: {
    /** Only guests that currently show a pending badge (faster). Default: all running LXCs. */
    onlyPending?: boolean;
    onProgress?: (info: { done: number; total: number; label: string }) => void;
  },
): Promise<{ done: number; total: number }> {
  const targets = guests
    .filter((g) => (g.type === "lxc" || g.kind === "lxc") && g.status === "running")
    .filter((g) => (opts?.onlyPending ? Number(g.updateCheck?.count || 0) > 0 : true))
    .sort((a, b) => String(a.name || a.id).localeCompare(String(b.name || b.id), undefined, { sensitivity: "base" }));

  if (!targets.length) {
    opts?.onProgress?.({ done: 0, total: 0, label: "No running LXCs" });
    return { done: 0, total: 0 };
  }

  opts?.onProgress?.({ done: 0, total: targets.length, label: `0 / ${targets.length}` });

  const ticketRes = await fetch("/api/widgets/proxmox-nodes/terminal/ticket", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ instance: instanceId, mode: "host" }),
  });
  const ticketJson = await ticketRes.json();
  if (!ticketRes.ok) throw new Error(ticketJson.error || "Terminal ticket failed");

  const socket = new WebSocket(String(ticketJson.wsUrl));
  let buffer = "";
  const waiters: Array<() => void> = [];

  await new Promise<void>((resolve, reject) => {
    socket.onopen = () => resolve();
    socket.onerror = () => reject(new Error("WebSocket error"));
    window.setTimeout(() => reject(new Error("WebSocket connect timeout")), 20_000);
  });

  socket.onmessage = (event) => {
    const raw = typeof event.data === "string" ? event.data : "";
    if (!raw) return;
    const chunk = feedSocketText(raw);
    if (!chunk) return;
    buffer += chunk;
    waiters.slice().forEach((w) => w());
  };

  const waitForDone = (marker: string, timeoutMs: number) =>
    new Promise<"ok" | "timeout" | "closed">((resolve) => {
      const re = new RegExp(`${marker.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(\\d+)`);
      let settled = false;
      const finish = (status: "ok" | "timeout" | "closed") => {
        if (settled) return;
        settled = true;
        window.clearTimeout(timer);
        const idx = waiters.indexOf(onChunk);
        if (idx >= 0) waiters.splice(idx, 1);
        resolve(status);
      };
      const timer = window.setTimeout(() => finish("timeout"), timeoutMs);
      const onChunk = () => {
        if (re.test(buffer)) finish("ok");
        else if (socket.readyState !== WebSocket.OPEN) finish("closed");
      };
      waiters.push(onChunk);
      onChunk();
    });

  // Let MOTD settle.
  await new Promise((r) => window.setTimeout(r, 350));
  buffer = "";

  let done = 0;
  try {
    for (const guest of targets) {
      const marker = `__HD_UPD_${guest.id}_${Date.now()}__`;
      // Host-level sentinel with digits — shell echo of `$?` must not false-trigger.
      const cmd =
        `pct exec ${guest.id} -- bash -lc ` +
        `'apt list --upgradable 2>/dev/null | grep -v "^Listing" || true'; ` +
        `echo ${marker}$?\n`;

      buffer = "";
      if (socket.readyState !== WebSocket.OPEN) throw new Error("Host terminal disconnected");
      socket.send(cmd);

      const result = await waitForDone(marker, PER_GUEST_TIMEOUT_MS);
      if (result === "ok") {
        const endIdx = buffer.search(new RegExp(`${marker.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\d+`));
        const body = endIdx >= 0 ? buffer.slice(0, endIdx) : buffer;
        const packages = parseAptUpgradableList(body);
        const count = packages.length;
        const uc: GuestUpdateCheck = {
          available: count > 0,
          count,
          security_count: packages.filter((p) => p.security).length,
          last_check: new Date().toISOString(),
          packages: count > 0 ? packages : [],
        };
        setLiveUpdateOverride(instanceId, guest.id, uc);
      }
      // On timeout/closed, leave prior override / MONITOR data alone.

      done += 1;
      opts?.onProgress?.({
        done,
        total: targets.length,
        label: `${done} / ${targets.length}`,
      });
      if (done < targets.length) await new Promise((r) => window.setTimeout(r, 350));
    }
  } finally {
    try {
      socket.close();
    } catch {
      // ignore
    }
  }

  return { done, total: targets.length };
}
