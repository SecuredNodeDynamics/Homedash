import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "proxmox-nodes",
  name: "Proxmox",
  description: "Node console: Overview, Network, Guests, Storage, Hardware, Backups, Security",
  version: "1.2.22",
  category: "Infra",
  hostClass: "pve-node-host pve-scifi",
  defaultSize: { w: 10, h: 18, minW: 6, minH: 10 },
  // Connection fields are edited via ProxmoxConfigEditor in Settings.
  configFields: [],
};
