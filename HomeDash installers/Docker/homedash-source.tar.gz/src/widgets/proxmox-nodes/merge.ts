import type { StatusPayload } from "./types";

/**
 * A poll can come back with some sections empty because a Proxmox call timed out
 * (the server lists them in `degraded`). Never let that replace data we already
 * have: carry the previous section over instead.
 */
export function mergeDegraded(prev: StatusPayload | null | undefined, next: StatusPayload): StatusPayload {
  const flags = new Set(next.degraded || []);
  if (!prev || !flags.size) return next;
  const out: StatusPayload = { ...next };
  const emptyList = (v: unknown) => !Array.isArray(v) || v.length === 0;

  const guestsDegraded = flags.has("vms") || flags.has("lxcs");
  if (guestsDegraded && emptyList(next.vms) && emptyList(next.lxcs) && (prev.vms.length || prev.lxcs.length)) {
    out.vms = prev.vms;
    out.lxcs = prev.lxcs;
    out.guests = prev.guests;
    out.network = { ...out.network, flowGuests: prev.network?.flowGuests ?? out.network?.flowGuests };
  }
  if ((flags.has("stores") || flags.has("disks")) && emptyList(next.storage?.stores) && emptyList(next.storage?.disks) && prev.storage) {
    out.storage = prev.storage;
    out.storageCount = prev.storageCount;
  }
  if (flags.has("rrd") && emptyList(next.network?.rrd) && prev.network?.rrd?.length) {
    out.network = { ...out.network, rrd: prev.network.rrd };
  }
  if (prev.backups && next.backups) {
    const backupFlag = flags.has("schedules") || [...flags].some((f) => f.startsWith("backup:"));
    if (backupFlag) {
      out.backups = {
        items: emptyList(next.backups.items) ? prev.backups.items : next.backups.items,
        schedules: flags.has("schedules") && emptyList(next.backups.schedules) ? prev.backups.schedules : next.backups.schedules,
      };
    }
  }
  if (flags.has("hardware") && !next.hardware && prev.hardware) out.hardware = prev.hardware;
  return out;
}
