export const DOW_ORDER = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"] as const;
export type Dow = (typeof DOW_ORDER)[number];

export const DOW_LABEL: Record<Dow, string> = {
  mon: "Mon",
  tue: "Tue",
  wed: "Wed",
  thu: "Thu",
  fri: "Fri",
  sat: "Sat",
  sun: "Sun",
};

/** Parse a Proxmox cron-style day-of-week spec ("mon,wed,fri", "mon..fri", "*") into an ordered list. */
export function parseDows(spec: string): Dow[] {
  const s = (spec || "").trim().toLowerCase();
  if (!s || s === "*") return [...DOW_ORDER];
  const days = new Set<Dow>();
  for (const tokRaw of s.split(",")) {
    const tok = tokRaw.trim();
    if (!tok) continue;
    if (tok.includes("..")) {
      const [a, b] = tok.split("..").map((t) => t.trim().slice(0, 3));
      const ai = DOW_ORDER.indexOf(a as Dow);
      const bi = DOW_ORDER.indexOf(b as Dow);
      if (ai === -1 || bi === -1) continue;
      if (ai <= bi) {
        for (let i = ai; i <= bi; i++) days.add(DOW_ORDER[i]);
      } else {
        for (let i = ai; i < 7; i++) days.add(DOW_ORDER[i]);
        for (let i = 0; i <= bi; i++) days.add(DOW_ORDER[i]);
      }
    } else {
      const d = tok.slice(0, 3);
      if ((DOW_ORDER as readonly string[]).includes(d)) days.add(d as Dow);
    }
  }
  return DOW_ORDER.filter((d) => days.has(d));
}

export function serializeDows(days: string[]): string {
  if (days.length === 0 || days.length === 7) return "*";
  return DOW_ORDER.filter((d) => days.includes(d)).join(",");
}

export function parseSchedule(schedule?: string): { days: Dow[]; time: string } {
  const s = (schedule || "").trim();
  if (!s) return { days: [...DOW_ORDER], time: "03:00" };
  const parts = s.split(/\s+/);
  const last = parts[parts.length - 1];
  if (/^\d{1,2}:\d{2}$/.test(last)) {
    const [h, m] = last.split(":");
    const time = `${h.padStart(2, "0")}:${m}`;
    const dowSpec = parts.length > 1 ? parts.slice(0, -1).join(" ") : "*";
    return { days: parseDows(dowSpec), time };
  }
  return { days: [...DOW_ORDER], time: "03:00" };
}

export function serializeSchedule(days: string[], time: string): string {
  return `${serializeDows(days)} ${time || "00:00"}`;
}

/** "14:05" -> "2:05 PM" */
export function formatTime12h(time24: string): string {
  const match = /^(\d{1,2}):(\d{1,2})$/.exec((time24 || "").trim());
  if (!match) return time24 || "";
  const h24 = Math.min(23, Math.max(0, parseInt(match[1], 10) || 0));
  const m = Math.min(59, Math.max(0, parseInt(match[2], 10) || 0));
  const period = h24 < 12 ? "AM" : "PM";
  const h12 = h24 % 12 || 12;
  return `${h12}:${String(m).padStart(2, "0")} ${period}`;
}

/** Collapse a set of selected days into the shortest readable label, e.g. "Mon–Fri", "Sat, Sun", "Every day". */
export function formatDaysLabel(days: Dow[]): string {
  if (days.length === 0) return "Never";
  if (days.length === 7) return "Every day";

  const set = new Set(days);
  const isWeekdays = ["mon", "tue", "wed", "thu", "fri"].every((d) => set.has(d as Dow)) && set.size === 5;
  if (isWeekdays) return "Weekdays";
  const isWeekend = ["sat", "sun"].every((d) => set.has(d as Dow)) && set.size === 2;
  if (isWeekend) return "Weekends";

  const ordered = DOW_ORDER.filter((d) => set.has(d));
  // Detect a single contiguous run within the mon..sun order (no wraparound needed here since UI only builds simple ranges).
  const indices = ordered.map((d) => DOW_ORDER.indexOf(d));
  const isContiguous = indices.every((idx, i) => i === 0 || idx === indices[i - 1] + 1);
  if (isContiguous && ordered.length > 2) {
    return `${DOW_LABEL[ordered[0]]}\u2013${DOW_LABEL[ordered[ordered.length - 1]]}`;
  }

  return ordered.map((d) => DOW_LABEL[d]).join(", ");
}

/** Full human-readable label for a Proxmox schedule string, e.g. "Mon\u2013Fri \u00b7 4:00 AM". */
export function formatScheduleLabel(schedule?: string): string {
  const { days, time } = parseSchedule(schedule);
  return `${formatDaysLabel(days)} \u00b7 ${formatTime12h(time)}`;
}
