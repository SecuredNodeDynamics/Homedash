export type TabKey = "overview" | "network" | "guests" | "storage" | "hardware" | "backups" | "security";

export type StatusPayload = {
  href: string;
  openFallbackUrl: string | null;
  connectionSource: "private" | "public" | "unknown";
  prxHref: string | null;
  prxOpenFallbackUrl: string | null;
  node: string;
  online: boolean;
  pveOnline: boolean;
  glancesOnline: boolean;
  uptime: number;
  uptimeLabel: string;
  color: string;
  iface: string;
  backupMount: string | null;
  cpu: number;
  memory: { used: number; total: number; percent: number };
  disk: { used: number; total: number; percent: number };
  vms: Guest[];
  lxcs: Guest[];
  storageCount: number;
  overview: Overview;
  guests: GuestsBlock;
  storage: StorageBlock;
  network: NetworkBlock;
  hardware: HardwareBlock | null;
  backups: BackupsBlock | null;
  security: SecurityBlock | null;
  prxConfigured: boolean;
  updatedAt: number;
  degraded?: string[];
  stale?: boolean;
};

export type BackupsBlock = {
  items: BackupItem[];
  schedules: BackupSchedule[];
};

export type BackupItem = {
  volid: string;
  vmid: number;
  ctime: number;
  size: number;
  format: string;
  content: string;
  notes?: string;
  storage: string;
  type: "vm" | "lxc";
  subtype?: string;
};

export type BackupSchedule = {
  id: string;
  vmid?: string;
  node?: string;
  storage?: string;
  schedule: string;
  enabled: number;
  comment?: string;
  dow?: string;
  starttime?: string;
  mode?: string;
  compress?: string;
  bwlimit?: number;
  all?: number;
  exclude?: string;
  "exclude-path"?: string;
  mailto?: string;
  mailnotification?: string;
  notes?: string;
  zstd?: number;
  maxfiles?: number;
  keep?: number;
  "prune-backups"?: string;
};

export type GuestUpdateCheck = {
  available: boolean;
  count: number;
  security_count: number;
  last_check?: string | null;
  packages?: Array<{
    name?: string;
    Package?: string;
    current?: string;
    latest?: string;
    Version?: string;
    NewVersion?: string;
    security?: boolean;
  }>;
};

export type Guest = {
  id: number;
  name: string;
  type: "vm" | "lxc";
  kind: "qemu" | "lxc";
  status: string;
  cpu: number;
  cpus: number;
  mem: number;
  maxmem: number;
  disk: number;
  maxdisk: number;
  diskread: number;
  diskwrite: number;
  netin: number;
  netout: number;
  uptime: number;
  ips?: string[];
  updateCheck?: GuestUpdateCheck | null;
};

export type Overview = {
  liveCpuPct: number;
  liveCpuColor: string;
  liveMemPct: number;
  liveMemColor: string;
  liveMemUsed: string;
  liveMemTotal: string;
  diskPct: number;
  diskColor: string;
  diskUsed: string;
  diskTotal: string;
  cpuTemp: number | null;
  loadDisplay: string;
  loadSub: string;
  loadBarColor: string;
  swapDisplay: string;
  swapSub: string;
  swapColor: string;
  procDisplay: string;
  procSub: string;
  procColor: string;
  rxBytes: number;
  txBytes: number;
  rxLabel: string;
  txLabel: string;
  ioWaitPct: number | null;
  ioWaitColor: string;
  bupPct: number | null;
  bupColor: string;
  bupUsed: string;
  bupTotal: string;
  bupNote?: string;
  bupLabel?: string;
  kernelVersion: string;
  hasKernelUpdate: boolean;
  updateCount: number;
  updateColor: string;
  updateLabel: string;
  updates: Array<{ Package?: string; name?: string; Version?: string; NewVersion?: string }>;
  topProcs: Array<{ name?: string; cmdline?: string; cpu_percent?: number; memory_percent?: number }>;
};

export type GuestsBlock = {
  total: number;
  running: number;
  vmCount: number;
  lxcCount: number;
  cpuUsedSum: number;
  cpuAllocSum: number;
  hostCpus: number;
  memUsedSum: number;
  memAllocSum: number;
  hostMemTotal: number;
  diskUsedSum: number;
  diskAllocSum: number;
  items: Guest[];
};

export type StorageBlock = {
  stores: Array<Record<string, unknown>>;
  disks: Array<Record<string, unknown>>;
  remoteMounts: Array<Record<string, unknown>>;
};

export type NetworkBlock = {
  rrd: Array<Record<string, unknown>>;
  ifaces: Array<Record<string, unknown>>;
  flowGuests: Array<{
    id: number;
    name: string;
    type: "vm" | "lxc";
    kind: "qemu" | "lxc";
    status: string;
    netin: number;
    netout: number;
  }>;
};

export type HardwareBlock = {
  cpu?: Record<string, unknown>;
  motherboard?: Record<string, unknown>;
  bios?: Record<string, unknown>;
  memory_modules?: Array<Record<string, unknown>>;
  temperatures?: Array<Record<string, unknown>>;
  gpus?: Array<Record<string, unknown>>;
  pci_devices?: Array<Record<string, unknown>>;
};

export type SecurityBlock = {
  tools?: unknown;
  report?: unknown;
  /** Set when the report shown is the saved copy, not a live ProxMenux answer. */
  stale?: boolean;
  savedAt?: number;
};

export function fmtBytes(bytes: number) {
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB", "PB"];
  const i = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  return `${(bytes / 1024 ** i).toFixed(i > 1 ? 1 : 0)} ${units[i]}`;
}

export function fmtUptimeFull(seconds: number) {
  if (!Number.isFinite(seconds) || seconds <= 0) return "—";
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (d > 0) return `${d}d ${h}h ${m}m`;
  if (h > 0) return `${h}h ${m}m ${s}s`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

export function pctColor(pct: number) {
  if (pct >= 90) return "#f87171";
  if (pct >= 75) return "#fbbf24";
  if (pct >= 50) return "#60a5fa";
  return "#6ee7b7";
}
