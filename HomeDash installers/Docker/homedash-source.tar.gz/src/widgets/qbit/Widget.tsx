"use client";
import "@/styles/widgets/qbit.widget.css";


import { useCallback, useEffect, useMemo, useState, useLayoutEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type Torrent = Record<string, unknown> & {
  hash: string;
  name: string;
  state: string;
  progress: number;
  dlspeed: number;
  upspeed: number;
  size: number;
  eta: number;
  ratio: number;
  category: string;
};

type ConnectionSource = "private" | "public" | "unknown";

const CONNECTION_SOURCE_LABEL: Record<ConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

function ConnectionCorner({ source }: { source: ConnectionSource }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const mark = (
    <div
      className={`qbit-corner-source qbit-corner-source--${source}`}
      title={CONNECTION_SOURCE_LABEL[source]}
      aria-label={CONNECTION_SOURCE_LABEL[source]}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}


type Status = {
  href: string;
  openFallbackUrl?: string;
  torrents: Torrent[];
  transfer: Record<string, number>;
  freeSpace: number;
  connectionSource?: ConnectionSource;
  categories: string[];
  categorySavePaths?: Record<string, string>;
  defaultSavePath?: string;
};

type Filter = "all" | "active" | "downloading" | "seeding" | "paused" | "stalled" | "error";

function bytes(value: number) {
  if (!value) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  const index = Math.min(Math.floor(Math.log(value) / Math.log(1024)), units.length - 1);
  return `${(value / 1024 ** index).toFixed(index > 1 ? 1 : 0)} ${units[index]}`;
}

const speed = (value: number) => `${bytes(value)}/s`;

// qBittorrent uses a "stalledUP" / "stalledDL" state to mean "active in this
// direction, just no peers are currently transferring data right now" - it's a
// normal, healthy sub-state (most common right after a download finishes and
// before a peer requests it), NOT a problem state. It must be treated as part
// of the seeding/downloading family, not as a distinct alarming status.
function isStalledSeeding(state: string) {
  return /stalledup/.test(state);
}

function isStalledDownloading(state: string) {
  return /stalleddl/.test(state);
}

function isActive(state: string) {
  return /download|upload|seed|meta|check|stalled/i.test(state) && !/paused|stopped/i.test(state);
}

function isPaused(state: string) {
  return /paused|stopped/i.test(state);
}

function matches(torrent: Torrent, filter: Filter) {
  const state = torrent.state.toLowerCase();
  if (filter === "all") return true;
  if (filter === "active") return isActive(state);
  if (filter === "downloading") return /download|meta/.test(state) || isStalledDownloading(state);
  if (filter === "seeding") return /seed|upload/.test(state) || isStalledSeeding(state);
  if (filter === "paused") return isPaused(state);
  if (filter === "stalled") return /stalled/.test(state);
  return /error|missing/.test(state);
}

function stateClass(state: string) {
  if (/error|missing/.test(state)) return "error";
  if (/paused|stopped/.test(state)) return "paused";
  if (isStalledSeeding(state)) return "seeding";
  if (isStalledDownloading(state)) return "downloading";
  if (/download|meta/.test(state)) return "downloading";
  if (/seed|upload/.test(state)) return "seeding";
  if (/check/.test(state)) return "checking";
  return "queued";
}

const DELETE_FILES_STORAGE_PREFIX = "qbit-widget:deleteFiles:";

function loadDeleteFilesPref(instanceId: string): boolean {
  if (typeof window === "undefined") return false;
  try {
    return window.localStorage.getItem(DELETE_FILES_STORAGE_PREFIX + instanceId) === "true";
  } catch {
    // localStorage can throw in private-browsing/storage-disabled contexts;
    // fall back to the old default rather than crashing the widget.
    return false;
  }
}

function saveDeleteFilesPref(instanceId: string, value: boolean) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(DELETE_FILES_STORAGE_PREFIX + instanceId, String(value));
  } catch {
    // Ignore write failures (quota exceeded, storage disabled, etc.) - the
    // checkbox still works for the current session even if it can't persist.
  }
}

const FILTERS: Array<{ key: Filter; label: string }> = [
  { key: "all", label: "All" },
  { key: "active", label: "Active" },
  { key: "downloading", label: "DL" },
  { key: "seeding", label: "Seeding" },
  { key: "paused", label: "Paused" },
  { key: "stalled", label: "Stalled" },
  { key: "error", label: "Error" },
];

function DeleteConfirm({
  count,
  busy,
  deleteFiles,
  onDeleteFilesChange,
  onCancel,
  onConfirm,
}: {
  count: number;
  busy: boolean;
  deleteFiles: boolean;
  onDeleteFilesChange: (value: boolean) => void;
  onCancel: () => void;
  onConfirm: (deleteFiles: boolean) => void;
}) {
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape" && !busy) onCancel();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [busy, onCancel]);

  return createPortal(
    <div
      className="qbit-confirm-overlay"
      role="presentation"
      onClick={(event) => {
        if (event.target === event.currentTarget && !busy) onCancel();
      }}
    >
      <div
        className="qbit-confirm-box"
        role="dialog"
        aria-modal="true"
        aria-labelledby="qbit-delete-title"
      >
        <div className="qbit-confirm-title" id="qbit-delete-title">
          Delete {count} torrent{count === 1 ? "" : "s"}?
        </div>
        <div className="qbit-confirm-msg">This will remove the torrent from qBittorrent.</div>
        <label className="qbit-confirm-check-row">
          <input
            id="qbit-del-files"
            type="checkbox"
            checked={deleteFiles}
            disabled={busy}
            onChange={(event) => onDeleteFilesChange(event.target.checked)}
          />
          Also delete downloaded files
        </label>
        <div className="qbit-confirm-buttons">
          <button
            className="qbit-confirm-btn qbit-confirm-btn--cancel"
            type="button"
            disabled={busy}
            onClick={onCancel}
          >
            Cancel
          </button>
          <button
            className="qbit-confirm-btn qbit-confirm-btn--ok"
            type="button"
            disabled={busy}
            onClick={() => onConfirm(deleteFiles)}
          >
            {busy ? "Deleting…" : "Delete"}
          </button>
        </div>
      </div>
    </div>,
    document.body,
  );
}

type AddForm = {
  urls: string;
  autoTMM: boolean;
  savepath: string;
  rename: string;
  category: string;
  startTorrent: boolean;
  addToTopOfQueue: boolean;
  stopCondition: "None" | "MetadataReceived" | "FilesChecked";
  skipChecking: boolean;
  contentLayout: "Original" | "Subfolder" | "NoSubfolder";
  sequentialDownload: boolean;
  firstLastPiecePrio: boolean;
  dlLimit: string;
  upLimit: string;
};

const DEFAULT_ADD_FORM: AddForm = {
  urls: "",
  autoTMM: false,
  savepath: "",
  rename: "",
  category: "",
  startTorrent: true,
  addToTopOfQueue: false,
  stopCondition: "None",
  skipChecking: false,
  contentLayout: "Original",
  sequentialDownload: false,
  firstLastPiecePrio: false,
  dlLimit: "",
  upLimit: "",
};

function joinPath(base: string, segment: string) {
  if (!base) return segment;
  if (!segment) return base;
  return `${base.replace(/\/+$/, "")}/${segment.replace(/^\/+/, "")}`;
}

// Resolves the save path for a given category: prefer whatever save path is
// already configured on that category inside qBittorrent itself, and only
// fall back to "<default save path>/<category name>" when the category has
// no save path of its own set.
function resolveSavePath(category: string, categorySavePaths: Record<string, string>, defaultSavePath: string) {
  if (!category) return defaultSavePath;
  return categorySavePaths[category] || joinPath(defaultSavePath, category);
}

function AddTorrentModal({
  busy,
  error,
  categories,
  categorySavePaths,
  defaultSavePath,
  onCancel,
  onSubmit,
}: {
  busy: boolean;
  error: string;
  categories: string[];
  categorySavePaths: Record<string, string>;
  defaultSavePath: string;
  onCancel: () => void;
  onSubmit: (form: AddForm) => void;
}) {
  // Pre-fill "Save files to location" with qBittorrent's own configured
  // default save path, so the field reflects the server's Settings ->
  // Downloads location instead of opening empty.
  const [form, setForm] = useState<AddForm>(() => ({ ...DEFAULT_ADD_FORM, savepath: defaultSavePath }));
  const set = <K extends keyof AddForm>(key: K, value: AddForm[K]) =>
    setForm((current) => ({ ...current, [key]: value }));

  const setCategory = (category: string) => {
    setForm((current) => {
      if (current.autoTMM) return { ...current, category };
      return {
        ...current,
        category,
        savepath: resolveSavePath(category, categorySavePaths, defaultSavePath),
        // Content layout "Subfolder" is qBittorrent's own built-in behavior
        // for creating a folder named after the torrent/media (using the
        // "Rename torrent" value when set, otherwise the torrent's own name)
        // inside the save path and placing the downloaded files in it. Auto-
        // enable it whenever a category is picked so category downloads land
        // in "<save path>/<Category>/<Media Name>/"; clearing the category
        // reverts to the plain save path.
        contentLayout: category ? "Subfolder" : "Original",
      };
    });
  };

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape" && !busy) onCancel();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [busy, onCancel]);

  return createPortal(
    <div
      className="qbit-confirm-overlay"
      role="presentation"
      onClick={(event) => {
        if (event.target === event.currentTarget && !busy) onCancel();
      }}
    >
      <div className="qbit-add-box" role="dialog" aria-modal="true" aria-labelledby="qbit-add-title">
        <div className="qbit-add-header">
          <span id="qbit-add-title">Add Torrent</span>
          <button
            className="qbit-add-close"
            type="button"
            disabled={busy}
            aria-label="Close"
            onClick={onCancel}
          >
            ✕
          </button>
        </div>

        <div className="qbit-add-body">
          <div className="qbit-add-section-label">Torrent links</div>
          <textarea
            className="qbit-add-textarea"
            placeholder="One link per line (HTTP, magnet, or info-hash)"
            value={form.urls}
            disabled={busy}
            onChange={(event) => set("urls", event.target.value)}
          />

          <div className="qbit-add-section-label">Options</div>
          <div className="qbit-add-grid">
            <label className="qbit-add-label">Torrent Management Mode</label>
            <select
              className="qbit-add-select"
              disabled={busy}
            value={form.autoTMM ? "Automatic" : "Manual"}
            onChange={(event) => {
              const autoTMM = event.target.value === "Automatic";
              setForm((current) => ({
                ...current,
                autoTMM,
                // Switching back to Manual should re-populate the save path
                // from the selected category (or the global default) rather
                // than leaving whatever was there when Automatic was toggled on.
                savepath: autoTMM
                  ? current.savepath
                  : resolveSavePath(current.category, categorySavePaths, defaultSavePath),
              }));
            }}
          >
            <option value="Manual">Manual</option>
            <option value="Automatic">Automatic</option>
          </select>

          <label className="qbit-add-label">Save files to location</label>
          <input
            className="qbit-add-input"
            disabled={busy || form.autoTMM}
            placeholder={defaultSavePath || "/media/Downloads"}
            value={form.savepath}
            onChange={(event) => set("savepath", event.target.value)}
          />

          <label className="qbit-add-label">Rename torrent</label>
          <input
            className="qbit-add-input"
            disabled={busy}
            value={form.rename}
            onChange={(event) => set("rename", event.target.value)}
          />

          <label className="qbit-add-label">Category</label>
          <select
            className="qbit-add-select"
            disabled={busy}
            value={form.category}
            onChange={(event) => setCategory(event.target.value)}
          >
            <option value="">(none)</option>
            {categories.map((category) => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>

          <label className="qbit-add-label">Start torrent</label>
          <input
            className="qbit-add-checkbox"
            type="checkbox"
            disabled={busy}
            checked={form.startTorrent}
            onChange={(event) => set("startTorrent", event.target.checked)}
          />

          <label className="qbit-add-label">Add to top of queue</label>
          <input
            className="qbit-add-checkbox"
            type="checkbox"
            disabled={busy}
            checked={form.addToTopOfQueue}
            onChange={(event) => set("addToTopOfQueue", event.target.checked)}
          />

          <label className="qbit-add-label">Stop condition</label>
          <select
            className="qbit-add-select"
            disabled={busy}
            value={form.stopCondition}
            onChange={(event) => set("stopCondition", event.target.value as AddForm["stopCondition"])}
          >
            <option value="None">None</option>
            <option value="MetadataReceived">Metadata received</option>
            <option value="FilesChecked">Files checked</option>
          </select>

          <label className="qbit-add-label">Skip hash check</label>
          <input
            className="qbit-add-checkbox"
            type="checkbox"
            disabled={busy}
            checked={form.skipChecking}
            onChange={(event) => set("skipChecking", event.target.checked)}
          />

          <label className="qbit-add-label">Content layout</label>
          <select
            className="qbit-add-select"
            disabled={busy}
            value={form.contentLayout}
            onChange={(event) => set("contentLayout", event.target.value as AddForm["contentLayout"])}
          >
            <option value="Original">Original</option>
            <option value="Subfolder">Create subfolder</option>
            <option value="NoSubfolder">Don't create subfolder</option>
          </select>

          <label className="qbit-add-label">Download in sequential order</label>
          <input
            className="qbit-add-checkbox"
            type="checkbox"
            disabled={busy}
            checked={form.sequentialDownload}
            onChange={(event) => set("sequentialDownload", event.target.checked)}
          />

          <label className="qbit-add-label">Download first and last pieces first</label>
          <input
            className="qbit-add-checkbox"
            type="checkbox"
            disabled={busy}
            checked={form.firstLastPiecePrio}
            onChange={(event) => set("firstLastPiecePrio", event.target.checked)}
          />

          <label className="qbit-add-label">Limit download rate</label>
          <input
            className="qbit-add-input"
            disabled={busy}
            placeholder="KiB/s"
            inputMode="numeric"
            value={form.dlLimit}
            onChange={(event) => set("dlLimit", event.target.value.replace(/[^0-9]/g, ""))}
          />

          <label className="qbit-add-label">Limit upload rate</label>
          <input
            className="qbit-add-input"
            disabled={busy}
            placeholder="KiB/s"
            inputMode="numeric"
            value={form.upLimit}
            onChange={(event) => set("upLimit", event.target.value.replace(/[^0-9]/g, ""))}
          />
          </div>

          {error ? <div className="qbit-inline-error">{error}</div> : null}
        </div>

        <div className="qbit-add-footer">
          <button className="qbit-confirm-btn qbit-confirm-btn--cancel" type="button" disabled={busy} onClick={onCancel}>
            Cancel
          </button>
          <button
            className="qbit-confirm-btn qbit-confirm-btn--ok qbit-confirm-btn--add"
            type="button"
            disabled={busy || !form.urls.trim()}
            onClick={() => onSubmit(form)}
          >
            {busy ? "Downloading…" : "Download"}
          </button>
        </div>
      </div>
    </div>,
    document.body,
  );
}

export default function QbitWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "qbit";
  const [data, setData] = useState<Status | null>(null);
  const [filter, setFilter] = useState<Filter>("all");
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<string[]>([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);
  const [pendingDelete, setPendingDelete] = useState<string[] | null>(null);
  const [deleteFiles, setDeleteFiles] = useState(() => loadDeleteFilesPref(instanceId));
  const [showAdd, setShowAdd] = useState(false);
  const [addBusy, setAddBusy] = useState(false);
  const [addError, setAddError] = useState("");

  const handleDeleteFilesChange = useCallback(
    (value: boolean) => {
      setDeleteFiles(value);
      saveDeleteFilesPref(instanceId, value);
    },
    [instanceId],
  );

  const load = useCallback(async () => {
    try {
      const response = await fetch(
        `/api/widgets/qbit/status?instance=${encodeURIComponent(instanceId)}`,
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load qBittorrent");
      setData(json);
      setError("");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Failed to load qBittorrent");
    }
  }, [instanceId]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: 15_000 });

  const torrents = useMemo(
    () =>
      (data?.torrents || []).filter(
        (torrent) =>
          matches(torrent, filter) &&
          `${torrent.name} ${torrent.category || ""}`.toLowerCase().includes(query.toLowerCase()),
      ),
    [data, filter, query],
  );

  const count = (next: Filter) =>
    (data?.torrents || []).filter((torrent) => matches(torrent, next)).length;

  const toggle = (hash: string) =>
    setSelected((current) =>
      current.includes(hash) ? current.filter((item) => item !== hash) : [...current, hash],
    );

  const selectAll = () => setSelected(torrents.map((torrent) => torrent.hash));

  async function runAction(
    actionName: "resume" | "pause" | "recheck" | "delete",
    hashes: string[],
    deleteFiles = false,
  ) {
    if (!hashes.length) return;
    if (actionName === "delete") {
      setPendingDelete(hashes);
      return;
    }
    setBusy(true);
    try {
      const response = await fetch("/api/widgets/qbit/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          instance: instanceId,
          action: actionName,
          hashes: hashes.join("|"),
          deleteFiles,
        }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Action failed");
      setSelected([]);
      await load();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Action failed");
    } finally {
      setBusy(false);
    }
  }

  async function submitAddTorrent(form: AddForm) {
    setAddBusy(true);
    setAddError("");
    try {
      const response = await fetch("/api/widgets/qbit/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          instance: instanceId,
          action: "add",
          urls: form.urls,
          autoTMM: form.autoTMM,
          savepath: form.savepath,
          rename: form.rename,
          category: form.category,
          startTorrent: form.startTorrent,
          addToTopOfQueue: form.addToTopOfQueue,
          stopCondition: form.stopCondition,
          skipChecking: form.skipChecking,
          contentLayout: form.contentLayout,
          sequentialDownload: form.sequentialDownload,
          firstLastPiecePrio: form.firstLastPiecePrio,
          dlLimitKib: form.dlLimit ? Number(form.dlLimit) : undefined,
          upLimitKib: form.upLimit ? Number(form.upLimit) : undefined,
        }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to add torrent");
      setShowAdd(false);
      await load();
    } catch (cause) {
      setAddError(cause instanceof Error ? cause.message : "Failed to add torrent");
    } finally {
      setAddBusy(false);
    }
  }

  async function confirmDelete(deleteFiles: boolean) {
    if (!pendingDelete?.length) return;
    const hashes = pendingDelete;
    setBusy(true);
    try {
      const response = await fetch("/api/widgets/qbit/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          instance: instanceId,
          action: "delete",
          hashes: hashes.join("|"),
          deleteFiles,
        }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Action failed");
      setPendingDelete(null);
      setSelected([]);
      await load();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Action failed");
    } finally {
      setBusy(false);
    }
  }

  if (!data) {
    return (
      <div className="hd-widget-body qbit-body-flat" ref={rootRef}>
        <div className="qbit-toolbar">
          <div className="qbit-toolbar-left">
            <span className={`qbit-status ${error ? "qbit-status--warn" : "qbit-status--idle"}`}>
              {error ? "Offline" : "Connecting"}
            </span>
          </div>
          {error ? (
            <div className="qbit-toolbar-right">
              <button className="qbit-tool-btn" type="button" onClick={load}>
                Retry
              </button>
            </div>
          ) : null}
        </div>
      </div>
    );
  }

  const transfer = data.transfer;
  const connectionSource: ConnectionSource = data.connectionSource || "unknown";

  return (
    <div className="hd-widget-body qbit-body-flat" ref={rootRef}>
      <ConnectionCorner source={connectionSource} />
      <div className="qbit-toolbar">
        <div className="qbit-toolbar-left">
          <span className={`qbit-status ${error ? "qbit-status--warn" : "qbit-status--active"}`}>
            {error ? "Degraded" : "Online"}
          </span>
        </div>
        <div className="qbit-toolbar-right">
          {openHref ? (
            <a className="qbit-tool-btn qbit-tool-btn--open" href={openHref} target="_blank" rel="noopener noreferrer">
              Open
            </a>
          ) : null}
        </div>
      </div>

      {error ? <div className="qbit-inline-error">{error}</div> : null}

      <div className="qbit-speeds-bar">
        <Metric tone="dl" value={speed(transfer.dl_info_speed || 0)} label="Download" />
        <Metric tone="ul" value={speed(transfer.up_info_speed || 0)} label="Upload" />
        <Metric
          tone="ratio"
          value={`${bytes(transfer.dl_info_data || 0)} / ${bytes(transfer.up_info_data || 0)}`}
          label="Session DL / UL"
        />
        <Metric tone="free" value={bytes(data.freeSpace)} label="Free Space" />
      </div>

      <div className="qbit-actions-row">
        <button
          className="qbit-toolbar-btn qbit-toolbar-btn--add"
          type="button"
          disabled={busy}
          onClick={() => {
            setAddError("");
            setShowAdd(true);
          }}
        >
          + Add
        </button>
        {selected.length ? (
          <>
            <span className="qbit-selection-badge">{selected.length} selected</span>
            <button
              className="qbit-toolbar-btn qbit-toolbar-btn--resume"
              type="button"
              disabled={busy}
              onClick={() => runAction("resume", selected)}
            >
              ▶ Resume
            </button>
            <button
              className="qbit-toolbar-btn qbit-toolbar-btn--pause"
              type="button"
              disabled={busy}
              onClick={() => runAction("pause", selected)}
            >
              ⏸ Pause
            </button>
            <button
              className="qbit-toolbar-btn qbit-toolbar-btn--delete"
              type="button"
              disabled={busy}
              onClick={() => runAction("delete", selected)}
            >
              Delete
            </button>
          </>
        ) : (
          <>
            <button
              className="qbit-toolbar-btn qbit-toolbar-btn--resume"
              type="button"
              disabled={busy}
              onClick={() => runAction("resume", ["all"])}
            >
              ▶ Resume All
            </button>
            <button
              className="qbit-toolbar-btn qbit-toolbar-btn--pause"
              type="button"
              disabled={busy}
              onClick={() => runAction("pause", ["all"])}
            >
              ⏸ Pause All
            </button>
            <button
              className="qbit-toolbar-btn"
              type="button"
              disabled={busy}
              onClick={() => runAction("recheck", ["all"])}
            >
              Recheck All
            </button>
            <button
              className="qbit-toolbar-btn qbit-toolbar-btn--select-all"
              type="button"
              disabled={busy || !torrents.length}
              onClick={selectAll}
              title={filter === "all" ? "Select all torrents" : `Select all ${FILTERS.find((item) => item.key === filter)?.label.toLowerCase()} torrents`}
            >
              ☑ Select All
            </button>
          </>
        )}
      </div>

      <div className="qbit-filter-bar">
        <input
          className="qbit-search"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search torrents…"
        />
        <div className="qbit-filter-tabs">
          {FILTERS.map((item) => (
            <button
              key={item.key}
              type="button"
              className={`qbit-filter-tab${filter === item.key ? " qbit-filter-tab--active" : ""}`}
              onClick={() => setFilter(item.key)}
            >
              {item.label}
              <em>{count(item.key)}</em>
            </button>
          ))}
        </div>
      </div>

      <div className="qbit-torrent-list">
        {torrents.length ? (
          torrents.map((torrent) => {
            const kind = stateClass(torrent.state.toLowerCase());
            const paused = isPaused(torrent.state);
            return (
              <div
                className={`qbit-torrent-row${selected.includes(torrent.hash) ? " qbit-torrent-row--selected" : ""}`}
                key={torrent.hash}
              >
                <div className="qbit-torrent-top">
                  <input
                    className="qbit-torrent-check"
                    type="checkbox"
                    checked={selected.includes(torrent.hash)}
                    onChange={() => toggle(torrent.hash)}
                  />
                  <span className="qbit-torrent-name" title={torrent.name}>
                    {torrent.name}
                  </span>
                  <span className={`qbit-state-badge qbit-state--${kind}`}>{kind.toUpperCase()}</span>
                </div>
                <div className="qbit-torrent-progress">
                  <div className="qbit-progress-track">
                    <div
                      className={`qbit-progress-fill qbit-progress-fill--${kind}`}
                      style={{ width: `${Math.round((torrent.progress || 0) * 100)}%` }}
                    />
                  </div>
                  <span>{Math.round((torrent.progress || 0) * 100)}%</span>
                </div>
                <div className="qbit-torrent-meta">
                  <span className="qbit-meta-chip">{bytes(torrent.size || 0)}</span>
                  <span className="qbit-meta-chip qbit-meta-chip--ratio">
                    ⇄ {(torrent.ratio || 0).toFixed(2)}
                  </span>
                  {torrent.category ? (
                    <span className="qbit-meta-chip qbit-meta-chip--cat">{torrent.category}</span>
                  ) : null}
                  <span className="qbit-meta-chip">
                    {torrent.dlspeed
                      ? `↓ ${speed(torrent.dlspeed)}`
                      : torrent.upspeed
                        ? `↑ ${speed(torrent.upspeed)}`
                        : ""}
                  </span>
                </div>
                <div className="qbit-torrent-actions">
                  <button
                    className={`qbit-row-btn qbit-row-btn--${paused ? "resume" : "pause"}`}
                    type="button"
                    disabled={busy}
                    onClick={() => runAction(paused ? "resume" : "pause", [torrent.hash])}
                  >
                    {paused ? "▶ Resume" : "⏸ Pause"}
                  </button>
                  <button
                    className="qbit-row-btn qbit-row-btn--recheck"
                    type="button"
                    disabled={busy}
                    onClick={() => runAction("recheck", [torrent.hash])}
                  >
                    Recheck
                  </button>
                  <button
                    className="qbit-row-btn qbit-row-btn--delete"
                    type="button"
                    disabled={busy}
                    onClick={() => runAction("delete", [torrent.hash])}
                  >
                    Delete
                  </button>
                </div>
              </div>
            );
          })
        ) : (
          <div className="qbit-empty">No torrents in this filter</div>
        )}
      </div>

      <div className="qbit-foot-meta">
        {data.torrents.length} torrent{data.torrents.length === 1 ? "" : "s"}
        {torrents.length !== data.torrents.length ? ` · ${torrents.length} shown` : ""}
      </div>

      {pendingDelete ? (
        <DeleteConfirm
          count={pendingDelete.length}
          busy={busy}
          deleteFiles={deleteFiles}
          onDeleteFilesChange={handleDeleteFilesChange}
          onCancel={() => setPendingDelete(null)}
          onConfirm={confirmDelete}
        />
      ) : null}

      {showAdd ? (
        <AddTorrentModal
          busy={addBusy}
          error={addError}
          categories={data.categories || []}
          categorySavePaths={data.categorySavePaths || {}}
          defaultSavePath={data.defaultSavePath || ""}
          onCancel={() => setShowAdd(false)}
          onSubmit={submitAddTorrent}
        />
      ) : null}
    </div>
  );
}

function Metric({ tone, value, label }: { tone: string; value: string; label: string }) {
  return (
    <div className="qbit-speed-card">
      <div className={`qbit-speed-val qbit-speed-val--${tone}`}>{value}</div>
      <div className="qbit-speed-label">{label}</div>
    </div>
  );
}
