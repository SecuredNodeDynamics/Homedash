import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "qbit",
  name: "qBittorrent",
  description: "Torrent download manager",
  version: "0.2.1",
  category: "Downloads",
  defaultSize: { w: 5, h: 5, minW: 3, minH: 3 },
  hostClass: "qbit-host qbit-manager-host",
  configFields: [
    { key: "baseUrl", label: "Private - IP", type: "url", placeholder: "http://10.0.0.1:8080" },
    { key: "fallbackUrl", label: "Fallback Public URL", type: "url" , placeholder: "https://qbit.example.com" },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url", placeholder: "http://10.0.0.1:8080" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    {
      key: "apiKey",
      label: "API Key (WebUI Settings -> API Key, qBittorrent 5.2.0+)",
      type: "password",
      required: true,
    },
  ],
};
