"use client";
import "@/styles/widgets/radarr.widget.css";
import "@/styles/widgets/arr.widgets.css";


import ArrOverviewWidget from "@/widgets/_shared/ArrOverviewWidget";
import type { ArrQueueCard } from "@/widgets/_shared/ArrOverviewWidget";

export default function RadarrWidget() {
  return (
    <ArrOverviewWidget
      apiId="radarr"
      fallbackId="radarr"
      initialTab="monitored"
      accentClass="arr-widget--radarr"
      pollMs={30_000}
      mapData={(data) => ({
        href: String(data.href || ""),
        connectionSource: (data.connectionSource as "private" | "public" | "unknown") || "unknown",
        stats: [
          { label: "Movies", value: Number(data.total || 0), tab: "all" },
          { label: "Monitored", value: Number(data.monitored || 0), tone: "ok", tab: "monitored" },
          {
            label: "Missing",
            value: Number(data.wanted || 0),
            tone: "warn",
            tab: "missing",
          },
          {
            label: "Queued",
            value: Number(data.queued || 0),
            tone: "active",
            tab: "queued",
          },
        ],
        missingItems: Array.isArray(data.missingItems)
          ? (data.missingItems as ArrQueueCard[])
          : [],
        queueItems: Array.isArray(data.queueItems)
          ? (data.queueItems as ArrQueueCard[])
          : [],
        libraryItems: Array.isArray(data.libraryItems)
          ? (data.libraryItems as ArrQueueCard[])
          : [],
        monitoredItems: Array.isArray(data.monitoredItems)
          ? (data.monitoredItems as ArrQueueCard[])
          : [],
      })}
    />
  );
}
