import type { WidgetManifest } from "@/lib/types";

const fields = [
  { key: "baseUrl", label: "Private - IP", type: "url" as const, placeholder: "http://10.0.0.1:7878" },
  { key: "fallbackUrl", label: "Fallback Public URL", type: "url" as const, placeholder: "https://radarr.example.com" },
  { key: "publicUrl", label: "OPEN - Private URL", type: "url" as const, placeholder: "http://10.0.0.1:7878" },
  { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url" as const, placeholder: "https://… (Cloudflare)" },
  { key: "apiKey", label: "API Key", type: "password" as const, required: true },
];

export const manifest: WidgetManifest = {
  id: "radarr",
  name: "Radarr",
  description: "Movie library activity",
  version: "0.2.7",
  category: "Media",
  defaultSize: { w: 4, h: 4, minW: 2, minH: 2 },
  hostClass: "arr-host",
  configFields: fields,
};
