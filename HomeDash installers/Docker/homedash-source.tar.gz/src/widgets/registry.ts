import type { ComponentType } from "react";
import type { WidgetManifest, WidgetModule } from "@/lib/types";

import { manifest as clockManifest } from "./clock/manifest";
import { manifest as notesManifest } from "./notes/manifest";
import { manifest as todoManifest } from "./todo/manifest";
import { manifest as grocery_listManifest } from "./grocery-list/manifest";
import { manifest as bookmarksManifest } from "./bookmarks/manifest";
import { manifest as weatherManifest } from "./weather/manifest";

type LazyEntry = {
  manifest: WidgetManifest;
  load: () => Promise<{ default: ComponentType }>;
};

function entry(manifest: WidgetManifest, load: LazyEntry["load"]): LazyEntry {
  return { manifest, load };
}

/** Minimal PVE distribution. Additional widgets are installed from .hdwidget packages. */
export const widgetRegistry: WidgetModule[] = [
  entry(clockManifest, () => import("./clock/Widget")),
  entry(notesManifest, () => import("./notes/Widget")),
  entry(todoManifest, () => import("./todo/Widget")),
  entry(grocery_listManifest, () => import("./grocery-list/Widget")),
  entry(bookmarksManifest, () => import("./bookmarks/Widget")),
  entry(weatherManifest, () => import("./weather/Widget")),
];

export function getWidget(id: string) {
  return widgetRegistry.find((widget) => widget.manifest.id === id);
}

export function listWidgets() {
  return widgetRegistry.map((widget) => widget.manifest);
}
