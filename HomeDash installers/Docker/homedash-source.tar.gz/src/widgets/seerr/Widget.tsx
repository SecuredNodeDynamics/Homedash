"use client";
import "@/styles/widgets/seerr.widget.css";


import { useCallback, useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";
import type { SeerrLibrary, SeerrRequest, SeerrSearchItem, SeerrSyncStatus } from "@/lib/widgets/seerr";

const TMDB = "https://image.tmdb.org/t/p/w200";
const TMDB_BACK = "https://image.tmdb.org/t/p/w780";

const SECTION_ORDER = ["pending", "approved", "processing", "missing", "available", "declined"] as const;
type SectionKey = (typeof SECTION_ORDER)[number];

type ConnectionSource = "private" | "public" | "unknown";

const CONNECTION_SOURCE_LABEL: Record<ConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

const STATUS_MAP: Record<number, SectionKey> = {
  1: "pending",
  2: "approved",
  3: "declined",
  4: "available",
  5: "processing",
};

const SECTION_META: Record<
  SectionKey,
  { label: string; accentCls: string }
> = {
  pending: { label: "Pending", accentCls: "sr-section--pending" },
  approved: { label: "Approved", accentCls: "sr-section--approved" },
  processing: { label: "Processing", accentCls: "sr-section--processing" },
  missing: { label: "Missing", accentCls: "sr-section--missing" },
  available: { label: "Available", accentCls: "sr-section--available" },
  declined: { label: "Declined", accentCls: "sr-section--declined" },
};

const SEARCH_STATUS_LABEL: Record<number, string> = {
  2: "Pending",
  3: "Processing",
  4: "Partial",
  5: "Available",
};

const SEARCH_STATUS_CLS: Record<number, string> = {
  2: "sr-search-result__status--pending",
  3: "sr-search-result__status--processing",
  4: "sr-search-result__status--processing",
  5: "sr-search-result__status--available",
};

const SEASON_STATUS: Record<number, { label: string; cls: string }> = {
  1: { label: "Pending", cls: "sr-popup__season-badge--pending" },
  2: { label: "Approved", cls: "sr-popup__season-badge--approved" },
  3: { label: "Declined", cls: "sr-popup__season-badge--declined" },
  4: { label: "Processing", cls: "sr-popup__season-badge--processing" },
  5: { label: "Available", cls: "sr-popup__season-badge--available" },
};

type Counts = Record<string, number>;

type DetailTarget = {
  mediaType: string;
  mediaId: number;
  title: string;
  year: string;
  overview: string;
  poster: string;
  backdrop: string;
  vote: string;
  status: number | null;
  url: string;
};

type CardPopupTarget = {
  title: string;
  user: string;
  age: string;
  /** ISO timestamp the request started processing (approval/last update, else created). */
  processingSince: string;
  poster: string;
  url: string;
  pending: boolean;
  processing: boolean;
  requestId: number;
  mediaType: string;
  mediaId: number;
  statusLabel: string;
  seasons: Array<{ seasonNumber: number; status: number }>;
};

function timeAgo(dateStr?: string) {
  if (!dateStr) return "";
  const diff = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000);
  if (!Number.isFinite(diff) || diff < 0) return "";
  if (diff < 60) return `${diff}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

function formatDuration(ms: number) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const d = Math.floor(total / 86400);
  const h = Math.floor((total % 86400) / 3600);
  const m = Math.floor((total % 3600) / 60);
  if (d > 0) return `${d}d ${h}h ${m}m`;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m`;
  return `${total}s`;
}

function lastSyncedStorageKey(instanceId: string) {
  return `sr:last-synced:${instanceId}`;
}

function formatLastSynced(ts: number) {
  return new Date(ts).toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

function groupRequests(requests: SeerrRequest[]) {
  const groups = Object.fromEntries(SECTION_ORDER.map((key) => [key, [] as SeerrRequest[]])) as Record<
    SectionKey,
    SeerrRequest[]
  >;
  for (const req of requests) {
    if (req.media?.status === 5) {
      groups.available.push(req);
    } else if (req.media?.status === 4) {
      // Partially available: some content already processed and imported,
      // but the request isn't fully available yet - surface it separately
      // instead of letting it sit invisibly in Approved/Processing.
      groups.missing.push(req);
    } else {
      const key = STATUS_MAP[req.status];
      if (key) groups[key].push(req);
    }
  }
  return groups;
}

function CardPopup({
  target,
  instanceId,
  onClose,
  onAction,
  onProcessingAction,
}: {
  target: CardPopupTarget;
  instanceId: string;
  onClose: () => void;
  onAction: (id: number, action: "approve" | "decline") => Promise<void>;
  onProcessingAction: (id: number, action: "delete" | "remove-arr" | "retry") => Promise<void>;
}) {
  const [busy, setBusy] = useState<"approve" | "decline" | null>(null);
  const [processingBusy, setProcessingBusy] = useState<"delete" | "remove-arr" | null>(null);
  const [retryState, setRetryState] = useState<{ status: "idle" | "busy" | "ok" | "error"; message: string }>({
    status: "idle",
    message: "",
  });
  const [arrLink, setArrLink] = useState<{ url: string; label: string } | null>(null);
  const [now, setNow] = useState(() => Date.now());
  const sinceMs = target.processingSince ? new Date(target.processingSince).getTime() : NaN;
  const hasSince = target.processing && Number.isFinite(sinceMs);

  useEffect(() => {
    if (!hasSince) return;
    const timer = window.setInterval(() => setNow(Date.now()), 30_000);
    return () => window.clearInterval(timer);
  }, [hasSince]);
  const [overview, setOverview] = useState("");
  const [backdrop, setBackdrop] = useState("");
  const [year, setYear] = useState("");
  const [poster, setPoster] = useState(target.poster);
  const isTV = target.mediaType === "tv";

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  useEffect(() => {
    let alive = true;
    setOverview("");
    setBackdrop("");
    setYear("");
    setPoster(target.poster);
    if (!target.mediaId) return;
    (async () => {
      try {
        const response = await fetch(
          `/api/widgets/seerr/action?instance=${encodeURIComponent(instanceId)}&kind=media&type=${encodeURIComponent(target.mediaType)}&id=${target.mediaId}`,
        );
        const json = await response.json();
        const detail = json.detail || {};
        if (!alive) return;
        setOverview(String(detail.overview || ""));
        if (detail.backdropPath) setBackdrop(`${TMDB_BACK}${detail.backdropPath}`);
        if (detail.posterPath) {
          setPoster(`https://image.tmdb.org/t/p/w342${detail.posterPath}`);
        }
        const date = String(detail.releaseDate || detail.firstAirDate || "");
        if (date) setYear(date.slice(0, 4));
      } catch {
        /* keep card data */
      }
    })();
    return () => {
      alive = false;
    };
  }, [instanceId, target.mediaId, target.mediaType, target.poster]);

  useEffect(() => {
    let alive = true;
    setArrLink(null);
    if (!target.requestId || target.pending) return;
    (async () => {
      try {
        const response = await fetch(
          `/api/widgets/seerr/action?instance=${encodeURIComponent(instanceId)}&kind=arr-link&id=${target.requestId}`,
        );
        const json = (await response.json()) as { url?: string; label?: string };
        if (alive && response.ok && json.url) setArrLink({ url: json.url, label: json.label || (isTV ? "Sonarr" : "Radarr") });
      } catch {
        /* no link available */
      }
    })();
    return () => {
      alive = false;
    };
  }, [instanceId, target.requestId, target.pending, isTV]);

  const typeLabel = isTV ? "TV Series" : "Movie";
  const kicker = ["Seerr", typeLabel, year].filter(Boolean).join(" · ");
  const meta = [target.user ? `Requested by ${target.user}` : "", target.age, target.statusLabel]
    .filter(Boolean)
    .join(" · ");
  const largePoster = poster.includes("/w200/")
    ? poster.replace("/w200/", "/w342/")
    : poster;

  return createPortal(
    <>
      <div className="sr-popup-backdrop sr-popup-backdrop--dim" onClick={onClose} />
      <div
        className={`sr-detail-popup${isTV && target.seasons.length ? " sr-detail-popup--with-list" : ""}`}
        role="dialog"
        aria-modal="true"
        aria-label={target.title}
      >
        <button className="sr-detail-popup__close" type="button" aria-label="Close" onClick={onClose}>
          ×
        </button>
        {backdrop ? (
          <div className="sr-detail-popup__bg" style={{ backgroundImage: `url('${backdrop}')` }} />
        ) : null}
        <div className="sr-detail-popup__body sr-detail-popup__body--media">
          <div className="sr-detail-popup__poster-wrap">
            {largePoster ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img className="sr-detail-popup__poster-lg" src={largePoster} alt={target.title} />
            ) : (
              <div className="sr-detail-popup__poster-placeholder">{target.title.charAt(0)}</div>
            )}
          </div>
          <div className="sr-detail-popup__info">
            <div className="sr-detail-popup__kicker">{kicker}</div>
            <div className="sr-detail-popup__title">{target.title}</div>
            {meta ? <div className="sr-detail-popup__meta">{meta}</div> : null}
            {hasSince ? (
              <div className="sr-detail-popup__processing">
                <span className="sr-detail-popup__processing-label">Processing for</span>
                <strong className="sr-detail-popup__processing-time">{formatDuration(now - sinceMs)}</strong>
                <span className="sr-detail-popup__processing-since">since {formatLastSynced(sinceMs)}</span>
              </div>
            ) : null}
            {target.statusLabel ? (
              <div className="sr-detail-popup__badges">
                <span className="sr-detail-popup__badge sr-detail-popup__badge--request">
                  {target.statusLabel}
                </span>
              </div>
            ) : null}
            <div className="sr-detail-popup__summary">{overview || "No summary available."}</div>

            <div className="sr-detail-popup__actions">
              <a
                className="sr-detail-popup__request-btn"
                href={target.url}
                target="_blank"
                rel="noopener noreferrer"
              >
                Open in Seerr
              </a>
              {arrLink ? (
                <a
                  className={`sr-detail-popup__request-btn sr-detail-popup__request-btn--${isTV ? "sonarr" : "radarr"}`}
                  href={arrLink.url}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Open in {arrLink.label}
                </a>
              ) : null}
              {target.pending ? (
                <>
                  <button
                    className="sr-detail-popup__view-link sr-detail-popup__view-link--approve"
                    type="button"
                    disabled={!!busy}
                    onClick={async () => {
                      setBusy("approve");
                      await onAction(target.requestId, "approve");
                      onClose();
                    }}
                  >
                    {busy === "approve" ? "Approving…" : "Approve"}
                  </button>
                  <button
                    className="sr-detail-popup__view-link sr-detail-popup__view-link--decline"
                    type="button"
                    disabled={!!busy}
                    onClick={async () => {
                      setBusy("decline");
                      await onAction(target.requestId, "decline");
                      onClose();
                    }}
                  >
                    {busy === "decline" ? "Declining…" : "Decline"}
                  </button>
                </>
              ) : null}
              {target.processing ? (
                <>
                  <button
                    className="sr-detail-popup__view-link sr-detail-popup__view-link--retry"
                    type="button"
                    disabled={retryState.status === "busy" || !!processingBusy}
                    title="Re-send this request to Radarr/Sonarr to try processing it again"
                    onClick={async () => {
                      setRetryState({ status: "busy", message: "" });
                      try {
                        await onProcessingAction(target.requestId, "retry");
                        setRetryState({ status: "ok", message: "Request re-sent — processing should restart shortly." });
                      } catch (error) {
                        setRetryState({
                          status: "error",
                          message: error instanceof Error ? error.message : "Retry failed",
                        });
                      }
                    }}
                  >
                    {retryState.status === "busy" ? "Resending…" : "Retry request"}
                  </button>
                  <button
                    className="sr-detail-popup__view-link sr-detail-popup__view-link--remove"
                    type="button"
                    disabled={!!processingBusy}
                    onClick={async () => {
                      if (!window.confirm(`Remove “${target.title}” from ${isTV ? "Sonarr" : "Radarr"}? Files will also be deleted.`)) return;
                      setProcessingBusy("remove-arr");
                      await onProcessingAction(target.requestId, "remove-arr");
                      onClose();
                    }}
                  >
                    {processingBusy === "remove-arr"
                      ? "Removing…"
                      : `Remove from ${isTV ? "Sonarr" : "Radarr"}`}
                  </button>
                  <button
                    className="sr-detail-popup__view-link sr-detail-popup__view-link--decline"
                    type="button"
                    disabled={!!processingBusy}
                    onClick={async () => {
                      if (!window.confirm(`Delete the request for “${target.title}”?`)) return;
                      setProcessingBusy("delete");
                      await onProcessingAction(target.requestId, "delete");
                      onClose();
                    }}
                  >
                    {processingBusy === "delete" ? "Deleting…" : "Delete"}
                  </button>
                </>
              ) : null}
            </div>
            {retryState.message ? (
              <div className={`sr-detail-popup__retry-msg sr-detail-popup__retry-msg--${retryState.status}`}>
                {retryState.message}
              </div>
            ) : null}

            {isTV && target.seasons.length ? (
              <div className="sr-detail-popup__list-section">
                <div className="sr-detail-popup__section-label">
                  {target.seasons.length} Season{target.seasons.length !== 1 ? "s" : ""} Requested
                </div>
                <div className="sr-detail-popup__season-list">
                  {[...target.seasons]
                    .sort((a, b) => a.seasonNumber - b.seasonNumber)
                    .map((season, index) => {
                      const st = SEASON_STATUS[season.status] || {
                        label: "Unknown",
                        cls: "sr-popup__season-badge--unknown",
                      };
                      return (
                        <div
                          className="sr-detail-popup__season-row"
                          key={season.seasonNumber}
                          style={{ ["--sr-season-i" as string]: index } as CSSProperties}
                        >
                          <span className="sr-detail-popup__season-num">
                            {season.seasonNumber === 0
                              ? "Sp"
                              : String(season.seasonNumber).padStart(2, "0")}
                          </span>
                          <span className="sr-detail-popup__season-name">
                            {season.seasonNumber === 0
                              ? "Specials"
                              : `Season ${season.seasonNumber}`}
                          </span>
                          <span className={`sr-popup__season-badge ${st.cls}`}>{st.label}</span>
                        </div>
                      );
                    })}
                </div>
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </>,
    document.body,
  );
}

function DetailPopup({
  target,
  instanceId,
  onClose,
  onRequested,
}: {
  target: DetailTarget;
  instanceId: string;
  onClose: () => void;
  onRequested: () => void;
}) {
  const isTV = target.mediaType === "tv";
  const alreadyAdded = target.status != null && target.status >= 3;
  const statusLabel = target.status != null ? SEARCH_STATUS_LABEL[target.status] : null;
  const [loading, setLoading] = useState(true);
  const [seasons, setSeasons] = useState<number[]>([]);
  const [seasonStatus, setSeasonStatus] = useState<Record<number, number>>({});
  const [selectedSeasons, setSelectedSeasons] = useState<number[]>([]);
  const [servers, setServers] = useState<
    Array<{ id: number; name: string; isDefault?: boolean; activeDirectory?: string }>
  >([]);
  const [serverId, setServerId] = useState<number | null>(null);
  const [folders, setFolders] = useState<Array<{ path: string; freeSpace?: number }>>([]);
  const [rootFolder, setRootFolder] = useState<string | null>(null);
  const [requestState, setRequestState] = useState<"idle" | "busy" | "ok" | "err">("idle");
  const [requestMsg, setRequestMsg] = useState("");

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  useEffect(() => {
    let alive = true;
    (async () => {
      setLoading(true);
      try {
        const serviceType = isTV ? "sonarr" : "radarr";
        const [mediaRes, servicesRes] = await Promise.all([
          isTV
            ? fetch(
                `/api/widgets/seerr/action?instance=${encodeURIComponent(instanceId)}&kind=media&type=tv&id=${target.mediaId}`,
              ).then((r) => r.json())
            : Promise.resolve(null),
          alreadyAdded
            ? Promise.resolve({ services: [] })
            : fetch(
                `/api/widgets/seerr/action?instance=${encodeURIComponent(instanceId)}&kind=services&type=${serviceType}`,
              ).then((r) => r.json()),
        ]);

        if (!alive) return;

        if (isTV && mediaRes?.detail) {
          const map: Record<number, number> = {};
          for (const season of mediaRes.detail.mediaInfo?.seasons || []) {
            map[season.seasonNumber] = season.status;
          }
          const all = (mediaRes.detail.seasons || [])
            .map((s: { seasonNumber?: number }) => s.seasonNumber || 0)
            .filter((n: number) => n > 0)
            .sort((a: number, b: number) => a - b);
          setSeasonStatus(map);
          setSeasons(all);
          setSelectedSeasons(
            all.filter((n: number) => {
              const st = map[n];
              return !st || (st !== 5 && st !== 3 && st !== 4);
            }),
          );
        }

        const list = servicesRes?.services || [];
        setServers(list);
        const def = list.find((s: { isDefault?: boolean }) => s.isDefault) || list[0] || null;
        if (def) {
          setServerId(def.id);
          setRootFolder(def.activeDirectory || null);
          const detailRes = await fetch(
            `/api/widgets/seerr/action?instance=${encodeURIComponent(instanceId)}&kind=services&type=${serviceType}&id=${def.id}`,
          ).then((r) => r.json());
          if (!alive) return;
          const roots = detailRes?.detail?.rootFolders || [];
          setFolders(roots);
          if (!def.activeDirectory && roots[0]?.path) setRootFolder(roots[0].path);
        }
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, [alreadyAdded, instanceId, isTV, target.mediaId]);

  async function changeServer(nextId: number) {
    setServerId(nextId);
    const serviceType = isTV ? "sonarr" : "radarr";
    const detailRes = await fetch(
      `/api/widgets/seerr/action?instance=${encodeURIComponent(instanceId)}&kind=services&type=${serviceType}&id=${nextId}`,
    ).then((r) => r.json());
    const roots = detailRes?.detail?.rootFolders || [];
    setFolders(roots);
    const match = servers.find((s) => s.id === nextId);
    setRootFolder(match?.activeDirectory || roots[0]?.path || null);
  }

  async function submitRequest() {
    setRequestState("busy");
    setRequestMsg("");
    try {
      const response = await fetch("/api/widgets/seerr/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          instance: instanceId,
          action: "request",
          mediaType: target.mediaType,
          mediaId: target.mediaId,
          seasons: isTV ? selectedSeasons : undefined,
          serverId,
          rootFolder,
        }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Request failed");
      setRequestState("ok");
      setRequestMsg("Requested");
      onRequested();
    } catch (error) {
      setRequestState("err");
      setRequestMsg(error instanceof Error ? error.message : "Request failed");
    }
  }

  const typeLabel = isTV ? "TV Series" : "Movie";
  const kicker = ["Seerr", typeLabel, target.year].filter(Boolean).join(" · ");
  const metaBits = [
    target.vote && parseFloat(target.vote) > 0 ? `★ ${target.vote}` : "",
    statusLabel || "",
    target.year,
  ].filter(Boolean);

  return createPortal(
    <>
      <div className="sr-popup-backdrop sr-popup-backdrop--dim" onClick={onClose} />
      <div className="sr-detail-popup" role="dialog" aria-modal="true" aria-label={target.title}>
        <button className="sr-detail-popup__close" type="button" aria-label="Close" onClick={onClose}>
          ×
        </button>
        {target.backdrop ? (
          <div
            className="sr-detail-popup__bg"
            style={{ backgroundImage: `url('${target.backdrop}')` }}
          />
        ) : null}
        <div className="sr-detail-popup__body sr-detail-popup__body--media">
          <div className="sr-detail-popup__poster-wrap">
            {target.poster ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                className="sr-detail-popup__poster-lg"
                src={target.poster.replace("/w200/", "/w342/")}
                alt={target.title}
              />
            ) : (
              <div className="sr-detail-popup__poster-placeholder">{target.title.charAt(0)}</div>
            )}
          </div>
          <div className="sr-detail-popup__info">
            <div className="sr-detail-popup__kicker">{kicker}</div>
            <div className="sr-detail-popup__title">{target.title}</div>
            {metaBits.length ? (
              <div className="sr-detail-popup__meta">{metaBits.join(" · ")}</div>
            ) : null}
            {statusLabel ? (
              <div className="sr-detail-popup__badges">
                <span
                  className={`sr-detail-popup__badge sr-detail-popup__badge--status-${target.status}`}
                >
                  {statusLabel}
                </span>
              </div>
            ) : null}
            <div className="sr-detail-popup__summary">
              {target.overview || "No summary available."}
            </div>

            {loading ? <div className="sr-search-empty">Loading options…</div> : null}

            {!loading && isTV && seasons.length > 0 && !alreadyAdded ? (
              <div className="sr-season-picker">
                <div className="sr-season-picker__header">
                  <span className="sr-season-picker__title">Seasons</span>
                  <button
                    className="sr-season-picker__all"
                    type="button"
                    onClick={() => {
                      const requestable = seasons.filter((n) => {
                        const st = seasonStatus[n];
                        return !st || (st !== 5 && st !== 3 && st !== 4);
                      });
                      setSelectedSeasons((prev) =>
                        prev.length === requestable.length ? [] : requestable,
                      );
                    }}
                  >
                    All
                  </button>
                </div>
                <div className="sr-season-picker__chips">
                  {seasons.map((n) => {
                    const st = seasonStatus[n];
                    const disabled = st === 5 || st === 3 || st === 4;
                    const stLabel =
                      st === 2
                        ? "Pending"
                        : st === 3 || st === 4
                          ? "Processing"
                          : st === 5
                            ? "Available"
                            : "";
                    const stCls =
                      st === 2
                        ? "sr-season-chip--pending"
                        : st === 3 || st === 4
                          ? "sr-season-chip--processing"
                          : st === 5
                            ? "sr-season-chip--available"
                            : "";
                    return (
                      <label
                        key={n}
                        className={`sr-season-chip ${stCls}${disabled ? " sr-season-chip--done" : ""}`}
                      >
                        <input
                          type="checkbox"
                          checked={selectedSeasons.includes(n)}
                          disabled={disabled}
                          onChange={() =>
                            setSelectedSeasons((prev) =>
                              prev.includes(n) ? prev.filter((x) => x !== n) : [...prev, n],
                            )
                          }
                        />
                        <span className="sr-season-chip__label">{`S${String(n).padStart(2, "0")}`}</span>
                        {stLabel ? <span className="sr-season-chip__status">{stLabel}</span> : null}
                      </label>
                    );
                  })}
                </div>
              </div>
            ) : null}

            {!loading && !alreadyAdded && servers.length > 0 ? (
              <div className="sr-dest-picker">
                <div className="sr-dest-picker__row">
                  <label className="sr-dest-picker__label">Server</label>
                  <select
                    className="sr-dest-picker__select"
                    value={serverId ?? ""}
                    onChange={(event) => changeServer(Number(event.target.value))}
                  >
                    {servers.map((server) => (
                      <option key={server.id} value={server.id}>
                        {server.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="sr-dest-picker__row">
                  <label className="sr-dest-picker__label">Folder</label>
                  <select
                    className="sr-dest-picker__select"
                    value={rootFolder ?? ""}
                    onChange={(event) => setRootFolder(event.target.value)}
                  >
                    {folders.map((folder) => {
                      const label = folder.path.split("/").filter(Boolean).pop() || folder.path;
                      const free = folder.freeSpace
                        ? ` (${Math.round(folder.freeSpace / 1073741824)}GB free)`
                        : "";
                      return (
                        <option key={folder.path} value={folder.path}>
                          {label}
                          {free}
                        </option>
                      );
                    })}
                  </select>
                </div>
              </div>
            ) : null}

            <div className="sr-detail-popup__actions">
              {alreadyAdded ? (
                <button
                  className="sr-detail-popup__request-btn sr-detail-popup__request-btn--already"
                  type="button"
                  disabled
                >
                  {statusLabel || "Added"}
                </button>
              ) : (
                <button
                  className={`sr-detail-popup__request-btn${
                    requestState === "ok"
                      ? " sr-detail-popup__request-btn--success"
                      : requestState === "err"
                        ? " sr-detail-popup__request-btn--error"
                        : ""
                  }`}
                  type="button"
                  disabled={
                    requestState === "busy" ||
                    requestState === "ok" ||
                    loading ||
                    (isTV && selectedSeasons.length === 0)
                  }
                  onClick={submitRequest}
                >
                  {requestState === "busy"
                    ? "Requesting…"
                    : requestState === "ok"
                      ? requestMsg || "Requested"
                      : requestState === "err"
                        ? requestMsg || "Failed"
                        : "Request"}
                </button>
              )}
              <a
                className="sr-detail-popup__view-link"
                href={target.url}
                target="_blank"
                rel="noopener noreferrer"
              >
                Open in Seerr
              </a>
            </div>
          </div>
        </div>
      </div>
    </>,
    document.body,
  );
}

function SyncLibrariesPopup({
  instanceId,
  onClose,
  onSynced,
}: {
  instanceId: string;
  onClose: () => void;
  onSynced: () => void;
}) {
  const [libraries, setLibraries] = useState<SeerrLibrary[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [syncing, setSyncing] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [scanStatus, setScanStatus] = useState<SeerrSyncStatus | null>(null);
  const [scanBusy, setScanBusy] = useState(false);
  const [lastSynced, setLastSynced] = useState<number | null>(null);
  const wasScanRunning = useRef(false);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(lastSyncedStorageKey(instanceId));
      if (raw) setLastSynced(Number(raw));
    } catch {
      // localStorage may be unavailable - the badge just stays empty.
    }
  }, [instanceId]);

  function markSynced() {
    const now = Date.now();
    try {
      window.localStorage.setItem(lastSyncedStorageKey(instanceId), String(now));
    } catch {
      // ignore - not critical, just a display nicety.
    }
    setLastSynced(now);
  }

  const loadScanStatus = useCallback(async () => {
    try {
      const response = await fetch(
        `/api/widgets/seerr/action?instance=${encodeURIComponent(instanceId)}&kind=sync-status`,
      );
      const json = await response.json();
      if (!response.ok) return;
      const status = json as SeerrSyncStatus;
      // A scan that just finished is exactly when Processing/Available/Missing
      // change, so refresh the widget's data the moment we see it stop.
      if (wasScanRunning.current && !status.running) {
        onSynced();
        markSynced();
      }
      wasScanRunning.current = !!status.running;
      setScanStatus(status);
    } catch {
      // Silently ignore - this just powers the progress display.
    }
  }, [instanceId, onSynced]);

  useEffect(() => {
    void loadScanStatus();
    const interval = window.setInterval(() => void loadScanStatus(), 1000);
    return () => window.clearInterval(interval);
  }, [loadScanStatus]);

  async function handleStartScan() {
    setScanBusy(true);
    try {
      const response = await fetch("/api/widgets/seerr/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, action: "start-scan" }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to start scan");
      setScanStatus(json as SeerrSyncStatus);
      wasScanRunning.current = !!(json as SeerrSyncStatus).running;
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to start scan");
    } finally {
      setScanBusy(false);
    }
  }

  async function handleCancelScan() {
    setScanBusy(true);
    try {
      const response = await fetch("/api/widgets/seerr/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, action: "cancel-scan" }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to cancel scan");
      setScanStatus(json as SeerrSyncStatus);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to cancel scan");
    } finally {
      setScanBusy(false);
    }
  }

  const loadLibraries = useCallback(async () => {
    try {
      const response = await fetch(
        `/api/widgets/seerr/action?instance=${encodeURIComponent(instanceId)}&kind=libraries`,
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load libraries");
      setLibraries(json.libraries || []);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load libraries");
    } finally {
      setLoading(false);
    }
  }, [instanceId]);

  useEffect(() => {
    void loadLibraries();
  }, [loadLibraries]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  async function handleSync() {
    setSyncing(true);
    setError("");
    try {
      const response = await fetch("/api/widgets/seerr/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, action: "sync-libraries" }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Sync failed");
      setLibraries(json.libraries || []);
      markSynced();
      onSynced();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sync failed");
    } finally {
      setSyncing(false);
    }
  }

  async function handleToggle(library: SeerrLibrary, nextEnabled: boolean) {
    setBusyId(library.id);
    setLibraries((prev) =>
      prev ? prev.map((lib) => (lib.id === library.id ? { ...lib, enabled: nextEnabled } : lib)) : prev,
    );
    try {
      const response = await fetch("/api/widgets/seerr/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          instance: instanceId,
          action: "toggle-library",
          libraryId: library.id,
          enabled: nextEnabled,
        }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Update failed");
    } catch (err) {
      // Revert the optimistic toggle on failure.
      setLibraries((prev) =>
        prev
          ? prev.map((lib) => (lib.id === library.id ? { ...lib, enabled: library.enabled } : lib))
          : prev,
      );
      setError(err instanceof Error ? err.message : "Update failed");
    } finally {
      setBusyId(null);
    }
  }

  return createPortal(
    <>
      <div className="sr-popup-backdrop sr-popup-backdrop--dim" onClick={onClose} />
      <div className="sr-lib-popup" role="dialog" aria-modal="true" aria-label="Sync Jellyfin Libraries">
        <button className="sr-detail-popup__close" type="button" aria-label="Close" onClick={onClose}>
          ×
        </button>
        <div className="sr-lib-popup__header">
          <span className="sr-lib-popup__title">Jellyfin Libraries</span>
        </div>
        <div className="sr-lib-popup__body">
          <button
            className="sr-lib-sync-btn"
            type="button"
            disabled={syncing}
            onClick={() => void handleSync()}
          >
            <span aria-hidden>⟳</span> {syncing ? "Syncing…" : "Sync Libraries"}
          </button>

          {error ? <div className="sr-error">⚠ {error}</div> : null}

          {loading ? (
            <div className="sr-search-empty">Loading libraries…</div>
          ) : !libraries?.length ? (
            <div className="sr-search-empty">
              No libraries found. Try Sync Libraries to fetch them from Jellyfin.
            </div>
          ) : (
            <div className="sr-lib-grid">
              {libraries.map((library) => (
                <div className="sr-lib-card" key={library.id}>
                  <span className="sr-lib-card__name" title={library.name}>
                    {library.name}
                  </span>
                  <label className="sr-lib-toggle">
                    <input
                      type="checkbox"
                      checked={library.enabled}
                      disabled={busyId === library.id}
                      onChange={(event) => void handleToggle(library, event.target.checked)}
                      aria-label={`Sync ${library.name}`}
                    />
                    <span className="sr-lib-toggle__track" />
                    <span className="sr-lib-toggle__thumb">✓</span>
                  </label>
                </div>
              ))}
            </div>
          )}

          <div className="sr-lib-scan">
            <span className="sr-lib-scan__title">Manual Library Scan</span>
            <div className="sr-lib-scan__bar">
              {scanStatus?.running ? (
                <div
                  className="sr-lib-scan__fill"
                  style={{
                    width: `${
                      scanStatus.total > 0
                        ? Math.round((scanStatus.progress / scanStatus.total) * 100)
                        : 0
                    }%`,
                  }}
                />
              ) : null}
              <span className="sr-lib-scan__bar-label">
                {scanStatus?.running
                  ? `${scanStatus.progress} of ${scanStatus.total}`
                  : "Not Running"}
              </span>
            </div>
            <div className="sr-lib-scan__footer">
              <span className="sr-lib-scan__last-synced">
                {lastSynced ? `Last synced ${formatLastSynced(lastSynced)}` : "Not synced yet"}
              </span>
              <div className="sr-lib-scan__badges">
                {scanStatus?.running && scanStatus.currentLibrary ? (
                  <span className="sr-lib-scan__badge">
                    Current: {scanStatus.currentLibrary.name}
                  </span>
                ) : null}
                {scanStatus?.running ? (
                  <span className="sr-lib-scan__badge sr-lib-scan__badge--warning">
                    Remaining:{" "}
                    {scanStatus.currentLibrary
                      ? scanStatus.libraries.slice(
                          scanStatus.libraries.findIndex(
                            (lib) => lib.id === scanStatus.currentLibrary?.id,
                          ) + 1,
                        ).length
                      : 0}
                  </span>
                ) : null}
              </div>
              {scanStatus?.running ? (
                <button
                  className="sr-lib-scan-btn sr-lib-scan-btn--danger"
                  type="button"
                  disabled={scanBusy}
                  onClick={() => void handleCancelScan()}
                >
                  Cancel Scan
                </button>
              ) : (
                <button
                  className="sr-lib-scan-btn"
                  type="button"
                  disabled={scanBusy}
                  onClick={() => void handleStartScan()}
                >
                  Start Scan
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </>,
    document.body,
  );
}

export default function SeerrWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "seerr";
  const searchWrapRef = useRef<HTMLDivElement>(null);
  const [counts, setCounts] = useState<Counts | null>(null);
  const [requests, setRequests] = useState<SeerrRequest[]>([]);
  const [processing, setProcessing] = useState<SeerrRequest[]>([]);
  const [publicUrl, setPublicUrl] = useState("");
  const [openFallbackUrl, setOpenFallbackUrl] = useState("");
  const [connectionSource, setConnectionSource] = useState<ConnectionSource>("unknown");
  const openHref = useOpenHref(publicUrl, openFallbackUrl);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [sectionOpen, setSectionOpen] = useState<Record<SectionKey, boolean>>({
    pending: false,
    approved: false,
    processing: false,
    missing: false,
    available: false,
    declined: false,
  });
  const openedOnce = useRef(false);
  const [query, setQuery] = useState("");
  const [searchResults, setSearchResults] = useState<SeerrSearchItem[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState("");
  const [detail, setDetail] = useState<DetailTarget | null>(null);
  const [cardPopup, setCardPopup] = useState<CardPopupTarget | null>(null);
  const [syncOpen, setSyncOpen] = useState(false);
  const searchSeq = useRef(0);

  const load = useCallback(async () => {
    try {
      const [statusResponse, processingResponse] = await Promise.all([
        fetch(`/api/widgets/seerr/status?instance=${encodeURIComponent(instanceId)}`),
        fetch(`/api/widgets/seerr/action?instance=${encodeURIComponent(instanceId)}&kind=processing`),
      ]);
      const data = await statusResponse.json();
      if (!statusResponse.ok) throw new Error(data.error || "Failed to load Seerr");
      setCounts(data.counts || {});
      setRequests(data.requests || []);
      setPublicUrl(data.publicUrl || "");
      setOpenFallbackUrl(data.openFallbackUrl || "");
      setConnectionSource(data.connectionSource || "unknown");
      if (processingResponse.ok) {
        const procData = await processingResponse.json();
        setProcessing(procData.requests || []);
      }
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Seerr unavailable");
    } finally {
      setLoading(false);
    }
  }, [instanceId]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: 120_000 });

  useEffect(() => {
    const q = query.trim();
    if (!q) {
      setSearchResults(null);
      setSearchError("");
      setSearching(false);
      return;
    }
    const seq = ++searchSeq.current;
    setSearching(true);
    const timer = window.setTimeout(async () => {
      try {
        const response = await fetch(
          `/api/widgets/seerr/search?instance=${encodeURIComponent(instanceId)}&q=${encodeURIComponent(q)}`,
        );
        const data = await response.json();
        if (seq !== searchSeq.current) return;
        if (!response.ok) throw new Error(data.error || "Search failed");
        setSearchResults(data.results || []);
        setSearchError("");
        if (data.publicUrl) setPublicUrl(data.publicUrl);
        if (data.openFallbackUrl) setOpenFallbackUrl(data.openFallbackUrl);
      } catch (err) {
        if (seq !== searchSeq.current) return;
        setSearchResults([]);
        setSearchError(err instanceof Error ? err.message : "Search failed");
      } finally {
        if (seq === searchSeq.current) setSearching(false);
      }
    }, 280);
    return () => window.clearTimeout(timer);
  }, [query, instanceId]);

  const groups = useMemo(() => {
    const g = groupRequests(requests);
    const procIds = new Set(processing.map((p) => p.id));
    g.approved = g.approved.filter((r) => !procIds.has(r.id));

    // The dedicated "processing" fetch can include items whose media has since
    // moved on to partially-available (4) or fully available (5) - a sync can
    // finish between polls. Re-split those instead of leaving them stuck
    // under Processing.
    const stillProcessing: SeerrRequest[] = [];
    for (const item of processing) {
      if (item.media?.status === 5) {
        if (!g.available.some((r) => r.id === item.id)) g.available.push(item);
      } else if (item.media?.status === 4) {
        if (!g.missing.some((r) => r.id === item.id)) g.missing.push(item);
      } else {
        stillProcessing.push(item);
      }
    }
    g.processing = stillProcessing;
    return g;
  }, [requests, processing]);

  useEffect(() => {
    if (openedOnce.current || !requests.length) return;
    const nextGroups = groupRequests(requests);
    const first = SECTION_ORDER.find((key) => nextGroups[key].length > 0);
    if (!first) return;
    openedOnce.current = true;
    setSectionOpen({
      pending: false,
      approved: false,
      processing: false,
      missing: false,
      available: false,
      declined: false,
      [first]: true,
    });
  }, [requests]);

  const pills = useMemo(() => {
    if (!counts) return [];
    return [
      { label: "Total", value: counts.total ?? 0, cls: "" },
      { label: "Pending", value: counts.pending ?? groups.pending.length, cls: "sr-pill--pending" },
      { label: "Approved", value: groups.approved.length, cls: "sr-pill--approved" },
      { label: "Processing", value: groups.processing.length, cls: "sr-pill--processing" },
      { label: "Missing", value: groups.missing.length, cls: "sr-pill--missing" },
      { label: "Available", value: groups.available.length, cls: "sr-pill--available" },
      { label: "Declined", value: counts.declined ?? groups.declined.length, cls: "sr-pill--declined" },
    ].filter((pill) => pill.value > 0 || pill.label === "Total");
  }, [counts, groups]);

  function toggleSection(key: SectionKey) {
    setSectionOpen((prev) => {
      const nextOpen = !prev[key];
      return {
        pending: false,
        approved: false,
        processing: false,
        missing: false,
        available: false,
        declined: false,
        [key]: nextOpen,
      };
    });
  }

  async function runRequestAction(id: number, action: "approve" | "decline") {
    const response = await fetch("/api/widgets/seerr/action", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ instance: instanceId, action, requestId: id }),
    });
    const json = await response.json();
    if (!response.ok) throw new Error(json.error || "Action failed");
    window.setTimeout(() => {
      void load();
    }, 600);
  }

  async function runProcessingAction(id: number, action: "delete" | "remove-arr" | "retry") {
    const response = await fetch("/api/widgets/seerr/action", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ instance: instanceId, action, requestId: id }),
    });
    const json = await response.json();
    if (!response.ok) throw new Error(json.error || "Action failed");
    window.setTimeout(() => {
      void load();
    }, 600);
  }

  function openSearchItem(item: SeerrSearchItem) {
    const title = item.title || item.name || "Unknown";
    const year = (item.releaseDate || item.firstAirDate || "").slice(0, 4);
    setSearchResults(null);
    setQuery("");
    setDetail({
      mediaType: item.mediaType,
      mediaId: item.id,
      title,
      year,
      overview: item.overview || "",
      poster: item.posterPath ? `${TMDB}${item.posterPath}` : "",
      backdrop: item.backdropPath ? `${TMDB_BACK}${item.backdropPath}` : "",
      vote: item.voteAverage != null ? item.voteAverage.toFixed(1) : "",
      status: item.mediaInfo?.status ?? null,
      url: `${(openHref || publicUrl).replace(/\/$/, "")}/${item.mediaType === "tv" ? "tv" : "movie"}/${item.id}`,
    });
  }

  const dropdown =
    query.trim() && (searching || searchResults || searchError) && searchWrapRef.current
      ? createPortal(
          <div
            className="sr-search-dropdown"
            style={(() => {
              const rect = searchWrapRef.current!.getBoundingClientRect();
              const dw = Math.min(Math.max(rect.width, 420), Math.min(560, window.innerWidth - 16));
              let left = rect.left;
              if (left + dw > window.innerWidth - 8) left = window.innerWidth - dw - 8;
              if (left < 8) left = 8;
              return {
                position: "fixed" as const,
                left,
                top: rect.bottom + 8,
                width: dw,
                zIndex: 2147483000,
              };
            })()}
          >
            {searching ? (
              <div className="sr-search-empty">Searching…</div>
            ) : searchError ? (
              <div className="sr-search-empty">{searchError}</div>
            ) : !searchResults?.length ? (
              <div className="sr-search-empty">No results found</div>
            ) : (
              <>
                <div className="sr-search-dropdown__header">
                  <span className="sr-search-dropdown__label">
                    {searchResults.length} Result{searchResults.length !== 1 ? "s" : ""}
                  </span>
                </div>
                <div className="sr-search-dropdown__grid">
                  {searchResults.map((item, index) => {
                    const title = item.title || item.name || "Unknown";
                    const year = (item.releaseDate || item.firstAirDate || "").slice(0, 4);
                    const type = item.mediaType === "tv" ? "TV Series" : "Movie";
                    const poster = item.posterPath ? `${TMDB}${item.posterPath}` : "";
                    const status = item.mediaInfo?.status;
                    return (
                      <button
                        key={`${item.mediaType}-${item.id}`}
                        className="sr-search-result"
                        type="button"
                        style={{ ["--sr-result-i" as string]: index } as CSSProperties}
                        onClick={() => openSearchItem(item)}
                      >
                        <div className="sr-search-poster">
                          <div className="sr-search-poster__art">
                            {poster ? (
                              // eslint-disable-next-line @next/next/no-img-element
                              <img src={poster} alt={title} loading="lazy" />
                            ) : (
                              <div className="sr-search-poster__placeholder">{title.charAt(0)}</div>
                            )}
                            {status && SEARCH_STATUS_LABEL[status] ? (
                              <span
                                className={`sr-search-result__status ${SEARCH_STATUS_CLS[status] || ""}`}
                              >
                                {SEARCH_STATUS_LABEL[status]}
                              </span>
                            ) : null}
                          </div>
                          <div className="sr-search-poster__title">{title}</div>
                          <div className="sr-search-poster__meta">
                            {type}
                            {year ? ` · ${year}` : ""}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </>
            )}
          </div>,
          document.body,
        )
      : null;

  if (loading && !counts) {
    return (
      <div className="hd-widget-body sr-body" ref={rootRef}>
        <div className="sr-toolbar">
          <span className="sr-status-pill sr-status-pill--loading">
            <span className="sr-status-dot" />
            Loading
          </span>
        </div>
        <div className="sr-skeleton-row" />
        <div className="sr-skeleton-section" />
      </div>
    );
  }

  if (error && !counts) {
    return (
      <div className="hd-widget-body sr-body" ref={rootRef}>
        <div className="sr-toolbar">
          <span className="sr-status-pill sr-status-pill--offline">
            <span className="sr-status-dot" />
            Offline
          </span>
        </div>
        <div className="sr-error">⚠ {error}</div>
        <button className="sr-action-btn sr-action-btn--approve" type="button" onClick={load}>
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="hd-widget-body sr-body" ref={rootRef}>
      {connectionSource !== "unknown" ? (
        <div
          className={`sr-corner-source sr-corner-source--${connectionSource}`}
          title={CONNECTION_SOURCE_LABEL[connectionSource]}
          aria-label={CONNECTION_SOURCE_LABEL[connectionSource]}
        />
      ) : null}
      <div className="sr-toolbar">
        <div className="sr-toolbar-left">
          <span className="sr-status-pill sr-status-pill--online">
            <span className="sr-status-dot" />
            Online
          </span>
        </div>
        <div className="sr-toolbar-right">
          <button className="sr-sync-link" type="button" onClick={() => setSyncOpen(true)}>
            <span aria-hidden>⟳</span> Sync
          </button>
          {openHref ? (
            <a className="sr-open-link" href={openHref} target="_blank" rel="noopener noreferrer">
              Open
            </a>
          ) : null}
        </div>
      </div>

      <div className="sr-search-wrap" ref={searchWrapRef}>
        <span className="sr-search-input-icon" aria-hidden>
          ⌕
        </span>
        <input
          className="sr-search-input"
          type="text"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search movies & TV…"
          autoComplete="off"
          aria-label="Search Seerr"
        />
      </div>

      {pills.length ? (
        <div className="sr-stats">
          {pills.map((pill) => (
            <span className={`sr-stat-pill ${pill.cls}`} key={pill.label}>
              <span className="sr-stat-value">{pill.value}</span>
              {pill.label}
            </span>
          ))}
        </div>
      ) : null}

      <div className="sr-sections">
        {SECTION_ORDER.map((key) => {
          const items = groups[key];
          if (!items.length) return null;
          const meta = SECTION_META[key];
          const open = sectionOpen[key];
          return (
            <div className={`sr-section ${meta.accentCls}`} key={key} data-section={key}>
              <button
                className={`sr-section__header${open ? " sr-section__header--open" : ""}`}
                type="button"
                onClick={() => toggleSection(key)}
              >
                <span className="sr-section__label">{meta.label}</span>
                <span className="sr-section__count">{items.length}</span>
                <span className="sr-section__spacer" />
                <span className="sr-chevron">{open ? "▾" : "▸"}</span>
              </button>
              <div className={`sr-section__body${open ? " sr-section__body--open" : ""}`}>
                <div className="sr-grid">
                  {items.map((req) => {
                    const media = req.media || {};
                    const title = media.title || media.name || "Unknown";
                    const type = media.mediaType || "movie";
                    const poster = media.posterPath ? `${TMDB}${media.posterPath}` : "";
                    const user =
                      req.requestedBy?.displayName || req.requestedBy?.username || "Unknown";
                    const age = timeAgo(req.createdAt);
                    const isPending = req.status === 1;
                    const isProcessing = key === "processing";
                    const isMissing = key === "missing";
                    const isTV = type === "tv";
                    const detailUrl = `${(openHref || publicUrl).replace(/\/$/, "")}/${isTV ? "tv" : "movie"}/${media.tmdbId || ""}`;
                    const statusLabel =
                      media.status === 5
                        ? "Available"
                        : isMissing
                          ? "Missing"
                          : isProcessing
                            ? "Processing"
                            : SECTION_META[STATUS_MAP[req.status] || "pending"]?.label || "Request";

                    return (
                      <button
                        key={req.id}
                        type="button"
                        className={`sr-poster-card sr-poster-card--clickable${isPending ? " sr-poster-card--pending" : ""}${isProcessing ? " sr-poster-card--processing" : ""}${isMissing ? " sr-poster-card--missing" : ""}${isTV ? " sr-poster-card--tv" : ""}`}
                        title={title}
                        onClick={() => {
                          setCardPopup({
                            title,
                            user,
                            age,
                            processingSince: req.updatedAt || req.createdAt || "",
                            poster,
                            url: detailUrl,
                            pending: isPending,
                            processing: isProcessing || isMissing,
                            requestId: req.id,
                            mediaType: type,
                            mediaId: Number(media.tmdbId || 0),
                            statusLabel,
                            seasons: req.seasons || [],
                          });
                        }}
                      >
                        {poster ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img className="sr-poster-card__img" src={poster} alt={title} loading="lazy" />
                        ) : (
                          <div className="sr-poster-card__placeholder">{title.charAt(0)}</div>
                        )}
                        <span className="sr-poster-card__type">{isTV ? "TV" : "Movie"}</span>
                        <div className="sr-poster-card__overlay">
                          <div className="sr-poster-card__title">{title}</div>
                          <div className="sr-poster-card__meta">
                            <span className="sr-poster-card__user">{user}</span>
                            <span className="sr-poster-card__age">{age}</span>
                          </div>
                        </div>
                        {isPending ? (
                          <div className="sr-poster-card__actions">
                            <button
                              className="sr-action-btn sr-action-btn--approve"
                              type="button"
                              onClick={(event) => {
                                event.preventDefault();
                                event.stopPropagation();
                                void runRequestAction(req.id, "approve");
                              }}
                            >
                              Approve
                            </button>
                            <button
                              className="sr-action-btn sr-action-btn--decline"
                              type="button"
                              onClick={(event) => {
                                event.preventDefault();
                                event.stopPropagation();
                                void runRequestAction(req.id, "decline");
                              }}
                            >
                              Decline
                            </button>
                          </div>
                        ) : null}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          );
        })}
        {!loading && !SECTION_ORDER.some((key) => groups[key].length) ? (
          <div className="sr-idle">No recent requests</div>
        ) : null}
      </div>

      {dropdown}
      {detail ? (
        <DetailPopup
          target={detail}
          instanceId={instanceId}
          onClose={() => setDetail(null)}
          onRequested={() => {
            window.setTimeout(() => {
              void load();
            }, 800);
          }}
        />
      ) : null}
      {cardPopup ? (
        <CardPopup
          target={cardPopup}
          instanceId={instanceId}
          onClose={() => setCardPopup(null)}
          onAction={runRequestAction}
          onProcessingAction={runProcessingAction}
        />
      ) : null}
      {syncOpen ? (
        <SyncLibrariesPopup
          instanceId={instanceId}
          onClose={() => {
            setSyncOpen(false);
            void load();
          }}
          onSynced={() => void load()}
        />
      ) : null}
    </div>
  );
}
