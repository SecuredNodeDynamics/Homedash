import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "seerr",
  name: "Seerr",
  description: "Search, request, and manage Jellyseerr / Overseerr requests",
  version: "0.5.4",
  category: "Media",
  defaultSize: { w: 6, h: 5, minW: 3, minH: 3 },
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "http://10.0.0.1:5055",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      placeholder: "https://seerr.example.com",
    },
    {
      key: "publicUrl",
      label: "OPEN - Private URL",
      type: "url",
      placeholder: "http://10.0.0.1:5055",
    },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    { key: "apiKey", label: "API Key", type: "password", required: true },
    { key: "username", label: "Jellyfin/Admin Username", type: "text" },
    { key: "password", label: "Jellyfin/Admin Password", type: "password" },
  ],
};
