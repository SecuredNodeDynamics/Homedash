"use client";
import "@/styles/widgets/shelfmark.widget.css";


import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type TabKey = "overview" | "active" | "recent" | "requests";

type TaskItem = {
  title: string;
  author: string;
  preview?: string;
  progress?: number;
  status?: string;
  bucket?: string;
  type?: string;
  delivery?: string;
  createdAt?: string;
};

type StatusPayload = {
  href: string;
  openFallbackUrl?: string;
  tab: TabKey;
  active?: number;
  complete?: number;
  failed?: number;
  pendingRequests?: number;
  recent?: TaskItem[];
  requests?: TaskItem[];
  items?: TaskItem[];
  error?: string;
};

const TABS: { key: TabKey; label: string }[] = [
  { key: "overview", label: "Overview" },
  { key: "active", label: "Active" },
  { key: "recent", label: "Recent" },
  { key: "requests", label: "Requests" },
];

function coverSrc(instanceId: string, preview?: string) {
  if (!preview) return "";
  if (/^https?:\/\//i.test(preview)) {
    return `/api/widgets/shelfmark/cover?instance=${encodeURIComponent(instanceId)}&path=${encodeURIComponent(preview)}`;
  }
  return `/api/widgets/shelfmark/cover?instance=${encodeURIComponent(instanceId)}&path=${encodeURIComponent(preview)}`;
}

function fmtPct(value: number | null | undefined) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 0;
  return Math.min(100, Math.max(0, Math.round(n)));
}

function fmtTime(ts?: string) {
  if (!ts) return "";
  try {
    const d = new Date(ts);
    return d.toLocaleString("en-US", {
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit",
    });
  } catch {
    return "";
  }
}

function BookIcon({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden>
      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
      <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
    </svg>
  );
}

function CoverArt({
  src,
  alt,
  placeholderClass,
  size = 28,
  children,
}: {
  src: string;
  alt: string;
  placeholderClass: string;
  size?: number;
  children?: ReactNode;
}) {
  const [missing, setMissing] = useState(!src);
  useEffect(() => {
    setMissing(!src);
  }, [src]);
  return (
    <>
      {src && !missing ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={src} alt={alt} loading="lazy" decoding="async" onError={() => setMissing(true)} />
      ) : (
        <div className={placeholderClass}>
          <BookIcon size={size} />
        </div>
      )}
      {children}
    </>
  );
}

function Skeleton() {
  return (
    <div className="sm-skeleton-wrap">
      {Array.from({ length: 5 }, (_, i) => (
        <div key={i} className="sm-skeleton-row" />
      ))}
    </div>
  );
}

function BookCard({
  item,
  index,
  href,
  instanceId,
}: {
  item: TaskItem;
  index: number;
  href: string;
  instanceId: string;
}) {
  const sub = [item.author, item.type, item.status].filter(Boolean).join(" · ");
  const pct = item.progress != null ? fmtPct(item.progress) : null;
  return (
    <a
      className="sm-card"
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      style={{ animationDelay: `${index * 35}ms` }}
      title={item.title}
    >
      <div className="sm-card-art">
        <CoverArt
          src={coverSrc(instanceId, item.preview)}
          alt={item.title}
          placeholderClass="sm-card-placeholder"
        />
        {pct != null ? (
          <div className="sm-card-progress">
            <span style={{ width: `${pct}%` }} />
          </div>
        ) : null}
      </div>
      <div className="sm-card-meta">
        <div className="sm-card-title">{item.title}</div>
        {sub ? <div className="sm-card-sub">{sub}</div> : null}
      </div>
    </a>
  );
}

function ActiveRow({
  item,
  index,
  href,
  instanceId,
}: {
  item: TaskItem;
  index: number;
  href: string;
  instanceId: string;
}) {
  const pct = fmtPct(item.progress);
  const bucket = item.bucket || "queued";
  return (
    <a
      className="sm-song-row sm-active-row"
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      style={{ animationDelay: `${index * 25}ms` }}
    >
      <div className="sm-song-art">
        <CoverArt
          src={coverSrc(instanceId, item.preview)}
          alt={item.title}
          placeholderClass="sm-song-placeholder"
          size={16}
        >
          <div className="sm-active-dot" />
        </CoverArt>
      </div>
      <div className="sm-song-body">
        <div className="sm-song-title">{item.title}</div>
        <div className="sm-song-meta">{item.author || item.status || ""}</div>
        <div className="sm-session-bar">
          <span style={{ width: `${pct}%` }} />
        </div>
      </div>
      <div className="sm-song-right">
        <span className={`sm-status-pill sm-status-pill--${bucket}`}>{bucket}</span>
        <span className="sm-song-dur">{pct}%</span>
      </div>
    </a>
  );
}

function RequestRow({ item, index, href }: { item: TaskItem; index: number; href: string }) {
  const status = item.status || "pending";
  const when = fmtTime(item.createdAt);
  return (
    <a
      className="sm-song-row"
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      style={{ animationDelay: `${index * 25}ms` }}
    >
      <div className="sm-song-art">
        <div className="sm-song-placeholder">
          <BookIcon size={16} />
        </div>
      </div>
      <div className="sm-song-body">
        <div className="sm-song-title">{item.title}</div>
        <div className="sm-song-meta">{item.author || "Book request"}</div>
      </div>
      <div className="sm-song-right">
        <span className={`sm-status-pill sm-status-pill--${status}`}>{status}</span>
        {item.delivery ? <span className="sm-song-dur">{item.delivery}</span> : null}
        {when ? <span className="sm-song-user">{when}</span> : null}
      </div>
    </a>
  );
}

export default function ShelfmarkWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "shelfmark";
  const [tab, setTab] = useState<TabKey>("overview");
  const [cache, setCache] = useState<Partial<Record<TabKey, StatusPayload>>>({});
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const tabRef = useRef(tab);
  const cacheRef = useRef(cache);
  tabRef.current = tab;
  cacheRef.current = cache;

  const data = cache[tab] || null;
  const rawHref = data?.href || Object.values(cache).find((v) => v?.href)?.href || "";
  const rawOpenFallbackUrl =
    data?.openFallbackUrl || Object.values(cache).find((v) => v?.openFallbackUrl)?.openFallbackUrl || "";
  const href = useOpenHref(rawHref, rawOpenFallbackUrl);
  const isOnline = Boolean(href || data) && !error;

  const load = useCallback(
    async (nextTab: TabKey = tabRef.current, opts?: { soft?: boolean; force?: boolean }) => {
      if (!opts?.force && !opts?.soft && cacheRef.current[nextTab]) {
        setLoading(false);
        setError("");
        return;
      }
      if (!opts?.soft) setLoading(true);
      try {
        const response = await fetch(
          `/api/widgets/shelfmark/status?instance=${encodeURIComponent(instanceId)}&tab=${encodeURIComponent(nextTab)}`,
        );
        const json = (await response.json()) as StatusPayload;
        if (!response.ok) throw new Error(json.error || "Failed to load Shelfmark");
        setCache((prev) => {
          const next = { ...prev, [nextTab]: json };
          cacheRef.current = next;
          return next;
        });
        setError("");
      } catch (cause) {
        setError(cause instanceof Error ? cause.message : "Failed to load Shelfmark");
      } finally {
        setLoading(false);
      }
    },
    [instanceId],
  );

  useEffect(() => {
    void load(tab, { force: !cacheRef.current[tab] });
  }, [tab, load]);

  const softPoll = useCallback(() => {
    void load(tabRef.current, { soft: true, force: true });
  }, [load]);
  const { rootRef } = useWidgetPoll(softPoll, { intervalMs: 30_000 });

  function renderPanel(): ReactNode {
    if (loading && !data) return <Skeleton />;
    if (error && !data) {
      return (
        <div className="sm-error">
          <div className="sm-error-title">Failed to load</div>
          <div className="sm-error-msg">{error}</div>
        </div>
      );
    }
    if (!data) return <Skeleton />;

    if (tab === "overview") {
      const recent = data.recent || [];
      return (
        <>
          <div className="sm-stats-grid">
            <div className="sm-stat-card">
              <div className="sm-stat-num">{data.active ?? 0}</div>
              <div className="sm-stat-label">Active</div>
            </div>
            <div className="sm-stat-card">
              <div className="sm-stat-num">{data.complete ?? 0}</div>
              <div className="sm-stat-label">Completed</div>
            </div>
            <div className="sm-stat-card">
              <div className="sm-stat-num">{data.failed ?? 0}</div>
              <div className="sm-stat-label">Failed</div>
            </div>
            <div className="sm-stat-card">
              <div className="sm-stat-num">{data.pendingRequests ?? 0}</div>
              <div className="sm-stat-label">Requests</div>
            </div>
          </div>
          {recent.length ? (
            <>
              <div className="sm-section-label" style={{ marginTop: 16 }}>
                Recently Completed
              </div>
              <div className="sm-card-grid">
                {recent.map((item, index) => (
                  <BookCard
                    key={`${item.title}-${index}`}
                    item={item}
                    index={index}
                    href={href}
                    instanceId={instanceId}
                  />
                ))}
              </div>
            </>
          ) : (
            <div className="sm-empty" style={{ marginTop: 16 }}>
              No completed downloads yet
            </div>
          )}
        </>
      );
    }

    if (tab === "active") {
      const items = data.items || [];
      if (!items.length) {
        return (
          <div className="sm-empty">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2" aria-hidden>
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="7 10 12 15 17 10" />
              <line x1="12" y1="15" x2="12" y2="3" />
            </svg>
            <div>No active downloads</div>
          </div>
        );
      }
      return (
        <div className="sm-song-list">
          {items.map((item, index) => (
            <ActiveRow
              key={`${item.title}-${index}`}
              item={item}
              index={index}
              href={href}
              instanceId={instanceId}
            />
          ))}
        </div>
      );
    }

    if (tab === "recent") {
      const items = data.items || [];
      if (!items.length) return <div className="sm-empty">No completed downloads</div>;
      return (
        <div className="sm-card-grid">
          {items.map((item, index) => (
            <BookCard
              key={`${item.title}-${index}`}
              item={item}
              index={index}
              href={href}
              instanceId={instanceId}
            />
          ))}
        </div>
      );
    }

    const items = data.items || [];
    if (!items.length) return <div className="sm-empty">No book requests</div>;
    return (
      <div className="sm-song-list">
        {items.map((item, index) => (
          <RequestRow key={`${item.title}-${index}`} item={item} index={index} href={href} />
        ))}
      </div>
    );
  }

  return (
    <div className="hd-widget-body sm-body-flat" ref={rootRef}>
      <div className="sm-shell">
        <div className="sm-toolbar">
          <div className="sm-toolbar-left">
            <span className={`sm-status-pill${isOnline ? " sm-status-pill--ok" : ""}`}>
              <span className="sm-status-dot" aria-hidden="true" />
              {isOnline ? "Online" : "Offline"}
            </span>
          </div>
          <div className="sm-toolbar-right">
            {href ? (
              <a className="sm-open-btn" href={href} target="_blank" rel="noopener noreferrer">
                Open
              </a>
            ) : null}
          </div>
        </div>

        <div className="sm-controls">
          <div className="sm-tabs" role="tablist">
            {TABS.map((item) => (
              <button
                key={item.key}
                className={`sm-tab${tab === item.key ? " sm-tab--active" : ""}`}
                type="button"
                role="tab"
                aria-selected={tab === item.key}
                onClick={() => setTab(item.key)}
              >
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="sm-panel">{renderPanel()}</div>
      </div>
    </div>
  );
}
