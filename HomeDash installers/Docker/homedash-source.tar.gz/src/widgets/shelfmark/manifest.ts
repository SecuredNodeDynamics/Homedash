import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "shelfmark",
  name: "Shelfmark",
  description: "Download activity, completed books, and requests",
  version: "0.2.0",
  category: "Media",
  defaultSize: { w: 5, h: 5, minW: 3, minH: 3 },
  hostClass: "sm-widget-host shelfmark-host",
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "http://10.0.0.1",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      required: false,
      placeholder: "https://shelfmark.example.com",
    },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url", placeholder: "http://10.0.0.1" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    {
      key: "username",
      label: "Username",
      type: "text",
      required: true,
    },
    {
      key: "password",
      label: "Password",
      type: "password",
      required: true,
    },
  ],
};
