import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "sonarr",
  name: "Sonarr",
  description: "TV series library activity",
  version: "0.2.6",
  category: "Media",
  defaultSize: { w: 4, h: 4, minW: 2, minH: 2 },
  hostClass: "arr-host",
  configFields: [
    { key: "baseUrl", label: "Private - IP", type: "url", placeholder: "http://10.0.0.1:8989" },
    { key: "fallbackUrl", label: "Fallback Public URL", type: "url", placeholder: "https://sonarr.example.com" },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url", placeholder: "http://10.0.0.1:8989" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    { key: "apiKey", label: "API Key", type: "password", required: true },
  ],
};
