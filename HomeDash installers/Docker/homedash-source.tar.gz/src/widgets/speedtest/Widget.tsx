"use client";
import "@/styles/widgets/speedtest.widget.css";


import { useCallback, useId, useLayoutEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type Result = {
  download: number;
  upload: number;
  ping: number;
  jitter: number;
  isp: string;
  server: string;
  resultUrl: string;
  createdAt: string;
};

type HistoryPoint = {
  download: number;
  upload: number;
  ping: number;
  createdAt: string;
};

type Stats = {
  downloadAvg: number;
  downloadPeak: number;
  uploadAvg: number;
  uploadPeak: number;
  pingAvg: number;
  pingBest: number;
  samples: number;
};

type Data = {
  href: string;
  openFallbackUrl?: string;
  accent: string;
  latest: Result | null;
  history: HistoryPoint[];
  stats: Stats;
  connectionSource?: ConnectionSource;
};

type ConnectionSource = "private" | "public" | "unknown";

const CONNECTION_SOURCE_LABEL: Record<ConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

function ConnectionCorner({ source }: { source: ConnectionSource }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const mark = (
    <div
      className={`spt-corner-source spt-corner-source--${source}`}
      title={CONNECTION_SOURCE_LABEL[source]}
      aria-label={CONNECTION_SOURCE_LABEL[source]}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}

function fmtSpeed(value: number) {
  if (!Number.isFinite(value) || value <= 0) return "—";
  const bits = value * 8;
  if (bits >= 1e9) return (bits / 1e9).toFixed(2);
  if (bits >= 1e6) return (bits / 1e6).toFixed(1);
  return (bits / 1e3).toFixed(0);
}

function speedUnit(value: number) {
  if (!Number.isFinite(value) || value <= 0) return "bps";
  const bits = value * 8;
  if (bits >= 1e9) return "Gbps";
  if (bits >= 1e6) return "Mbps";
  return "Kbps";
}

function fmtSpeedPair(value: number) {
  return `${fmtSpeed(value)} ${speedUnit(value)}`;
}

function timeAgo(stamp: string) {
  if (!stamp) return "";
  const seconds = Math.floor((Date.now() - new Date(stamp).getTime()) / 1000);
  if (!Number.isFinite(seconds) || seconds < 0) return "";
  if (seconds < 60) return `${seconds}s ago`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
}

function shortTime(stamp: string) {
  if (!stamp) return "";
  const date = new Date(stamp);
  if (!Number.isFinite(date.getTime())) return "";
  return date.toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

function deltaLabel(current: number, avg: number, lowerIsBetter = false) {
  if (!current || !avg) return null;
  const pct = ((current - avg) / avg) * 100;
  if (!Number.isFinite(pct) || Math.abs(pct) < 3) return { text: "≈ avg", tone: "flat" as const };
  const better = lowerIsBetter ? pct < 0 : pct > 0;
  const text = `${pct > 0 ? "+" : ""}${pct.toFixed(0)}% vs avg`;
  return { text, tone: better ? ("up" as const) : ("down" as const) };
}

function buildPath(values: number[], width: number, height: number, padY = 4) {
  if (values.length < 2) return "";
  const max = Math.max(...values, 1);
  return values
    .map((value, index) => {
      const x = (index / (values.length - 1)) * width;
      const y = height - padY - (Math.max(0, value) / max) * (height - padY * 2);
      return `${index === 0 ? "M" : "L"} ${x.toFixed(2)} ${y.toFixed(2)}`;
    })
    .join(" ");
}

function HistoryChart({
  history,
  accent,
  hover,
  onHover,
}: {
  history: HistoryPoint[];
  accent: string;
  hover: number | null;
  onHover: (index: number | null) => void;
}) {
  const uid = useId().replace(/:/g, "");
  const width = 320;
  const height = 88;
  const downloads = history.map((row) => row.download);
  const uploads = history.map((row) => row.upload);
  const dlPath = buildPath(downloads, width, height);
  const ulPath = buildPath(uploads, width, height);
  const maxDl = Math.max(...downloads, 1);
  const areaPath = dlPath
    ? `${dlPath} L ${width} ${height} L 0 ${height} Z`
    : "";

  return (
    <svg
      className="spt-chart-svg"
      viewBox={`0 0 ${width} ${height}`}
      preserveAspectRatio="none"
      onMouseLeave={() => onHover(null)}
    >
      <defs>
        <linearGradient id={`spt-fill-${uid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={accent} stopOpacity="0.35" />
          <stop offset="100%" stopColor={accent} stopOpacity="0.02" />
        </linearGradient>
      </defs>
      {[0.25, 0.5, 0.75].map((ratio) => (
        <line
          key={ratio}
          x1="0"
          x2={width}
          y1={height * ratio}
          y2={height * ratio}
          stroke="rgba(255,255,255,0.06)"
          strokeWidth="1"
        />
      ))}
      {areaPath ? <path d={areaPath} fill={`url(#spt-fill-${uid})`} /> : null}
      {dlPath ? (
        <path
          d={dlPath}
          fill="none"
          stroke={accent}
          strokeWidth="2.2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      ) : null}
      {ulPath ? (
        <path
          d={ulPath}
          fill="none"
          stroke="#60a5fa"
          strokeWidth="1.6"
          strokeLinecap="round"
          strokeLinejoin="round"
          opacity="0.85"
          strokeDasharray="4 3"
        />
      ) : null}
      {history.map((point, index) => {
        const x = history.length === 1 ? width / 2 : (index / (history.length - 1)) * width;
        const y = height - 4 - (Math.max(0, point.download) / maxDl) * (height - 8);
        const active = hover === index;
        return (
          <g key={`${point.createdAt}-${index}`}>
            <rect
              x={Math.max(0, x - width / history.length / 2)}
              y={0}
              width={Math.max(8, width / history.length)}
              height={height}
              fill="transparent"
              onMouseEnter={() => onHover(index)}
            />
            {active ? (
              <>
                <line
                  x1={x}
                  x2={x}
                  y1={0}
                  y2={height}
                  stroke="rgba(255,255,255,0.18)"
                  strokeWidth="1"
                />
                <circle cx={x} cy={y} r="3.5" fill={accent} stroke="rgba(0,0,0,0.35)" strokeWidth="1" />
              </>
            ) : null}
          </g>
        );
      })}
    </svg>
  );
}

function MetricTile({
  label,
  value,
  unit,
  color,
  detail,
  delta,
}: {
  label: string;
  value: string;
  unit: string;
  color: string;
  detail?: string;
  delta?: { text: string; tone: "up" | "down" | "flat" } | null;
}) {
  return (
    <div
      className="spt-metric-tile"
      style={{
        ["--spt-metric" as string]: color,
        ["--spt-metric-bg" as string]: `${color}14`,
        ["--spt-metric-border" as string]: `${color}33`,
      }}
    >
      <div className="spt-metric-head">
        <div className="spt-metric-label">{label}</div>
        <div className="spt-metric-main">
          <span className="spt-metric-value">{value}</span>
          <span className="spt-metric-unit">{unit}</span>
        </div>
      </div>
      {detail || delta ? (
        <div className="spt-metric-foot">
          {detail ? <div className="spt-metric-detail">{detail}</div> : null}
          {delta ? (
            <div className={`spt-metric-delta spt-metric-delta--${delta.tone}`}>{delta.text}</div>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

export default function SpeedtestWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "speedtest";
  const [data, setData] = useState<Data | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [running, setRunning] = useState(false);
  const [hover, setHover] = useState<number | null>(null);
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);

  const load = useCallback(async () => {
    try {
      const response = await fetch(
        `/api/widgets/speedtest/status?instance=${encodeURIComponent(instanceId)}`,
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load Speedtest");
      setData(json);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Speedtest unavailable");
    } finally {
      setLoading(false);
    }
  }, [instanceId]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: 300_000 });

  async function run() {
    setRunning(true);
    setError("");
    try {
      const response = await fetch("/api/widgets/speedtest/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Test failed");
      window.setTimeout(() => {
        void load();
      }, 12_000);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Test failed");
    } finally {
      setRunning(false);
    }
  }

  const history = data?.history || [];
  const hoverPoint = useMemo(
    () => (hover != null ? history[hover] || null : null),
    [hover, history],
  );

  if (loading && !data) {
    return (
      <div className="hd-widget-body spt-body" ref={rootRef}>
        <div className="spt-toolbar">
          <span className="spt-status-pill spt-status-pill--loading">
            <span className="spt-status-dot" />
            Loading
          </span>
        </div>
        <div className="spt-skeleton" />
        <div className="spt-skeleton spt-skeleton--chart" />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="hd-widget-body spt-body" ref={rootRef}>
        <div className="spt-toolbar">
          <span className="spt-status-pill spt-status-pill--offline">
            <span className="spt-status-dot" />
            Offline
          </span>
          <button className="spt-run-btn" type="button" onClick={load}>
            Retry
          </button>
        </div>
        <div className="spt-error">{error}</div>
      </div>
    );
  }

  const latest = data.latest;
  const accent = data.accent || "#22c55e";
  const stats = data.stats;
  const statusTone = running ? "loading" : error && !latest ? "offline" : "online";
  const statusLabel = running ? "Testing" : error && !latest ? "Offline" : "Online";
  const badgeTxt = running
    ? "Running test…"
    : error
      ? "Test failed"
      : latest
        ? `Result · ${timeAgo(latest.createdAt)}`
        : "No data yet";
  const badgeTone = running ? "running" : error ? "error" : latest ? "ok" : "idle";
  const rangeLabel =
    history.length > 1
      ? `${shortTime(history[0].createdAt)} → ${shortTime(history[history.length - 1].createdAt)}`
      : history[0]
        ? shortTime(history[0].createdAt)
        : "";

  return (
    <div className="hd-widget-body spt-body" ref={rootRef}>
      <ConnectionCorner source={data.connectionSource || "unknown"} />
      <div className="spt-toolbar">
        <span className={`spt-status-pill spt-status-pill--${statusTone}`}>
          <span className="spt-status-dot" />
          {statusLabel}
        </span>
        <div className="spt-toolbar-right">
          <a className="spt-open-link" href={openHref} target="_blank" rel="noopener noreferrer">
            Open
          </a>
          <button className="spt-run-btn" type="button" disabled={running} onClick={run}>
            {running ? "Testing…" : "Run test"}
          </button>
        </div>
      </div>

      <div className="spt-metric-grid">
        <MetricTile
          label="Download"
          value={fmtSpeed(latest?.download || 0)}
          unit={speedUnit(latest?.download || 0)}
          color="#22c55e"
          detail={stats.downloadAvg ? `avg ${fmtSpeedPair(stats.downloadAvg)}` : undefined}
          delta={deltaLabel(latest?.download || 0, stats.downloadAvg)}
        />
        <MetricTile
          label="Upload"
          value={fmtSpeed(latest?.upload || 0)}
          unit={speedUnit(latest?.upload || 0)}
          color="#3b82f6"
          detail={stats.uploadAvg ? `avg ${fmtSpeedPair(stats.uploadAvg)}` : undefined}
          delta={deltaLabel(latest?.upload || 0, stats.uploadAvg)}
        />
        <MetricTile
          label="Ping"
          value={latest ? String(Math.round(latest.ping)) : "—"}
          unit="ms"
          color="#f59e0b"
          detail={
            stats.pingAvg
              ? `avg ${Math.round(stats.pingAvg)} · best ${Math.round(stats.pingBest)}`
              : undefined
          }
          delta={deltaLabel(latest?.ping || 0, stats.pingAvg, true)}
        />
      </div>

      <div className="spt-chart">
        <div className="spt-chart-head">
          <div className="spt-section-label">
            History
            <span className="spt-section-meta">
              {stats.samples ? `${stats.samples} tests` : "No samples"}
            </span>
          </div>
          <div className="spt-chart-legend">
            <span className="spt-legend spt-legend--dl" style={{ ["--lg" as string]: accent }}>
              Download
            </span>
            <span className="spt-legend spt-legend--ul">Upload</span>
          </div>
        </div>

        {history.length >= 2 ? (
          <>
            <div className="spt-chart-frame">
              <div className="spt-chart-peak">{fmtSpeedPair(stats.downloadPeak)} peak</div>
              <HistoryChart
                history={history}
                accent={accent}
                hover={hover}
                onHover={setHover}
              />
            </div>
            <div className="spt-chart-foot">
              {hoverPoint ? (
                <span className="spt-chart-hover">
                  {shortTime(hoverPoint.createdAt)} · ↓ {fmtSpeedPair(hoverPoint.download)} · ↑{" "}
                  {fmtSpeedPair(hoverPoint.upload)} · {Math.round(hoverPoint.ping)} ms
                </span>
              ) : (
                <span className="spt-chart-range">{rangeLabel}</span>
              )}
            </div>
          </>
        ) : (
          <div className="spt-history-empty">
            {latest ? "Need a few more tests to draw history" : "No history yet — run a test"}
          </div>
        )}
      </div>

      <div className="spt-meta-row">
        <span className={`spt-badge spt-badge--${badgeTone}`}>{badgeTxt}</span>
        {latest?.jitter ? (
          <span className="spt-meta-item">Jitter {Math.round(latest.jitter)} ms</span>
        ) : null}
        {latest?.server ? (
          <span className="spt-meta-item spt-meta-item--ellipsis" title={latest.server}>
            {latest.server}
          </span>
        ) : null}
      </div>

      {error ? <div className="spt-error">{error}</div> : null}
    </div>
  );
}
