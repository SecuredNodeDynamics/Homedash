import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "speedtest",
  name: "Speedtest",
  description: "Internet speed history per tracker",
  version: "0.2.7",
  category: "Network",
  defaultSize: { w: 4, h: 5, minW: 3, minH: 4 },
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "http://10.0.0.1",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      placeholder: "https://speedtest.example.com",
    },
    {
      key: "publicUrl",
      label: "OPEN - Private URL",
      type: "url",
      placeholder: "http://10.0.0.1",
    },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    {
      key: "apiKey",
      label: "API Key",
      type: "password",
      required: true,
    },
    {
      key: "nodeName",
      label: "PVE ID",
      type: "text",
      placeholder: "LNV1",
      required: true,
    },
    {
      key: "serverId",
      label: "Ookla server ID (optional)",
      type: "text",
      placeholder: "35180",
    },
    {
      key: "color",
      label: "Accent color",
      type: "color",
      placeholder: "#22c55e",
    },
  ],
};
