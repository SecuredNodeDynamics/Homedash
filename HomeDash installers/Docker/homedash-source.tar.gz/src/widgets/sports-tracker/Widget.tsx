"use client";
import "@/styles/widgets/sports.widget.css";

import { useEffect, useMemo, useState } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";
import {
  SPORT_META,
  SPORT_ORDER,
  TEAM_LEAGUES,
  isTeamSport,
  isGamecastable,
  type GameDetail as GameDetailData,
  type NewsItem,
  type SportCompetitor,
  type SportEvent,
  type SportKey,
  type SportsStatus,
  type StandingsGroup,
  type TeamDetail,
  type TeamSport,
  type TeamSummary,
} from "@/lib/widgets/sports";

type Tab = "compare" | SportKey;
type PanelMode = "scores" | "vs";

function fmtTime(iso: string) {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  return date.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
}

function fmtDay(iso: string) {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  const today = new Date();
  const sameDay =
    date.getFullYear() === today.getFullYear() &&
    date.getMonth() === today.getMonth() &&
    date.getDate() === today.getDate();
  if (sameDay) return "Today";
  return date.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
}

function StateDot({ state }: { state: SportEvent["state"] }) {
  return <span className={`spt-state-dot spt-state-dot--${state}`} />;
}

function EventRow({
  event,
  onOpen,
  accent,
}: {
  event: SportEvent;
  onOpen?: (event: SportEvent) => void;
  accent?: string;
}) {
  const canOpen = Boolean(onOpen) && isGamecastable(event);
  const rowStyle = accent ? { ["--spt-accent" as string]: accent } : undefined;
  const body = (
    <>
      <div className="spt-row-status">
        <StateDot state={event.state} />
        <span className="spt-row-status-text">
          {event.state === "in"
            ? event.statusDetail || "Live"
            : event.state === "post"
              ? "Final"
              : fmtTime(event.startTime)}
        </span>
      </div>
      <div className="spt-row-main">
        {event.competitors.length ? (
          <div className="spt-row-competitors">
            {event.competitors.map((c, i) => (
              <div className={`spt-competitor${c.winner ? " spt-competitor--winner" : ""}`} key={`${event.id}-${i}`}>
                <span className="spt-competitor-id">
                  {c.logo ? <img className="spt-competitor-logo" src={c.logo} alt="" loading="lazy" /> : null}
                  <span className="spt-competitor-name">{c.name}</span>
                </span>
                {c.score ? (
                  <span className={`spt-score-badge${c.winner ? " spt-score-badge--winner" : ""}`}>{c.score}</span>
                ) : null}
              </div>
            ))}
          </div>
        ) : (
          <div className="spt-row-name">{event.shortName || event.name}</div>
        )}
        <div className="spt-row-meta">
          <span className="spt-row-league">{event.league}</span>
          {event.venue ? <span className="spt-row-venue"> · {event.venue}</span> : null}
          {event.network ? <span className="spt-row-network"> · 📺 {event.network}</span> : null}
        </div>
      </div>
    </>
  );

  if (canOpen) {
    return (
      <button type="button" className="spt-row spt-row--link spt-row--open" style={rowStyle} onClick={() => onOpen!(event)}>
        {body}
        <span className="spt-row-chevron" aria-hidden="true">›</span>
      </button>
    );
  }
  if (event.href) {
    return (
      <a className="spt-row spt-row--link" style={rowStyle} href={event.href} target="_blank" rel="noopener noreferrer">
        {body}
      </a>
    );
  }
  return (
    <div className="spt-row" style={rowStyle}>
      {body}
    </div>
  );
}

// ── Team picker + team-vs-team comparison (soccer / football / basketball / baseball) ──

function useTeamList(sport: TeamSport, league: string) {
  const [teams, setTeams] = useState<TeamSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError("");
    fetch(`/api/widgets/sports-tracker/teams?sport=${sport}&league=${encodeURIComponent(league)}`)
      .then(async (response) => {
        const json = await response.json();
        if (!response.ok) throw new Error(json.error || "Failed to load teams");
        return json.teams as TeamSummary[];
      })
      .then((list) => {
        if (!cancelled) setTeams(list);
      })
      .catch((cause) => {
        if (!cancelled) setError(cause instanceof Error ? cause.message : "Failed to load teams");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [sport, league]);

  return { teams, loading, error };
}

function useTeamDetail(sport: TeamSport, league: string, teamId: string) {
  const [detail, setDetail] = useState<TeamDetail | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!teamId) {
      setDetail(null);
      return;
    }
    let cancelled = false;
    setLoading(true);
    setError("");
    fetch(
      `/api/widgets/sports-tracker/team?sport=${sport}&league=${encodeURIComponent(league)}&team=${encodeURIComponent(teamId)}`,
    )
      .then(async (response) => {
        const json = await response.json();
        if (!response.ok) throw new Error(json.error || "Failed to load team");
        return json as TeamDetail;
      })
      .then((json) => {
        if (!cancelled) setDetail(json);
      })
      .catch((cause) => {
        if (!cancelled) setError(cause instanceof Error ? cause.message : "Failed to load team");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [sport, league, teamId]);

  return { detail, loading, error };
}

function TeamSide({
  side,
  teams,
  teamsLoading,
  teamsError,
  selected,
  onSelect,
  detail,
  detailLoading,
  detailError,
}: {
  side: "A" | "B";
  teams: TeamSummary[];
  teamsLoading: boolean;
  teamsError: string;
  selected: string;
  onSelect: (id: string) => void;
  detail: TeamDetail | null;
  detailLoading: boolean;
  detailError: string;
}) {
  return (
    <div className="spt-vs-side">
      <select
        className="spt-select"
        value={selected}
        onChange={(e) => onSelect(e.target.value)}
        disabled={teamsLoading || !teams.length}
      >
        <option value="">{teamsLoading ? "Loading teams…" : `Select team ${side}`}</option>
        {teams.map((team) => (
          <option value={team.id} key={team.id}>
            {team.name}
          </option>
        ))}
      </select>
      {teamsError ? <div className="spt-inline-error">{teamsError}</div> : null}

      {selected && detailLoading ? <div className="spt-vs-loading">Loading…</div> : null}
      {selected && detailError ? <div className="spt-inline-error">{detailError}</div> : null}

      {detail ? (
        <div className="spt-vs-card">
          <div className="spt-vs-header">
            {detail.logo ? <img className="spt-vs-logo" src={detail.logo} alt="" /> : null}
            <div className="spt-vs-name-block">
              <div className="spt-vs-name">{detail.name}</div>
              <div className="spt-vs-record">
                {detail.recordSummary || "—"}
                {detail.standingSummary ? ` · ${detail.standingSummary}` : ""}
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function TeamCompare({ sport }: { sport: TeamSport }) {
  const leagues = TEAM_LEAGUES[sport];
  const [league, setLeague] = useState(leagues[0]?.leaguePath || "");
  const [teamAId, setTeamAId] = useState("");
  const [teamBId, setTeamBId] = useState("");

  const { teams, loading: teamsLoading, error: teamsError } = useTeamList(sport, league);
  const { detail: detailA, loading: loadingA, error: errorA } = useTeamDetail(sport, league, teamAId);
  const { detail: detailB, loading: loadingB, error: errorB } = useTeamDetail(sport, league, teamBId);

  useEffect(() => {
    setTeamAId("");
    setTeamBId("");
  }, [league]);

  const statRows = useMemo(() => {
    if (!detailA || !detailB) return [];
    const order: string[] = [];
    const byName: Record<string, { label: string; a?: string; b?: string }> = {};
    for (const stat of detailA.stats) {
      if (!byName[stat.name]) order.push(stat.name);
      byName[stat.name] = { ...(byName[stat.name] || { label: stat.label }), label: stat.label, a: stat.value };
    }
    for (const stat of detailB.stats) {
      if (!byName[stat.name]) order.push(stat.name);
      byName[stat.name] = { ...(byName[stat.name] || { label: stat.label }), label: stat.label, b: stat.value };
    }
    return order.map((name) => ({ name, ...byName[name] }));
  }, [detailA, detailB]);

  return (
    <div className="spt-vs-wrap">
      {leagues.length > 1 ? (
        <div className="spt-vs-league-picker">
          {leagues.map((option) => (
            <button
              type="button"
              key={option.leaguePath}
              className={`spt-chip${league === option.leaguePath ? " spt-chip--active" : ""}`}
              onClick={() => setLeague(option.leaguePath)}
            >
              {option.label}
            </button>
          ))}
        </div>
      ) : null}

      <div className="spt-vs-pickers">
        <TeamSide
          side="A"
          teams={teams}
          teamsLoading={teamsLoading}
          teamsError={teamsError}
          selected={teamAId}
          onSelect={setTeamAId}
          detail={detailA}
          detailLoading={loadingA}
          detailError={errorA}
        />
        <div className="spt-vs-divider">VS</div>
        <TeamSide
          side="B"
          teams={teams}
          teamsLoading={teamsLoading}
          teamsError={teamsError}
          selected={teamBId}
          onSelect={setTeamBId}
          detail={detailB}
          detailLoading={loadingB}
          detailError={errorB}
        />
      </div>

      {detailA && detailB ? (
        <>
          {statRows.length ? (
            <div className="spt-vs-stats">
              <div className="spt-vs-stats-title">Team stats</div>
              {statRows.map((row) => (
                <div className="spt-vs-stat-row" key={row.name}>
                  <span className="spt-vs-stat-value spt-vs-stat-value--a">{row.a ?? "—"}</span>
                  <span className="spt-vs-stat-label">{row.label}</span>
                  <span className="spt-vs-stat-value spt-vs-stat-value--b">{row.b ?? "—"}</span>
                </div>
              ))}
            </div>
          ) : null}

          {detailA.leaders.length || detailB.leaders.length ? (
            <div className="spt-vs-leaders">
              <div className="spt-vs-stats-title">Player stat leaders</div>
              <div className="spt-vs-leaders-cols">
                <div className="spt-vs-leaders-col">
                  {detailA.leaders.map((leader) => (
                    <div className="spt-leader-row" key={leader.category}>
                      {leader.athleteHeadshot ? <img className="spt-leader-avatar" src={leader.athleteHeadshot} alt="" /> : null}
                      <div className="spt-leader-info">
                        <div className="spt-leader-name">{leader.athleteName}</div>
                        <div className="spt-leader-cat">{leader.category}</div>
                      </div>
                      <div className="spt-leader-value">{leader.value}</div>
                    </div>
                  ))}
                </div>
                <div className="spt-vs-leaders-col">
                  {detailB.leaders.map((leader) => (
                    <div className="spt-leader-row" key={leader.category}>
                      {leader.athleteHeadshot ? <img className="spt-leader-avatar" src={leader.athleteHeadshot} alt="" /> : null}
                      <div className="spt-leader-info">
                        <div className="spt-leader-name">{leader.athleteName}</div>
                        <div className="spt-leader-cat">{leader.category}</div>
                      </div>
                      <div className="spt-leader-value">{leader.value}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : null}

          {detailA.roster.length || detailB.roster.length ? (
            <div className="spt-vs-roster">
              <div className="spt-vs-stats-title">Roster</div>
              <div className="spt-roster-col-headers">
                <span className="spt-roster-col-header">
                  {detailA.logo ? <img className="spt-roster-col-logo" src={detailA.logo} alt="" /> : null}
                  {detailA.name}
                </span>
                <span className="spt-roster-col-header spt-roster-col-header--b">
                  {detailB.name}
                  {detailB.logo ? <img className="spt-roster-col-logo" src={detailB.logo} alt="" /> : null}
                </span>
              </div>
              <div className="spt-roster-cols">
                <div className="spt-roster-col">
                  {detailA.roster.slice(0, 15).map((player) => (
                    <div className="spt-roster-row" key={player.id || player.name}>
                      <span className="spt-roster-jersey">{player.jersey || "—"}</span>
                      <span className="spt-roster-name">{player.name}</span>
                      <span className="spt-roster-pos">{player.position}</span>
                    </div>
                  ))}
                </div>
                <div className="spt-roster-col">
                  {detailB.roster.slice(0, 15).map((player) => (
                    <div className="spt-roster-row" key={player.id || player.name}>
                      <span className="spt-roster-jersey">{player.jersey || "—"}</span>
                      <span className="spt-roster-name">{player.name}</span>
                      <span className="spt-roster-pos">{player.position}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : null}
        </>
      ) : (
        <div className="spt-vs-hint">Pick two teams to compare records, stats, top players and rosters.</div>
      )}
    </div>
  );
}

// ── Athlete picker + head-to-head (golf / tennis — individual sports, no teams) ──

function PlayerCompare({ events }: { events: SportEvent[] }) {
  const athletes = useMemo(() => {
    const seen = new Map<string, { competitor: SportCompetitor; event: SportEvent }>();
    for (const event of events) {
      for (const competitor of event.competitors) {
        if (!seen.has(competitor.name)) seen.set(competitor.name, { competitor, event });
      }
    }
    return Array.from(seen.values()).sort((a, b) => a.competitor.name.localeCompare(b.competitor.name));
  }, [events]);

  const [nameA, setNameA] = useState("");
  const [nameB, setNameB] = useState("");
  const pickA = athletes.find((a) => a.competitor.name === nameA) || null;
  const pickB = athletes.find((a) => a.competitor.name === nameB) || null;

  if (!athletes.length) {
    return <div className="spt-empty">No players in today's events to compare yet.</div>;
  }

  const renderCard = (pick: typeof pickA) => {
    if (!pick) return <div className="spt-vs-hint">Select a player</div>;
    const { competitor, event } = pick;
    return (
      <div className="spt-vs-card">
        <div className="spt-vs-header">
          {competitor.logo ? <img className="spt-vs-logo spt-vs-logo--round" src={competitor.logo} alt="" /> : null}
          <div className="spt-vs-name-block">
            <div className="spt-vs-name">{competitor.name}</div>
            <div className="spt-vs-record">{competitor.score ? `Score: ${competitor.score}` : "No score yet"}</div>
          </div>
        </div>
        <div className="spt-vs-event-meta">
          {event.league} · {event.state === "in" ? event.statusDetail || "Live" : event.state === "post" ? "Final" : fmtDay(event.startTime)}
          {event.venue ? ` · ${event.venue}` : ""}
          {event.network ? ` · 📺 ${event.network}` : ""}
        </div>
      </div>
    );
  };

  return (
    <div className="spt-vs-wrap">
      <div className="spt-vs-pickers">
        <div className="spt-vs-side">
          <select className="spt-select" value={nameA} onChange={(e) => setNameA(e.target.value)}>
            <option value="">Select player A</option>
            {athletes.map(({ competitor }) => (
              <option value={competitor.name} key={competitor.name}>
                {competitor.name}
              </option>
            ))}
          </select>
          {renderCard(pickA)}
        </div>
        <div className="spt-vs-divider">VS</div>
        <div className="spt-vs-side">
          <select className="spt-select" value={nameB} onChange={(e) => setNameB(e.target.value)}>
            <option value="">Select player B</option>
            {athletes.map(({ competitor }) => (
              <option value={competitor.name} key={competitor.name}>
                {competitor.name}
              </option>
            ))}
          </select>
          {renderCard(pickB)}
        </div>
      </div>
      {!pickA || !pickB ? (
        <div className="spt-vs-hint">Pick two players to compare their current tournament standing.</div>
      ) : null}
    </div>
  );
}

function SportPanel({
  sport,
  summary,
  onOpenGame,
}: {
  sport: SportKey;
  summary: SportsStatus["sports"][SportKey] | undefined;
  onOpenGame: (event: SportEvent) => void;
}) {
  const meta = SPORT_META[sport];
  const events = summary?.events || [];
  const [mode, setMode] = useState<PanelMode>("scores");

  const groups = useMemo(() => {
    const live = events.filter((e) => e.state === "in");
    const upcoming = events.filter((e) => e.state === "pre");
    const final = events.filter((e) => e.state === "post");
    return { live, upcoming, final };
  }, [events]);

  return (
    <div className="spt-sport-panel">
      <div className="spt-mode-toggle">
        <button
          type="button"
          className={`spt-mode-btn${mode === "scores" ? " spt-mode-btn--active" : ""}`}
          onClick={() => setMode("scores")}
        >
          Scores
        </button>
        <button
          type="button"
          className={`spt-mode-btn${mode === "vs" ? " spt-mode-btn--active" : ""}`}
          onClick={() => setMode("vs")}
        >
          {isTeamSport(sport) ? "Compare teams" : "Compare players"}
        </button>
      </div>

      {mode === "vs" ? (
        isTeamSport(sport) ? <TeamCompare sport={sport} /> : <PlayerCompare events={events} />
      ) : summary?.error && !events.length ? (
        <div className="spt-inline-error">{summary.error}</div>
      ) : !events.length ? (
        <div className="spt-empty">No {meta.label.toLowerCase()} events found right now.</div>
      ) : (
        <div className="spt-scores-layout">
          <div className="spt-scores-main">
            {groups.live.length ? (
              <div className="spt-group">
                <div className="spt-group-title">
                  <StateDot state="in" /> Live
                </div>
                <div className="spt-group-items">
                  {groups.live.map((event) => (
                    <EventRow event={event} onOpen={onOpenGame} accent={meta.color} key={event.id} />
                  ))}
                </div>
              </div>
            ) : null}
            {groups.upcoming.length ? (
              <div className="spt-group">
                <div className="spt-group-title">Upcoming</div>
                <div className="spt-group-items">
                  {groups.upcoming.slice(0, 12).map((event) => (
                    <EventRow event={event} onOpen={onOpenGame} accent={meta.color} key={event.id} />
                  ))}
                </div>
              </div>
            ) : null}
            {groups.final.length ? (
              <div className="spt-group">
                <div className="spt-group-title">Final</div>
                <div className="spt-group-items">
                  {groups.final.slice(0, 8).map((event) => (
                    <EventRow event={event} onOpen={onOpenGame} accent={meta.color} key={event.id} />
                  ))}
                </div>
              </div>
            ) : null}
          </div>

          <SportSidebar sport={sport} />
        </div>
      )}
    </div>
  );
}

// ── Standings + headlines rail (ESPN-style sidebar), shown under scores ──

function useLeagueData(sportPath: string, leaguePath: string) {
  const [standings, setStandings] = useState<StandingsGroup[]>([]);
  const [news, setNews] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    Promise.allSettled([
      fetch(`/api/widgets/sports-tracker/standings?sportPath=${sportPath}&leaguePath=${encodeURIComponent(leaguePath)}`).then((r) => r.json()),
      fetch(`/api/widgets/sports-tracker/news?sportPath=${sportPath}&leaguePath=${encodeURIComponent(leaguePath)}`).then((r) => r.json()),
    ]).then(([standingsResult, newsResult]) => {
      if (cancelled) return;
      setStandings(standingsResult.status === "fulfilled" ? standingsResult.value.groups || [] : []);
      setNews(newsResult.status === "fulfilled" ? newsResult.value.items || [] : []);
      setLoading(false);
    });
    return () => {
      cancelled = true;
    };
  }, [sportPath, leaguePath]);

  return { standings, news, loading };
}

function SportSidebar({ sport }: { sport: SportKey }) {
  const options = isTeamSport(sport) ? TEAM_LEAGUES[sport] : [];
  const [leagueIdx, setLeagueIdx] = useState(0);
  const active = options[leagueIdx];
  // Golf/tennis: headlines only (no league table for individual sports).
  const newsOnlyPath = sport === "golf" ? { sportPath: "golf", leaguePath: "pga" } : sport === "tennis" ? { sportPath: "tennis", leaguePath: "atp" } : null;
  const { standings, news, loading } = useLeagueData(
    active?.sportPath || newsOnlyPath?.sportPath || "",
    active?.leaguePath || newsOnlyPath?.leaguePath || "",
  );

  if (!active && !newsOnlyPath) return null;
  if (loading && !standings.length && !news.length) return null;

  return (
    <div className="spt-sidebar">
      {options.length > 1 ? (
        <div className="spt-vs-league-picker">
          {options.map((option, i) => (
            <button
              type="button"
              key={option.leaguePath}
              className={`spt-chip${leagueIdx === i ? " spt-chip--active" : ""}`}
              onClick={() => setLeagueIdx(i)}
            >
              {option.label}
            </button>
          ))}
        </div>
      ) : null}

      {standings.length ? (
        <div className="spt-standings">
          <div className="spt-section-title">Standings</div>
          {standings.map((group) => (
            <div className="spt-standings-group" key={group.label || "all"}>
              {group.label ? <div className="spt-standings-group-label">{group.label}</div> : null}
              <div className="spt-standings-table">
                <div className="spt-standings-header-row">
                  <span className="spt-standings-team-col">Team</span>
                  <span>W</span>
                  <span>L</span>
                  <span>PCT</span>
                  <span>STRK</span>
                </div>
                {group.rows.map((row) => (
                  <div className="spt-standings-row" key={row.teamId}>
                    <span className="spt-standings-team-col">
                      {row.logo ? <img className="spt-standings-logo" src={row.logo} alt="" loading="lazy" /> : null}
                      <span className="spt-standings-name">{row.abbrev || row.name}</span>
                    </span>
                    <span>{row.wins}</span>
                    <span>{row.losses}</span>
                    <span>{row.pct}</span>
                    <span>{row.streak}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : null}

      {news.length ? (
        <div className="spt-news">
          <div className="spt-section-title">Headlines</div>
          <div className="spt-news-list">
            {news.slice(0, 5).map((item) => (
              <a
                className="spt-news-item"
                href={item.href || undefined}
                target="_blank"
                rel="noopener noreferrer"
                key={item.id}
              >
                {item.image ? <img className="spt-news-thumb" src={item.image} alt="" loading="lazy" /> : null}
                <div className="spt-news-text">
                  <div className="spt-news-headline">{item.headline}</div>
                </div>
              </a>
            ))}
          </div>
        </div>
      ) : null}
    </div>
  );
}

function featuredEvent(events: SportEvent[]) {
  return (
    events.find((e) => e.state === "in") ||
    events.find((e) => e.state === "pre") ||
    events[0] ||
    null
  );
}

function CompareTile({
  sport,
  summary,
  onOpen,
}: {
  sport: SportKey;
  summary: SportsStatus["sports"][SportKey] | undefined;
  onOpen: () => void;
}) {
  const meta = SPORT_META[sport];
  const events = summary?.events || [];
  const featured = featuredEvent(events);

  return (
    <button type="button" className="spt-tile" onClick={onOpen} style={{ ["--spt-accent" as string]: meta.color }}>
      <div className="spt-tile-top">
        <span className="spt-tile-icon">{meta.icon}</span>
        <span className="spt-tile-label">{meta.label}</span>
        {summary?.liveCount ? <span className="spt-tile-live">{summary.liveCount} live</span> : null}
      </div>
      {summary?.error && !events.length ? (
        <div className="spt-tile-error">Unavailable</div>
      ) : featured ? (
        <div className="spt-tile-event">
          {featured.competitors.length ? (
            <div className="spt-tile-competitors">
              {featured.competitors.slice(0, 2).map((c, i) => (
                <span className="spt-tile-competitor" key={i}>
                  {c.logo ? <img className="spt-tile-competitor-logo" src={c.logo} alt="" loading="lazy" /> : null}
                  {c.abbrev || c.name}
                  {c.score ? ` ${c.score}` : ""}
                </span>
              ))}
            </div>
          ) : (
            <div className="spt-tile-competitors">
              <span className="spt-tile-competitor">{featured.shortName || featured.name}</span>
            </div>
          )}
          <div className="spt-tile-sub">
            {featured.state === "in" ? featured.statusDetail || "Live" : featured.state === "post" ? "Final" : `${fmtDay(featured.startTime)} · ${fmtTime(featured.startTime)}`}
            {featured.network ? ` · 📺 ${featured.network}` : ""}
          </div>
        </div>
      ) : (
        <div className="spt-tile-sub spt-tile-sub--empty">No events</div>
      )}
      <div className="spt-tile-count">{summary?.todayCount ?? 0} today</div>
    </button>
  );
}

// ── Gamecast — full matchup detail opened from an event row ──

function fmtFullDate(iso: string) {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  return date.toLocaleDateString("en-US", { weekday: undefined, month: "short", day: "numeric" });
}

function GameDetail({ event, onClose }: { event: SportEvent; onClose: () => void }) {
  const [detail, setDetail] = useState<GameDetailData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [teamA, teamB] = event.competitors;
  const accent = SPORT_META[event.sport]?.color;

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError("");
    const params = new URLSearchParams({
      sportPath: event.sportPath,
      leaguePath: event.leaguePath,
      eventId: event.rawId,
      teamA: teamA.id,
      teamB: teamB.id,
    });
    fetch(`/api/widgets/sports-tracker/game?${params.toString()}`)
      .then(async (response) => {
        const json = await response.json();
        if (!response.ok) throw new Error(json.error || "Failed to load game");
        return json as GameDetailData;
      })
      .then((json) => {
        if (!cancelled) setDetail(json);
      })
      .catch((cause) => {
        if (!cancelled) setError(cause instanceof Error ? cause.message : "Failed to load game");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [event.sportPath, event.leaguePath, event.rawId, teamA.id, teamB.id]);

  const recentGamesFor = (teamId: string) => detail?.recentGames?.[teamId] || [];
  const injuriesFor = (teamId: string) => detail?.injuries.find((g) => g.teamId === teamId)?.injuries || [];

  return (
    <div className="spt-gc-overlay" role="dialog" aria-modal="true">
      <div className="spt-gc-panel" style={accent ? { ["--spt-accent" as string]: accent } : undefined}>
        <button type="button" className="spt-gc-close" onClick={onClose} aria-label="Close">
          ×
        </button>

        <div className="spt-gc-header">
          {[teamA, teamB].map((c, i) => (
            <div className="spt-gc-header-team" key={i}>
              {c.logo ? <img className="spt-gc-header-logo" src={c.logo} alt="" /> : null}
              <span className="spt-gc-header-name">{c.name}</span>
              {c.score ? (
                <span className={`spt-score-badge spt-score-badge--lg${c.winner ? " spt-score-badge--winner" : ""}`}>
                  {c.score}
                </span>
              ) : null}
            </div>
          ))}
        </div>
        <div className="spt-gc-header-sub">
          <StateDot state={event.state} />
          {event.state === "in" ? event.statusDetail || "Live" : event.state === "post" ? "Final" : `${fmtDay(event.startTime)} · ${fmtTime(event.startTime)}`}
          {event.href ? (
            <a className="spt-gc-espn-link" href={event.href} target="_blank" rel="noopener noreferrer">
              View on ESPN ↗
            </a>
          ) : null}
        </div>

        {loading ? (
          <div className="spt-loading">
            <span className="spt-spin" /> Loading game…
          </div>
        ) : error ? (
          <div className="spt-inline-error">{error}</div>
        ) : detail ? (
          <div className="spt-gc-body">
            <div className="spt-gc-main">
              <div className="spt-gc-section">
                <div className="spt-section-title">Injury Report</div>
                {[teamA, teamB].map((c) => {
                  const rows = injuriesFor(c.id);
                  return (
                    <div className="spt-injury-team" key={c.id}>
                      <div className="spt-injury-team-head">
                        {c.logo ? <img className="spt-injury-team-logo" src={c.logo} alt="" /> : null}
                        <span>{c.name}</span>
                      </div>
                      {rows.length ? (
                        <div className="spt-injury-table">
                          {rows.map((row, i) => (
                            <div className="spt-injury-row" key={i}>
                              <span className="spt-injury-name">
                                {row.athleteName}
                                {row.position ? <span className="spt-injury-pos"> {row.position}</span> : null}
                              </span>
                              <span className="spt-injury-status">
                                <span className="spt-injury-dot" /> {row.status}
                              </span>
                              <span className="spt-injury-detail">{row.detail}</span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="spt-injury-none">No injuries reported</div>
                      )}
                    </div>
                  );
                })}
              </div>

              <div className="spt-gc-section">
                <div className="spt-section-title">Last Five Games</div>
                <div className="spt-lastfive-cols">
                  {[teamA, teamB].map((c) => (
                    <div className="spt-lastfive-col" key={c.id}>
                      <div className="spt-lastfive-head">
                        {c.logo ? <img className="spt-lastfive-logo" src={c.logo} alt="" /> : null}
                        <span>{c.name}</span>
                      </div>
                      {recentGamesFor(c.id).length ? (
                        recentGamesFor(c.id).map((g, i) => (
                          <div className="spt-lastfive-row" key={i}>
                            <span className="spt-lastfive-date">{fmtFullDate(g.date)}</span>
                            <span className="spt-lastfive-opp">
                              {g.home ? "vs" : "@"} {g.opponentAbbrev}
                            </span>
                            <span className={`spt-lastfive-result${g.result.startsWith("W") ? " spt-lastfive-result--win" : " spt-lastfive-result--loss"}`}>
                              {g.result}
                            </span>
                          </div>
                        ))
                      ) : (
                        <div className="spt-injury-none">No recent games</div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="spt-gc-section">
                <div className="spt-section-title">Game Information</div>
                <div className="spt-gc-info-row">📅 {fmtFullDate(detail.startTime || event.startTime)} · {fmtTime(detail.startTime || event.startTime)}</div>
                {detail.venue ? <div className="spt-gc-info-row">📍 {detail.venue}{detail.city ? ` — ${detail.city}` : ""}</div> : null}
                {detail.network ? <div className="spt-gc-info-row">📺 {detail.network}</div> : null}
              </div>
            </div>

            <div className="spt-gc-side">
              <SportSidebar sport={event.sport} />
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}

export default function SportsTrackerWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "sports-tracker";
  const [data, setData] = useState<SportsStatus | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<Tab>("compare");
  const [openGame, setOpenGame] = useState<SportEvent | null>(null);

  const load = async () => {
    try {
      const response = await fetch(
        `/api/widgets/sports-tracker/status?instance=${encodeURIComponent(instanceId)}`,
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load sports data");
      setData(json);
      setError("");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Failed to load sports data");
    } finally {
      setLoading(false);
    }
  };

  const { rootRef } = useWidgetPoll(load, { intervalMs: 60_000 });

  const maxToday = useMemo(() => {
    if (!data) return 0;
    return SPORT_ORDER.reduce((max, sport) => Math.max(max, data.sports[sport]?.todayCount ?? 0), 0);
  }, [data]);

  if (loading && !data) {
    return (
      <div className="hd-widget-body spt-body" ref={rootRef}>
        <div className="spt-loading">
          <span className="spt-spin" /> Loading sports…
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="hd-widget-body spt-body" ref={rootRef}>
        <div className="spt-inline-error">{error || "Sports data unavailable"}</div>
        <button className="spt-tool-btn" type="button" onClick={load}>
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="hd-widget-body spt-body" ref={rootRef}>
      <div className="spt-tabs">
        <button
          type="button"
          className={`spt-tab${tab === "compare" ? " spt-tab--active" : ""}`}
          onClick={() => setTab("compare")}
        >
          Compare
        </button>
        {SPORT_ORDER.map((sport) => (
          <button
            type="button"
            key={sport}
            className={`spt-tab${tab === sport ? " spt-tab--active" : ""}`}
            onClick={() => setTab(sport)}
          >
            <span className="spt-tab-icon">{SPORT_META[sport].icon}</span>
            <span className="spt-tab-text">{SPORT_META[sport].label}</span>
          </button>
        ))}
      </div>

      {error ? <div className="spt-inline-error">{error}</div> : null}

      {tab === "compare" ? (
        <div className="spt-compare">
          <div className="spt-tile-grid">
            {SPORT_ORDER.map((sport) => (
              <CompareTile
                key={sport}
                sport={sport}
                summary={data.sports[sport]}
                onOpen={() => setTab(sport)}
              />
            ))}
          </div>
          <div className="spt-stats">
            <div className="spt-stats-title">Games today</div>
            <div className="spt-stats-grid">
              {SPORT_ORDER.map((sport) => {
                const meta = SPORT_META[sport];
                const count = data.sports[sport]?.todayCount ?? 0;
                const width = maxToday > 0 ? Math.max(4, Math.round((count / maxToday) * 100)) : 0;
                return (
                  <div
                    className="spt-stat-card"
                    key={sport}
                    style={{ ["--spt-accent" as string]: meta.color }}
                  >
                    <div className="spt-stat-top">
                      <span className="spt-stat-icon">{meta.icon}</span>
                      <span className="spt-stat-label">{meta.label}</span>
                    </div>
                    <div className="spt-stat-value">{count}</div>
                    <div className="spt-stat-track">
                      <div className="spt-stat-fill" style={{ width: `${width}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      ) : (
        <SportPanel sport={tab} summary={data.sports[tab]} onOpenGame={setOpenGame} />
      )}

      {openGame ? <GameDetail event={openGame} onClose={() => setOpenGame(null)} /> : null}
    </div>
  );
}
