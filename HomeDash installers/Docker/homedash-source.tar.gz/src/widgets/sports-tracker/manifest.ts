import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "sports-tracker",
  name: "Sports Tracker",
  description:
    "Live scores with team logos & broadcast networks, team-vs-team comparisons, team stats, player stat leaders & rosters, standings, headlines and an ESPN-style gamecast (injury report + last five games) across Soccer, Football, Golf, Basketball, Baseball & Tennis",
  version: "0.3.0",
  category: "Sports",
  defaultSize: { w: 6, h: 5, minW: 3, minH: 3 },
  hostClass: "spt-host",
  // Public scoreboard/team data — nothing to configure, no credentials required.
  configFields: [],
};
