"use client";
import "@/styles/widgets/spotify.widget.css";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

// ── Types (mirrors src/lib/widgets/spotify.ts) ───────────────────────────

type SpotifyDevice = {
  id: string | null;
  name: string;
  type: string;
  isActive: boolean;
  isPrivateSession: boolean;
  volumePercent: number | null;
};

type SpotifyTrack = {
  id: string | null;
  name: string;
  artists: string;
  album: string;
  albumArtUrl: string | null;
  durationMs: number;
  uri: string | null;
  externalUrl: string | null;
};

type SpotifyPlaybackState = {
  isPlaying: boolean;
  progressMs: number | null;
  shuffle: boolean;
  repeat: "off" | "track" | "context";
  device: SpotifyDevice | null;
  track: SpotifyTrack | null;
};

type SpotifyRecentItem = { playedAt: string; track: SpotifyTrack };

type SpotifyPlaylist = {
  id: string;
  name: string;
  ownerName: string;
  trackCount: number;
  imageUrl: string | null;
  uri: string;
  externalUrl: string | null;
};

type StatusPayload = {
  playback: SpotifyPlaybackState | null;
  playbackError: string | null;
  recentlyPlayed: SpotifyRecentItem[];
  devices: SpotifyDevice[];
  playlists: SpotifyPlaylist[];
};

type View = "now-playing" | "recent" | "devices" | "playlists";

// ── Helpers ────────────────────────────────────────────────────────────

function formatMs(ms: number | null | undefined) {
  if (ms === null || ms === undefined || Number.isNaN(ms)) return "0:00";
  const totalSeconds = Math.max(0, Math.floor(ms / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${String(seconds).padStart(2, "0")}`;
}

function formatRelative(iso: string) {
  const parsed = new Date(iso).getTime();
  if (Number.isNaN(parsed)) return "";
  const diffMs = Date.now() - parsed;
  const minutes = Math.round(diffMs / 60000);
  if (minutes < 1) return "just now";
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  return `${days}d ago`;
}

// ── Icons (inline SVG, no external deps) ──────────────────────────────

function Icon({ path, size = 15 }: { path: string; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d={path} />
    </svg>
  );
}

const ICONS = {
  play: "M8 5v14l11-7z",
  pause: "M6 5h4v14H6zM14 5h4v14h-4z",
  prev: "M6 6h2v12H6zm3.5 6 8.5 6V6z",
  next: "M16 6h2v12h-2zM6 6l8.5 6L6 18z",
  shuffle: "M10.59 9.17 5.41 4 4 5.41l5.17 5.17 1.42-1.41zM14.5 4l2.04 2.04L4 18.59 5.41 20 17.96 7.46 20 9.5V4h-5.5zm.33 9.41-1.41 1.42 3.13 3.13L14.5 20H20v-5.5l-2.04 2.04-3.13-3.13z",
  repeat: "M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4z",
  repeatOne: "M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4zm-4.5-4h1V9h-2v1h1z",
  device: "M4 6h16v10H4V6zm-1 12h18v2H3v-2z",
  speaker: "M12 2a5 5 0 0 0-5 5v10a5 5 0 0 0 10 0V7a5 5 0 0 0-5-5zm0 3a1.8 1.8 0 1 1 0 3.6A1.8 1.8 0 0 1 12 5zm0 6a3 3 0 1 1 0 6 3 3 0 0 1 0-6z",
  computer: "M4 4h16v12H4V4zm3 15h10v2H7z",
  phone: "M8 2h8a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2zm4 17a1.2 1.2 0 1 0 0-2.4 1.2 1.2 0 0 0 0 2.4z",
  refresh: "M17.65 6.35A8 8 0 1 0 19.94 13h-2.02A6 6 0 1 1 12 6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z",
};

function deviceIconPath(type: string) {
  const t = type.toLowerCase();
  if (t.includes("speaker")) return ICONS.speaker;
  if (t.includes("phone") || t.includes("smartphone")) return ICONS.phone;
  return ICONS.computer;
}

// ── Component ───────────────────────────────────────────────────────────

export default function SpotifyPlayerWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "spotify-player";

  const [view, setView] = useState<View>("now-playing");
  const [data, setData] = useState<StatusPayload | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [pending, setPending] = useState<Record<string, boolean>>({});
  const [actionError, setActionError] = useState("");
  const [localProgressMs, setLocalProgressMs] = useState<number | null>(null);

  const load = useCallback(async () => {
    setError("");
    try {
      const response = await fetch(
        `/api/widgets/spotify-player/status?instance=${encodeURIComponent(instanceId)}`,
        { cache: "no-store", signal: AbortSignal.timeout(15_000) },
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load Spotify");
      setData(json as StatusPayload);
      setLocalProgressMs(json?.playback?.progressMs ?? null);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Failed to load Spotify");
    } finally {
      setLoading(false);
    }
  }, [instanceId]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: 15_000 });

  // Tick the progress bar locally between polls so it doesn't look frozen.
  useEffect(() => {
    if (!data?.playback?.isPlaying) return;
    const timer = setInterval(() => {
      setLocalProgressMs((prev) => {
        if (prev === null) return prev;
        const duration = data.playback?.track?.durationMs ?? Infinity;
        return Math.min(prev + 1000, duration);
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [data?.playback?.isPlaying, data?.playback?.track?.durationMs]);

  const runAction = useCallback(
    async (actionId: string, action: string, extra: Record<string, unknown> = {}) => {
      setActionError("");
      setPending((prev) => ({ ...prev, [actionId]: true }));
      try {
        const response = await fetch("/api/widgets/spotify-player/action", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ instance: instanceId, action, ...extra }),
          signal: AbortSignal.timeout(15_000),
        });
        const json = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(json.error || "Action failed");
        await load();
      } catch (reason) {
        setActionError(reason instanceof Error ? reason.message : "Action failed");
      } finally {
        setPending((prev) => {
          const next = { ...prev };
          delete next[actionId];
          return next;
        });
      }
    },
    [instanceId, load],
  );

  const playback = data?.playback ?? null;
  const track = playback?.track ?? null;
  const recentlyPlayed = data?.recentlyPlayed ?? [];
  const devices = data?.devices ?? [];
  const playlists = data?.playlists ?? [];

  const badge = useMemo(() => {
    if (!playback || !track) return { label: "Offline", className: "spotify-status-badge--offline" };
    return playback.isPlaying
      ? { label: "Playing", className: "spotify-status-badge--playing" }
      : { label: "Paused", className: "spotify-status-badge--paused" };
  }, [playback, track]);

  if (loading && !data) {
    return (
      <div className="hd-widget-body spotify-body-flat" ref={rootRef}>
        <div className="spotify-toolbar">
          <div className="spotify-status-badge spotify-status-badge--offline">
            <span className="spotify-status-dot-pill" />
            Loading
          </div>
        </div>
        {Array.from({ length: 3 }, (_, index) => (
          <div className="spotify-skeleton-row" style={{ animationDelay: `${index * 0.1}s` }} key={index} />
        ))}
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="hd-widget-body spotify-body-flat" ref={rootRef}>
        <div className="spotify-toolbar">
          <div className="spotify-status-badge spotify-status-badge--unhealthy">
            <span className="spotify-status-dot-pill" />
            Unhealthy
          </div>
          <button className="spotify-refresh-btn" type="button" onClick={() => load()} aria-label="Retry">
            <Icon path={ICONS.refresh} />
          </button>
        </div>
        <div className="spotify-error">⚠ {error}</div>
      </div>
    );
  }

  return (
    <div className="hd-widget-body spotify-body-flat" ref={rootRef}>
      <div className="spotify-toolbar">
        <div className="spotify-toolbar-left">
          <div className={`spotify-status-badge ${badge.className}`}>
            <span className="spotify-status-dot-pill" />
            {badge.label}
          </div>
        </div>
        <div className="spotify-toolbar-right">
          <div className="spotify-tabs">
            <button
              className={`spotify-tab${view === "now-playing" ? " spotify-tab--active" : ""}`}
              type="button"
              onClick={() => setView("now-playing")}
            >
              Now Playing
            </button>
            <button
              className={`spotify-tab${view === "recent" ? " spotify-tab--active" : ""}`}
              type="button"
              onClick={() => setView("recent")}
            >
              Recent
            </button>
            <button
              className={`spotify-tab${view === "devices" ? " spotify-tab--active" : ""}`}
              type="button"
              onClick={() => setView("devices")}
            >
              Devices
            </button>
            <button
              className={`spotify-tab${view === "playlists" ? " spotify-tab--active" : ""}`}
              type="button"
              onClick={() => setView("playlists")}
            >
              Playlists
            </button>
          </div>
          <button
            className={`spotify-refresh-btn${loading ? " spotify-refresh-btn--spinning" : ""}`}
            type="button"
            onClick={() => load()}
            aria-label="Refresh"
          >
            <Icon path={ICONS.refresh} />
          </button>
        </div>
      </div>

      {actionError ? <div className="spotify-error">⚠ {actionError}</div> : null}

      <div className="spotify-scroll">
        {view === "now-playing" ? (
          <NowPlayingPanel
            playback={playback}
            track={track}
            playbackError={data?.playbackError ?? null}
            progressMs={localProgressMs}
            pending={pending}
            onSeekRatio={(ratio) => {
              if (!track) return;
              const ms = Math.round(track.durationMs * ratio);
              setLocalProgressMs(ms);
              runAction("seek", "seek", { positionMs: ms });
            }}
            onPlayPause={() =>
              playback?.isPlaying ? runAction("playpause", "pause") : runAction("playpause", "play")
            }
            onNext={() => runAction("next", "next")}
            onPrev={() => runAction("prev", "previous")}
            onToggleShuffle={() => runAction("shuffle", "shuffle", { state: !playback?.shuffle })}
            onCycleRepeat={() => {
              const next = playback?.repeat === "off" ? "context" : playback?.repeat === "context" ? "track" : "off";
              runAction("repeat", "repeat", { state: next });
            }}
            onVolumeChange={(percent) =>
              playback?.device?.id &&
              runAction("volume", "volume", { volumePercent: percent, deviceId: playback.device.id })
            }
          />
        ) : null}

        {view === "recent" ? (
          <RecentPanel
            items={recentlyPlayed}
            deviceId={playback?.device?.id ?? devices.find((d) => d.isActive)?.id ?? null}
            pending={pending}
            onPlay={(uri, actionId) => runAction(actionId, "play-track", { uri })}
          />
        ) : null}

        {view === "devices" ? (
          <DevicesPanel
            devices={devices}
            pending={pending}
            onSelect={(deviceId, actionId) =>
              runAction(actionId, "transfer-playback", { deviceId, play: Boolean(playback?.isPlaying) })
            }
          />
        ) : null}

        {view === "playlists" ? (
          <PlaylistsPanel
            playlists={playlists}
            deviceId={playback?.device?.id ?? devices.find((d) => d.isActive)?.id ?? null}
            pending={pending}
            onPlay={(uri, actionId) => runAction(actionId, "play-playlist", { uri })}
          />
        ) : null}
      </div>
    </div>
  );
}

// ── Now Playing ──────────────────────────────────────────────────────

function NowPlayingPanel({
  playback,
  track,
  playbackError,
  progressMs,
  pending,
  onSeekRatio,
  onPlayPause,
  onNext,
  onPrev,
  onToggleShuffle,
  onCycleRepeat,
  onVolumeChange,
}: {
  playback: SpotifyPlaybackState | null;
  track: SpotifyTrack | null;
  playbackError: string | null;
  progressMs: number | null;
  pending: Record<string, boolean>;
  onSeekRatio: (ratio: number) => void;
  onPlayPause: () => void;
  onNext: () => void;
  onPrev: () => void;
  onToggleShuffle: () => void;
  onCycleRepeat: () => void;
  onVolumeChange: (percent: number) => void;
}) {
  const trackRef = useRef<HTMLDivElement>(null);

  if (!track) {
    if (playbackError) {
      return (
        <div className="spotify-empty">
          <div className="spotify-error">⚠ Couldn&apos;t load Now Playing: {playbackError}</div>
        </div>
      );
    }
    return <div className="spotify-empty">Nothing playing right now</div>;
  }

  const ratio = track.durationMs > 0 ? Math.min(1, (progressMs ?? 0) / track.durationMs) : 0;

  const handleSeekClick = (event: React.MouseEvent<HTMLDivElement>) => {
    const el = trackRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const clickRatio = Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width));
    onSeekRatio(clickRatio);
  };

  return (
    <div className="spotify-now-playing">
      <div className="spotify-np-main">
        {track.albumArtUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img className="spotify-np-art" src={track.albumArtUrl} alt="" />
        ) : (
          <div className="spotify-np-art spotify-np-art--placeholder">♪</div>
        )}
        <div className="spotify-np-meta">
          <div className="spotify-np-track" title={track.name}>{track.name}</div>
          <div className="spotify-np-artist" title={track.artists}>{track.artists}</div>
          <div className="spotify-np-album" title={track.album}>{track.album}</div>
          {playback?.device ? <div className="spotify-np-device">▸ {playback.device.name}</div> : null}
        </div>
      </div>

      <div className="spotify-progress-wrap">
        <span className="spotify-progress-time">{formatMs(progressMs)}</span>
        <div className="spotify-progress-track" ref={trackRef} onClick={handleSeekClick}>
          <div className="spotify-progress-fill" style={{ width: `${ratio * 100}%` }} />
        </div>
        <span className="spotify-progress-time">{formatMs(track.durationMs)}</span>
      </div>

      <div className="spotify-controls">
        <button
          type="button"
          className={`spotify-control-btn${playback?.shuffle ? " spotify-control-btn--toggle-on" : ""}`}
          onClick={onToggleShuffle}
          disabled={pending.shuffle}
          aria-label="Toggle shuffle"
          title="Shuffle"
        >
          <Icon path={ICONS.shuffle} size={14} />
        </button>
        <button
          type="button"
          className="spotify-control-btn"
          onClick={onPrev}
          disabled={pending.prev}
          aria-label="Previous track"
          title="Previous"
        >
          <Icon path={ICONS.prev} size={16} />
        </button>
        <button
          type="button"
          className="spotify-control-btn spotify-control-btn--play"
          onClick={onPlayPause}
          disabled={pending.playpause}
          aria-label={playback?.isPlaying ? "Pause" : "Play"}
          title={playback?.isPlaying ? "Pause" : "Play"}
        >
          <Icon path={playback?.isPlaying ? ICONS.pause : ICONS.play} size={18} />
        </button>
        <button
          type="button"
          className="spotify-control-btn"
          onClick={onNext}
          disabled={pending.next}
          aria-label="Next track"
          title="Next"
        >
          <Icon path={ICONS.next} size={16} />
        </button>
        <button
          type="button"
          className={`spotify-control-btn${playback?.repeat && playback.repeat !== "off" ? " spotify-control-btn--toggle-on" : ""}`}
          onClick={onCycleRepeat}
          disabled={pending.repeat}
          aria-label="Cycle repeat mode"
          title={`Repeat: ${playback?.repeat ?? "off"}`}
        >
          <Icon path={playback?.repeat === "track" ? ICONS.repeatOne : ICONS.repeat} size={14} />
        </button>
      </div>

      {playback?.device?.volumePercent !== null && playback?.device?.volumePercent !== undefined ? (
        <div className="spotify-volume-row">
          <span className="spotify-progress-time">Vol</span>
          <div
            className="spotify-volume-track"
            onClick={(event) => {
              const rect = event.currentTarget.getBoundingClientRect();
              const clickRatio = Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width));
              onVolumeChange(Math.round(clickRatio * 100));
            }}
          >
            <div className="spotify-volume-fill" style={{ width: `${playback.device.volumePercent}%` }} />
          </div>
          <span className="spotify-progress-time">{playback.device.volumePercent}%</span>
        </div>
      ) : null}
    </div>
  );
}

// ── Recently Played ──────────────────────────────────────────────────

function RecentPanel({
  items,
  deviceId,
  pending,
  onPlay,
}: {
  items: SpotifyRecentItem[];
  deviceId: string | null;
  pending: Record<string, boolean>;
  onPlay: (uri: string, actionId: string) => void;
}) {
  if (!items.length) return <div className="spotify-empty">No recent plays yet</div>;
  return (
    <div className="spotify-group">
      <div className="spotify-group-label">Recently Played</div>
      {items.map((item, index) => {
        const actionId = `recent-${item.track.id}-${index}`;
        return (
          <button
            key={`${item.track.id}-${item.playedAt}-${index}`}
            type="button"
            className="spotify-track-row"
            onClick={() => item.track.uri && onPlay(item.track.uri, actionId)}
            disabled={pending[actionId] || !item.track.uri || !deviceId}
            title={deviceId ? "Play this track" : "No active device"}
          >
            {item.track.albumArtUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img className="spotify-track-art" src={item.track.albumArtUrl} alt="" />
            ) : (
              <div className="spotify-track-art" />
            )}
            <div className="spotify-track-meta">
              <span className="spotify-track-name">{item.track.name}</span>
              <span className="spotify-track-artist">{item.track.artists}</span>
            </div>
            <span className="spotify-track-meta-right">{formatRelative(item.playedAt)}</span>
          </button>
        );
      })}
    </div>
  );
}

// ── Devices ───────────────────────────────────────────────────────────

function DevicesPanel({
  devices,
  pending,
  onSelect,
}: {
  devices: SpotifyDevice[];
  pending: Record<string, boolean>;
  onSelect: (deviceId: string, actionId: string) => void;
}) {
  if (!devices.length) return <div className="spotify-empty">No devices found — open Spotify somewhere first</div>;
  return (
    <div className="spotify-group">
      <div className="spotify-group-label">Devices</div>
      {devices.map((device) => {
        const actionId = `device-${device.id}`;
        return (
          <button
            key={device.id || device.name}
            type="button"
            className={`spotify-device-row${device.isActive ? " spotify-device-row--active" : ""}`}
            onClick={() => device.id && onSelect(device.id, actionId)}
            disabled={pending[actionId] || !device.id || device.isActive}
          >
            <div className="spotify-device-left">
              <span className="spotify-device-icon">
                <Icon path={deviceIconPath(device.type)} size={17} />
              </span>
              <span className="spotify-device-name">{device.name}</span>
              <span className="spotify-device-type">{device.type}</span>
            </div>
            {device.isActive ? (
              <span className="spotify-status-badge spotify-status-badge--playing">
                <span className="spotify-status-dot-pill" />
                Active
              </span>
            ) : device.volumePercent !== null ? (
              <span className="spotify-track-meta-right">{device.volumePercent}%</span>
            ) : null}
          </button>
        );
      })}
    </div>
  );
}

// ── Playlists ─────────────────────────────────────────────────────────

function PlaylistsPanel({
  playlists,
  deviceId,
  pending,
  onPlay,
}: {
  playlists: SpotifyPlaylist[];
  deviceId: string | null;
  pending: Record<string, boolean>;
  onPlay: (uri: string, actionId: string) => void;
}) {
  if (!playlists.length) return <div className="spotify-empty">No playlists found</div>;
  return (
    <div className="spotify-group">
      <div className="spotify-group-label">Playlists</div>
      <div className="spotify-playlist-grid">
        {playlists.map((playlist) => {
          const actionId = `playlist-${playlist.id}`;
          return (
            <div
              key={playlist.id}
              className="spotify-playlist-card"
              role="button"
              tabIndex={0}
              title={deviceId ? "Play this playlist" : "No active device"}
              onClick={() => playlist.uri && onPlay(playlist.uri, actionId)}
              onKeyDown={(event) => {
                if ((event.key === "Enter" || event.key === " ") && playlist.uri) {
                  event.preventDefault();
                  onPlay(playlist.uri, actionId);
                }
              }}
              aria-disabled={pending[actionId] || !deviceId}
            >
              {playlist.imageUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img className="spotify-playlist-art" src={playlist.imageUrl} alt="" />
              ) : (
                <div className="spotify-playlist-art" />
              )}
              <div className="spotify-playlist-name" title={playlist.name}>{playlist.name}</div>
              <div className="spotify-playlist-owner">
                {playlist.trackCount} tracks{playlist.ownerName ? ` · ${playlist.ownerName}` : ""}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
