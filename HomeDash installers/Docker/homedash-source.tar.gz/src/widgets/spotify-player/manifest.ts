import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "spotify-player",
  name: "Spotify",
  description: "Now playing with playback controls, recently played, devices, and playlist browser",
  version: "0.1.0",
  category: "Media",
  defaultSize: { w: 6, h: 6, minW: 4, minH: 4 },
  configFields: [
    {
      key: "clientId",
      label: "Client ID",
      type: "text",
      placeholder: "Spotify app Client ID",
    },
    {
      key: "clientSecret",
      label: "Client Secret",
      type: "password",
      placeholder: "Spotify app Client Secret",
    },
    {
      key: "refreshToken",
      label: "Refresh Token (one-time OAuth exchange — needs user-read-playback-state, user-modify-playback-state, user-read-currently-playing, user-read-recently-played, playlist-read-private scopes)",
      type: "password",
      placeholder: "AQC…",
    },
  ],
};
