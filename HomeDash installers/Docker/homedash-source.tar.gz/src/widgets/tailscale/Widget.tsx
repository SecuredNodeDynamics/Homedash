"use client";
import "@/styles/widgets/tailscale.widget.css";


import { useCallback, useState } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type Device = {
  id: string;
  nodeId: string;
  name: string;
  hostname: string;
  os: string;
  addresses: string[];
  tags: string[];
  lastSeen: string | null;
  advertisedRoutes: string[];
  enabledRoutes: string[];
  authorized: boolean;
  updateAvailable: boolean;
  isExitNode: boolean;
  online: boolean;
};

type Status = {
  devices: Device[];
  publicUrl: string;
  overviewLimit: number;
};

type Tab = "overview" | "devices" | "exitnodes";

function timeAgo(value: string | null) {
  if (!value) return "Never";
  const seconds = Math.floor((Date.now() - new Date(value).getTime()) / 1000);
  if (!Number.isFinite(seconds)) return "Never";
  if (seconds < 60) return `${Math.max(0, seconds)}s ago`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  if (seconds < 2_592_000) return `${Math.floor(seconds / 86400)}d ago`;
  return new Date(value).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

function deviceIp(device: Device) {
  return device.addresses.find((address) => address.startsWith("100.")) || device.addresses[0] || "—";
}

function osIcon(os: string) {
  const normalized = os.toLowerCase();
  if (normalized.includes("linux")) return "🐧";
  if (normalized.includes("windows")) return "🪟";
  if (normalized.includes("darwin") || normalized.includes("mac")) return "🍎";
  if (normalized.includes("ios") || normalized.includes("iphone")) return "📱";
  if (normalized.includes("android")) return "🤖";
  if (normalized.includes("freebsd") || normalized.includes("openbsd")) return "😈";
  return "💻";
}

function tagsFor(device: Device) {
  return device.tags.map((tag) => tag.replace(/^tag:/, ""));
}

function sortedForOverview(devices: Device[]) {
  return [...devices].sort((a, b) => {
    if (a.online !== b.online) return a.online ? -1 : 1;
    if (a.isExitNode !== b.isExitNode) return a.isExitNode ? -1 : 1;
    if (a.updateAvailable !== b.updateAvailable) return a.updateAvailable ? -1 : 1;
    const aTime = a.lastSeen ? new Date(a.lastSeen).getTime() : 0;
    const bTime = b.lastSeen ? new Date(b.lastSeen).getTime() : 0;
    return bTime - aTime || a.name.localeCompare(b.name);
  });
}

function OpenLink({ href }: { href: string }) {
  return (
    <a className="ts-open-link" href={href} target="_blank" rel="noopener noreferrer">
      Open
    </a>
  );
}

function DeviceRow({ device }: { device: Device }) {
  const tags = tagsFor(device);
  return (
    <div className="ts-row">
      <span className={`ts-dot ${device.online ? "ts-dot--online" : "ts-dot--offline"}`} />
      <span className="ts-os-icon">{osIcon(device.os)}</span>
      <div className="ts-row-body">
        <div className="ts-row-title">
          <span>{device.name}</span>
          {device.isExitNode ? <span className="ts-exit-badge">Exit Node</span> : null}
          {device.updateAvailable ? <span className="ts-update-badge">Update Available</span> : null}
          {device.updateAvailable && device.nodeId ? (
            <a
              className="ts-update-btn"
              href={`https://login.tailscale.com/admin/machines/${encodeURIComponent(device.nodeId)}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              ↑ Update
            </a>
          ) : null}
          {!device.authorized ? <span className="ts-warn-badge">Unauthorized</span> : null}
        </div>
        <div className="ts-row-sub">
          <span className="ts-ip">{deviceIp(device)}</span>
          {tags.map((tag) => (
            <span className="ts-tag ts-tag--sm" key={tag}>
              {tag}
            </span>
          ))}
        </div>
      </div>
      <div className="ts-row-meta">
        <span className={`ts-lastseen${device.online ? " ts-lastseen--online" : ""}`}>
          {timeAgo(device.lastSeen)}
        </span>
      </div>
    </div>
  );
}

function TabBar({
  tab,
  setTab,
  online,
  total,
  exitCount,
}: {
  tab: Tab;
  setTab: (tab: Tab) => void;
  online: number;
  total: number;
  exitCount: number;
}) {
  return (
    <div className="ts-tabs" role="tablist" aria-label="Tailscale views">
      {(["overview", "devices", "exitnodes"] as const).map((key) => (
        <button
          className={`ts-tab${tab === key ? " ts-tab--active" : ""}`}
          type="button"
          role="tab"
          aria-selected={tab === key}
          key={key}
          onClick={() => setTab(key)}
        >
          {key === "exitnodes" ? "Exit Nodes" : key[0].toUpperCase() + key.slice(1)}
          {key === "devices" && total ? (
            <span className="ts-tab-badge">
              {online}/{total}
            </span>
          ) : null}
          {key === "exitnodes" && exitCount ? (
            <span className="ts-tab-badge">{exitCount}</span>
          ) : null}
        </button>
      ))}
    </div>
  );
}

export default function TailscaleWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "tailscale";
  const [tab, setTab] = useState<Tab>("overview");
  const [data, setData] = useState<Status | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const response = await fetch(
        `/api/widgets/tailscale/status?instance=${encodeURIComponent(instanceId)}`,
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load Tailscale");
      setData(json);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load Tailscale");
      setData(null);
    } finally {
      setLoading(false);
    }
  }, [instanceId]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: 60_000 });

  const devices = data?.devices || [];
  const online = devices.filter((device) => device.online).length;
  const exitNodes = devices.filter((device) => device.isExitNode);
  const tagNames = [...new Set(devices.flatMap(tagsFor))];
  const publicUrl = data?.publicUrl || "https://login.tailscale.com/admin/machines";

  function renderContent() {
    if (loading && !data) {
      return (
        <div className="ts-loading">
          <svg
            className="ts-spin"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="#3b82f6"
            strokeWidth="2"
            aria-hidden
          >
            <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" />
          </svg>{" "}
          Loading…
        </div>
      );
    }

    if (error && !data) {
      return (
        <div className="ts-empty">
          Failed to load Tailscale data
          <br />
          <span>{error}</span>
          <br />
          <button className="ts-tab" type="button" onClick={load}>
            Retry
          </button>
        </div>
      );
    }

    if (tab === "devices") {
      const onlineDevices = devices
        .filter((device) => device.online)
        .sort((a, b) => a.name.localeCompare(b.name));
      const offlineDevices = devices
        .filter((device) => !device.online)
        .sort(
          (a, b) =>
            new Date(b.lastSeen || 0).getTime() - new Date(a.lastSeen || 0).getTime(),
        );
      if (!devices.length) return <div className="ts-empty">No devices found</div>;
      return (
        <div className="ts-scroll">
          {onlineDevices.length ? (
            <>
              <div className="ts-group-header">
                <span className="ts-dot ts-dot--online" />
                Online <span className="ts-group-count">{onlineDevices.length}</span>
              </div>
              {onlineDevices.map((device) => (
                <DeviceRow key={device.id} device={device} />
              ))}
            </>
          ) : null}
          {offlineDevices.length ? (
            <>
              <div className="ts-group-header" style={{ marginTop: onlineDevices.length ? 10 : 0 }}>
                <span className="ts-dot ts-dot--offline" />
                Offline <span className="ts-group-count">{offlineDevices.length}</span>
              </div>
              {offlineDevices.map((device) => (
                <DeviceRow key={device.id} device={device} />
              ))}
            </>
          ) : null}
        </div>
      );
    }

    if (tab === "exitnodes") {
      if (!exitNodes.length) return <div className="ts-empty">No exit nodes configured</div>;
      return (
        <div className="ts-scroll">
          {exitNodes.map((device) => {
            const routes = [...new Set([...device.advertisedRoutes, ...device.enabledRoutes])].filter(
              (route) => route !== "0.0.0.0/0" && route !== "::/0",
            );
            return (
              <div className="ts-exit-card" key={device.id}>
                <div className="ts-exit-card-header">
                  <span className={`ts-dot ${device.online ? "ts-dot--online" : "ts-dot--offline"}`} />
                  <span className="ts-os-icon">{osIcon(device.os)}</span>
                  <span className="ts-exit-card-name">{device.name}</span>
                  <span className="ts-exit-badge" style={{ marginLeft: "auto" }}>
                    Exit Node
                  </span>
                  <span className={`ts-lastseen${device.online ? " ts-lastseen--online" : ""}`}>
                    {timeAgo(device.lastSeen)}
                  </span>
                </div>
                <div className="ts-exit-card-body">
                  <div className="ts-exit-detail">
                    <span className="ts-exit-detail-label">Tailscale IP</span>
                    <span className="ts-exit-detail-value ts-ip">{deviceIp(device)}</span>
                  </div>
                  <div className="ts-exit-detail">
                    <span className="ts-exit-detail-label">Hostname</span>
                    <span className="ts-exit-detail-value">{device.hostname || device.name}</span>
                  </div>
                  <div className="ts-exit-detail">
                    <span className="ts-exit-detail-label">OS</span>
                    <span className="ts-exit-detail-value">{device.os || "Unknown"}</span>
                  </div>
                  {routes.length ? (
                    <div className="ts-exit-detail">
                      <span className="ts-exit-detail-label">Routes</span>
                      <span className="ts-exit-detail-value">
                        {routes.map((route) => (
                          <span className="ts-route" key={route}>
                            {route}
                          </span>
                        ))}
                      </span>
                    </div>
                  ) : null}
                </div>
              </div>
            );
          })}
        </div>
      );
    }

    const limit = data?.overviewLimit || 0;
    const overviewDevices = sortedForOverview(devices);
    const limited =
      Number.isFinite(limit) && limit > 0 ? overviewDevices.slice(0, limit) : overviewDevices;

    return (
      <>
        <div className="ts-fixed">
          <div className="ts-stat-grid">
            <div className="ts-stat ts-stat--online">
              <div className="ts-stat-value">{online.toLocaleString()}</div>
              <div className="ts-stat-label">Online</div>
            </div>
            <div className="ts-stat ts-stat--offline">
              <div className="ts-stat-value">{(devices.length - online).toLocaleString()}</div>
              <div className="ts-stat-label">Offline</div>
            </div>
            <div className="ts-stat">
              <div className="ts-stat-value">{devices.length.toLocaleString()}</div>
              <div className="ts-stat-label">Total Devices</div>
            </div>
            <div className={`ts-stat${exitNodes.length ? " ts-stat--accent" : ""}`}>
              <div className="ts-stat-value">{exitNodes.length.toLocaleString()}</div>
              <div className="ts-stat-label">Exit Nodes</div>
            </div>
            <div
              className={`ts-stat${
                devices.some((device) => device.updateAvailable) ? " ts-stat--warn" : ""
              }`}
            >
              <div className="ts-stat-value">
                {devices.filter((device) => device.updateAvailable).length.toLocaleString()}
              </div>
              <div className="ts-stat-label">Updates</div>
            </div>
            <div className="ts-stat">
              <div className="ts-stat-value">{tagNames.length.toLocaleString()}</div>
              <div className="ts-stat-label">Tags</div>
            </div>
          </div>
          {tagNames.length ? (
            <div className="ts-tag-cloud">
              {tagNames.map((tag) => (
                <span className="ts-tag" key={tag}>
                  {tag}
                </span>
              ))}
            </div>
          ) : null}
        </div>
        <div className="ts-scroll">
          <div className="ts-section-label">Devices</div>
          {limited.map((device) => (
            <DeviceRow key={device.id} device={device} />
          ))}
          {!devices.length ? <div className="ts-empty">No devices found</div> : null}
        </div>
      </>
    );
  }

  return (
    <div className="hd-widget-body ts-body" ref={rootRef}>
      <div className="ts-toolbar">
        <TabBar
          tab={tab}
          setTab={setTab}
          online={online}
          total={devices.length}
          exitCount={exitNodes.length}
        />
        <div className="ts-toolbar-right">
          <OpenLink href={publicUrl} />
        </div>
      </div>
      <div className="ts-content">{renderContent()}</div>
    </div>
  );
}
