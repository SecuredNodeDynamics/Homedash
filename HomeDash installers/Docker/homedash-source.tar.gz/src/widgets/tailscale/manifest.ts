import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "tailscale",
  name: "Tailscale",
  description: "Tailnet device status",
  version: "0.1.0",
  category: "Network",
  defaultSize: { w: 5, h: 4, minW: 3, minH: 3 },
  configFields: [
    {
      key: "apiKey",
      label: "API Key",
      type: "password",
      required: true,
      placeholder: "tskey-api-…",
    },
    {
      key: "proxyUrl",
      label: "Proxy URL",
      type: "url",
      required: true,
      placeholder: "https://tailscale.example.workers.dev/tailscale-proxy",
    },
    {
      key: "publicUrl",
      label: "Dashboard / Open URL",
      type: "url",
      required: true,
      placeholder: "https://login.tailscale.com/admin/machines",
    },
    {
      key: "tailnet",
      label: "Tailnet",
      type: "text",
      placeholder: "you@example.com or -",
    },
    {
      key: "overviewLimit",
      label: "Overview device limit (0 = all)",
      type: "number",
      placeholder: "0",
    },
  ],
};
