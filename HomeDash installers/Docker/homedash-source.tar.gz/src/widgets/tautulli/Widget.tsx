"use client";
import "@/styles/widgets/tautulli.widget.css";


import { useCallback, useState } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type Session = {
  title: string;
  user: string;
  progress: number;
  player: string;
  quality: string;
  bandwidth: string | number;
  transcode: string;
  mediaType?: string;
  state?: string;
};

type Library = {
  name: string;
  count: number;
  duration?: number;
  type?: string;
};

type HistoryRow = {
  title: string;
  user: string;
  date: number;
  mediaType?: string;
};

type Data = {
  href: string;
  openFallbackUrl?: string;
  streams: number;
  transcodes: number;
  direct_play: number;
  direct?: number;
  users: number;
  sessions: Session[];
  libraries: Library[];
  history: HistoryRow[];
  serverName: string;
};

type TabKey = "overview" | "playing" | "history" | "libraries";

const POLL_MS = 30_000;

const TABS: { key: TabKey; label: string }[] = [
  { key: "overview", label: "Overview" },
  { key: "playing", label: "Now Playing" },
  { key: "history", label: "History" },
  { key: "libraries", label: "Libraries" },
];

function fmtInt(value: number) {
  return Number(value || 0).toLocaleString();
}

function mediaIcon(type?: string) {
  const t = String(type || "").toLowerCase();
  if (t.includes("movie")) return "🎬";
  if (t.includes("episode") || t.includes("show")) return "📺";
  if (t.includes("track") || t.includes("artist") || t.includes("album")) return "🎵";
  return "▶";
}

function streamState(state?: string) {
  const value = String(state || "").toLowerCase();
  if (value.includes("pause")) return { label: "Paused", cls: "tau-badge--paused" };
  if (value.includes("buffer")) return { label: "Buffering", cls: "tau-badge--warn" };
  return { label: "Playing", cls: "tau-badge--playing" };
}

function fmtHistoryDate(date: number) {
  if (!date) return "";
  return new Date(Number(date) * 1000).toLocaleDateString();
}

function SessionCard({ session }: { session: Session }) {
  const state = streamState(session.state);
  const pct = Math.max(0, Math.min(100, Math.round(session.progress || 0)));
  const subtitle = [session.user, session.player, session.quality].filter(Boolean).join(" · ");
  const bandwidth = session.bandwidth ? `${session.bandwidth} kbps` : "";
  return (
    <div className="tau-stream">
      <div className="tau-stream-icon">{mediaIcon(session.mediaType)}</div>
      <div className="tau-stream-body">
        <div className="tau-stream-top">
          <span className="tau-stream-title">{session.title}</span>
          <span className={`tau-badge ${state.cls}`}>{state.label}</span>
        </div>
        <div className="tau-stream-sub">{subtitle}</div>
        <div className="tau-progress">
          <span style={{ width: `${pct}%` }} />
        </div>
        <div className="tau-stream-meta">
          <span>{session.transcode || "Stream"}</span>
          <span>{bandwidth}</span>
        </div>
      </div>
    </div>
  );
}

function HistoryItem({ row }: { row: HistoryRow }) {
  return (
    <div className="tau-history-row">
      <span className="tau-history-icon">{mediaIcon(row.mediaType)}</span>
      <div className="tau-history-main">
        <div className="tau-history-title">{row.title}</div>
        <div className="tau-history-sub">
          {[row.user, fmtHistoryDate(row.date)].filter(Boolean).join(" · ")}
        </div>
      </div>
    </div>
  );
}

function LibraryItem({ lib }: { lib: Library }) {
  return (
    <div className="tau-library">
      <span>{mediaIcon(lib.type)}</span>
      <div>
        <div className="tau-library-title">{lib.name}</div>
        <div className="tau-library-sub">
          {lib.type || "library"} · {fmtInt(lib.count)} items
        </div>
      </div>
    </div>
  );
}

function StatsStrip({
  streams,
  transcodes,
  direct,
  users,
}: {
  streams: number;
  transcodes: number;
  direct: number;
  users: number;
}) {
  return (
    <div className="tau-stats tau-stats--strip">
      <div className="tau-stat">
        <span>{fmtInt(streams)}</span>
        <small>Streams</small>
      </div>
      <div className="tau-stat">
        <span>{fmtInt(transcodes)}</span>
        <small>Transcodes</small>
      </div>
      <div className="tau-stat">
        <span>{fmtInt(direct)}</span>
        <small>Direct</small>
      </div>
      <div className="tau-stat">
        <span>{fmtInt(users)}</span>
        <small>Users</small>
      </div>
    </div>
  );
}

export default function TautulliWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "tautulli";
  const [data, setData] = useState<Data | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<TabKey>("overview");
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);

  const load = useCallback(
    async (opts?: { soft?: boolean }) => {
      if (!opts?.soft) setLoading(true);
      try {
        const response = await fetch(
          `/api/widgets/tautulli/status?instance=${encodeURIComponent(instanceId)}`,
        );
        const json = await response.json();
        if (!response.ok) throw new Error(json.error || "Failed to load Tautulli");
        setData(json);
        setError("");
      } catch (cause) {
        if (!opts?.soft) {
          setError(cause instanceof Error ? cause.message : "Failed to load Tautulli");
        }
      } finally {
        if (!opts?.soft) setLoading(false);
      }
    },
    [instanceId],
  );

  const { rootRef } = useWidgetPoll(load, { intervalMs: POLL_MS });

  if (loading && !data) {
    return (
      <div className="hd-widget-body tau-body-flat" ref={rootRef}>
        <div className="tau-shell">
          <div className="tau-empty">Loading Tautulli…</div>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="hd-widget-body tau-body-flat" ref={rootRef}>
        <div className="tau-shell">
          <div className="tau-toolbar">
            <div className="tau-toolbar-left">
              <span className="tau-status-pill tau-status-pill--warn">
                <span className="tau-status-dot" aria-hidden="true" />
                Offline
              </span>
            </div>
            <div className="tau-toolbar-right">
              <button className="tau-open-link" type="button" onClick={() => void load()}>
                Retry
              </button>
            </div>
          </div>
          <div className="tau-empty tau-empty--error">{error || "Failed to load Tautulli"}</div>
        </div>
      </div>
    );
  }

  const live = data;
  const direct = live.direct_play ?? live.direct ?? 0;
  const isOnline = Boolean(live.href || live.sessions.length || live.libraries.length) && !error;

  function renderPanel() {
    if (tab === "overview") {
      return (
        <div className="tau-overview">
          <StatsStrip
            streams={live.streams}
            transcodes={live.transcodes}
            direct={direct}
            users={live.users}
          />
          <div className="tau-overview-block">
            <div className="tau-block-label">Active</div>
            {live.sessions.length ? (
              <div className="tau-streams">
                {live.sessions.slice(0, 2).map((session, index) => (
                  <SessionCard key={`${session.title}-${index}`} session={session} />
                ))}
              </div>
            ) : (
              <div className="tau-empty tau-empty--soft">No active Plex streams</div>
            )}
          </div>
          <div className="tau-overview-block">
            <div className="tau-block-label">Recent</div>
            {live.history.length ? (
              <div className="tau-history tau-list-flat">
                {live.history.slice(0, 3).map((row, index) => (
                  <HistoryItem key={`${row.title}-${index}`} row={row} />
                ))}
              </div>
            ) : (
              <div className="tau-empty tau-empty--soft">No recent history</div>
            )}
          </div>
        </div>
      );
    }

    if (tab === "playing") {
      if (!live.sessions.length) {
        return <div className="tau-empty">No active Plex streams</div>;
      }
      return (
        <div className="tau-streams">
          {live.sessions.map((session, index) => (
            <SessionCard key={`${session.title}-${index}`} session={session} />
          ))}
        </div>
      );
    }

    if (tab === "history") {
      if (!live.history.length) {
        return <div className="tau-empty">No recent history</div>;
      }
      return (
        <div className="tau-history tau-list-flat">
          {live.history.map((row, index) => (
            <HistoryItem key={`${row.title}-${index}`} row={row} />
          ))}
        </div>
      );
    }

    if (!live.libraries.length) {
      return <div className="tau-empty">No library data</div>;
    }
    return (
      <div className="tau-libraries tau-list-flat">
        {live.libraries.map((lib, index) => (
          <LibraryItem key={`${lib.name}-${index}`} lib={lib} />
        ))}
      </div>
    );
  }

  return (
    <div className="hd-widget-body tau-body-flat" ref={rootRef}>
      <div className="tau-shell">
        <div className="tau-toolbar">
          <div className="tau-toolbar-left">
            <span className={`tau-status-pill${isOnline ? " tau-status-pill--ok" : " tau-status-pill--warn"}`}>
              <span className="tau-status-dot" aria-hidden="true" />
              {isOnline ? "Online" : "Offline"}
            </span>
          </div>
          <div className="tau-toolbar-right">
            {openHref ? (
              <a className="tau-open-link" href={openHref} target="_blank" rel="noopener noreferrer">
                Open
              </a>
            ) : null}
          </div>
        </div>

        <div className="tau-controls">
          <div className="tau-tabs" role="tablist" aria-label="Tautulli sections">
            {TABS.map((item) => (
              <button
                key={item.key}
                className={`tau-tab${tab === item.key ? " tau-tab--active" : ""}`}
                type="button"
                role="tab"
                aria-selected={tab === item.key}
                onClick={() => setTab(item.key)}
              >
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="tau-panel">{renderPanel()}</div>
      </div>
    </div>
  );
}
