import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "tautulli",
  name: "Tautulli",
  description: "Plex streams, libraries, and history with Overview / Now Playing / History / Libraries tabs",
  version: "0.3.0",
  category: "Media",
  defaultSize: { w: 5, h: 5, minW: 3, minH: 3 },
  hostClass: "tau-monitor-host",
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "http://10.0.0.1:8181",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      placeholder: "https://tautulli.example.com",
    },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url", placeholder: "http://10.0.0.1:8181" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    {
      key: "apiKey",
      label: "API Key",
      type: "password",
      required: true,
    },
  ],
};
