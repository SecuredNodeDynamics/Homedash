"use client";

import "@/styles/widgets/tdarr.widget.css";
import "@/styles/widgets/tdarr.offline.state.css";

import { useCallback, useState } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type Data = {
  href: string;
  openFallbackUrl?: string;
  files: number;
  queue: number;
  errors: number;
  transcoded: number;
  nodes: { name: string; status: string; paused: boolean }[];
};

export default function Widget() {
  const i = useWidgetInstance();
  const [d, setD] = useState<Data>();
  const [e, setE] = useState("");

  const l = useCallback(async () => {
    try {
      const r = await fetch(
        `/api/widgets/tdarr/status?instance=${encodeURIComponent(i?.instanceId || "tdarr")}`,
      );
      const j = await r.json();
      if (!r.ok) throw Error(j.error);
      setD(j);
      setE("");
    } catch (x) {
      setE(x instanceof Error ? x.message : "Failed to load");
    }
  }, [i?.instanceId]);

  const { rootRef } = useWidgetPoll(l, { intervalMs: 60_000 });
  const openHref = useOpenHref(d?.href, d?.openFallbackUrl);

  return (
    <div className="hd-widget-body" ref={rootRef}>
      <div className="tdr-host">
        <div className="tdr-shell">
          <header className="tdr-hdr">
            <b>{i?.label || "Tdarr"}</b>
            {d && (
              <a href={openHref} target="_blank" rel="noreferrer">
                Open
              </a>
            )}
          </header>
          {d ? (
            <>
              <div className="tdr-stat-grid">
                {(
                  [
                    ["Files", d.files],
                    ["Queue", d.queue],
                    ["Errors", d.errors],
                    ["Transcoded", d.transcoded],
                  ] as const
                ).map(([n, v]) => (
                  <div className="tdr-stat" key={String(n)}>
                    <strong>{Number(v).toLocaleString()}</strong>
                    <span>{n}</span>
                  </div>
                ))}
              </div>
              <div className="tdr-nodes">
                {d.nodes.map((n, x) => (
                  <div className="tdr-node" key={x}>
                    <b>{n.name}</b>
                    <span>{n.paused ? "Paused" : n.status}</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="tdr-empty">{e || "Loading…"}</div>
          )}
        </div>
      </div>
    </div>
  );
}
