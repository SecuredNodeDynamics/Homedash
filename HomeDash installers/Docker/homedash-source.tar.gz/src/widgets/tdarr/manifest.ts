import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "tdarr",
  name: "Tdarr",
  description: "Library transcode queues",
  version: "0.1.0",
  category: "Media",
  defaultSize: { w: 5, h: 4, minW: 3, minH: 3 },
  hostClass: "tdr-host",
  configFields: [
  {
    "key": "baseUrl",
    "label": "Private - IP",
    "type": "url",
    "placeholder": "http://10.0.0.1:8265"
  },
  {
    "key": "fallbackUrl",
    "label": "Fallback Public URL",
    "type": "url",
    "placeholder": "https://tdarr.example.com"
  },
  {
    "key": "publicUrl",
    "label": "OPEN - Private URL",
    "type": "url",
    "placeholder": "http://10.0.0.1:8265"
  },
  {
    "key": "openFallbackUrl",
    "label": "OPEN - Public URL",
    "type": "url",
    "placeholder": "https://… (Cloudflare)"
  },
  {
    "key": "apiKey",
    "label": "API Key",
    "type": "password",
    "required": true
  }
],
};
