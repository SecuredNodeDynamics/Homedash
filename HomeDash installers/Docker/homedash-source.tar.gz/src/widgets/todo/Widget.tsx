"use client";

import "@/styles/widgets/todo.widget.css";

import { useEffect, useMemo, useRef, useState } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";

type Filter = "all" | "active" | "done";

type TodoItem = {
  id: string;
  text: string;
  done: boolean;
  createdAt: number;
};

function newId() {
  return typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function normalizeItems(value: unknown): TodoItem[] {
  if (!Array.isArray(value)) return [];
  return value
    .filter((item): item is Partial<TodoItem> => Boolean(item && typeof item === "object"))
    .map((item) => ({
      id: String(item.id || newId()),
      text: String(item.text || "").trim().slice(0, 240),
      done: Boolean(item.done),
      createdAt: Number(item.createdAt) || Date.now(),
    }))
    .filter((item) => item.text);
}

export default function TodoWidget() {
  const instance = useWidgetInstance();
  const storageKey = `homedash.todo.${instance?.instanceId || "todo"}`;
  const [items, setItems] = useState<TodoItem[]>([]);
  const [draft, setDraft] = useState("");
  const [filter, setFilter] = useState<Filter>("all");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState("");
  const [ready, setReady] = useState(false);
  const editInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    try {
      setItems(normalizeItems(JSON.parse(localStorage.getItem(storageKey) || "[]")));
    } catch {
      setItems([]);
    }
    setReady(true);
  }, [storageKey]);

  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem(storageKey, JSON.stringify(items));
    } catch {
      /* Browser storage can be unavailable in private/restricted contexts. */
    }
  }, [items, ready, storageKey]);

  useEffect(() => {
    if (editingId) editInputRef.current?.focus();
  }, [editingId]);

  const active = items.filter((item) => !item.done).length;
  const done = items.length - active;
  const visible = useMemo(
    () =>
      items.filter((item) =>
        filter === "active" ? !item.done : filter === "done" ? item.done : true,
      ),
    [filter, items],
  );

  function addItem() {
    const text = draft.trim();
    if (!text) return;
    setItems((current) => [
      { id: newId(), text: text.slice(0, 240), done: false, createdAt: Date.now() },
      ...current,
    ]);
    setDraft("");
  }

  function beginEdit(item: TodoItem) {
    setEditingId(item.id);
    setEditingText(item.text);
  }

  function saveEdit() {
    if (!editingId) return;
    const text = editingText.trim().slice(0, 240);
    if (text) {
      setItems((current) =>
        current.map((item) => (item.id === editingId ? { ...item, text } : item)),
      );
    } else {
      setItems((current) => current.filter((item) => item.id !== editingId));
    }
    setEditingId(null);
    setEditingText("");
  }

  return (
    <div className="todo-shell">
      <form
        className="todo-compose"
        onSubmit={(event) => {
          event.preventDefault();
          addItem();
        }}
      >
        <input
          value={draft}
          onChange={(event) => setDraft(event.target.value)}
          maxLength={240}
          placeholder="Add a task…"
          aria-label="New task"
        />
        <button type="submit" disabled={!draft.trim()} aria-label="Add task">
          <span aria-hidden>+</span>
        </button>
      </form>

      <div className="todo-toolbar">
        <div className="todo-filters" role="tablist" aria-label="Filter tasks">
          {(["all", "active", "done"] as const).map((key) => (
            <button
              key={key}
              type="button"
              role="tab"
              aria-selected={filter === key}
              className={filter === key ? "is-active" : ""}
              onClick={() => setFilter(key)}
            >
              {key === "all" ? `All ${items.length}` : key === "active" ? `Active ${active}` : `Done ${done}`}
            </button>
          ))}
        </div>
        {done ? (
          <button
            type="button"
            className="todo-clear"
            onClick={() => setItems((current) => current.filter((item) => !item.done))}
          >
            Clear done
          </button>
        ) : null}
      </div>

      <div className="todo-list" aria-live="polite">
        {!ready ? <div className="todo-empty">Loading tasks…</div> : null}
        {ready && !visible.length ? (
          <div className="todo-empty">
            <span aria-hidden>✓</span>
            {items.length ? `No ${filter} tasks` : "Nothing on your list"}
            <small>{items.length ? "Try another filter" : "Add a task above to get started"}</small>
          </div>
        ) : null}
        {visible.map((item) => (
          <div key={item.id} className={`todo-item${item.done ? " is-done" : ""}`}>
            <button
              type="button"
              className="todo-check"
              aria-label={item.done ? `Mark ${item.text} active` : `Complete ${item.text}`}
              aria-pressed={item.done}
              onClick={() =>
                setItems((current) =>
                  current.map((entry) =>
                    entry.id === item.id ? { ...entry, done: !entry.done } : entry,
                  ),
                )
              }
            >
              <span aria-hidden>{item.done ? "✓" : ""}</span>
            </button>
            {editingId === item.id ? (
              <input
                ref={editInputRef}
                className="todo-edit"
                value={editingText}
                maxLength={240}
                aria-label={`Edit ${item.text}`}
                onChange={(event) => setEditingText(event.target.value)}
                onBlur={saveEdit}
                onKeyDown={(event) => {
                  if (event.key === "Enter") saveEdit();
                  if (event.key === "Escape") setEditingId(null);
                }}
              />
            ) : (
              <button type="button" className="todo-text" onClick={() => beginEdit(item)}>
                {item.text}
              </button>
            )}
            <button
              type="button"
              className="todo-delete"
              aria-label={`Delete ${item.text}`}
              onClick={() =>
                setItems((current) => current.filter((entry) => entry.id !== item.id))
              }
            >
              <span aria-hidden>×</span>
            </button>
          </div>
        ))}
      </div>

      <div className="todo-footer">
        <span>{active ? `${active} remaining` : items.length ? "All caught up" : "Ready when you are"}</span>
        <span>Stored in this browser</span>
      </div>
    </div>
  );
}
