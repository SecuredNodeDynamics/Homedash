import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "todo",
  name: "Todo List",
  description: "Quick, persistent task list stored in the browser",
  version: "0.1.0",
  category: "Productivity",
  hostClass: "todo-host",
  defaultSize: { w: 4, h: 6, minW: 2, minH: 4 },
  configFields: [],
};
