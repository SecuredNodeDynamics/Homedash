"use client";

import "@/styles/widgets/tracearr.widget.css";

import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";
import {
  CHART_PALETTE,
  COMPAT_CODECS,
  MOST_WATCHED_RANGES,
  compatTone,
  fmtBytes,
  fmtBytesSigned,
  fmtDaysStale,
  fmtDuration,
  fmtResolution,
  getCompatibilityMatrix,
  getDeviceHealth,
  getDurationSeconds,
  getHistoryPlays,
  getLibraries,
  getMostWatched,
  getTopUsers,
  getTranscodeHotspots,
  mediaTypeLabel,
  num,
  parseStaleItems,
  relativeAgo,
  sessionTitle,
  sessionUser,
  sessionsForDay,
  sortMostWatched,
  sortStaleItems,
  type HistoryEntry,
  type MostWatchedKind,
  type MostWatchedRange,
  type MostWatchedSort,
  type StaleCategory,
  type StaleSort,
  type StoragePayload,
  type StoragePeriod,
} from "@/lib/widgets/tracearr-data";
import { useTracearrCharts, type TracearrTab } from "./useTracearrCharts";

type ConnectionSource = "private" | "public" | "unknown";

const CONNECTION_SOURCE_LABEL: Record<ConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

function ConnectionCorner({ source }: { source: ConnectionSource }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const mark = (
    <div
      className={`trr-corner-source trr-corner-source--${source}`}
      title={CONNECTION_SOURCE_LABEL[source]}
      aria-label={CONNECTION_SOURCE_LABEL[source]}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}

type Data = {
  href: string;
  openFallbackUrl?: string;
  connectionSource?: ConnectionSource;
  health: {
    status?: string;
    version?: string;
    servers?: Array<{ name?: string; online?: boolean; activeStreams?: number }>;
  } | null;
  stats: Record<string, unknown>;
  today: Record<string, unknown>;
  activity: Record<string, unknown>;
  users: unknown[];
  streams: unknown;
  history: HistoryEntry[];
  storage: StoragePayload | null;
  libraryAuthConfigured?: boolean;
  duplicates: {
    summary?: {
      totalGroups?: number;
      totalPotentialSavingsBytes?: number;
    };
  } | null;
  stale: {
    available?: boolean;
    summary?: {
      neverWatched?: { count?: number; sizeBytes?: number };
      stale?: { count?: number; sizeBytes?: number };
    } | null;
    staleItems?: unknown[];
    neverWatchedItems?: unknown[];
  };
};

type PopupState = {
  label: string;
  plays: number;
  watch: number;
  context?: string;
  emptyText?: string;
  sessions: Array<{ title: string; user: string; duration: string }>;
  more: number;
} | null;

const TABS: Array<{ id: TracearrTab; label: string }> = [
  { id: "overview", label: "Overview" },
  { id: "watch", label: "Watch" },
  { id: "history", label: "History" },
  { id: "users", label: "Users" },
  { id: "devices", label: "Devices" },
  { id: "storage", label: "Storage" },
  { id: "libraries", label: "Libraries" },
  { id: "heatmap", label: "Peak Hours" },
];

const MOST_WATCHED_PAGE_SIZE = 10;
const STALE_PAGE_SIZE = 10;
const STORAGE_PERIODS: Array<{ id: StoragePeriod; label: string }> = [
  { id: "7d", label: "7d" },
  { id: "30d", label: "30d" },
  { id: "1y", label: "1y" },
  { id: "all", label: "All" },
];

const DOW = ["S", "M", "T", "W", "T", "F", "S"];
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const HEAT_DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function cellColor(plays: number, max: number) {
  if (!plays) return "rgba(255,255,255,0.05)";
  const t = plays / max;
  if (t <= 0.25) return "rgba(34,211,238,0.22)";
  if (t <= 0.5) return "rgba(34,211,238,0.46)";
  if (t <= 0.75) return "rgba(34,211,238,0.70)";
  return "rgba(34,211,238,0.92)";
}

function textColor(plays: number, max: number) {
  if (!plays) return "rgba(255,255,255,0.25)";
  return plays / max >= 0.5 ? "rgba(0,0,0,0.70)" : "rgba(255,255,255,0.60)";
}

function activityLabel(v: number, max: number) {
  if (!v) return "No activity";
  const pct = v / max;
  if (pct >= 0.75) return "Peak activity";
  if (pct >= 0.5) return "High activity";
  if (pct >= 0.25) return "Moderate activity";
  return "Light activity";
}

function hourLabel(h: number) {
  const start = new Date(2000, 0, 1, h);
  const end = new Date(2000, 0, 1, h + 1);
  return `${start.toLocaleTimeString("en-US", { hour: "numeric" })} - ${end.toLocaleTimeString("en-US", { hour: "numeric" })}`;
}

export default function TracearrWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "tracearr";
  const [data, setData] = useState<Data | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<TracearrTab>("overview");
  const [histRange, setHistRange] = useState(7);
  const [histMetric, setHistMetric] = useState<"plays" | "watchTime">("plays");
  const [watchRange, setWatchRange] = useState<MostWatchedRange>(30);
  const [watchKind, setWatchKind] = useState<MostWatchedKind>("movie");
  const [watchSort, setWatchSort] = useState<MostWatchedSort>("plays");
  const [watchSortDir, setWatchSortDir] = useState<"asc" | "desc">("desc");
  const [watchPage, setWatchPage] = useState(1);
  const [watchRangeOpen, setWatchRangeOpen] = useState(false);
  const watchRangeRef = useRef<HTMLDivElement | null>(null);
  const [storagePeriod, setStoragePeriod] = useState<StoragePeriod>("30d");
  const [storagePredictions, setStoragePredictions] = useState(true);
  const [storageLive, setStorageLive] = useState<StoragePayload | null>(null);
  const [storageError, setStorageError] = useState("");
  const [staleCat, setStaleCat] = useState<StaleCategory>("stale");
  const [staleMediaFilter, setStaleMediaFilter] = useState<"all" | "movie" | "show" | "music">("all");
  const [staleSort, setStaleSort] = useState<StaleSort>("size");
  const [staleSortDir, setStaleSortDir] = useState<"asc" | "desc">("desc");
  const [stalePage, setStalePage] = useState(1);
  const [staleMediaOpen, setStaleMediaOpen] = useState(false);
  const staleMediaRef = useRef<HTMLDivElement | null>(null);
  const [popup, setPopup] = useState<PopupState>(null);
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);

  const watchRef = useRef<HTMLCanvasElement | null>(null);
  const concurrentRef = useRef<HTMLCanvasElement | null>(null);
  const historyMainRef = useRef<HTMLCanvasElement | null>(null);
  const bandwidthRef = useRef<HTMLCanvasElement | null>(null);
  const storageRef = useRef<HTMLCanvasElement | null>(null);
  const usersRef = useRef<HTMLCanvasElement | null>(null);
  const librariesRef = useRef<HTMLCanvasElement | null>(null);
  const [, setCanvasTick] = useState(0);

  const load = useCallback(async () => {
    try {
      const response = await fetch(
        `/api/widgets/tracearr/status?instance=${encodeURIComponent(instanceId)}`,
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load Tracearr");
      setData(json);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unavailable");
    } finally {
      setLoading(false);
    }
  }, [instanceId]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: 60_000 });

  // Remount charts after tab body paints canvases.
  useEffect(() => {
    setCanvasTick((n) => n + 1);
  }, [tab, histRange, histMetric, data, storagePeriod, storagePredictions, storageLive]);

  useTracearrCharts({
    tab,
    histRange,
    histMetric,
    history: data?.history || [],
    activity: data?.activity || {},
    users: data?.users || [],
    storage: storageLive || data?.storage || null,
    storagePeriod,
    storagePredictions,
    watchCanvas: watchRef.current,
    concurrentCanvas: concurrentRef.current,
    historyMainCanvas: historyMainRef.current,
    bandwidthCanvas: bandwidthRef.current,
    storageCanvas: storageRef.current,
    usersCanvas: usersRef.current,
    librariesCanvas: librariesRef.current,
  });

  useEffect(() => {
    if (!popup) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setPopup(null);
    };
    const onClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      if (target?.closest(".trr-cal-popup, .trr-cal-cell, .trr-heatmap-cell")) return;
      setPopup(null);
    };
    window.addEventListener("keydown", onKey);
    // Defer so the opening click does not immediately dismiss the popup.
    const timer = window.setTimeout(() => {
      document.addEventListener("click", onClick, true);
    }, 0);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener("keydown", onKey);
      document.removeEventListener("click", onClick, true);
    };
  }, [popup]);

  useEffect(() => {
    if (!watchRangeOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setWatchRangeOpen(false);
    };
    const onClick = (e: MouseEvent) => {
      if (watchRangeRef.current?.contains(e.target as Node)) return;
      setWatchRangeOpen(false);
    };
    window.addEventListener("keydown", onKey);
    const timer = window.setTimeout(() => {
      document.addEventListener("mousedown", onClick, true);
    }, 0);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener("keydown", onKey);
      document.removeEventListener("mousedown", onClick, true);
    };
  }, [watchRangeOpen]);

  useEffect(() => {
    if (!staleMediaOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setStaleMediaOpen(false);
    };
    const onClick = (e: MouseEvent) => {
      if (staleMediaRef.current?.contains(e.target as Node)) return;
      setStaleMediaOpen(false);
    };
    window.addEventListener("keydown", onKey);
    const timer = window.setTimeout(() => {
      document.addEventListener("mousedown", onClick, true);
    }, 0);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener("keydown", onKey);
      document.removeEventListener("mousedown", onClick, true);
    };
  }, [staleMediaOpen]);

  useEffect(() => {
    setStorageLive(data?.storage || null);
  }, [data?.storage]);

  useEffect(() => {
    if (tab !== "storage") return;
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(
          `/api/widgets/tracearr/storage?instance=${encodeURIComponent(instanceId)}&period=${storagePeriod}`,
        );
        if (!res.ok) return;
        const json = (await res.json()) as StoragePayload & { error?: string };
        if (cancelled) return;
        if (!res.ok) {
          setStorageError(json.error || `Storage request failed (HTTP ${res.status})`);
          return;
        }
        setStorageLive(json);
        setStorageError("");
      } catch (nextError) {
        if (!cancelled) {
          setStorageError(nextError instanceof Error ? nextError.message : "Storage request failed");
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [tab, storagePeriod, instanceId]);

  const today = data?.today || {};
  const stats = data?.stats || {};
  const health = data?.health;
  const online = health?.servers?.[0]?.online ?? true;
  const activeStreams = num(today.activeStreams ?? stats.activeStreams, 0);
  const statusTxt = online
    ? activeStreams > 0
      ? `${activeStreams} Streaming`
      : "Online"
    : "Offline";

  const metrics = useMemo(() => {
    const watch =
      today.watchTimeHours != null
        ? `${num(today.watchTimeHours, 0)}h`
        : fmtDuration(num(today.watchTime ?? today.watch_time ?? 0, 0));
    return [
      { label: "Today Plays", value: num(today.todayPlays ?? today.plays ?? today.totalPlays, 0) },
      { label: "Today Watch Time", value: watch },
      { label: "Active Streams", value: num(today.activeStreams ?? stats.activeStreams, 0) },
      { label: "Users", value: num(stats.users ?? stats.totalUsers, 0) },
    ];
  }, [today, stats]);

  const topUsers = useMemo(
    () => getTopUsers(data?.history || [], data?.users || []),
    [data?.history, data?.users],
  );
  const deviceHealth = useMemo(() => getDeviceHealth(data?.history || []), [data?.history]);
  const transcodeHotspots = useMemo(
    () => getTranscodeHotspots(data?.history || []),
    [data?.history],
  );
  const compatMatrix = useMemo(
    () => getCompatibilityMatrix(data?.history || []),
    [data?.history],
  );
  const mostWatchedMovies = useMemo(
    () => getMostWatched(data?.history || [], "movie", watchRange),
    [data?.history, watchRange],
  );
  const mostWatchedShows = useMemo(
    () => getMostWatched(data?.history || [], "show", watchRange),
    [data?.history, watchRange],
  );
  const mostWatched = useMemo(() => {
    const source = watchKind === "movie" ? mostWatchedMovies : mostWatchedShows;
    return sortMostWatched(source, watchSort, watchSortDir);
  }, [mostWatchedMovies, mostWatchedShows, watchKind, watchSort, watchSortDir]);
  const watchPageCount = Math.max(1, Math.ceil(mostWatched.length / MOST_WATCHED_PAGE_SIZE));
  const watchPageSafe = Math.min(watchPage, watchPageCount);
  const mostWatchedPage = useMemo(() => {
    const start = (watchPageSafe - 1) * MOST_WATCHED_PAGE_SIZE;
    return mostWatched.slice(start, start + MOST_WATCHED_PAGE_SIZE);
  }, [mostWatched, watchPageSafe]);

  const storageData = storageLive || data?.storage || null;
  const storageAvailable = !!(storageData || data?.duplicates || data?.stale?.available);
  const totalStorageBytes = num(storageData?.current?.totalSizeBytes, 0);
  const growthPerMonth = num(storageData?.growthRate?.bytesPerMonth, 0);
  const dupGroups = num(data?.duplicates?.summary?.totalGroups, 0);
  const dupSavings = num(data?.duplicates?.summary?.totalPotentialSavingsBytes, 0);
  const neverCount = num(data?.stale?.summary?.neverWatched?.count, 0);
  const staleCount = num(data?.stale?.summary?.stale?.count, 0);
  const neverBytes = num(data?.stale?.summary?.neverWatched?.sizeBytes, 0);
  const staleBytes = num(data?.stale?.summary?.stale?.sizeBytes, 0);
  const staleTotalItems = neverCount + staleCount;
  const staleTotalBytes = neverBytes + staleBytes;
  const confidence = storageData?.predictions?.confidence || null;

  const staleSource = useMemo(() => {
    const raw =
      staleCat === "never_watched"
        ? data?.stale?.neverWatchedItems || []
        : data?.stale?.staleItems || [];
    let items = parseStaleItems(raw);
    if (staleMediaFilter === "movie") {
      items = items.filter((i) => mediaTypeLabel(i.mediaType) === "Movie");
    } else if (staleMediaFilter === "show") {
      items = items.filter((i) => mediaTypeLabel(i.mediaType) === "TV");
    } else if (staleMediaFilter === "music") {
      items = items.filter((i) => mediaTypeLabel(i.mediaType) === "Music");
    }
    return sortStaleItems(items, staleSort, staleSortDir);
  }, [
    data?.stale?.neverWatchedItems,
    data?.stale?.staleItems,
    staleCat,
    staleMediaFilter,
    staleSort,
    staleSortDir,
  ]);
  const stalePageCount = Math.max(1, Math.ceil(staleSource.length / STALE_PAGE_SIZE));
  const stalePageSafe = Math.min(stalePage, stalePageCount);
  const stalePageRows = useMemo(() => {
    const start = (stalePageSafe - 1) * STALE_PAGE_SIZE;
    return staleSource.slice(start, start + STALE_PAGE_SIZE);
  }, [staleSource, stalePageSafe]);

  const libraries = useMemo(() => getLibraries(data?.history || []), [data?.history]);

  function toggleWatchSort(next: MostWatchedSort) {
    if (watchSort === next) {
      setWatchSortDir((d) => (d === "desc" ? "asc" : "desc"));
    } else {
      setWatchSort(next);
      setWatchSortDir("desc");
    }
    setWatchPage(1);
  }

  function sortMark(col: MostWatchedSort) {
    if (watchSort !== col) return "↕";
    return watchSortDir === "desc" ? "↓" : "↑";
  }

  function toggleStaleSort(next: StaleSort) {
    if (staleSort === next) {
      setStaleSortDir((d) => (d === "desc" ? "asc" : "desc"));
    } else {
      setStaleSort(next);
      setStaleSortDir("desc");
    }
    setStalePage(1);
  }

  function staleSortMark(col: StaleSort) {
    if (staleSort !== col) return "↕";
    return staleSortDir === "desc" ? "↓" : "↑";
  }
  const watch30 = useMemo(
    () => getHistoryPlays(data?.history || [], data?.activity || {}, 30),
    [data?.history, data?.activity],
  );
  const hasDuration = watch30.duration.some((v) => v > 0);

  const calendar = useMemo(() => {
    const DAYS = 35;
    const bucket = getHistoryPlays(data?.history || [], data?.activity || {}, DAYS);
    const max = Math.max(...bucket.plays, 1);
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    const lookup: Record<
      string,
      { plays: number; label: string; date: Date }
    > = {};
    for (let i = 0; i < DAYS; i++) {
      const d = new Date(now);
      d.setDate(d.getDate() - (DAYS - 1 - i));
      lookup[d.toISOString().slice(0, 10)] = {
        plays: bucket.plays[i],
        label: bucket.labels[i],
        date: new Date(d),
      };
    }
    const rangeStart = new Date(now);
    rangeStart.setDate(rangeStart.getDate() - (DAYS - 1));
    rangeStart.setDate(rangeStart.getDate() - rangeStart.getDay());
    const rangeEnd = new Date(now);
    rangeEnd.setDate(rangeEnd.getDate() + (6 - rangeEnd.getDay()));
    const weeks: Array<Array<{ inRange: boolean; plays?: number; date?: Date }>> = [];
    const cur = new Date(rangeStart);
    while (cur <= rangeEnd) {
      if (!weeks.length || weeks[weeks.length - 1].length === 7) weeks.push([]);
      const key = cur.toISOString().slice(0, 10);
      const info = lookup[key];
      weeks[weeks.length - 1].push(info ? { ...info, inRange: true } : { inRange: false });
      cur.setDate(cur.getDate() + 1);
    }
    while (weeks[weeks.length - 1].length < 7) weeks[weeks.length - 1].push({ inRange: false });
    const visibleMonths = [
      ...new Set(
        weeks
          .flat()
          .filter((c) => c.inRange && c.date)
          .map((c) => MONTHS[c.date!.getMonth()]),
      ),
    ].join(" / ");
    return { weeks, max, visibleMonths };
  }, [data?.history, data?.activity]);

  const heatmap = useMemo(() => {
    const hist = data?.history || [];
    const grid = Array.from({ length: 7 }, () => Array(24).fill(0) as number[]);
    const sessionsByHour: HistoryEntry[][][] = Array.from({ length: 7 }, () =>
      Array.from({ length: 24 }, () => [] as HistoryEntry[]),
    );
    for (const e of hist) {
      const ts =
        e.startedAt ||
        e.stoppedAt ||
        e.date ||
        e.timestamp ||
        e.started_at ||
        e.startTime ||
        e.created_at ||
        e.time;
      if (!ts) continue;
      const d = new Date(String(ts));
      if (Number.isNaN(d.getTime())) continue;
      grid[d.getDay()][d.getHours()] += 1;
      sessionsByHour[d.getDay()][d.getHours()].push(e);
    }
    const max = Math.max(...grid.flat(), 1);
    return { grid, sessionsByHour, max };
  }, [data?.history]);

  function openSessionPopup(opts: {
    label: string;
    plays: number;
    watch: number;
    sessions: HistoryEntry[];
    context?: string;
    emptyText?: string;
  }) {
    const topSessions = opts.sessions.slice(0, 5).map((e) => ({
      title: sessionTitle(e),
      user: sessionUser(e),
      duration: fmtDuration(getDurationSeconds(e)),
    }));
    setPopup({
      label: opts.label,
      plays: opts.plays,
      watch: opts.watch,
      context: opts.context,
      emptyText: opts.emptyText,
      sessions: topSessions,
      more: Math.max(0, opts.sessions.length - topSessions.length),
    });
  }

  if (loading && !data) {
    return (
      <div className="hd-widget-body trr-body" ref={rootRef}>
        <div className="trr-shell">
          <div className="trr-header">
            <div className="trr-header-right">
              <span className="trr-status trr-status--idle">Loading</span>
            </div>
          </div>
          <div className="trr-empty">Connecting to Tracearr…</div>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="hd-widget-body trr-body" ref={rootRef}>
        <div className="trr-shell">
          <div className="trr-header">
            <div className="trr-header-right">
              <span className="trr-status trr-status--idle">Offline</span>
              <button className="trr-open-link" type="button" onClick={load}>
                Retry
              </button>
            </div>
          </div>
          <div className="trr-empty">Unable to load Tracearr data.{error ? ` ${error}` : ""}</div>
        </div>
      </div>
    );
  }

  const connectionSource: ConnectionSource = data.connectionSource || "unknown";

  return (
    <div className="hd-widget-body trr-body" ref={rootRef}>
      <ConnectionCorner source={connectionSource} />
      <div className="trr-shell">
        <div className="trr-header">
          <div className="trr-header-left">
            <div>
              <div className="trr-title">Tracearr</div>
            </div>
          </div>
          <div className="trr-header-status">
            <span className={`trr-status ${online ? "trr-status--active" : "trr-status--idle"}`}>
              {statusTxt}
            </span>
          </div>
          <div className="trr-header-right">
            {openHref ? (
              <a className="trr-open-link" href={openHref} target="_blank" rel="noopener noreferrer">
                Open
              </a>
            ) : null}
          </div>
        </div>

        <div className="trr-controls">
          <div className="trr-tabs">
            {TABS.map((item) => (
              <button
                key={item.id}
                className={`trr-tab${tab === item.id ? " trr-tab--active" : ""}`}
                type="button"
                onClick={() => {
                  setPopup(null);
                  setTab(item.id);
                }}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>

        <div className={`trr-body-content${tab === "storage" ? " is-storage" : ""}`}>
          {tab === "overview" ? (
            <>
              <div className="trr-metrics">
                {metrics.map((m) => (
                  <div className="trr-card trr-metric" key={m.label}>
                    <div className="trr-metric-value">{m.value}</div>
                    <div className="trr-metric-label">{m.label}</div>
                  </div>
                ))}
              </div>
              <div className="trr-grid trr-grid--2">
                <div className="trr-card">
                  <div className="trr-card-title">Plays Per Day — Last 5 Weeks</div>
                  <div id="trr-overview-cal" className="trr-cal-wrap">
                    <div className="trr-cal">
                      <div className="trr-cal-month-title">{calendar.visibleMonths}</div>
                      <div className="trr-cal-weekdays">
                        {DOW.map((d, i) => (
                          <div className="trr-cal-dow-item" key={`${d}-${i}`}>
                            {d}
                          </div>
                        ))}
                      </div>
                      <div className="trr-cal-body">
                        <div className="trr-cal-scroll">
                          <div className="trr-cal-grid">
                            {calendar.weeks.map((week, wi) => (
                              <div className="trr-cal-week" key={wi}>
                                {week.map((cell, ci) =>
                                  cell.inRange && cell.date ? (
                                    <button
                                      key={ci}
                                      type="button"
                                      className="trr-cal-cell"
                                      style={{
                                        background: cellColor(cell.plays || 0, calendar.max),
                                        color: textColor(cell.plays || 0, calendar.max),
                                      }}
                                      title={`${cell.date.toLocaleDateString("en-US", { month: "short", day: "numeric" })}: ${cell.plays || 0} play${cell.plays !== 1 ? "s" : ""}`}
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        const key = cell.date!.toISOString().slice(0, 10);
                                        const sessions = sessionsForDay(data.history, key);
                                        const watchMins = Math.round(
                                          sessions.reduce((sum, s) => sum + getDurationSeconds(s), 0) /
                                            60,
                                        );
                                        openSessionPopup({
                                          label: cell.date!.toLocaleDateString("en-US", {
                                            weekday: "long",
                                            month: "long",
                                            day: "numeric",
                                          }),
                                          plays: cell.plays || 0,
                                          watch: watchMins,
                                          sessions,
                                          emptyText: "No session details for this day.",
                                        });
                                      }}
                                    >
                                      {cell.date.getDate()}
                                    </button>
                                  ) : (
                                    <div className="trr-cal-cell trr-cal-cell--void" key={ci} />
                                  ),
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="trr-cal-legend">
                        <span>Less</span>
                        {[0.05, 0.22, 0.46, 0.7, 0.92].map((a) => (
                          <div
                            className="trr-cal-swatch"
                            key={a}
                            style={{ background: `rgba(34,211,238,${a})` }}
                          />
                        ))}
                        <span>More</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="trr-card">
                  <div className="trr-card-title">Watch Time Per Day (min)</div>
                  <div className="trr-chart-wrap" style={{ position: "relative" }}>
                    <canvas id="trr-overview-watchtime" ref={watchRef} />
                    {!hasDuration ? (
                      <div className="trr-no-data">
                        <span>Duration not reported by server</span>
                      </div>
                    ) : null}
                  </div>
                </div>
              </div>
              <div className="trr-card trr-concurrent-card">
                <div className="trr-card-heading-title">Concurrent Streams</div>
                <div className="trr-chart-wrap">
                  <canvas id="trr-overview-concurrent" ref={concurrentRef} />
                </div>
              </div>
            </>
          ) : null}

          {tab === "watch" ? (
            <div className="trr-card trr-most-watched-card">
              <div className="trr-mw-header">
                <div className="trr-card-heading-title">Most Watched</div>
                <div className="trr-mw-range" ref={watchRangeRef}>
                  <button
                    type="button"
                    className={`trr-mw-range-btn${watchRangeOpen ? " is-open" : ""}`}
                    aria-haspopup="listbox"
                    aria-expanded={watchRangeOpen}
                    onClick={() => setWatchRangeOpen((open) => !open)}
                  >
                    <span>
                      {MOST_WATCHED_RANGES.find((opt) => opt.value === watchRange)?.label ||
                        "Last 30 Days"}
                    </span>
                    <svg viewBox="0 0 12 8" aria-hidden="true" className="trr-mw-range-caret">
                      <path
                        d="M1.5 1.75 6 6.25l4.5-4.5"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.6"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </button>
                  {watchRangeOpen ? (
                    <div className="trr-mw-range-menu" role="listbox" aria-label="Time range">
                      {MOST_WATCHED_RANGES.map((opt) => (
                        <button
                          key={opt.value}
                          type="button"
                          role="option"
                          aria-selected={watchRange === opt.value}
                          className={`trr-mw-range-option${watchRange === opt.value ? " is-active" : ""}`}
                          onClick={() => {
                            setWatchRange(opt.value);
                            setWatchPage(1);
                            setWatchRangeOpen(false);
                          }}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  ) : null}
                </div>
              </div>

              <div className="trr-mw-kinds">
                <button
                  type="button"
                  className={`trr-mw-kind${watchKind === "movie" ? " is-active" : ""}`}
                  onClick={() => {
                    setWatchKind("movie");
                    setWatchPage(1);
                  }}
                >
                  <svg viewBox="0 0 24 24" aria-hidden="true" className="trr-mw-kind-icon">
                    <path
                      fill="currentColor"
                      d="M18 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2Zm0 2v2.5l-1.5-1-1.5 1V6h3ZM6 6h3v2.5L7.5 7.5 6 8.5V6Zm0 12v-2.5l1.5 1 1.5-1V18H6Zm12 0h-3v-2.5l1.5 1 1.5-1V18Z"
                    />
                  </svg>
                  Movies ({mostWatchedMovies.length})
                </button>
                <button
                  type="button"
                  className={`trr-mw-kind${watchKind === "show" ? " is-active" : ""}`}
                  onClick={() => {
                    setWatchKind("show");
                    setWatchPage(1);
                  }}
                >
                  <svg viewBox="0 0 24 24" aria-hidden="true" className="trr-mw-kind-icon">
                    <path
                      fill="currentColor"
                      d="M4 5h16a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-5l2 2v1H7v-1l2-2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2Zm0 2v9h16V7H4Z"
                    />
                  </svg>
                  TV Shows ({mostWatchedShows.length})
                </button>
              </div>

              {mostWatched.length ? (
                <>
                  <div className="trr-mw-table-wrap">
                    <div className="trr-mw-table">
                      <div className="trr-mw-head">
                        <span>Title</span>
                        <button type="button" onClick={() => toggleWatchSort("plays")}>
                          Plays <em>{sortMark("plays")}</em>
                        </button>
                        <button type="button" onClick={() => toggleWatchSort("watchHours")}>
                          Watch Hours <em>{sortMark("watchHours")}</em>
                        </button>
                        <button type="button" onClick={() => toggleWatchSort("viewers")}>
                          Viewers <em>{sortMark("viewers")}</em>
                        </button>
                        <button type="button" onClick={() => toggleWatchSort("completion")}>
                          Completion <em>{sortMark("completion")}</em>
                        </button>
                      </div>
                      {mostWatchedPage.map((row) => (
                        <div className="trr-mw-row" key={row.id}>
                          <div className="trr-mw-title">
                            <span className={`trr-mw-badge is-${row.kind}`}>
                              {row.kind === "movie" ? "Movie" : "Show"}
                            </span>
                            <span className="trr-mw-title-text">
                              {row.title}
                              {row.year ? ` (${row.year})` : ""}
                            </span>
                          </div>
                          <div className="trr-mw-num">{row.plays}</div>
                          <div className="trr-mw-num">{row.watchHours.toFixed(1)}</div>
                          <div className="trr-mw-num">{row.viewers}</div>
                          <div className="trr-mw-completion">
                            <span
                              className={`trr-mw-pill${row.completion >= 100 ? " is-complete" : ""}`}
                            >
                              {row.completion}%
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="trr-mw-footer">
                    <div className="trr-mw-page-label">
                      Page {watchPageSafe} of {watchPageCount}
                    </div>
                    <div className="trr-mw-pager">
                      <button
                        type="button"
                        className="trr-mw-page-btn"
                        disabled={watchPageSafe <= 1}
                        onClick={() => setWatchPage((p) => Math.max(1, p - 1))}
                      >
                        Previous
                      </button>
                      <button
                        type="button"
                        className="trr-mw-page-btn"
                        disabled={watchPageSafe >= watchPageCount}
                        onClick={() => setWatchPage((p) => Math.min(watchPageCount, p + 1))}
                      >
                        Next
                      </button>
                    </div>
                  </div>
                </>
              ) : (
                <div className="trr-empty">No watch data for this range</div>
              )}
            </div>
          ) : null}

          {tab === "history" ? (
            <>
              <div className="trr-toolbar">
                <div className="trr-toggle-group">
                  {[7, 30].map((range) => (
                    <button
                      key={range}
                      className={`trr-toggle${histRange === range ? " is-active" : ""}`}
                      type="button"
                      onClick={() => setHistRange(range)}
                    >
                      {range} days
                    </button>
                  ))}
                </div>
                <div className="trr-toggle-group">
                  <button
                    className={`trr-toggle${histMetric === "plays" ? " is-active" : ""}`}
                    type="button"
                    onClick={() => setHistMetric("plays")}
                  >
                    Plays
                  </button>
                  <button
                    className={`trr-toggle${histMetric === "watchTime" ? " is-active" : ""}`}
                    type="button"
                    onClick={() => setHistMetric("watchTime")}
                  >
                    Watch Time
                  </button>
                </div>
              </div>
              <div className="trr-grid">
                <div className="trr-card">
                  <div className="trr-card-title">
                    {histMetric === "plays"
                      ? `Plays Over Time (${histRange}D)`
                      : `Watch Time Over Time (${histRange}D)`}
                  </div>
                  <div className="trr-chart-wrap">
                    <canvas id="trr-history-main" ref={historyMainRef} />
                  </div>
                </div>
                <div className="trr-card trr-bw-card">
                  <div className="trr-card-heading">
                    <div className="trr-card-heading-title">Daily Bandwidth Usage</div>
                    <div className="trr-card-heading-sub">
                      Average bitrate and session count over time
                    </div>
                  </div>
                  <div className="trr-chart-wrap">
                    <canvas id="trr-bw-chart" ref={bandwidthRef} />
                  </div>
                </div>
              </div>
            </>
          ) : null}

          {tab === "users" ? (
            <div className="trr-grid trr-grid--2">
              <div className="trr-card">
                <div className="trr-card-title">Top Users by Play Count</div>
                <div className="trr-chart-wrap">
                  <canvas id="trr-users-chart" ref={usersRef} />
                </div>
              </div>
              <div className="trr-card">
                <div className="trr-card-title">User Watch Time</div>
                <div className="trr-list">
                  {topUsers.length ? (
                    topUsers.map((u) => (
                      <div className="trr-list-row" key={u.uid}>
                        <div className="trr-list-main">
                          <div className="trr-list-title">{u.name}</div>
                          <div className="trr-list-sub">{u.plays} plays</div>
                        </div>
                        <div className="trr-list-side">{fmtDuration(u.duration)}</div>
                      </div>
                    ))
                  ) : (
                    <div className="trr-empty">No user data</div>
                  )}
                </div>
              </div>
            </div>
          ) : null}

          {tab === "devices" ? (
            <div className="trr-devices-stack">
              <div className="trr-grid trr-grid--2 trr-grid--devices">
                <div className="trr-card trr-device-health-card">
                  <div className="trr-card-heading">
                    <div className="trr-card-heading-title">Device Health</div>
                    <div className="trr-card-heading-sub">Direct play rate by device type</div>
                  </div>
                  {deviceHealth.length ? (
                    <div className="trr-device-health">
                      {deviceHealth.map((row) => {
                        const warn = row.directPlayRate < 80;
                        return (
                          <div className="trr-device-health-row" key={row.name}>
                            <div className="trr-device-health-meta">
                              <span className="trr-device-health-name">{row.name}</span>
                              <span className="trr-device-health-stats">
                                <span className="trr-device-health-sessions">
                                  {row.sessions} session{row.sessions === 1 ? "" : "s"}
                                </span>
                                <span
                                  className={`trr-device-health-pct${warn ? " is-warn" : ""}`}
                                >
                                  {row.directPlayRate.toFixed(1)}%
                                </span>
                              </span>
                            </div>
                            <div className="trr-bar">
                              <span
                                style={{
                                  width: `${Math.min(100, Math.max(0, row.directPlayRate))}%`,
                                  background: warn
                                    ? "rgba(251,146,60,0.95)"
                                    : "rgba(52,211,153,0.95)",
                                }}
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="trr-empty">No device data</div>
                  )}
                </div>

                <div className="trr-card trr-hotspots-card">
                  <div className="trr-card-heading">
                    <div className="trr-card-heading-title">Transcode Hotspots</div>
                    <div className="trr-card-heading-sub">
                      Combinations causing the most transcodes
                    </div>
                  </div>
                  {transcodeHotspots.length ? (
                    <div className="trr-hotspots">
                      <div className="trr-hotspots-head">
                        <span>Device + Codec</span>
                        <span>Transcodes</span>
                        <span>% of Total</span>
                      </div>
                      {transcodeHotspots.map((row) => (
                        <div className="trr-hotspots-row" key={`${row.device}|${row.codec}`}>
                          <div className="trr-hotspots-device">
                            <div className="trr-hotspots-device-name">{row.device}</div>
                            <div className="trr-hotspots-device-codec">{row.codec}</div>
                          </div>
                          <div className="trr-hotspots-count">{row.transcodes}</div>
                          <div className="trr-hotspots-pct">
                            <span className="trr-hotspots-pill">{row.percentOfTotal}%</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="trr-empty">No transcode data</div>
                  )}
                </div>
              </div>

              <div className="trr-card trr-compat-card">
                <div className="trr-card-heading">
                  <div className="trr-card-heading-title">Compatibility Matrix</div>
                  <div className="trr-card-heading-sub">
                    Direct play rates by device and video codec. Sorted by session volume.
                  </div>
                </div>
                {compatMatrix.length ? (
                  <>
                    <div className="trr-compat">
                      <div className="trr-compat-head">
                        <span>Device</span>
                        {COMPAT_CODECS.map((codec) => (
                          <span key={codec}>{codec}</span>
                        ))}
                      </div>
                      {compatMatrix.map((row) => (
                        <div className="trr-compat-row" key={row.device}>
                          <div className="trr-compat-device">
                            <div className="trr-compat-device-name">{row.device}</div>
                            <div className="trr-compat-device-sub">
                              {row.sessions} session{row.sessions === 1 ? "" : "s"}
                            </div>
                          </div>
                          {COMPAT_CODECS.map((codec) => {
                            const cell = row.cells[codec];
                            if (!cell) {
                              return (
                                <div className="trr-compat-cell is-empty" key={codec}>
                                  —
                                </div>
                              );
                            }
                            return (
                              <div
                                className={`trr-compat-cell is-${compatTone(cell.directPlayRate)}`}
                                key={codec}
                              >
                                <div className="trr-compat-pct">
                                  {cell.directPlayRate.toFixed(1)}%
                                </div>
                                <div className="trr-compat-count">{cell.sessions}</div>
                              </div>
                            );
                          })}
                        </div>
                      ))}
                    </div>
                    <div className="trr-compat-legend">
                      <span className="trr-compat-legend-label">Legend:</span>
                      <span className="trr-compat-swatch is-good">≥80% Direct</span>
                      <span className="trr-compat-swatch is-mid">50–79%</span>
                      <span className="trr-compat-swatch is-bad">&lt;50%</span>
                    </div>
                  </>
                ) : (
                  <div className="trr-empty">No compatibility data</div>
                )}
              </div>
            </div>
          ) : null}

          {tab === "storage" ? (
            <div className="trr-storage-stack">
              {storageError || !storageAvailable ? (
                <div className="trr-storage-note">
                  {storageError
                    ? storageError
                    : data?.libraryAuthConfigured
                      ? "Storage login failed — use the same email/password you use to sign in to Tracearr."
                    : "Storage needs a Tracearr account session (not the public API key). Add your Tracearr email and password in widget settings."}
                </div>
              ) : null}

              <div className="trr-storage-metrics">
                <div className="trr-storage-metric">
                  <div className="trr-storage-metric-icon" aria-hidden="true">
                    <svg viewBox="0 0 24 24">
                      <path
                        fill="currentColor"
                        d="M4 6h16a2 2 0 0 1 2 2v2H2V8a2 2 0 0 1 2-2Zm-2 6h20v4a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-4Zm4 2.25a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5Z"
                      />
                    </svg>
                  </div>
                  <div className="trr-storage-metric-value">
                    {storageAvailable ? fmtBytes(totalStorageBytes, 0) : "—"}
                  </div>
                  <div className="trr-storage-metric-label">Total Storage</div>
                </div>
                <div className="trr-storage-metric">
                  <div className="trr-storage-metric-icon" aria-hidden="true">
                    <svg viewBox="0 0 24 24">
                      <path
                        fill="currentColor"
                        d="M3 17.25 9.75 10.5l4 4L21 6.75V10h2V4h-6v2h3.25L13.75 12.5l-4-4L1 16.25l2 1Z"
                      />
                    </svg>
                  </div>
                  <div className="trr-storage-metric-value">
                    {storageAvailable ? `${fmtBytesSigned(growthPerMonth)}/mo` : "—"}
                  </div>
                  <div className="trr-storage-metric-label">Growth Rate</div>
                </div>
                <div className="trr-storage-metric">
                  <div className="trr-storage-metric-icon" aria-hidden="true">
                    <svg viewBox="0 0 24 24">
                      <path
                        fill="currentColor"
                        d="M7 5h10a2 2 0 0 1 2 2v1H5V7a2 2 0 0 1 2-2Zm-2 5h14v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7Zm3 2v2h8v-2H8Z"
                      />
                    </svg>
                  </div>
                  <div className="trr-storage-metric-value">
                    {storageAvailable ? `${dupGroups} groups` : "—"}
                  </div>
                  <div className="trr-storage-metric-label">
                    Duplicates ({storageAvailable ? `${fmtBytes(dupSavings)} recoverable` : "—"})
                  </div>
                </div>
                <div className="trr-storage-metric">
                  <div className="trr-storage-metric-icon" aria-hidden="true">
                    <svg viewBox="0 0 24 24">
                      <path
                        fill="currentColor"
                        d="M9 3h6l1 2h4v2H4V5h4l1-2Zm-4 6h14l-1.2 11.2A2 2 0 0 1 15.81 22H8.19a2 2 0 0 1-1.99-1.8L5 9Z"
                      />
                    </svg>
                  </div>
                  <div className="trr-storage-metric-value">
                    {storageAvailable ? `${staleTotalItems} items` : "—"}
                  </div>
                  <div className="trr-storage-metric-label">
                    Stale Content ({storageAvailable ? `${fmtBytes(staleTotalBytes)} unused` : "—"})
                  </div>
                </div>
              </div>

              <div className="trr-card trr-storage-trend-card">
                <div className="trr-storage-trend-header">
                  <div className="trr-storage-trend-title-row">
                    <div className="trr-card-heading-title">Storage Trend</div>
                    {confidence ? (
                      <span className={`trr-storage-confidence is-${confidence}`}>
                        {confidence.charAt(0).toUpperCase() + confidence.slice(1)} Confidence
                      </span>
                    ) : null}
                  </div>
                  <div className="trr-storage-trend-controls">
                    <label className="trr-storage-pred-toggle">
                      <input
                        type="checkbox"
                        checked={storagePredictions}
                        onChange={(e) => setStoragePredictions(e.target.checked)}
                      />
                      <span className="trr-storage-switch" aria-hidden="true" />
                      <span>Predictions</span>
                    </label>
                    <div className="trr-toggle-group">
                      {STORAGE_PERIODS.map((p) => (
                        <button
                          key={p.id}
                          type="button"
                          className={`trr-toggle${storagePeriod === p.id ? " is-active" : ""}`}
                          onClick={() => setStoragePeriod(p.id)}
                        >
                          {p.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="trr-chart-wrap">
                  <canvas id="trr-storage-chart" ref={storageRef} />
                  {!storageData?.history?.length ? (
                    <div className="trr-no-data">
                      <span>No storage trend data</span>
                    </div>
                  ) : null}
                </div>
              </div>

              <div className="trr-card trr-stale-card">
                <div className="trr-card-heading">
                  <div className="trr-card-heading-title">Stale Content</div>
                  <div className="trr-card-heading-sub">
                    Content that may be candidates for removal.
                  </div>
                </div>

                <div className="trr-stale-toolbar">
                  <div className="trr-mw-kinds">
                    <button
                      type="button"
                      className={`trr-mw-kind${staleCat === "never_watched" ? " is-active" : ""}`}
                      onClick={() => {
                        setStaleCat("never_watched");
                        setStalePage(1);
                      }}
                    >
                      Never Watched ({neverCount})
                    </button>
                    <button
                      type="button"
                      className={`trr-mw-kind${staleCat === "stale" ? " is-active" : ""}`}
                      onClick={() => {
                        setStaleCat("stale");
                        setStalePage(1);
                      }}
                    >
                      Stale Content ({staleCount})
                    </button>
                  </div>

                  <div className="trr-stale-filters">
                    <div className="trr-mw-range" ref={staleMediaRef}>
                      <button
                        type="button"
                        className={`trr-mw-range-btn${staleMediaOpen ? " is-open" : ""}`}
                        aria-haspopup="listbox"
                        aria-expanded={staleMediaOpen}
                        onClick={() => setStaleMediaOpen((o) => !o)}
                      >
                        <span>
                          {staleMediaFilter === "all"
                            ? "All Types"
                            : staleMediaFilter === "movie"
                              ? "Movies"
                              : staleMediaFilter === "show"
                                ? "TV Shows"
                                : "Music"}
                        </span>
                        <svg viewBox="0 0 12 8" aria-hidden="true" className="trr-mw-range-caret">
                          <path
                            d="M1.5 1.75 6 6.25l4.5-4.5"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="1.6"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                      </button>
                      {staleMediaOpen ? (
                        <div className="trr-mw-range-menu" role="listbox">
                          {(
                            [
                              ["all", "All Types"],
                              ["movie", "Movies"],
                              ["show", "TV Shows"],
                              ["music", "Music"],
                            ] as const
                          ).map(([value, label]) => (
                            <button
                              key={value}
                              type="button"
                              role="option"
                              aria-selected={staleMediaFilter === value}
                              className={`trr-mw-range-option${staleMediaFilter === value ? " is-active" : ""}`}
                              onClick={() => {
                                setStaleMediaFilter(value);
                                setStalePage(1);
                                setStaleMediaOpen(false);
                              }}
                            >
                              {label}
                            </button>
                          ))}
                        </div>
                      ) : null}
                    </div>
                  </div>
                </div>

                {staleSource.length ? (
                  <>
                    <div className="trr-stale-table-wrap">
                      <div className="trr-stale-table">
                        <div className="trr-stale-head">
                          <span>Type</span>
                          <button type="button" onClick={() => toggleStaleSort("title")}>
                            Title <em>{staleSortMark("title")}</em>
                          </button>
                          <span>Server</span>
                          <button type="button" onClick={() => toggleStaleSort("size")}>
                            Size <em>{staleSortMark("size")}</em>
                          </button>
                          <button type="button" onClick={() => toggleStaleSort("added")}>
                            Added <em>{staleSortMark("added")}</em>
                          </button>
                          <button type="button" onClick={() => toggleStaleSort("staleFor")}>
                            Stale For <em>{staleSortMark("staleFor")}</em>
                          </button>
                          <span>Quality</span>
                        </div>
                        {stalePageRows.map((row) => {
                          const kind = mediaTypeLabel(row.mediaType);
                            return (
                            <div className="trr-stale-row" key={row.id}>
                              <div className="trr-stale-type">
                                <span className={`trr-stale-type-badge is-${kind.toLowerCase()}`}>
                                  {kind === "Movie"
                                    ? "Movie"
                                    : kind === "TV"
                                      ? "TV"
                                      : kind === "Music"
                                        ? "Music"
                                        : "•"}
                                </span>
                              </div>
                              <div className="trr-stale-title">
                                {row.title}
                                {row.year ? ` (${row.year})` : ""}
                              </div>
                              <div className="trr-stale-server">
                                <span className="trr-stale-server-pill">{row.serverName}</span>
                              </div>
                              <div className="trr-stale-num">{fmtBytes(row.fileSize)}</div>
                              <div className="trr-stale-num is-muted">{relativeAgo(row.addedAt)}</div>
                              <div className="trr-stale-stale">
                                <span className="trr-stale-pill">{fmtDaysStale(row.daysStale)}</span>
                              </div>
                              <div className="trr-stale-num is-muted">
                                {fmtResolution(row.resolution)}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                    <div className="trr-mw-footer">
                      <div className="trr-mw-page-label">
                        Page {stalePageSafe} of {stalePageCount}
                      </div>
                      <div className="trr-mw-pager">
                        <button
                          type="button"
                          className="trr-mw-page-btn"
                          disabled={stalePageSafe <= 1}
                          onClick={() => setStalePage((p) => Math.max(1, p - 1))}
                        >
                          Previous
                        </button>
                        <button
                          type="button"
                          className="trr-mw-page-btn"
                          disabled={stalePageSafe >= stalePageCount}
                          onClick={() => setStalePage((p) => Math.min(stalePageCount, p + 1))}
                        >
                          Next
                        </button>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="trr-empty">No stale content for this filter</div>
                )}
              </div>
            </div>
          ) : null}

          {tab === "libraries" ? (
            <div className="trr-grid trr-grid--2">
              <div className="trr-card">
                <div className="trr-card-title">Most-Watched Libraries</div>
                <div className="trr-chart-wrap">
                  <canvas id="trr-libraries-chart" ref={librariesRef} />
                </div>
              </div>
              <div className="trr-card">
                <div className="trr-card-title">Library Totals</div>
                <div className="trr-list">
                  {libraries.length ? (
                    libraries.map((l, i) => (
                      <div className="trr-list-row" key={l.name}>
                        <div className="trr-list-main">
                          <div className="trr-list-title">{l.name}</div>
                          <div className="trr-bar">
                            <span
                              style={{
                                width: `${Math.max(
                                  6,
                                  Math.round(
                                    (l.count / Math.max(...libraries.map((x) => x.count), 1)) * 100,
                                  ),
                                )}%`,
                                background: CHART_PALETTE[i % CHART_PALETTE.length][0],
                              }}
                            />
                          </div>
                        </div>
                        <div className="trr-list-side">{l.count}</div>
                      </div>
                    ))
                  ) : (
                    <div className="trr-empty">No library data</div>
                  )}
                </div>
              </div>
            </div>
          ) : null}

          {tab === "heatmap" ? (
            <div className="trr-card">
              <div className="trr-card-title">Peak Hours Heatmap</div>
              <div id="trr-heatmap" className="trr-heatmap">
                <div className="trr-heatmap-grid">
                  <div className="trr-heatmap-corner" />
                  {Array.from({ length: 24 }, (_, h) => (
                    <div className="trr-heatmap-hour" key={h}>
                      {h}
                    </div>
                  ))}
                  {heatmap.grid.map((row, dayIdx) => [
                    <div className="trr-heatmap-day" key={`day-${HEAT_DAYS[dayIdx]}`}>
                      {HEAT_DAYS[dayIdx]}
                    </div>,
                    ...row.map((v, hour) => {
                      const a = v === 0 ? 0.06 : 0.12 + (v / heatmap.max) * 0.88;
                      const sessions = heatmap.sessionsByHour[dayIdx][hour];
                      const watchMins = Math.round(
                        sessions.reduce((sum, s) => sum + getDurationSeconds(s), 0) / 60,
                      );
                      const label = `${HEAT_DAYS[dayIdx]} ${hourLabel(hour)}`;
                      return (
                        <button
                          key={`${dayIdx}-${hour}`}
                          type="button"
                          className="trr-heatmap-cell"
                          title={`${label} • ${v} play${v === 1 ? "" : "s"}`}
                          style={{ background: `rgba(34,211,238,${a})` }}
                          onClick={(e) => {
                            e.stopPropagation();
                            openSessionPopup({
                              label,
                              plays: v,
                              watch: watchMins,
                              sessions,
                              context: activityLabel(v, heatmap.max),
                              emptyText: "No session details for this hour.",
                            });
                          }}
                        />
                      );
                    }),
                  ])}
                </div>
              </div>
            </div>
          ) : null}
        </div>

        {error ? <div className="trr-footer">Degraded connection</div> : null}
      </div>

      {popup && typeof document !== "undefined"
        ? createPortal(
            <div
              className="trr-cal-popup trr-cal-popup--center"
              role="dialog"
              aria-label={popup.label}
            >
              <div className="trr-cal-popup__head">
                <div>
                  <div className="trr-cal-popup__date">{popup.label}</div>
                  <div className="trr-cal-popup__sub">
                    {popup.plays} play{popup.plays === 1 ? "" : "s"} · {popup.watch} min watched
                    {popup.context ? ` · ${popup.context}` : ""}
                  </div>
                </div>
                <button
                  type="button"
                  className="trr-cal-popup__close"
                  aria-label="Close"
                  onClick={() => setPopup(null)}
                >
                  ×
                </button>
              </div>
              <div className="trr-cal-popup__list">
                {popup.sessions.length ? (
                  popup.sessions.map((item, i) => (
                    <div className="trr-cal-popup__row" key={`${item.title}-${i}`}>
                      <div className="trr-cal-popup__main">
                        <div className="trr-cal-popup__title">{item.title}</div>
                        <div className="trr-cal-popup__meta">
                          {[item.user, item.duration].filter(Boolean).join(" · ")}
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="trr-cal-popup__empty">
                    {popup.emptyText || "No session details for this day."}
                  </div>
                )}
                {popup.more ? (
                  <div className="trr-cal-popup__more">
                    +{popup.more} more session{popup.more === 1 ? "" : "s"}
                  </div>
                ) : null}
              </div>
            </div>,
            document.body,
          )
        : null}
    </div>
  );
}
