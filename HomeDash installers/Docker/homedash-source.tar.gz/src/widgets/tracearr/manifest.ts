import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "tracearr",
  name: "Tracearr",
  description: "Playback analytics overview",
  version: "0.2.6",
  category: "Media",
  defaultSize: { w: 6, h: 8, minW: 3, minH: 5 },
  hostClass: "trr-host",
  configFields: [
    { key: "baseUrl", label: "Private - IP", type: "url", placeholder: "http://10.0.0.1" },
    { key: "fallbackUrl", label: "Fallback Public URL", type: "url", placeholder: "https://tracearr.example.com" },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url", placeholder: "http://10.0.0.1" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    { key: "apiKey", label: "Public API Key", type: "password", placeholder: "trr_pub_…" },
    {
      key: "email",
      label: "Tracearr Login Email (Storage)",
      type: "text",
      placeholder: "admin@example.com",
    },
    {
      key: "password",
      label: "Tracearr Login Password (Storage)",
      type: "password",
      placeholder: "Your Tracearr web-login password",
    },
  ],
};
