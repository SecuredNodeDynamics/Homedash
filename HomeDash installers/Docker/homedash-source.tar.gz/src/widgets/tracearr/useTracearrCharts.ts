"use client";

import { useEffect, useRef } from "react";
import type { Chart, ChartConfiguration } from "chart.js";
import {
  CHART_COLORS,
  CHART_PALETTE,
  buildStorageTrend,
  getConcurrentStreams,
  getDailyBandwidth,
  getHistoryPlays,
  getLibraries,
  getTopUsers,
  type DayBucket,
  type StoragePayload,
  type StoragePeriod,
} from "@/lib/widgets/tracearr-data";

type ChartJsModule = typeof import("chart.js");

let chartPromise: Promise<ChartJsModule> | null = null;

function loadChartJs() {
  if (!chartPromise) {
    chartPromise = import("chart.js").then((mod) => {
      const { Chart, LineController, BarController, CategoryScale, LinearScale, PointElement, LineElement, BarElement, Filler, Tooltip, Legend } = mod;
      Chart.register(
        LineController,
        BarController,
        CategoryScale,
        LinearScale,
        PointElement,
        LineElement,
        BarElement,
        Filler,
        Tooltip,
        Legend,
      );
      return mod;
    });
  }
  return chartPromise;
}

function baseOpts(extra: Record<string, unknown> = {}) {
  return {
    responsive: true,
    maintainAspectRatio: false,
    animation: { duration: 600, easing: "easeOutQuart" as const },
    layout: { padding: { top: 4, right: 0, bottom: 10, left: 0 } },
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: "rgba(12,16,22,0.96)",
        borderColor: "rgba(255,255,255,0.12)",
        borderWidth: 1,
        titleColor: "rgba(255,255,255,0.85)",
        bodyColor: "rgba(255,255,255,0.65)",
        padding: 10,
        cornerRadius: 8,
      },
      ...(extra.plugins as object | undefined),
    },
    scales: {
      x: {
        grid: { color: "rgba(255,255,255,0.05)", drawTicks: false },
        ticks: {
          color: "rgba(255,255,255,0.30)",
          font: { size: 10 },
          maxRotation: 45,
          autoSkip: true,
          maxTicksLimit: 14,
          padding: 8,
        },
        border: { color: "rgba(255,255,255,0.08)" },
      },
      y: {
        grid: { color: "rgba(255,255,255,0.05)", drawTicks: false },
        ticks: { color: "rgba(255,255,255,0.30)", font: { size: 10 } },
        border: { color: "transparent" },
        beginAtZero: true,
      },
      ...(extra.scales as object | undefined),
    },
    ...Object.fromEntries(Object.entries(extra).filter(([k]) => k !== "plugins" && k !== "scales")),
  };
}

export type TracearrTab =
  | "overview"
  | "watch"
  | "history"
  | "users"
  | "devices"
  | "storage"
  | "libraries"
  | "heatmap";

type ChartInputs = {
  tab: TracearrTab;
  histRange: number;
  histMetric: "plays" | "watchTime";
  history: unknown;
  activity: Record<string, unknown>;
  users: unknown;
  storage: StoragePayload | null;
  storagePeriod: StoragePeriod;
  storagePredictions: boolean;
  watchCanvas: HTMLCanvasElement | null;
  concurrentCanvas: HTMLCanvasElement | null;
  historyMainCanvas: HTMLCanvasElement | null;
  bandwidthCanvas: HTMLCanvasElement | null;
  storageCanvas: HTMLCanvasElement | null;
  usersCanvas: HTMLCanvasElement | null;
  librariesCanvas: HTMLCanvasElement | null;
};

export function useTracearrCharts(inputs: ChartInputs) {
  const chartsRef = useRef<Record<string, Chart>>({});

  useEffect(() => {
    let cancelled = false;
    const charts = chartsRef.current;

    function destroyAll() {
      for (const key of Object.keys(charts)) {
        charts[key]?.destroy();
        delete charts[key];
      }
    }

    async function mount() {
      destroyAll();
      if (inputs.tab === "heatmap" || inputs.tab === "watch") return;

      const { Chart } = await loadChartJs();
      if (cancelled) return;

      const make = (key: string, canvas: HTMLCanvasElement | null, config: ChartConfiguration | Record<string, unknown>) => {
        if (!canvas || cancelled) return;
        charts[key] = new Chart(canvas, config as ChartConfiguration);
      };

      if (inputs.tab === "overview") {
        if (inputs.watchCanvas) {
          const watch30 = getHistoryPlays(inputs.history, inputs.activity, 30);
          const hasDuration = watch30.duration.some((v) => v > 0);
          make("overviewWatch", inputs.watchCanvas, {
            type: "line",
            data: {
              labels: watch30.labels,
              datasets: [
                {
                  data: watch30.duration,
                  borderColor: CHART_COLORS.green[0],
                  backgroundColor: CHART_COLORS.green[1],
                  fill: true,
                  tension: 0.35,
                  pointRadius: hasDuration ? 2 : 0,
                  pointHoverRadius: hasDuration ? 5 : 0,
                  borderWidth: hasDuration ? 1.8 : 1,
                },
              ],
            },
            options: {
              ...baseOpts(),
              plugins: {
                ...baseOpts().plugins,
                tooltip: {
                  ...baseOpts().plugins.tooltip,
                  callbacks: {
                    label: (ctx) => {
                      const v = Number(ctx.parsed.y) || 0;
                      return v >= 60 ? `${Math.floor(v / 60)}h ${v % 60}m` : `${v}m`;
                    },
                  },
                },
              },
            },
          });
        }

        if (inputs.concurrentCanvas) {
          const conc = getConcurrentStreams(inputs.activity);
          make("overviewConcurrent", inputs.concurrentCanvas, {
            type: "line",
            data: {
              labels: conc.labels,
              datasets: [
                {
                  label: "Direct Play",
                  data: conc.direct,
                  borderColor: "rgba(125,211,252,0.95)",
                  backgroundColor: "rgba(125,211,252,0.22)",
                  fill: true,
                  tension: 0.3,
                  pointRadius: 0,
                  pointHoverRadius: 4,
                  borderWidth: 2,
                },
                {
                  label: "Direct Stream",
                  data: conc.directStream,
                  borderColor: "rgba(37,99,235,0.95)",
                  backgroundColor: "rgba(37,99,235,0.16)",
                  fill: true,
                  tension: 0.3,
                  pointRadius: 0,
                  pointHoverRadius: 4,
                  borderWidth: 2,
                },
                {
                  label: "Transcode",
                  data: conc.transcode,
                  borderColor: "rgba(251,191,36,0.95)",
                  backgroundColor: "rgba(251,191,36,0.18)",
                  fill: true,
                  tension: 0.3,
                  pointRadius: 0,
                  pointHoverRadius: 4,
                  borderWidth: 2,
                },
              ],
            },
            options: {
              responsive: true,
              maintainAspectRatio: false,
              animation: { duration: 600, easing: "easeOutQuart" as const },
              interaction: { mode: "index" as const, intersect: false },
              layout: { padding: { top: 4, right: 4, bottom: 4, left: 0 } },
              plugins: {
                legend: {
                  display: true,
                  position: "top",
                  align: "end",
                  labels: {
                    color: "rgba(255,255,255,0.50)",
                    usePointStyle: true,
                    pointStyle: "line",
                    boxWidth: 12,
                    boxHeight: 2,
                    padding: 14,
                    font: { size: 11 },
                  },
                },
                tooltip: {
                  backgroundColor: "rgba(12,16,22,0.96)",
                  borderColor: "rgba(255,255,255,0.12)",
                  borderWidth: 1,
                  titleColor: "rgba(255,255,255,0.85)",
                  bodyColor: "rgba(255,255,255,0.65)",
                  padding: 10,
                  cornerRadius: 8,
                },
              },
              scales: {
                x: {
                  grid: { display: false },
                  ticks: {
                    color: "rgba(255,255,255,0.30)",
                    font: { size: 10 },
                    maxRotation: 0,
                    autoSkip: true,
                    maxTicksLimit: 6,
                  },
                  border: { color: "rgba(255,255,255,0.08)" },
                },
                y: {
                  beginAtZero: true,
                  grace: "5%",
                  ticks: {
                    color: "rgba(255,255,255,0.30)",
                    font: { size: 10 },
                    precision: 0,
                    stepSize: 1,
                  },
                  grid: { color: "rgba(255,255,255,0.05)", drawTicks: false },
                  border: { color: "transparent" },
                },
              },
            },
          });
        }
      }

      if (inputs.tab === "history") {
        const hist = getHistoryPlays(inputs.history, inputs.activity, inputs.histRange);
        const playsMode = inputs.histMetric === "plays";
        make("historyMain", inputs.historyMainCanvas, {
          type: playsMode ? "bar" : "line",
          data: {
            labels: hist.labels,
            datasets: [
              {
                data: playsMode ? hist.plays : hist.duration,
                backgroundColor: playsMode ? CHART_COLORS.blue[1] : CHART_COLORS.green[1],
                borderColor: playsMode ? CHART_COLORS.blue[0] : CHART_COLORS.green[0],
                borderWidth: 1.5,
                borderRadius: playsMode ? 6 : 0,
                fill: !playsMode,
                tension: 0.35,
                pointRadius: playsMode ? 0 : 2,
                pointHoverRadius: playsMode ? 0 : 4,
              },
            ],
          },
          options: baseOpts(),
        });

        const bw = getDailyBandwidth(inputs.history, inputs.histRange);
        make("bandwidth", inputs.bandwidthCanvas, {
          type: "bar",
          data: {
            labels: bw.labels,
            datasets: [
              {
                type: "line",
                label: "Avg Bitrate",
                data: bw.avgMbps,
                yAxisID: "y",
                borderColor: "rgba(34,211,238,0.95)",
                backgroundColor: "rgba(34,211,238,0.18)",
                fill: true,
                tension: 0.35,
                pointRadius: 0,
                pointHoverRadius: 4,
                borderWidth: 2,
                pointStyle: "line",
                order: 2,
              },
              {
                type: "bar",
                label: "Sessions",
                data: bw.sessions,
                yAxisID: "y1",
                backgroundColor: "rgba(34,211,238,0.35)",
                borderColor: "rgba(34,211,238,0.55)",
                borderWidth: 0,
                borderRadius: 4,
                pointStyle: "circle",
                order: 1,
              },
            ],
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: { duration: 600, easing: "easeOutQuart" as const },
            interaction: { mode: "index" as const, intersect: false },
            layout: { padding: { top: 4, right: 4, bottom: 4, left: 0 } },
            plugins: {
              legend: {
                display: true,
                position: "bottom",
                labels: {
                  color: "rgba(255,255,255,0.45)",
                  usePointStyle: true,
                  pointStyleWidth: 10,
                  boxWidth: 8,
                  boxHeight: 8,
                  padding: 14,
                  font: { size: 11 },
                },
              },
              tooltip: {
                backgroundColor: "rgba(12,16,22,0.96)",
                borderColor: "rgba(255,255,255,0.12)",
                borderWidth: 1,
                titleColor: "rgba(255,255,255,0.85)",
                bodyColor: "rgba(255,255,255,0.65)",
                padding: 10,
                cornerRadius: 8,
                callbacks: {
                  label: (ctx) => {
                    const v = Number(ctx.parsed.y) || 0;
                    if (ctx.dataset.label === "Avg Bitrate") return `Avg Bitrate: ${v.toFixed(2)} Mbps`;
                    return `Sessions: ${v}`;
                  },
                },
              },
            },
            scales: {
              x: {
                grid: { color: "rgba(255,255,255,0.05)", drawTicks: false },
                ticks: {
                  color: "rgba(255,255,255,0.30)",
                  font: { size: 10 },
                  maxRotation: 0,
                  autoSkip: true,
                  maxTicksLimit: 10,
                  padding: 8,
                },
                border: { color: "rgba(255,255,255,0.08)" },
              },
              y: {
                position: "left",
                beginAtZero: true,
                grid: { color: "rgba(255,255,255,0.05)", drawTicks: false },
                ticks: { color: "rgba(255,255,255,0.30)", font: { size: 10 } },
                border: { color: "transparent" },
                title: {
                  display: true,
                  text: "Avg Bitrate (Mbps)",
                  color: "rgba(255,255,255,0.35)",
                  font: { size: 10, weight: 500 },
                  padding: { bottom: 4 },
                },
              },
              y1: {
                position: "right",
                beginAtZero: true,
                grid: { drawOnChartArea: false },
                ticks: {
                  color: "rgba(255,255,255,0.30)",
                  font: { size: 10 },
                  precision: 0,
                },
                border: { color: "transparent" },
                title: {
                  display: true,
                  text: "Sessions",
                  color: "rgba(255,255,255,0.35)",
                  font: { size: 10, weight: 500 },
                  padding: { bottom: 4 },
                },
              },
            },
          },
        });
      }

      if (inputs.tab === "users") {
        const top = getTopUsers(inputs.history, inputs.users);
        make("users", inputs.usersCanvas, {
          type: "bar",
          data: {
            labels: top.map((u) => u.name),
            datasets: [
              {
                data: top.map((u) => u.plays),
                backgroundColor: top.map((_, i) => CHART_PALETTE[i % CHART_PALETTE.length][1]),
                borderColor: top.map((_, i) => CHART_PALETTE[i % CHART_PALETTE.length][0]),
                borderWidth: 1.3,
                borderRadius: 6,
              },
            ],
          },
          options: baseOpts({
            indexAxis: "y",
            scales: {
              x: {
                grid: { color: "rgba(255,255,255,0.05)", drawTicks: false },
                ticks: { color: "rgba(255,255,255,0.30)", font: { size: 10 } },
                border: { color: "transparent" },
                beginAtZero: true,
              },
              y: {
                grid: { display: false },
                ticks: { color: "rgba(255,255,255,0.45)", font: { size: 11 } },
                border: { color: "transparent" },
              },
            },
          }),
        });
      }

      if (inputs.tab === "storage") {
        const trend = buildStorageTrend(inputs.storage, inputs.storagePredictions, inputs.storagePeriod);
        make("storageTrend", inputs.storageCanvas, {
          type: "line",
          data: {
            labels: trend.labels,
            datasets: [
              {
                label: "Historical",
                data: trend.historical,
                borderColor: "rgba(34,211,238,0.95)",
                backgroundColor: "rgba(34,211,238,0.18)",
                fill: true,
                tension: 0.25,
                pointRadius: 0,
                pointHoverRadius: 4,
                borderWidth: 2,
                spanGaps: false,
                order: 3,
              },
              {
                label: "Pred min",
                data: trend.predMin,
                borderColor: "transparent",
                backgroundColor: "transparent",
                pointRadius: 0,
                borderWidth: 0,
                spanGaps: false,
                order: 1,
              },
              {
                label: "Pred max",
                data: trend.predMax,
                borderColor: "transparent",
                backgroundColor: "rgba(34,211,238,0.12)",
                fill: "-1",
                pointRadius: 0,
                borderWidth: 0,
                spanGaps: false,
                order: 1,
              },
              {
                label: "Prediction",
                data: trend.prediction,
                borderColor: "rgba(34,211,238,0.85)",
                backgroundColor: "rgba(34,211,238,0.85)",
                borderDash: [6, 4],
                fill: false,
                tension: 0.2,
                pointRadius: (ctx: { dataIndex: number }) => (ctx.dataIndex > trend.nowIndex ? 3 : 0),
                pointStyle: "rectRot",
                pointHoverRadius: 5,
                borderWidth: 2,
                spanGaps: false,
                order: 2,
              },
            ],
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: { duration: 600, easing: "easeOutQuart" as const },
            interaction: { mode: "index" as const, intersect: false },
            layout: { padding: { top: 8, right: 8, bottom: 4, left: 0 } },
            plugins: {
              legend: {
                display: true,
                position: "top",
                align: "end",
                labels: {
                  color: "rgba(255,255,255,0.45)",
                  usePointStyle: true,
                  boxWidth: 8,
                  boxHeight: 8,
                  padding: 12,
                  font: { size: 11 },
                  filter: (item) => item.text === "Historical" || item.text === "Prediction",
                },
              },
              tooltip: {
                backgroundColor: "rgba(12,16,22,0.96)",
                borderColor: "rgba(255,255,255,0.12)",
                borderWidth: 1,
                titleColor: "rgba(255,255,255,0.85)",
                bodyColor: "rgba(255,255,255,0.65)",
                padding: 10,
                cornerRadius: 8,
                filter: (item) => item.dataset.label === "Historical" || item.dataset.label === "Prediction",
                callbacks: {
                  label: (ctx) => {
                    const v = ctx.parsed.y;
                    if (v == null) return "";
                    return `${ctx.dataset.label}: ${v} ${trend.unit}`;
                  },
                },
              },
            },
            scales: {
              x: {
                grid: { color: "rgba(255,255,255,0.05)", drawTicks: false },
                ticks: {
                  color: "rgba(255,255,255,0.30)",
                  font: { size: 10 },
                  maxRotation: 0,
                  autoSkip: true,
                  maxTicksLimit: 10,
                },
                border: { color: "rgba(255,255,255,0.08)" },
              },
              y: {
                beginAtZero: true,
                grid: { color: "rgba(255,255,255,0.05)", drawTicks: false },
                ticks: {
                  color: "rgba(255,255,255,0.30)",
                  font: { size: 10 },
                  callback: (value) => `${value} ${trend.unit}`,
                },
                border: { color: "transparent" },
                title: {
                  display: true,
                  text: `Storage (${trend.unit})`,
                  color: "rgba(255,255,255,0.35)",
                  font: { size: 10, weight: 500 },
                },
              },
            },
          },
        });
      }

      if (inputs.tab === "libraries") {
        const libs = getLibraries(inputs.history);
        make("libraries", inputs.librariesCanvas, {
          type: "bar",
          data: {
            labels: libs.map((l) => l.name),
            datasets: [
              {
                data: libs.map((l) => l.count),
                backgroundColor: libs.map((_, i) => CHART_PALETTE[i % CHART_PALETTE.length][1]),
                borderColor: libs.map((_, i) => CHART_PALETTE[i % CHART_PALETTE.length][0]),
                borderWidth: 1.3,
                borderRadius: 6,
              },
            ],
          },
          options: baseOpts(),
        });
      }
    }

    void mount();
    return () => {
      cancelled = true;
      destroyAll();
    };
  }, [
    inputs.tab,
    inputs.histRange,
    inputs.histMetric,
    inputs.history,
    inputs.activity,
    inputs.users,
    inputs.storage,
    inputs.storagePeriod,
    inputs.storagePredictions,
    inputs.watchCanvas,
    inputs.concurrentCanvas,
    inputs.historyMainCanvas,
    inputs.bandwidthCanvas,
    inputs.storageCanvas,
    inputs.usersCanvas,
    inputs.librariesCanvas,
  ]);
}

export function hasWatchDuration(bucket: DayBucket) {
  return bucket.duration.some((v) => v > 0);
}
