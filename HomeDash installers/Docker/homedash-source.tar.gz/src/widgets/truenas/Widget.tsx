"use client";

import "@/styles/widgets/truenas.widget.css";

import { useCallback, useLayoutEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type Pool = {
  name: string;
  healthy: boolean;
  status: string;
  used: number;
  available: number;
  id?: number;
  scan?: {
    function: string | null;
    state: string | null;
    endTime: number | null;
    percentage: number | null;
    errors: number | null;
  } | null;
};
type Host = { name: string; healthy: boolean; status: string; used: number; available: number };
type UsedPort = { containerPort: number; protocol: string; hostPort: number | null };
type App = {
  id: string;
  name: string;
  state: string;
  version: string;
  upgradeAvailable: boolean;
  latestVersion?: string;
  imageUpdatesAvailable?: boolean;
  containers?: number;
  usedPorts?: UsedPort[];
  portalUrl?: string | null;
};
type Update = { available: boolean; version: string; changes: number; changelog?: string; releaseNotesUrl?: string | null };
type Alert = {
  uuid?: string;
  level?: string;
  message?: string;
  klass?: string;
  datetime?: number | null;
  lastOccurrence?: number | null;
};
type Data = {
  href: string;
  openFallbackUrl?: string;
  connectionSource?: "private" | "public" | "unknown";
  system: {
    hostname: string;
    version: string;
    uptime: number;
    loadavg: number[];
    model?: string;
    cores?: number;
    physicalCores?: number;
    physmem?: number;
  };
  pools: Pool[];
  host: Host;
  apps: App[];
  update: Update;
  alerts: Alert[];
};

const bytes = (n: number) =>
  n > 1e12 ? `${(n / 1e12).toFixed(2)} TB` : n > 1e9 ? `${(n / 1e9).toFixed(1)} GB` : n ? `${(n / 1e6).toFixed(0)} MB` : "—";
const uptime = (s: number) => (s ? `${Math.floor(s / 86400)}d ${Math.floor((s % 86400) / 3600)}h` : "—");
const pct = (used: number, avail: number) => (used + avail ? (used / (used + avail)) * 100 : 0);

const formatDate = (ms?: number | null) => (ms ? new Date(ms).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" }) : "");

const ALERT_LEVEL_RANK: Record<string, number> = { CRITICAL: 0, ALERT: 0, EMERGENCY: 0, ERROR: 1, WARNING: 2, NOTICE: 3, INFO: 4 };
function alertLevelClass(level?: string) {
  const l = (level || "").toUpperCase();
  if (l === "CRITICAL" || l === "ALERT" || l === "EMERGENCY" || l === "ERROR") return "tn-dot--bad";
  if (l === "WARNING") return "tn-dot--warn";
  return "tn-dot--ok";
}

const TABS = [
  { key: "overview", label: "Overview" },
  { key: "storage", label: "Storage" },
  { key: "apps", label: "Apps" },
  { key: "updates", label: "Updates" },
  { key: "alerts", label: "Alerts" },
];

const CONNECTION_SOURCE_LABEL: Record<"private" | "public", string> = {
  private: "Connected via Private - IP",
  public: "Connected via Fallback Public URL",
};

function ConnectionCorner({ source }: { source: "private" | "public" | "unknown" }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const mark = (
    <div
      className={`tn-corner-source tn-corner-source--${source}`}
      title={CONNECTION_SOURCE_LABEL[source]}
      aria-label={CONNECTION_SOURCE_LABEL[source]}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}

function UsageBar({ used, available }: { used: number; available: number }) {
  const p = pct(used, available);
  return (
    <>
      <div className="tn-bar-track">
        <div className="tn-bar-fill" style={{ width: `${p}%` }} />
      </div>
      <div className="tn-row-sub">
        {bytes(used)} used · {bytes(available)} free ({p.toFixed(0)}%)
      </div>
    </>
  );
}

function usageColor(p: number) {
  if (p >= 90) return "#f87171";
  if (p >= 75) return "#fbbf24";
  return "#38bdf8";
}

function RingGauge({ pct: value, color, size = 76 }: { pct: number; color: string; size?: number }) {
  const r = (size - 8) / 2;
  const c = 2 * Math.PI * r;
  const clamped = Math.max(0, Math.min(100, value));
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="tn-ring">
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="6" />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={r}
        fill="none"
        stroke={color}
        strokeWidth="6"
        strokeDasharray={`${(clamped / 100) * c} ${c}`}
        strokeLinecap="round"
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
      />
      <text x="50%" y="50%" textAnchor="middle" dominantBaseline="central" fill={color} fontSize="15" fontWeight="700">
        {Math.round(clamped)}%
      </text>
    </svg>
  );
}

function MiniUsageRow({ name, used, available }: { name: string; used: number; available: number }) {
  const p = pct(used, available);
  const color = usageColor(p);
  return (
    <div className="tn-ov-pool-row">
      <div className="tn-ov-pool-hdr">
        <span className="tn-ov-pool-name" title={name}>{name}</span>
        <span className="tn-ov-pool-pct" style={{ color }}>{p.toFixed(0)}%</span>
      </div>
      <div className="tn-ov-pool-track">
        <div className="tn-ov-pool-fill" style={{ width: `${p}%`, background: color }} />
      </div>
      <div className="tn-row-sub">
        {bytes(used)} used · {bytes(available)} free
      </div>
    </div>
  );
}

export default function Widget() {
  const instance = useWidgetInstance();
  const id = instance?.instanceId || "truenas";
  const showIcon = instance?.showIcon !== false;
  const showTitle = instance?.showTitle !== false;
  const [data, setData] = useState<Data | null>(null);
  const [error, setError] = useState("");
  const [tab, setTab] = useState("overview");
  const [busy, setBusy] = useState<string>("");

  const load = useCallback(async () => {
    try {
      const r = await fetch(`/api/widgets/truenas/status?instance=${encodeURIComponent(id)}`);
      const j = await r.json();
      if (!r.ok) throw new Error(j.error);
      setData(j);
      setError("");
    } catch (e) {
      setError(e instanceof Error ? e.message : "TrueNAS unavailable");
    }
  }, [id]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: 60_000 });
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);

  const runAction = useCallback(
    async (action: string, appId?: string, confirmMsg?: string) => {
      if (confirmMsg && !window.confirm(confirmMsg)) return;
      const key = appId ? `${action}:${appId}` : action;
      setBusy(key);
      try {
        const r = await fetch("/api/widgets/truenas/action", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ instance: id, action, appId }),
        });
        const j = await r.json();
        if (!r.ok) throw new Error(j.error);
        if (action === "dismiss-alert" && appId) {
          // The status endpoint is cached for 30s server-side, so an immediate
          // reload here would just hand back the same stale snapshot with the
          // alert still in it. Remove it from local state instead; the next
          // regular poll (60s interval) will pick up the confirmed server state
          // once the cache has expired.
          setData((prev) => (prev ? { ...prev, alerts: prev.alerts.filter((al) => al.uuid !== appId) } : prev));
        } else {
          await load();
        }
      } catch (e) {
        setError(e instanceof Error ? e.message : "Action failed");
      } finally {
        setBusy("");
      }
    },
    [id, load],
  );

  if (!data) {
    return (
      <div className="hd-widget-body" ref={rootRef}>
        <div className="tn-shell">
          <div className="tn-loading">{error || "Connecting to TrueNAS…"}</div>
          {error && (
            <button className="hd-btn hd-btn--sm" onClick={load}>
              Retry
            </button>
          )}
        </div>
      </div>
    );
  }

  const appsRunning = data.apps.filter((a) => a.state === "RUNNING").length;
  const appsWithUpdates = data.apps.filter((a) => a.upgradeAvailable).length;
  const poolsHealthy = data.pools.filter((p) => p.healthy).length;

  const storageEntries = [data.host, ...data.pools].filter((e) => e.used + e.available > 0);
  const totalUsed = storageEntries.reduce((sum, e) => sum + e.used, 0);
  const totalAvailable = storageEntries.reduce((sum, e) => sum + e.available, 0);
  const overallPct = pct(totalUsed, totalAvailable);
  const memGb = data.system.physmem ? data.system.physmem / 1e9 : 0;

  const content =
    tab === "overview" ? (
      <>
        <div className="tn-stats-grid">
          <div className="tn-stat-card">
            <div className="tn-stat-num">{data.system.hostname}</div>
            <div className="tn-stat-label">Hostname</div>
          </div>
          <div className="tn-stat-card">
            <div className="tn-stat-num">{uptime(data.system.uptime)}</div>
            <div className="tn-stat-label">Uptime</div>
          </div>
          <div className="tn-stat-card">
            <div className="tn-stat-num">
              {data.system.loadavg.slice(0, 3).map((v) => v.toFixed(2)).join(" / ") || "—"}
            </div>
            <div className="tn-stat-label">Load Avg</div>
          </div>
          <div className="tn-stat-card">
            <div className="tn-stat-num">
              {poolsHealthy}/{data.pools.length}
            </div>
            <div className="tn-stat-label">Healthy Pools</div>
          </div>
          <div className="tn-stat-card">
            <div className="tn-stat-num">
              {data.system.physicalCores || data.system.cores || "—"}
              {data.system.cores && data.system.physicalCores && data.system.cores !== data.system.physicalCores
                ? ` / ${data.system.cores}t`
                : ""}
            </div>
            <div className="tn-stat-label">CPU Cores</div>
          </div>
          <div className="tn-stat-card">
            <div className="tn-stat-num">{memGb ? `${memGb.toFixed(0)} GB` : "—"}</div>
            <div className="tn-stat-label">Memory</div>
          </div>
        </div>

        <section className="tn-ov-section">
          <div className="tn-ov-section-hdr">Storage Usage</div>
          <div className="tn-ov-storage">
            <div className="tn-ov-storage-ring">
              <RingGauge pct={overallPct} color={usageColor(overallPct)} />
              <div className="tn-ov-storage-total">
                <div className="tn-ov-storage-total-num">{bytes(totalUsed)}</div>
                <div className="tn-row-sub">of {bytes(totalUsed + totalAvailable)} used</div>
              </div>
            </div>
            <div className="tn-ov-pool-list">
              {storageEntries.length ? (
                storageEntries
                  .slice(0, 5)
                  .map((e) => <MiniUsageRow key={e.name} name={e.name} used={e.used} available={e.available} />)
              ) : (
                <div className="tn-empty">No storage data</div>
              )}
              {storageEntries.length > 5 ? (
                <div className="tn-row-sub">+{storageEntries.length - 5} more in Storage tab</div>
              ) : null}
            </div>
          </div>
        </section>

        <div className="tn-quickfacts">
          <span className="tn-chip">Version {data.system.version}</span>
          {data.system.model ? <span className="tn-chip" title={data.system.model}>{data.system.model}</span> : null}
          <span className={`tn-chip ${appsWithUpdates || data.update.available ? "tn-chip--warn" : ""}`}>
            {appsRunning}/{data.apps.length} apps running
          </span>
          <span className={`tn-chip ${data.update.available || appsWithUpdates > 0 ? "tn-chip--warn" : ""}`}>
            {(data.update.available ? 1 : 0) + appsWithUpdates} updates pending
          </span>
          <span className={`tn-chip ${data.alerts.length ? "tn-chip--warn" : ""}`}>
            {data.alerts.length} active alerts
          </span>
        </div>
      </>
    ) : tab === "storage" ? (
      <div className="tn-list">
        <div className="tn-row">
          <span className={`tn-dot ${data.host.healthy ? "tn-dot--ok" : "tn-dot--bad"}`} />
          <div className="tn-row-body">
            <div className="tn-row-title">Host ({data.host.name})</div>
            <UsageBar used={data.host.used} available={data.host.available} />
          </div>
        </div>
        {data.pools.map((p) => {
          const scanning = p.scan?.state === "SCANNING";
          const scanKey = `scrub-pool:${p.id}`;
          return (
            <div className="tn-row" key={p.name}>
              <span className={`tn-dot ${p.healthy ? "tn-dot--ok" : "tn-dot--bad"}`} />
              <div className="tn-row-body">
                <div className="tn-row-title">{p.name}</div>
                <div className="tn-row-sub">{p.status}</div>
                <UsageBar used={p.used} available={p.available} />
                {p.scan ? (
                  <div className="tn-row-sub tn-scan-sub">
                    {scanning
                      ? `Scrub in progress${p.scan.percentage != null ? ` · ${p.scan.percentage.toFixed(0)}%` : ""}`
                      : p.scan.endTime
                        ? `Last scrub ${formatDate(p.scan.endTime)}${p.scan.errors ? ` · ${p.scan.errors} errors` : " · no errors"}`
                        : "No scrub history"}
                  </div>
                ) : null}
              </div>
              {p.id != null ? (
                <div className="tn-row-actions">
                  <button
                    className="tn-action-btn"
                    disabled={scanning || busy === scanKey}
                    onClick={() =>
                      runAction(
                        "scrub-pool",
                        String(p.id),
                        `Start a scrub on "${p.name}"? This reads every block in the pool to check for errors and can take hours on large pools.`,
                      )
                    }
                  >
                    {scanning ? "Scrubbing…" : busy === scanKey ? "Starting…" : "Scrub"}
                  </button>
                </div>
              ) : null}
            </div>
          );
        })}
      </div>
    ) : tab === "apps" ? (
      <div className="tn-list">
        {data.apps.length ? (
          data.apps.map((a) => {
            const running = a.state === "RUNNING";
            const ports = a.usedPorts || [];
            return (
              <div className="tn-row" key={a.id}>
                <span className={`tn-dot ${running ? "tn-dot--ok" : a.state === "STOPPED" ? "tn-dot--off" : "tn-dot--warn"}`} />
                <div className="tn-row-body">
                  <div className="tn-row-title">{a.name}</div>
                  <div className="tn-row-sub">
                    {a.state}
                    {a.version ? ` · ${a.version}` : ""}
                    {a.upgradeAvailable && a.latestVersion ? ` → ${a.latestVersion}` : a.upgradeAvailable ? " · update available" : ""}
                    {!a.upgradeAvailable && a.imageUpdatesAvailable ? " · image update available" : ""}
                    {a.containers ? ` · ${a.containers} container${a.containers === 1 ? "" : "s"}` : ""}
                  </div>
                  {ports.length ? (
                    <div className="tn-port-chips">
                      {ports.slice(0, 4).map((p, i) => (
                        <span className="tn-chip" key={i}>
                          {p.hostPort ?? p.containerPort}
                          {p.hostPort ? ` → ${p.containerPort}` : ""}
                          {p.protocol ? `/${p.protocol}` : ""}
                        </span>
                      ))}
                      {ports.length > 4 ? <span className="tn-chip">+{ports.length - 4}</span> : null}
                    </div>
                  ) : null}
                </div>
                <div className="tn-row-actions">
                  {running && a.portalUrl ? (
                    <a className="tn-action-btn tn-action-btn--link" href={a.portalUrl} target="_blank" rel="noreferrer">
                      Open
                    </a>
                  ) : null}
                  {a.upgradeAvailable && (
                    <button
                      className="tn-action-btn tn-action-btn--update"
                      disabled={busy === `upgrade-app:${a.id}`}
                      onClick={() => runAction("upgrade-app", a.id)}
                    >
                      {busy === `upgrade-app:${a.id}` ? "Updating…" : "Update"}
                    </button>
                  )}
                  {running ? (
                    <button
                      className="tn-action-btn"
                      disabled={busy === `restart-app:${a.id}`}
                      onClick={() => runAction("restart-app", a.id, `Restart "${a.name}"?`)}
                    >
                      {busy === `restart-app:${a.id}` ? "Restarting…" : "Restart"}
                    </button>
                  ) : null}
                  <button
                    className="tn-action-btn"
                    disabled={busy === `${running ? "stop-app" : "start-app"}:${a.id}`}
                    onClick={() => runAction(running ? "stop-app" : "start-app", a.id)}
                  >
                    {running ? "Stop" : "Start"}
                  </button>
                </div>
              </div>
            );
          })
        ) : (
          <div className="tn-empty">No apps installed</div>
        )}
      </div>
    ) : tab === "updates" ? (
      <div className="tn-list">
        <div className="tn-row">
          <span className={`tn-dot ${data.update.available ? "tn-dot--warn" : "tn-dot--ok"}`} />
          <div className="tn-row-body">
            <div className="tn-row-title">System</div>
            <div className="tn-row-sub">
              {data.update.available
                ? `Update available${data.update.version ? ` · ${data.update.version}` : ""}${data.update.changes ? ` · ${data.update.changes} changes` : ""}`
                : "Up to date"}
            </div>
            {data.update.available && data.update.changelog ? (
              <div className="tn-row-sub tn-changelog">{data.update.changelog.slice(0, 220)}{data.update.changelog.length > 220 ? "…" : ""}</div>
            ) : null}
            {data.update.available && data.update.releaseNotesUrl ? (
              <a className="tn-inline-link" href={data.update.releaseNotesUrl} target="_blank" rel="noreferrer">
                Release notes
              </a>
            ) : null}
          </div>
          {data.update.available && (
            <div className="tn-row-actions">
              <button
                className="tn-action-btn tn-action-btn--update"
                disabled={busy === "system-update"}
                onClick={() =>
                  runAction(
                    "system-update",
                    undefined,
                    "This downloads and installs the TrueNAS update, then reboots the system. Continue?",
                  )
                }
              >
                {busy === "system-update" ? "Updating…" : "Update Now"}
              </button>
            </div>
          )}
        </div>
        {appsWithUpdates > 0 ? (
          data.apps
            .filter((a) => a.upgradeAvailable)
            .map((a) => (
              <div className="tn-row" key={a.id}>
                <span className="tn-dot tn-dot--warn" />
                <div className="tn-row-body">
                  <div className="tn-row-title">{a.name}</div>
                  <div className="tn-row-sub">
                    App update available
                    {a.version ? ` · ${a.version}` : ""}
                    {a.latestVersion ? ` → ${a.latestVersion}` : ""}
                  </div>
                </div>
                <div className="tn-row-actions">
                  <button
                    className="tn-action-btn tn-action-btn--update"
                    disabled={busy === `upgrade-app:${a.id}`}
                    onClick={() => runAction("upgrade-app", a.id)}
                  >
                    {busy === `upgrade-app:${a.id}` ? "Updating…" : "Update"}
                  </button>
                </div>
              </div>
            ))
        ) : (
          <div className="tn-empty">All apps up to date</div>
        )}
      </div>
    ) : (
      <div className="tn-list">
        {data.alerts.length ? (
          [...data.alerts]
            .sort((a, b) => {
              const rankDiff = (ALERT_LEVEL_RANK[(a.level || "").toUpperCase()] ?? 5) - (ALERT_LEVEL_RANK[(b.level || "").toUpperCase()] ?? 5);
              if (rankDiff !== 0) return rankDiff;
              return (b.lastOccurrence || b.datetime || 0) - (a.lastOccurrence || a.datetime || 0);
            })
            .map((a, i) => {
              const key = a.uuid || String(i);
              const when = formatDate(a.lastOccurrence || a.datetime);
              return (
                <div className="tn-row" key={key}>
                  <span className={`tn-dot ${alertLevelClass(a.level)}`} />
                  <div className="tn-row-body">
                    <div className="tn-row-title">{a.message || "Alert"}</div>
                    <div className="tn-row-sub">
                      {a.level || "INFO"}
                      {when ? ` · ${when}` : ""}
                    </div>
                  </div>
                  {a.uuid ? (
                    <div className="tn-row-actions">
                      <button
                        className="tn-action-btn"
                        disabled={busy === `dismiss-alert:${a.uuid}`}
                        onClick={() => runAction("dismiss-alert", a.uuid)}
                      >
                        {busy === `dismiss-alert:${a.uuid}` ? "Dismissing…" : "Dismiss"}
                      </button>
                    </div>
                  ) : null}
                </div>
              );
            })
        ) : (
          <div className="tn-empty">No active alerts</div>
        )}
      </div>
    );

  return (
    <div className="hd-widget-body" ref={rootRef}>
    <ConnectionCorner source={data.connectionSource || "unknown"} />
    <div className="tn-shell">
      <div className="tn-header">
        <div className="tn-header-top">
          <div className="tn-header-left">
            {showIcon || showTitle ? (
              <>
                {showIcon ? (
                  <img
                    className="tn-icon"
                    src="https://cdn.jsdelivr.net/gh/homarr-labs/dashboard-icons/webp/truenas.webp"
                    alt=""
                  />
                ) : null}
                {showTitle ? <span className="tn-title">{instance?.label || "TrueNAS"}</span> : null}
              </>
            ) : null}
          </div>
          <div className="tn-header-right">
            <span className="tn-pill tn-pill--apps">
              <span className="dot" />
              {appsRunning}/{data.apps.length} Apps
            </span>
            <span className="tn-pill tn-pill--pools">
              <span className="dot" />
              {poolsHealthy}/{data.pools.length} Pools
            </span>
            {(data.update.available || appsWithUpdates > 0) && (
              <span className="tn-pill tn-pill--update">
                <span className="dot" />
                {(data.update.available ? 1 : 0) + appsWithUpdates} Updates
              </span>
            )}
            <span className={`tn-status-badge ${error ? "tn-status-badge--offline" : "tn-status-badge--online"}`}>
              <span className="tn-status-dot" />
              {error ? "OFFLINE" : "ONLINE"}
            </span>
            <a className="tn-open-link" href={openHref} target="_blank" rel="noreferrer">
              Open
            </a>
          </div>
        </div>
        <div className="tn-tabs" role="tablist" aria-label="TrueNAS views">
          {TABS.map((item) => (
            <button
              key={item.key}
              type="button"
              className={`tn-tab${tab === item.key ? " tn-tab--active" : ""}`}
              onClick={() => setTab(item.key)}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>
      <div className="tn-body">{content}</div>
      <div className="tn-footer">
        <span className="tn-footer-text">TrueNAS · Updated {new Date().toLocaleTimeString()}</span>
      </div>
      {error && <div className="tn-empty">{error}</div>}
    </div>
    </div>
  );
}
