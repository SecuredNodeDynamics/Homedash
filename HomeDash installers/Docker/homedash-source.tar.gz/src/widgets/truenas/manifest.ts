import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "truenas",
  name: "TrueNAS",
  description: "Storage, apps, and updates",
  version: "0.2.4",
  category: "Infra",
  defaultSize: { w: 5, h: 4, minW: 3, minH: 3 },
  hostClass: "truenas-host tn-host",
  configFields: [
  {
    "key": "baseUrl",
    "label": "Private - IP",
    "type": "url",
    "placeholder": "https://10.0.0.1"
  },
  {
    "key": "fallbackUrl",
    "label": "Fallback Public URL",
    "type": "url",
    "placeholder": "https://truenas.example.com"
  },
  {
    "key": "publicUrl",
    "label": "OPEN - Private URL",
    "type": "url",
    "placeholder": "https://10.0.0.1"
  },
  {
    "key": "openFallbackUrl",
    "label": "OPEN - Public URL",
    "type": "url",
    "placeholder": "https://… (Cloudflare)"
  },
  {
    "key": "apiKey",
    "label": "API Key",
    "type": "password",
    "required": true
  }
],
};
