"use client";
import "@/styles/widgets/kuma.widget.css";


import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type Heartbeat = {
  status: number;
  time?: string;
  msg?: string;
  ping?: number | null;
};

type Monitor = {
  id: string | number;
  name: string;
  type: string;
  url: string;
  status: number;
  up24: number | null;
  up7d: number | null;
  up30d: number | null;
  avgPing: number | null;
  lastCheck: string | null;
  lastMsg: string;
  recentBeats: Heartbeat[];
  group: string;
};

type ConnectionSource = "private" | "public" | "unknown";

type Page = {
  slug: string;
  label: string;
  icon: string;
  href: string;
  openFallbackUrl?: string;
  monitors: Monitor[] | null;
  connectionSource?: ConnectionSource;
  error?: string;
};

const CONNECTION_SOURCE_LABEL: Record<ConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

function ConnectionCorner({ source }: { source: ConnectionSource }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const mark = (
    <div
      className={`uk-corner-source uk-corner-source--${source}`}
      title={CONNECTION_SOURCE_LABEL[source]}
      aria-label={CONNECTION_SOURCE_LABEL[source]}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}


function statusInfo(status: number) {
  if (status === 1) return { label: "UP", className: "uk-status--up", dot: "uk-dot--up", color: "#4ade80" };
  if (status === 0) return { label: "DOWN", className: "uk-status--down", dot: "uk-dot--down", color: "#f87171" };
  if (status === 2) {
    return { label: "PENDING", className: "uk-status--pending", dot: "uk-dot--pending", color: "#fbbf24" };
  }
  return { label: "—", className: "uk-status--unknown", dot: "", color: "rgba(255,255,255,0.25)" };
}

function uptimeColor(uptime: number | null) {
  if (uptime === null) return "rgba(255,255,255,0.15)";
  if (uptime >= 99) return "#4ade80";
  if (uptime >= 95) return "#fbbf24";
  return "#f87171";
}

function formatTime(value: string | null | undefined) {
  if (!value) return null;
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime())
    ? null
    : parsed.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function MonitorPopup({
  monitor,
  href,
  anchorRect,
  onClose,
}: {
  monitor: Monitor;
  href: string;
  anchorRect: DOMRect | null;
  onClose: () => void;
}) {
  const popupRef = useRef<HTMLDivElement>(null);
  const [style, setStyle] = useState<React.CSSProperties>({ visibility: "hidden" });

  useLayoutEffect(() => {
    const popup = popupRef.current;
    if (!popup) return;

    const place = () => {
      const margin = 12;
      const gap = 8;
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const width = popup.offsetWidth;
      const height = popup.offsetHeight;

      let top: number;
      let left: number;

      if (anchorRect) {
        // Open just below the clicked row, aligned to its left edge.
        top = anchorRect.bottom + gap;
        left = anchorRect.left;

        // Flip above the row if there's no room below.
        if (top + height > vh - margin) {
          top = anchorRect.top - height - gap;
        }
        // Last-resort vertical clamp for very short viewports.
        top = Math.max(margin, Math.min(top, vh - height - margin));
        // Keep it fully on-screen horizontally.
        left = Math.max(margin, Math.min(left, vw - width - margin));
      } else {
        // No anchor available (e.g. reopened via keyboard) — center it.
        top = (vh - height) / 2;
        left = (vw - width) / 2;
      }

      setStyle({ top, left, visibility: "visible" });
    };

    place();
    window.addEventListener("resize", place);
    window.addEventListener("scroll", place, true);
    return () => {
      window.removeEventListener("resize", place);
      window.removeEventListener("scroll", place, true);
    };
  }, [anchorRect, monitor.id]);

  const status = statusInfo(monitor.status);
  const uptime = monitor.up24 === null ? null : monitor.up24 * 100;
  const details = [
    monitor.type && ["Type", monitor.type.toUpperCase()],
    monitor.url && ["URL", monitor.url.replace(/^https?:\/\//, "").split("/")[0]],
    monitor.avgPing !== null && ["Avg Ping", `${monitor.avgPing} ms`],
    formatTime(monitor.lastCheck) && ["Last Check", formatTime(monitor.lastCheck)!],
    monitor.up24 !== null && ["Uptime 24h", `${(monitor.up24 * 100).toFixed(2)}%`],
    monitor.up7d !== null && ["Uptime 7d", `${(monitor.up7d * 100).toFixed(2)}%`],
    monitor.up30d !== null && ["Uptime 30d", `${(monitor.up30d * 100).toFixed(2)}%`],
  ].filter((detail): detail is [string, string] => Boolean(detail));

  return createPortal(
    (
      <>
        <button
          className="uk-popup-backdrop"
          type="button"
          aria-label="Close monitor details"
          onClick={onClose}
        />
        <div
          ref={popupRef}
          className="uk-popup"
          role="dialog"
          aria-modal="true"
          aria-label={`${monitor.name} details`}
          style={style}
        >
          <div className="uk-popup__body">
            <div className="uk-popup__header">
              <span
                className="uk-popup__dot"
                style={{ background: status.color, boxShadow: `0 0 6px ${status.color}80` }}
              />
              <span className="uk-popup__name" title={monitor.name}>
                {monitor.name}
              </span>
              <span className={`uk-popup__badge ${status.className}`}>{status.label}</span>
            </div>
            <div className="uk-popup__rows">
              {details.map(([label, value]) => (
                <div className="uk-popup__row" key={label}>
                  <span className="uk-popup__label">{label}</span>
                  <span className="uk-popup__value">{value}</span>
                </div>
              ))}
            </div>
            {monitor.lastMsg ? (
              <>
                <div className="uk-popup__divider" />
                <div
                  className="uk-popup__value"
                  style={{ textAlign: "left", fontSize: "0.65rem", wordBreak: "break-word" }}
                >
                  {monitor.lastMsg}
                </div>
              </>
            ) : null}
            {monitor.recentBeats.length ? (
              <>
                <div className="uk-popup__divider" />
                <div className="uk-popup__label" style={{ marginBottom: 5 }}>
                  Recent Checks
                </div>
                <div style={{ display: "flex", gap: 2, alignItems: "flex-end" }}>
                  {monitor.recentBeats.map((beat, index) => (
                    <span
                      key={`${beat.time || index}-${index}`}
                      title={formatTime(beat.time) || ""}
                      style={{
                        flex: 1,
                        height: 18,
                        borderRadius: 3,
                        minWidth: 4,
                        maxWidth: 12,
                        opacity: 0.75,
                        background: statusInfo(beat.status).color,
                      }}
                    />
                  ))}
                </div>
              </>
            ) : null}
            {uptime !== null ? (
              <div className="uk-popup__uptime-bar-wrap">
                <div className="uk-popup__uptime-label">
                  <span>24h Uptime</span>
                  <span>{uptime.toFixed(2)}%</span>
                </div>
                <div className="uk-popup__uptime-track">
                  <div
                    className="uk-popup__uptime-fill"
                    style={{
                      width: `${Math.min(100, uptime)}%`,
                      background: uptimeColor(uptime),
                    }}
                  />
                </div>
              </div>
            ) : null}
            <a className="uk-popup__open-btn" href={href} target="_blank" rel="noopener noreferrer">
              Open Status Page ↗
            </a>
          </div>
        </div>
      </>
    ),
    document.body,
  );
}

export default function UkMonitorWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "uk-monitor";
  const [pages, setPages] = useState<Page[]>([]);
  const [activeSlug, setActiveSlug] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState<string | number | null>(null);
  const [anchorRect, setAnchorRect] = useState<DOMRect | null>(null);

  const load = useCallback(
    async () => {
      setError("");
      try {
        const response = await fetch(
          `/api/widgets/uk-monitor/status?instance=${encodeURIComponent(instanceId)}`,
          { cache: "no-store", signal: AbortSignal.timeout(22_000) },
        );
        const json = await response.json();
        if (!response.ok) throw new Error(json.error || "Failed to load Uptime Kuma");
        const nextPages = json.pages as Page[];
        setPages(nextPages);
        setActiveSlug((current) => current || nextPages[0]?.slug || "");
      } catch (reason) {
        setError(reason instanceof Error ? reason.message : "Failed to load Uptime Kuma");
      } finally {
        setLoading(false);
      }
    },
    [instanceId],
  );

  const { rootRef } = useWidgetPoll(load, { intervalMs: 60_000 });

  useEffect(() => {
    if (selectedId === null) return;
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setSelectedId(null);
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [selectedId]);

  const activePage = pages.find((page) => page.slug === activeSlug) || pages[0];
  const openHref = useOpenHref(activePage?.href, activePage?.openFallbackUrl);
  const connectionSource = activePage?.connectionSource;
  const monitors = activePage?.monitors || [];
  const counts = monitors.reduce(
    (total, monitor) => ({
      up: total.up + Number(monitor.status === 1),
      down: total.down + Number(monitor.status === 0),
      pending: total.pending + Number(monitor.status === 2),
    }),
    { up: 0, down: 0, pending: 0 },
  );
  const groups = monitors.reduce<Record<string, Monitor[]>>((result, monitor) => {
    const group = monitor.group || "Ungrouped";
    (result[group] ||= []).push(monitor);
    return result;
  }, {});
  const allOperational = monitors.length > 0 && counts.down === 0 && counts.pending === 0;
  // Re-resolve against the latest poll so the open card reflects live data
  // instead of a frozen snapshot from the moment it was clicked.
  const selectedMonitor =
    selectedId === null ? null : monitors.find((monitor) => monitor.id === selectedId) || null;

  if (loading && !pages.length) {
    return (
      <div className="hd-widget-body uk-body-flat" ref={rootRef}>
        <div className="uk-toolbar">
          <div className="uk-status-badge uk-status-badge--unknown">
            <span className="uk-status-dot-pill" />
            Loading
          </div>
        </div>
        {Array.from({ length: 4 }, (_, index) => (
          <div className="uk-skeleton-row" style={{ animationDelay: `${index * 0.1}s` }} key={index} />
        ))}
      </div>
    );
  }

  if (error && !pages.length) {
    return (
      <div className="hd-widget-body uk-body-flat" ref={rootRef}>
        <div className="uk-toolbar">
          <div className="uk-status-badge uk-status-badge--unhealthy">
            <span className="uk-status-dot-pill" />
            Unhealthy
          </div>
          <button className="uk-refresh-btn" type="button" onClick={() => load()}>
            Retry
          </button>
        </div>
        <div className="uk-error">⚠ {error}</div>
      </div>
    );
  }

  return (
    <div className="hd-widget-body uk-body-flat" ref={rootRef}>
      <ConnectionCorner source={connectionSource || "unknown"} />
      <div className="uk-toolbar">
        <div className="uk-toolbar-left">
          <div
            className={`uk-status-badge ${
              allOperational ? "uk-status-badge--healthy" : "uk-status-badge--unhealthy"
            }`}
          >
            <span className="uk-status-dot-pill" />
            {allOperational ? "Healthy" : "Unhealthy"}
          </div>
        </div>
        <div className="uk-toolbar-right">
          {pages.length > 1 ? (
            <div className="uk-tabs">
              {pages.map((page) => (
                <button
                  className={`uk-tab${page.slug === activePage?.slug ? " uk-tab--active" : ""}`}
                  type="button"
                  key={page.slug}
                  onClick={() => {
                    setSelectedId(null);
                    setActiveSlug(page.slug);
                  }}
                >
                  <span className="uk-tab-icon">{page.icon}</span>
                  {page.label}
                </button>
              ))}
            </div>
          ) : null}
          {activePage ? (
            <a className="uk-open-link" href={openHref} target="_blank" rel="noopener noreferrer">
              Open
            </a>
          ) : null}
        </div>
      </div>

      {activePage?.monitors === null ? (
        <div className="uk-error">⚠ {activePage.error || "Could not reach Uptime Kuma"}</div>
      ) : null}

      {activePage && activePage.monitors !== null ? (
        <>
          <div className={`uk-summary-bar${allOperational ? " uk-summary-bar--ok" : ""}`}>
            <span className="uk-summary-chip uk-summary-chip--up">
              <span className="uk-dot uk-dot--up" />
              {counts.up} up
            </span>
            {counts.down ? (
              <span className="uk-summary-chip uk-summary-chip--down">
                <span className="uk-dot uk-dot--down" />
                {counts.down} down
              </span>
            ) : null}
            {counts.pending ? (
              <span className="uk-summary-chip uk-summary-chip--pending">
                <span className="uk-dot uk-dot--pending" />
                {counts.pending} pending
              </span>
            ) : null}
            <span className="uk-summary-total">{monitors.length} monitored</span>
            {allOperational ? <span className="uk-all-ok">✓ All operational</span> : null}
          </div>

          <div className="uk-scroll">
            <div className="uk-scroll-inner">
            {!monitors.length ? (
              <div className="uk-empty">No monitors found</div>
            ) : (
              Object.entries(groups)
                .sort(([a], [b]) => a.localeCompare(b))
                .map(([group, groupMonitors]) => (
                  <div className="uk-group" key={group}>
                    <div className="uk-group-label">{group}</div>
                    <div className="uk-monitor-grid">
                      {[...groupMonitors]
                        .sort((a, b) => a.name.localeCompare(b.name))
                        .map((monitor) => {
                          const status = statusInfo(monitor.status);
                          return (
                            <button
                              className="uk-monitor-row"
                              type="button"
                              key={String(monitor.id)}
                              onClick={(event) => {
                                setAnchorRect(event.currentTarget.getBoundingClientRect());
                                setSelectedId(monitor.id);
                              }}
                            >
                              <span className="uk-monitor-left">
                                <span className={`uk-status-dot ${status.dot}`} />
                                <span className="uk-monitor-name">{monitor.name}</span>
                              </span>
                              <span className="uk-monitor-right">
                                {monitor.up24 !== null ? (
                                  <span className="uk-uptime">{(monitor.up24 * 100).toFixed(1)}%</span>
                                ) : null}
                                <span className={`uk-status-badge ${status.className}`}>
                                  {status.label}
                                </span>
                              </span>
                            </button>
                          );
                        })}
                    </div>
                  </div>
                ))
            )}
            </div>
          </div>
        </>
      ) : null}

      {selectedMonitor && activePage ? (
        <MonitorPopup
          monitor={selectedMonitor}
          href={openHref}
          anchorRect={anchorRect}
          onClose={() => setSelectedId(null)}
        />
      ) : null}
    </div>
  );
}
