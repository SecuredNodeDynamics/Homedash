import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "uk-monitor",
  name: "Uptime Kuma",
  description: "Service uptime monitors",
  version: "0.1.6",
  category: "Network",
  defaultSize: { w: 8, h: 6, minW: 4, minH: 4 },
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "http://10.0.0.1:3001",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      placeholder: "https://kuma.example.com",
    },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url", placeholder: "http://10.0.0.1:3001" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    {
      key: "statusPages",
      label: "Status pages",
      type: "text",
      placeholder: "slug|Label|Icon, another-slug|Another page|◉",
    },
  ],
};
