"use client";
import "@/styles/widgets/vaultwarden.widget.css";

import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";
import { useAuthPermission } from "@/lib/use-auth-permission";

type ConnectionSource = "private" | "public" | "unknown";

const CONNECTION_SOURCE_LABEL: Record<ConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

function ConnectionCorner({ source, detail }: { source: ConnectionSource; detail?: string }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const label = detail ? `${CONNECTION_SOURCE_LABEL[source]} — Private - IP failed: ${detail}` : CONNECTION_SOURCE_LABEL[source];
  const mark = (
    <div
      className={`vw-corner-source vw-corner-source--${source}`}
      title={label}
      aria-label={label}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}

type Status = {
  href: string;
  openFallbackUrl?: string;
  connectionSource?: ConnectionSource;
  privateConnectionError?: string;
  domain: string;
  webVaultEnabled: boolean;
  websocketEnabled: boolean;
  signupsAllowed: boolean;
  invitationsAllowed: boolean;
  smtpEnabled: boolean;
  userCount: number;
  enabledUserCount: number;
  twoFactorCount: number;
  premiumCount: number;
};

type VaultSummary = {
  totalItems: number;
  logins: number;
  secureNotes: number;
  cards: number;
  identities: number;
  favorites: number;
  lastChangedAt?: string;
};

type VwUser = {
  id: string;
  email: string;
  name: string;
  enabled: boolean;
  emailVerified: boolean;
  premium: boolean;
  twoFactorEnabled: boolean;
  createdAt?: string;
};

type UserAction = "enable" | "disable" | "delete" | "deauth" | "remove-2fa";
type TabKey = "status" | "users" | "orgs" | "config";

type VwOrg = {
  id: string;
  name: string;
  type: number;
};

type VwOrgMember = {
  id: string;
  userId: string | null;
  name: string;
  email: string;
  type: number;
  status: number;
  twoFactorEnabled: boolean;
};

type OrgMemberAction = "reinvite" | "revoke" | "restore" | "remove";

const ORG_ROLE_LABEL: Record<number, string> = {
  0: "Owner",
  1: "Admin",
  2: "User",
  3: "Manager",
  4: "Custom",
};

const ORG_STATUS_LABEL: Record<number, string> = {
  [-1]: "Revoked",
  0: "Invited",
  1: "Accepted",
  2: "Confirmed",
};

type ToggleField = { key: string; label: string; hint?: string };
type TextField = { key: string; label: string; placeholder?: string; password?: boolean };

const REGISTRATION_TOGGLES: ToggleField[] = [
  { key: "signups_allowed", label: "Allow new signups" },
  { key: "invitations_allowed", label: "Allow org invitations" },
  { key: "signups_verify", label: "Require email verification" },
  { key: "show_password_hint", label: "Show password hint on login" },
];

const SERVER_TOGGLES: ToggleField[] = [
  { key: "web_vault_enabled", label: "Web vault enabled" },
  { key: "enable_websocket", label: "Live sync (WebSocket)" },
  { key: "sends_allowed", label: "Allow Bitwarden Send" },
  { key: "emergency_access_allowed", label: "Allow emergency access" },
  { key: "disable_2fa_remember", label: "Disable \u201cremember 2FA\u201d" },
];

const SMTP_TOGGLES: ToggleField[] = [
  { key: "smtp_accept_invalid_certs", label: "Accept invalid SMTP certs" },
  { key: "smtp_accept_invalid_hostnames", label: "Accept invalid SMTP hostnames" },
];

const SMTP_TEXT: TextField[] = [
  { key: "smtp_host", label: "SMTP host", placeholder: "smtp.example.com" },
  { key: "smtp_port", label: "SMTP port", placeholder: "587" },
  { key: "smtp_security", label: "Security", placeholder: "starttls / force_tls / off" },
  { key: "smtp_from", label: "From address", placeholder: "vaultwarden@example.com" },
  { key: "smtp_from_name", label: "From name", placeholder: "Vaultwarden" },
  { key: "smtp_username", label: "SMTP username" },
  { key: "smtp_password", label: "SMTP password", password: true },
  { key: "smtp_auth_mechanism", label: "Auth mechanism", placeholder: "Plain" },
];

function fmtDate(v?: string) {
  if (!v) return "\u2014";
  return v;
}

function fmtRelative(iso?: string) {
  if (!iso) return "\u2014";
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return "\u2014";
  const diffMs = Date.now() - then;
  const mins = Math.floor(diffMs / 60_000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

export default function VaultwardenWidget() {
  const canControlServices = useAuthPermission("widgets.control");
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "vaultwarden";

  const [data, setData] = useState<Status | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<TabKey>("status");

  const [users, setUsers] = useState<VwUser[]>([]);
  const [usersLoading, setUsersLoading] = useState(false);
  const [usersError, setUsersError] = useState("");
  const [busyUser, setBusyUser] = useState("");
  const [query, setQuery] = useState("");

  const [config, setConfig] = useState<Record<string, unknown> | null>(null);
  const [configLoading, setConfigLoading] = useState(false);
  const [configError, setConfigError] = useState("");
  const [configMsg, setConfigMsg] = useState("");
  const [savingKey, setSavingKey] = useState("");
  const [drafts, setDrafts] = useState<Record<string, string>>({});

  const [vault, setVault] = useState<VaultSummary | null>(null);
  const [vaultLoading, setVaultLoading] = useState(false);
  const [vaultError, setVaultError] = useState("");

  const [orgs, setOrgs] = useState<VwOrg[]>([]);
  const [orgsLoading, setOrgsLoading] = useState(false);
  const [orgsError, setOrgsError] = useState("");
  const [selectedOrgId, setSelectedOrgId] = useState("");
  const [members, setMembers] = useState<VwOrgMember[]>([]);
  const [membersLoading, setMembersLoading] = useState(false);
  const [membersError, setMembersError] = useState("");
  const [busyMember, setBusyMember] = useState("");

  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`/api/widgets/vaultwarden/status?instance=${encodeURIComponent(instanceId)}`);
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to load Vaultwarden");
      setData(json);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load Vaultwarden");
      setData(null);
    } finally {
      setLoading(false);
    }
  }, [instanceId]);

  const loadUsers = useCallback(async () => {
    setUsersLoading(true);
    setUsersError("");
    try {
      const res = await fetch(`/api/widgets/vaultwarden/users?instance=${encodeURIComponent(instanceId)}`);
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to load users");
      setUsers(Array.isArray(json.users) ? json.users : []);
    } catch (err) {
      setUsersError(err instanceof Error ? err.message : "Failed to load users");
    } finally {
      setUsersLoading(false);
    }
  }, [instanceId]);

  const loadConfig = useCallback(async () => {
    setConfigLoading(true);
    setConfigError("");
    try {
      const res = await fetch(`/api/widgets/vaultwarden/settings?instance=${encodeURIComponent(instanceId)}`);
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to load config");
      setConfig(json.config || {});
    } catch (err) {
      setConfigError(err instanceof Error ? err.message : "Failed to load config");
    } finally {
      setConfigLoading(false);
    }
  }, [instanceId]);

  const loadVault = useCallback(async () => {
    setVaultLoading(true);
    setVaultError("");
    try {
      const res = await fetch(`/api/widgets/vaultwarden/vault?instance=${encodeURIComponent(instanceId)}`);
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to load vault summary");
      setVault(json);
    } catch (err) {
      setVaultError(err instanceof Error ? err.message : "Failed to load vault summary");
      setVault(null);
    } finally {
      setVaultLoading(false);
    }
  }, [instanceId]);

  const loadOrgs = useCallback(async () => {
    setOrgsLoading(true);
    setOrgsError("");
    try {
      const res = await fetch(`/api/widgets/vaultwarden/organizations?instance=${encodeURIComponent(instanceId)}`);
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to load organizations");
      const list: VwOrg[] = Array.isArray(json.organizations) ? json.organizations : [];
      setOrgs(list);
      setSelectedOrgId((prev) => (prev && list.some((o) => o.id === prev) ? prev : list[0]?.id || ""));
    } catch (err) {
      setOrgsError(err instanceof Error ? err.message : "Failed to load organizations");
      setOrgs([]);
    } finally {
      setOrgsLoading(false);
    }
  }, [instanceId]);

  const loadMembers = useCallback(
    async (orgId: string) => {
      if (!orgId) return;
      setMembersLoading(true);
      setMembersError("");
      try {
        const res = await fetch(
          `/api/widgets/vaultwarden/organizations?instance=${encodeURIComponent(instanceId)}&orgId=${encodeURIComponent(orgId)}`,
        );
        const json = await res.json();
        if (!res.ok) throw new Error(json.error || "Failed to load members");
        setMembers(Array.isArray(json.members) ? json.members : []);
      } catch (err) {
        setMembersError(err instanceof Error ? err.message : "Failed to load members");
        setMembers([]);
      } finally {
        setMembersLoading(false);
      }
    },
    [instanceId],
  );

  async function runMemberAction(memberId: string, action: OrgMemberAction) {
    if (!selectedOrgId) return;
    if (action === "remove" && !window.confirm("Remove this member from the organization?")) return;
    setBusyMember(memberId);
    setMembersError("");
    try {
      const res = await fetch("/api/widgets/vaultwarden/organizations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, orgId: selectedOrgId, memberId, action }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || `Failed to ${action}`);
      await loadMembers(selectedOrgId);
    } catch (err) {
      setMembersError(err instanceof Error ? err.message : `Failed to ${action}`);
    } finally {
      setBusyMember("");
    }
  }

  const { rootRef } = useWidgetPoll(load, { intervalMs: 60_000 });

  useEffect(() => {
    if (tab === "status" && !vault && !vaultLoading) void loadVault();
    if (tab === "users" && !users.length && !usersLoading) void loadUsers();
    if (tab === "orgs" && !orgs.length && !orgsLoading) void loadOrgs();
    if (tab === "config" && !config && !configLoading) void loadConfig();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  useEffect(() => {
    if (tab === "orgs" && selectedOrgId) void loadMembers(selectedOrgId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab, selectedOrgId]);

  const filteredUsers = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return users;
    return users.filter((u) => u.email.toLowerCase().includes(q) || u.name.toLowerCase().includes(q));
  }, [users, query]);

  async function runUserAction(userId: string, action: UserAction) {
    if (action === "delete" && !window.confirm("Permanently delete this user and all their data?")) return;
    if (action === "deauth" && !window.confirm("Log this user out of every device?")) return;
    setBusyUser(userId);
    setUsersError("");
    try {
      const res = await fetch("/api/widgets/vaultwarden/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, userId, action }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || `Failed to ${action}`);
      await loadUsers();
    } catch (err) {
      setUsersError(err instanceof Error ? err.message : `Failed to ${action}`);
    } finally {
      setBusyUser("");
    }
  }

  async function saveToggle(key: string, value: boolean) {
    setSavingKey(key);
    setConfigMsg("");
    setConfigError("");
    try {
      const res = await fetch("/api/widgets/vaultwarden/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, patch: { [key]: value } }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to save");
      const saved = json.config || {};
      setConfig(saved);
      if (Boolean(saved[key]) !== value) {
        setConfigError(
          `Vaultwarden accepted the request but ${key} is still ${Boolean(saved[key])}. An environment variable of the same name is likely forcing this setting — check your Vaultwarden container config.`,
        );
      } else {
        setConfigMsg("Saved.");
      }
    } catch (err) {
      setConfigError(err instanceof Error ? err.message : "Failed to save");
    } finally {
      setSavingKey("");
    }
  }

  async function saveText(key: string) {
    const raw = drafts[key];
    if (raw === undefined) return;
    setSavingKey(key);
    setConfigMsg("");
    setConfigError("");
    try {
      const value = /^\d+$/.test(raw.trim()) ? Number(raw.trim()) : raw;
      const res = await fetch("/api/widgets/vaultwarden/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, patch: { [key]: value } }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to save");
      const saved = json.config || {};
      setConfig(saved);
      setDrafts((prev) => {
        const next = { ...prev };
        delete next[key];
        return next;
      });
      // Password fields come back masked ("***"), so there's nothing to
      // compare there — for everything else, confirm the server actually
      // kept the value we sent instead of assuming the 200 meant it stuck.
      const isPass = SMTP_TEXT.find((f) => f.key === key)?.password;
      if (!isPass && String(saved[key] ?? "") !== String(value)) {
        setConfigError(
          `Vaultwarden accepted the request but ${key} is still "${saved[key]}". An environment variable of the same name is likely forcing this setting.`,
        );
      } else {
        setConfigMsg("Saved.");
      }
    } catch (err) {
      setConfigError(err instanceof Error ? err.message : "Failed to save");
    } finally {
      setSavingKey("");
    }
  }

  if (loading && !data) {
    return (
      <div className="hd-widget-body vw-body" ref={rootRef}>
        <div className="vw-toolbar">
          <span className="vw-status-pill vw-status-pill--loading">
            <span className="vw-status-dot" />
            Loading
          </span>
        </div>
        <div className="vw-skeleton-card" />
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="hd-widget-body vw-body" ref={rootRef}>
        <div className="vw-toolbar">
          <span className="vw-status-pill vw-status-pill--offline">
            <span className="vw-status-dot" />
            Offline
          </span>
        </div>
        <div className="vw-error">{error}</div>
      </div>
    );
  }

  return (
    <div className="hd-widget-body vw-body" ref={rootRef}>
      {data?.connectionSource ? (
        <ConnectionCorner source={data.connectionSource} detail={data.privateConnectionError} />
      ) : null}

      <div className="vw-toolbar">
        <div className="vw-tabs">
          {(["status", "users", "orgs", "config"] as TabKey[]).map((key) => (
            <button
              key={key}
              type="button"
              className={`vw-tab${tab === key ? " vw-tab--active" : ""}`}
              onClick={() => setTab(key)}
            >
              {key[0].toUpperCase() + key.slice(1)}
            </button>
          ))}
        </div>
        <a
          className="vw-open-vault"
          href={openHref || data?.href || "#"}
          target="_blank"
          rel="noopener noreferrer"
          title="Open the full Vaultwarden web vault — this widget manages users and server config only; vault items are end-to-end encrypted and can only be unlocked in the real vault UI."
        >
          Open
        </a>
      </div>

      {tab === "status" && data && (
        <div className="vw-status-grid">
          <div className="vw-stat">
            <span className="vw-stat-value">{data.userCount}</span>
            <span className="vw-stat-label">Users</span>
          </div>
          <div className="vw-stat">
            <span className="vw-stat-value">{data.enabledUserCount}</span>
            <span className="vw-stat-label">Enabled</span>
          </div>
          <div className="vw-stat">
            <span className="vw-stat-value">{data.twoFactorCount}</span>
            <span className="vw-stat-label">2FA on</span>
          </div>
          <div className="vw-stat">
            <span className="vw-stat-value">{data.premiumCount}</span>
            <span className="vw-stat-label">Premium</span>
          </div>
          <div className="vw-flags">
            <span className={`vw-flag${data.signupsAllowed ? " vw-flag--on" : ""}`}>Signups</span>
            <span className={`vw-flag${data.invitationsAllowed ? " vw-flag--on" : ""}`}>Invites</span>
            <span className={`vw-flag${data.smtpEnabled ? " vw-flag--on" : ""}`}>SMTP</span>
            <span className={`vw-flag${data.websocketEnabled ? " vw-flag--on" : ""}`}>Live sync</span>
            <span className={`vw-flag${data.webVaultEnabled ? " vw-flag--on" : ""}`}>Web vault</span>
          </div>

          <div className="vw-vault-card">
            <div className="vw-vault-card-hdr">
              <h4>Vault items</h4>
              <span className="vw-vault-badge" title="Item names, usernames, passwords and notes are end-to-end encrypted with your master password — this widget never sees or stores them, only these counts.">
                Metadata only
              </span>
            </div>
            {vaultError ? (
              <div className="vw-vault-empty">
                {vaultError}
                {vaultError.toLowerCase().includes("api key") && (
                  <span> Add it in this widget's settings, then reload.</span>
                )}
              </div>
            ) : vaultLoading && !vault ? (
              <div className="vw-skeleton-card" />
            ) : vault ? (
              <>
                <div className="vw-vault-grid">
                  <div className="vw-vault-stat">
                    <span className="vw-vault-num">{vault.totalItems}</span>
                    <span className="vw-vault-label">Total</span>
                  </div>
                  <div className="vw-vault-stat">
                    <span className="vw-vault-num">{vault.logins}</span>
                    <span className="vw-vault-label">Logins</span>
                  </div>
                  <div className="vw-vault-stat">
                    <span className="vw-vault-num">{vault.cards}</span>
                    <span className="vw-vault-label">Cards</span>
                  </div>
                  <div className="vw-vault-stat">
                    <span className="vw-vault-num">{vault.identities}</span>
                    <span className="vw-vault-label">Identities</span>
                  </div>
                  <div className="vw-vault-stat">
                    <span className="vw-vault-num">{vault.secureNotes}</span>
                    <span className="vw-vault-label">Notes</span>
                  </div>
                  <div className="vw-vault-stat">
                    <span className="vw-vault-num">{vault.favorites}</span>
                    <span className="vw-vault-label">Favorites</span>
                  </div>
                </div>
                <div className="vw-vault-sub">
                  Last changed {fmtRelative(vault.lastChangedAt)} · open the vault to view or edit an item
                </div>
              </>
            ) : null}
          </div>
        </div>
      )}

      {tab === "users" && (
        <div className="vw-panel">
          <div className="vw-panel-toolbar">
            <input
              className="vw-search"
              placeholder="Filter users\u2026"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
          {usersError && <div className="vw-error">{usersError}</div>}
          {usersLoading && !users.length ? (
            <div className="vw-skeleton-card" />
          ) : (
            <div className="vw-list">
              {filteredUsers.map((u) => (
                <div className="vw-row" key={u.id}>
                  <div className="vw-row-main">
                    <span className={`vw-dot ${u.enabled ? "vw-dot--on" : "vw-dot--off"}`} />
                    <div className="vw-row-text">
                      <span className="vw-row-title">{u.email}</span>
                      <span className="vw-row-sub">
                        {u.name !== u.email ? `${u.name} \u00b7 ` : ""}
                        {u.twoFactorEnabled ? "2FA" : "no 2FA"}
                        {u.premium ? " \u00b7 Premium" : ""}
                        {u.createdAt ? ` \u00b7 joined ${fmtDate(u.createdAt)}` : ""}
                      </span>
                    </div>
                  </div>
                  {canControlServices && (
                    <div className="vw-row-actions">
                      {u.enabled ? (
                        <button disabled={busyUser === u.id} onClick={() => runUserAction(u.id, "disable")}>
                          Disable
                        </button>
                      ) : (
                        <button disabled={busyUser === u.id} onClick={() => runUserAction(u.id, "enable")}>
                          Enable
                        </button>
                      )}
                      <button disabled={busyUser === u.id} onClick={() => runUserAction(u.id, "deauth")}>
                        Log out
                      </button>
                      <button disabled={busyUser === u.id} onClick={() => runUserAction(u.id, "remove-2fa")}>
                        Reset 2FA
                      </button>
                      <button
                        className="vw-danger"
                        disabled={busyUser === u.id}
                        onClick={() => runUserAction(u.id, "delete")}
                      >
                        Delete
                      </button>
                    </div>
                  )}
                </div>
              ))}
              {!filteredUsers.length && !usersLoading && <div className="vw-empty">No users found.</div>}
            </div>
          )}
        </div>
      )}

      {tab === "orgs" && (
        <div className="vw-panel">
          {orgsError ? (
            <div className="vw-vault-empty">
              {orgsError}
              {orgsError.toLowerCase().includes("api key") && (
                <span> Add your Personal API Key Client ID/Secret in this widget's settings, then reload.</span>
              )}
            </div>
          ) : orgsLoading && !orgs.length ? (
            <div className="vw-skeleton-card" />
          ) : orgs.length ? (
            <>
              <div className="vw-org-picker">
                {orgs.map((o) => (
                  <button
                    key={o.id}
                    type="button"
                    className={`vw-org-chip${selectedOrgId === o.id ? " vw-org-chip--active" : ""}`}
                    onClick={() => setSelectedOrgId(o.id)}
                  >
                    {o.name}
                    <span className="vw-role-badge">{ORG_ROLE_LABEL[o.type] || "Member"}</span>
                  </button>
                ))}
              </div>

              {membersError && <div className="vw-error">{membersError}</div>}
              {membersLoading && !members.length ? (
                <div className="vw-skeleton-card" />
              ) : (
                <div className="vw-list">
                  {members.map((m) => (
                    <div className="vw-row" key={m.id}>
                      <div className="vw-row-main">
                        <span className={`vw-dot ${m.status >= 1 ? "vw-dot--on" : "vw-dot--off"}`} />
                        <div className="vw-row-text">
                          <span className="vw-row-title">{m.email}</span>
                          <span className="vw-row-sub">
                            {m.name && m.name !== m.email ? `${m.name} \u00b7 ` : ""}
                            {ORG_ROLE_LABEL[m.type] || "Member"} \u00b7 {ORG_STATUS_LABEL[m.status] ?? "Unknown"}
                            {m.twoFactorEnabled ? " \u00b7 2FA" : " \u00b7 no 2FA"}
                          </span>
                        </div>
                      </div>
                      {canControlServices && (
                        <div className="vw-row-actions">
                          {m.status === 0 && (
                            <button disabled={busyMember === m.id} onClick={() => runMemberAction(m.id, "reinvite")}>
                              Reinvite
                            </button>
                          )}
                          {m.status !== -1 ? (
                            <button disabled={busyMember === m.id} onClick={() => runMemberAction(m.id, "revoke")}>
                              Revoke
                            </button>
                          ) : (
                            <button disabled={busyMember === m.id} onClick={() => runMemberAction(m.id, "restore")}>
                              Restore
                            </button>
                          )}
                          <button
                            className="vw-danger"
                            disabled={busyMember === m.id}
                            onClick={() => runMemberAction(m.id, "remove")}
                          >
                            Remove
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                  {!members.length && !membersLoading && <div className="vw-empty">No members found.</div>}
                </div>
              )}
            </>
          ) : (
            <div className="vw-empty">
              No organizations found where you're an Owner or Admin.
            </div>
          )}
        </div>
      )}

      {tab === "config" && (
        <div className="vw-panel vw-config">
          {configError && <div className="vw-error">{configError}</div>}
          {configMsg && <div className="vw-msg">{configMsg}</div>}
          {configLoading && !config ? (
            <div className="vw-skeleton-card" />
          ) : config ? (
            <>
              <div className="vw-config-section">
                <h4>Registration</h4>
                {REGISTRATION_TOGGLES.map((f) => (
                  <label className="vw-switch-row" key={f.key}>
                    <span>{f.label}</span>
                    <input
                      type="checkbox"
                      checked={Boolean(config[f.key])}
                      disabled={!canControlServices || savingKey === f.key}
                      onChange={(e) => saveToggle(f.key, e.target.checked)}
                    />
                  </label>
                ))}
              </div>

              <div className="vw-config-section">
                <h4>Server</h4>
                {SERVER_TOGGLES.map((f) => (
                  <label className="vw-switch-row" key={f.key}>
                    <span>{f.label}</span>
                    <input
                      type="checkbox"
                      checked={Boolean(config[f.key])}
                      disabled={!canControlServices || savingKey === f.key}
                      onChange={(e) => saveToggle(f.key, e.target.checked)}
                    />
                  </label>
                ))}
              </div>

              <div className="vw-config-section">
                <h4>SMTP</h4>
                {SMTP_TEXT.map((f) => (
                  <div className="vw-text-row" key={f.key}>
                    <span>{f.label}</span>
                    <div className="vw-text-row-input">
                      <input
                        type={f.password ? "password" : "text"}
                        placeholder={f.password ? "\u2022\u2022\u2022\u2022 (unchanged)" : f.placeholder}
                        value={drafts[f.key] ?? (f.password ? "" : String(config[f.key] ?? ""))}
                        disabled={!canControlServices}
                        onChange={(e) => setDrafts((prev) => ({ ...prev, [f.key]: e.target.value }))}
                      />
                      <button
                        disabled={!canControlServices || savingKey === f.key || drafts[f.key] === undefined}
                        onClick={() => saveText(f.key)}
                      >
                        Save
                      </button>
                    </div>
                  </div>
                ))}
                {SMTP_TOGGLES.map((f) => (
                  <label className="vw-switch-row" key={f.key}>
                    <span>{f.label}</span>
                    <input
                      type="checkbox"
                      checked={Boolean(config[f.key])}
                      disabled={!canControlServices || savingKey === f.key}
                      onChange={(e) => saveToggle(f.key, e.target.checked)}
                    />
                  </label>
                ))}
              </div>
            </>
          ) : null}
        </div>
      )}
    </div>
  );
}
