import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "vaultwarden",
  name: "Vaultwarden",
  description: "Users, orgs, and server config via the admin API",
  version: "0.2.2",
  category: "Security",
  defaultSize: { w: 5, h: 6, minW: 3, minH: 4 },
  hostClass: "vw-host",
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "http://10.0.0.1:8080",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      placeholder: "https://vault.example.com",
    },
    { key: "publicUrl", label: "OPEN - Private URL", type: "url", placeholder: "http://10.0.0.1:8080" },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    {
      key: "adminToken",
      label: "Admin Token",
      type: "password",
      required: true,
      placeholder: "Your plain ADMIN_TOKEN secret",
    },
    {
      key: "apiKeyClientId",
      label: "Personal API Key - Client ID",
      type: "text",
      placeholder: "user.<uuid> — Account Settings → Security → Keys",
    },
    {
      key: "apiKeyClientSecret",
      label: "Personal API Key - Client Secret",
      type: "password",
      placeholder: "The API key shown alongside the Client ID",
    },

  ],
};
