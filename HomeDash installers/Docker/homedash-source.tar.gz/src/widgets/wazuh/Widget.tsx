"use client";
import "@/styles/widgets/wazuh.widget.css";


import { useCallback, useEffect, useState, type CSSProperties } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type Agent = {
  id: string;
  name: string;
  ip: string;
  status: string;
  os: string;
  version: string;
};

type Summary = {
  total: number;
  active: number;
  disconnected: number;
  never_connected: number;
  pending: number;
};

type Alert = {
  timestamp: string | null;
  ruleId: string;
  description: string;
  level: number;
  groups: string[];
  agentName: string;
  agentIp: string;
};

type AlertResult = {
  hits: Alert[];
  counts: Record<string, number>;
  total: number;
  hasMore: boolean;
  searchAfter: unknown[] | null;
};

type Status = {
  href: string;
  openFallbackUrl?: string;
  summary: Summary;
  agents: Agent[];
  alerts: AlertResult | null;
  alertError: string | null;
  agentNames: string[];
};

type AlertTab = "all" | "syscheck" | "auth" | "system" | "vuln";
type TimeRange = "24h" | "7d" | "30d";

const ALERT_TABS: Array<{ key: AlertTab; label: string }> = [
  { key: "all", label: "All" },
  { key: "syscheck", label: "File Integrity" },
  { key: "auth", label: "Auth" },
  { key: "system", label: "System" },
  { key: "vuln", label: "Vulnerabilities" },
];

const GROUP_COLORS: Record<string, { color: string; bg: string; border: string }> = {
  syscheck: { color: "#818cf8", bg: "rgba(129,140,248,0.12)", border: "rgba(129,140,248,0.28)" },
  authentication_success: { color: "#6ee7b7", bg: "rgba(110,231,183,0.12)", border: "rgba(110,231,183,0.28)" },
  authentication_failed: { color: "#f87171", bg: "rgba(248,113,113,0.12)", border: "rgba(248,113,113,0.28)" },
  sshd: { color: "#38bdf8", bg: "rgba(56,189,248,0.12)", border: "rgba(56,189,248,0.28)" },
  pam: { color: "#38bdf8", bg: "rgba(56,189,248,0.12)", border: "rgba(56,189,248,0.28)" },
  ossec: { color: "#fb923c", bg: "rgba(251,146,60,0.12)", border: "rgba(251,146,60,0.28)" },
  rootcheck: { color: "#fbbf24", bg: "rgba(251,191,36,0.12)", border: "rgba(251,191,36,0.28)" },
  systemd: { color: "#a78bfa", bg: "rgba(167,139,250,0.12)", border: "rgba(167,139,250,0.28)" },
  syslog: { color: "#94a3b8", bg: "rgba(148,163,184,0.12)", border: "rgba(148,163,184,0.28)" },
  dpkg: { color: "#34d399", bg: "rgba(52,211,153,0.12)", border: "rgba(52,211,153,0.28)" },
  "vulnerability-detector": { color: "#f472b6", bg: "rgba(244,114,182,0.12)", border: "rgba(244,114,182,0.28)" },
};

function sevInfo(level: number) {
  if (level >= 14) {
    return { label: "Critical", color: "#f87171", bg: "rgba(248,113,113,0.12)", border: "rgba(248,113,113,0.30)" };
  }
  if (level >= 11) {
    return { label: "High", color: "#fb923c", bg: "rgba(251,146,60,0.12)", border: "rgba(251,146,60,0.30)" };
  }
  if (level >= 7) {
    return { label: "Medium", color: "#fbbf24", bg: "rgba(251,191,36,0.12)", border: "rgba(251,191,36,0.30)" };
  }
  return { label: "Low", color: "#6ee7b7", bg: "rgba(110,231,183,0.10)", border: "rgba(110,231,183,0.25)" };
}

function timeAgo(iso: string | null) {
  if (!iso) return "—";
  const diff = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (!Number.isFinite(diff) || diff < 0) return "—";
  if (diff < 60) return `${diff}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

function AgentCard({ agent }: { agent: Agent }) {
  const active = agent.status === "active";
  return (
    <div
      className={`wz-agent-card${active ? " wz-agent-card--active" : " wz-agent-card--offline"}`}
      title={[agent.name, agent.ip, agent.version, agent.status].filter(Boolean).join(" · ")}
    >
      <div className="wz-agent-icon" aria-hidden>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <rect x="2" y="3" width="20" height="14" rx="2" />
          <line x1="8" y1="21" x2="16" y2="21" />
          <line x1="12" y1="17" x2="12" y2="21" />
        </svg>
      </div>
      <div className="wz-agent-info">
        <div className="wz-agent-name">{agent.name}</div>
        <div className="wz-agent-meta">
          {agent.os ? <span className="wz-agent-os">{agent.os}</span> : null}
          {agent.ip ? <span className="wz-agent-ip">{agent.ip}</span> : null}
        </div>
      </div>
      <span className={`wz-agent-status${active ? " wz-agent-status--on" : ""}`} aria-label={agent.status} />
    </div>
  );
}

function AlertRow({ alert }: { alert: Alert }) {
  const sev = sevInfo(alert.level);
  return (
    <div
      className="wz-alert-row"
      style={
        {
          ["--row-bg" as string]: sev.bg,
          ["--row-border" as string]: sev.border,
        } as CSSProperties
      }
    >
      <div className="wz-alert-left">
        <div
          className="wz-alert-dot"
          style={{ background: sev.color, boxShadow: `0 0 5px ${sev.color}80`, marginTop: 4 }}
        />
        <div className="wz-alert-body">
          <div className="wz-alert-rule">{alert.description}</div>
          <div className="wz-alert-meta">
            <span className="wz-agent-badge">
              {alert.agentName}
              {alert.agentIp ? ` · ${alert.agentIp}` : ""}
            </span>
            {alert.ruleId ? <span className="wz-rule-id">Rule {alert.ruleId}</span> : null}
          </div>
          {alert.groups.length ? (
            <div className="wz-group-badges">
              {alert.groups.map((group) => {
                const colors = GROUP_COLORS[group] || {
                  color: "rgba(255,255,255,0.45)",
                  bg: "rgba(255,255,255,0.07)",
                  border: "rgba(255,255,255,0.12)",
                };
                return (
                  <span
                    className="wz-group-badge"
                    key={group}
                    style={{ color: colors.color, background: colors.bg, borderColor: colors.border }}
                  >
                    {group}
                  </span>
                );
              })}
            </div>
          ) : null}
        </div>
      </div>
      <div className="wz-alert-right">
        <span
          className="wz-sev-chip"
          style={{ color: sev.color, background: sev.bg, borderColor: sev.border }}
        >
          {sev.label}
        </span>
        <span className="wz-alert-time">{timeAgo(alert.timestamp)}</span>
      </div>
    </div>
  );
}

export default function WazuhWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "wazuh";
  const [data, setData] = useState<Status | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [alertTab, setAlertTab] = useState<AlertTab>("all");
  const [alertAgent, setAlertAgent] = useState("all");
  const [alertRange, setAlertRange] = useState<TimeRange>("7d");
  const [alerts, setAlerts] = useState<AlertResult | null>(null);
  const [alertError, setAlertError] = useState<string | null>(null);
  const [alertsLoading, setAlertsLoading] = useState(false);
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch(
        `/api/widgets/wazuh/status?instance=${encodeURIComponent(instanceId)}`,
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load Wazuh");
      setData(json);
      setAlerts(json.alerts);
      setAlertError(json.alertError);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load Wazuh");
      setData(null);
    } finally {
      setLoading(false);
    }
  }, [instanceId]);

  const loadAlerts = useCallback(
    async (opts?: { append?: boolean }) => {
      setAlertsLoading(true);
      try {
        const params = new URLSearchParams({
          instance: instanceId,
          tab: alertTab,
          agent: alertAgent,
          range: alertRange,
        });
        if (opts?.append && alerts?.searchAfter?.length) {
          params.set("searchAfter", JSON.stringify(alerts.searchAfter));
        }
        const response = await fetch(`/api/widgets/wazuh/alerts?${params.toString()}`);
        const json = await response.json();
        if (!response.ok) throw new Error(json.error || "Failed to load alerts");
        setAlerts((prev) =>
          opts?.append && prev
            ? {
                ...json,
                hits: [...prev.hits, ...json.hits],
                counts: Object.keys(json.counts || {}).length ? json.counts : prev.counts,
              }
            : json,
        );
        setAlertError(null);
      } catch (err) {
        setAlertError(err instanceof Error ? err.message : "Alerts unavailable");
        if (!opts?.append) setAlerts(null);
      } finally {
        setAlertsLoading(false);
      }
    },
    [instanceId, alertTab, alertAgent, alertRange, alerts?.searchAfter],
  );

  const { rootRef } = useWidgetPoll(load, { intervalMs: 120_000 });

  useEffect(() => {
    if (!data) return;
    if (!(data.alerts || data.alertError || alertError)) return;
    // Refetch when filters change after initial status load
    loadAlerts();
    // eslint-disable-next-line react-hooks/exhaustive-deps -- only on filter changes
  }, [alertTab, alertAgent, alertRange]);

  if (loading && !data) {
    return (
      <div className="hd-widget-body wz-body" ref={rootRef}>
        <div className="wz-toolbar">
          <span className="wz-status-pill wz-status-pill--loading">
            <span className="wz-status-dot" />
            Loading
          </span>
        </div>
        <div className="wz-skeleton-wrap">
          {Array.from({ length: 4 }, (_, index) => (
            <div className="wz-skeleton-row" key={index} />
          ))}
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="hd-widget-body wz-body" ref={rootRef}>
        <div className="wz-toolbar">
          <span className="wz-status-pill wz-status-pill--offline">
            <span className="wz-status-dot" />
            Offline
          </span>
          <button className="wz-open-link" type="button" onClick={load}>
            Retry
          </button>
        </div>
        <div className="wz-error">
          <div className="wz-error-title">Wazuh Unavailable</div>
          <div className="wz-error-msg">{error}</div>
        </div>
      </div>
    );
  }

  const summary = data.summary;
  const agents = [...data.agents].sort((a, b) => (a.status === "active" ? -1 : 1)).slice(0, 24);
  const healthPct = summary.total ? Math.round((summary.active / summary.total) * 100) : 0;
  const overallOk = summary.disconnected === 0 && summary.active === summary.total;
  const overallColor = overallOk ? "#6ee7b7" : summary.disconnected > 0 ? "#fb923c" : "#6ee7b7";
  const alertCounts = alerts?.counts || {};
  const sevPills = (
    [
      { key: "critical", label: "Critical", color: "#f87171", bg: "rgba(248,113,113,0.12)", border: "rgba(248,113,113,0.28)" },
      { key: "high", label: "High", color: "#fb923c", bg: "rgba(251,146,60,0.12)", border: "rgba(251,146,60,0.28)" },
      { key: "medium", label: "Medium", color: "#fbbf24", bg: "rgba(251,191,36,0.10)", border: "rgba(251,191,36,0.25)" },
      { key: "low", label: "Low", color: "#6ee7b7", bg: "rgba(110,231,183,0.08)", border: "rgba(110,231,183,0.22)" },
    ] as const
  ).filter((item) => (alertCounts[item.key] || 0) > 0);

  return (
    <div className="hd-widget-body wz-body" ref={rootRef}>
      <div className="wz-toolbar">
        <span className="wz-status-pill wz-status-pill--online">
          <span className="wz-status-dot" />
          Online
        </span>
        <div className="wz-toolbar-right">
          {openHref ? (
            <a className="wz-open-link" href={openHref} target="_blank" rel="noopener noreferrer">
              Open
            </a>
          ) : null}
        </div>
      </div>

      <div className="wz-summary-bar">
        <div className="wz-summary-total">
          <span className="wz-total-num" style={{ color: overallColor }}>
            {summary.active}
          </span>
          <span className="wz-total-label">/ {summary.total} agents active</span>
        </div>
        <div className="wz-summary-pills">
          {summary.disconnected ? (
            <div
              className="wz-pill"
              style={
                {
                  ["--pill-bg" as string]: "rgba(248,113,113,0.10)",
                  ["--pill-border" as string]: "rgba(248,113,113,0.22)",
                  ["--pill-color" as string]: "#f87171",
                } as CSSProperties
              }
            >
              <div className="wz-pill-dot" style={{ background: "#f87171", boxShadow: "0 0 4px #f8717180" }} />
              <span className="wz-pill-count">{summary.disconnected}</span>
              <span className="wz-pill-label">Offline</span>
            </div>
          ) : null}
          {summary.never_connected ? (
            <div
              className="wz-pill"
              style={
                {
                  ["--pill-bg" as string]: "rgba(251,146,60,0.08)",
                  ["--pill-border" as string]: "rgba(251,146,60,0.20)",
                  ["--pill-color" as string]: "#fb923c",
                } as CSSProperties
              }
            >
              <div className="wz-pill-dot" style={{ background: "#fb923c" }} />
              <span className="wz-pill-count">{summary.never_connected}</span>
              <span className="wz-pill-label">Never</span>
            </div>
          ) : null}
          {summary.pending ? (
            <div
              className="wz-pill"
              style={
                {
                  ["--pill-bg" as string]: "rgba(251,191,36,0.08)",
                  ["--pill-border" as string]: "rgba(251,191,36,0.20)",
                  ["--pill-color" as string]: "#fbbf24",
                } as CSSProperties
              }
            >
              <div className="wz-pill-dot" style={{ background: "#fbbf24" }} />
              <span className="wz-pill-count">{summary.pending}</span>
              <span className="wz-pill-label">Pending</span>
            </div>
          ) : null}
        </div>
      </div>

      <div className="wz-health-bar">
        <div className="wz-health-fill" style={{ width: `${healthPct}%`, background: overallColor }} />
      </div>

      <div className="wz-main-grid">
        <div className="wz-agents-col">
          {agents.length ? (
            <>
              <div className="wz-section-label">
                Agents
                <span className="wz-section-count">{data.agents.length} total</span>
              </div>
              <div className="wz-agent-grid">
                {agents.map((agent) => (
                  <AgentCard agent={agent} key={agent.id || agent.name} />
                ))}
              </div>
            </>
          ) : (
            <div className="wz-empty">No agents found</div>
          )}
        </div>

      <div className="wz-alerts-panel">
        <div className="wz-section-label">Alert Summary</div>
        <div className="wz-summary-pills" style={{ marginBottom: 2 }}>
          {sevPills.length ? (
            sevPills.map((pill) => (
              <div
                className="wz-pill"
                key={pill.key}
                style={
                  {
                    ["--pill-bg" as string]: pill.bg,
                    ["--pill-border" as string]: pill.border,
                    ["--pill-color" as string]: pill.color,
                  } as CSSProperties
                }
              >
                <div
                  className="wz-pill-dot"
                  style={{ background: pill.color, boxShadow: `0 0 4px ${pill.color}90` }}
                />
                <span className="wz-pill-count">{(alertCounts[pill.key] || 0).toLocaleString()}</span>
                <span className="wz-pill-label">{pill.label}</span>
              </div>
            ))
          ) : (
            <span style={{ fontSize: "0.68rem", color: "rgba(255,255,255,0.28)" }}>
              {alertError || "No alerts in range"}
            </span>
          )}
        </div>

        <div className="wz-alert-toolbar">
          <div className="wz-atabs">
            {ALERT_TABS.map((tab) => (
              <button
                className={`wz-atab${alertTab === tab.key ? " wz-atab--active" : ""}`}
                type="button"
                key={tab.key}
                onClick={() => setAlertTab(tab.key)}
              >
                {tab.label}
              </button>
            ))}
          </div>
          <div className="wz-alert-controls">
            <div className="wz-time-toggle">
              {(["24h", "7d", "30d"] as const).map((range) => (
                <button
                  className={`wz-ttog${alertRange === range ? " wz-ttog--active" : ""}`}
                  type="button"
                  key={range}
                  onClick={() => setAlertRange(range)}
                >
                  {range}
                </button>
              ))}
            </div>
            <select
              className="wz-agent-select"
              value={alertAgent}
              onChange={(event) => setAlertAgent(event.target.value)}
            >
              <option value="all">All agents</option>
              {data.agentNames.map((name) => (
                <option value={name} key={name}>
                  {name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="wz-alert-list">
          {alertsLoading && !alerts?.hits.length ? (
            <div className="wz-empty">Loading alerts…</div>
          ) : alerts?.hits.length ? (
            alerts.hits.map((alert, index) => (
              <AlertRow alert={alert} key={`${alert.ruleId}-${alert.timestamp}-${index}`} />
            ))
          ) : (
            <div className="wz-empty">{alertError || "No alerts for this filter"}</div>
          )}
        </div>

        {alerts?.hasMore ? (
          <button
            className="wz-load-more"
            type="button"
            disabled={alertsLoading}
            onClick={() => loadAlerts({ append: true })}
          >
            Load more{" "}
            <span style={{ opacity: 0.5, fontWeight: 400 }}>
              ({alerts.total.toLocaleString()} total)
            </span>
          </button>
        ) : null}
      </div>
      </div>
    </div>
  );
}
