import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "wazuh",
  name: "Wazuh",
  description: "Agents and security alerts",
  version: "0.2.3",
  category: "Security",
  defaultSize: { w: 6, h: 8, minW: 4, minH: 5 },
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "https://10.0.0.1:55000",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      placeholder: "https://wazuh.example.com",
    },
    {
      key: "publicUrl",
      label: "OPEN - Private URL",
      type: "url",
      placeholder: "https://10.0.0.1",
    },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    { key: "username", label: "Username", type: "text", required: true },
    { key: "password", label: "Password", type: "password", required: true },
    {
      key: "opensearchUrl",
      label: "OpenSearch URL",
      type: "url",
      placeholder: "https://10.0.0.1:9200",
    },
    { key: "osUsername", label: "OpenSearch Username", type: "text", placeholder: "admin" },
    { key: "osPassword", label: "OpenSearch Password", type: "password" },
  ],
};
