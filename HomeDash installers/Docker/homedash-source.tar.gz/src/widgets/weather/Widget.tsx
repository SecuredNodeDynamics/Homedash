"use client";
import "@/styles/widgets/weather.widget.css";


import { useCallback, useState } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type Data = {
  href: string;
  units: "imperial" | "metric";
  place: string;
  temperature: number;
  feelsLike: number;
  humidity: number;
  windSpeed: number;
  weatherCode: number;
  condition: string;
  isDay: boolean;
};

function tempUnit(units: Data["units"]) {
  return units === "metric" ? "°C" : "°F";
}

function windUnit(units: Data["units"]) {
  return units === "metric" ? "km/h" : "mph";
}

function fmtTemp(value: number) {
  if (!Number.isFinite(value)) return "—";
  return String(Math.round(value));
}

function fmtWind(value: number) {
  if (!Number.isFinite(value)) return "—";
  return String(Math.round(value));
}

function WeatherIcon({ code, isDay }: { code: number; isDay: boolean }) {
  const stroke = "currentColor";
  const common = {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke,
    strokeWidth: 1.7,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true as const,
  };

  if (code === 0) {
    return isDay ? (
      <svg {...common}>
        <circle cx="12" cy="12" r="4" />
        <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
      </svg>
    ) : (
      <svg {...common}>
        <path d="M20 14.5A7.5 7.5 0 0 1 9.5 4 6.5 6.5 0 1 0 20 14.5z" />
      </svg>
    );
  }
  if (code <= 2) {
    return (
      <svg {...common}>
        <circle cx="8" cy="9" r="3" />
        <path d="M8 3v1.2M3.5 9H2.3M4.2 5.2l-.9-.9M17 16.5a4 4 0 0 0-7.6-1.8A3.2 3.2 0 0 0 7 20.8h9.4a3.1 3.1 0 0 0 .6-6.3z" />
      </svg>
    );
  }
  if (code === 3 || code === 45 || code === 48) {
    return (
      <svg {...common}>
        <path d="M17.5 17a4 4 0 0 0-7.7-1.7A3.2 3.2 0 0 0 7 21.2h9.5a3.2 3.2 0 0 0 1-6.2z" />
        {code >= 45 ? <path d="M7 12h10M8 9.5h8M9 14.5h6" opacity="0.7" /> : null}
      </svg>
    );
  }
  if (code >= 71 && code <= 77) {
    return (
      <svg {...common}>
        <path d="M17.5 14a4 4 0 0 0-7.7-1.7A3.2 3.2 0 0 0 7 18.2h9.5a3.2 3.2 0 0 0 1-6.2z" />
        <path d="M9 19.5l.8 1.3M12 19l.8 1.3M15 19.5l.8 1.3" />
      </svg>
    );
  }
  if (code >= 95) {
    return (
      <svg {...common}>
        <path d="M17.5 13a4 4 0 0 0-7.7-1.7A3.2 3.2 0 0 0 7 17.2h9.5a3.2 3.2 0 0 0 1-6.2z" />
        <path d="M12 16.5l-1.5 3h2.2L11.4 22" />
      </svg>
    );
  }
  return (
    <svg {...common}>
      <path d="M17.5 14a4 4 0 0 0-7.7-1.7A3.2 3.2 0 0 0 7 18.2h9.5a3.2 3.2 0 0 0 1-6.2z" />
      <path d="M9.5 19.5v2M12.5 18.8v2.7M15.5 19.5v2" />
    </svg>
  );
}

export default function WeatherWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "weather";
  const [data, setData] = useState<Data | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  const detectDeviceCoords = useCallback((): Promise<{ latitude: number; longitude: number } | null> => {
    if (typeof window === "undefined" || typeof navigator === "undefined" || !navigator.geolocation) {
      return Promise.resolve(null);
    }
    // Browsers only show the permission popup in a secure context (HTTPS / localhost).
    if (!window.isSecureContext) return Promise.resolve(null);

    return new Promise((resolve) => {
      navigator.geolocation.getCurrentPosition(
        (pos) =>
          resolve({
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
          }),
        () => resolve(null),
        { enableHighAccuracy: false, timeout: 8_000, maximumAge: 300_000 },
      );
    });
  }, []);

  const load = useCallback(async () => {
    try {
      const coords = await detectDeviceCoords();
      const params = new URLSearchParams({ instance: instanceId });
      if (coords) {
        params.set("lat", String(coords.latitude));
        params.set("lon", String(coords.longitude));
      }
      const response = await fetch(`/api/widgets/weather/status?${params.toString()}`);
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load weather");
      setData(json);
      setError("");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Weather unavailable");
    } finally {
      setLoading(false);
    }
  }, [detectDeviceCoords, instanceId]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: 600_000 });

  if (loading && !data) {
    return (
      <div className="hd-widget-body wx-body" ref={rootRef}>
        <div className="wx-skeleton" />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="hd-widget-body wx-body" ref={rootRef}>
        <div className="wx-error">
          {error || "Allow location access, or set a city / lat-lon in Settings"}
        </div>
        <button className="wx-tool-btn" type="button" onClick={load}>
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="hd-widget-body wx-body" ref={rootRef}>
      {error ? <div className="wx-inline-error">{error}</div> : null}

      <div className="wx-hero">
        <div className="wx-glyph" aria-hidden="true">
          <WeatherIcon code={data.weatherCode} isDay={data.isDay} />
        </div>
        <div className="wx-temp-block">
          <div className="wx-temp">
            {fmtTemp(data.temperature)}
            <span className="wx-temp-unit">{tempUnit(data.units)}</span>
          </div>
          <div className="wx-condition">{data.condition}</div>
        </div>
      </div>

      <div className="wx-meta">
        <div className="wx-meta-item">
          <span className="wx-meta-label">Feels</span>
          <span className="wx-meta-value">
            {fmtTemp(data.feelsLike)}
            {tempUnit(data.units)}
          </span>
        </div>
        <div className="wx-meta-item">
          <span className="wx-meta-label">Humidity</span>
          <span className="wx-meta-value">{Math.round(data.humidity)}%</span>
        </div>
        <div className="wx-meta-item">
          <span className="wx-meta-label">Wind</span>
          <span className="wx-meta-value">
            {fmtWind(data.windSpeed)} {windUnit(data.units)}
          </span>
        </div>
      </div>

      <div className="wx-place" title={data.place}>
        {data.place}
      </div>
    </div>
  );
}
