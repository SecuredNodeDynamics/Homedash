import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "weather",
  name: "Weather",
  description: "Current conditions via Open-Meteo",
  version: "0.2.0",
  category: "General",
  defaultSize: { w: 3, h: 4, minW: 2, minH: 3 },
  configFields: [
    {
      key: "location",
      label: "Location (optional)",
      type: "text",
      placeholder: "Auto-detect, or type a city",
    },
    {
      key: "units",
      label: "Units",
      type: "select",
      options: [
        { value: "imperial", label: "Imperial (°F, mph)" },
        { value: "metric", label: "Metric (°C, km/h)" },
      ],
    },
    {
      key: "latitude",
      label: "Latitude",
      type: "number",
      placeholder: "Auto-filled from device",
    },
    {
      key: "longitude",
      label: "Longitude",
      type: "number",
      placeholder: "Auto-filled from device",
    },
  ],
};
