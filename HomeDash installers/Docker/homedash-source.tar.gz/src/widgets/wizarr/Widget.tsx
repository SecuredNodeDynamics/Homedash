"use client";
import "@/styles/widgets/wizarr.widget.css";


import { useCallback, useEffect, useMemo, useState, useLayoutEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useOpenHref } from "@/widgets/_shared/use-open-href";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";
import type {
  WizarrInvitation,
  WizarrServer,
  WizarrUser,
} from "@/lib/widgets/wizarr";

type Tab = "overview" | "users" | "invitations";

type ConnectionSource = "private" | "public" | "unknown";

type Data = {
  href: string;
  openFallbackUrl?: string;
  users: WizarrUser[];
  invitations: WizarrInvitation[];
  servers: WizarrServer[];
  connectionSource?: ConnectionSource;
};

const CONNECTION_SOURCE_LABEL: Record<ConnectionSource, string> = {
  private: "Connected via Private URL (LAN)",
  public: "Connected via Public URL (Cloudflare)",
  unknown: "Connection source unknown",
};

function ConnectionCorner({ source }: { source: ConnectionSource }) {
  const probeRef = useRef<HTMLSpanElement>(null);
  const [host, setHost] = useState<Element | null>(null);
  useLayoutEffect(() => {
    setHost(probeRef.current?.closest(".hd-widget") ?? null);
  }, []);
  if (source === "unknown") return <span ref={probeRef} hidden />;
  const mark = (
    <div
      className={`wzr-corner-source wzr-corner-source--${source}`}
      title={CONNECTION_SOURCE_LABEL[source]}
      aria-label={CONNECTION_SOURCE_LABEL[source]}
    />
  );
  return (
    <>
      <span ref={probeRef} hidden />
      {host ? createPortal(mark, host) : mark}
    </>
  );
}


function fmtDate(iso?: string) {
  if (!iso) return "—";
  const date = new Date(iso);
  return Number.isNaN(date.getTime())
    ? "—"
    : date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

function fmtNum(n: number) {
  return n.toLocaleString();
}

function timeUntil(iso?: string) {
  if (!iso) return "Never";
  const diff = new Date(iso).getTime() - Date.now();
  if (diff <= 0) return "Expired";
  const days = Math.floor(diff / 86400000);
  const hrs = Math.floor((diff % 86400000) / 3600000);
  if (days > 0) return `${days}d ${hrs}h`;
  const mins = Math.floor((diff % 3600000) / 60000);
  if (hrs > 0) return `${hrs}h ${mins}m`;
  return `${mins}m`;
}

function isInviteActive(inv: WizarrInvitation) {
  if (inv.status === "expired") return false;
  if (!inv.expires) return true;
  return new Date(inv.expires).getTime() > Date.now();
}

function CreateInviteModal({
  servers,
  instanceId,
  onClose,
  onCreated,
}: {
  servers: WizarrServer[];
  instanceId: string;
  onClose: () => void;
  onCreated: () => void;
}) {
  const [serverId, setServerId] = useState(String(servers[0]?.id ?? ""));
  const [label, setLabel] = useState("");
  const [expires, setExpires] = useState("");
  const [duration, setDuration] = useState("unlimited");
  const [allowDownloads, setAllowDownloads] = useState(false);
  const [allowLiveTv, setAllowLiveTv] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [resultUrl, setResultUrl] = useState("");
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = overflow;
      window.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  async function submit() {
    setBusy(true);
    setError("");
    setResultUrl("");
    try {
      const response = await fetch("/api/widgets/wizarr/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          instance: instanceId,
          action: "create",
          server_ids: serverId,
          duration,
          allow_downloads: allowDownloads,
          allow_live_tv: allowLiveTv,
          expires_in_days: expires ? Number(expires) : undefined,
          label: label.trim() || undefined,
        }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to create invitation");
      setResultUrl(json.url || "");
      onCreated();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to create invitation");
    } finally {
      setBusy(false);
    }
  }

  const selectedServer = servers.find((server) => String(server.id) === serverId);
  const expiryLabel = expires ? `${expires} day${expires === "1" ? "" : "s"}` : "Never expires";
  const durationLabel = duration === "unlimited" ? "Unlimited access" : `${duration} days access`;

  return createPortal(
    <div className="wzr-modal-overlay" onClick={(event) => event.target === event.currentTarget && onClose()}>
      <div className="wzr-modal" role="dialog" aria-modal="true" aria-label="Create Invitation">
        <div className="wzr-modal-hdr">
          <div className="wzr-modal-heading">
            <span className="wzr-modal-mark" aria-hidden="true">✦</span>
            <div>
              <span className="wzr-modal-eyebrow">Wizarr invitation</span>
              <span className="wzr-modal-title">{resultUrl ? "Invitation ready" : "Create an invitation"}</span>
              <p>{resultUrl ? "Share this secure link with your new member." : "Configure server access for a new member."}</p>
            </div>
          </div>
          <button className="wzr-modal-close" type="button" aria-label="Close" onClick={onClose}>
            ×
          </button>
        </div>
        {resultUrl ? (
          <div className="wzr-invite-success">
            <div className="wzr-invite-success__icon">✓</div>
            <div>
              <strong>{label.trim() || "New invitation"}</strong>
              <span>{selectedServer?.name || "Media server"} · {expiryLabel} · {durationLabel}</span>
            </div>
            <div className="wzr-modal-result">
              <div className="wzr-result-label">Invitation link</div>
              <div className="wzr-result-row">
                <input className="wzr-input wzr-result-input" type="text" readOnly value={resultUrl} />
                <button
                  className="wzr-copy-btn"
                  type="button"
                  onClick={async () => {
                    try {
                      await navigator.clipboard.writeText(resultUrl);
                      setCopied(true);
                      window.setTimeout(() => setCopied(false), 2000);
                    } catch {
                      setError("Could not copy the link. Select and copy it manually.");
                    }
                  }}
                >
                  {copied ? "Copied!" : "Copy link"}
                </button>
              </div>
            </div>
            {error ? <div className="wzr-modal-error">{error}</div> : null}
          </div>
        ) : (
          <div className="wzr-modal-body">
            <section className="wzr-invite-section">
              <div className="wzr-invite-section__head">
                <span>1</span>
                <div><strong>Invitation details</strong><small>Choose the destination server and a recognizable label.</small></div>
              </div>
              <div className="wzr-field-row">
                <div className="wzr-field">
                  <label className="wzr-label">Server</label>
                  <select className="wzr-input" value={serverId} onChange={(event) => setServerId(event.target.value)}>
                    {servers.length ? servers.map((server) => (
                      <option key={String(server.id)} value={String(server.id)}>
                        {server.name || `Server ${server.id}`}
                      </option>
                    )) : <option value="">No servers found</option>}
                  </select>
                </div>
                <div className="wzr-field">
                  <label className="wzr-label">Invitation label <span className="wzr-label-hint">Optional</span></label>
                  <input className="wzr-input" type="text" placeholder="Friends & Family" value={label} onChange={(event) => setLabel(event.target.value)} />
                </div>
              </div>
            </section>

            <section className="wzr-invite-section">
              <div className="wzr-invite-section__head">
                <span>2</span>
                <div><strong>Access window</strong><small>Control when the link expires and how long membership lasts.</small></div>
              </div>
              <div className="wzr-field-row">
                <div className="wzr-field">
                  <label className="wzr-label">Invite expires</label>
                  <select className="wzr-input" value={expires} onChange={(event) => setExpires(event.target.value)}>
                    <option value="">Never expires</option>
                    <option value="1">In 1 day</option>
                    <option value="3">In 3 days</option>
                    <option value="7">In 7 days</option>
                    <option value="14">In 14 days</option>
                    <option value="30">In 30 days</option>
                    <option value="90">In 90 days</option>
                  </select>
                </div>
                <div className="wzr-field">
                  <label className="wzr-label">Member access</label>
                  <select className="wzr-input" value={duration} onChange={(event) => setDuration(event.target.value)}>
                    <option value="unlimited">Unlimited access</option>
                    <option value="7">7 days access</option>
                    <option value="30">30 days access</option>
                    <option value="90">90 days access</option>
                    <option value="180">180 days access</option>
                    <option value="365">1 year access</option>
                  </select>
                </div>
              </div>
            </section>

            <section className="wzr-invite-section">
              <div className="wzr-invite-section__head">
                <span>3</span>
                <div><strong>Permissions</strong><small>Optional capabilities granted to the new member.</small></div>
              </div>
              <div className="wzr-permission-grid">
                <label className={`wzr-permission-card${allowDownloads ? " is-enabled" : ""}`}>
                  <input type="checkbox" checked={allowDownloads} onChange={(event) => setAllowDownloads(event.target.checked)} />
                  <span aria-hidden="true">↓</span>
                  <div><strong>Downloads</strong><small>Allow offline media downloads</small></div>
                </label>
                <label className={`wzr-permission-card${allowLiveTv ? " is-enabled" : ""}`}>
                  <input type="checkbox" checked={allowLiveTv} onChange={(event) => setAllowLiveTv(event.target.checked)} />
                  <span aria-hidden="true">◉</span>
                  <div><strong>Live TV</strong><small>Allow access to live channels</small></div>
                </label>
              </div>
            </section>

            <div className="wzr-invite-review">
              <span>Invite summary</span>
              <strong>{selectedServer?.name || "No server"} · {expiryLabel} · {durationLabel}</strong>
            </div>
            {error ? <div className="wzr-modal-error">{error}</div> : null}
          </div>
        )}
        <div className="wzr-modal-footer">
          {resultUrl ? (
            <>
              <button className="wzr-btn wzr-btn--ghost" type="button" onClick={onClose}>Done</button>
              <a className="wzr-btn wzr-btn--primary" href={resultUrl} target="_blank" rel="noopener noreferrer">Open invitation</a>
            </>
          ) : (
            <>
              <button className="wzr-btn wzr-btn--ghost" type="button" onClick={onClose}>Cancel</button>
              <button className="wzr-btn wzr-btn--primary" type="button" disabled={busy || !serverId} onClick={submit}>
                {busy ? "Creating invitation…" : "Create invitation"}
              </button>
            </>
          )}
        </div>
      </div>
    </div>,
    document.body,
  );
}

export default function WizarrWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "wizarr";
  const [data, setData] = useState<Data | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<Tab>("overview");
  const [createOpen, setCreateOpen] = useState(false);
  const [deleting, setDeleting] = useState<string | null>(null);
  const openHref = useOpenHref(data?.href, data?.openFallbackUrl);

  const load = useCallback(async () => {
    try {
      const response = await fetch(
        `/api/widgets/wizarr/status?instance=${encodeURIComponent(instanceId)}`,
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load Wizarr");
      setData(json);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Wizarr unavailable");
    } finally {
      setLoading(false);
    }
  }, [instanceId]);

  const { rootRef } = useWidgetPoll(load, { intervalMs: 60_000 });

  const activeInvites = useMemo(
    () => (data?.invitations || []).filter(isInviteActive).length,
    [data?.invitations],
  );

  async function deleteInvite(id: string) {
    setDeleting(id);
    try {
      const response = await fetch("/api/widgets/wizarr/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instance: instanceId, action: "delete", id }),
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Delete failed");
      await load();
    } catch {
      /* keep list; user can retry */
    } finally {
      setDeleting(null);
    }
  }

  const content = (() => {
    if (!data) return null;
    if (tab === "overview") {
      const totalUsers = data.users.length;
      const totalInvites = data.invitations.length;
      const expiredInvites = totalInvites - activeInvites;
      const recentUsers = [...data.users]
        .filter((user) => user.created_at || user.createdAt)
        .sort(
          (a, b) =>
            new Date(b.created_at || b.createdAt || 0).getTime() -
            new Date(a.created_at || a.createdAt || 0).getTime(),
        )
        .slice(0, 3);

      return (
        <>
          <div className="wzr-stat-grid">
            <div className="wzr-stat wzr-stat--good">
              <div className="wzr-stat-value">{fmtNum(totalUsers)}</div>
              <div className="wzr-stat-label">Total Users</div>
            </div>
            <div className="wzr-stat wzr-stat--active">
              <div className="wzr-stat-value">{fmtNum(activeInvites)}</div>
              <div className="wzr-stat-label">Active Invites</div>
            </div>
            <div className="wzr-stat">
              <div className="wzr-stat-value">{fmtNum(data.servers.length)}</div>
              <div className="wzr-stat-label">Servers</div>
            </div>
            <div className="wzr-stat wzr-stat--warn">
              <div className="wzr-stat-value">{fmtNum(expiredInvites)}</div>
              <div className="wzr-stat-label">Expired Invites</div>
            </div>
            <div className="wzr-stat">
              <div className="wzr-stat-value">{fmtNum(totalInvites)}</div>
              <div className="wzr-stat-label">Total Invites</div>
            </div>
            <div className="wzr-stat wzr-stat--good">
              <div className="wzr-stat-value">{fmtNum(recentUsers.length)}</div>
              <div className="wzr-stat-label">New (Recent)</div>
            </div>
          </div>
          {recentUsers.length ? (
            <>
              <div className="wzr-section-label">Recently Joined</div>
              {recentUsers.map((user) => (
                <div className="wzr-row" key={String(user.id || user.username)}>
                  <span className="wzr-dot wzr-dot--good" />
                  <div className="wzr-row-body">
                    <div className="wzr-row-title">{user.username || user.email || "Unknown"}</div>
                    <div className="wzr-row-sub">
                      Joined {fmtDate(user.created_at || user.createdAt)}
                    </div>
                  </div>
                  <div className="wzr-row-meta">
                    <span className="wzr-badge wzr-badge--good">Member</span>
                  </div>
                </div>
              ))}
            </>
          ) : null}
        </>
      );
    }

    if (tab === "users") {
      if (!data.users.length) return <div className="wzr-empty">No users found</div>;
      return data.users.map((user) => {
        const name = user.username || user.email || "Unknown";
        const server = user.server || user.media_server || "";
        return (
          <div className="wzr-row" key={String(user.id || name)}>
            <span className="wzr-dot wzr-dot--good" />
            <div className="wzr-row-body">
              <div className="wzr-row-title">{name}</div>
              <div className="wzr-row-sub">
                Joined {fmtDate(user.created_at || user.createdAt)}
                {server ? ` · ${server}` : ""}
              </div>
            </div>
            <div className="wzr-row-meta">
              <span className="wzr-badge wzr-badge--good">Member</span>
            </div>
          </div>
        );
      });
    }

    if (!data.invitations.length) return <div className="wzr-empty">No invitations found</div>;
    const sorted = [...data.invitations].sort((a, b) => {
      const aExp = a.expires ? new Date(a.expires).getTime() : Number.POSITIVE_INFINITY;
      const bExp = b.expires ? new Date(b.expires).getTime() : Number.POSITIVE_INFINITY;
      return aExp - bExp;
    });

    return sorted.map((inv) => {
      const expired = !isInviteActive(inv);
      const unlimited = !inv.expires;
      const code = inv.code || inv.token || inv.id || "—";
      const uses = inv.used_by != null ? inv.used_by : inv.uses != null ? inv.uses : "—";
      const maxUses = inv.unlimited ? "∞" : inv.max_uses || "∞";
      return (
        <div className="wzr-row" key={String(inv.id || code)}>
          <span className={`wzr-dot ${expired ? "wzr-dot--warn" : "wzr-dot--good"}`} />
          <div className="wzr-row-body">
            <div className="wzr-row-title">{inv.label || inv.display_name || String(code)}</div>
            <div className="wzr-row-sub">
              Code: {String(code)} · Uses: {String(uses)}/{String(maxUses)}
              {inv.expires ? ` · Expires: ${fmtDate(inv.expires)}` : " · No expiry"}
            </div>
          </div>
          <div className="wzr-row-meta">
            <span className={`wzr-badge ${expired ? "wzr-badge--warn" : "wzr-badge--active"}`}>
              {expired ? "Expired" : unlimited ? "Active" : timeUntil(inv.expires)}
            </span>
            {expired && inv.id != null ? (
              <button
                className="wzr-delete-btn"
                type="button"
                title="Delete invitation"
                disabled={deleting === String(inv.id)}
                onClick={() => deleteInvite(String(inv.id))}
              >
                ✕
              </button>
            ) : null}
          </div>
        </div>
      );
    });
  })();

  if (loading && !data) {
    return (
      <div className="hd-widget-body wzr-body-flat" ref={rootRef}>
        <div className="wzr-toolbar">
          <span className="wzr-status-pill wzr-status-pill--loading">
            <span className="wzr-status-dot" />
            Loading
          </span>
        </div>
        <div className="wzr-loading">Loading…</div>
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="hd-widget-body wzr-body-flat" ref={rootRef}>
        <div className="wzr-toolbar">
          <span className="wzr-status-pill wzr-status-pill--offline">
            <span className="wzr-status-dot" />
            Offline
          </span>
        </div>
        <div className="wzr-empty" style={{ color: "#f87171" }}>
          {error}
        </div>
        <button className="wzr-btn wzr-btn--ghost" type="button" onClick={load}>
          Retry
        </button>
      </div>
    );
  }

  const connectionSource: ConnectionSource = data?.connectionSource || "unknown";

  return (
    <div className="hd-widget-body wzr-body-flat" ref={rootRef}>
      <ConnectionCorner source={connectionSource} />
      <div className="wzr-toolbar">
        <div className="wzr-toolbar-left">
          <span className="wzr-status-pill wzr-status-pill--online">
            <span className="wzr-status-dot" />
            Online
          </span>
        </div>
        <div className="wzr-toolbar-right">
          <button className="wzr-create-btn" type="button" onClick={() => setCreateOpen(true)}>
            + Create
          </button>
          {openHref ? (
            <a className="wzr-open-link" href={openHref} target="_blank" rel="noopener noreferrer">
              Open
            </a>
          ) : null}
        </div>
      </div>

      <div className="wzr-controls">
        <div className="wzr-tabs">
          {(
            [
              { key: "overview", label: "Overview" },
              { key: "users", label: "Users" },
              { key: "invitations", label: "Invites" },
            ] as const
          ).map((item) => (
            <button
              key={item.key}
              type="button"
              className={`wzr-tab${tab === item.key ? " wzr-tab--active" : ""}`}
              onClick={() => setTab(item.key)}
            >
              {item.label}
              {item.key === "invitations" && activeInvites ? (
                <span className="wzr-tab-badge">{activeInvites}</span>
              ) : null}
            </button>
          ))}
        </div>
      </div>

      <div className="wzr-scroll wzr-scroll--scrollable">
        {content}
      </div>

      {createOpen ? (
        <CreateInviteModal
          servers={data?.servers || []}
          instanceId={instanceId}
          onClose={() => setCreateOpen(false)}
          onCreated={() => {
            window.setTimeout(() => {
              void load();
            }, 400);
          }}
        />
      ) : null}
    </div>
  );
}
