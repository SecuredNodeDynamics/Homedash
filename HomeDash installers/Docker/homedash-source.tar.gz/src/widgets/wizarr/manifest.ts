import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "wizarr",
  name: "Wizarr",
  description: "Invite users and manage Wizarr servers",
  version: "0.2.3",
  category: "Media",
  defaultSize: { w: 4, h: 5, minW: 3, minH: 3 },
  configFields: [
    {
      key: "baseUrl",
      label: "Private - IP",
      type: "url",
      placeholder: "http://10.0.0.1:5690",
    },
    {
      key: "fallbackUrl",
      label: "Fallback Public URL",
      type: "url",
      placeholder: "https://wizarr.example.com",
    },
    {
      key: "publicUrl",
      label: "OPEN - Private URL",
      type: "url",
      placeholder: "http://10.0.0.1:5690",
    },
    { key: "openFallbackUrl", label: "OPEN - Public URL", type: "url", placeholder: "https://… (Cloudflare)" },
    { key: "apiKey", label: "API Key", type: "password", required: true },
  ],
};
