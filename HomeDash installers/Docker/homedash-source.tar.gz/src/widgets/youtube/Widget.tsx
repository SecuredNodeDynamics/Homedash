"use client";
import "@/styles/widgets/youtube.widget.css";


import { useCallback, useEffect, useMemo, useState } from "react";
import { useWidgetInstance } from "@/widgets/_shared/instance-context";
import { useWidgetPoll } from "@/widgets/_shared/use-widget-poll";

type TabKey = "live" | "saved";

type YtVideo = {
  id: string;
  title: string;
  channel: string;
  thumbnail: string;
  publishedAt?: string;
  savedAt?: number;
};

const TABS: { key: TabKey; label: string }[] = [
  { key: "live", label: "Live" },
  { key: "saved", label: "Saved" },
];

function storageKey(instanceId: string) {
  return `homedash.youtube.saved.${instanceId}`;
}

function thumbFor(id: string) {
  return `https://i.ytimg.com/vi/${encodeURIComponent(id)}/hqdefault.jpg`;
}

function embedFor(id: string) {
  return `https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}?autoplay=1&rel=0`;
}

function watchFor(id: string) {
  return `https://www.youtube.com/watch?v=${encodeURIComponent(id)}`;
}

function formatDate(value?: string | number) {
  if (!value) return "";
  const date = typeof value === "number" ? new Date(value) : new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

function readSaved(instanceId: string): YtVideo[] {
  try {
    const raw = localStorage.getItem(storageKey(instanceId));
    if (!raw) return [];
    const parsed = JSON.parse(raw) as YtVideo[];
    return Array.isArray(parsed) ? parsed.filter((item) => item?.id) : [];
  } catch {
    return [];
  }
}

function writeSaved(instanceId: string, items: YtVideo[]) {
  localStorage.setItem(storageKey(instanceId), JSON.stringify(items));
}

async function enrichVideo(video: YtVideo): Promise<YtVideo> {
  if (video.title && video.title !== `Video ${video.id}` && video.channel !== "YouTube") {
    return video;
  }
  try {
    const response = await fetch(
      `https://www.youtube.com/oembed?url=${encodeURIComponent(watchFor(video.id))}&format=json`,
    );
    if (!response.ok) return video;
    const json = (await response.json()) as { title?: string; author_name?: string; thumbnail_url?: string };
    return {
      ...video,
      title: json.title || video.title,
      channel: json.author_name || video.channel,
      thumbnail: json.thumbnail_url || video.thumbnail || thumbFor(video.id),
    };
  } catch {
    return video;
  }
}

function VideoCard({
  video,
  active,
  saved,
  onPlay,
  onToggleSave,
}: {
  video: YtVideo;
  active: boolean;
  saved: boolean;
  onPlay: () => void;
  onToggleSave: () => void;
}) {
  return (
    <article className={`yt-card${active ? " yt-card--active" : ""}`}>
      <button type="button" className="yt-card-media" onClick={onPlay} title={video.title}>
        {video.thumbnail ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={video.thumbnail || thumbFor(video.id)} alt="" loading="lazy" />
        ) : (
          <div className="yt-card-fallback">▶</div>
        )}
        <span className="yt-card-play" aria-hidden="true">
          ▶
        </span>
      </button>
      <div className="yt-card-body">
        <button type="button" className="yt-card-copy" onClick={onPlay}>
          <div className="yt-card-title">{video.title}</div>
          <div className="yt-card-sub">
            {[video.channel, formatDate(video.publishedAt || video.savedAt)].filter(Boolean).join(" · ")}
          </div>
        </button>
        <button
          type="button"
          className={`yt-save-btn${saved ? " yt-save-btn--on" : ""}`}
          aria-label={saved ? "Remove from saved" : "Save video"}
          title={saved ? "Remove from saved" : "Save video"}
          onClick={onToggleSave}
        >
          {saved ? "★" : "☆"}
        </button>
      </div>
    </article>
  );
}

export default function YoutubeWidget() {
  const instance = useWidgetInstance();
  const instanceId = instance?.instanceId || "youtube";

  const [tab, setTab] = useState<TabKey>("live");
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<YtVideo[]>([]);
  const [saved, setSaved] = useState<YtVideo[]>([]);
  const [active, setActive] = useState<YtVideo | null>(null);
  const [searching, setSearching] = useState(false);
  const [error, setError] = useState("");
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    const items = readSaved(instanceId);
    setSaved(items);
    setHydrated(true);
  }, [instanceId]);

  useEffect(() => {
    if (!hydrated) return;
    writeSaved(instanceId, saved);
  }, [hydrated, instanceId, saved]);

  const savedIds = useMemo(() => new Set(saved.map((item) => item.id)), [saved]);

  const loadSuggestions = useCallback(async () => {
    setSearching(true);
    try {
      const response = await fetch(
        `/api/widgets/youtube/search?instance=${encodeURIComponent(instanceId)}&mode=channels`,
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Failed to load videos");
      const items = ((json.items || []) as YtVideo[]).map((item) => ({
        ...item,
        thumbnail: item.thumbnail || thumbFor(item.id),
      }));
      setResults(items);
      if (!items.length) {
        setError("No suggestion videos found. Add channel IDs or an API key in Settings.");
      } else {
        setError("");
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Failed to load videos");
      setResults([]);
    } finally {
      setSearching(false);
    }
  }, [instanceId]);

  const { rootRef } = useWidgetPoll(loadSuggestions, { intervalMs: 300_000 });

  const play = useCallback(async (video: YtVideo) => {
    const enriched = await enrichVideo({
      ...video,
      thumbnail: video.thumbnail || thumbFor(video.id),
    });
    setActive(enriched);
    setTab("live");
    setError("");
  }, []);

  const closePlayer = useCallback(() => {
    setActive(null);
  }, []);

  const toggleSave = useCallback(
    async (video: YtVideo) => {
      const enriched = await enrichVideo({
        ...video,
        thumbnail: video.thumbnail || thumbFor(video.id),
      });
      setSaved((prev) => {
        if (prev.some((item) => item.id === enriched.id)) {
          return prev.filter((item) => item.id !== enriched.id);
        }
        return [{ ...enriched, savedAt: Date.now() }, ...prev].slice(0, 100);
      });
    },
    [],
  );

  const runSearch = useCallback(async () => {
    const q = query.trim();
    if (!q) {
      void loadSuggestions();
      return;
    }
    setSearching(true);
    setError("");
    try {
      const response = await fetch(
        `/api/widgets/youtube/search?instance=${encodeURIComponent(instanceId)}&q=${encodeURIComponent(q)}`,
      );
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || "Search failed");
      const items = (json.items || []) as YtVideo[];
      setResults(items);
      if (json.direct && items[0]) {
        await play(items[0]);
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Search failed");
      setResults([]);
    } finally {
      setSearching(false);
    }
  }, [instanceId, loadSuggestions, play, query]);

  const list = tab === "live" ? results : saved;
  const showPlayer = tab === "live" && !!active;

  return (
    <div className="hd-widget-body yt-body-flat" ref={rootRef}>
      <div className="yt-shell">
        <div className="yt-toolbar">
          <div className="yt-toolbar-left">
            <span className="yt-status-pill yt-status-pill--ok">
              <span className="yt-status-dot" aria-hidden="true" />
              Online
            </span>
            <span className="yt-meta">
              {tab === "saved"
                ? `${saved.length} saved`
                : showPlayer
                  ? "Playing"
                  : "Ready"}
            </span>
          </div>
          <div className="yt-toolbar-right">
            {showPlayer ? (
              <button type="button" className="yt-open-btn yt-close-btn" onClick={closePlayer}>
                Close
              </button>
            ) : null}
            <a
              className="yt-open-btn"
              href={active ? watchFor(active.id) : "https://www.youtube.com/"}
              target="_blank"
              rel="noopener noreferrer"
            >
              Open
            </a>
          </div>
        </div>

        <div className="yt-controls">
          <div className="yt-tabs" role="tablist" aria-label="YouTube sections">
            {TABS.map((item) => (
              <button
                key={item.key}
                type="button"
                role="tab"
                aria-selected={tab === item.key}
                className={`yt-tab${tab === item.key ? " yt-tab--active" : ""}`}
                onClick={() => setTab(item.key)}
              >
                {item.label}
                {item.key === "saved" && saved.length ? (
                  <span className="yt-tab-count">{saved.length}</span>
                ) : null}
              </button>
            ))}
          </div>
        </div>

        {tab === "live" ? (
          <form
            className="yt-search-bar"
            onSubmit={(event) => {
              event.preventDefault();
              void runSearch();
            }}
          >
            <input
              className="yt-search"
              type="search"
              placeholder="Search YouTube or paste a video URL…"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              autoComplete="off"
            />
            <button className="yt-search-btn" type="submit" disabled={searching}>
              {searching ? "…" : "Search"}
            </button>
          </form>
        ) : null}

        <div
          className={`yt-layout${showPlayer ? " yt-layout--playing" : " yt-layout--browse"}${
            tab === "saved" ? " yt-layout--saved" : ""
          }`}
        >
          {showPlayer && active ? (
            <div className="yt-player-pane">
              <div className="yt-player">
                <iframe
                  title={active.title}
                  src={embedFor(active.id)}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                />
                <button
                  type="button"
                  className="yt-player-close"
                  aria-label="Close video"
                  title="Close video"
                  onClick={closePlayer}
                >
                  ✕
                </button>
              </div>
              <div className="yt-now">
                <div className="yt-now-main">
                  <div className="yt-now-title">{active.title}</div>
                  <div className="yt-now-sub">{active.channel || "YouTube"}</div>
                </div>
                <div className="yt-now-actions">
                  <button
                    type="button"
                    className={`yt-save-btn yt-save-btn--lg${savedIds.has(active.id) ? " yt-save-btn--on" : ""}`}
                    onClick={() => void toggleSave(active)}
                  >
                    {savedIds.has(active.id) ? "Saved" : "Save"}
                  </button>
                  <button type="button" className="yt-close-btn yt-close-btn--text" onClick={closePlayer}>
                    Close
                  </button>
                </div>
              </div>
            </div>
          ) : null}

          <div className="yt-list-pane">
            <div className="yt-list-label">
              {tab === "live" ? (query.trim() ? "Results" : "Videos") : "Saved videos"}
            </div>
            {error && tab === "live" ? <div className="yt-error">{error}</div> : null}
            {list.length ? (
              <div className={`yt-card-grid${tab === "saved" ? " yt-card-grid--saved" : ""}`}>
                {list.map((video) => (
                  <VideoCard
                    key={`${tab}-${video.id}`}
                    video={video}
                    active={tab === "live" && active?.id === video.id}
                    saved={savedIds.has(video.id)}
                    onPlay={() => void play(video)}
                    onToggleSave={() => void toggleSave(video)}
                  />
                ))}
              </div>
            ) : (
              <div className="yt-empty">
                {tab === "saved"
                  ? "No saved videos yet. Save one from Live."
                  : searching
                    ? "Loading videos…"
                    : "Search for a video, or add channel IDs / an API key in Settings."}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
