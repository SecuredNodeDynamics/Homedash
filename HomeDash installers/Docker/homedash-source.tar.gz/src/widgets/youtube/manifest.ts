import type { WidgetManifest } from "@/lib/types";

export const manifest: WidgetManifest = {
  id: "youtube",
  name: "YouTube",
  description: "Search, watch, and save YouTube videos (Live / Saved tabs)",
  version: "0.3.0",
  category: "General",
  defaultSize: { w: 6, h: 6, minW: 4, minH: 4 },
  hostClass: "yt-feed-host",
  configFields: [
    {
      key: "apiKey",
      label: "YouTube Data API Key",
      type: "password",
      placeholder: "AIza…",
      required: false,
    },
    {
      key: "channels",
      label: "Channel IDs (comma-separated, optional Live suggestions)",
      placeholder: "UC…",
    },
  ],
};
