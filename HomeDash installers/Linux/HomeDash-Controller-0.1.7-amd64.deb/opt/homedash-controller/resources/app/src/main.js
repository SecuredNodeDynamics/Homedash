const { app, BrowserWindow, dialog, ipcMain, Menu, shell } = require("electron");
const fs = require("node:fs/promises");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

const CONNECT_PAGE = path.join(__dirname, "renderer", "connect.html");
const HIDE_DOCUMENT_SCROLLBAR_CSS = `
  html, body {
    scrollbar-width: none !important;
    -ms-overflow-style: none !important;
  }
  html::-webkit-scrollbar,
  body::-webkit-scrollbar {
    width: 0 !important;
    height: 0 !important;
    display: none !important;
  }
`;
let mainWindow;
let connectedServer = null;

function configPath() {
  return path.join(app.getPath("userData"), "connection.json");
}

async function readConnection() {
  try {
    const parsed = JSON.parse(await fs.readFile(configPath(), "utf8"));
    return typeof parsed.serverUrl === "string" ? parsed.serverUrl : "";
  } catch {
    return "";
  }
}

async function saveConnection(serverUrl) {
  await fs.mkdir(path.dirname(configPath()), { recursive: true });
  await fs.writeFile(configPath(), JSON.stringify({ serverUrl }, null, 2), "utf8");
}

function normalizeServerUrl(value) {
  const candidate = String(value || "").trim();
  if (!candidate) throw new Error("Enter your HomeDash server address.");
  let url;
  try {
    url = new URL(candidate.includes("://") ? candidate : `http://${candidate}`);
  } catch {
    throw new Error("Enter a valid server address, such as https://dash.example.com.");
  }
  if (!["http:", "https:"].includes(url.protocol)) {
    throw new Error("The server address must use HTTP or HTTPS.");
  }
  if (url.username || url.password) throw new Error("Do not include credentials in the server address.");
  url.hash = "";
  url.search = "";
  url.pathname = url.pathname.replace(/\/+$/, "");
  return url.toString().replace(/\/$/, "");
}

async function testConnection(rawUrl) {
  const serverUrl = normalizeServerUrl(rawUrl);
  const abort = new AbortController();
  const timer = setTimeout(() => abort.abort(), 10_000);
  try {
    const response = await fetch(`${serverUrl}/api/controller/ping`, {
      signal: abort.signal,
      headers: { Accept: "application/json" },
      redirect: "follow",
    });
    if (response.ok) {
      const body = await response.json();
      if (body?.service !== "homedash" || body?.controllerApi !== 1) {
        throw new Error("This server is not a compatible HomeDash server.");
      }
      return { serverUrl, version: body.version || "unknown" };
    }

    // Older HomeDash releases return 401 before this compatibility endpoint
    // reaches its route. Verify their public Next.js login/setup page instead.
    if (![401, 404].includes(response.status)) {
      throw new Error(`Server returned HTTP ${response.status}.`);
    }
    const legacyResponse = await fetch(`${serverUrl}/login`, {
      signal: abort.signal,
      headers: { Accept: "text/html" },
      redirect: "follow",
    });
    const contentType = legacyResponse.headers.get("content-type") || "";
    const html = legacyResponse.ok && contentType.includes("text/html")
      ? await legacyResponse.text()
      : "";
    const finalUrl = new URL(legacyResponse.url);
    const isLoginPage = ["/login", "/setup"].includes(finalUrl.pathname);
    const isNextApplication = html.includes("/_next/") || html.includes("/_next/static/");
    if (!legacyResponse.ok || !isLoginPage || !isNextApplication) {
      throw new Error(`Server returned HTTP ${response.status} and could not be verified as HomeDash.`);
    }
    return { serverUrl: finalUrl.origin, version: "legacy" };
  } catch (error) {
    if (error?.name === "AbortError") throw new Error("The server did not respond within 10 seconds.");
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function showConnectionScreen() {
  connectedServer = null;
  await mainWindow.loadURL(pathToFileURL(CONNECT_PAGE).href);
}

async function restoreSavedConnection() {
  const savedServer = await readConnection();
  if (!savedServer) return false;

  try {
    const result = await testConnection(savedServer);
    connectedServer = result.serverUrl;
    await mainWindow.loadURL(`${connectedServer}/login`);
    return true;
  } catch {
    return false;
  }
}

async function connect(serverUrl) {
  const result = await testConnection(serverUrl);
  await saveConnection(result.serverUrl);
  connectedServer = result.serverUrl;
  await mainWindow.loadURL(`${connectedServer}/login`);
  return result;
}

function buildMenu() {
  return Menu.buildFromTemplate([
    {
      label: "HomeDash",
      submenu: [
        { label: "Change server", accelerator: "CmdOrCtrl+Shift+S", click: showConnectionScreen },
        { type: "separator" },
        { role: "quit" },
      ],
    },
    {
      label: "View",
      submenu: [
        { role: "reload" },
        { role: "togglefullscreen" },
        { type: "separator" },
        { role: "resetzoom" },
        { role: "zoomin" },
        { role: "zoomout" },
      ],
    },
  ]);
}

async function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 860,
    minHeight: 600,
    backgroundColor: "#070b17",
    icon: path.join(__dirname, "..", "assets", "homedash-logo.png"),
    show: false,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  Menu.setApplicationMenu(buildMenu());
  mainWindow.once("ready-to-show", () => mainWindow.show());
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    try {
      const target = new URL(url);
      if (connectedServer && target.origin === new URL(connectedServer).origin) return { action: "allow" };
      if (["http:", "https:"].includes(target.protocol)) shell.openExternal(url);
    } catch {}
    return { action: "deny" };
  });
  mainWindow.webContents.on("will-navigate", (event, url) => {
    if (!connectedServer) return;
    try {
      if (new URL(url).origin === new URL(connectedServer).origin) return;
      event.preventDefault();
      if (["http:", "https:"].includes(new URL(url).protocol)) shell.openExternal(url);
    } catch {
      event.preventDefault();
    }
  });
  mainWindow.webContents.on("did-finish-load", async () => {
    if (!connectedServer) return;
    try {
      const loadedOrigin = new URL(mainWindow.webContents.getURL()).origin;
      if (loadedOrigin === new URL(connectedServer).origin) {
        await mainWindow.webContents.insertCSS(HIDE_DOCUMENT_SCROLLBAR_CSS);
      }
    } catch (error) {
      console.warn("Could not hide the document scrollbar:", error);
    }
  });

  const restored = await restoreSavedConnection();
  if (!restored) {
    await showConnectionScreen();
  }
}

ipcMain.handle("connection:default", readConnection);
ipcMain.handle("connection:test", async (_event, value) => testConnection(value));
ipcMain.handle("connection:connect", async (_event, value) => connect(value));

app.whenReady().then(createWindow).catch((error) => {
  console.error(error);
  dialog.showErrorBox(
    "HomeDash Controller could not start",
    error?.message || "An unexpected startup error occurred.",
  );
  app.quit();
});
app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
