const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("homeDash", {
  defaultServer: () => ipcRenderer.invoke("connection:default"),
  test: (serverUrl) => ipcRenderer.invoke("connection:test", serverUrl),
  connect: (serverUrl) => ipcRenderer.invoke("connection:connect", serverUrl),
});
