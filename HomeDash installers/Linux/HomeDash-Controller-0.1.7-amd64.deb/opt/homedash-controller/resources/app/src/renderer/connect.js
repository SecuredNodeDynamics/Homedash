const form = document.querySelector("#connection-form");
const input = document.querySelector("#server-url");
const testButton = document.querySelector("#test-button");
const connectButton = document.querySelector("#connect-button");
const status = document.querySelector("#status");

function setBusy(busy) {
  input.disabled = busy;
  testButton.disabled = busy;
  connectButton.disabled = busy;
}

function setStatus(message, kind = "") {
  status.textContent = message;
  status.className = `status ${kind}`;
}

function messageFrom(error) {
  const message = error?.message || "Could not connect to the server.";
  return message.replace(/^Error invoking remote method '[^']+': Error: /, "");
}

async function test() {
  setBusy(true);
  setStatus("Checking server...");
  try {
    const result = await window.homeDash.test(input.value);
    input.value = result.serverUrl;
    setStatus(`Connected to HomeDash ${result.version}.`, "success");
    return true;
  } catch (error) {
    setStatus(messageFrom(error), "error");
    return false;
  } finally {
    setBusy(false);
  }
}

testButton.addEventListener("click", test);
form.addEventListener("submit", async (event) => {
  event.preventDefault();
  setBusy(true);
  setStatus("Connecting securely...");
  try {
    await window.homeDash.connect(input.value);
  } catch (error) {
    setStatus(messageFrom(error), "error");
    setBusy(false);
  }
});

window.homeDash.defaultServer().then((value) => {
  input.value = value;
  input.focus();
  input.select();
});
