Homedash Proxmox VE package

1. Upload homedash-pve-package.tar.gz to the Proxmox VE host.
2. Run as root:

   tar -xzf homedash-pve-package.tar.gz
   bash homedash-pve/install.sh

The installer creates a Debian LXC, installs Docker, prompts for the Homedash
admin username/password, and starts a clean dashboard. Credentials are created
during installation and are not embedded in this package.
