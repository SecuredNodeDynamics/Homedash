#!/usr/bin/env bash
# Entry point included in a package produced by pve.build.sh.
set -Eeuo pipefail

PACKAGE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_TAR="${PACKAGE_DIR}/homedash-source.tar.gz"
PVE_SCRIPT="${PACKAGE_DIR}/pve/homedash.sh"

if [[ "${EUID}" -ne 0 ]]; then
  echo "Run this installer as root on the Proxmox VE host." >&2
  exit 1
fi
if [[ ! -f "${SOURCE_TAR}" || ! -f "${PVE_SCRIPT}" ]]; then
  echo "The Homedash PVE package is incomplete." >&2
  exit 1
fi

export HOMEDASH_SOURCE_TAR="${SOURCE_TAR}"
exec bash "${PVE_SCRIPT}" "$@"
