#!/usr/bin/env bash
# Homedash Proxmox VE installer
# Creates a Debian 13 LXC with Docker nesting, then installs Homedash.
#
# Run on the Proxmox host as root:
#   bash pve/homedash.sh
#
# Modes (whiptail menu, same idea as community-scripts):
#   1) Default Install
#   2) Advanced Install  — step wizard (root password, CT type, resources, network, features, …)
#
# Optional env overrides still work for non-interactive / default mode.
set -euo pipefail

APP="Homedash"
NSAPP="homedash"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_SCRIPT="${SCRIPT_DIR}/install/homedash-install.sh"
BACKTITLE="Homedash Proxmox VE Installer"

# App defaults
CTID="${CTID:-}"
HN="${HN:-homedash}"
CORE_COUNT="${CORE_COUNT:-2}"
RAM_SIZE="${RAM_SIZE:-4096}"
DISK_SIZE="${DISK_SIZE:-16}"
BRIDGE="${BRIDGE:-vmbr0}"
STORAGE="${STORAGE:-}"
TEMPLATE_STORAGE="${TEMPLATE_STORAGE:-}"
NET="${NET:-dhcp}"
GATEWAY="${GATEWAY:-}"
UNPRIVILEGED="${UNPRIVILEGED:-1}"
HOMEDASH_PORT="${HOMEDASH_PORT:-3080}"
HOMEDASH_REPO="${HOMEDASH_REPO:-}"
HOMEDASH_BRANCH="${HOMEDASH_BRANCH:-main}"
HOMEDASH_SOURCE_TAR="${HOMEDASH_SOURCE_TAR:-}"
HOMEDASH_ADMIN_USER="${HOMEDASH_ADMIN_USER:-}"
HOMEDASH_ADMIN_PASSWORD="${HOMEDASH_ADMIN_PASSWORD:-}"
SSH_PASSWORD="${SSH_PASSWORD:-}"
VERBOSE="${VERBOSE:-no}"
METHOD="${METHOD:-}"
OSTYPE="debian"
OSVERSION="13"

# Advanced feature defaults (Docker-in-LXC)
ENABLE_FUSE="${ENABLE_FUSE:-yes}"
ENABLE_TUN="${ENABLE_TUN:-no}"
ENABLE_NESTING="${ENABLE_NESTING:-1}"
ENABLE_KEYCTL="${ENABLE_KEYCTL:-1}"
ENABLE_MKNOD="${ENABLE_MKNOD:-0}"
ENABLE_GPU="${ENABLE_GPU:-no}"
PROTECT_CT="${PROTECT_CT:-no}"
ALLOW_MOUNT_FS="${ALLOW_MOUNT_FS:-}"
CT_TAGS="${CT_TAGS:-homedash;dashboard;docker}"
CT_TIMEZONE="${CT_TIMEZONE:-}"
MTU="${MTU:-}"
SEARCHDOMAIN="${SEARCHDOMAIN:-}"
NAMESERVER="${NAMESERVER:-}"
MACADDR="${MACADDR:-}"
VLAN="${VLAN:-}"
IPV6_METHOD="${IPV6_METHOD:-auto}"
ENABLE_SSH="${ENABLE_SSH:-yes}"
ROOT_PASSWORD="${ROOT_PASSWORD:-${SSH_PASSWORD:-}}" # plain password; empty = automatic login

RED=$'\033[0;31m'
GRN=$'\033[0;32m'
YLW=$'\033[1;33m'
BLU=$'\033[0;34m'
CYN=$'\033[0;36m'
BFR=$'\r\033[K'
HOLD='•'
CM='✔️'
CROSS='✖️'
CL=$'\033[0m'

msg_info() { echo -e " ${HOLD} ${YLW}${1}...${CL}" >&2; }
msg_ok() { echo -e "${BFR} ${CM} ${GRN}${1}${CL}" >&2; }
msg_warn() { echo -e " ${YLW}!${CL} ${1}" >&2; }
msg_error() { echo -e "${BFR} ${CROSS} ${RED}${1}${CL}" >&2; }

# Surface real failures instead of silently dropping to the shell (set -e).
trap 'rc=$?; msg_error "Command failed (exit ${rc}) at line ${LINENO}: ${BASH_COMMAND}"; exit "${rc}"' ERR

header() {
  clear
  cat <<'EOF'
    __  __                         __          __
   / / / /___  ____ ___  ___  ____/ /___ ______/ /_
  / /_/ / __ \/ __ `__ \/ _ \/ __  / __ `/ ___/ __ \
 / __  / /_/ / / / / / /  __/ /_/ / /_/ (__  ) / / /
/_/ /_/\____/_/ /_/ /_/\___/\__,_/\__,_/____/_/ /_/

  Proxmox VE LXC installer  ·  Debian 13 + Docker
EOF
  echo
}

exit_script() {
  header
  echo -e " ${CROSS} ${RED}Installation cancelled.${CL}\n"
  exit 0
}

require_pve_host() {
  if [[ ! -f /etc/pve/.version ]] && ! command -v pct >/dev/null 2>&1; then
    msg_error "This script must be run on a Proxmox VE host."
    exit 1
  fi
  if [[ "${EUID}" -ne 0 ]]; then
    msg_error "Run as root on the Proxmox host."
    exit 1
  fi
  if [[ ! -f "${INSTALL_SCRIPT}" ]]; then
    msg_error "Missing guest installer: ${INSTALL_SCRIPT}"
    exit 1
  fi
  if ! command -v whiptail >/dev/null 2>&1; then
    msg_error "whiptail is required (install package 'whiptail' / 'newt')."
    exit 1
  fi
}

next_ctid() {
  if command -v pvesh >/dev/null 2>&1; then
    pvesh get /cluster/nextid 2>/dev/null && return
  fi
  local id=100
  while pct status "${id}" &>/dev/null; do
    id=$((id + 1))
  done
  echo "${id}"
}

wt() {
  # Wrapper so cancel/back codes are easy to handle.
  whiptail --backtitle "${BACKTITLE}" "$@"
}

prompt_admin_account() {
  if [[ -n "${HOMEDASH_ADMIN_USER}" && -n "${HOMEDASH_ADMIN_PASSWORD}" ]]; then
    return
  fi

  local username password confirm
  while true; do
    username="$(wt --title "HOMEDASH ADMIN" --ok-button "Next" --cancel-button "Exit" \
      --inputbox "\nCreate the dashboard administrator.\n\nUsername (letters, numbers, . _ -):" 13 62 \
      "${HOMEDASH_ADMIN_USER:-admin}" 3>&1 1>&2 2>&3)" || exit_script
    if [[ "${username}" =~ ^[a-zA-Z0-9._-]{2,64}$ ]]; then
      break
    fi
    wt --msgbox "Username must be 2-64 characters and use only letters, numbers, . _ -" 10 64
  done

  while true; do
    password="$(wt --title "HOMEDASH ADMIN PASSWORD" --ok-button "Next" --cancel-button "Exit" \
      --passwordbox "\nAdmin password (minimum 8 characters):" 11 60 \
      3>&1 1>&2 2>&3)" || exit_script
    confirm="$(wt --title "CONFIRM ADMIN PASSWORD" --ok-button "Continue" --cancel-button "Back" \
      --passwordbox "\nEnter the admin password again:" 11 60 \
      3>&1 1>&2 2>&3)" || continue
    [[ "${#password}" -ge 8 ]] || {
      wt --msgbox "Password must be at least 8 characters." 9 54
      continue
    }
    [[ "${password}" == "${confirm}" ]] || {
      wt --msgbox "Passwords did not match." 9 48
      continue
    }
    break
  done

  HOMEDASH_ADMIN_USER="${username}"
  HOMEDASH_ADMIN_PASSWORD="${password}"
}

# ─── Storage helpers ─────────────────────────────────────────────────────────

select_storage_whiptail() {
  local kind="$1"
  local content title
  if [[ "${kind}" == "template" ]]; then
    content="vztmpl"
    title="TEMPLATE STORAGE"
  else
    content="rootdir"
    title="CONTAINER STORAGE"
  fi

  mapfile -t pools < <(pvesm status -content "${content}" 2>/dev/null | awk 'NR>1 {print $1}')
  if [[ "${#pools[@]}" -eq 0 ]]; then
    msg_error "No storage pools found with content type '${content}'."
    exit 1
  fi
  if [[ "${#pools[@]}" -eq 1 ]]; then
    echo "${pools[0]}"
    return
  fi

  local menu_items=()
  local p free
  for p in "${pools[@]}"; do
    free="$(pvesm status 2>/dev/null | awk -v s="$p" '$1==s {printf "%.1fGB", $6/1048576}')"
    menu_items+=("$p" "Free: ${free:-?}")
  done

  local choice
  choice="$(wt --title "${title}" --ok-button "Select" --cancel-button "Exit" \
    --menu "\nSelect ${kind} storage pool:" 18 60 8 \
    "${menu_items[@]}" 3>&1 1>&2 2>&3)" || exit_script
  echo "${choice}"
}

ensure_template() {
  local storage="$1"
  local template_name
  template_name="$(pveam available -section system 2>/dev/null | awk '/debian-13-standard_.*_amd64\.tar\.zst/{print $2}' | sort -V | tail -n1)"
  if [[ -z "${template_name}" ]]; then
    template_name="debian-13-standard_13.1-2_amd64.tar.zst"
  fi

  if ! pveam list "${storage}" 2>/dev/null | grep -q "${template_name}"; then
    msg_info "Downloading template ${template_name}"
    pveam update >/dev/null
    pveam download "${storage}" "${template_name}"
    msg_ok "Downloaded ${template_name}"
  else
    msg_ok "Template present: ${template_name}"
  fi
  echo "${template_name}"
}

# ─── Homedash source prompts ─────────────────────────────────────────────────

prompt_homedash_source() {
  if [[ -n "${HOMEDASH_REPO}" || -n "${HOMEDASH_SOURCE_TAR}" ]]; then
    return
  fi

  local src_choice
  src_choice="$(wt --title "HOMEDASH SOURCE" --ok-button "Next" --cancel-button "Exit" \
    --radiolist "\nHow should Homedash source be provided?\n\nUse SPACE to select, ENTER to confirm." 14 68 2 \
    "tar" "Packed tarball on this Proxmox host (recommended)" ON \
    "git" "Clone from a git repository URL" OFF \
    3>&1 1>&2 2>&3)" || exit_script

  if [[ "${src_choice}" == "git" ]]; then
    HOMEDASH_REPO="$(wt --title "GIT REPOSITORY" --ok-button "Next" --cancel-button "Exit" \
      --inputbox "\nGit repository URL for Homedash:" 10 70 "" \
      3>&1 1>&2 2>&3)" || exit_script
    [[ -z "${HOMEDASH_REPO}" ]] && { msg_error "Repository URL required."; exit 1; }
    HOMEDASH_BRANCH="$(wt --title "GIT BRANCH" --ok-button "Next" --cancel-button "Exit" \
      --inputbox "\nGit branch:" 10 58 "${HOMEDASH_BRANCH}" \
      3>&1 1>&2 2>&3)" || exit_script
    HOMEDASH_BRANCH="${HOMEDASH_BRANCH:-main}"
  else
    HOMEDASH_SOURCE_TAR="$(wt --title "SOURCE TARBALL" --ok-button "Next" --cancel-button "Exit" \
      --inputbox "\nAbsolute path to homedash-source.tar.gz on this host:\n\nCreate with: bash pve/pack-source.sh" 12 70 \
      "${HOMEDASH_SOURCE_TAR:-/root/homedash-source.tar.gz}" \
      3>&1 1>&2 2>&3)" || exit_script
  fi

  HOMEDASH_PORT="$(wt --title "HOMEDASH PORT" --ok-button "Next" --cancel-button "Exit" \
    --inputbox "\nHTTP port published on the container:" 10 58 "${HOMEDASH_PORT}" \
    3>&1 1>&2 2>&3)" || exit_script
  HOMEDASH_PORT="${HOMEDASH_PORT:-3080}"

  validate_homedash_source
}

validate_homedash_source() {
  if [[ -n "${HOMEDASH_SOURCE_TAR}" && ! -f "${HOMEDASH_SOURCE_TAR}" ]]; then
    msg_error "Source tarball not found: ${HOMEDASH_SOURCE_TAR}"
    echo "Create it with: bash pve/pack-source.sh" >&2
    exit 1
  fi
  if [[ -z "${HOMEDASH_REPO}" && -z "${HOMEDASH_SOURCE_TAR}" ]]; then
    msg_error "No Homedash source provided (repo or tarball)."
    exit 1
  fi
}

# ─── Default install ─────────────────────────────────────────────────────────

default_settings() {
  header
  echo -e " ${BLU}Using Default Settings${CL}\n"

  CTID="${CTID:-$(next_ctid)}"
  HN="${HN:-homedash}"
  UNPRIVILEGED=1
  ENABLE_NESTING=1
  ENABLE_KEYCTL=1
  ENABLE_FUSE=yes
  ENABLE_TUN=no
  ENABLE_MKNOD=0
  ENABLE_GPU=no
  PROTECT_CT=no
  NET="${NET:-dhcp}"
  BRIDGE="${BRIDGE:-vmbr0}"
  CORE_COUNT="${CORE_COUNT:-2}"
  RAM_SIZE="${RAM_SIZE:-4096}"
  DISK_SIZE="${DISK_SIZE:-16}"
  CT_TAGS="homedash;dashboard;docker"
  VERBOSE="${VERBOSE:-no}"
  ROOT_PASSWORD="${ROOT_PASSWORD:-${SSH_PASSWORD:-}}"

  if [[ -z "${TEMPLATE_STORAGE}" ]]; then
    TEMPLATE_STORAGE="$(select_storage_whiptail template)"
  fi
  if [[ -z "${STORAGE}" ]]; then
    STORAGE="$(select_storage_whiptail container)"
  fi

  prompt_homedash_source

  echo -e " ${YLW}Default install summary${CL}"
  echo "  CTID:       ${CTID}"
  echo "  Hostname:   ${HN}"
  echo "  Type:       Unprivileged"
  echo "  Resources:  ${CORE_COUNT} CPU / ${RAM_SIZE} MiB / ${DISK_SIZE} GB"
  echo "  Network:    ${NET} on ${BRIDGE}"
  echo "  Features:   nesting + keyctl + fuse (Docker)"
  echo "  Root PW:    ${ROOT_PASSWORD:+********}${ROOT_PASSWORD:-Automatic Login}"
  if [[ -n "${HOMEDASH_REPO}" ]]; then
    echo "  Source:     git ${HOMEDASH_REPO} (${HOMEDASH_BRANCH})"
  else
    echo "  Source:     ${HOMEDASH_SOURCE_TAR}"
  fi
  echo "  Port:       ${HOMEDASH_PORT}"
  echo
  if ! wt --title "CONFIRM DEFAULT INSTALL" --yesno \
    "\nCreate Homedash LXC with default settings?\n\nCTID ${CTID} · ${HN} · Debian ${OSVERSION}\n${CORE_COUNT} CPU / ${RAM_SIZE} MiB / ${DISK_SIZE} GB\nhttp://<ip>:${HOMEDASH_PORT}" 14 62; then
    exit_script
  fi
}

# ─── Advanced install wizard ─────────────────────────────────────────────────

advanced_settings() {
  local STEP=1
  local MAX_STEP=24
  local result PW1 PW2

  # Locals for back-navigation
  local _ct_type="${UNPRIVILEGED}"
  local _pw=""
  local _pw_display="Automatic Login"
  local _ct_id="${CTID:-$(next_ctid)}"
  local _hostname="${HN}"
  local _disk_size="${DISK_SIZE}"
  local _core_count="${CORE_COUNT}"
  local _ram_size="${RAM_SIZE}"
  local _bridge="${BRIDGE}"
  local _net="${NET}"
  local _gate="${GATEWAY}"
  local _ipv6_method="${IPV6_METHOD}"
  local _mtu="${MTU}"
  local _sd="${SEARCHDOMAIN}"
  local _ns="${NAMESERVER}"
  local _mac="${MACADDR}"
  local _vlan="${VLAN}"
  local _tags="${CT_TAGS}"
  local _enable_fuse="${ENABLE_FUSE}"
  local _enable_tun="${ENABLE_TUN}"
  local _enable_nesting="${ENABLE_NESTING}"
  local _enable_keyctl="${ENABLE_KEYCTL}"
  local _enable_mknod="${ENABLE_MKNOD}"
  local _enable_gpu="${ENABLE_GPU}"
  local _protect_ct="${PROTECT_CT}"
  local _mount_fs="${ALLOW_MOUNT_FS}"
  local _enable_ssh="${ENABLE_SSH}"
  local _verbose="${VERBOSE}"
  local _port="${HOMEDASH_PORT}"
  local _repo="${HOMEDASH_REPO}"
  local _branch="${HOMEDASH_BRANCH}"
  local _tar="${HOMEDASH_SOURCE_TAR}"
  local _tz="${CT_TIMEZONE}"

  if [[ -z "${_tz}" ]] && command -v timedatectl >/dev/null 2>&1; then
    _tz="$(timedatectl show --value --property=Timezone 2>/dev/null || true)"
  fi
  [[ "${_tz:-}" == Etc/* ]] && _tz="host"

  header
  echo -e " ${RED}Using Advanced Install${CL}\n"

  while ((STEP <= MAX_STEP)); do
    if ((STEP < 1)); then
      exit_script
    fi
    case "${STEP}" in

    1) # Container type
      local def_unpriv=ON def_priv=OFF
      [[ "${_ct_type}" == "0" ]] && { def_unpriv=OFF; def_priv=ON; }
      if result="$(wt --title "CONTAINER TYPE [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Exit" \
        --radiolist "\nChoose container type:\n\nUse SPACE to select, ENTER to confirm." 14 58 2 \
        "1" "Unprivileged (recommended)" "${def_unpriv}" \
        "0" "Privileged" "${def_priv}" \
        3>&1 1>&2 2>&3)"; then
        _ct_type="${result:-1}"
        ((STEP++))
      else
        exit_script
      fi
      ;;

    2) # Root password
      if PW1="$(wt --title "ROOT PASSWORD [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Back" \
        --passwordbox "\nSet Root Password (needed for root SSH access)\n\nLeave blank for automatic login (no password)" 12 58 \
        3>&1 1>&2 2>&3)"; then
        if [[ -z "${PW1}" ]]; then
          _pw=""
          _pw_display="Automatic Login"
          ((STEP++))
        elif [[ "${PW1}" == *" "* ]]; then
          wt --msgbox "Password cannot contain spaces." 8 58
        else
          local clean="${PW1}"
          while [[ "${clean}" == -* ]]; do clean="${clean#-}"; done
          if [[ -z "${clean}" ]]; then
            wt --msgbox "Password cannot be only '-' characters." 8 58
          elif ((${#clean} < 5)); then
            wt --msgbox "Password must be at least 5 characters." 8 58
          elif PW2="$(wt --title "PASSWORD VERIFICATION [Step ${STEP}/${MAX_STEP}]" \
            --ok-button "Confirm" --cancel-button "Back" \
            --passwordbox "\nVerify Root Password" 10 58 \
            3>&1 1>&2 2>&3)"; then
            local clean2="${PW2}"
            while [[ "${clean2}" == -* ]]; do clean2="${clean2#-}"; done
            if [[ "${clean}" == "${clean2}" ]]; then
              _pw="${clean}"
              _pw_display="********"
              ((STEP++))
            else
              wt --msgbox "Passwords do not match. Please try again." 8 58
            fi
          else
            ((STEP--))
          fi
        fi
      else
        ((STEP--))
      fi
      ;;

    3) # CTID
      if result="$(wt --title "CONTAINER ID [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Back" \
        --inputbox "\nEnter Container ID:" 10 58 "${_ct_id}" \
        3>&1 1>&2 2>&3)"; then
        if [[ ! "${result}" =~ ^[0-9]+$ ]]; then
          wt --msgbox "Container ID must be numeric." 8 58
        elif pct status "${result}" &>/dev/null; then
          if wt --title "ID ALREADY IN USE" --yesno \
            "\nContainer ID ${result} already exists.\n\nUse next available ID instead?" 10 58; then
            _ct_id="$(next_ctid)"
            ((STEP++))
          fi
        else
          _ct_id="${result}"
          ((STEP++))
        fi
      else
        ((STEP--))
      fi
      ;;

    4) # Hostname
      if result="$(wt --title "HOSTNAME [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Back" \
        --inputbox "\nSet Hostname:" 10 58 "${_hostname}" \
        3>&1 1>&2 2>&3)"; then
        if [[ "${result}" =~ ^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?([.][a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$ ]]; then
          _hostname="${result}"
          ((STEP++))
        else
          wt --msgbox "Invalid hostname.\n\nUse lowercase letters, digits, dots and hyphens." 10 58
        fi
      else
        ((STEP--))
      fi
      ;;

    5) # Disk
      if result="$(wt --title "DISK SIZE [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Back" \
        --inputbox "\nSet Disk Size in GB:" 10 58 "${_disk_size}" \
        3>&1 1>&2 2>&3)"; then
        if [[ "${result}" =~ ^[1-9][0-9]*$ ]]; then
          _disk_size="${result}"
          ((STEP++))
        else
          wt --msgbox "Disk size must be a positive integer." 8 58
        fi
      else
        ((STEP--))
      fi
      ;;

    6) # CPU
      if result="$(wt --title "CPU CORES [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Back" \
        --inputbox "\nAllocate CPU cores:" 10 58 "${_core_count}" \
        3>&1 1>&2 2>&3)"; then
        if [[ "${result}" =~ ^[1-9][0-9]*$ ]]; then
          _core_count="${result}"
          ((STEP++))
        else
          wt --msgbox "CPU core count must be a positive integer." 8 58
        fi
      else
        ((STEP--))
      fi
      ;;

    7) # RAM
      if result="$(wt --title "RAM SIZE [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Back" \
        --inputbox "\nAllocate RAM in MiB:" 10 58 "${_ram_size}" \
        3>&1 1>&2 2>&3)"; then
        if [[ "${result}" =~ ^[1-9][0-9]*$ ]]; then
          _ram_size="${result}"
          ((STEP++))
        else
          wt --msgbox "RAM size must be a positive integer." 8 58
        fi
      else
        ((STEP--))
      fi
      ;;

    8) # Bridge
      if result="$(wt --title "BRIDGE [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Back" \
        --inputbox "\nSet network bridge (e.g. vmbr0):" 10 58 "${_bridge}" \
        3>&1 1>&2 2>&3)"; then
        _bridge="${result:-vmbr0}"
        ((STEP++))
      else
        ((STEP--))
      fi
      ;;

    9) # IPv4
      if result="$(wt --title "IPv4 NETWORK [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Back" \
        --radiolist "\nIPv4 configuration:\n\nUse SPACE to select." 14 62 2 \
        "dhcp" "DHCP (automatic)" "$([[ ${_net} == dhcp ]] && echo ON || echo OFF)" \
        "static" "Static IPv4 CIDR" "$([[ ${_net} != dhcp ]] && echo ON || echo OFF)" \
        3>&1 1>&2 2>&3)"; then
        if [[ "${result}" == "dhcp" ]]; then
          _net="dhcp"
          _gate=""
          ((STEP++))
        else
          local static_ip gateway_ip
          if static_ip="$(wt --title "STATIC IPv4" --ok-button "Next" --cancel-button "Back" \
            --inputbox "\nEnter IPv4 CIDR (e.g. 192.168.1.50/24):" 10 62 \
            "$([[ ${_net} != dhcp ]] && echo "${_net}" || echo "")" \
            3>&1 1>&2 2>&3)"; then
            if [[ ! "${static_ip}" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}/[0-9]{1,2}$ ]]; then
              wt --msgbox "Invalid IPv4 CIDR.\nExample: 192.168.1.50/24" 10 58
              continue
            fi
            if gateway_ip="$(wt --title "GATEWAY" --ok-button "Next" --cancel-button "Back" \
              --inputbox "\nEnter Gateway IPv4:" 10 58 "${_gate}" \
              3>&1 1>&2 2>&3)"; then
              if [[ ! "${gateway_ip}" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
                wt --msgbox "Invalid gateway IP." 8 58
                continue
              fi
              _net="${static_ip}"
              _gate="${gateway_ip}"
              ((STEP++))
            else
              continue
            fi
          else
            continue
          fi
        fi
      else
        ((STEP--))
      fi
      ;;

    10) # IPv6
      if result="$(wt --title "IPv6 NETWORK [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Back" \
        --radiolist "\nIPv6 configuration:" 14 58 3 \
        "auto" "SLAAC / auto" "$([[ ${_ipv6_method} == auto ]] && echo ON || echo OFF)" \
        "dhcp" "DHCPv6" "$([[ ${_ipv6_method} == dhcp ]] && echo ON || echo OFF)" \
        "none" "Disabled" "$([[ ${_ipv6_method} == none ]] && echo ON || echo OFF)" \
        3>&1 1>&2 2>&3)"; then
        _ipv6_method="${result:-auto}"
        ((STEP++))
      else
        ((STEP--))
      fi
      ;;

    11) # MTU / DNS / MAC / VLAN (compact advanced networking)
      if result="$(wt --title "MTU SIZE [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Back" \
        --inputbox "\nInterface MTU (blank = default 1500):" 10 58 "${_mtu}" \
        3>&1 1>&2 2>&3)"; then
        if [[ -n "${result}" && ! "${result}" =~ ^[0-9]+$ ]]; then
          wt --msgbox "MTU must be numeric (576-65535)." 8 58
        else
          _mtu="${result}"
          ((STEP++))
        fi
      else
        ((STEP--))
      fi
      ;;

    12)
      if result="$(wt --title "DNS SEARCH DOMAIN [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Back" \
        --inputbox "\nDNS search domain (blank = host default):" 10 58 "${_sd}" \
        3>&1 1>&2 2>&3)"; then
        _sd="${result}"
        ((STEP++))
      else
        ((STEP--))
      fi
      ;;

    13)
      if result="$(wt --title "DNS SERVER [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Back" \
        --inputbox "\nDNS server IP (blank = host default):" 10 58 "${_ns}" \
        3>&1 1>&2 2>&3)"; then
        _ns="${result}"
        ((STEP++))
      else
        ((STEP--))
      fi
      ;;

    14)
      if result="$(wt --title "MAC ADDRESS [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Back" \
        --inputbox "\nMAC address (blank = auto):\nFormat XX:XX:XX:XX:XX:XX" 11 58 "${_mac}" \
        3>&1 1>&2 2>&3)"; then
        if [[ -n "${result}" && ! "${result}" =~ ^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$ ]]; then
          wt --msgbox "Invalid MAC address format." 8 58
        else
          _mac="${result}"
          ((STEP++))
        fi
      else
        ((STEP--))
      fi
      ;;

    15)
      if result="$(wt --title "VLAN TAG [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Back" \
        --inputbox "\nVLAN tag 1-4094 (blank = none):" 10 58 "${_vlan}" \
        3>&1 1>&2 2>&3)"; then
        if [[ -n "${result}" && ! "${result}" =~ ^([1-9]|[1-9][0-9]{1,2}|[1-3][0-9]{3}|40[0-8][0-9]|409[0-4])$ ]]; then
          wt --msgbox "VLAN must be 1-4094." 8 58
        else
          _vlan="${result}"
          ((STEP++))
        fi
      else
        ((STEP--))
      fi
      ;;

    16) # Tags
      if result="$(wt --title "CONTAINER TAGS [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Back" \
        --inputbox "\nSemicolon-separated tags:" 10 58 "${_tags}" \
        3>&1 1>&2 2>&3)"; then
        _tags="$(echo "${result}" | tr -d '[:space:]')"
        ((STEP++))
      else
        ((STEP--))
      fi
      ;;

    17) # SSH
      if wt --title "SSH ACCESS [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Back" \
        --yesno "\nEnable SSH server inside the container?\n\nRoot password (if set) can be used for SSH login." 12 58; then
        _enable_ssh="yes"
        ((STEP++))
      else
        local rc=$?
        if [[ ${rc} -eq 1 ]]; then
          _enable_ssh="no"
          ((STEP++))
        else
          ((STEP--))
        fi
      fi
      ;;

    18) # FUSE
      local fuse_flag="--defaultno"
      [[ "${_enable_fuse}" == "yes" || "${_enable_fuse}" == "1" ]] && fuse_flag=""
      if wt --title "FUSE SUPPORT [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Back" ${fuse_flag} \
        --yesno "\nEnable FUSE support?\n\nRecommended for Docker-in-LXC / AppImage / rclone.\n\n(App default: yes)" 13 58; then
        _enable_fuse="yes"
        ((STEP++))
      else
        local rc=$?
        if [[ ${rc} -eq 1 ]]; then
          _enable_fuse="no"
          ((STEP++))
        else
          ((STEP--))
        fi
      fi
      ;;

    19) # TUN
      local tun_flag="--defaultno"
      [[ "${_enable_tun}" == "yes" || "${_enable_tun}" == "1" ]] && tun_flag=""
      if wt --title "TUN/TAP SUPPORT [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Back" ${tun_flag} \
        --yesno "\nEnable TUN/TAP?\n\nRequired for WireGuard, OpenVPN, Tailscale, etc.\n\n(App default: no)" 13 62; then
        _enable_tun="yes"
        ((STEP++))
      else
        local rc=$?
        if [[ ${rc} -eq 1 ]]; then
          _enable_tun="no"
          ((STEP++))
        else
          ((STEP--))
        fi
      fi
      ;;

    20) # Nesting
      local nest_flag=""
      [[ "${_enable_nesting}" == "0" ]] && nest_flag="--defaultno"
      if wt --title "NESTING SUPPORT [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Back" ${nest_flag} \
        --yesno "\nEnable Nesting?\n\nRequired for Docker / Podman inside the LXC.\n\n(App default: enabled)" 13 58; then
        _enable_nesting="1"
        ((STEP++))
      else
        local rc=$?
        if [[ ${rc} -eq 1 ]]; then
          _enable_nesting="0"
          wt --msgbox "Warning: Homedash needs Docker. Without nesting, Docker-in-LXC usually fails." 10 62
          ((STEP++))
        else
          ((STEP--))
        fi
      fi
      ;;

    21) # Keyctl (auto for unprivileged)
      if [[ "${_ct_type}" == "1" ]]; then
        _enable_keyctl="1"
        ((STEP++))
        continue
      fi
      local key_flag="--defaultno"
      [[ "${_enable_keyctl}" == "1" ]] && key_flag=""
      if wt --title "KEYCTL SUPPORT [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Back" ${key_flag} \
        --yesno "\nEnable Keyctl?\n\nRequired for Docker / systemd keyring ops.\n\n(App default: enabled for Homedash)" 13 62; then
        _enable_keyctl="1"
        ((STEP++))
      else
        local rc=$?
        if [[ ${rc} -eq 1 ]]; then
          _enable_keyctl="0"
          ((STEP++))
        else
          ((STEP--))
        fi
      fi
      ;;

    22) # GPU / mknod / protection / mount / timezone (bundled confirm flow)
      local gpu_flag="--defaultno"
      [[ "${_enable_gpu}" == "yes" ]] && gpu_flag=""
      if wt --title "GPU PASSTHROUGH [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Back" ${gpu_flag} \
        --yesno "\nEnable basic GPU (/dev/dri) passthrough?\n\nUseful for hardware acceleration.\n\n(App default: no)" 13 62; then
        _enable_gpu="yes"
      else
        local rc=$?
        if [[ ${rc} -eq 1 ]]; then
          _enable_gpu="no"
        else
          ((STEP--))
          continue
        fi
      fi

      local mknod_flag="--defaultno"
      [[ "${_enable_mknod}" == "1" ]] && mknod_flag=""
      if wt --title "DEVICE NODE CREATION" --ok-button "Next" --cancel-button "Back" ${mknod_flag} \
        --yesno "\nAllow mknod (device node creation)?\n\n(App default: no)" 11 58; then
        _enable_mknod="1"
      else
        local rc=$?
        if [[ ${rc} -eq 1 ]]; then
          _enable_mknod="0"
        else
          continue
        fi
      fi

      local prot_flag="--defaultno"
      [[ "${_protect_ct}" == "yes" || "${_protect_ct}" == "1" ]] && prot_flag=""
      if wt --title "CONTAINER PROTECTION" --ok-button "Next" --cancel-button "Back" ${prot_flag} \
        --yesno "\nEnable container protection?\n\nPrevents accidental deletion.\n\n(App default: no)" 12 58; then
        _protect_ct="yes"
      else
        local rc=$?
        if [[ ${rc} -eq 1 ]]; then
          _protect_ct="no"
        else
          continue
        fi
      fi

      if result="$(wt --title "MOUNT FILESYSTEMS" --ok-button "Next" --cancel-button "Back" \
        --inputbox "\nAllowed mount filesystems (comma-separated).\nExample: nfs,cifs\nLeave blank for none." 12 58 "${_mount_fs}" \
        3>&1 1>&2 2>&3)"; then
        _mount_fs="${result// /}"
      else
        continue
      fi

      if result="$(wt --title "CONTAINER TIMEZONE" --ok-button "Next" --cancel-button "Back" \
        --inputbox "\nTimezone (blank = host).\nExamples: America/Los_Angeles, UTC, Europe/Berlin" 12 62 "${_tz}" \
        3>&1 1>&2 2>&3)"; then
        _tz="${result}"
        ((STEP++))
      else
        continue
      fi
      ;;

    23) # Homedash source + port
      local src_choice
      local tar_on=ON git_on=OFF
      [[ -n "${_repo}" ]] && { tar_on=OFF; git_on=ON; }
      if src_choice="$(wt --title "HOMEDASH SOURCE [Step ${STEP}/${MAX_STEP}]" \
        --ok-button "Next" --cancel-button "Back" \
        --radiolist "\nHomedash source:" 13 68 2 \
        "tar" "Packed tarball on this Proxmox host" "${tar_on}" \
        "git" "Git repository URL" "${git_on}" \
        3>&1 1>&2 2>&3)"; then
        if [[ "${src_choice}" == "git" ]]; then
          if result="$(wt --title "GIT REPOSITORY" --ok-button "Next" --cancel-button "Back" \
            --inputbox "\nGit repository URL:" 10 70 "${_repo}" \
            3>&1 1>&2 2>&3)"; then
            [[ -z "${result}" ]] && { wt --msgbox "Repository URL required." 8 50; continue; }
            _repo="${result}"
            _tar=""
            if result="$(wt --title "GIT BRANCH" --ok-button "Next" --cancel-button "Back" \
              --inputbox "\nGit branch:" 10 58 "${_branch:-main}" \
              3>&1 1>&2 2>&3)"; then
              _branch="${result:-main}"
            else
              continue
            fi
          else
            continue
          fi
        else
          if result="$(wt --title "SOURCE TARBALL" --ok-button "Next" --cancel-button "Back" \
            --inputbox "\nAbsolute path to homedash-source.tar.gz:" 11 70 \
            "${_tar:-/root/homedash-source.tar.gz}" \
            3>&1 1>&2 2>&3)"; then
            [[ -z "${result}" ]] && { wt --msgbox "Tarball path required." 8 50; continue; }
            if [[ ! -f "${result}" ]]; then
              wt --msgbox "File not found:\n${result}\n\nPack with: bash pve/pack-source.sh" 12 62
              continue
            fi
            _tar="${result}"
            _repo=""
          else
            continue
          fi
        fi

        if result="$(wt --title "HOMEDASH PORT" --ok-button "Next" --cancel-button "Back" \
          --inputbox "\nHTTP port:" 10 58 "${_port}" \
          3>&1 1>&2 2>&3)"; then
          if [[ ! "${result}" =~ ^[0-9]+$ ]]; then
            wt --msgbox "Port must be numeric." 8 40
            continue
          fi
          _port="${result}"
          ((STEP++))
        else
          continue
        fi
      else
        ((STEP--))
      fi
      ;;

    24) # Verbose + confirm
      local verb_flag="--defaultno"
      [[ "${_verbose}" == "yes" || "${_verbose}" == "1" ]] && verb_flag=""
      if wt --title "VERBOSE MODE [Step ${STEP}/${MAX_STEP}]" ${verb_flag} \
        --yesno "\nEnable Verbose Mode?\n\nShows detailed installer output." 11 58; then
        _verbose="yes"
      else
        _verbose="no"
      fi

      local ct_desc="Unprivileged"
      [[ "${_ct_type}" == "0" ]] && ct_desc="Privileged"
      local src_line
      if [[ -n "${_repo}" ]]; then
        src_line="git ${_repo} (${_branch})"
      else
        src_line="${_tar}"
      fi

      local summary
      summary=$(
        cat <<EOF
Type: ${ct_desc}
CTID: ${_ct_id}
Hostname: ${_hostname}
Root PW: ${_pw_display}

Resources:
  Disk ${_disk_size} GB · CPU ${_core_count} · RAM ${_ram_size} MiB

Network:
  ${_net} on ${_bridge}
  IPv6: ${_ipv6_method}

Features:
  Nesting: ${_enable_nesting} · Keyctl: ${_enable_keyctl}
  FUSE: ${_enable_fuse} · TUN: ${_enable_tun}
  GPU: ${_enable_gpu} · mknod: ${_enable_mknod}
  Protection: ${_protect_ct} · SSH: ${_enable_ssh}

Homedash:
  Source: ${src_line}
  Port: ${_port}
  Verbose: ${_verbose}
EOF
      )

      if wt --title "CONFIRM ADVANCED SETTINGS" \
        --ok-button "Create LXC" --cancel-button "Back" \
        --yesno "${summary}\n\nCreate Homedash LXC with these settings?" 28 70; then
        ((STEP++))
      else
        ((STEP--))
      fi
      ;;
    esac
  done

  # Apply wizard values to globals
  UNPRIVILEGED="${_ct_type}"
  ROOT_PASSWORD="${_pw}"
  CTID="${_ct_id}"
  HN="${_hostname}"
  DISK_SIZE="${_disk_size}"
  CORE_COUNT="${_core_count}"
  RAM_SIZE="${_ram_size}"
  BRIDGE="${_bridge}"
  NET="${_net}"
  GATEWAY="${_gate}"
  IPV6_METHOD="${_ipv6_method}"
  MTU="${_mtu}"
  SEARCHDOMAIN="${_sd}"
  NAMESERVER="${_ns}"
  MACADDR="${_mac}"
  VLAN="${_vlan}"
  CT_TAGS="${_tags}"
  ENABLE_FUSE="${_enable_fuse}"
  ENABLE_TUN="${_enable_tun}"
  ENABLE_NESTING="${_enable_nesting}"
  ENABLE_KEYCTL="${_enable_keyctl}"
  ENABLE_MKNOD="${_enable_mknod}"
  ENABLE_GPU="${_enable_gpu}"
  PROTECT_CT="${_protect_ct}"
  ALLOW_MOUNT_FS="${_mount_fs}"
  ENABLE_SSH="${_enable_ssh}"
  VERBOSE="${_verbose}"
  HOMEDASH_PORT="${_port}"
  HOMEDASH_REPO="${_repo}"
  HOMEDASH_BRANCH="${_branch}"
  HOMEDASH_SOURCE_TAR="${_tar}"
  CT_TIMEZONE="${_tz}"

  if [[ -z "${TEMPLATE_STORAGE}" ]]; then
    TEMPLATE_STORAGE="$(select_storage_whiptail template)"
  fi
  if [[ -z "${STORAGE}" ]]; then
    STORAGE="$(select_storage_whiptail container)"
  fi

  validate_homedash_source

  tput rmcup 2>/dev/null || true
  header
  echo -e " ${RED}Creating Homedash LXC with Advanced Settings${CL}\n"
  echo "  CTID ${CTID} · ${HN} · Debian ${OSVERSION}"
  echo "  ${CORE_COUNT} CPU / ${RAM_SIZE} MiB / ${DISK_SIZE} GB"
  echo "  Root PW: ${_pw_display}"
  echo
}

# ─── Install mode menu ───────────────────────────────────────────────────────

install_menu() {
  # Allow METHOD=default|advanced via env / first arg
  local choice="${METHOD:-${1:-}}"
  if [[ -z "${choice}" ]]; then
    choice="$(wt --title "Homedash Installer Options" \
      --ok-button "Select" --cancel-button "Exit Script" --notags \
      --menu "\nChoose an option:\n Use TAB/arrows to navigate, ENTER to select.\n" \
      16 60 4 \
      "1" "Default Install" \
      "2" "Advanced Install" \
      "3" "Exit" \
      --default-item "1" \
      3>&1 1>&2 2>&3)" || exit_script
  fi

  case "${choice}" in
  1 | default | DEFAULT)
    METHOD="default"
    default_settings
    ;;
  2 | advanced | ADVANCED)
    METHOD="advanced"
    advanced_settings
    ;;
  3 | exit | EXIT)
    exit_script
    ;;
  *)
    msg_error "Unknown option: ${choice}"
    exit 1
    ;;
  esac
}

# ─── Container create / install ──────────────────────────────────────────────

build_features() {
  local parts=()
  [[ "${ENABLE_NESTING}" == "1" || "${ENABLE_NESTING}" == "yes" ]] && parts+=("nesting=1")
  [[ "${ENABLE_KEYCTL}" == "1" || "${ENABLE_KEYCTL}" == "yes" ]] && parts+=("keyctl=1")
  [[ "${ENABLE_FUSE}" == "1" || "${ENABLE_FUSE}" == "yes" ]] && parts+=("fuse=1")
  [[ "${ENABLE_MKNOD}" == "1" || "${ENABLE_MKNOD}" == "yes" ]] && parts+=("mknod=1")
  if [[ -n "${ALLOW_MOUNT_FS}" ]]; then
    parts+=("mount=$(echo "${ALLOW_MOUNT_FS}" | tr ',' ';')")
  fi
  local IFS=,
  echo "${parts[*]}"
}

build_net0() {
  local net="name=eth0,bridge=${BRIDGE}"
  if [[ "${NET}" == "dhcp" ]]; then
    net+=",ip=dhcp"
  else
    net+=",ip=${NET},gw=${GATEWAY}"
  fi
  case "${IPV6_METHOD}" in
  dhcp) net+=",ip6=dhcp" ;;
  none | "") ;;
  *) net+=",ip6=auto" ;;
  esac
  [[ -n "${MTU}" ]] && net+=",mtu=${MTU}"
  [[ -n "${MACADDR}" ]] && net+=",hwaddr=${MACADDR}"
  [[ -n "${VLAN}" ]] && net+=",tag=${VLAN}"
  echo "${net}"
}

create_container() {
  local template features net0 create_log rc
  template="$(ensure_template "${TEMPLATE_STORAGE}" | tr -d '\r' | tail -n1)"
  features="$(build_features | tr -d '\r')"
  net0="$(build_net0 | tr -d '\r')"

  if [[ -z "${STORAGE}" || -z "${TEMPLATE_STORAGE}" ]]; then
    msg_error "Storage is not set (STORAGE='${STORAGE:-}' TEMPLATE_STORAGE='${TEMPLATE_STORAGE:-}')."
    exit 1
  fi
  if [[ -z "${template}" ]]; then
    msg_error "Debian 13 template name is empty."
    exit 1
  fi
  if pct status "${CTID}" &>/dev/null; then
    msg_error "CT ${CTID} already exists."
    exit 1
  fi

  local -a args=(
    create "${CTID}" "${TEMPLATE_STORAGE}:vztmpl/${template}"
    --hostname "${HN}"
    --cores "${CORE_COUNT}"
    --memory "${RAM_SIZE}"
    --swap 512
    --rootfs "${STORAGE}:${DISK_SIZE}"
    --net0 "${net0}"
    --unprivileged "${UNPRIVILEGED}"
    --ostype "${OSTYPE}"
    --onboot 1
    --startup "order=3"
    --description "Homedash dashboard (Debian ${OSVERSION} + Docker)"
  )

  # Features: apply at create when possible; fall back to pct set if create rejects them.
  [[ -n "${features}" ]] && args+=(--features "${features}")
  [[ -n "${CT_TAGS}" ]] && args+=(--tags "${CT_TAGS}")
  [[ -n "${ROOT_PASSWORD}" ]] && args+=(--password "${ROOT_PASSWORD}")

  msg_info "Creating LXC ${CTID} (${HN})"
  if [[ "${VERBOSE}" =~ ^(1|yes)$ ]]; then
    echo "  template=${TEMPLATE_STORAGE}:vztmpl/${template}" >&2
    echo "  rootfs=${STORAGE}:${DISK_SIZE}  net0=${net0}" >&2
    echo "  features=${features:-none}  unprivileged=${UNPRIVILEGED}" >&2
  fi

  create_log="$(mktemp)"
  set +e
  pct "${args[@]}" >"${create_log}" 2>&1
  rc=$?
  set -e

  if [[ ${rc} -ne 0 ]]; then
    # Retry without --features / --tags / --startup (older or picky pct builds), then set afterward.
    msg_warn "pct create failed; retrying with a minimal create, then applying options"
    echo "----- pct create output -----" >&2
    cat "${create_log}" >&2 || true
    echo "-----------------------------" >&2

    local -a minimal=(
      create "${CTID}" "${TEMPLATE_STORAGE}:vztmpl/${template}"
      --hostname "${HN}"
      --cores "${CORE_COUNT}"
      --memory "${RAM_SIZE}"
      --swap 512
      --rootfs "${STORAGE}:${DISK_SIZE}"
      --net0 "${net0}"
      --unprivileged "${UNPRIVILEGED}"
      --ostype "${OSTYPE}"
      --onboot 1
      --description "Homedash dashboard (Debian ${OSVERSION} + Docker)"
    )
    [[ -n "${ROOT_PASSWORD}" ]] && minimal+=(--password "${ROOT_PASSWORD}")

    set +e
    pct "${minimal[@]}" >"${create_log}" 2>&1
    rc=$?
    set -e
    if [[ ${rc} -ne 0 ]]; then
      msg_error "pct create failed for CT ${CTID}"
      echo "----- pct create output -----" >&2
      cat "${create_log}" >&2 || true
      echo "-----------------------------" >&2
      echo "Tip: if this mentions Debian 13 unsupported, run on the host:" >&2
      echo "  apt update && apt install --only-upgrade pve-container -y" >&2
      rm -f "${create_log}"
      exit "${rc}"
    fi
  fi
  rm -f "${create_log}"

  # Apply options that may have been skipped on the minimal retry path.
  if [[ -n "${features}" ]]; then
    pct set "${CTID}" --features "${features}" || msg_warn "Could not set features='${features}' (set them under Options → Features)"
  fi
  [[ -n "${CT_TAGS}" ]] && pct set "${CTID}" --tags "${CT_TAGS}" || true
  pct set "${CTID}" --startup "order=3" || true
  [[ -n "${SEARCHDOMAIN}" ]] && pct set "${CTID}" --searchdomain "${SEARCHDOMAIN}" || true
  [[ -n "${NAMESERVER}" ]] && pct set "${CTID}" --nameserver "${NAMESERVER}" || true
  if [[ -n "${CT_TIMEZONE}" && "${CT_TIMEZONE}" != "host" ]]; then
    pct set "${CTID}" --timezone "${CT_TIMEZONE}" || true
  fi
  [[ "${PROTECT_CT}" == "yes" || "${PROTECT_CT}" == "1" ]] && pct set "${CTID}" --protection 1 || true

  # Docker-friendly LXC tweaks
  {
    echo "lxc.apparmor.profile: unconfined"
    echo "lxc.cgroup2.devices.allow: a"
    echo "lxc.cap.drop:"
    if [[ "${ENABLE_TUN}" == "yes" || "${ENABLE_TUN}" == "1" ]]; then
      echo "lxc.cgroup2.devices.allow: c 10:200 rwm"
      echo "lxc.mount.entry: /dev/net/tun dev/net/tun none bind,create=file"
    fi
    if [[ "${ENABLE_GPU}" == "yes" && -d /dev/dri ]]; then
      echo "lxc.mount.entry: /dev/dri dev/dri none bind,optional,create=dir"
    fi
  } >>"/etc/pve/lxc/${CTID}.conf"

  msg_ok "Created CT ${CTID}"
}

start_container() {
  msg_info "Starting CT ${CTID}"
  pct start "${CTID}"
  local i
  for i in $(seq 1 60); do
    if pct exec "${CTID}" -- bash -c 'ip -4 route show default 2>/dev/null | grep -q .'; then
      break
    fi
    sleep 1
  done
  msg_ok "CT ${CTID} is running"

  if [[ "${ENABLE_SSH}" == "yes" ]]; then
    msg_info "Configuring SSH in CT"
    pct exec "${CTID}" -- bash -c '
      export DEBIAN_FRONTEND=noninteractive
      apt-get update -y >/dev/null
      apt-get install -y openssh-server >/dev/null
      sed -i "s/^#\?PermitRootLogin.*/PermitRootLogin yes/" /etc/ssh/sshd_config
      systemctl enable --now ssh >/dev/null 2>&1 || systemctl enable --now sshd >/dev/null 2>&1 || true
    ' || msg_warn "SSH setup skipped/failed (container still usable via pct enter)"
    msg_ok "SSH enabled"
  fi
}

push_and_install() {
  msg_info "Pushing installer into CT"
  pct exec "${CTID}" -- mkdir -p /root/homedash-pve/install /tmp
  pct push "${CTID}" "${INSTALL_SCRIPT}" /root/homedash-pve/install/homedash-install.sh
  pct exec "${CTID}" -- chmod +x /root/homedash-pve/install/homedash-install.sh

  if [[ -n "${HOMEDASH_SOURCE_TAR}" ]]; then
    msg_info "Pushing Homedash source tarball"
    pct push "${CTID}" "${HOMEDASH_SOURCE_TAR}" /tmp/homedash-source.tar.gz
  fi
  msg_ok "Files pushed"

  msg_info "Installing Docker + Homedash inside CT (this takes a while)"
  local env_args=(
    "HOMEDASH_PORT=${HOMEDASH_PORT}"
    "HOMEDASH_BRANCH=${HOMEDASH_BRANCH}"
    "HOMEDASH_ADMIN_USER=${HOMEDASH_ADMIN_USER}"
    "HOMEDASH_ADMIN_PASSWORD=${HOMEDASH_ADMIN_PASSWORD}"
  )
  if [[ -n "${HOMEDASH_REPO}" ]]; then
    env_args+=("HOMEDASH_REPO=${HOMEDASH_REPO}")
  else
    env_args+=("HOMEDASH_SOURCE_TAR=/tmp/homedash-source.tar.gz")
  fi

  pct exec "${CTID}" -- env "${env_args[@]}" bash /root/homedash-pve/install/homedash-install.sh
  msg_ok "Guest installation finished"
}

ct_ip() {
  pct exec "${CTID}" -- hostname -I 2>/dev/null | awk '{print $1}'
}

finish() {
  local ip
  ip="$(ct_ip)"
  echo
  msg_ok "${APP} LXC is ready"
  echo -e "  ${YLW}Mode:${CL}     ${METHOD}"
  echo -e "  ${YLW}CTID:${CL}     ${CTID}"
  echo -e "  ${YLW}Hostname:${CL} ${HN}"
  echo -e "  ${YLW}URL:${CL}      http://${ip:-<ct-ip>}:${HOMEDASH_PORT}"
  if [[ -n "${ROOT_PASSWORD}" ]]; then
    echo -e "  ${YLW}SSH:${CL}      root@${ip:-<ct-ip>}  (password set in Advanced Install)"
  else
    echo -e "  ${YLW}Console:${CL}  pct enter ${CTID}  (automatic login)"
  fi
  echo
  echo "  Manage from host:"
  echo "    pct enter ${CTID}"
  echo "    pct exec ${CTID} -- bash -lc 'cd /opt/homedash && docker compose ps'"
  echo "    pct exec ${CTID} -- bash -lc 'cd /opt/homedash && docker compose logs -f'"
  echo
}

# Re-exec with CRLF stripped if this file was copied from Windows/SMB with CRLF
# endings (breaks bash line continuations and causes silent-looking failures).
fix_crlf_and_reexec() {
  if LC_ALL=C grep -q $'\r' "${BASH_SOURCE[0]}" 2>/dev/null; then
    local tmp
    tmp="$(mktemp /tmp/homedash-pve.XXXXXX.sh)"
    tr -d '\r' <"${BASH_SOURCE[0]}" >"${tmp}"
    chmod +x "${tmp}"
    echo "Note: stripped Windows CRLF line endings from installer; re-running..." >&2
    exec bash "${tmp}" "$@"
  fi
}

main() {
  fix_crlf_and_reexec "$@"
  require_pve_host
  install_menu "${1:-}"
  prompt_admin_account
  create_container
  start_container
  push_and_install
  finish
}

main "$@"
