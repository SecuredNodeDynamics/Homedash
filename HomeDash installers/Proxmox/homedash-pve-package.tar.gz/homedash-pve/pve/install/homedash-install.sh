#!/usr/bin/env bash
# Homedash guest installer — runs inside the Debian LXC.
# Installs Docker + Compose, deploys Homedash, and starts the stack.
set -euo pipefail

APP="Homedash"
INSTALL_DIR="${HOMEDASH_INSTALL_DIR:-/opt/homedash}"
DATA_DIR="${HOMEDASH_DATA_DIR:-/opt/homedash/data}"
PORT="${HOMEDASH_PORT:-3080}"
REPO_URL="${HOMEDASH_REPO:-}"
REPO_BRANCH="${HOMEDASH_BRANCH:-main}"
SOURCE_TAR="${HOMEDASH_SOURCE_TAR:-/tmp/homedash-source.tar.gz}"

RED=$'\033[0;31m'
GRN=$'\033[0;32m'
YLW=$'\033[1;33m'
CYN=$'\033[0;36m'
CL=$'\033[0m'

msg_info() { echo -e "${CYN}[INFO]${CL} $1"; }
msg_ok() { echo -e "${GRN}[OK]${CL} $1"; }
msg_warn() { echo -e "${YLW}[WARN]${CL} $1"; }
msg_error() { echo -e "${RED}[ERROR]${CL} $1" >&2; }

require_root() {
  if [[ "${EUID}" -ne 0 ]]; then
    msg_error "Run as root inside the container."
    exit 1
  fi
}

detect_debian_codename() {
  . /etc/os-release
  echo "${VERSION_CODENAME:-trixie}"
}

install_base_packages() {
  msg_info "Updating OS packages"
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -y
  apt-get upgrade -y
  apt-get install -y \
    ca-certificates \
    curl \
    gnupg \
    git \
    jq \
    openssl \
    rsync \
    tar \
    unzip \
    wget
  msg_ok "Base packages installed"
}

install_docker() {
  if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
    msg_ok "Docker already installed ($(docker --version))"
    return
  fi

  msg_info "Installing Docker Engine + Compose plugin"
  install -m 0755 -d /etc/apt/keyrings
  if [[ ! -f /etc/apt/keyrings/docker.asc ]]; then
    curl -fsSL https://download.docker.com/linux/debian/gpg -o /etc/apt/keyrings/docker.asc
    chmod a+r /etc/apt/keyrings/docker.asc
  fi

  local codename arch
  codename="$(detect_debian_codename)"
  arch="$(dpkg --print-architecture)"
  cat >/etc/apt/sources.list.d/docker.list <<EOF
deb [arch=${arch} signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/debian ${codename} stable
EOF

  apt-get update -y
  apt-get install -y \
    docker-ce \
    docker-ce-cli \
    containerd.io \
    docker-buildx-plugin \
    docker-compose-plugin

  systemctl enable --now docker
  msg_ok "Docker installed ($(docker --version))"
}

configure_docker_daemon() {
  mkdir -p /etc/docker
  if [[ ! -f /etc/docker/daemon.json ]]; then
    cat >/etc/docker/daemon.json <<'EOF'
{
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  },
  "storage-driver": "overlay2"
}
EOF
    systemctl restart docker
    msg_ok "Configured Docker daemon (overlay2 + log rotation)"
  fi
}

deploy_source() {
  mkdir -p "${INSTALL_DIR}"

  if [[ -n "${REPO_URL}" ]]; then
    msg_info "Cloning Homedash from ${REPO_URL} (${REPO_BRANCH})"
    if [[ -d "${INSTALL_DIR}/.git" ]]; then
      git -C "${INSTALL_DIR}" fetch --depth 1 origin "${REPO_BRANCH}"
      git -C "${INSTALL_DIR}" checkout -B "${REPO_BRANCH}" "origin/${REPO_BRANCH}"
    else
      rm -rf "${INSTALL_DIR:?}/"* "${INSTALL_DIR}"/.[!.]* "${INSTALL_DIR}"/..?* 2>/dev/null || true
      git clone --depth 1 --branch "${REPO_BRANCH}" "${REPO_URL}" "${INSTALL_DIR}"
    fi
    msg_ok "Source cloned"
    return
  fi

  if [[ -f "${SOURCE_TAR}" ]]; then
    msg_info "Extracting Homedash source from ${SOURCE_TAR}"
    rm -rf "${INSTALL_DIR:?}/"* "${INSTALL_DIR}"/.[!.]* "${INSTALL_DIR}"/..?* 2>/dev/null || true
    tar -xzf "${SOURCE_TAR}" -C "${INSTALL_DIR}"
    # Support tarballs that wrap a single top-level directory.
    if [[ ! -f "${INSTALL_DIR}/Dockerfile" ]]; then
      local nested
      nested="$(find "${INSTALL_DIR}" -mindepth 1 -maxdepth 1 -type d | head -n1 || true)"
      if [[ -n "${nested}" && -f "${nested}/Dockerfile" ]]; then
        shopt -s dotglob
        mv "${nested}"/* "${INSTALL_DIR}/"
        rmdir "${nested}" 2>/dev/null || rm -rf "${nested}"
        shopt -u dotglob
      fi
    fi
    msg_ok "Source extracted"
    return
  fi

  if [[ -f "${INSTALL_DIR}/Dockerfile" && -f "${INSTALL_DIR}/docker-compose.yml" ]]; then
    msg_ok "Using existing source in ${INSTALL_DIR}"
    return
  fi

  msg_error "No Homedash source found."
  msg_error "Set HOMEDASH_REPO, or place a tarball at ${SOURCE_TAR}, or copy the project to ${INSTALL_DIR}."
  exit 1
}

prepare_fresh_install() {
  msg_info "Preparing clean install (no personal dashboard data from source pack)"

  # A dev-machine tarball must never seed live config, credentials, or layouts.
  rm -rf "${INSTALL_DIR}/data"
  rm -f "${INSTALL_DIR}/config/session-secret"
  rm -rf "${INSTALL_DIR}/config/uploads" "${INSTALL_DIR}/config/widgets"
  rm -rf "${INSTALL_DIR}/compliance-reports"

  mkdir -p "${DATA_DIR}/widgets" "${DATA_DIR}/uploads" "${DATA_DIR}/backups"

  # A clean PVE deployment starts with only the core widgets. Additional
  # widgets are intentionally added later from credential-free .hdwidget files.
  cat >"${DATA_DIR}/settings.json" <<'EOF'
{
  "appName": "Homedash",
  "tabs": [
    {
      "id": "home",
      "name": "Home",
      "order": 0,
      "widgetIds": ["clock", "weather", "notes", "todo", "grocery-list", "bookmarks"]
    }
  ],
  "enabledWidgets": ["clock", "weather", "notes", "todo", "grocery-list", "bookmarks"],
  "widgetInstances": [
    { "id": "clock", "widgetId": "clock", "key": "default", "label": "Clock" },
    { "id": "weather", "widgetId": "weather", "key": "default", "label": "Weather" },
    { "id": "notes", "widgetId": "notes", "key": "default", "label": "Notes" },
    { "id": "todo", "widgetId": "todo", "key": "default", "label": "Todo" },
    { "id": "grocery-list", "widgetId": "grocery-list", "key": "default", "label": "Grocery List" },
    { "id": "bookmarks", "widgetId": "bookmarks", "key": "default", "label": "Bookmarks" }
  ],
  "bookmarks": [],
  "bookmarkGroups": [{ "id": "general", "name": "General", "order": 0 }]
}
EOF

  if [[ -f "${INSTALL_DIR}/docker-compose.yml" ]]; then
    # Drop dev-machine public URL; set at deploy time if needed.
    sed -i 's/^[[:space:]]*- HOMEDASH_PUBLIC_URL=.*/      # - HOMEDASH_PUBLIC_URL=/' \
      "${INSTALL_DIR}/docker-compose.yml" 2>/dev/null || true
  fi

  msg_ok "Fresh data volume ready at ${DATA_DIR}"
}

ensure_compose_file() {
  if [[ ! -f "${INSTALL_DIR}/docker-compose.yml" ]]; then
    msg_error "Missing docker-compose.yml in ${INSTALL_DIR}"
    exit 1
  fi
  if [[ ! -f "${INSTALL_DIR}/Dockerfile" ]]; then
    msg_error "Missing Dockerfile in ${INSTALL_DIR}"
    exit 1
  fi

  mkdir -p "${DATA_DIR}/widgets" "${INSTALL_DIR}/icons"
  # Alpine image user is nextjs (uid 100) / nodejs (gid 101)
  # data/ + icons/ must be writable (uploads land in icons/)
  chown -R 100:101 "${DATA_DIR}" "${INSTALL_DIR}/icons" 2>/dev/null || true
  chmod -R u+rwX "${DATA_DIR}" "${INSTALL_DIR}/icons" 2>/dev/null || true

  # Keep published port configurable without rewriting the whole compose file.
  if grep -q '"3080:3080"' "${INSTALL_DIR}/docker-compose.yml" || grep -q '3080:3080' "${INSTALL_DIR}/docker-compose.yml"; then
    sed -i "s/3080:3080/${PORT}:3080/g" "${INSTALL_DIR}/docker-compose.yml"
  fi
}

build_and_start() {
  msg_info "Building and starting Homedash (first build can take several minutes)"
  cd "${INSTALL_DIR}"
  docker compose up -d --build
  msg_ok "Homedash container started"
}

install_widget_agent() {
  local installer="${INSTALL_DIR}/pve/widget-agent/install-agent.sh"
  if [[ ! -f "${installer}" ]]; then
    msg_error "Widget package agent installer is missing: ${installer}"
    exit 1
  fi
  msg_info "Installing the local widget package agent"
  HOMEDASH_DIR="${INSTALL_DIR}" HOMEDASH_DATA_DIR="${DATA_DIR}" \
    sh "${installer}" >/dev/null
  msg_ok "Widget package agent installed"
}

create_admin_account() {
  local username="${HOMEDASH_ADMIN_USER:-}"
  local password="${HOMEDASH_ADMIN_PASSWORD:-}"
  if [[ -z "${username}" || -z "${password}" ]]; then
    msg_error "Admin username and password were not provided by the PVE installer."
    exit 1
  fi

  msg_info "Creating Homedash administrator"
  local attempt response status
  for attempt in $(seq 1 60); do
    if curl -fsS "http://127.0.0.1:${PORT}/api/auth/me" >/dev/null 2>&1; then
      break
    fi
    sleep 2
  done

  response="$(mktemp)"
  status="$(curl -sS -o "${response}" -w '%{http_code}' \
    -H 'Content-Type: application/json' \
    --data "$(jq -cn --arg username "${username}" --arg password "${password}" \
      '{username:$username,password:$password}')" \
    "http://127.0.0.1:${PORT}/api/auth/setup" || true)"
  unset HOMEDASH_ADMIN_PASSWORD password
  if [[ "${status}" != "200" ]]; then
    msg_error "Could not create the administrator (HTTP ${status})."
    cat "${response}" >&2
    rm -f "${response}"
    exit 1
  fi
  rm -f "${response}"
  msg_ok "Administrator created"
}

write_motd() {
  local ip
  ip="$(hostname -I 2>/dev/null | awk '{print $1}')"
  cat >/etc/motd <<EOF

  Homedash LXC
  ------------
  App dir : ${INSTALL_DIR}
  Data    : ${DATA_DIR}
  URL     : http://${ip:-<ct-ip>}:${PORT}

  Useful commands:
    cd ${INSTALL_DIR} && docker compose ps
    cd ${INSTALL_DIR} && docker compose logs -f
    cd ${INSTALL_DIR} && docker compose pull && docker compose up -d --build

EOF
}

print_summary() {
  local ip
  ip="$(hostname -I 2>/dev/null | awk '{print $1}')"
  echo
  msg_ok "${APP} installation complete"
  echo -e "  ${YLW}URL:${CL}      http://${ip:-<ct-ip>}:${PORT}"
  echo -e "  ${YLW}Install:${CL}  ${INSTALL_DIR}"
  echo -e "  ${YLW}Config:${CL}   ${DATA_DIR}"
  echo
}

main() {
  require_root
  install_base_packages
  install_docker
  configure_docker_daemon
  deploy_source
  prepare_fresh_install
  ensure_compose_file
  build_and_start
  install_widget_agent
  create_admin_account
  write_motd
  print_summary
}

main "$@"
